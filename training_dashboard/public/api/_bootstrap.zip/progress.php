<?php
/**
 * progress.php — the learner writing back what they have done.
 * ---------------------------------------------------------------------------
 *   ?action=position   POST {lesson_id, seconds}   video position heartbeat
 *   ?action=complete   POST {lesson_id, done}      the "Mark as complete" item
 *
 * Both write to lms_progress, the same table the admin panel's reports read,
 * so a learner ticking a lesson here moves the admin course-progress report.
 * Every write re-checks the enrolment: a revoked or expired course can no
 * longer record progress even if the tab was left open.
 */

require_once __DIR__ . '/_bootstrap.php';

$uid    = learn_require_user();
$action = $_GET['action'] ?? '';
$in     = learn_input();

/** Resolves a lesson the learner may actually write against, or stops. */
function learn_writable_lesson($conn, $uid, $lessonId) {
    $lid = (int)$lessonId;
    if (!$lid) learn_error('A lesson id is required');

    $res = $conn->query("SELECT l.id, l.course_id, l.duration_secs, e.expiry_date, e.status
                         FROM lms_lessons l
                         JOIN lms_enrollments e ON e.course_id = l.course_id AND e.user_id = " . (int)$uid . "
                         WHERE l.id = $lid AND l.is_hidden = 0 AND l.status = 'published' LIMIT 1");
    $l = $res ? $res->fetch_assoc() : null;
    if (!$l) learn_error('That lesson is not on your account', 403);
    if ($l['status'] !== 'active') learn_error('Your enrolment in this course is not active', 403);
    if ($l['expiry_date'] && $l['expiry_date'] < date('Y-m-d')) learn_error('Your access to this course has ended', 403);
    return $l;
}

/* ── video position ────────────────────────────────────────────────────────
   Sent every few seconds while playing. Clamped to the lesson's own duration
   so a bad player event cannot store a nonsense number, and never allowed to
   move backwards — a learner scrubbing back should not lose their furthest
   point. */
if ($action === 'position') {
    $l    = learn_writable_lesson($conn, $uid, $in['lesson_id'] ?? 0);
    $secs = max(0, (int)($in['seconds'] ?? 0));
    $cap  = (int)$l['duration_secs'];
    if ($cap > 0) $secs = min($secs, $cap);

    $cid = (int)$l['course_id'];
    $lid = (int)$l['id'];
    $conn->query("INSERT INTO lms_progress (user_id, course_id, lesson_id, status, watched_secs)
                  VALUES (" . (int)$uid . ", $cid, $lid, 'started', $secs)
                  ON DUPLICATE KEY UPDATE
                      watched_secs = GREATEST(watched_secs, VALUES(watched_secs)),
                      status       = IF(status = 'completed', 'completed', 'started')");

    learn_ok(['lesson_id' => $lid, 'watched_secs' => $secs]);
}

/* ── mark complete / undo ─────────────────────────────────────────────── */
if ($action === 'complete') {
    $l    = learn_writable_lesson($conn, $uid, $in['lesson_id'] ?? 0);
    $done = array_key_exists('done', $in) ? (bool)$in['done'] : true;

    $cid    = (int)$l['course_id'];
    $lid    = (int)$l['id'];
    $status = $done ? 'completed' : 'started';

    $conn->query("INSERT INTO lms_progress (user_id, course_id, lesson_id, status, watched_secs)
                  VALUES (" . (int)$uid . ", $cid, $lid, '$status', " . (int)$l['duration_secs'] * ($done ? 1 : 0) . ")
                  ON DUPLICATE KEY UPDATE
                      status       = VALUES(status),
                      watched_secs = GREATEST(watched_secs, VALUES(watched_secs))");

    /* Hand back the fresh course percentage so the syllabus ring can move
       without the player refetching the whole course. */
    $r = $conn->query("SELECT
            (SELECT COUNT(*) FROM lms_lessons
              WHERE course_id = $cid AND is_hidden = 0 AND status = 'published') total,
            (SELECT COUNT(*) FROM lms_progress
              WHERE course_id = $cid AND user_id = " . (int)$uid . " AND status = 'completed') done");
    $c = $r ? $r->fetch_assoc() : ['total' => 0, 'done' => 0];

    learn_ok([
        'lesson_id' => $lid,
        'status'    => $status,
        'progress'  => [
            'total'     => (int)$c['total'],
            'completed' => (int)$c['done'],
            'percent'   => (int)$c['total'] > 0 ? (int)round($c['done'] * 100 / $c['total']) : 0,
        ],
    ], $done ? 'Lesson marked complete' : 'Marked as not complete');
}

learn_error('Unknown progress action: ' . $action, 404);

<?php
/**
 * track.php — portal usage analytics: how often learners come back, how long
 * they stay, and which screens and courses that time went to.
 * ---------------------------------------------------------------------------
 *   ?action=visit      POST {visit_key, path, referrer}    once per tab
 *   ?action=page       POST {visit_key, path, title, course_id, lesson_id}
 *                                                          once per navigation
 *   ?action=beat       POST {visit_key, path, lesson_id, seconds}
 *                                                          every ~15s, visible only
 *
 * Design notes
 *   • The client owns `visit_key` (a random 32-hex string kept in
 *     sessionStorage), so one browser tab is one visit and a reload does not
 *     inflate the count.
 *   • Time is accumulated by heartbeat rather than measured from an exit
 *     event: `beforeunload` is unreliable (especially on mobile), so a tab that
 *     simply disappears still leaves an accurate-to-15-seconds record.
 *   • The client only beats while the tab is visible, so an abandoned tab
 *     stops adding time instead of counting overnight.
 *   • Everything here is best-effort: a tracking failure must never surface to
 *     the learner, so the endpoint answers success even when a write is a
 *     no-op.
 */

require_once __DIR__ . '/_bootstrap.php';

$uid    = learn_require_user();
$action = $_GET['action'] ?? '';
$in     = learn_input();

/** A visit key is client-generated, so it is validated hard before use. */
function learn_visit_key($in) {
    $k = strtolower(trim((string)($in['visit_key'] ?? '')));
    return preg_match('/^[0-9a-f]{32}$/', $k) ? $k : '';
}

function learn_path($in) {
    $p = (string)($in['path'] ?? '/');
    $p = parse_url($p, PHP_URL_PATH) ?: '/';
    return substr($p, 0, 255);
}

/** Resolves visit_key -> row id, creating the visit row if this is its first ping. */
function learn_visit_id($conn, $uid, $key, $path, $referrer = '') {
    if ($key === '') return 0;
    $ke = learn_esc($conn, $key);

    $r = $conn->query("SELECT id FROM lms_learner_visits WHERE visit_key = '$ke' LIMIT 1");
    if ($r && ($row = $r->fetch_assoc())) return (int)$row['id'];

    $conn->query("INSERT INTO lms_learner_visits
        (user_id, visit_key, entry_path, referrer, ip, user_agent, last_seen_at)
        VALUES (" . (int)$uid . ", '$ke', '" . learn_esc($conn, $path) . "',
                '" . learn_esc($conn, substr((string)$referrer, 0, 500)) . "',
                '" . learn_esc($conn, learn_ip()) . "', '" . learn_esc($conn, learn_ua()) . "', NOW())");
    if ($conn->insert_id) return (int)$conn->insert_id;

    /* Two tabs racing on the same key: re-read rather than insert a duplicate. */
    $r = $conn->query("SELECT id FROM lms_learner_visits WHERE visit_key = '$ke' LIMIT 1");
    return $r && ($row = $r->fetch_assoc()) ? (int)$row['id'] : 0;
}

/* ── a new tab arrived ─────────────────────────────────────────────────── */
if ($action === 'visit') {
    $key = learn_visit_key($in);
    if (!$key) learn_ok(['visit_id' => 0]);

    $vid = learn_visit_id($conn, $uid, $key, learn_path($in), $in['referrer'] ?? '');

    /* How many separate visits this learner has made — handy on the client for
       a "welcome back" and useful as the canonical number in reports. */
    $r = $conn->query("SELECT COUNT(*) c FROM lms_learner_visits WHERE user_id = " . (int)$uid);
    $visits = $r ? (int)$r->fetch_assoc()['c'] : 0;

    learn_ok(['visit_id' => $vid, 'visit_count' => $visits]);
}

/* ── a navigation inside the app ───────────────────────────────────────── */
if ($action === 'page') {
    $key = learn_visit_key($in);
    if (!$key) learn_ok([]);

    $path = learn_path($in);
    $vid  = learn_visit_id($conn, $uid, $key, $path);
    if (!$vid) learn_ok([]);

    $lid = (int)($in['lesson_id'] ?? 0);
    $cid = (int)($in['course_id'] ?? 0);

    $conn->query("INSERT INTO lms_learner_page_views
        (visit_id, user_id, path, title, course_id, lesson_id, seconds, last_seen_at)
        VALUES ($vid, " . (int)$uid . ", '" . learn_esc($conn, $path) . "',
                '" . learn_esc($conn, substr((string)($in['title'] ?? ''), 0, 190)) . "',
                $cid, $lid, 0, NOW())
        ON DUPLICATE KEY UPDATE last_seen_at = NOW(),
                                course_id = IF(VALUES(course_id) > 0, VALUES(course_id), course_id)");

    $conn->query("UPDATE lms_learner_visits
                  SET page_views = page_views + 1, last_seen_at = NOW()
                  WHERE id = $vid");

    learn_ok([]);
}

/* ── the every-15-seconds heartbeat ────────────────────────────────────── */
if ($action === 'beat') {
    $key = learn_visit_key($in);
    if (!$key) learn_ok([]);

    $path = learn_path($in);
    $vid  = learn_visit_id($conn, $uid, $key, $path);
    if (!$vid) learn_ok([]);

    /* Clamped: a client that sleeps and wakes must not be able to donate an
       hour in one call. 120s is generous for a 15s cadence with retries. */
    $secs = min(120, max(0, (int)($in['seconds'] ?? 0)));
    if (!$secs) learn_ok([]);

    $lid = (int)($in['lesson_id'] ?? 0);
    $cid = (int)($in['course_id'] ?? 0);

    $conn->query("INSERT INTO lms_learner_page_views
        (visit_id, user_id, path, title, course_id, lesson_id, seconds, last_seen_at)
        VALUES ($vid, " . (int)$uid . ", '" . learn_esc($conn, $path) . "', NULL, $cid, $lid, $secs, NOW())
        ON DUPLICATE KEY UPDATE seconds = seconds + VALUES(seconds), last_seen_at = NOW()");

    $conn->query("UPDATE lms_learner_visits
                  SET duration_secs = duration_secs + $secs, last_seen_at = NOW()
                  WHERE id = $vid");

    learn_ok([]);
}

learn_error('Unknown track action: ' . $action, 404);

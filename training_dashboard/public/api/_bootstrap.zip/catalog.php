<?php
/**
 * catalog.php — what the signed-in learner is allowed to see and play.
 * ---------------------------------------------------------------------------
 *   ?action=home           GET   "Continue Learning" + counts for /learn
 *   ?action=enrollments    GET   the My Enrollments list
 *   ?action=course&slug=   GET   one course: sections, lessons, attachments,
 *                                the learner's progress, and the resolved
 *                                video source for each lesson
 *   ?action=lesson&id=     GET   one lesson (used when deep-linking a lesson)
 *   ?action=analytics&course_id=  GET  the course-analytics screen
 *
 * Access rule: a learner sees a course only through an active row in
 * lms_enrollments. Expired rows still list (Learnyst shows them greyed with an
 * EXPIRED chip) but their lessons are not served.
 */

require_once __DIR__ . '/_bootstrap.php';

$uid    = learn_require_user();
$action = $_GET['action'] ?? '';

/* ── how a stored video_url turns into something the player can show ───────
   Admins paste whatever their source gives them, so the shape is sniffed here
   once rather than in three different places in React. */
function learn_video_source($url, $provider) {
    $url = trim((string)$url);
    if ($url === '') return ['kind' => 'none', 'src' => '', 'embed' => ''];

    /* Vimeo — either a plain link or an already-built player URL. */
    if (preg_match('#(?:player\.)?vimeo\.com/(?:video/)?(\d+)#i', $url, $m)) {
        $q = 'title=0&byline=0&portrait=0&dnt=1';
        /* Unlisted Vimeo links carry a hash after the id: vimeo.com/ID/HASH */
        if (preg_match('#vimeo\.com/(?:video/)?\d+/([0-9a-z]+)#i', $url, $h)) $q .= '&h=' . $h[1];
        return ['kind' => 'vimeo', 'src' => $url, 'embed' => "https://player.vimeo.com/video/{$m[1]}?$q"];
    }

    /* Bunny Stream — the embed iframe, or a direct HLS playlist off the CDN. */
    if (preg_match('#iframe\.mediadelivery\.net/(?:embed|play)/(\d+)/([0-9a-f\-]+)#i', $url, $m)) {
        return [
            'kind'  => 'bunny',
            'src'   => $url,
            'embed' => "https://iframe.mediadelivery.net/embed/{$m[1]}/{$m[2]}?autoplay=false&preload=true",
        ];
    }
    if (preg_match('#\.b-cdn\.net/.+\.m3u8#i', $url)) {
        return ['kind' => 'hls', 'src' => $url, 'embed' => ''];
    }

    if (preg_match('#(?:youtube\.com/watch\?v=|youtu\.be/|youtube\.com/embed/)([A-Za-z0-9_\-]{6,})#i', $url, $m)) {
        return ['kind' => 'youtube', 'src' => $url, 'embed' => "https://www.youtube-nocookie.com/embed/{$m[1]}?rel=0&modestbranding=1"];
    }

    if (preg_match('#\.m3u8(\?|$)#i', $url))                 return ['kind' => 'hls',  'src' => $url, 'embed' => ''];
    if (preg_match('#\.(mp4|webm|ogg|mov|m4v)(\?|$)#i', $url)) return ['kind' => 'file', 'src' => $url, 'embed' => ''];

    /* An S3 object without a recognisable extension is still a direct file. */
    if ($provider === 's3' || preg_match('#amazonaws\.com/#i', $url)) {
        return ['kind' => 'file', 'src' => $url, 'embed' => ''];
    }

    /* Last resort: let an iframe try. Better than a blank frame with no clue. */
    return ['kind' => 'iframe', 'src' => $url, 'embed' => $url];
}

/** The learner's enrolments, newest first, with progress folded in. */
function learn_enrollment_rows($conn, $uid) {
    $sql = "SELECT e.id enrollment_id, e.access_type, e.amount, e.expiry_date, e.status enrollment_status,
                   e.enrolled_at, e.source,
                   c.id course_id, c.title, c.slug, c.subtitle, c.description, c.category,
                   c.thumbnail_url, c.instructor, c.validity_days,
                   (SELECT COUNT(*) FROM lms_lessons l
                      WHERE l.course_id = c.id AND l.is_hidden = 0 AND l.status = 'published') lesson_count,
                   (SELECT COUNT(*) FROM lms_lessons l
                      WHERE l.course_id = c.id AND l.is_hidden = 0 AND l.status = 'published'
                        AND l.lesson_type = 'quiz') quiz_count,
                   (SELECT COALESCE(SUM(l.duration_secs),0) FROM lms_lessons l
                      WHERE l.course_id = c.id AND l.is_hidden = 0 AND l.status = 'published') total_secs,
                   (SELECT COUNT(*) FROM lms_progress p
                      WHERE p.user_id = e.user_id AND p.course_id = c.id AND p.status = 'completed') done_count,
                   (SELECT MAX(p.updated_at) FROM lms_progress p
                      WHERE p.user_id = e.user_id AND p.course_id = c.id) last_activity
            FROM lms_enrollments e
            JOIN lms_courses c ON c.id = e.course_id
            WHERE e.user_id = " . (int)$uid . "
              AND e.status <> 'revoked'
              AND c.status = 'published'
            ORDER BY (e.expiry_date IS NOT NULL AND e.expiry_date < CURDATE()) ASC,
                     COALESCE((SELECT MAX(p.updated_at) FROM lms_progress p
                               WHERE p.user_id = e.user_id AND p.course_id = c.id), e.enrolled_at) DESC";
    $res  = $conn->query($sql);
    $rows = [];
    while ($res && ($r = $res->fetch_assoc())) {
        $lessons = (int)$r['lesson_count'];
        $done    = (int)$r['done_count'];
        $expired = $r['expiry_date'] && $r['expiry_date'] < date('Y-m-d');

        $rows[] = [
            'enrollment_id' => (int)$r['enrollment_id'],
            'course_id'     => (int)$r['course_id'],
            'title'         => $r['title'],
            'slug'          => $r['slug'],
            'subtitle'      => $r['subtitle'],
            'description'   => $r['description'],
            'category'      => $r['category'],
            'thumbnail_url' => $r['thumbnail_url'],
            'instructor'    => $r['instructor'],
            'lesson_count'  => $lessons,
            'quiz_count'    => (int)$r['quiz_count'],
            'total_secs'    => (int)$r['total_secs'],
            'completed'     => $done,
            'progress'      => $lessons > 0 ? (int)round($done * 100 / $lessons) : 0,
            'access_type'   => $r['access_type'],
            'amount'        => (float)$r['amount'],
            'source'        => $r['source'],
            'expiry_date'   => $r['expiry_date'],
            'expired'       => $expired,
            'state'         => $expired ? 'expired' : (($r['access_type'] === 'free') ? 'free' : 'purchased'),
            'enrolled_at'   => $r['enrolled_at'],
            'last_activity' => $r['last_activity'],
        ];
    }
    return $rows;
}

/* ───────────────────────────── /learn home ────────────────────────────── */
if ($action === 'home') {
    $rows = learn_enrollment_rows($conn, $uid);

    /* "Continue Learning" = whatever they touched last, else the newest
       non-expired enrolment, else simply the newest thing they own. */
    $continue = null;
    foreach ($rows as $r) { if (!$r['expired']) { $continue = $r; break; } }
    if (!$continue && $rows) $continue = $rows[0];

    learn_ok([
        'continue'    => $continue,
        'total'       => count($rows),
        'active'      => count(array_filter($rows, fn($r) => !$r['expired'])),
        'enrollments' => array_slice($rows, 0, 6),
    ]);
}

/* ─────────────────────────── my enrollments ───────────────────────────── */
if ($action === 'enrollments') {
    learn_ok(['enrollments' => learn_enrollment_rows($conn, $uid)]);
}

/* ───────────────────────── one course, in full ────────────────────────── */
if ($action === 'course') {
    $slug = trim((string)($_GET['slug'] ?? ''));
    $cid  = (int)($_GET['course_id'] ?? 0);
    if (!$slug && !$cid) learn_error('A course slug or id is required');

    $where = $cid ? "c.id = $cid" : "c.slug = '" . learn_esc($conn, $slug) . "'";
    $res = $conn->query("SELECT c.*, e.id enrollment_id, e.access_type, e.expiry_date, e.status enrollment_status
                         FROM lms_courses c
                         JOIN lms_enrollments e ON e.course_id = c.id AND e.user_id = " . (int)$uid . "
                         WHERE $where AND c.status = 'published' LIMIT 1");
    $c = $res ? $res->fetch_assoc() : null;
    if (!$c) learn_error('You are not enrolled in that course', 403);

    $expired = $c['expiry_date'] && $c['expiry_date'] < date('Y-m-d');
    if ($expired || $c['enrollment_status'] === 'revoked') {
        learn_ok([
            'course'  => [
                'id' => (int)$c['id'], 'title' => $c['title'], 'slug' => $c['slug'],
                'thumbnail_url' => $c['thumbnail_url'], 'expiry_date' => $c['expiry_date'],
            ],
            'expired' => true,
            'sections' => [],
        ], 'Your access to this course has ended.');
    }

    $cidReal = (int)$c['id'];

    /* progress first, so each lesson can be stamped without an N+1 */
    $prog = [];
    $pr = $conn->query("SELECT lesson_id, status, watched_secs FROM lms_progress
                        WHERE user_id = " . (int)$uid . " AND course_id = $cidReal");
    while ($pr && ($p = $pr->fetch_assoc())) {
        $prog[(int)$p['lesson_id']] = ['status' => $p['status'], 'watched_secs' => (int)$p['watched_secs']];
    }

    /* attachments, likewise batched */
    $atts = [];
    $ar = $conn->query("SELECT a.lesson_id, a.id, a.title, a.file_url, a.file_name, a.file_type, a.file_size, a.kind
                        FROM lms_lesson_attachments a
                        JOIN lms_lessons l ON l.id = a.lesson_id
                        WHERE l.course_id = $cidReal AND a.status = 'active'
                        ORDER BY a.sort_order, a.id");
    while ($ar && ($a = $ar->fetch_assoc())) {
        $atts[(int)$a['lesson_id']][] = [
            'id' => (int)$a['id'], 'title' => $a['title'], 'url' => $a['file_url'],
            'file_name' => $a['file_name'], 'file_type' => $a['file_type'],
            'file_size' => (int)$a['file_size'], 'kind' => $a['kind'],
        ];
    }

    $sections = [];
    $sr = $conn->query("SELECT id, title, description, sort_order FROM lms_sections
                        WHERE course_id = $cidReal AND status = 'active'
                        ORDER BY sort_order, id");
    while ($sr && ($s = $sr->fetch_assoc())) {
        $sections[(int)$s['id']] = [
            'id' => (int)$s['id'], 'title' => $s['title'], 'description' => $s['description'],
            'lessons' => [], 'lesson_count' => 0, 'quiz_count' => 0, 'attachment_count' => 0,
        ];
    }

    $lr = $conn->query("SELECT id, section_id, title, lesson_type, video_provider, video_url,
                               duration_secs, content, quiz_id, is_free_preview, sort_order
                        FROM lms_lessons
                        WHERE course_id = $cidReal AND is_hidden = 0 AND status = 'published'
                        ORDER BY sort_order, id");
    $flat = [];
    while ($lr && ($l = $lr->fetch_assoc())) {
        $lid   = (int)$l['id'];
        $video = learn_video_source($l['video_url'], $l['video_provider']);
        $item  = [
            'id'           => $lid,
            'section_id'   => (int)$l['section_id'],
            'title'        => $l['title'],
            'type'         => $l['lesson_type'],
            'duration'     => (int)$l['duration_secs'],
            'quiz_id'      => (int)$l['quiz_id'],
            'free_preview' => (int)$l['is_free_preview'] === 1,
            'video'        => $video,
            /* Article/PDF bodies are small; sending them with the syllabus lets
               the player switch lessons without a second round trip. */
            'content'      => in_array($l['lesson_type'], ['article', 'pdf'], true) ? $l['content'] : null,
            'attachments'  => $atts[$lid] ?? [],
            'status'       => $prog[$lid]['status'] ?? null,
            'watched_secs' => $prog[$lid]['watched_secs'] ?? 0,
        ];
        $flat[] = $item;

        $sid = (int)$l['section_id'];
        if (isset($sections[$sid])) {
            $sections[$sid]['lessons'][]      = $item;
            $sections[$sid]['lesson_count']  += 1;
            $sections[$sid]['quiz_count']    += ($l['lesson_type'] === 'quiz' ? 1 : 0);
            $sections[$sid]['attachment_count'] += count($item['attachments']);
        }
    }

    $doneCount = count(array_filter($flat, fn($l) => $l['status'] === 'completed'));

    learn_ok([
        'course' => [
            'id'            => $cidReal,
            'title'         => $c['title'],
            'slug'          => $c['slug'],
            'subtitle'      => $c['subtitle'],
            'description'   => $c['description'],
            'thumbnail_url' => $c['thumbnail_url'],
            'instructor'    => $c['instructor'],
            'expiry_date'   => $c['expiry_date'],
            'access_type'   => $c['access_type'],
        ],
        'expired'   => false,
        'sections'  => array_values($sections),
        'lessons'   => $flat,
        'progress'  => [
            'total'     => count($flat),
            'completed' => $doneCount,
            'percent'   => count($flat) ? (int)round($doneCount * 100 / count($flat)) : 0,
        ],
    ]);
}

/* ──────────────────────────── a single lesson ─────────────────────────── */
if ($action === 'lesson') {
    $lid = (int)($_GET['id'] ?? 0);
    if (!$lid) learn_error('A lesson id is required');

    $res = $conn->query("SELECT l.*, c.title course_title, c.slug course_slug, e.expiry_date
                         FROM lms_lessons l
                         JOIN lms_courses c     ON c.id = l.course_id
                         JOIN lms_enrollments e ON e.course_id = l.course_id AND e.user_id = " . (int)$uid . "
                         WHERE l.id = $lid AND l.is_hidden = 0 AND l.status = 'published'
                           AND e.status = 'active' LIMIT 1");
    $l = $res ? $res->fetch_assoc() : null;
    if (!$l) learn_error('That lesson is not available on your account', 403);
    if ($l['expiry_date'] && $l['expiry_date'] < date('Y-m-d')) learn_error('Your access to this course has ended', 403);

    learn_ok(['lesson' => [
        'id'       => (int)$l['id'],
        'title'    => $l['title'],
        'type'     => $l['lesson_type'],
        'duration' => (int)$l['duration_secs'],
        'content'  => $l['content'],
        'quiz_id'  => (int)$l['quiz_id'],
        'video'    => learn_video_source($l['video_url'], $l['video_provider']),
        'course'   => ['id' => (int)$l['course_id'], 'title' => $l['course_title'], 'slug' => $l['course_slug']],
    ]]);
}

/* ─────────────────────── the course-analytics screen ──────────────────── */
if ($action === 'analytics') {
    $cid = (int)($_GET['course_id'] ?? 0);
    if (!$cid) learn_error('A course id is required');

    $chk = $conn->query("SELECT c.id, c.title, c.slug FROM lms_courses c
                         JOIN lms_enrollments e ON e.course_id = c.id AND e.user_id = " . (int)$uid . "
                         WHERE c.id = $cid LIMIT 1");
    $c = $chk ? $chk->fetch_assoc() : null;
    if (!$c) learn_error('You are not enrolled in that course', 403);

    $row = fn($sql) => (($r = $conn->query($sql)) ? $r->fetch_assoc() : []) ?: [];

    $lessons = $row("SELECT
        SUM(lesson_type = 'video') videos,
        SUM(lesson_type = 'quiz')  quizzes,
        SUM(lesson_type = 'form')  assignments
        FROM lms_lessons WHERE course_id = $cid AND is_hidden = 0 AND status = 'published'");

    $done = $row("SELECT
        SUM(l.lesson_type = 'video') videos,
        SUM(l.lesson_type = 'quiz')  quizzes,
        SUM(l.lesson_type = 'form')  assignments
        FROM lms_progress p JOIN lms_lessons l ON l.id = p.lesson_id
        WHERE p.user_id = " . (int)$uid . " AND p.course_id = $cid AND p.status = 'completed'");

    $quiz = $row("SELECT COUNT(*) attempts, AVG(a.percentage) avg_pct,
                         SUM(a.score) score, SUM(a.total_marks) total
                  FROM lms_quiz_attempts a
                  JOIN lms_quizzes q ON q.id = a.quiz_id
                  WHERE a.user_id = " . (int)$uid . " AND q.course_id = $cid");

    /* Time on this course, from the portal's own page-view tracking. */
    $time = $row("SELECT COALESCE(SUM(seconds),0) secs FROM lms_learner_page_views
                  WHERE user_id = " . (int)$uid . " AND course_id = $cid");

    $pct = fn($d, $t) => $t > 0 ? (int)round($d * 100 / $t) : null;

    learn_ok([
        'course'  => ['id' => (int)$c['id'], 'title' => $c['title'], 'slug' => $c['slug']],
        'lessons' => [
            'total' => (int)($lessons['videos'] ?? 0), 'done' => (int)($done['videos'] ?? 0),
            'percent' => $pct((int)($done['videos'] ?? 0), (int)($lessons['videos'] ?? 0)),
        ],
        'assignments' => [
            'total' => (int)($lessons['assignments'] ?? 0), 'done' => (int)($done['assignments'] ?? 0),
            'percent' => $pct((int)($done['assignments'] ?? 0), (int)($lessons['assignments'] ?? 0)),
        ],
        'quizzes' => [
            'total' => (int)($lessons['quizzes'] ?? 0), 'done' => (int)($done['quizzes'] ?? 0),
            'percent' => $pct((int)($done['quizzes'] ?? 0), (int)($lessons['quizzes'] ?? 0)),
            'attempts' => (int)($quiz['attempts'] ?? 0),
            'score' => $quiz['score'] === null ? null : (float)$quiz['score'],
            'total_marks' => $quiz['total'] === null ? null : (float)$quiz['total'],
            'accuracy' => $quiz['avg_pct'] === null ? null : round((float)$quiz['avg_pct'], 1),
        ],
        'time_spent_secs' => (int)($time['secs'] ?? 0),
    ]);
}

learn_error('Unknown catalog action: ' . $action, 404);

<?php
/**
 * CORS Headers - included by every endpoint
 */
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");
header("Access-Control-Max-Age: 86400");
header("Content-Type: application/json; charset=UTF-8");

/*
 * Nothing this API answers may be cached, by anything, ever.
 *
 * These responses carry no cache headers at all until now, which leaves every layer between the
 * panel and PHP free to invent its own freshness rule — the browser's heuristic cache, the host's
 * page cache, Cloudflare in front of it. The symptom is always the same and always looks like a
 * broken write: duplicate a campaign, the list comes back without it, press F5 and it is STILL
 * not there, then minutes later it appears on its own. The row was in the database the whole
 * time; a cached copy of the list was being replayed.
 *
 * All three headers, not just Cache-Control: Expires and Pragma are what the older intermediaries
 * actually read.
 */
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Pragma: no-cache");
header("Expires: 0");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit();
}

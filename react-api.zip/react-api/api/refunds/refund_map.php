<?php
/*
 * /api/refunds/refund_map.php  —  Refund Funnel Map
 *
 * Universe: every internship_payment row with refund = 'yes'.
 *
 * Funnel (strictly nested — each stage is a subset of the previous):
 *   registered → attendance_qualified → project_submitted
 *   → project_approved → refund_claim_requested → refund_done
 *
 *   GET action=funnel         per-batch funnel counts (paginated)
 *   GET action=stage_records  drill-down records at a batch + stage (paginated)
 *   GET action=export_funnel  every funnel row (CSV is built on the client)
 *   GET action=export_stage   every record for a batch + stage
 *
 * Attendance (same rule as attendance/attendance.php):
 *   A day is "present" when user_login_activity has a row for that date
 *   with activity_level >= 1, AND — from 2026-05-13 onward — the user also
 *   has an attendance_log row for that date (matched on marked_at). Dates
 *   before 2026-05-13 keep the login-only rule.
 *   Displayed attendance % = present days ÷ FULL duration (e.g. 28/30 = 93.3%),
 *   exactly like the Attendance page — future days simply aren't present yet.
 *   The funnel "attendance_qualified" gate still requires every elapsed day
 *   (start … yesterday) to be present.
 *   Duration months by total_duration days:
 *     ≤35→1, ≤65→2, ≤95→3, ≤125→4, ≤155→5, else 6   (× 30 days each)
 *   attendance_qualified = present on EVERY day of that window.
 *   For the drill-down display, today is also counted when it is marked.
 */
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../middleware/auth.php';

$jwt = require_jwt();
require_permission('manage_refund', $jwt);

global $conn;
if (!$conn) api_error('Database connection failed', 500);
date_default_timezone_set('Asia/Kolkata');

/* ───────────── helpers ───────────── */

function rm_duration_months($days) {
    $days = (int)$days;
    if ($days <= 35)  return 1;
    if ($days <= 65)  return 2;
    if ($days <= 95)  return 3;
    if ($days <= 125) return 4;
    if ($days <= 155) return 5;
    return 6;
}

/*
 * Attendance-window length in days for a stored total_duration.
 *   ≤0   → 30   (missing → default to 1 month)
 *   ≤30  → used as-is        (e.g. 14 → 14 days)
 *   else → rounded to whole months × 30
 *          (35→30, 65→60, 95→90, 125→120, 155→150, 185→180)
 */
function rm_window_days($duration) {
    $d = (int)$duration;
    if ($d <= 0)  return 30;
    if ($d <= 30) return $d;
    return rm_duration_months($d) * 30;
}

function rm_parse_batch_start($batch) {
    if (!$batch) return null;
    $clean = preg_replace('/(\d+)(st|nd|rd|th)/i', '$1', trim($batch));
    try { $d = new DateTime($clean); }
    catch (Exception $e) { return null; }
    $d->setTime(0, 0, 0);
    return $d;
}

/*
 * Core funnel computation.
 * Returns one entry per refund-eligible payment, each carrying its
 * attendance figures and the deepest funnel stage it reached (0–5).
 */
function rm_compute($conn, $batchFilter = null) {
    $sql = "SELECT ip.id AS payment_row_id, ip.user_id,
                   u.name, u.email, u.phone,
                   ip.internship AS internship_name, il.id AS internship_id,
                   ip.batch, ip.total_duration, ip.paid_at,
                   ps.id AS ps_id, ps.status AS ps_status,
                   rc.id AS claim_id, rc.status AS claim_status
            FROM internship_payment ip
            INNER JOIN users u            ON u.user_id        = ip.user_id
            LEFT  JOIN internship_list il ON il.internship_name = ip.internship
            LEFT  JOIN project_submission ps ON ps.user_id = ip.user_id AND ps.internship_id = il.id
            LEFT  JOIN refund_claims rc      ON rc.user_id = ip.user_id AND rc.internship_id = il.id
            WHERE ip.refund = 'yes'";
    if ($batchFilter !== null && $batchFilter !== '') {
        $sql .= " AND ip.batch = '" . $conn->real_escape_string($batchFilter) . "'";
    }
    $res = $conn->query($sql);
    if (!$res) api_error('Query failed: ' . $conn->error, 500);

    $rows = []; $seen = []; $userIds = [];
    while ($r = $res->fetch_assoc()) {
        if (isset($seen[$r['payment_row_id']])) continue;   // guard duplicate joins
        $seen[$r['payment_row_id']] = true;
        $rows[] = $r;
        $userIds[(int)$r['user_id']] = true;
    }
    if (!$rows) return [];

    $today    = new DateTime('today');
    $todayStr = $today->format('Y-m-d');
    $yest     = (clone $today)->modify('-1 day');

    /* parse batch starts, track the earliest for the activity query bound */
    $minStart = null;
    foreach ($rows as &$row) {
        $st = rm_parse_batch_start($row['batch']);
        $row['_start'] = $st;
        $row['batch_start'] = $st ? $st->format('Y-m-d') : null;
        if ($st && ($minStart === null || $st < $minStart)) $minStart = $st;
    }
    unset($row);

    /* present-day map: user_id => [ 'Y-m-d' => true ] */
    $present = [];
    $ids = implode(',', array_map('intval', array_keys($userIds)));
    if ($ids !== '') {
        $bound = $minStart
            ? " AND la.login_date >= '" . $minStart->format('Y-m-d') . " 00:00:00'"
            : '';
        /* present = logged in that day AND (before the cutoff OR has an
           attendance_log entry for that date) — mirrors attendance/attendance.php
           (matched on marked_at, the same column the Attendance page uses) */
        $aq = "SELECT la.user_id, DATE(la.login_date) AS d
               FROM user_login_activity la
               WHERE la.user_id IN ($ids) AND la.activity_level >= 1 $bound
                 AND ( DATE(la.login_date) < '2026-05-13'
                       OR EXISTS ( SELECT 1 FROM attendance_log al
                                   WHERE al.user_id = la.user_id
                                     AND DATE(al.marked_at) = DATE(la.login_date) ) )
               GROUP BY la.user_id, DATE(la.login_date)";
        $ares = $conn->query($aq);
        if ($ares) {
            while ($a = $ares->fetch_assoc()) {
                $present[(int)$a['user_id']][$a['d']] = true;
            }
        }
    }

    /* per-row attendance + funnel stage */
    foreach ($rows as &$row) {
        $start = $row['_start'];
        unset($row['_start']);

        $durDays = rm_window_days($row['total_duration']);
        $row['window_days'] = $durDays;
        $row['batch_end']   = null;

        $attP = 0; $attE = 0; $dispP = 0; $dispE = 0; $markedToday = false;

        if ($start) {
            $pmap = $present[(int)$row['user_id']] ?? [];
            $end  = (clone $start)->modify('+' . ($durDays - 1) . ' days');   // inclusive batch end
            $row['batch_end'] = $end->format('Y-m-d');

            /* funnel window — strictly up to yesterday */
            $fEnd = ($yest < $end) ? $yest : $end;
            if ($fEnd >= $start) {
                $attE = (int)$start->diff($fEnd)->days + 1;
                $cur  = clone $start;
                while ($cur <= $fEnd) {
                    if (!empty($pmap[$cur->format('Y-m-d')])) $attP++;
                    $cur->modify('+1 day');
                }
            }

            /* today counted only for the drill-down display */
            if ($today >= $start && $today <= $end && !empty($pmap[$todayStr])) {
                $markedToday = true;
            }

            /* drill-down display — mirrors the Attendance page: present days
               counted over the WHOLE window (future days simply aren't present
               yet) and the percentage taken against the FULL duration, e.g.
               28 present of a 30-day window → 93.3%. */
            $dispE = $durDays;
            $cur   = clone $start;
            while ($cur <= $end) {
                $ds = $cur->format('Y-m-d');
                if ($ds <= $todayStr && !empty($pmap[$ds])) $dispP++;
                $cur->modify('+1 day');
            }
        }

        $row['att_present']   = $attP;
        $row['att_expected']  = $attE;
        $row['disp_present']  = $dispP;
        $row['disp_expected'] = $dispE;
        $row['disp_pct']      = $dispE > 0 ? round($dispP / $dispE * 100, 1) : 0;
        $row['marked_today']  = $markedToday ? 1 : 0;

        /* strict funnel — stop at the first failed condition */
        $stage = 0;                                   // registered
        if ($attE > 0 && $attP >= $attE) {
            $stage = 1;                               // attendance_qualified
            if (!empty($row['ps_id'])) {
                $stage = 2;                           // project_submitted
                if ($row['ps_status'] === 'approved') {
                    $stage = 3;                       // project_approved
                    if (!empty($row['claim_id'])) {
                        $stage = 4;                   // refund_claim_requested
                        if ($row['claim_status'] === 'refunded') {
                            $stage = 5;               // refund_done
                        }
                    }
                }
            }
        }
        $row['reached_stage'] = $stage;
    }
    unset($row);
    return $rows;
}

/* all unique refund-eligible batches, newest first */
function rm_all_batches($conn) {
    $out = [];
    $q = "SELECT DISTINCT batch FROM internship_payment
          WHERE refund = 'yes' AND batch IS NOT NULL AND batch != ''
          ORDER BY STR_TO_DATE(REGEXP_REPLACE(batch,'(st|nd|rd|th)',''),'%d %M, %Y') DESC";
    $r = $conn->query($q);
    if ($r) while ($b = $r->fetch_assoc()) $out[] = $b['batch'];
    return $out;
}

$STAGE_INDEX = [
    'registered'             => 0,
    'attendance_qualified'   => 1,
    'project_submitted'      => 2,
    'project_approved'       => 3,
    'refund_claim_requested' => 4,
    'refund_done'            => 5,
];

/* ───────────── routing ───────────── */

$action = $_GET['action'] ?? 'funnel';

/* ===== FUNNEL — per-batch counts ===== */
if ($action === 'funnel' || $action === 'export_funnel') {
    $search   = trim($_GET['search']    ?? '');
    $batchF   = trim($_GET['batch']     ?? '');
    $dateFrom = trim($_GET['date_from'] ?? '');
    $dateTo   = trim($_GET['date_to']   ?? '');

    $all = rm_compute($conn, $batchF !== '' ? $batchF : null);

    /* group into per-batch funnel rows */
    $groups = [];
    $endCounts = [];                       // batch => [ end_date => occurrences ]
    foreach ($all as $r) {
        $b = $r['batch'];
        if (!isset($groups[$b])) {
            $groups[$b] = [
                'batch' => $b, 'batch_start' => $r['batch_start'], 'batch_end' => null,
                'registered' => 0, 'attendance_qualified' => 0,
                'project_submitted' => 0, 'project_approved' => 0,
                'refund_claim_requested' => 0, 'refund_done' => 0,
                /* per-stage split by purchased duration bucket (30/60/90/120/150/180).
                   Nested identically to the counts above, so each duration map sums
                   back to its column total. Keyed by duration-days => count. */
                'durations' => [
                    'registered' => [], 'attendance_qualified' => [],
                    'project_submitted' => [], 'project_approved' => [],
                    'refund_claim_requested' => [], 'refund_done' => [],
                ],
            ];
        }
        $s = $r['reached_stage'];
        /* duration bucket in days. >30 rounds to whole months × 30 (35→30, 65→60…);
           ≤30 keeps the raw day count so short purchases (e.g. 15) can show as weeks. */
        $dur = rm_window_days($r['total_duration']);
        $bumpDur = function ($stageKey) use (&$groups, $b, $dur) {
            $groups[$b]['durations'][$stageKey][$dur] =
                ($groups[$b]['durations'][$stageKey][$dur] ?? 0) + 1;
        };
        $groups[$b]['registered']++;                       $bumpDur('registered');
        if ($s >= 1) { $groups[$b]['attendance_qualified']++;   $bumpDur('attendance_qualified'); }
        if ($s >= 2) { $groups[$b]['project_submitted']++;      $bumpDur('project_submitted'); }
        if ($s >= 3) { $groups[$b]['project_approved']++;       $bumpDur('project_approved'); }
        if ($s >= 4) { $groups[$b]['refund_claim_requested']++; $bumpDur('refund_claim_requested'); }
        if ($s >= 5) { $groups[$b]['refund_done']++;            $bumpDur('refund_done'); }
        if ($r['batch_end']) {
            $endCounts[$b][$r['batch_end']] = ($endCounts[$b][$r['batch_end']] ?? 0) + 1;
        }
    }
    /* batch end date = the most common end date among the batch's students */
    foreach ($groups as $b => &$g) {
        if (!empty($endCounts[$b])) {
            arsort($endCounts[$b]);
            $g['batch_end'] = array_key_first($endCounts[$b]);
        }
    }
    unset($g);
    $list = array_values($groups);

    /* filters */
    if ($search !== '') {
        $list = array_values(array_filter($list,
            fn($g) => stripos($g['batch'], $search) !== false));
    }
    if ($dateFrom !== '') {
        $list = array_values(array_filter($list,
            fn($g) => $g['batch_start'] && $g['batch_start'] >= $dateFrom));
    }
    if ($dateTo !== '') {
        $list = array_values(array_filter($list,
            fn($g) => $g['batch_start'] && $g['batch_start'] <= $dateTo));
    }

    /* ordering — an explicit column sort (from a header click) wins;
       otherwise the default funnel-depth ranking applies */
    $sortKey = trim($_GET['sort'] ?? '');
    $sortDir = strtolower($_GET['dir'] ?? 'asc') === 'desc' ? 'desc' : 'asc';
    $sortableCounts = ['registered', 'attendance_qualified', 'project_submitted',
                       'project_approved', 'refund_claim_requested', 'refund_done'];

    if ($sortKey === 'batch') {
        usort($list, function ($a, $b) use ($sortDir) {
            $cmp = strcmp($a['batch_start'] ?? '', $b['batch_start'] ?? '');
            return $sortDir === 'desc' ? -$cmp : $cmp;
        });
    } elseif (in_array($sortKey, $sortableCounts, true)) {
        usort($list, function ($a, $b) use ($sortKey, $sortDir) {
            $cmp = $a[$sortKey] <=> $b[$sortKey];
            if ($cmp === 0) $cmp = strcmp($b['batch_start'] ?? '', $a['batch_start'] ?? '');
            return $sortDir === 'desc' ? -$cmp : $cmp;
        });
    } else {
        /* default: batches that progress deepest down the funnel first —
           a batch with every column non-zero tops the list, then progressively
           shallower funnels, comparing counts from the deepest stage backwards.
           Newest batch start date breaks remaining ties. */
        $stageOrder = ['refund_done', 'refund_claim_requested', 'project_approved',
                       'project_submitted', 'attendance_qualified', 'registered'];
        usort($list, function ($a, $b) use ($stageOrder) {
            foreach ($stageOrder as $k) {
                if ($a[$k] != $b[$k]) return $b[$k] - $a[$k];   // higher count first
            }
            if (!$a['batch_start']) return 1;
            if (!$b['batch_start']) return -1;
            return strcmp($b['batch_start'], $a['batch_start']);
        });
    }

    /* grand totals across the filtered set */
    $totals = ['registered' => 0, 'attendance_qualified' => 0, 'project_submitted' => 0,
               'project_approved' => 0, 'refund_claim_requested' => 0, 'refund_done' => 0];
    foreach ($list as $g) foreach ($totals as $k => $_) $totals[$k] += $g[$k];

    /* duration split of the grand totals (same buckets as the per-batch cells) */
    $totalsDur = ['registered' => [], 'attendance_qualified' => [], 'project_submitted' => [],
                  'project_approved' => [], 'refund_claim_requested' => [], 'refund_done' => []];
    foreach ($list as $g) {
        foreach ($totalsDur as $k => $_) {
            foreach (($g['durations'][$k] ?? []) as $d => $c) {
                $totalsDur[$k][$d] = ($totalsDur[$k][$d] ?? 0) + $c;
            }
        }
    }
    $totals['durations'] = $totalsDur;

    if ($action === 'export_funnel') {
        api_success(['rows' => $list, 'totals' => $totals], 'OK');
    }

    $total = count($list);
    [$page, $per_page, $offset] = get_pagination();
    api_success([
        'rows'        => array_slice($list, $offset, $per_page),
        'total'       => $total,
        'page'        => $page,
        'per_page'    => $per_page,
        'total_pages' => (int)ceil($total / max(1, $per_page)),
        'totals'      => $totals,
        'batches'     => rm_all_batches($conn),
    ], 'OK');
}

/* ===== STAGE RECORDS — drill-down ===== */
if ($action === 'stage_records' || $action === 'export_stage') {
    $batch    = trim($_GET['batch'] ?? '');
    $stageKey = trim($_GET['stage'] ?? '');
    if ($batch === '')                  api_error('batch is required');
    if (!isset($STAGE_INDEX[$stageKey])) api_error('invalid stage');
    $minStage = $STAGE_INDEX[$stageKey];

    $all  = rm_compute($conn, $batch);
    $recs = array_values(array_filter($all, fn($r) => $r['reached_stage'] >= $minStage));

    /* duration filter — clicked a duration chip; window_days bucket matches the
       value the funnel emitted (rm_window_days), so this isolates exactly that group. */
    $durationF = (int)($_GET['duration'] ?? 0);
    if ($durationF > 0) {
        $recs = array_values(array_filter($recs, fn($r) => (int)$r['window_days'] === $durationF));
    }

    /* popup filters */
    $search = trim($_GET['search']     ?? '');
    $intern = trim($_GET['internship'] ?? '');
    if ($search !== '') {
        $q = mb_strtolower($search);
        $recs = array_values(array_filter($recs, function ($r) use ($q) {
            $hay = mb_strtolower(($r['name'] ?? '') . ' ' . ($r['email'] ?? '') . ' '
                 . ($r['phone'] ?? '') . ' ' . $r['user_id']);
            return mb_strpos($hay, $q) !== false;
        }));
    }
    if ($intern !== '') {
        $recs = array_values(array_filter($recs, fn($r) => $r['internship_name'] === $intern));
    }

    $shape = fn($r) => [
        'user_id'       => $r['user_id'],
        'name'          => $r['name'],
        'email'         => $r['email'],
        'phone'         => $r['phone'],
        'internship_name' => $r['internship_name'],
        'batch'         => $r['batch'],
        'batch_start'   => $r['batch_start'],
        'batch_end'     => $r['batch_end'],
        'duration_days' => $r['window_days'],
        'paid_at'       => $r['paid_at'],
        'att_present'   => $r['disp_present'],
        'att_expected'  => $r['disp_expected'],
        'att_pct'       => $r['disp_pct'],
        'marked_today'  => $r['marked_today'],
        'reached_stage' => $r['reached_stage'],
    ];

    /* internship dropdown for the popup (from the whole batch) */
    $interns = array_values(array_unique(array_filter(
        array_map(fn($r) => $r['internship_name'], $all))));
    sort($interns);

    if ($action === 'export_stage') {
        api_success(['rows' => array_map($shape, $recs)], 'OK');
    }

    $total = count($recs);
    [$page, $per_page, $offset] = get_pagination();
    api_success([
        'rows'        => array_map($shape, array_slice($recs, $offset, $per_page)),
        'total'       => $total,
        'page'        => $page,
        'per_page'    => $per_page,
        'total_pages' => (int)ceil($total / max(1, $per_page)),
        'internships' => $interns,
        'stage'       => $stageKey,
        'batch'       => $batch,
    ], 'OK');
}

/* ===== ATTENDANCE CALENDAR — one student's day-by-day attendance ===== */
if ($action === 'attendance_calendar') {
    $user_id = (int)($_GET['user_id'] ?? 0);
    $batch   = trim($_GET['batch'] ?? '');
    if (!$user_id || $batch === '') api_error('user_id and batch are required');

    $esc = $conn->real_escape_string($batch);
    $res = $conn->query("
        SELECT ip.internship, ip.total_duration, ip.paid_at,
               u.name, u.email, u.phone
        FROM internship_payment ip
        INNER JOIN users u ON u.user_id = ip.user_id
        WHERE ip.user_id = $user_id AND ip.batch = '$esc' AND ip.refund = 'yes'
        LIMIT 1");
    if (!$res || !$res->num_rows) api_error('Record not found', 404);
    $rec = $res->fetch_assoc();

    $start = rm_parse_batch_start($batch);
    if (!$start) api_error('Invalid batch date');

    $durDays = rm_window_days($rec['total_duration']);
    $end     = (clone $start)->modify('+' . ($durDays - 1) . ' days');
    $today   = new DateTime('today');

    /* present dates inside the window — logged in that day AND (before the
       cutoff OR has an attendance_log entry on marked_at); see rm_compute */
    $present = [];
    $aq = $conn->query("
        SELECT DISTINCT DATE(la.login_date) AS d
        FROM user_login_activity la
        WHERE la.user_id = $user_id AND la.activity_level >= 1
          AND DATE(la.login_date) BETWEEN '" . $start->format('Y-m-d') . "'
                                      AND '" . $end->format('Y-m-d') . "'
          AND ( DATE(la.login_date) < '2026-05-13'
                OR EXISTS ( SELECT 1 FROM attendance_log al
                            WHERE al.user_id = la.user_id
                              AND DATE(al.marked_at) = DATE(la.login_date) ) )");
    if ($aq) while ($a = $aq->fetch_assoc()) $present[$a['d']] = true;

    /* day-by-day grid — mirrors the Attendance page: only strictly-later dates
       are "future"; today, marked or not, is an elapsed day (present/absent). */
    $todayStr = $today->format('Y-m-d');
    $days = []; $presentCount = 0; $elapsed = 0;
    $cur = clone $start;
    while ($cur <= $end) {
        $ds = $cur->format('Y-m-d');
        if ($ds > $todayStr) {
            $status = 'future';
        } else {
            $elapsed++;
            if (!empty($present[$ds])) { $status = 'present'; $presentCount++; }
            else                       { $status = 'absent'; }
        }
        $days[] = ['date' => $ds, 'status' => $status];
        $cur->modify('+1 day');
    }

    api_success(['calendar' => [
        'user_id'         => $user_id,
        'name'            => $rec['name'],
        'email'           => $rec['email'],
        'phone'           => $rec['phone'],
        'internship_name' => $rec['internship'],
        'batch'           => $batch,
        'batch_start'     => $start->format('Y-m-d'),
        'batch_end'       => $end->format('Y-m-d'),
        'total_days'      => $durDays,
        'elapsed_days'    => $elapsed,
        'present_days'    => $presentCount,
        'absent_days'     => $elapsed - $presentCount,
        /* percentage against the FULL duration, exactly like the Attendance page */
        'attendance_pct'  => $durDays > 0 ? round($presentCount / $durDays * 100, 1) : 0,
        'days'            => $days,
    ]], 'OK');
}

api_error('Invalid action', 400);

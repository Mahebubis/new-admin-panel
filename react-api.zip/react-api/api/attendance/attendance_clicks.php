<?php
/* ════════════════════════════════════════════════════════════
   ATTENDANCE CLICK-LOG API
   Endpoint: /api/attendance/attendance_clicks.php

   Reads & filters the raw attendance click log written by the
   attendance-marking endpoint on dashboard.internshipstudio.com:

     2026-06-17 05:59:12 | click_id=… | phase=result | uid=3387993
       | email=a@b.com | name=… | iid=113734 | result=SUCCESS
       | note_len=53 | client_ts=… | ip=… | api_msg=…
       | note="…" | ua=Mozilla/5.0 …

   Two lines are written per submission — phase=click (precursor,
   email/name still blank) and phase=result (the outcome, fully
   resolved). This API works on the phase=result lines: one row per
   submission outcome.

   Actions (GET):
     ?action=search   filtered + paginated rows (JSON)
     ?action=export   filtered rows streamed as a CSV download

   Filters (shared by both actions):
     q          email | user id | name   (blank = everyone)
     date       YYYY-MM-DD  exact single day
     date_from  } inclusive range (used when `date` is empty)
     date_to    }
     outcome    all | success | failed   (default all)
     phase      result | click | all     (default result)
════════════════════════════════════════════════════════════ */
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../middleware/auth.php';

date_default_timezone_set('Asia/Kolkata');

$jwt = require_jwt();
require_permission('attendance', $jwt);

/* ── where the log lives — first readable wins, else HTTP fallback ── */
$LOG_CANDIDATES = [
    '/home/istudio/public_html/dashboard/api/logs/attendance_clicks.log',
    '/home/istudio/dashboard/api/logs/attendance_clicks.log',
    __DIR__ . '/../logs/attendance_clicks.log',
];
$LOG_URL = 'https://dashboard.internshipstudio.com/api/logs/attendance_clicks.log';

/* open a read handle to the log; $src is set to whatever path/url worked */
function clicks_open(array $candidates, $url, &$src) {
    foreach ($candidates as $p) {
        if (@is_file($p) && @is_readable($p)) {
            $fh = @fopen($p, 'r');
            if ($fh) { $src = $p; return $fh; }
        }
    }
    /* HTTP fallback — pull the whole file into a temp stream (slower; the
       absolute path above should normally hit first) */
    $data = false;
    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 25);
        $data = curl_exec($ch);
        curl_close($ch);
    }
    if ($data === false && ini_get('allow_url_fopen')) {
        $data = @file_get_contents($url);
    }
    if ($data !== false && $data !== null) {
        $fh = fopen('php://temp', 'r+');
        fwrite($fh, $data);
        rewind($fh);
        $src = $url;
        return $fh;
    }
    return null;
}

/* parse one log line into an assoc array, or null if it isn't a log line.
   note="…" may itself contain ' | ', and ua=… runs to end of line, so both
   are peeled off the tail before the remaining key=value pairs are split. */
function clicks_parse($line) {
    $line = rtrim($line, "\r\n");
    if ($line === '') return null;
    if (!preg_match('/^(\d{4}-\d{2}-\d{2}) (\d{2}:\d{2}:\d{2}) \| (.*)$/s', $line, $m)) return null;

    $rec  = ['date' => $m[1], 'time' => $m[2], 'ts' => $m[1] . ' ' . $m[2],
             'ua' => '', 'note' => '', 'click_id' => '', 'phase' => '', 'uid' => '',
             'email' => '', 'name' => '', 'iid' => '', 'result' => '', 'note_len' => '',
             'client_ts' => '', 'ip' => '', 'api_msg' => ''];
    $rest = $m[3];

    if (preg_match('/ \| ua=(.*)$/s', $rest, $mm)) {
        $rec['ua'] = $mm[1];
        $rest = substr($rest, 0, strlen($rest) - strlen($mm[0]));
    }
    if (preg_match('/ \| note="(.*)"\s*$/s', $rest, $mm)) {
        $rec['note'] = $mm[1];
        $rest = substr($rest, 0, strlen($rest) - strlen($mm[0]));
    }
    foreach (explode(' | ', $rest) as $kv) {
        $kv = trim($kv);
        if ($kv === '') continue;
        $eq = strpos($kv, '=');
        if ($eq === false) continue;
        $rec[substr($kv, 0, $eq)] = substr($kv, $eq + 1);
    }
    return $rec;
}

/* does a parsed record pass the active filters? */
function clicks_match($r, $f) {
    /* phase */
    if ($f['phase'] !== 'all' && ($r['phase'] ?? '') !== $f['phase']) return false;

    /* outcome (only meaningful on result rows) */
    if ($f['outcome'] === 'success' && strtoupper($r['result'] ?? '') !== 'SUCCESS') return false;
    if ($f['outcome'] === 'failed'  && strtoupper($r['result'] ?? '') === 'SUCCESS') return false;

    /* date */
    $d = $r['date'] ?? '';
    if ($f['date'] !== '') {
        if ($d !== $f['date']) return false;
    } else {
        if ($f['from'] !== '' && $d < $f['from']) return false;
        if ($f['to']   !== '' && $d > $f['to'])   return false;
    }

    /* q — email / uid / name */
    if ($f['q'] !== '') {
        $q = $f['q'];
        if (strpos($q, '@') !== false) {
            if (stripos($r['email'] ?? '', $q) === false) return false;
        } elseif (ctype_digit($q)) {
            if ((string)($r['uid'] ?? '') !== $q) return false;
        } else {
            if (stripos($r['name'] ?? '', $q) === false) return false;
        }
    }
    return true;
}

/* gather the active filters from the query string */
function clicks_filters() {
    return [
        'q'       => trim($_GET['q'] ?? ''),
        'date'    => trim($_GET['date'] ?? ''),
        'from'    => trim($_GET['date_from'] ?? ''),
        'to'      => trim($_GET['date_to'] ?? ''),
        'outcome' => in_array($_GET['outcome'] ?? 'all', ['all', 'success', 'failed'], true) ? ($_GET['outcome'] ?? 'all') : 'all',
        'phase'   => in_array($_GET['phase'] ?? 'result', ['result', 'click', 'all'], true) ? ($_GET['phase'] ?? 'result') : 'result',
    ];
}

$action = $_GET['action'] ?? 'search';
$filters = clicks_filters();

$src = null;
$fh  = clicks_open($LOG_CANDIDATES, $LOG_URL, $src);
if (!$fh) {
    api_error('Could not read attendance_clicks.log (checked: ' . implode(', ', $LOG_CANDIDATES) . ' and ' . $LOG_URL . ')', 500);
}

/* ───────────── EXPORT — stream CSV ───────────── */
if ($action === 'export') {
    $fname = 'attendance_clicks';
    if ($filters['q'] !== '')    $fname .= '_' . preg_replace('/[^\w.-]+/', '', $filters['q']);
    if ($filters['date'] !== '') $fname .= '_' . $filters['date'];
    elseif ($filters['from'] !== '' || $filters['to'] !== '') $fname .= '_' . ($filters['from'] ?: 'start') . '_to_' . ($filters['to'] ?: 'end');
    $fname .= '_' . date('Ymd_His') . '.csv';

    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $fname . '"');
    $out = fopen('php://output', 'w');
    fputcsv($out, ['Date', 'Time', 'User ID', 'Name', 'Email', 'Internship ID', 'Result',
                   'API Message', 'Note', 'Note Length', 'IP Address', 'Device (UA)', 'Client Timestamp', 'Click ID']);
    while (($line = fgets($fh)) !== false) {
        $r = clicks_parse($line);
        if (!$r || !clicks_match($r, $filters)) continue;
        fputcsv($out, [
            $r['date'], $r['time'], $r['uid'], $r['name'], $r['email'], $r['iid'], $r['result'],
            $r['api_msg'], $r['note'], $r['note_len'], $r['ip'], $r['ua'], $r['client_ts'], $r['click_id'],
        ]);
    }
    fclose($fh);
    exit;
}

/* ───────────── SEARCH — paginated JSON ───────────── */
$page     = max(1, (int)($_GET['page'] ?? 1));
$per_page = min(200, max(1, (int)($_GET['per_page'] ?? 50)));
$CAP      = 5000;   // newest-N matches kept in memory for the on-screen view

$matches = [];
$total   = 0;
$truncated = false;
while (($line = fgets($fh)) !== false) {
    $r = clicks_parse($line);
    if (!$r || !clicks_match($r, $filters)) continue;
    $total++;
    $matches[] = $r;
    if (count($matches) > $CAP) { array_shift($matches); $truncated = true; }
}
fclose($fh);

/* newest first */
$matches = array_reverse($matches);
$shown   = count($matches);
$offset  = ($page - 1) * $per_page;
$slice   = array_slice($matches, $offset, $per_page);

api_success([
    'records'     => $slice,
    'total'       => $total,            // total matches in the file
    'shown_total' => $shown,            // matches available to page through (<= CAP)
    'page'        => $page,
    'per_page'    => $per_page,
    'total_pages' => (int)ceil($shown / max(1, $per_page)),
    'truncated'   => $truncated,        // true => only the newest $CAP matches are paginable
    'cap'         => $CAP,
    'source'      => $src,              // which path/url the log was read from
], 'OK');

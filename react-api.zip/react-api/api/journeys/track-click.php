<?php
/*
 * /api/journeys/track-click.php  —  click redirect for journey emails.
 *
 * first_clicked_at is not just a metric: it is the anchor for last-click conversion
 * attribution in JourneyEngine::journey_recount_conversions(). A student only counts
 * as converted if they clicked a link from THIS journey and then did the goal event
 * inside the window. So this endpoint failing quietly would zero out the conversion
 * numbers, not just the click ones.
 *
 * The redirect happens even if the bookkeeping fails. A student who clicks a link
 * must land on the page.
 */

require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/lib/JourneyWebhookSink.php';

$rid = preg_replace('/[^a-f0-9]/i', '', (string)($_GET['rid'] ?? ''));
$url = (string)($_GET['u'] ?? '');

/* Open-redirect guard: only http(s), and never bounce back into this endpoint. */
$scheme = parse_url($url, PHP_URL_SCHEME);
if ($url === '' || !in_array(strtolower((string)$scheme), ['http', 'https'], true)
    || stripos($url, '/track-click.php') !== false) {
    $url = 'https://internshipstudio.com';
}

try {
    if ($rid !== '' && strlen($rid) === 32) {
        $esc = $conn->real_escape_string($rid);
        $conn->query("UPDATE journey_messages
                         SET first_clicked_at = COALESCE(first_clicked_at, NOW()),
                             click_count = click_count + 1,
                             opened_at = COALESCE(opened_at, NOW()),
                             delivered_at = COALESCE(delivered_at, NOW())
                       WHERE rid = '$esc' LIMIT 1");

        /*
         * HAND THE JOURNEY OVER TO THE BROWSER — the three parameters that become the
         * attribution cookie, exactly as campaigns/track-click.php appends them.
         *
         * This is what makes a journey conversion mean "the message carried them into it"
         * rather than merely "it happened afterwards". The cookie is deleted by the
         * dashboard the instant someone arrives without a campaign_id, so a visitor who
         * clicks, closes the browser, and comes back by typing the address has no cookie
         * left and is no longer credited to this journey.
         *
         * Only when the journey has a goal: with nothing to attribute, writing a sticker
         * would just clear whatever attribution the visitor legitimately arrived with.
         */
        $jr = $conn->query("SELECT m.journey_id, j.goal_enabled, j.goal_window_hours
                              FROM journey_messages m
                              JOIN journeys j ON j.id = m.journey_id
                             WHERE m.rid = '$esc' LIMIT 1");
        $jrow = $jr ? $jr->fetch_assoc() : null;
        if ($jrow && !empty($jrow['goal_enabled']) && (int)$jrow['journey_id'] > 0) {
            $q = journey_attr_query((int)$jrow['journey_id'],
                                    journey_attr_window_days((int)$jrow['goal_window_hours']));
            // Preserve any query string the destination already carries — appending with a
            // bare '?' would corrupt it.
            $url .= (strpos($url, '?') === false ? '?' : '&') . $q;
        }
    }
} catch (Throwable $e) {
    error_log('[journey/track-click] ' . $e->getMessage());
}

header('Location: ' . $url, true, 302);
exit;

<?php
/*
 * /api/journeys/track-open.php  —  the 1x1 open pixel for journey emails.
 *
 * Deliberately separate from campaigns/track-open.php even though the pixel HTML is
 * identical: a rid must resolve against exactly one table, and mixing journey and
 * campaign rids in one endpoint would mean two lookups on every image load from
 * every inbox. inject_tracking() is told which base URL to write, so the two never
 * collide.
 *
 * Always returns the GIF, whatever happens. A broken rid, a dead database, a bot —
 * none of them may produce a broken-image icon in a student's inbox.
 */

require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../campaigns/lib/BotDetector.php';
require_once __DIR__ . '/../campaigns/lib/TrackingRewriter.php';

$gif = base64_decode('R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7');

// Send the pixel first, then do the bookkeeping — the inbox never waits on our DB.
header('Content-Type: image/gif');
header('Content-Length: ' . strlen($gif));
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
echo $gif;
if (function_exists('fastcgi_finish_request')) fastcgi_finish_request();

try {
    $rid = preg_replace('/[^a-f0-9]/i', '', (string)($_GET['rid'] ?? ''));
    if ($rid === '' || strlen($rid) !== 32) exit;

    $esc = $conn->real_escape_string($rid);

    /*
     * Apple Mail Privacy Protection and security scanners open every message the
     * instant it lands. Counting them would give every journey a ~90% open rate and
     * make the report useless, so the same classifier the campaigns use decides.
     * It needs how long ago the message was sent — an "open" one second after send is
     * a machine, not a student.
     */
    $ua = (string)($_SERVER['HTTP_USER_AGENT'] ?? '');
    $sr = $conn->query("SELECT sent_at FROM journey_messages WHERE rid = '$esc' LIMIT 1");
    $srow = $sr ? $sr->fetch_assoc() : null;
    if (!$srow) exit;
    $since = $srow['sent_at'] ? (time() - strtotime($srow['sent_at'])) : null;

    if (function_exists('tracking_machine_reason')
        && tracking_machine_reason($ua, $since, $_SERVER['REQUEST_METHOD'] ?? 'GET') !== null) {
        exit;
    }
    $conn->query("UPDATE journey_messages
                     SET opened_at = COALESCE(opened_at, NOW()),
                         open_count = open_count + 1,
                         delivered_at = COALESCE(delivered_at, NOW())
                   WHERE rid = '$esc' LIMIT 1");
} catch (Throwable $e) {
    error_log('[journey/track-open] ' . $e->getMessage());
}
exit;

<?php
/*
 * /api/journeys/journeys.php
 *
 * Every read and write the Journey UI makes. Action-based single endpoint, same
 * shape as campaigns/campaigns.php and whatsapp/wa_campaigns.php.
 *
 * action=list        &status &q &tag &page &per_page &sort   → rows + per-status tab counts
 * action=get         &id                                     → journey incl. graph, settings, versions
 * action=save   [&id] &name &tags &startAt &endType &endAt &graph &settings  → create/update (autosave)
 * action=graph       &id  &nodes &edges &settings &name      → canvas save (the builder's Save draft)
 * action=status      &id  &status                            → deploy / pause / stop / archive
 * action=duplicate   &id                                     → copy as a new draft
 * action=delete      &id
 * action=versions    &id                                     → version history
 * action=add_version &id  &name &status &nodes &edges &settings
 * action=validate    &id | &graph &settings                  → { blocking[], warnings[] }
 * action=report      &id                                     → KPIs + node stats + funnel
 * action=entries     &id  &page &status &q                   → who is in the journey, and where
 * action=trace       &id  &user_id | &email                  → one student's full step history
 * action=test        &id  &node_id &to                       → fire one node at a test recipient
 * action=options                                             → REAL dropdown data for the builder
 * action=business_event &event_name &payload                  → your backend fires a business event
 * action=run         [&id]                                    → kick the worker now (no cron wait)
 * action=outbox        &kind &journey_id &q &page          -> what the engine still owes
 * action=outbox_release &ids | &all &kind                   -> send those now (kicks the worker)
 * action=outbox_cancel  &ids &note                          -> skip those steps, students continue
 * action=condition_test &id &node_id &user_id|&email        -> evaluate one condition for one student
 * action=health                                               → schema + cron + provider status
 */

require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../middleware/auth.php';
require_once __DIR__ . '/lib/schema.php';
require_once __DIR__ . '/lib/JourneyGraph.php';
require_once __DIR__ . '/lib/JourneyConditions.php';
require_once __DIR__ . '/lib/JourneyDispatch.php';
require_once __DIR__ . '/lib/JourneyEngine.php';
require_once __DIR__ . '/lib/JourneyOutbox.php';
require_once __DIR__ . '/../campaigns/lib/config.php';   // CRON_SECRET, for the Outbox's worker kick

header('Content-Type: application/json');
/*
 * Never cache. These are GET reads of live state, and a browser that serves a cached
 * listing makes a delete or a duplicate look like it did nothing until the page is
 * reloaded by hand.
 */
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');

/*
 * Anything that escapes an action handler comes back as JSON, not as PHP's HTML
 * error page. The frontend parses every response as JSON, so an uncaught fatal
 * used to surface in the panel as an unreadable parse error with the real cause
 * buried in markup. Now the message reaches the toast intact.
 *
 * The shutdown handler covers what set_exception_handler() cannot: parse errors
 * and fatals raised outside a throwable context.
 */
set_exception_handler(function (Throwable $e) {
    http_response_code(500);
    error_log('[journeys] ' . $e->getMessage() . ' @ ' . $e->getFile() . ':' . $e->getLine());
    echo json_encode(['success' => false,
        'error' => $e->getMessage() . ' (' . basename($e->getFile()) . ':' . $e->getLine() . ')']);
});
register_shutdown_function(function () {
    $err = error_get_last();
    if (!$err || !in_array($err['type'], [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR], true)) return;
    if (!headers_sent()) { http_response_code(500); header('Content-Type: application/json'); }
    echo json_encode(['success' => false,
        'error' => $err['message'] . ' (' . basename($err['file']) . ':' . $err['line'] . ')']);
});

journeys_ensure_schema();

$jwt = require_jwt();
require_permission('netcore_behaviour', $jwt);

function jin($k, $d = null) {
    $v = $_REQUEST[$k] ?? null;
    if ($v === null || $v === '') {
        // The builder PUTs JSON bodies; merge those in once, lazily.
        static $body = null;
        if ($body === null) {
            $raw = file_get_contents('php://input');
            $body = $raw ? (json_decode($raw, true) ?: []) : [];
        }
        $v = $body[$k] ?? null;
    }
    return ($v === null || $v === '') ? $d : $v;
}

function ok($data = null)  { echo json_encode(['success' => true,  'data' => $data]); exit; }
function fail(string $msg, int $code = 400, array $extra = []) {
    http_response_code($code);
    echo json_encode(array_merge(['success' => false, 'error' => $msg], $extra));
    exit;
}

$action = (string)jin('action', 'list');
$id     = (int)jin('id', 0);

/* ════════════════════════════════════════════════════════════════════════════
   Row shaping — the frontend's journey object (BACKEND_API.md 1)
   ═══════════════════════════════════════════════════════════════════════════ */

function journey_display_dates(array $r): string {
    if (empty($r['start_at'])) return '-';
    $start = date('M d, Y h:i a', strtotime($r['start_at']));
    $end = ($r['end_type'] === 'date' && $r['end_at'])
        ? date('M d, Y h:i a', strtotime($r['end_at'])) : 'Never ending';
    return "$start - $end";
}

/*
 * ── Live engagement totals ───────────────────────────────────────────────────
 * Read straight from journey_messages rather than from the journeys.*_count
 * columns. Those columns are only refreshed by the worker's rollup, once a
 * minute — so a delivery receipt or a click that arrived by webhook five seconds
 * ago did not show until the next cron tick. That is why tracking looked like it
 * "updates sometime, not instantly": the data was already there, the page was
 * reading a stale cache of it.
 *
 * One GROUP BY over the ids on screen, so the listing costs a single extra query
 * no matter how many journeys it shows.
 *
 * @return array journey_id => ['total' => [...], 'whatsapp' => [...], 'email' => [...]]
 */
function journey_live_counts(array $ids): array {
    global $conn;
    $ids = array_values(array_filter(array_map('intval', $ids)));
    if (!$ids) return [];
    $in = implode(',', $ids);

    $blank = ['sent' => 0, 'delivered' => 0, 'opened' => 0, 'clicked' => 0, 'suppressed' => 0, 'failed' => 0, 'conversions' => 0, 'recipients' => 0];
    $out = [];
    foreach ($ids as $id) $out[$id] = ['total' => $blank, 'whatsapp' => $blank, 'email' => $blank];

    $q = $conn->query("SELECT journey_id, channel,
                              SUM(status = 'sent')              AS sent,
                              SUM(delivered_at IS NOT NULL)     AS delivered,
                              SUM(opened_at IS NOT NULL)        AS opened,
                              SUM(first_clicked_at IS NOT NULL) AS clicked,
                              SUM(status = 'suppressed')        AS suppressed,
                              SUM(status = 'failed')            AS failed
                         FROM journey_messages
                        WHERE journey_id IN ($in)
                          -- Exclude test sends. action=test dispatches with a synthetic
                          -- entry (user_id 0) precisely so it moves no real student; it
                          -- must not inflate the funnel either.
                          AND user_id IS NOT NULL AND user_id > 0
                        GROUP BY journey_id, channel");
    while ($q && $row = $q->fetch_assoc()) {
        $jid = (int)$row['journey_id'];
        $ch  = $row['channel'];
        $vals = [
            'sent' => (int)$row['sent'], 'delivered' => (int)$row['delivered'],
            'opened' => (int)$row['opened'], 'clicked' => (int)$row['clicked'],
            'suppressed' => (int)$row['suppressed'], 'failed' => (int)$row['failed'],
            'conversions' => 0,
        ];
        if (isset($out[$jid][$ch])) $out[$jid][$ch] = $vals;
        foreach ($vals as $k => $v) $out[$jid]['total'][$k] += $v;
    }

    /*
     * How many DISTINCT students were messaged, as opposed to how many messages went
     * out. A journey with three message steps can send five messages to four students,
     * and without this number on screen that reads as a counting bug every single time.
     */
    // user_id 0 is a TEST send — journeys.php?action=test dispatches with a synthetic
    // entry so it never touches the funnel. Counting it made "students messaged" one
    // higher than the number of real students.
    $q = $conn->query("SELECT journey_id, COUNT(DISTINCT user_id) AS recipients
                         FROM journey_messages
                        WHERE journey_id IN ($in) AND status = 'sent'
                          AND user_id IS NOT NULL AND user_id > 0
                        GROUP BY journey_id");
    while ($q && $row = $q->fetch_assoc()) {
        $out[(int)$row['journey_id']]['total']['recipients'] = (int)$row['recipients'];
    }

    /*
     * Conversions split by channel: the conversion is credited to the message the
     * student last clicked, so the channel is that message's channel. A conversion
     * with no click behind it (a control-group member) has no channel and only
     * appears in the total — which is correct, nothing was sent to them.
     */
    $q = $conn->query("SELECT c.journey_id, m.channel, COUNT(*) AS n
                         FROM journey_conversions c
                         LEFT JOIN journey_messages m
                                ON m.entry_id = c.entry_id AND m.node_id = c.node_id
                        WHERE c.journey_id IN ($in)
                        GROUP BY c.journey_id, m.channel");
    while ($q && $row = $q->fetch_assoc()) {
        $jid = (int)$row['journey_id'];
        $n = (int)$row['n'];
        $ch = $row['channel'];
        if ($ch !== null && isset($out[$jid][$ch])) $out[$jid][$ch]['conversions'] += $n;
        $out[$jid]['total']['conversions'] += $n;
    }

    return $out;
}

/** Deep-sort so two graphs that differ only in key order fingerprint identically. */
function journey_sort_deep($v) {
    if (!is_array($v)) return $v;
    $out = [];
    foreach ($v as $k => $x) $out[$k] = journey_sort_deep($x);
    if (array_keys($out) !== range(0, count($out) - 1)) ksort($out);
    return $out;
}

/**
 * The graph reduced to what actually changes EXECUTION.
 *
 * Positions are deliberately excluded: dragging a node or pressing "Tidy up" must not
 * make a live journey report itself as out of date. What counts is the set of steps,
 * their config, and every connector with the delay sitting on it.
 */
function journey_exec_fingerprint($graph): string {
    $g = journey_graph_parse($graph);

    $nodes = [];
    foreach ($g['nodes'] as $id => $n) {
        $nodes[$id] = ['key' => $n['key'], 'cfg' => journey_sort_deep($n['cfg'])];
    }
    ksort($nodes);

    $edges = [];
    foreach ($g['edges'] as $e) {
        // "3" from a text input and 3 from a re-read of the JSON are the same delay.
        $w = is_array($e['wait'] ?? null)
            ? (int)($e['wait']['amount'] ?? 0) . ' ' . (string)($e['wait']['unit'] ?? 'hours')
            : '';
        $edges[] = $e['from'] . '|' . $e['branch'] . '|' . $e['to'] . '|' . $w;
    }
    sort($edges);

    return md5((string)json_encode([$nodes, $edges]));
}

/**
 * Is the canvas the same journey the engine is running?
 *
 * A deployed journey executes the version PINNED at publish time (journeys.current_version_id),
 * never the draft — that is what stops an edit half-finished at 4pm from going live to everyone
 * mid-flight. The cost is that "Save draft" on a running journey changes nothing for students,
 * and until now nothing in the panel said so: the canvas showed a WhatsApp step three minutes
 * after the email while the engine was still running a version that had neither. This is what
 * lets the builder and the report say it out loud.
 */
function journey_live_graph_state(array $r): array {
    global $conn;
    $vid = (int)($r['current_version_id'] ?? 0);
    if (!$vid) return ['liveVersion' => null, 'graphDirty' => false];

    $q   = $conn->query("SELECT version_no, graph FROM journey_versions WHERE id = $vid LIMIT 1");
    $row = $q ? $q->fetch_assoc() : null;
    if (!$row) return ['liveVersion' => null, 'graphDirty' => false];

    return [
        'liveVersion' => (int)$row['version_no'],
        'graphDirty'  => journey_exec_fingerprint($row['graph']) !== journey_exec_fingerprint($r['graph']),
    ];
}

/**
 * A display name for an admin user id.
 *
 * Loaded once for the whole request, not per row: a 200-journey list would otherwise fire 200
 * identical lookups. Falls back to "Admin #id" rather than an empty cell, because an unnamed
 * editor is still a usable thing to filter by — and a blank there reads as "nobody edited it",
 * which is a different and untrue statement.
 */
function journey_editor_name(int $userId): string {
    global $conn;
    static $names = null;
    if ($userId <= 0) return '';
    if ($names === null) {
        $names = [];
        $r = @$conn->query("SELECT u.user_id, TRIM(CONCAT(COALESCE(u.fname,''), ' ', COALESCE(u.lname,''))) nm, u.email
                              FROM admin_users a INNER JOIN users u ON u.user_id = a.user_id");
        while ($r && $row = $r->fetch_assoc()) {
            $names[(int)$row['user_id']] = trim((string)$row['nm']) ?: (string)$row['email'];
        }
    }
    return $names[$userId] ?? ('Admin #' . $userId);
}

function journey_shape(array $r, bool $full = false, ?array $live = null): array {
    $out = [
        'id'       => (int)$r['id'],
        'name'     => $r['name'],
        'tags'     => json_decode((string)($r['tags'] ?? '[]'), true) ?: [],
        'status'   => $r['status'],
        'startAt'  => $r['start_at'] ? str_replace(' ', 'T', substr($r['start_at'], 0, 16)) : '',
        'endType'  => $r['end_type'],
        'endAt'    => $r['end_at'] ? str_replace(' ', 'T', substr($r['end_at'], 0, 16)) : '',
        'dates'    => journey_display_dates($r),
        'edited'   => date('M d, Y h:i a', strtotime($r['updated_at'])),
        'updatedAt'=> strtotime($r['updated_at']) * 1000,
        'createdAt'=> strtotime($r['created_at']) * 1000,
        // Who touched it last, for the Edited by filter. The id is what the filter matches on;
        // the name is only for display and falls back to the id when the user row is gone.
        'editedById' => (int)($r['updated_by'] ?? 0),
        'editedBy'   => journey_editor_name((int)($r['updated_by'] ?? 0)),
        // Milliseconds the journey is scheduled to run for, so "Journey duration" can sort on it.
        'durationMs' => ($r['start_at'] && $r['end_at'])
            ? max(0, (strtotime($r['end_at']) - strtotime($r['start_at'])) * 1000)
            : null,

        'entered'    => (int)$r['entered_count'],
        'active'     => (int)$r['active_count'],
        // Live where we have it, falling back to the rollup columns (an archived
        // journey whose messages were purged still shows its historical totals).
        'sent'       => $live ? $live['total']['sent']        : (int)$r['sent_count'],
        'delivered'  => $live ? $live['total']['delivered']   : (int)$r['delivered_count'],
        'opened'     => $live ? $live['total']['opened']      : (int)$r['opened_count'],
        'clicked'    => $live ? $live['total']['clicked']     : (int)$r['clicked_count'],
        'conversions'=> $live ? $live['total']['conversions'] : (int)$r['conversion_count'],
        'suppressed' => $live ? $live['total']['suppressed']  : (int)$r['suppressed_count'],
        // Distinct students messaged — always ≤ sent, because one student can pass
        // through several message steps in the same journey.
        'recipients' => $live ? $live['total']['recipients']   : 0,
        'revenue'    => (float)$r['revenue'],
        // Per-channel split, so the listing can show "whatsapp | email" under each total.
        'byChannel'  => $live ? ['whatsapp' => $live['whatsapp'], 'email' => $live['email']] : null,
        'convGoal'   => (bool)$r['goal_enabled'],
        'revGoal'    => (float)$r['revenue'] > 0,
        'lastError'  => $r['last_error'],
        'lastWorkerAt' => $r['last_worker_at'] ?? null,
        /*
         * Seconds since the engine last touched this journey, computed HERE rather than
         * from the timestamp in the browser — the panel and the server are rarely in the
         * same timezone, and an hour of skew would either cry wolf or hide a dead cron.
         *
         * null means "never run". Every delay in the product — including "WhatsApp three
         * minutes after the email" — fires only on a tick, so a stalled cron looks exactly
         * like a broken journey unless this is shown.
         */
        'workerAge'  => empty($r['last_worker_at']) ? null : max(0, time() - strtotime($r['last_worker_at'])),
    ];
    if ($full) {
        $out['graph']    = json_decode((string)$r['graph'], true) ?: ['nodes' => [], 'edges' => []];
        $out['settings'] = json_decode((string)($r['settings'] ?? 'null'), true);
        /*
         * The pinned sending route lives in COLUMNS, not in the settings blob — the engine
         * reads the columns and the publish path stamps them. Mirroring them back into the
         * blob is what lets the settings drawer show the real route without a second call,
         * and column-wins means a stale blob from an older save can never contradict what
         * is actually being used to send.
         */
        if (!is_array($out['settings'])) $out['settings'] = [];
        $out['settings']['espTransport'] = (string)($r['esp_transport'] ?? '');
        $out['settings']['waProvider']   = (string)($r['wa_provider'] ?? '');
        $out['versions'] = journey_versions_list((int)$r['id']);
        $out += journey_live_graph_state($r);
    }
    return $out;
}

function journey_versions_list(int $journeyId): array {
    global $conn;
    $q = $conn->query("SELECT * FROM journey_versions WHERE journey_id = " . (int)$journeyId . " ORDER BY version_no DESC");
    $out = [];
    while ($q && $row = $q->fetch_assoc()) {
        $g = json_decode((string)$row['graph'], true) ?: [];
        $out[] = [
            'no'    => (int)$row['version_no'],
            'at'    => date('M d, Y h:i a', strtotime($row['created_at'])),
            'name'  => $row['name'],
            'status'=> $row['status'],
            'nodes' => $g['nodes'] ?? [],
            'edges' => $g['edges'] ?? [],
            'settings' => json_decode((string)($row['settings'] ?? 'null'), true),
        ];
    }
    return $out;
}

function journey_row(int $id): ?array {
    global $conn;
    $r = $conn->query("SELECT * FROM journeys WHERE id = " . (int)$id . " LIMIT 1");
    return $r ? ($r->fetch_assoc() ?: null) : null;
}

/* ════════════════════════════════════════════════════════════════════════════
   Actions
   ═══════════════════════════════════════════════════════════════════════════ */

if ($action === 'list') {
    $status  = (string)jin('status', 'all');
    $q       = trim((string)jin('q', ''));
    $tag     = trim((string)jin('tag', ''));
    $page    = max(1, (int)jin('page', 1));
    $perPage = max(1, min(200, (int)jin('per_page', 50)));
    $sort    = (string)jin('sort', 'recent');

    $where = ['1=1'];
    if ($status !== 'all') $where[] = "status = '" . $conn->real_escape_string($status) . "'";
    if ($q !== '')   $where[] = "name LIKE '%" . $conn->real_escape_string($q) . "%'";
    if ($tag !== '') $where[] = "JSON_SEARCH(tags, 'one', '" . $conn->real_escape_string($tag) . "') IS NOT NULL";
    $w = implode(' AND ', $where);

    $order = $sort === 'name' ? 'name ASC' : ($sort === 'created' ? 'created_at DESC' : 'updated_at DESC');
    $offset = ($page - 1) * $perPage;

    $rows = [];
    $res = $conn->query("SELECT * FROM journeys WHERE $w ORDER BY $order LIMIT $perPage OFFSET $offset");
    $page = [];
    while ($res && $row = $res->fetch_assoc()) $page[] = $row;
    // One counts query for the whole page, not one per row.
    $live = journey_live_counts(array_map(fn($x) => (int)$x['id'], $page));
    foreach ($page as $row) $rows[] = journey_shape($row, false, $live[(int)$row['id']] ?? null);

    $tot = $conn->query("SELECT COUNT(*) c FROM journeys WHERE $w");
    $total = (int)(($tot ? $tot->fetch_assoc() : ['c' => 0])['c']);

    $counts = ['all' => 0];
    $cq = $conn->query("SELECT status, COUNT(*) c FROM journeys GROUP BY status");
    while ($cq && $row = $cq->fetch_assoc()) { $counts[$row['status']] = (int)$row['c']; $counts['all'] += (int)$row['c']; }

    ok(['rows' => $rows, 'total' => $total, 'counts' => $counts]);
}

/*
 * Real per-step counts for the canvas badges.
 *
 * The builder used to render a decaying formula off each node's depth, which looked
 * plausible (44.3k → 33.8k → 18.3k) and meant nothing. These are the actual numbers:
 *
 *   trigger  the size of the audience it draws from — how many contacts are in that
 *            list or segment right now. Activity and business-event triggers return
 *            null, because the population genuinely is not knowable in advance
 *            (Netcore's own UI hides the count on those for the same reason).
 *   others   how many DISTINCT students have reached that step, plus how many are
 *            sitting on it this second.
 *
 * A draft that has never run reports zeroes, which is the honest answer.
 */
function journey_node_counts(int $journeyId, array $graph): array {
    global $conn;
    $out = [];

    $q = $conn->query("SELECT node_id, COUNT(DISTINCT entry_id) AS reached
                         FROM journey_steps WHERE journey_id = " . (int)$journeyId . "
                        GROUP BY node_id");
    while ($q && $row = $q->fetch_assoc()) {
        $out[$row['node_id']] = ['reached' => (int)$row['reached'], 'waiting' => 0, 'audience' => null];
    }

    $q = $conn->query("SELECT node_id, COUNT(*) AS waiting
                         FROM journey_waits WHERE journey_id = " . (int)$journeyId . " AND status = 'pending'
                        GROUP BY node_id");
    while ($q && $row = $q->fetch_assoc()) {
        if (!isset($out[$row['node_id']])) $out[$row['node_id']] = ['reached' => 0, 'waiting' => 0, 'audience' => null];
        $out[$row['node_id']]['waiting'] = (int)$row['waiting'];
    }

    $trigger = journey_trigger_node($graph);
    if ($trigger) {
        $cfg = $trigger['cfg'] ?? [];
        $audience = null;
        try {
            if ($trigger['key'] === 'trg_list') {
                $ids = journey_resolve_list_ids([(string)($cfg['list'] ?? '')]);
                if ($ids) {
                    $in = implode(',', array_map('intval', $ids));
                    $r = $conn->query("SELECT COUNT(DISTINCT c.email) AS n
                                         FROM campaign_list_members m
                                         INNER JOIN campaign_contacts c ON c.id = m.contact_id
                                        WHERE m.list_id IN ($in)");
                    $audience = $r ? (int)($r->fetch_assoc()['n'] ?? 0) : null;
                }
            } elseif ($trigger['key'] === 'trg_segment') {
                $ids = journey_resolve_segment_ids([(string)($cfg['segment'] ?? '')]);
                if ($ids) {
                    $r = $conn->query("SELECT config FROM netcore_segments WHERE id = " . (int)$ids[0] . " LIMIT 1");
                    $row = $r ? $r->fetch_assoc() : null;
                    if ($row) $audience = countSegment(json_decode($row['config'], true));
                }
            }
        } catch (Throwable $e) {
            // A deleted list or an unparseable segment must not stop the canvas loading.
            $audience = null;
        }
        $tid = $trigger['id'];
        if (!isset($out[$tid])) $out[$tid] = ['reached' => 0, 'waiting' => 0, 'audience' => null];
        $out[$tid]['audience'] = $audience;
        // Everyone who entered came through the trigger, whether or not a step was logged for it.
        $r = $conn->query("SELECT COUNT(*) AS n FROM journey_entries WHERE journey_id = " . (int)$journeyId);
        $out[$tid]['reached'] = $r ? (int)($r->fetch_assoc()['n'] ?? 0) : 0;
    }

    return $out;
}

if ($action === 'get') {
    $r = journey_row($id);
    if (!$r) fail('Journey not found.', 404);
    $shaped = journey_shape($r, true);
    $shaped['nodeCounts'] = journey_node_counts($id, journey_graph_parse($r['graph']));
    ok($shaped);
}

if ($action === 'node_counts') {
    $r = journey_row($id);
    if (!$r) fail('Journey not found.', 404);
    ok(journey_node_counts($id, journey_graph_parse($r['graph'])));
}

if ($action === 'save') {
    $name     = trim((string)jin('name', 'Untitled journey'));
    $tags     = jin('tags', []);
    if (is_string($tags)) $tags = json_decode($tags, true) ?: [];
    $tags     = array_slice(array_values(array_filter((array)$tags)), 0, 5);   // Netcore's cap of 5
    $startAt  = (string)jin('startAt', '');
    $endType  = (string)jin('endType', 'never') === 'date' ? 'date' : 'never';
    $endAt    = (string)jin('endAt', '');
    $settings = jin('settings', null);
    if (is_string($settings)) $settings = json_decode($settings, true);
    $graph    = jin('graph', ['nodes' => (object)[], 'edges' => (object)[]]);
    if (is_string($graph)) $graph = json_decode($graph, true);

    $den = journeys_denormalize_settings($settings);

    $startSql = $startAt !== '' ? "'" . $conn->real_escape_string(str_replace('T', ' ', $startAt) . ':00') . "'" : 'NULL';
    $endSql   = ($endType === 'date' && $endAt !== '')
        ? "'" . $conn->real_escape_string(str_replace('T', ' ', $endAt) . ':00') . "'" : 'NULL';

    $sets = [
        "name = '" . $conn->real_escape_string($name) . "'",
        "tags = '" . $conn->real_escape_string(json_encode($tags)) . "'",
        "start_at = $startSql",
        "end_type = '$endType'",
        "end_at = $endSql",
        "graph = '" . $conn->real_escape_string(json_encode($graph)) . "'",
        "settings = " . ($settings === null ? 'NULL' : "'" . $conn->real_escape_string(json_encode($settings)) . "'"),
    ];
    foreach ($den as $col => $val) {
        // The goal freezes on deploy — Netcore's rule, and ours. Silently ignoring the
        // change would be worse than rejecting it, so the deploy path rejects (below)
        // and the autosave path simply does not write these three columns again.
        if (in_array($col, ['goal_enabled', 'goal_event', 'goal_window_hours'], true) && $id) {
            $existing = journey_row($id);
            if ($existing && $existing['goal_locked_at']) continue;
        }
        $sets[] = "`$col` = " . ($val === null ? 'NULL' : "'" . $conn->real_escape_string((string)$val) . "'");
    }

    if ($id) {
        $r = journey_row($id);
        if (!$r) fail('Journey not found.', 404);
        if (in_array($r['status'], ['archived'], true)) fail('An archived journey cannot be edited. Restore it first.');
        // Stamped on every write so the Journeys list can answer "who changed this last".
        $sets[] = "updated_by = " . ((int)($jwt['user_id'] ?? $jwt['id'] ?? 0) ?: 'NULL');
        $conn->query("UPDATE journeys SET " . implode(', ', $sets) . " WHERE id = " . (int)$id);
    } else {
        // The insert has to carry every NOT NULL column that has no default — `name`
        // is one, so a bare stub row is rejected outright under strict mode. The
        // UPDATE that follows still writes the full field set; this only has to be
        // legal enough to get an auto-increment id back.
        $uid = (int)($jwt['user_id'] ?? $jwt['id'] ?? 0);
        $stmt = $conn->prepare("INSERT INTO journeys (name, graph, created_by) VALUES (?, '{\"nodes\":{},\"edges\":{}}', ?)");
        if (!$stmt) fail('Could not create the journey: ' . $conn->error, 500);
        $stmt->bind_param('si', $name, $uid);
        if (!$stmt->execute()) { $err = $stmt->error; $stmt->close(); fail('Could not create the journey: ' . $err, 500); }
        $id = (int)$conn->insert_id;
        $stmt->close();
        // Stamped on every write so the Journeys list can answer "who changed this last".
        $sets[] = "updated_by = " . ((int)($jwt['user_id'] ?? $jwt['id'] ?? 0) ?: 'NULL');
        $conn->query("UPDATE journeys SET " . implode(', ', $sets) . " WHERE id = $id");
    }
    ok(journey_shape(journey_row($id), true));
}

if ($action === 'graph') {
    if (!$id) fail('Missing journey id.');
    $r = journey_row($id);
    if (!$r) fail('Journey not found.', 404);

    $nodes = jin('nodes', []); if (is_string($nodes)) $nodes = json_decode($nodes, true);
    $edges = jin('edges', []); if (is_string($edges)) $edges = json_decode($edges, true);
    $settings = jin('settings', null); if (is_string($settings)) $settings = json_decode($settings, true);
    $name = trim((string)jin('name', $r['name']));

    $graph = ['nodes' => $nodes ?: (object)[], 'edges' => $edges ?: (object)[]];
    $den = journeys_denormalize_settings($settings);

    $sets = [
        "graph = '" . $conn->real_escape_string(json_encode($graph)) . "'",
        "name = '" . $conn->real_escape_string($name) . "'",
        "settings = " . ($settings === null ? 'NULL' : "'" . $conn->real_escape_string(json_encode($settings)) . "'"),
    ];
    foreach ($den as $col => $val) {
        if (in_array($col, ['goal_enabled', 'goal_event', 'goal_window_hours'], true) && $r['goal_locked_at']) continue;
        $sets[] = "`$col` = " . ($val === null ? 'NULL' : "'" . $conn->real_escape_string((string)$val) . "'");
    }
    // Stamped on every write so the Journeys list can answer "who changed this last".
    $sets[] = "updated_by = " . ((int)($jwt['user_id'] ?? $jwt['id'] ?? 0) ?: 'NULL');
    $conn->query("UPDATE journeys SET " . implode(', ', $sets) . " WHERE id = $id");
    /* A journey whose own quiet hours just changed must re-time the people it is already
       holding, for the same reason the account screen does — see journey_dnd_release_holds(). */
    journey_dnd_release_holds((int)$id);
    ok(journey_shape(journey_row($id), true));
}

if ($action === 'validate') {
    $graph = jin('graph', null); if (is_string($graph)) $graph = json_decode($graph, true);
    $settings = jin('settings', null); if (is_string($settings)) $settings = json_decode($settings, true);
    if ($graph === null && $id) {
        $r = journey_row($id);
        if (!$r) fail('Journey not found.', 404);
        $graph = json_decode((string)$r['graph'], true);
        $settings = json_decode((string)$r['settings'], true);
    }
    $v = journey_graph_validate($graph, $settings, ['require_live_channel' => (bool)jin('strict', false)]);
    $v['blocking'] = array_merge($v['blocking'], journey_validate_templates(journey_graph_parse($graph)));
    ok($v);
}

/*
 * Template checks the graph validator cannot do, because they need the database.
 *
 * The one that matters: a WhatsApp template whose URL button ends in a variable
 * CANNOT be delivered through Netcore. Their API ignores the button parameter in every
 * documented shape, and WhatsApp then refuses the whole message with "131008: Button at
 * index 0 of type Url requires a parameter" — the same wall the campaign sender hit and
 * documented in WaSendWorker.php.
 *
 * This is only catchable here, at publish, and catching it here is the difference
 * between a clear refusal and a live journey that quietly fails every WhatsApp send.
 */
function journey_validate_templates(array $graph): array {
    global $conn;
    $problems = [];

    $route = null;   // resolved lazily; the default sender's provider
    foreach ($graph['nodes'] as $n) {
        if ($n['key'] !== 'act_wa') continue;
        $cfg = $n['cfg'] ?? [];
        $tpl = journey_lookup_wa_template((string)($cfg['template'] ?? ''));
        if (!$tpl) continue;

        if (($tpl['approval_status'] ?? '') === 'rejected') {
            $problems[] = "WhatsApp template '{$tpl['name']}' is rejected by Meta and cannot be sent.";
        }

        /*
         * Auto-disabled by category drift. Meta has re-filed this template — almost always
         * UTILITY to MARKETING — which changes its price, whether marketing opt-in is required,
         * and whether it is dropped by the per-user marketing cap. Publishing is the last point
         * at which a person can decide what to do about that, so it is refused here rather than
         * discovered later as a journey whose WhatsApp leg quietly stopped reaching anybody.
         */
        if (!empty($tpl['auto_disabled'])) {
            $problems[] = "WhatsApp template '{$tpl['name']}' has been disabled: "
                . (string)($tpl['disabled_reason'] ?? 'Meta re-classified it.')
                . ' Resolve it under Content → WhatsApp templates before publishing.';
        }

        $override = strtolower(trim((string)($cfg['provider'] ?? '')));
        if ($override === '') {
            if ($route === null) {
                $s = journey_wa_sender((string)($cfg['sender'] ?? ''));
                $route = $s ? strtolower((string)($s['provider'] ?? 'meta')) : 'meta';
            }
            $override = $route;
        }

        /*
         * Only a problem when the step actually asks for a button value. Left blank,
         * no `buttons` block is sent at all and the template delivers fine — which is
         * how the WhatsApp campaigns send this same template today. Blocking on the
         * template alone would refuse graphs that work.
         */
        if (trim((string)($cfg['buttonUrl'] ?? '')) === '' || $override !== 'netcore') continue;

        $buttons = json_decode((string)($tpl['buttons'] ?? '[]'), true) ?: [];
        foreach ($buttons as $b) {
            if (($b['type'] ?? '') !== 'url' || empty($b['dynamic'])) continue;
            $problems[] = "The WhatsApp step using '{$tpl['name']}' has a Button link value set, but Netcore "
                . "does not deliver button parameters — WhatsApp rejects the send with 131008. Clear that "
                . "field to send without a button value, or put the tracked link in the message body instead.";
            break;
        }
    }
    /*
     * ── Update-attribute steps ──────────────────────────────────────────────────
     * A step naming an attribute that no longer exists cannot write anything, and there is
     * no way to see that from the canvas: the node renders "FIR_NAME = active" whether or
     * not FIR_NAME is a real attribute. Publishing is the last moment this can be caught,
     * so it is caught here rather than discovered later as a journey that walks everybody
     * through a step that quietly does nothing.
     */
    foreach ($graph['nodes'] as $n) {
        if ($n['key'] !== 'act_attr') continue;
        $cfg  = $n['cfg'] ?? [];
        $attr = strtoupper(trim((string)($cfg['attr'] ?? '')));
        if ($attr === '') continue;

        $row = journey_attribute_row($attr);
        if ($row) {
            if (($row['category'] ?? '') === 'system'
                && !($row['mapped_db'] && $row['mapped_table'] && $row['mapped_column'] && $row['mapped_join_col'])) {
                $problems[] = "The Update-attribute step writing [$attr] cannot run: that attribute is mapped to a "
                    . 'database column but the mapping is incomplete. Finish it under Audience → Attributes.';
            }
            continue;
        }
        if (journey_users_has_column($attr) || journey_attribute_data_has_column($attr)) continue;
        $problems[] = "The Update-attribute step writing \"$attr\" names an attribute that does not exist "
            . '(Audience → Attributes), so it would write nothing. Pick a real attribute or delete the step.';
    }

    return array_values(array_unique($problems));
}

if ($action === 'status') {
    if (!$id) fail('Missing journey id.');
    $r = journey_row($id);
    if (!$r) fail('Journey not found.', 404);

    $to = (string)jin('status', '');
    $allowed = ['draft','scheduled','ongoing','paused','stopped','completed','archived'];
    if (!in_array($to, $allowed, true)) fail("Unknown status '$to'.");

    // Archiving is only legal from completed / stopped / draft — Netcore's rule.
    if ($to === 'archived' && !in_array($r['status'], ['completed','stopped','draft'], true)) {
        fail('Only a completed, stopped or draft journey can be archived.');
    }

    $goingLive = in_array($to, ['ongoing','scheduled'], true);
    if ($goingLive) {
        $graph    = json_decode((string)$r['graph'], true);
        $settings = json_decode((string)$r['settings'], true);
        $v = journey_graph_validate($graph, $settings, ['require_live_channel' => true]);
        // Template problems can only be seen with the database in hand, so they are
        // merged into the same refusal the canvas already knows how to display.
        $v['blocking'] = array_merge($v['blocking'], journey_validate_templates(journey_graph_parse($graph)));
        if ($v['blocking']) {
            fail('This journey cannot be published yet.', 422, ['problems' => $v['blocking'], 'warnings' => $v['warnings']]);
        }

        /* Deployment must SUPERSEDE, not stack (Netcore A9.2: deploying twice makes users
           qualify under multiple instances and receive duplicates). Snapshot a version and
           point the journey at it; the previous version keeps serving students already
           inside it, and no second instance of the trigger is ever created. */
        $vr = $conn->query("SELECT COALESCE(MAX(version_no),0) n FROM journey_versions WHERE journey_id = $id");
        $next = (int)(($vr ? $vr->fetch_assoc() : ['n' => 0])['n']) + 1;

        $stmt = $conn->prepare("INSERT INTO journey_versions (journey_id, version_no, name, status, graph, settings, created_by)
                                VALUES (?,?,?,?,?,?,?)");
        // settings is a JSON column and is legitimately NULL on a journey whose
        // settings drawer was never opened. Casting that to '' would be an empty
        // string, which MySQL rejects as invalid JSON — so publishing an otherwise
        // valid journey would fail. Keep NULL as NULL.
        $gj = (string)$r['graph'];
        $sj = ($r['settings'] === null || $r['settings'] === '') ? null : (string)$r['settings'];
        $nm = (string)$r['name'];
        $by = (int)($jwt['user_id'] ?? $jwt['id'] ?? 0);
        $stmt->bind_param('iissssi', $id, $next, $nm, $to, $gj, $sj, $by);
        if (!$stmt->execute()) { $err = $stmt->error; $stmt->close(); fail('Could not snapshot the version: ' . $err, 500); }
        $versionId = (int)$conn->insert_id;
        $stmt->close();

        /*
         * A future start date schedules a journey — but only one that is not already
         * running. Re-deploying a live journey whose start date happens to sit in the
         * future would otherwise demote it to 'scheduled', silently stopping an engine
         * that was working, as the price of pushing an edit.
         */
        $startTs = $r['start_at'] ? strtotime($r['start_at']) : time();
        $realStatus = ($startTs > time() && $r['status'] !== 'ongoing') ? 'scheduled' : 'ongoing';

        /*
         * A start date in the PAST is stale, not meaningful — it is whatever the clock said when
         * the journey was first drafted, often days earlier, and it then shows on the report as
         * the moment this journey went live, which it isn't. Publishing is the moment it goes
         * live, so that is what the field records.
         *
         * A FUTURE start date is left exactly alone: that is a deliberate schedule, and it is the
         * value $realStatus above just used to decide between 'scheduled' and 'ongoing'.
         * Overwriting it would turn every scheduled journey into an immediate one.
         */
        $startSql = $startTs > time() ? 'start_at' : 'NOW()';

        /*
         * The sending route, pinned on FIRST publish only.
         *
         * COALESCE, so republishing after an unrelated edit cannot silently move a live journey
         * onto whatever provider happens to be active today. Changing the account's ESP or a
         * number's WhatsApp route from Settings now affects new journeys and campaigns, and
         * leaves running ones exactly where they were.
         */
        $espNow = $conn->real_escape_string((string)TransportFactory::activeProvider());

        /*
         * Pulled in here rather than relied on: JourneyDispatch requires the WhatsApp library
         * INSIDE journey_send_whatsapp(), so at publish time these functions do not exist yet and
         * the stamp would silently never happen. Both files define only functions and constants,
         * so requiring them from this block is safe.
         */
        $waNow = '';
        if (is_file(__DIR__ . '/../whatsapp/lib/schema.php')) {
            require_once __DIR__ . '/../whatsapp/lib/config.php';
            require_once __DIR__ . '/../whatsapp/lib/schema.php';
            if (function_exists('wa_default_sender') && function_exists('wa_resolve_provider')) {
                $waNow = $conn->real_escape_string((string)wa_resolve_provider(wa_default_sender(), null));
            }
        }
        $waSet = $waNow !== '' ? ", wa_provider = COALESCE(wa_provider, '$waNow')" : '';

        $conn->query("UPDATE journeys
                         SET status = '$realStatus',
                             current_version_id = $versionId,
                             goal_locked_at = COALESCE(goal_locked_at, NOW()),
                             deployed_at = COALESCE(deployed_at, NOW()),
                             start_at = $startSql,
                             esp_transport = COALESCE(esp_transport, '$espNow')
                             $waSet,
                             last_error = NULL
                       WHERE id = $id");

        /* First deploy starts every cursor at NOW, so publishing a journey triggered on
           `register` cannot mail every user who ever registered. */
        $conn->query("UPDATE journey_event_cursors SET last_seen_at = NOW()
                       WHERE journey_id = $id AND last_seen_at IS NULL");

        ok(journey_shape(journey_row($id), true));
    }

    $extra = $to === 'completed' ? ", completed_at = NOW()" : '';
    $conn->query("UPDATE journeys SET status = '" . $conn->real_escape_string($to) . "' $extra WHERE id = $id");

    // Stopping cancels pending waits — students stop where they are rather than
    // waking up days later into a journey nobody is running any more.
    if (in_array($to, ['stopped','archived'], true)) {
        $conn->query("UPDATE journey_waits SET status='cancelled' WHERE journey_id = $id AND status='pending'");
        $conn->query("UPDATE journey_entries SET status='exited', exited_at=NOW(), exit_reason='Journey $to'
                       WHERE journey_id = $id AND status IN ('active','waiting')");
    }
    ok(journey_shape(journey_row($id), true));
}

/*
 * Turn the daily message cap off from the report, without a trip through the canvas.
 *
 * The cap is the single most common reason a journey looks broken — it counts across
 * every journey, so a student messaged by an unrelated one in the morning silently
 * loses this journey's messages. Writing the settings blob as well as the column keeps
 * the builder's toggle in step with what the engine is doing.
 */
if ($action === 'set_cap') {
    $r = journey_row($id);
    if (!$r) fail('Journey not found.', 404);
    $on = (int)jin('enabled', 0) === 1 ? 1 : 0;

    $settings = json_decode((string)$r['settings'], true);
    if (is_array($settings)) {
        $settings['cap'] = (bool)$on;
        $conn->query("UPDATE journeys SET settings = '" . $conn->real_escape_string(json_encode($settings)) . "' WHERE id = $id");
    }
    $conn->query("UPDATE journeys SET fc_enabled = $on WHERE id = $id");
    ok(journey_shape(journey_row($id), true));
}

if ($action === 'duplicate') {
    $r = journey_row($id);
    if (!$r) fail('Journey not found.', 404);
    $uid = (int)($jwt['user_id'] ?? $jwt['id'] ?? 0);
    $stmt = $conn->prepare("INSERT INTO journeys
        (name, tags, status, start_at, end_type, end_at, timezone, graph, settings,
         goal_enabled, goal_event, goal_window_hours, exit_criteria, entry_debounce_seconds,
         dnd_enabled, dnd_config, fc_enabled, fc_max_per_day, ignore_fc, ignore_dnd, counts_toward_fc,
         control_mode, control_pct, control_list, created_by)
        SELECT CONCAT(name, ' (copy)'), tags, 'draft', start_at, end_type, end_at, timezone, graph, settings,
               goal_enabled, goal_event, goal_window_hours, exit_criteria, entry_debounce_seconds,
               dnd_enabled, dnd_config, fc_enabled, fc_max_per_day, ignore_fc, ignore_dnd, counts_toward_fc,
               control_mode, control_pct, control_list, ?
          FROM journeys WHERE id = ?");
    $stmt->bind_param('ii', $uid, $id);
    $stmt->execute();
    $newId = (int)$conn->insert_id;
    $stmt->close();
    ok(journey_shape(journey_row($newId), true));
}

if ($action === 'delete') {
    $r = journey_row($id);
    if (!$r) fail('Journey not found.', 404);
    if (in_array($r['status'], ['ongoing','scheduled'], true)) {
        fail('Stop the journey before deleting it — there are students inside.');
    }
    foreach (['journey_waits','journey_steps','journey_messages','journey_entries','journey_versions',
              'journey_event_cursors','journey_conversions','journey_node_stats','journey_split_assignments'] as $t) {
        $conn->query("DELETE FROM `$t` WHERE journey_id = " . (int)$id);
    }
    $conn->query("DELETE FROM journeys WHERE id = " . (int)$id);
    ok(['ok' => true]);
}

if ($action === 'versions') {
    ok(journey_versions_list($id));
}

if ($action === 'add_version') {
    $r = journey_row($id);
    if (!$r) fail('Journey not found.', 404);
    $nodes = jin('nodes', []); if (is_string($nodes)) $nodes = json_decode($nodes, true);
    $edges = jin('edges', []); if (is_string($edges)) $edges = json_decode($edges, true);
    $settings = jin('settings', null); if (is_string($settings)) $settings = json_decode($settings, true);

    $vr = $conn->query("SELECT COALESCE(MAX(version_no),0) n FROM journey_versions WHERE journey_id = $id");
    $next = (int)(($vr ? $vr->fetch_assoc() : ['n' => 0])['n']) + 1;

    $stmt = $conn->prepare("INSERT INTO journey_versions (journey_id, version_no, name, status, graph, settings, created_by)
                            VALUES (?,?,?,?,?,?,?)");
    $nm = (string)jin('name', $r['name']); $st = (string)jin('status', $r['status']);
    $gj = json_encode(['nodes' => $nodes ?: (object)[], 'edges' => $edges ?: (object)[]]);
    $sj = json_encode($settings);
    $by = (int)($jwt['user_id'] ?? $jwt['id'] ?? 0);
    $stmt->bind_param('iissssi', $id, $next, $nm, $st, $gj, $sj, $by);
    $stmt->execute();
    $stmt->close();
    ok(journey_versions_list($id));
}

/* ── Reporting ───────────────────────────────────────────────────────────── */

/**
 * Why the trigger has (or has not) matched anybody — the answer to "I published this and
 * nothing happened".
 *
 * A journey that enrols nobody looks identical to one that is broken, and the single most
 * common cause is not a bug at all: every trigger starts counting from the moment the journey
 * is published, so engagement from BEFORE that is invisible. Two identical journeys published
 * ten minutes apart will disagree about the same email open for that reason alone, which is
 * impossible to work out from a screen of zeroes.
 *
 * So the report states it outright: what the trigger watches, how far back it has read, when it
 * last ran, and how many rows it has ever seen.
 */
/**
 * Other LIVE journeys whose trigger is configured identically to this one.
 *
 * Duplicating a journey to try a variation is the most natural thing in the world, and if the
 * copy is published while the original is still ongoing they both enrol the same student off the
 * same event and both send. The student gets the message twice, seconds apart — and nothing in
 * the panel connects the two, because each journey's own report is entirely correct: one entry,
 * one send. The only place the duplication is visible is the student's phone.
 *
 * So the report names the twins. Compared on the trigger's own config (type, event, status,
 * scope, repeat rule) rather than on the whole graph: two journeys that differ only in which
 * message they send still hit the same people, which is exactly the case worth warning about.
 * `backfillHours` is excluded — it only affects the first tick after publishing, not who is
 * enrolled from then on.
 */
function journey_trigger_twins(array $r): array {
    global $conn;
    $me = (int)$r['id'];

    $fingerprint = static function ($graphJson): ?string {
        $g = json_decode((string)$graphJson, true);
        $parts = [];
        foreach ((array)($g['nodes'] ?? []) as $node) {
            $key = (string)($node['key'] ?? '');
            if (strpos($key, 'trg_') !== 0) continue;
            $cfg = (array)($node['cfg'] ?? []);
            unset($cfg['backfillHours']);
            ksort($cfg);
            $parts[] = $key . '|' . json_encode($cfg);
        }
        if (!$parts) return null;
        sort($parts);
        return sha1(implode('~', $parts));
    };

    $mine = $fingerprint($r['graph']);
    if ($mine === null) return [];

    $out = [];
    // Only live journeys: a draft or a stopped copy sends nothing and is not worth warning about.
    $q = @$conn->query("SELECT id, name, graph FROM journeys
                         WHERE status IN ('ongoing','scheduled') AND id <> $me");
    while ($q && $row = $q->fetch_assoc()) {
        if ($fingerprint($row['graph']) === $mine) {
            $out[] = ['id' => (int)$row['id'], 'name' => $row['name']];
        }
    }
    return $out;
}

function journey_trigger_state(array $r): array {
    global $conn;
    $id = (int)$r['id'];

    $cursors = [];
    $q = $conn->query("SELECT source_key, last_seen_at, last_run_at, rows_seen
                         FROM journey_event_cursors WHERE journey_id = $id ORDER BY source_key");
    while ($q && $row = $q->fetch_assoc()) {
        $cursors[] = [
            'key'       => $row['source_key'],
            'watchedFrom' => $row['last_seen_at'],
            'lastRunAt' => $row['last_run_at'],
            'rowsSeen'  => (int)$row['rows_seen'],
        ];
    }

    $entered = 0;
    $er = $conn->query("SELECT COUNT(*) c FROM journey_entries WHERE journey_id = $id");
    if ($er) $entered = (int)$er->fetch_assoc()['c'];

    return [
        'deployedAt'    => $r['deployed_at'],
        'lastWorkerAt'  => $r['last_worker_at'] ?? null,
        'entered'       => $entered,
        'cursors'       => $cursors,
        // No cursor row at all means the worker has not reached this journey's trigger even
        // once — a different problem (a stopped cron) from a trigger that ran and matched nobody.
        'everPolled'    => count(array_filter($cursors, fn($c) => !empty($c['lastRunAt']))) > 0,
        'twins'         => journey_trigger_twins($r),
    ];
}

if ($action === 'report') {
    $r = journey_row($id);
    if (!$r) fail('Journey not found.', 404);

    /*
     * Recount before rendering, rather than only on the cron tick.
     *
     * The worker's job is to keep the LIST warm in the background; a report somebody
     * deliberately opened should never be a minute stale, and "is the conversion there yet?"
     * is the single most common reason for opening this screen at all. The WhatsApp campaign
     * report already re-reconciles on open for the same reason.
     *
     * Cheap and idempotent: two indexed reads plus INSERT IGNORE against a table that is UNIQUE
     * on (entry_id, event_key), so opening the report twice cannot invent a second conversion.
     * Wrapped because a reporting refresh must never be able to take the report itself down.
     */
    try { journey_recount_conversions($id); } catch (Throwable $e) {
        error_log('journey report recount #' . $id . ': ' . $e->getMessage());
    }
    $r = journey_row($id) ?: $r;

    $nodes = [];
    $q = $conn->query("SELECT node_id, SUM(entered) entered, SUM(sent) sent, SUM(delivered) delivered,
                              SUM(opened) opened, SUM(clicked) clicked, SUM(suppressed) suppressed, SUM(failed) failed
                         FROM journey_node_stats WHERE journey_id = $id GROUP BY node_id");
    while ($q && $row = $q->fetch_assoc()) $nodes[$row['node_id']] = array_map('intval', $row);

    /*
     * Conversions per node, folded onto the same map.
     *
     * They live in journey_conversions rather than journey_node_stats because attribution is
     * last-click: the conversion belongs to whichever message earned the click, which is only
     * known when the goal event lands — long after the node's own counters were written. The
     * Channel-wise view needs them per message step, which is the whole point of that view.
     */
    $q = $conn->query("SELECT node_id, COUNT(*) c FROM journey_conversions
                        WHERE journey_id = $id AND node_id IS NOT NULL AND is_control = 0
                        GROUP BY node_id");
    while ($q && $row = $q->fetch_assoc()) {
        $nid = (string)$row['node_id'];
        if (!isset($nodes[$nid])) $nodes[$nid] = ['node_id' => $nid];
        $nodes[$nid]['conversions'] = (int)$row['c'];
    }

    $waiting = [];
    $q = $conn->query("SELECT w.node_id, COUNT(*) c FROM journey_waits w
                        WHERE w.journey_id = $id AND w.status = 'pending' GROUP BY w.node_id");
    while ($q && $row = $q->fetch_assoc()) $waiting[$row['node_id']] = (int)$row['c'];

    // Control vs treated — the number that justifies the whole system.
    $lift = ['control_entered' => 0, 'control_converted' => 0, 'treated_entered' => 0, 'treated_converted' => 0];
    $q = $conn->query("SELECT is_control, COUNT(*) c FROM journey_entries WHERE journey_id = $id GROUP BY is_control");
    while ($q && $row = $q->fetch_assoc()) {
        $lift[$row['is_control'] ? 'control_entered' : 'treated_entered'] = (int)$row['c'];
    }
    $q = $conn->query("SELECT is_control, COUNT(*) c FROM journey_conversions WHERE journey_id = $id GROUP BY is_control");
    while ($q && $row = $q->fetch_assoc()) {
        $lift[$row['is_control'] ? 'control_converted' : 'treated_converted'] = (int)$row['c'];
    }

    $sup = [];
    $q = $conn->query("SELECT suppress_reason, COUNT(*) c FROM journey_messages
                        WHERE journey_id = $id AND status='suppressed' GROUP BY suppress_reason");
    while ($q && $row = $q->fetch_assoc()) $sup[$row['suppress_reason'] ?: 'unknown'] = (int)$row['c'];

    $statusCounts = [];
    $q = $conn->query("SELECT status, COUNT(*) c FROM journey_entries WHERE journey_id = $id GROUP BY status");
    while ($q && $row = $q->fetch_assoc()) $statusCounts[$row['status']] = (int)$row['c'];

    /*
     * The step-by-step record of what the engine actually did, newest first.
     *
     * This is the difference between "the journey isn't working" and "the WhatsApp
     * step was suppressed because those three students have no phone number". Every
     * branch decision and every withheld message carries its own reason, so the
     * answer is read off the table rather than inferred from counters that are all
     * zero.
     */
    $steps = [];
    $q = $conn->query("SELECT s.*, e.email, e.phone, e.user_id, e.is_control
                         FROM journey_steps s
                         INNER JOIN journey_entries e ON e.id = s.entry_id
                        WHERE s.journey_id = $id
                        ORDER BY s.id DESC LIMIT 120");
    while ($q && $row = $q->fetch_assoc()) {
        $steps[] = [
            'at' => $row['created_at'], 'entryId' => (int)$row['entry_id'],
            'who' => $row['email'] ?: ($row['phone'] ?: ('user #' . $row['user_id'])),
            'isControl' => (bool)$row['is_control'],
            'node' => $row['node_id'], 'nodeKey' => $row['node_key'],
            'branch' => $row['branch'], 'outcome' => $row['outcome'], 'detail' => $row['detail'],
        ];
    }

    $msgs = [];
    $q = $conn->query("SELECT * FROM journey_messages WHERE journey_id = $id ORDER BY id DESC LIMIT 60");
    while ($q && $row = $q->fetch_assoc()) {
        $msgs[] = [
            'at' => $row['queued_at'], 'node' => $row['node_id'], 'channel' => $row['channel'],
            'to' => $row['to_addr'], 'status' => $row['status'],
            'reason' => $row['suppress_reason'], 'error' => $row['error_message'],
            'provider' => $row['provider'], 'subject' => $row['subject'],
        ];
    }

    /*
     * Who actually engaged — name, email and phone, not just a count. A click number
     * tells you the journey worked; this tells you WHO to follow up, which is the
     * thing anyone actually does next.
     */
    $engaged = [];
    $q = $conn->query("SELECT m.channel, m.to_addr, m.node_id, m.subject,
                              m.delivered_at, m.opened_at, m.first_clicked_at, m.click_count,
                              e.user_id, e.email, e.phone, e.first_name, e.last_name
                         FROM journey_messages m
                         INNER JOIN journey_entries e ON e.id = m.entry_id
                        WHERE m.journey_id = $id AND m.opened_at IS NOT NULL
                        ORDER BY COALESCE(m.first_clicked_at, m.opened_at) DESC LIMIT 100");
    while ($q && $row = $q->fetch_assoc()) {
        $engaged[] = [
            'name'    => trim(($row['first_name'] ?? '') . ' ' . ($row['last_name'] ?? '')),
            'userId'  => (int)$row['user_id'],
            'email'   => $row['email'], 'phone' => $row['phone'],
            'channel' => $row['channel'], 'to' => $row['to_addr'], 'node' => $row['node_id'],
            'deliveredAt' => $row['delivered_at'], 'openedAt' => $row['opened_at'],
            'clickedAt'   => $row['first_clicked_at'], 'clicks' => (int)$row['click_count'],
        ];
    }

    /*
     * EVERY WhatsApp tap, one row each — not a count.
     *
     * The Clicked figure counts distinct PEOPLE, which is the number that belongs next to Sent.
     * But that makes "I tapped it four times and it still says 1" impossible to tell apart from
     * "the tracking is broken", and those need telling apart. This is the raw log: one line per
     * tap, with whatever was known about the tapper at that moment.
     *
     * A logged-out tap has no name — the link is identical in every message, so all it leaves is
     * a per-browser visitor key. That is shown honestly as "Not signed in" rather than dropped.
     *
     * Guarded: wa_link_clicks belongs to the WhatsApp feature and may not exist on a server
     * running journeys alone.
     */
    $taps = [];
    $tq = @$conn->query("SELECT c.clicked_at, c.link_id, c.user_id, c.phone, c.email,
                                c.identity_key, c.visitor_key
                           FROM wa_link_clicks c
                          WHERE c.journey_id = $id
                          ORDER BY c.clicked_at DESC LIMIT 100");
    while ($tq && $row = $tq->fetch_assoc()) {
        $taps[] = [
            'at'      => $row['clicked_at'],
            'linkId'  => (int)$row['link_id'],
            'userId'  => (int)$row['user_id'],
            'phone'   => $row['phone'],
            'email'   => $row['email'],
            'who'     => $row['email'] ?: ($row['phone'] ?: 'Not signed in'),
            'identity'=> $row['identity_key'],
        ];
    }
    // Distinct tappers, which is what the Clicked tile counts — shown beside the row count so a
    // "5 taps / 2 people" report reads as intended rather than as a discrepancy.
    $tapPeople = count(array_unique(array_column($taps, 'identity')));

    ok([
        'journey'      => journey_shape($r, true, (journey_live_counts([$id])[$id] ?? null)),
        'engaged'      => $engaged,
        'taps'         => $taps,
        'tapPeople'    => $tapPeople,
        'nodes'        => $nodes,
        'waiting'      => $waiting,
        'triggerState' => journey_trigger_state($r),
        'entryStatus'  => $statusCounts,
        'suppressions' => $sup,
        'lift'         => $lift,
        'steps'        => $steps,
        'messages'     => $msgs,
    ]);
}

if ($action === 'entries') {
    $page = max(1, (int)jin('page', 1));
    $per  = max(1, min(200, (int)jin('per_page', 50)));
    $st   = (string)jin('entry_status', '');
    $q    = trim((string)jin('q', ''));

    $where = ['journey_id = ' . (int)$id];
    if ($st !== '') $where[] = "status = '" . $conn->real_escape_string($st) . "'";
    if ($q !== '')  $where[] = "(email LIKE '%" . $conn->real_escape_string($q) . "%' OR phone LIKE '%" . $conn->real_escape_string($q) . "%')";
    $w = implode(' AND ', $where);

    $rows = [];
    $res = $conn->query("SELECT * FROM journey_entries WHERE $w ORDER BY id DESC LIMIT $per OFFSET " . (($page - 1) * $per));
    while ($res && $row = $res->fetch_assoc()) {
        // When are they scheduled to leave the node they're sitting in? Iterable's
        // per-node user list — the thing that turns a support ticket into 30 seconds.
        $wq = $conn->query("SELECT wake_at FROM journey_waits WHERE entry_id = " . (int)$row['id'] . "
                             AND status='pending' ORDER BY wake_at LIMIT 1");
        $wr = $wq ? $wq->fetch_assoc() : null;
        $rows[] = [
            'id' => (int)$row['id'], 'user_id' => (int)$row['user_id'], 'email' => $row['email'],
            'phone' => $row['phone'], 'status' => $row['status'], 'node' => $row['current_node'],
            'isControl' => (bool)$row['is_control'], 'enteredAt' => $row['entered_at'],
            'exitedAt' => $row['exited_at'], 'exitReason' => $row['exit_reason'],
            'leavesAt' => $wr['wake_at'] ?? null, 'steps' => (int)$row['steps_taken'],
            'error' => $row['last_error'],
        ];
    }
    $tot = $conn->query("SELECT COUNT(*) c FROM journey_entries WHERE $w");
    ok(['rows' => $rows, 'total' => (int)(($tot ? $tot->fetch_assoc() : ['c' => 0])['c'])]);
}

if ($action === 'trace') {
    $userId = (int)jin('user_id', 0);
    $email  = trim((string)jin('email', ''));
    if (!$userId && $email === '') fail('Give a user_id or an email.');

    $cond = $userId ? 'user_id = ' . $userId : "email = '" . $conn->real_escape_string($email) . "'";
    $entries = [];
    $q = $conn->query("SELECT * FROM journey_entries WHERE journey_id = " . (int)$id . " AND $cond ORDER BY id DESC LIMIT 20");
    while ($q && $e = $q->fetch_assoc()) {
        $steps = [];
        $sq = $conn->query("SELECT * FROM journey_steps WHERE entry_id = " . (int)$e['id'] . " ORDER BY id ASC");
        while ($sq && $s = $sq->fetch_assoc()) $steps[] = $s;

        $msgs = [];
        $mq = $conn->query("SELECT * FROM journey_messages WHERE entry_id = " . (int)$e['id'] . " ORDER BY id ASC");
        while ($mq && $m = $mq->fetch_assoc()) $msgs[] = $m;

        $entries[] = ['entry' => $e, 'steps' => $steps, 'messages' => $msgs];
    }
    ok(['entries' => $entries]);
}

/* ── Test send ───────────────────────────────────────────────────────────── */

if ($action === 'test') {
    $r = journey_row($id);
    if (!$r) fail('Journey not found.', 404);
    $nodeId = (string)jin('node_id', '');
    $to     = trim((string)jin('to', ''));
    if ($nodeId === '' || $to === '') fail('Give a node_id and a recipient.');

    $g = journey_graph_parse($r['graph']);
    $node = $g['nodes'][$nodeId] ?? null;
    if (!$node) fail('That step is not on the canvas.');

    // A synthetic entry, never written to journey_entries — a test must not appear in
    // the funnel or move any real student.
    $entry = ['id' => 0, 'user_id' => 0, 'email' => $to, 'phone' => $to,
              'first_name' => 'Test', 'last_name' => 'Student', 'is_control' => 0];
    $ctx = ['journey_id' => (int)$id, 'entry_id' => 0, 'node_id' => $nodeId,
            'user_id' => 0, 'attempt' => (int)(microtime(true) * 1000) % 100000];

    // Governance gates are bypassed for a test — you are asking for this one message.
    $testJourney = array_merge($r, ['fc_enabled' => 0, 'dnd_enabled' => 0]);
    $res = journey_dispatch($testJourney, $entry, $node, $ctx);
    if ($res['outcome'] === 'failed') fail($res['detail']);
    ok(['outcome' => $res['outcome'], 'detail' => $res['detail']]);
}

/* ════════════════════════════════════════════════════════════════════════════
   Test a condition against a real student

   A message step has always had a Test button — send it to yourself and look at what
   arrives. A CONDITION had nothing. The only way to find out which way somebody would
   branch was to publish the journey, wait for them to walk into it, and read the trace
   afterwards; and if the answer was wrong, there was no way to tell a mis-typed value
   from a missing attribute from a rule that never matched anybody.

   This evaluates one condition node against one named student, with no side effects
   whatsoever — nothing is written, nobody enters the journey, no message goes out — and
   answers with the branch they would take AND the evidence behind it: the values the rules
   were compared against, rule by rule, with each one's own verdict.

   The evidence is the point. "False" on its own is the least useful answer this could
   give: the question people actually have is "why", and the answer is almost always that
   the attribute is empty or holds something other than what the rule expected.
   ═══════════════════════════════════════════════════════════════════════════ */

if ($action === 'condition_test') {
    $r = journey_row($id);
    if (!$r) fail('Journey not found.', 404);

    $nodeId = (string)jin('node_id', '');
    if ($nodeId === '') fail('Give a node_id.');

    $g = journey_graph_parse($r['graph']);
    $node = $g['nodes'][$nodeId] ?? null;
    if (!$node) fail('That step is not on the canvas.');

    $testable = ['cnd_attr', 'cnd_event', 'cnd_in_segment', 'cnd_in_list', 'cnd_reach', 'cnd_split'];
    if (!in_array($node['key'], $testable, true)) {
        fail('Only condition steps can be tested this way. Use Send test on a message step.');
    }

    /* ── Who to test with ── */
    $userId = (int)jin('user_id', 0);
    $email  = trim((string)jin('email', ''));
    if (!$userId && $email === '') fail('Give a student — a user id or an email address.');

    if ($userId) {
        $u = $conn->query("SELECT user_id, email, phone, fname, lname FROM users WHERE user_id = $userId LIMIT 1");
    } else {
        $u = $conn->query("SELECT user_id, email, phone, fname, lname FROM users
                            WHERE email = '" . $conn->real_escape_string($email) . "' LIMIT 1");
    }
    $urow = $u ? $u->fetch_assoc() : null;
    if (!$urow) fail($userId ? "No student with user_id $userId." : "No student with the email $email.");

    // The same shape journey_entries carries, so the condition sees exactly what it would
    // see at run time. Never inserted — id 0 marks it as synthetic.
    $entry = [
        'id' => 0, 'user_id' => (int)$urow['user_id'], 'email' => $urow['email'], 'phone' => $urow['phone'],
        'first_name' => $urow['fname'], 'last_name' => $urow['lname'], 'is_control' => 0,
    ];
    $cfg = $node['cfg'] ?? [];
    $uid = (int)$entry['user_id'];

    $branch = null; $why = []; $detail = '';

    switch ($node['key']) {
        case 'cnd_attr': {
            /*
             * Re-implemented rule by rule rather than calling journey_check_attribute(),
             * because that function answers only true/false and the whole value of this
             * screen is the per-rule breakdown underneath the answer. The operator itself
             * still goes through journey_apply_operator(), so a test can never disagree with
             * what the engine would actually do.
             */
            $vals  = journey_attribute_values($uid, $entry);
            $rules = (array)($cfg['rules'] ?? []);
            $any   = strtolower((string)($cfg['match'] ?? 'All rules')) === 'any rule';

            foreach ($rules as $rule) {
                $attr = strtoupper(trim((string)($rule['a'] ?? '')));
                if ($attr === '') continue;
                $op   = (string)($rule['op'] ?? 'Is');
                $want = (string)($rule['v'] ?? '');
                $have = $vals[$attr] ?? null;
                $pass = journey_apply_operator($have, $op, $want);
                $why[] = [
                    'attribute' => $attr,
                    'operator'  => $op,
                    'expected'  => $want,
                    // null and '' are genuinely different answers here — "the attribute does
                    // not exist" versus "it exists and is empty" — and conflating them is how
                    // a rule looks correct and matches nobody.
                    'actual'    => $have === null ? null : (string)$have,
                    'known'     => array_key_exists($attr, $vals),
                    'passed'    => $pass,
                ];
            }
            $passes = array_column($why, 'passed');
            $ok = $rules ? ($any ? in_array(true, $passes, true) : !in_array(false, $passes, true)) : true;
            $branch = $ok ? 'True' : 'False';
            $detail = $any ? 'Any rule has to pass.' : 'Every rule has to pass.';
            break;
        }

        case 'cnd_event': {
            $type = (string)($cfg['type'] ?? 'App / web activity');
            [$from, $to] = journey_event_window($cfg, 'NOW()');
            if ($type !== 'App / web activity') {
                $status = (string)($cfg['status'] ?? '');
                $spec = journey_engagement_spec($type, $status);
                if (!$spec) fail(journey_engagement_unsupported_reason($type, $status));
                $scope = journey_engagement_scope_from_cfg($cfg);
                $problem = journey_engagement_scope_problem($spec, $scope);
                if ($problem !== null) fail($problem);
                $hit = journey_engagement_happened($uid, $spec, $scope, $from, $to);
                if ($hit === null) fail("Cannot evaluate '$type / $status' for this student.");
                $branch = $hit ? 'True' : 'False';
                $detail = "$type / $status inside the configured window.";
            } else {
                $key = (string)($cfg['event'] ?? '');
                $hit = journey_event_happened($uid, $key, $from, $to);
                if ($hit === null) fail("Cannot evaluate the event '$key' — it is not in \$EVENT_SOURCE.");
                $branch = $hit ? 'True' : 'False';
                $detail = "Event '$key' inside the configured window.";
            }
            $why[] = ['attribute' => 'window', 'operator' => 'between', 'expected' => "$from … $to",
                      'actual' => $branch === 'True' ? 'at least one matching event' : 'no matching event',
                      'known' => true, 'passed' => $branch === 'True'];
            break;
        }

        case 'cnd_in_segment': {
            $refs = (array)($cfg['segments'] ?? []);
            $branch = journey_in_segment($uid, $refs) ? 'True' : 'False';
            // Per-segment, not just the combined answer: with five segments on the node, "False"
            // says nothing about which of the five was expected to match.
            foreach (array_slice($refs, 0, 5) as $ref) {
                $one = journey_in_segment($uid, [$ref]);
                $why[] = ['attribute' => 'segment', 'operator' => 'is in', 'expected' => (string)$ref,
                          'actual' => $one ? 'member' : 'not a member', 'known' => true, 'passed' => $one];
            }
            $detail = 'True if the student is in any one of them.';
            break;
        }

        case 'cnd_in_list': {
            $refs = (array)($cfg['lists'] ?? []);
            $branch = journey_in_list($uid, (string)$entry['email'], $refs) ? 'True' : 'False';
            foreach (array_slice($refs, 0, 5) as $ref) {
                $one = journey_in_list($uid, (string)$entry['email'], [$ref]);
                $why[] = ['attribute' => 'list', 'operator' => 'is on', 'expected' => (string)$ref,
                          'actual' => $one ? 'on the list' : 'not on the list', 'known' => true, 'passed' => $one];
            }
            $detail = 'Lists are matched by email address, not by user id.';
            break;
        }

        case 'cnd_reach': {
            $branch = journey_reachable_branch($entry, (array)($cfg['channels'] ?? []));
            $why[] = ['attribute' => 'EMAIL', 'operator' => 'reachable', 'expected' => 'a deliverable address',
                      'actual' => (string)$entry['email'] ?: null, 'known' => trim((string)$entry['email']) !== '',
                      'passed' => trim((string)$entry['email']) !== '' && !journey_is_blocklisted((string)$entry['email'])];
            $why[] = ['attribute' => 'PHONE', 'operator' => 'reachable', 'expected' => 'a dialable, opted-in number',
                      'actual' => (string)$entry['phone'] ?: null, 'known' => trim((string)$entry['phone']) !== '',
                      'passed' => trim((string)$entry['phone']) !== '' && journey_wa_reachable((string)$entry['phone'])];
            $detail = 'The first channel in the priority order that this student is reachable on wins.';
            break;
        }

        case 'cnd_split': {
            /*
             * Reads the stored assignment when there is one and computes the band otherwise —
             * without writing. Testing a split must not be what assigns somebody to a variant,
             * or checking the journey would change its own results.
             */
            $variants = (array)($cfg['variants'] ?? []);
            $stored = $conn->query("SELECT variant FROM journey_split_assignments
                                     WHERE journey_id = " . (int)$id . "
                                       AND node_id = '" . $conn->real_escape_string($nodeId) . "'
                                       AND user_id = $uid LIMIT 1");
            $srow = $stored ? $stored->fetch_assoc() : null;
            if ($srow) {
                $branch = (string)$srow['variant'];
                $detail = 'Already assigned to this variant — a re-entering student keeps it.';
            } else {
                $keys = [];
                foreach ($variants as $v) { $k = (string)($v['key'] ?? ''); if ($k !== '') $keys[$k] = max(0, (int)($v['pct'] ?? 0)); }
                $totalPct = array_sum($keys) ?: 1;
                $bucket = hexdec(substr(md5($id . ':' . $nodeId . ':' . $uid), 0, 8)) % $totalPct;
                $acc = 0; $branch = (string)array_key_first($keys);
                foreach ($keys as $k => $pct) { $acc += $pct; if ($bucket < $acc) { $branch = $k; break; } }
                $detail = 'Not yet assigned. This is the variant they would get — the hash is stable, '
                        . 'so it will be this one when they really walk through.';
            }
            break;
        }
    }

    ok([
        'branch'  => $branch,
        'detail'  => $detail,
        'rules'   => $why,
        'student' => [
            'user_id' => $uid, 'email' => $entry['email'], 'phone' => $entry['phone'],
            'name'    => trim(((string)$entry['first_name']) . ' ' . ((string)$entry['last_name'])),
        ],
        'step'    => ['id' => $nodeId, 'key' => $node['key']],
    ]);
}

/* ── Real dropdown data for the builder ──────────────────────────────────── */

/* ════════════════════════════════════════════════════════════════════════════
   Account-level Do Not Disturb

   The schedule a new journey inherits, and — when enforce_all is on — the schedule EVERY
   journey obeys whatever its own switch says. Both halves are read at send time by
   journey_dnd_effective_config() in lib/JourneyDispatch.php.
   ═══════════════════════════════════════════════════════════════════════════ */

/** Normalises whatever the client sent into the stored shape, dropping anything malformed. */
function journey_dnd_normalize_config($raw): array {
    if (is_string($raw)) $raw = json_decode($raw, true);
    if (!is_array($raw)) return [];

    $out = [];
    foreach ($raw as $row) {
        if (!is_array($row)) continue;
        $day = (int)($row['day'] ?? -1);
        if ($day < 0 || $day > 6) continue;

        // HH:MM only. A malformed time silently becoming 00:00 would turn a narrow window into
        // one that blocks most of the day, so it is rejected rather than coerced.
        $hm = static function ($v): ?string {
            $v = trim((string)$v);
            return preg_match('/^([01]\d|2[0-3]):([0-5]\d)$/', $v) ? $v : null;
        };
        $from = $hm($row['from'] ?? '');
        $to   = $hm($row['to'] ?? '');
        if ($from === null || $to === null) continue;

        $out[$day] = ['day' => $day, 'enabled' => !empty($row['enabled']) ? 1 : 0, 'from' => $from, 'to' => $to];
    }
    ksort($out);
    return array_values($out);
}

if ($action === 'dnd_account_get') {
    $r = $conn->query("SELECT * FROM journey_account_dnd WHERE id = 1 LIMIT 1");
    $row = $r ? $r->fetch_assoc() : null;

    if (!$row) {
        // Never written yet. Answer with the shape the UI expects rather than a null it has to
        // special-case — an unconfigured schedule is "every day, nothing blocked", not "no data".
        $cfg = [];
        for ($d = 0; $d < 7; $d++) $cfg[] = ['day' => $d, 'enabled' => 0, 'from' => '21:00', 'to' => '09:30'];
        ok(['enabled' => 0, 'enforce_all' => 0, 'timezone' => 'Asia/Kolkata',
            'config' => $cfg, 'updated_at' => null, 'exists' => false]);
    }

    ok([
        'enabled'     => (int)$row['enabled'],
        'enforce_all' => (int)$row['enforce_all'],
        'timezone'    => $row['timezone'] ?: 'Asia/Kolkata',
        'config'      => journey_dnd_normalize_config($row['config']),
        'updated_at'  => $row['updated_at'],
        'exists'      => true,
    ]);
}

if ($action === 'dnd_account_save') {
    $enabled   = (int)!!jin('enabled', 0);
    $enforce   = (int)!!jin('enforce_all', 0);
    $tz        = trim((string)jin('timezone', 'Asia/Kolkata'));
    $cfg       = journey_dnd_normalize_config(jin('config', '[]'));

    // A timezone that does not exist would throw at send time, inside the worker, on every
    // message — validated here where a person can still read the error.
    if (!in_array($tz, DateTimeZone::listIdentifiers(), true)) fail("'$tz' is not a timezone this server knows.");

    // Refusing to enforce an empty schedule: switching enforce_all on with nothing configured
    // reads as "quiet hours are on everywhere" while blocking nothing at all.
    $hasWindow = false;
    foreach ($cfg as $row) if (!empty($row['enabled'])) { $hasWindow = true; break; }
    if ($enabled && !$hasWindow) {
        fail('Turn on at least one day before enabling the account schedule — as it stands nothing would ever be held.');
    }
    if ($enforce && !$enabled) fail('The account schedule has to be on before it can be enforced across all journeys.');

    $json = $conn->real_escape_string(json_encode($cfg));
    $tzE  = $conn->real_escape_string($tz);
    $by   = (int)($jwt['id'] ?? $jwt['user_id'] ?? 0) ?: 'NULL';

    $conn->query("INSERT INTO journey_account_dnd (id, enabled, enforce_all, config, timezone, updated_by)
                  VALUES (1, $enabled, $enforce, '$json', '$tzE', $by)
                  ON DUPLICATE KEY UPDATE enabled=$enabled, enforce_all=$enforce,
                                          config='$json', timezone='$tzE', updated_by=$by");

    // How many journeys this actually changes, so the confirmation is about consequences rather
    // than about a row being saved.
    $affected = 0;
    if ($enforce) {
        $r = $conn->query("SELECT COUNT(*) c FROM journeys WHERE status IN ('ongoing','scheduled')");
        $affected = $r ? (int)$r->fetch_assoc()['c'] : 0;
    }

    /*
     * Apply the new schedule to people ALREADY being held, right now.
     *
     * Saving quiet hours used to change only what happened to the next message; anybody
     * already parked stayed parked until the window they were caught by would have ended.
     * Switching the schedule off therefore appeared to do nothing for hours. The sweep
     * releases everyone who is no longer inside a window and re-times the rest, so the
     * confirmation below can report a real, immediate consequence.
     */
    $swept = journey_dnd_release_holds();

    ok(['saved' => true, 'enforced_journeys' => $affected,
        'released' => $swept['released'], 'retimed' => $swept['retimed']]);
}

if ($action === 'options') {
    $events = journey_event_keys();

    $segments = [];
    $q = $conn->query("SELECT id, name FROM netcore_segments ORDER BY name");
    while ($q && $row = $q->fetch_assoc()) $segments[] = ['id' => (int)$row['id'], 'name' => $row['name']];
    /*
     * The lists a person actually made under Audience → Lists — and nothing else.
     *
     * campaign_lists holds the blocklist too (kind='blocklist'), which is a suppression list
     * rather than an audience: it is created automatically, there can be more than one row of
     * it from earlier code paths, and offering it in a List trigger or an Is-in-list condition
     * means offering to start a journey for everyone who has unsubscribed. Filtered out here,
     * at the single place the builder gets its list options from, rather than in each of the
     * three dropdowns that read it.
     */
    $lists = [];
    $q = $conn->query("SELECT id, name FROM campaign_lists WHERE kind = 'list' ORDER BY name");
    while ($q && $row = $q->fetch_assoc()) $lists[] = ['id' => (int)$row['id'], 'name' => $row['name']];

    $emailTemplates = [];
    $q = $conn->query("SELECT id, name FROM campaign_templates WHERE status='active' ORDER BY name");
    while ($q && $row = $q->fetch_assoc()) $emailTemplates[] = ['id' => (int)$row['id'], 'name' => $row['name']];

    $waTemplates = [];
    $q = $conn->query("SELECT id, name, language, approval_status FROM wa_templates WHERE status='active' AND COALESCE(auto_disabled, 0) = 0 ORDER BY name");
    while ($q && $row = $q->fetch_assoc()) {
        $waTemplates[] = ['id' => (int)$row['id'], 'name' => $row['name'],
                          'language' => $row['language'], 'approved' => $row['approval_status'] === 'approved'];
    }

    $senders = [];
    $q = $conn->query("SELECT business_number, display_name FROM wa_senders WHERE is_active=1 ORDER BY is_default DESC");
    while ($q && $row = $q->fetch_assoc()) {
        $senders[] = ['number' => $row['business_number'],
                      'label'  => $row['business_number'] . ($row['display_name'] ? " ({$row['display_name']})" : '')];
    }

    /*
     * ── Attributes, in two lists, because the two nodes that use them want different things ──
     *
     * `customerAttributes` is the real Customer Attributes register (Audience → Attributes):
     * the [FIR_NAME] / [LAST_NAME] style names an admin actually created, each carrying where
     * it is stored. This is what the Update-attribute step offers, because those are the only
     * names it can meaningfully WRITE — a raw users column is a schema detail, not something
     * a journey should be stamping values into by name alone.
     *
     * `attributes` stays the wide flat list — Customer Attributes FIRST, then every users
     * column — because Check-attribute READS, and reading a raw column is legitimate and
     * useful (ACTIVE, CITY, BRANCH …). Customer Attributes lead the list so the names the
     * admin created are the ones at the top of the picker instead of being buried in the
     * alphabetical middle of eighty column names.
     */
    $customerAttrs = [];
    $q = @$conn->query("SELECT name, category, data_type, mapped_db, mapped_table, mapped_column, mapped_join_col
                          FROM campaign_attributes ORDER BY name");
    while ($q && $row = $q->fetch_assoc()) {
        $mapped = $row['category'] === 'system' && $row['mapped_table']
            ? trim((string)$row['mapped_db'], '`') . '.' . $row['mapped_table'] . '.' . $row['mapped_column']
            : 'Customer attribute store';
        $customerAttrs[] = [
            'name'      => strtoupper((string)$row['name']),
            'category'  => (string)$row['category'],
            'dataType'  => (string)$row['data_type'],
            'storedIn'  => $mapped,
            // A mapped attribute with a hole in its mapping can be read but never written, and
            // the Update-attribute step says so on the field rather than failing at run time.
            'writable'  => $row['category'] !== 'system'
                           || ($row['mapped_db'] && $row['mapped_table'] && $row['mapped_column'] && $row['mapped_join_col'])
                           ? 1 : 0,
        ];
    }

    $userCols = [];
    $q = $conn->query("SHOW COLUMNS FROM users");
    while ($q && $row = $q->fetch_assoc()) $userCols[] = strtoupper($row['Field']);
    sort($userCols);

    $attrs = array_column($customerAttrs, 'name');
    foreach ($userCols as $c) if (!in_array($c, $attrs, true)) $attrs[] = $c;

    $domains = [];
    $q = $conn->query("SELECT DISTINCT default_sending_domain d FROM email_esp_settings WHERE default_sending_domain <> ''");
    while ($q && $row = $q->fetch_assoc()) $domains[] = $row['d'];

    /*
     * Journeys, each carrying its own MESSAGE STEPS.
     *
     * An engagement node scoped to a journey ("they opened something from the nurture journey")
     * is nearly always too broad on its own — a journey routinely sends four or five different
     * emails and WhatsApps, and "opened any of them" is not the branch anyone means. So the
     * builder needs to offer the individual sends, which means the step list has to travel with
     * the journey rather than being fetched one journey at a time as the picker changes.
     *
     * The graph is parsed here rather than shipped raw: a graph is large and the builder needs
     * exactly three fields per message step.
     */
    $journeys = [];
    $q = $conn->query("SELECT id, name, graph FROM journeys WHERE status <> 'archived' ORDER BY name");
    while ($q && $row = $q->fetch_assoc()) {
        $steps = [];
        $g = json_decode((string)$row['graph'], true);
        foreach ((array)($g['nodes'] ?? []) as $nid => $node) {
            $key = (string)($node['key'] ?? '');
            if ($key !== 'act_email' && $key !== 'act_wa') continue;
            $cfg = (array)($node['cfg'] ?? []);
            // The template name is what a person recognises; the node id is what the engine
            // matches on. Both are shown so the picker reads as "Welcome email (n4)".
            $label = trim((string)($cfg['template'] ?? '')) ?: ($key === 'act_wa' ? 'WhatsApp step' : 'Email step');
            $steps[] = [
                'id'      => (string)($node['id'] ?? $nid),
                'channel' => $key === 'act_wa' ? 'whatsapp' : 'email',
                'label'   => $label,
            ];
        }
        // Stable order, so the picker does not reshuffle between page loads.
        usort($steps, fn($a, $b) => strnatcasecmp($a['id'], $b['id']));
        $journeys[] = ['id' => (int)$row['id'], 'name' => $row['name'], 'steps' => $steps];
    }

    $bizEvents = [];
    $q = $conn->query("SELECT DISTINCT event_name FROM journey_business_events ORDER BY event_name");
    while ($q && $row = $q->fetch_assoc()) $bizEvents[] = $row['event_name'];

    /*
     * Campaigns an engagement node can be scoped to ("opened THIS email", "read THAT WhatsApp").
     *
     * Only campaigns that actually went out: a draft has no recipients and therefore no opens, so
     * offering one is offering a choice that can only ever match nobody. Newest first and capped,
     * because these accounts run into the thousands and the picker is a dropdown, not an archive.
     */
    $campaigns = [];
    $q = @$conn->query("SELECT id, name, started_at FROM email_campaigns
                         WHERE status IN ('sent','running','suspended')
                         ORDER BY COALESCE(started_at, created_at) DESC LIMIT 300");
    while ($q && $row = $q->fetch_assoc()) {
        $campaigns[] = ['id' => (int)$row['id'], 'name' => $row['name'],
                        'channel' => 'email', 'sent_at' => $row['started_at']];
    }
    $q = @$conn->query("SELECT id, name, started_at FROM wa_campaigns
                         WHERE status IN ('sent','running','suspended')
                         ORDER BY COALESCE(started_at, created_at) DESC LIMIT 300");
    while ($q && $row = $q->fetch_assoc()) {
        $campaigns[] = ['id' => (int)$row['id'], 'name' => $row['name'],
                        'channel' => 'whatsapp', 'sent_at' => $row['started_at']];
    }

    /*
     * The people who appear in the Journeys "Edited by" filter, and the tags in use.
     * Only names that actually appear on a journey — offering every admin would mean a list
     * mostly made of people who have never touched one.
     */
    $editors = [];
    $q = @$conn->query("SELECT DISTINCT updated_by FROM journeys WHERE updated_by IS NOT NULL AND updated_by > 0");
    while ($q && $row = $q->fetch_assoc()) {
        $uid = (int)$row['updated_by'];
        $editors[] = ['id' => $uid, 'name' => journey_editor_name($uid)];
    }
    usort($editors, fn($a, $b) => strcasecmp($a['name'], $b['name']));

    $journeyTags = [];
    $q = @$conn->query("SELECT tags FROM journeys WHERE tags IS NOT NULL AND tags <> '[]'");
    while ($q && $row = $q->fetch_assoc()) {
        foreach ((array)(json_decode((string)$row['tags'], true) ?: []) as $t) {
            $t = trim((string)$t);
            if ($t !== '') $journeyTags[$t] = true;
        }
    }
    $journeyTags = array_keys($journeyTags);
    sort($journeyTags);

    /*
     * Sending routes the journey can be pinned to, plus which one is active right now.
     *
     * Only providers that are actually CONFIGURED are offered: a journey pinned to SES on an
     * account that has never filled in SES credentials would fail every send at dispatch time
     * with nothing in the builder to explain why. The active one is sent separately so the
     * drawer can label the blank choice honestly — "use whatever is active (SendGrid today)".
     */
    $espRoutes = [];
    $q = @$conn->query("SELECT provider, is_active FROM email_esp_settings ORDER BY provider");
    while ($q && $row = $q->fetch_assoc()) {
        $espRoutes[] = ['id' => (string)$row['provider'], 'active' => (int)$row['is_active'] === 1];
    }
    $espActive = '';
    if (is_file(__DIR__ . '/../campaigns/lib/TransportFactory.php')) {
        require_once __DIR__ . '/../campaigns/lib/TransportFactory.php';
        $espActive = (string)TransportFactory::activeProvider();
    }

    $waRoutes = [];
    $waActive = '';
    // JourneyDispatch only pulls the WhatsApp library in when it is actually sending, so
    // the resolver is not in scope here unless we ask for it.
    if (is_file(__DIR__ . '/../whatsapp/lib/schema.php')) {
        require_once __DIR__ . '/../whatsapp/lib/config.php';
        require_once __DIR__ . '/../whatsapp/lib/schema.php';
    }
    $q = @$conn->query("SELECT DISTINCT provider FROM wa_senders WHERE is_active = 1 AND provider <> ''");
    while ($q && $row = $q->fetch_assoc()) $waRoutes[] = ['id' => strtolower((string)$row['provider'])];
    if (function_exists('wa_default_sender') && function_exists('wa_resolve_provider')) {
        $waActive = (string)wa_resolve_provider(wa_default_sender(), null);
    }
    if (!$waRoutes && $waActive !== '') $waRoutes[] = ['id' => $waActive];

    ok([
        'editors' => $editors, 'journeyTags' => $journeyTags,
        'events' => $events, 'segments' => $segments, 'lists' => $lists,
        'emailTemplates' => $emailTemplates, 'waTemplates' => $waTemplates, 'waSenders' => $senders,
        'attributes' => $attrs, 'customerAttributes' => $customerAttrs,
        'sendingDomains' => $domains, 'journeys' => $journeys,
        'businessEvents' => $bizEvents, 'campaigns' => $campaigns,
        'liveChannels' => ['email', 'whatsapp'],
        'espRoutes' => $espRoutes, 'espActive' => $espActive,
        'waRoutes' => $waRoutes, 'waActive' => $waActive,
    ]);
}

/* ── Template preview ────────────────────────────────────────────────────── */

/*
 * What the step will actually look like. Rendered from the SAME template row the
 * dispatcher will read at send time, so the preview cannot drift from the send —
 * which is the only thing that makes a preview worth having.
 *
 * Merge tags are left as-is rather than filled with fake data: showing a made-up
 * name would hide the far more common mistake of a token that never resolves.
 */
if ($action === 'preview') {
    $kind = (string)jin('kind', 'email');
    $ref  = (string)jin('ref', '');
    if ($ref === '') fail('Pick a template first.');

    if ($kind === 'email') {
        $tpl = journey_lookup_email_template($ref);
        if (!$tpl) fail("Email template '$ref' was not found. It may have been archived or renamed.", 404);
        $subject = trim((string)jin('subject', ''));
        ok([
            'kind'    => 'email',
            'name'    => $tpl['name'],
            'subject' => $subject !== '' ? $subject : (string)($tpl['subject_default'] ?? ''),
            'html'    => (string)$tpl['body_html'],
        ]);
    }

    $tpl = journey_lookup_wa_template($ref);
    if (!$tpl) fail("WhatsApp template '$ref' was not found.", 404);
    ok([
        'kind'        => 'whatsapp',
        'name'        => $tpl['name'],
        'language'    => $tpl['language'],
        'category'    => $tpl['category'],
        'approved'    => ($tpl['approval_status'] ?? '') === 'approved',
        'approval'    => $tpl['approval_status'],
        'headerType'  => $tpl['header_type'],
        'headerText'  => $tpl['header_text'],
        'headerMedia' => $tpl['header_media_url'],
        'body'        => (string)$tpl['body_text'],
        'footer'      => (string)($tpl['footer_text'] ?? ''),
        'buttons'     => json_decode((string)($tpl['buttons'] ?? '[]'), true) ?: [],
        'samples'     => json_decode((string)($tpl['sample_values'] ?? '[]'), true) ?: [],
    ]);
}

/* ── Attachments ─────────────────────────────────────────────────────────── */

/*
 * Uploads to S3 and hands the descriptor BACK to the client, which stores it in the
 * node's cfg and saves the graph as usual. Deliberately not written into the graph
 * server-side: the builder autosaves its own copy of the canvas, so a server-side
 * mutation of cfg would be silently overwritten by the next autosave. Returning it
 * keeps a single writer for the graph and removes the race entirely.
 */
if ($action === 'upload_attachment') {
    require_once __DIR__ . '/../lib/S3Uploader.php';

    if (empty($_FILES['file']) || $_FILES['file']['error'] !== UPLOAD_ERR_OK) fail('Choose a file to attach.');
    $file = $_FILES['file'];

    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    if (!in_array($ext, CAMPAIGN_ATTACHMENT_ALLOWED_EXT, true)) {
        fail('That file type is not allowed (.' . $ext . '). Allowed: ' . implode(', ', CAMPAIGN_ATTACHMENT_ALLOWED_EXT));
    }
    if ($file['size'] > CAMPAIGN_ATTACHMENT_MAX_FILE_BYTES) {
        fail('File too large — the limit is ' . (CAMPAIGN_ATTACHMENT_MAX_FILE_BYTES / 1024 / 1024) . 'MB per file.');
    }
    $already = (int)jin('existing_bytes', 0);
    if ($already + $file['size'] > CAMPAIGN_ATTACHMENT_MAX_TOTAL_BYTES) {
        fail('That would take this step over ' . (CAMPAIGN_ATTACHMENT_MAX_TOTAL_BYTES / 1024 / 1024) . 'MB of attachments.');
    }

    $mimeGuess = [
        'pdf' => 'application/pdf', 'doc' => 'application/msword',
        'docx' => 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        'xls' => 'application/vnd.ms-excel', 'xlsx' => 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        'jpg' => 'image/jpeg', 'jpeg' => 'image/jpeg', 'png' => 'image/png', 'gif' => 'image/gif',
        'txt' => 'text/plain', 'csv' => 'text/csv', 'zip' => 'application/zip',
    ];
    $mime = $mimeGuess[$ext] ?? 'application/octet-stream';
    $safeName = preg_replace('/[^a-zA-Z0-9_.\-]/', '_', basename($file['name']));
    $key = 'journey_attachments/' . (int)$id . '/' . bin2hex(random_bytes(8)) . '_' . $safeName;

    $s3Url = s3_upload_file($file['tmp_name'], $key, $mime);
    if (!$s3Url) fail('Could not upload the file to storage.', 500);

    ok(['filename' => $safeName, 's3_key' => $key, 's3_url' => $s3Url,
        'size' => (int)$file['size'], 'mime' => $mime]);
}

if ($action === 'delete_attachment') {
    require_once __DIR__ . '/../lib/S3Uploader.php';
    $key = (string)jin('s3_key', '');
    // Only ever delete inside this feature's own prefix, so a crafted key cannot
    // reach a campaign attachment or anything else in the bucket.
    if ($key === '' || strpos($key, 'journey_attachments/') !== 0) fail('That is not a journey attachment.');
    s3_delete_key($key);
    ok(['ok' => true]);
}

/* ── Engine-facing ───────────────────────────────────────────────────────── */

if ($action === 'business_event') {
    $name = trim((string)jin('event_name', ''));
    if ($name === '') fail('event_name is required.');
    $payload = jin('payload', []);
    if (is_string($payload)) $payload = json_decode($payload, true) ?: [];
    $occurred = (string)jin('occurred_at', date('Y-m-d H:i:s'));

    $stmt = $conn->prepare("INSERT INTO journey_business_events (event_name, payload, occurred_at) VALUES (?,?,?)");
    $pj = json_encode($payload);
    $stmt->bind_param('sss', $name, $pj, $occurred);
    $stmt->execute();
    $newId = (int)$conn->insert_id;
    $stmt->close();
    ok(['id' => $newId]);
}

/* ════════════════════════════════════════════════════════════════════════════
   Outbox — everything the engine still owes

   See lib/JourneyOutbox.php for what each bucket means and why this is a read over
   the existing ledger rather than a queue table of its own.
   ═══════════════════════════════════════════════════════════════════════════ */

if ($action === 'outbox') {
    $kind     = (string)jin('kind', 'all');
    $jid      = (int)jin('journey_id', 0) ?: null;
    $search   = trim((string)jin('q', ''));
    $page     = max(1, (int)jin('page', 1));
    $perPage  = max(1, min(200, (int)jin('per_page', 50)));

    $allowed = ['all', 'overdue', 'dnd_hold', 'retry', 'delay', 'failed'];
    if (!in_array($kind, $allowed, true)) $kind = 'all';

    $res = journey_outbox_rows($kind, $jid, $search, $page, $perPage);

    /*
     * The journey filter's options travel with the listing rather than being a second
     * request: the screen is useless without them and they cost one small query.
     */
    $journeys = [];
    $q = $conn->query("SELECT id, name FROM journeys WHERE status IN ('ongoing','paused','scheduled','completed')
                        ORDER BY name");
    while ($q && $row = $q->fetch_assoc()) $journeys[] = ['id' => (int)$row['id'], 'name' => $row['name']];

    ok([
        'rows'     => $res['rows'],
        'total'    => $res['total'],
        'page'     => $page,
        'per_page' => $perPage,
        'pages'    => $res['total'] > 0 ? (int)ceil($res['total'] / $perPage) : 1,
        'summary'  => journey_outbox_summary($jid),
        'journeys' => $journeys,
        'kind'     => $kind,
    ]);
}

if ($action === 'outbox_release') {
    $ids = jin('ids', '');
    $ids = is_string($ids) ? (json_decode($ids, true) ?: array_filter(explode(',', $ids))) : (array)$ids;

    /*
     * "Send everything now" is a real request and a common one after an outage, so it is a
     * first-class option rather than something you achieve by ticking two thousand boxes.
     * Capped, because releasing a hundred thousand delays at once is a different and much
     * worse action than the one anybody means by it — and the cap is reported back.
     */
    if (empty($ids) && jin('all', '') !== '') {
        $kind = (string)jin('kind', 'overdue');
        $jid  = (int)jin('journey_id', 0) ?: null;
        $page = journey_outbox_rows(in_array($kind, ['all','overdue','dnd_hold','retry','delay','failed'], true) ? $kind : 'overdue',
                                    $jid, '', 1, 2000);
        $ids = array_column($page['rows'], 'id');
    }

    if (!$ids) fail('Nothing selected.');
    $res = journey_outbox_release(array_map('strval', $ids));

    /*
     * Kick the worker straight after, so "Send now" means now rather than "at the top of
     * the next minute". Fire-and-forget: the panel must not sit waiting for a tick that
     * could legitimately take four minutes on a large journey.
     */
    journey_kick_worker_async();
    ok($res + ['selected' => count($ids)]);
}

if ($action === 'outbox_cancel') {
    $ids = jin('ids', '');
    $ids = is_string($ids) ? (json_decode($ids, true) ?: array_filter(explode(',', $ids))) : (array)$ids;
    if (!$ids) fail('Nothing selected.');
    ok(journey_outbox_cancel(array_map('strval', $ids), trim((string)jin('note', ''))));
}

if ($action === 'run') {
    // Manual kick, so you never have to wait a minute for cron while testing.
    $stats = journey_tick($id ?: null);
    ok($stats);
}

if ($action === 'health') {
    $logPath = JOURNEY_WORKER_LOG;
    $lastLines = [];
    if (file_exists($logPath)) {
        $all = @file($logPath, FILE_IGNORE_NEW_LINES) ?: [];
        $lastLines = array_slice($all, -25);
    }
    $lastRun = null;
    $q = $conn->query("SELECT MAX(last_worker_at) m FROM journeys");
    if ($q) $lastRun = ($q->fetch_assoc())['m'];

    $esp = TransportFactory::activeProvider();
    $espT = TransportFactory::forProvider($esp);

    $waOk = false;
    $q = $conn->query("SELECT COUNT(*) c FROM wa_senders WHERE is_active=1");
    if ($q) $waOk = ((int)($q->fetch_assoc())['c']) > 0;

    /*
     * DELIVERY TRACKING — "are the provider callbacks reaching journey messages?"
     *
     * A journey's Delivered / Opened columns are recomputed from journey_messages, and the
     * only thing that can fill delivered_at is a provider callback. Those callbacks arrive at
     * the CAMPAIGN webhooks, which hand an unrecognised rid over to JourneyWebhookSink.php.
     *
     * All three files therefore have to be on the server, and this backend is deployed folder
     * by folder — so whatsapp/ can be live while journeys/lib is a week old. That is invisible
     * from the UI: journeys keep sending perfectly and simply never report a delivery. This
     * block makes it visible without SSH, by checking the files on disk and then showing what
     * the last week of messages actually recorded.
     */
    $sinkPath = __DIR__ . '/lib/JourneyWebhookSink.php';
    $wired = static function (string $path): bool {
        if (!file_exists($path)) return false;
        return strpos((string)@file_get_contents($path), 'JourneyWebhookSink') !== false;
    };

    $recent = [];
    $q = $conn->query("SELECT channel,
                              COUNT(*) sent,
                              SUM(delivered_at IS NOT NULL) delivered,
                              SUM(opened_at    IS NOT NULL) opened,
                              SUM(first_clicked_at IS NOT NULL) clicked
                         FROM journey_messages
                        WHERE status = 'sent' AND sent_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)
                        GROUP BY channel");
    while ($q && $row = $q->fetch_assoc()) {
        $recent[$row['channel']] = [
            'sent' => (int)$row['sent'], 'delivered' => (int)$row['delivered'],
            'opened' => (int)$row['opened'], 'clicked' => (int)$row['clicked'],
        ];
    }

    /*
     * CONVERSIONS — why a journey with clicks can still read 0.
     *
     * Journey conversions are NOT cookie-attributed the way campaigns are. There is no
     * campaign_attr cookie involved and none is expected in the browser: the worker polls the
     * goal event's own source table directly (journey_recount_conversions), and credits an
     * entry only when ALL of these hold:
     *
     *   goal      the journey has a goal event and a window
     *   user_id   the entry resolved to a users row — a list contact that matched no account
     *             carries user_id NULL and can never convert, however many clicks it gets
     *   click     first_clicked_at on one of its messages, which anchors last-click attribution
     *   event     the goal event happened AFTER that click, inside the window
     *
     * Each is counted separately here so a zero can be traced to the one that is missing rather
     * than guessed at. 'eligible' is the number of entries that clear the first three and are
     * waiting only on the student to perform the goal.
     */
    $goals = [];
    $gq = $conn->query("SELECT id, name, goal_event, goal_window_hours
                          FROM journeys
                         WHERE goal_enabled = 1 AND goal_event <> '' AND status <> 'archived'
                         ORDER BY id DESC LIMIT 20");
    while ($gq && $g = $gq->fetch_assoc()) {
        $gid = (int)$g['id'];
        $c = $conn->query("SELECT COUNT(*) entries,
                                  SUM(e.user_id IS NOT NULL) withUser,
                                  SUM(EXISTS(SELECT 1 FROM journey_messages m
                                              WHERE m.entry_id = e.id AND m.first_clicked_at IS NOT NULL)) clicked,
                                  SUM(e.user_id IS NOT NULL
                                      AND EXISTS(SELECT 1 FROM journey_messages m
                                                  WHERE m.entry_id = e.id AND m.first_clicked_at IS NOT NULL)) eligible
                             FROM journey_entries e WHERE e.journey_id = $gid");
        $row = $c ? $c->fetch_assoc() : [];
        $cc = $conn->query("SELECT COUNT(*) c FROM journey_conversions WHERE journey_id = $gid");

        /*
         * Which rule this goal is counted by, and — in strict mode — how many stickers have
         * actually come back. A strict goal with clicks but zero ledger rows means visitors are
         * arriving without the cookie: the click redirect is not appending the parameters, or
         * something cleared the cookie before the goal fired.
         */
        $strictGoal = in_array((string)$g['goal_event'], (array)$LIVE_ATTRIBUTED_EVENTS, true);
        $ledger = 0;
        if ($strictGoal) {
            $lr = @$conn->query("SELECT COUNT(*) c FROM campaign_attributions
                                  WHERE campaign_id = " . journey_attr_campaign_id($gid) . "
                                    AND medium = '" . $conn->real_escape_string(JOURNEY_ATTR_MEDIUM) . "'
                                    AND event_key = '" . $conn->real_escape_string((string)$g['goal_event']) . "'");
            $ledger = (int)(($lr ? $lr->fetch_assoc() : [])['c'] ?? 0);
        }

        $goals[] = [
            'id'          => $gid,
            'name'        => $g['name'],
            'goal'        => $g['goal_event'],
            // A goal whose key is no longer in $EVENT_SOURCE can never be counted, and the
            // journey gives no sign of it — recount_conversions simply returns.
            'goalKnown'   => journey_event_source((string)$g['goal_event']) !== null,
            'windowHours' => (int)$g['goal_window_hours'],
            // 'cookie' = credited only if the visitor still carried this journey's sticker when
            // the goal fired. 'window' = the looser rule, for goals with no live write path.
            'rule'        => $strictGoal ? 'cookie' : 'window',
            'ledgerRows'  => $ledger,
            'entries'     => (int)($row['entries']  ?? 0),
            'withUserId'  => (int)($row['withUser'] ?? 0),
            'clicked'     => (int)($row['clicked']  ?? 0),
            'eligible'    => (int)($row['eligible'] ?? 0),
            'converted'   => (int)(($cc ? $cc->fetch_assoc() : [])['c'] ?? 0),
        ];
    }

    ok([
        'schema'        => journeys_schema_health(),
        'lastWorkerRun' => $lastRun,
        'cronHealthy'   => $lastRun !== null && (time() - strtotime($lastRun)) < 600,
        'emailProvider' => ['name' => $esp, 'configured' => $espT ? $espT->isConfigured() : false],
        'whatsapp'      => ['configured' => $waOk],
        'events'        => count(journey_event_keys()),
        'tracking'      => [
            'sink'             => file_exists($sinkPath),
            'sendgridWebhook'  => $wired(__DIR__ . '/../campaigns/sendgrid-webhook.php'),
            'elasticWebhook'   => $wired(__DIR__ . '/../campaigns/elasticemail-webhook.php'),
            // SES's receipts arrive via SNS at ses-webhook.php, which hands unrecognised rids to
            // the same sink. Note that unlike the other two, the file being present is necessary
            // but not sufficient: SES publishes nothing at all unless a configuration set with an
            // SNS event destination is set in Settings — see the setup notes in that file.
            'sesWebhook'       => $wired(__DIR__ . '/../campaigns/ses-webhook.php'),
            'whatsappWebhook'  => $wired(__DIR__ . '/../whatsapp/webhook.php'),
            'whatsappClick'    => $wired(__DIR__ . '/../whatsapp/click.php'),
            'last7Days'        => $recent,
        ],
        'goals'         => $goals,
        'log'           => $lastLines,
    ]);
}

fail("Unknown action '$action'.", 404);

<?php
/*
 * /api/journeys/journey-worker.php
 *
 * The cron entry point. Everything the journey engine does over time happens
 * because this file runs — waits waking, triggers polling, messages going out.
 *
 * ── Install (once, on the server) ────────────────────────────────────────────
 *   * * * * * /usr/bin/php /path/to/react-api/api/journeys/journey-worker.php >> /dev/null 2>&1
 *
 * Once a minute is right. The engine is idle-cheap (one SELECT per live journey
 * when there is nothing to do) and the tick interval is the floor on how quickly a
 * "wait 5 minutes" step can fire.
 *
 * ── Two ways in ──────────────────────────────────────────────────────────────
 *   CLI   (cron)  no secret needed — being able to run PHP on the box is the auth.
 *   HTTP  (kick)  ?secret=<CRON_SECRET>, used by journeys.php?action=run so the
 *                 panel can make something happen immediately instead of waiting
 *                 for the next minute. Same secret the campaign worker uses.
 *
 * ── Why flock ────────────────────────────────────────────────────────────────
 * A tick can outlive its minute (a slow ESP, a big segment poll). Without the
 * lock, the next cron tick would start a second worker, and two workers walking
 * the same entry is how duplicate sends happen. Overlapping ticks simply no-op.
 * The idempotency key in journey_messages is the second line of defence; this is
 * the first.
 */

require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../campaigns/lib/config.php';   // CRON_SECRET, shared with the campaign worker
require_once __DIR__ . '/lib/schema.php';
require_once __DIR__ . '/lib/JourneyEngine.php';

$isCli = (php_sapi_name() === 'cli');

if (!$isCli) {
    header('Content-Type: application/json');
    $secret = $_REQUEST['secret'] ?? '';
    if (!hash_equals(CRON_SECRET, (string)$secret)) {
        http_response_code(403);
        echo json_encode(['success' => false, 'error' => 'Forbidden']);
        exit;
    }
}

@set_time_limit(0);
ini_set('memory_limit', '512M');

$journeyId = isset($_REQUEST['journey_id']) ? (int)$_REQUEST['journey_id'] : null;

/* ── the lock ── */
$lockPath = __DIR__ . '/worker.lock';
$lock = @fopen($lockPath, 'c');
if (!$lock) {
    journey_log('FATAL: cannot open ' . $lockPath . ' — check directory permissions.');
    if (!$isCli) { http_response_code(500); echo json_encode(['success' => false, 'error' => 'Cannot acquire lock file']); }
    exit(1);
}
if (!flock($lock, LOCK_EX | LOCK_NB)) {
    // Not an error. The previous tick is still working.
    if (!$isCli) echo json_encode(['success' => true, 'data' => ['skipped' => 'already running']]);
    exit(0);
}

$started = microtime(true);
$stats = ['journeys' => 0, 'entered' => 0, 'woken' => 0, 'stepped' => 0, 'errors' => 0];

try {
    journeys_ensure_schema();

    /*
     * Keep pulling ticks until the budget is spent, rather than doing one pass and
     * exiting. A journey that has just been published against a large segment has
     * thousands of entries to walk; one pass per minute would take hours. The lock
     * makes a long run safe — the next few cron ticks just no-op.
     */
    $deadline = time() + (defined('WORKER_MAX_RUNTIME_SECONDS') ? WORKER_MAX_RUNTIME_SECONDS : 240);
    $passes = 0;
    do {
        $s = journey_tick($journeyId);
        foreach ($stats as $k => $_) $stats[$k] += ($s[$k] ?? 0);
        $passes++;
        // Nothing moved — no point spinning for the rest of the budget.
        if (($s['entered'] + $s['woken'] + $s['stepped']) === 0) break;
    } while (time() < $deadline && $passes < 50);

    $elapsed = round(microtime(true) - $started, 1);
    journey_log("worker finished: {$passes} pass(es) in {$elapsed}s — "
        . "{$stats['entered']} entered, {$stats['woken']} woken, {$stats['stepped']} stepped, {$stats['errors']} error(s)");

    if (!$isCli) echo json_encode(['success' => true, 'data' => $stats + ['passes' => $passes, 'seconds' => $elapsed]]);

} catch (Throwable $e) {
    // A throw here means the engine itself broke, not one journey. Log loudly and
    // exit non-zero so a cron mail / monitor can see it.
    journey_log('WORKER FATAL: ' . $e->getMessage() . ' @ ' . $e->getFile() . ':' . $e->getLine());
    if (!$isCli) { http_response_code(500); echo json_encode(['success' => false, 'error' => $e->getMessage()]); }
    flock($lock, LOCK_UN); fclose($lock);
    exit(1);
}

flock($lock, LOCK_UN);
fclose($lock);
exit(0);

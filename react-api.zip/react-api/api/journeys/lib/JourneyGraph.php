<?php
/*
 * /api/journeys/lib/JourneyGraph.php
 *
 * The graph model, shared by the API and the worker.
 *
 * JOURNEY_NODE_TYPES below is the server's copy of the `T` registry in
 * JourneyBuilder.jsx. It is deliberately a copy and not a generated artefact —
 * the client's version carries icons, field widgets and summary renderers that
 * mean nothing here, and this one carries execution semantics the canvas doesn't
 * need. What the two MUST agree on is: the group, the output branch names, and
 * which config fields are required. If you add a node type, add it in both, and
 * add an executor arm in JourneyEngine::executeNode().
 *
 * journey_graph_validate() is the server-side mirror of the client's problems().
 * The client validator is a convenience; this one is the gate — POST status
 * transitions to scheduled/ongoing run it and refuse to deploy a graph that
 * fails, because "users pile up at an unconnected branch" is the single most
 * common journey defect in Netcore's own troubleshooting docs and it is 100%
 * preventable at publish time.
 */

const JOURNEY_TRIGGER_KEYS = ['trg_activity', 'trg_segment', 'trg_list', 'trg_business'];

/** Channels the engine can actually deliver on today. Anything else is palette-only. */
const JOURNEY_LIVE_CHANNELS = ['act_email', 'act_wa'];

function journey_node_types(): array {
    static $T = null;
    if ($T !== null) return $T;

    $T = [
        /* ── triggers ── */
        'trg_activity' => ['g' => 'trigger', 'name' => 'Activity',       'out' => ['Yes'],
                           'req' => ['type', 'repeat']],
        'trg_segment'  => ['g' => 'trigger', 'name' => 'Segment',        'out' => ['Yes'],
                           'req' => ['segment', 'freq']],
        'trg_list'     => ['g' => 'trigger', 'name' => 'List',           'out' => ['Yes'],
                           'req' => ['list', 'freq']],
        'trg_business' => ['g' => 'trigger', 'name' => 'Business event', 'out' => ['Yes'],
                           'req' => ['event']],

        /* ── actions ── */
        'act_wa'     => ['g' => 'action', 'name' => 'WhatsApp',            'out' => ['Sent', 'Failed'], 'req' => ['template'], 'channel' => 'whatsapp'],
        'act_email'  => ['g' => 'action', 'name' => 'Email',               'out' => ['Sent', 'Failed'], 'req' => ['template'], 'channel' => 'email'],
        'act_sms'    => ['g' => 'action', 'name' => 'SMS',                 'out' => ['Sent', 'Failed'], 'req' => ['template'], 'channel' => 'sms'],
        'act_push'   => ['g' => 'action', 'name' => 'App push',            'out' => ['Sent', 'Failed'], 'req' => ['template'], 'channel' => 'push'],
        'act_attr'   => ['g' => 'action', 'name' => 'Update attribute',    'out' => ['Done'],           'req' => ['attr', 'value']],
        'act_remove' => ['g' => 'action', 'name' => 'Remove from journey', 'out' => ['Done'],           'req' => ['journey']],
        'act_hook'   => ['g' => 'action', 'name' => 'Call a service',      'out' => ['Called', 'Failed'], 'req' => ['url'], 'channel' => 'webhook'],
        'act_exit'   => ['g' => 'action', 'name' => 'Exit journey',        'out' => [],                 'req' => ['reason']],

        /* ── conditions ── */
        'cnd_attr'       => ['g' => 'cond', 'name' => 'Check attribute', 'out' => ['True', 'False'], 'req' => ['rules']],
        'cnd_event'      => ['g' => 'cond', 'name' => 'Has done event',  'out' => ['True', 'False'], 'req' => ['type', 'wtype']],
        'cnd_in_segment' => ['g' => 'cond', 'name' => 'Is in segment',   'out' => ['True', 'False'], 'req' => ['segments']],
        'cnd_in_list'    => ['g' => 'cond', 'name' => 'Is in list',      'out' => ['True', 'False'], 'req' => ['lists']],
        // Dynamic outputs — one branch per channel in the configured priority order,
        // plus Unreachable. journey_node_outputs() resolves these from cfg.
        'cnd_reach'      => ['g' => 'cond', 'name' => 'Reachable on',    'out' => 'dynamic:channels', 'req' => []],
        'cnd_split'      => ['g' => 'cond', 'name' => 'Split traffic',   'out' => 'dynamic:variants', 'req' => ['variants']],

        /* ── flow control ── */
        'flw_wait'  => ['g' => 'flow', 'name' => 'Wait',           'out' => ['Next'],                 'req' => ['mode']],
        // `event` is NOT in req: it only applies when type is App / web activity. An engagement
        // wait requires `status` instead, and the conditional check below decides which.
        'flw_event' => ['g' => 'flow', 'name' => 'Wait for event', 'out' => ['Happened', 'Timed out'], 'req' => ['amount']],
    ];
    return $T;
}

const JOURNEY_DEFAULT_CHANNELS = ['Email', 'App push', 'WhatsApp', 'SMS'];

/** Branch names leaving this node, resolved against its own config. */
function journey_node_outputs(array $node): array {
    $T = journey_node_types();
    $def = $T[$node['key'] ?? ''] ?? null;
    if (!$def) return [];
    $out = $def['out'];
    if (!is_string($out)) return $out;

    $cfg = $node['cfg'] ?? [];
    if ($out === 'dynamic:channels') {
        $ch = (isset($cfg['channels']) && is_array($cfg['channels']) && $cfg['channels'])
            ? $cfg['channels'] : JOURNEY_DEFAULT_CHANNELS;
        return array_merge(array_values($ch), ['Unreachable']);
    }
    if ($out === 'dynamic:variants') {
        $vs = (isset($cfg['variants']) && is_array($cfg['variants']) && $cfg['variants'])
            ? $cfg['variants'] : [['key' => 'A', 'pct' => 50], ['key' => 'B', 'pct' => 50]];
        $keys = [];
        foreach ($vs as $v) $keys[] = (string)($v['key'] ?? '');
        return array_values(array_filter($keys, fn($k) => $k !== ''));
    }
    return [];
}

/**
 * Normalises whatever the client sent into { nodes: [id => node], edges: [id => edge] }
 * with every node carrying its own id. Tolerates both the object-map form the builder
 * serialises and a plain array, because a hand-written graph posted by a script is a
 * legitimate way to drive this engine (spec 8.1: build the executor first, JSON graph,
 * no UI).
 */
function journey_graph_parse($graph): array {
    if (is_string($graph)) $graph = json_decode($graph, true);
    if (!is_array($graph)) $graph = [];

    $nodes = [];
    foreach ((array)($graph['nodes'] ?? []) as $id => $n) {
        if (!is_array($n)) continue;
        $id = (string)($n['id'] ?? $id);
        if ($id === '') continue;
        $nodes[$id] = [
            'id'  => $id,
            'key' => (string)($n['key'] ?? ''),
            'x'   => (float)($n['x'] ?? 0),
            'y'   => (float)($n['y'] ?? 0),
            'cfg' => is_array($n['cfg'] ?? null) ? $n['cfg'] : [],
        ];
    }

    $edges = [];
    foreach ((array)($graph['edges'] ?? []) as $id => $e) {
        if (!is_array($e)) continue;
        $id = (string)($e['id'] ?? $id);
        if ($id === '') continue;
        $from = (string)($e['from'] ?? '');
        $to   = (string)($e['to'] ?? '');
        if ($from === '' || $to === '') continue;
        $edges[$id] = [
            'id'     => $id,
            'from'   => $from,
            'to'     => $to,
            'branch' => (string)($e['branch'] ?? ''),
            // Wait lives on the connector, not on a node — Journey 2.0's model, kept.
            'wait'   => is_array($e['wait'] ?? null) ? $e['wait'] : null,
        ];
    }

    return ['nodes' => $nodes, 'edges' => $edges];
}

function journey_trigger_node(array $g): ?array {
    foreach ($g['nodes'] as $n) {
        if (in_array($n['key'], JOURNEY_TRIGGER_KEYS, true)) return $n;
    }
    return null;
}

function journey_out_edges(array $g, string $nodeId, ?string $branch = null): array {
    $out = [];
    foreach ($g['edges'] as $e) {
        if ($e['from'] !== $nodeId) continue;
        if ($branch !== null && $e['branch'] !== $branch) continue;
        $out[] = $e;
    }
    return $out;
}

function journey_in_edges(array $g, string $nodeId): array {
    $out = [];
    foreach ($g['edges'] as $e) if ($e['to'] === $nodeId) $out[] = $e;
    return $out;
}

/** Node ids walkable from the trigger. Iterative, so a cycle can't blow the stack. */
function journey_reachable(array $g): array {
    $trigger = journey_trigger_node($g);
    if (!$trigger) return [];
    $seen = [$trigger['id'] => true];
    $stack = [$trigger['id']];
    while ($stack) {
        $id = array_pop($stack);
        foreach (journey_out_edges($g, $id) as $e) {
            if (isset($seen[$e['to']])) continue;
            $seen[$e['to']] = true;
            $stack[] = $e['to'];
        }
    }
    return $seen;
}

/** True when a required config field is missing/empty on this node. */
function journey_node_bad_cfg(array $node): bool {
    $T = journey_node_types();
    $def = $T[$node['key']] ?? null;
    if (!$def) return true;
    $cfg = $node['cfg'] ?? [];

    foreach ($def['req'] as $k) {
        $v = $cfg[$k] ?? null;
        if ($v === null || $v === '' || (is_array($v) && count($v) === 0)) {
            // Conditional requirements the flat list can't express.
            if ($node['key'] === 'trg_activity' && $k === 'type') return true;
            return true;
        }
    }

    // trg_activity / cnd_event / flw_event: which of event|status is required depends on type.
    if (in_array($node['key'], ['trg_activity', 'cnd_event', 'flw_event'], true)) {
        $type = (string)($cfg['type'] ?? 'App / web activity');

        /*
         * Contact activity asks for neither an event key nor an engagement status — it asks
         * which of the three contact things happened, and then one follow-up question that
         * depends on the answer. Checked before the event/status split below, which would
         * otherwise fall into its else branch and demand a Status that this trigger has no
         * field for, making every contact trigger permanently unpublishable.
         */
        if ($type === 'Contact activity') {
            if ($node['key'] !== 'trg_activity') return true;   // trigger-only activity type
            $what = (string)($cfg['contactActivity'] ?? '');
            if ($what === '') return true;
            if ($what === 'Contact is added to List'
                && ($cfg['contactList'] ?? '') === 'Specific List'
                && trim((string)($cfg['contactListRef'] ?? '')) === '') return true;
            if ($what === 'Contact is updated'
                && ($cfg['contactAttrScope'] ?? '') === 'Specific attribute'
                && trim((string)($cfg['contactAttr'] ?? '')) === '') return true;
            return false;
        }

        if ($type === 'App / web activity') {
            if (empty($cfg['event'])) return true;
        } else {
            if (empty($cfg['status'])) return true;

            /*
             * An engagement node narrowed to a specific campaign or journey but left without one
             * selected is incomplete, not permissive: journey_engagement_scope_sql() deliberately
             * matches nothing in that state rather than silently widening to "any message ever",
             * so the node would sit there forever looking configured and firing for no one.
             */
            require_once __DIR__ . '/JourneyEngagement.php';
            $scope = journey_engagement_scope_from_cfg($cfg);
            if (($scope['comm'] ?? '') === 'Campaign' && (int)($scope['campaign_id'] ?? 0) <= 0) return true;
            if (($scope['comm'] ?? '') === 'Journey'  && (int)($scope['journey_id'] ?? 0) <= 0) return true;
        }
    }

    if ($node['key'] === 'cnd_split') {
        $sum = 0;
        foreach ((array)($cfg['variants'] ?? []) as $v) $sum += (int)($v['pct'] ?? 0);
        if ($sum !== 100) return true;
    }

    if ($node['key'] === 'flw_wait' && ($cfg['mode'] ?? '') === 'A fixed period') {
        if ((int)($cfg['amount'] ?? 0) <= 0) return true;
    }

    return false;
}

function journey_node_label(array $node): string {
    $T = journey_node_types();
    $name = $T[$node['key']]['name'] ?? $node['key'];
    return $name . ' (' . $node['id'] . ')';
}

/**
 * The publish gate.
 *
 * @param array      $graph     raw or parsed graph
 * @param array|null $settings  UI settings blob
 * @param array      $opts      ['require_live_channel' => bool] — when true, a message node on a
 *                              channel with no transport (SMS/push today) is a hard error rather
 *                              than a warning. The deploy path sets it; the draft save doesn't.
 * @return array ['blocking' => string[], 'warnings' => string[]]
 */
function journey_graph_validate($graph, ?array $settings = null, array $opts = []): array {
    $g = journey_graph_parse($graph);
    $blocking = [];
    $warnings = [];

    $triggers = [];
    foreach ($g['nodes'] as $n) if (in_array($n['key'], JOURNEY_TRIGGER_KEYS, true)) $triggers[] = $n;

    if (!$triggers)            $blocking[] = 'This journey has no trigger — nobody can enter it.';
    if (count($triggers) > 1)  $blocking[] = 'More than one trigger. A journey has exactly one entry point.';
    if (!$g['nodes'])          $blocking[] = 'The canvas is empty.';

    $reach = journey_reachable($g);
    $T = journey_node_types();

    foreach ($g['nodes'] as $n) {
        $def = $T[$n['key']] ?? null;
        if (!$def) { $blocking[] = "Unknown step type '{$n['key']}' ({$n['id']})."; continue; }
        $label = journey_node_label($n);

        if (journey_node_bad_cfg($n)) {
            if ($n['key'] === 'cnd_split') $blocking[] = "$label: the variant percentages don't add up to 100.";
            else                           $blocking[] = "$label is missing a required setting.";
        }

        if ($def['g'] !== 'trigger') {
            if (!journey_in_edges($g, $n['id'])) {
                $blocking[] = "$label isn't connected to anything above it.";
            } elseif ($triggers && !isset($reach[$n['id']])) {
                $blocking[] = "$label can't be reached from the trigger.";
            }
        }

        /*
         * Unconnected branches are a WARNING, not a blocker.
         *
         * The defect Netcore documents is users silently ACCUMULATING at a node with
         * no way out. That cannot happen here: journey_process_entry() closes the
         * entry as 'completed' with the reason recorded on the step, so a dead-end
         * branch is a clean end of path, not a leak.
         *
         * Blocking on it was wrong in practice — every terminal message step has a
         * Sent and a Failed output, so a perfectly ordinary five-step journey would
         * demand six Exit nodes before it could go live. Warn, name the branch, and
         * let the author decide.
         */
        foreach (journey_node_outputs($n) as $b) {
            if (!journey_out_edges($g, $n['id'], $b)) {
                $warnings[] = ($def['g'] === 'cond' || $def['g'] === 'flow')
                    ? "$label → $b goes nowhere, so students taking that branch finish the journey immediately. Connect it if that is not what you want."
                    : "$label → $b goes nowhere. Students finish the journey after this step.";
            }
        }

        // Netcore A9.3: two connectors on the SAME branch are not parallel delivery —
        // users move down the first one only. Refuse it rather than silently dropping a path.
        foreach (journey_node_outputs($n) as $b) {
            if (count(journey_out_edges($g, $n['id'], $b)) > 1) {
                $blocking[] = "$label → $b has more than one connector. Students would only take the first — delete the extras.";
            }
        }

        // Channels without a transport.
        if (isset($def['channel']) && in_array($def['channel'], ['sms', 'push'], true)) {
            $msg = "$label uses " . strtoupper($def['channel'])
                 . ", which has no sending provider configured on this server yet.";
            if (!empty($opts['require_live_channel'])) $blocking[] = $msg . ' Remove the step or configure the provider before publishing.';
            else                                       $warnings[] = $msg;
        }
    }

    // End date sanity.
    $s = $settings ?: [];
    $start = (string)($s['start'] ?? '');
    $endD  = (string)($s['endDate'] ?? '');
    if (($s['end'] ?? '') === 'On a date' && $endD !== '' && $start !== '' && strtotime($endD) <= strtotime($start)) {
        $blocking[] = 'The end date is on or before the start date.';
    }

    // Soft advice — mirrors the client's warnings.
    $hasExit = false;
    foreach ($g['nodes'] as $n) if ($n['key'] === 'act_exit') { $hasExit = true; break; }
    if (!$hasExit)          $warnings[] = 'No exit step anywhere. Students will sit at the last node until the journey ends.';
    if (empty($s['goal']))  $warnings[] = 'No conversion goal set — you will not be able to measure whether this worked.';
    if (empty($s['control'])) $warnings[] = 'No holdout group. Without one you cannot separate the journey\'s effect from what students would have done anyway.';

    return ['blocking' => array_values(array_unique($blocking)),
            'warnings' => array_values(array_unique($warnings))];
}

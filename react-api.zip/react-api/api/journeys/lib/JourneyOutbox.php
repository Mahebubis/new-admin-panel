<?php
/*
 * /api/journeys/lib/JourneyOutbox.php
 *
 * "What does the engine still owe, and why hasn't it gone out yet?"
 *
 * ── The question this answers ────────────────────────────────────────────────
 * A journey step that was due at 17:05 while the server was down does go out when the
 * server comes back: every pause is a journey_waits row with a wake_at, and the worker
 * picks up everything with wake_at <= NOW() on its next tick. That part always worked.
 *
 * What did not exist was any way to SEE it. Between 17:05 and the server coming back
 * there was nothing on any screen to say four hundred people were owed a message, nothing
 * to say why, and no way to make it happen now rather than at the top of the next minute.
 * The report showed the journey as healthy — because from its point of view it was — and
 * the only evidence was in a log file on the server.
 *
 * So the Outbox is a read over the tables that already hold the truth, plus the two
 * actions that were missing (send now, cancel). It deliberately does NOT introduce a
 * queue table of its own: a second copy of "who is owed what" would be one more thing to
 * fall out of step with the ledger, and the ledger is already correct.
 *
 * ── The five things that can be in it ────────────────────────────────────────
 *   overdue    a wait whose time has passed and which the worker has not picked up.
 *              This is the server-was-down case, and it is listed first because it is
 *              the only one that means something is wrong right now.
 *   dnd_hold   held by quiet hours. Releases itself when the window ends, or the moment
 *              somebody changes the schedule (journey_dnd_release_holds()).
 *   retry      a send that failed transiently and is backing off.
 *   delay      an ordinary "wait 3 days" connector or Wait step. Not a problem; shown
 *              because "what is this journey going to send, and when" has no other home.
 *   failed     a send that spent its attempts. Terminal unless somebody retries it here.
 *
 * A row that has been claimed but never resolved ('queued' in journey_messages with no
 * sent_at) is folded into `overdue` — it means a worker died between claiming the send
 * and recording the outcome, which is the same class of problem and wants the same fix.
 */

require_once __DIR__ . '/schema.php';
require_once __DIR__ . '/JourneyGraph.php';

/** A wait is "overdue" once the worker has had a fair chance to pick it up and hasn't.
 *  Two minutes: the worker runs every minute and a tick can legitimately take one. */
if (!defined('JOURNEY_OVERDUE_SECONDS')) define('JOURNEY_OVERDUE_SECONDS', 120);

/**
 * Headline counts. One query per bucket rather than one big GROUP BY, because the buckets
 * come from two different tables and a UNION here would be harder to read than five lines.
 */
function journey_outbox_summary(?int $journeyId = null): array {
    global $conn;
    $jf = $journeyId ? ' AND journey_id = ' . (int)$journeyId : '';

    $count = function (string $sql) use ($conn): int {
        $r = @$conn->query($sql);
        $row = $r ? $r->fetch_assoc() : null;
        return (int)($row['c'] ?? 0);
    };

    $overdueW = $count("SELECT COUNT(*) c FROM journey_waits
                         WHERE status = 'pending' AND wake_at <= DATE_SUB(NOW(), INTERVAL "
                       . JOURNEY_OVERDUE_SECONDS . " SECOND)$jf");
    $stuckMsg = $count("SELECT COUNT(*) c FROM journey_messages
                         WHERE status = 'queued' AND queued_at <= DATE_SUB(NOW(), INTERVAL 10 MINUTE)$jf");

    $out = [
        'overdue'  => $overdueW + $stuckMsg,
        'dnd_hold' => $count("SELECT COUNT(*) c FROM journey_waits
                               WHERE status = 'pending' AND reason = 'dnd_hold'$jf"),
        'retry'    => $count("SELECT COUNT(*) c FROM journey_waits
                               WHERE status = 'pending' AND reason = 'retry'$jf"),
        'delay'    => $count("SELECT COUNT(*) c FROM journey_waits
                               WHERE status = 'pending' AND reason = 'delay'
                                 AND wake_at > DATE_SUB(NOW(), INTERVAL " . JOURNEY_OVERDUE_SECONDS . " SECOND)$jf"),
        'failed'   => $count("SELECT COUNT(*) c FROM journey_messages
                               WHERE status = 'failed'$jf"),
    ];
    $out['total'] = $out['overdue'] + $out['dnd_hold'] + $out['retry'] + $out['delay'] + $out['failed'];

    /*
     * When the worker last ran, which is the single most useful fact on this screen: a pile
     * of overdue rows plus "last tick 40 minutes ago" is a cron that has stopped, and a pile
     * of overdue rows plus "last tick 30 seconds ago" is a tick that cannot keep up. Those
     * are different problems and the number is what tells them apart.
     */
    $r = @$conn->query("SELECT MAX(last_worker_at) t FROM journeys WHERE status = 'ongoing'");
    $row = $r ? $r->fetch_assoc() : null;
    $out['last_worker_at'] = $row['t'] ?? null;
    $out['worker_lag_seconds'] = $out['last_worker_at'] ? max(0, time() - strtotime($out['last_worker_at'])) : null;
    $out['next_release'] = null;
    $r = @$conn->query("SELECT MIN(wake_at) t FROM journey_waits WHERE status = 'pending'$jf");
    $row = $r ? $r->fetch_assoc() : null;
    $out['next_release'] = $row['t'] ?? null;

    return $out;
}

/**
 * One page of the Outbox.
 *
 * $kind is one of the bucket names, or 'all'. Ordering is deliberate and the same in every
 * bucket: soonest-due first, so the top of the list is always what is about to happen (or
 * what should already have happened) rather than an arbitrary id order.
 */
function journey_outbox_rows(string $kind, ?int $journeyId, string $search, int $page, int $perPage): array {
    global $conn;

    $offset = max(0, ($page - 1) * $perPage);
    $jf     = $journeyId ? ' AND w.journey_id = ' . (int)$journeyId : '';
    $jfm    = $journeyId ? ' AND m.journey_id = ' . (int)$journeyId : '';
    $overdueCut = 'DATE_SUB(NOW(), INTERVAL ' . JOURNEY_OVERDUE_SECONDS . ' SECOND)';

    $searchSql = '';
    if ($search !== '') {
        $s = $conn->real_escape_string($search);
        $searchSql = " AND (e.email LIKE '%$s%' OR e.phone LIKE '%$s%'
                            OR CONCAT_WS(' ', e.first_name, e.last_name) LIKE '%$s%')";
    }

    $rows = [];
    $total = 0;

    if ($kind === 'failed') {
        $where = "m.status = 'failed'$jfm" . ($search !== ''
            ? " AND (m.to_addr LIKE '%" . $conn->real_escape_string($search) . "%')" : '');
        $tr = @$conn->query("SELECT COUNT(*) c FROM journey_messages m WHERE $where");
        $total = $tr ? (int)$tr->fetch_assoc()['c'] : 0;

        $q = @$conn->query("SELECT m.id, m.journey_id, m.entry_id, m.node_id, m.channel, m.to_addr,
                                   m.error_message, m.attempts, m.queued_at, m.user_id,
                                   j.name AS journey_name, j.graph
                              FROM journey_messages m
                              INNER JOIN journeys j ON j.id = m.journey_id
                             WHERE $where
                             ORDER BY m.queued_at DESC
                             LIMIT $perPage OFFSET $offset");
        while ($q && $r = $q->fetch_assoc()) {
            $rows[] = [
                'id'         => 'm' . (int)$r['id'],
                'kind'       => 'failed',
                'journey_id' => (int)$r['journey_id'],
                'journey'    => $r['journey_name'],
                'entry_id'   => (int)$r['entry_id'],
                'node_id'    => $r['node_id'],
                'step'       => journey_outbox_node_label($r['graph'], (string)$r['node_id']),
                'channel'    => $r['channel'],
                'to'         => $r['to_addr'],
                'user_id'    => (int)$r['user_id'],
                'due_at'     => $r['queued_at'],
                'overdue'    => 0,
                'attempts'   => (int)$r['attempts'],
                'error'      => $r['error_message'],
            ];
        }
        return ['rows' => $rows, 'total' => $total];
    }

    /* Everything else lives in journey_waits. */
    switch ($kind) {
        case 'overdue':  $bucket = "w.wake_at <= $overdueCut"; break;
        case 'dnd_hold': $bucket = "w.reason = 'dnd_hold'";     break;
        case 'retry':    $bucket = "w.reason = 'retry'";        break;
        case 'delay':    $bucket = "w.reason = 'delay' AND w.wake_at > $overdueCut"; break;
        default:         $bucket = '1=1';                        break;   // 'all'
    }
    $where = "w.status = 'pending' AND $bucket$jf$searchSql";

    $tr = @$conn->query("SELECT COUNT(*) c FROM journey_waits w
                          INNER JOIN journey_entries e ON e.id = w.entry_id
                         WHERE $where");
    $total = $tr ? (int)$tr->fetch_assoc()['c'] : 0;

    $q = @$conn->query("SELECT w.id, w.journey_id, w.entry_id, w.node_id, w.wake_at, w.reason,
                               w.last_error, w.held_since,
                               TIMESTAMPDIFF(SECOND, w.wake_at, NOW()) AS late_by,
                               e.email, e.phone, e.first_name, e.last_name, e.user_id,
                               j.name AS journey_name, j.graph
                          FROM journey_waits w
                          INNER JOIN journey_entries e ON e.id = w.entry_id
                          INNER JOIN journeys j ON j.id = w.journey_id
                         WHERE $where
                         ORDER BY w.wake_at ASC
                         LIMIT $perPage OFFSET $offset");
    while ($q && $r = $q->fetch_assoc()) {
        $late = (int)$r['late_by'];
        [$label, $channel] = journey_outbox_node_info($r['graph'], (string)$r['node_id']);
        $rows[] = [
            'id'         => 'w' . (int)$r['id'],
            // A row can be BOTH a dnd_hold and overdue; overdue wins, because "the worker
            // has not touched this" is the more urgent of the two facts.
            'kind'       => $late > JOURNEY_OVERDUE_SECONDS ? 'overdue' : (string)$r['reason'],
            'reason'     => (string)$r['reason'],
            'journey_id' => (int)$r['journey_id'],
            'journey'    => $r['journey_name'],
            'entry_id'   => (int)$r['entry_id'],
            'node_id'    => $r['node_id'],
            'step'       => $label,
            'channel'    => $channel,
            'to'         => $channel === 'whatsapp' ? $r['phone'] : $r['email'],
            'name'       => trim(($r['first_name'] ?? '') . ' ' . ($r['last_name'] ?? '')),
            'user_id'    => (int)$r['user_id'],
            'due_at'     => $r['wake_at'],
            'held_since' => $r['held_since'],
            'overdue'    => max(0, $late),
            'error'      => $r['last_error'],
        ];
    }
    return ['rows' => $rows, 'total' => $total];
}

/** The step's display name, resolved from the journey's own graph. */
function journey_outbox_node_info($graphJson, string $nodeId): array {
    static $cache = [];
    $key = md5((string)$graphJson) . ':' . $nodeId;
    if (isset($cache[$key])) return $cache[$key];

    $g = json_decode((string)$graphJson, true);
    $node = $g['nodes'][$nodeId] ?? null;
    if (!$node) return $cache[$key] = ["Step $nodeId (no longer on the canvas)", ''];

    $types = journey_node_types();
    $def = $types[$node['key']] ?? null;
    $name = $def['name'] ?? $node['key'];
    $cfg = $node['cfg'] ?? [];
    $extra = trim((string)($cfg['template'] ?? $cfg['title'] ?? ''));
    return $cache[$key] = [$extra !== '' ? "$name · $extra" : $name, (string)($def['channel'] ?? '')];
}

function journey_outbox_node_label($graphJson, string $nodeId): string {
    return journey_outbox_node_info($graphJson, $nodeId)[0];
}

/**
 * Send now.
 *
 * For a wait, that means pulling wake_at forward to this instant — the worker's own
 * "wake_at <= NOW()" sweep does the rest, so there is exactly one code path that starts a
 * step and no second, subtly different one living in here.
 *
 * For a failed message it means clearing the way for a fresh attempt: the entry goes back
 * to the node it failed on, and the failed row keeps its place on the ledger. The next
 * attempt gets its own idem_key (attempt N+1), which is what makes this safe to press
 * twice — journey_attempt_no() counts the ledger, so the retry cannot collide with the
 * attempt that failed.
 *
 * @param string[] $ids row ids as returned by journey_outbox_rows() ('w123' / 'm456')
 */
function journey_outbox_release(array $ids): array {
    global $conn;
    $waitIds = []; $msgIds = [];
    foreach ($ids as $id) {
        $id = trim((string)$id);
        if ($id === '') continue;
        if ($id[0] === 'w') $waitIds[] = (int)substr($id, 1);
        elseif ($id[0] === 'm') $msgIds[] = (int)substr($id, 1);
    }

    $released = 0; $requeued = 0;

    if ($waitIds) {
        $in = implode(',', array_map('intval', $waitIds));
        @$conn->query("UPDATE journey_waits SET wake_at = NOW()
                        WHERE id IN ($in) AND status = 'pending'");
        $released = $conn->affected_rows;
    }

    foreach ($msgIds as $mid) {
        $r = @$conn->query("SELECT entry_id, node_id, journey_id FROM journey_messages
                             WHERE id = $mid AND status = 'failed' LIMIT 1");
        $m = $r ? $r->fetch_assoc() : null;
        if (!$m) continue;

        /*
         * Put the student back on the failing node and mark them active. Deliberately not
         * queueing a wait: the entry is due NOW, and journey_advance_entries() picks up
         * every active entry on the next tick. Restricted to entries that are still in the
         * journey — retrying a message for somebody who has since exited would walk them
         * back into a journey they have left.
         */
        $upd = @$conn->query("UPDATE journey_entries
                                 SET status = 'active', current_node = '" . $conn->real_escape_string($m['node_id']) . "'
                               WHERE id = " . (int)$m['entry_id'] . "
                                 AND status IN ('active','waiting','errored')");
        if ($upd && $conn->affected_rows > 0) {
            @$conn->query("UPDATE journey_waits SET status = 'cancelled'
                            WHERE entry_id = " . (int)$m['entry_id'] . " AND status = 'pending'");
            $requeued++;
        }
    }

    return ['released' => $released, 'requeued' => $requeued];
}

/**
 * Drop it.
 *
 * The wait is cancelled and the student is walked ON from that node rather than being
 * stranded on it — "cancel this message" means "skip this step", not "delete this person
 * halfway through a journey". The entry is left active on the same node with the wait
 * gone, which is not enough on its own, so the step is recorded as skipped and the entry
 * is moved to the node's first outgoing connector.
 *
 * Everything after the cancel is normal journey execution, which is the point: a cancelled
 * message must not need special handling anywhere else in the engine.
 */
function journey_outbox_cancel(array $ids, string $note = ''): array {
    global $conn;
    $cancelled = 0;

    foreach ($ids as $id) {
        $id = trim((string)$id);
        if ($id === '' || $id[0] !== 'w') continue;
        $wid = (int)substr($id, 1);

        $r = @$conn->query("SELECT w.*, j.graph FROM journey_waits w
                             INNER JOIN journeys j ON j.id = w.journey_id
                            WHERE w.id = $wid AND w.status = 'pending' LIMIT 1");
        $w = $r ? $r->fetch_assoc() : null;
        if (!$w) continue;

        @$conn->query("UPDATE journey_waits SET status = 'cancelled' WHERE id = $wid AND status = 'pending'");
        if ($conn->affected_rows !== 1) continue;

        $graph = journey_graph_parse($w['graph']);
        $node  = $graph['nodes'][$w['node_id']] ?? null;

        journey_record_step((int)$w['entry_id'], (int)$w['journey_id'], (string)$w['node_id'],
            $node['key'] ?? 'unknown', null, 'suppressed',
            'Cancelled from the Outbox' . ($note !== '' ? ": $note" : '') . '. The student continues from here.');

        /*
         * Where they go next. A message node's first output ('Sent' / 'Called') is the
         * continuation path, which is the same one a suppressed send takes — so cancelling
         * behaves exactly like a frequency-capped message, a behaviour the engine already
         * has and the report already explains.
         */
        $branch = '';
        if ($node) {
            $outs = journey_node_outputs($node);
            $branch = (string)($outs[0] ?? '');
        }
        $edges = $node ? journey_out_edges($graph, (string)$w['node_id'], $branch) : [];
        if ($edges) {
            @$conn->query("UPDATE journey_entries
                              SET status = 'active', current_node = '" . $conn->real_escape_string($edges[0]['to']) . "'
                            WHERE id = " . (int)$w['entry_id']);
        } else {
            journey_close_entry((int)$w['entry_id'], 'completed', 'Cancelled from the Outbox');
        }
        $cancelled++;
    }
    return ['cancelled' => $cancelled];
}

/**
 * Make the worker run now instead of at the top of the next minute.
 *
 * Fire-and-forget over a one-second socket, exactly as campaigns/lib/SendWorker.php's
 * trigger_worker_async() does — the panel must not block on a tick that can legitimately
 * take four minutes on a large journey, and journey-worker.php's flock means a kick that
 * lands while a tick is already running simply no-ops.
 *
 * Best-effort by design: if the socket cannot be opened, the next cron minute picks
 * everything up anyway. Releasing is already durable in the database by this point.
 */
function journey_kick_worker_async(?int $journeyId = null): void {
    if (!defined('CRON_SECRET')) return;
    $host = 'cit3.internshipstudio.com';
    $path = '/admin/react-api/api/journeys/journey-worker.php?secret=' . urlencode(CRON_SECRET)
          . ($journeyId ? '&journey_id=' . (int)$journeyId : '');
    $fp = @fsockopen('ssl://' . $host, 443, $errno, $errstr, 1);
    if (!$fp) return;
    stream_set_timeout($fp, 1);
    fwrite($fp, "GET $path HTTP/1.1\r\nHost: $host\r\nConnection: Close\r\n\r\n");
    fclose($fp);
}

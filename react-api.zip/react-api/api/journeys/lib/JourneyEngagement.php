<?php
/*
 * Engagement as a journey event source — "they opened the email", "they read the WhatsApp",
 * "they tapped the button".
 *
 * WHY THIS FILE EXISTS
 * The Activity trigger, the Has-done-event condition and the Wait-for-event node all offered
 * Email / WhatsApp / SMS activity types in the builder, and all three refused them at run time
 * with "no source wired up yet". So the single most useful journey anyone actually wants —
 * send an email, wait, and if they opened it send WhatsApp, otherwise something else — could be
 * drawn but never run. This is that source.
 *
 * WHERE ENGAGEMENT ACTUALLY LIVES
 * There is no engagement table. There are four, written by four unrelated paths, and a student's
 * open can legitimately be in any of them:
 *
 *   email_campaign_events    ESP webhooks + our own open/click pixels, for BROADCAST email.
 *                            Keyed by recipient_id → email_campaign_recipients.email.
 *   wa_campaign_events       provider webhooks for BROADCAST WhatsApp (read / button_click / …).
 *                            Keyed by recipient_id → wa_campaign_recipients.phone.
 *   wa_link_clicks           taps on a tracked link inside a WhatsApp message. Separate because
 *                            Meta reports nothing at all for URL buttons — the redirect through
 *                            the panel is the ONLY evidence a link was ever tapped.
 *   journey_messages         the journey engine's own ledger, for messages a JOURNEY sent.
 *                            Already carries user_id, opened_at and first_clicked_at.
 *
 * So every query here is a UNION over whichever of those the requested (channel, status) can
 * appear in, normalised to the one shape the engine consumes: {user_id, at}.
 *
 * IDENTITY
 * A journey enrols a user_id, but a campaign is addressed to an email or a phone number and goes
 * to plenty of people who have never signed in. Fortunately both recipient tables already resolve
 * that at send time and store `user_id` on the row, so these queries read it rather than
 * re-deriving it — which matters more than it sounds: matching a phone back to `users` means
 * normalising both sides (users.phone holds bare 10-digit Indian numbers, everything WhatsApp
 * holds is country-code prefixed), and a function on an indexed column turns a lookup into a
 * 3.3M-row scan on a query that runs every tick.
 *
 * Email keeps ONE fallback join for recipients whose user_id was never resolved — u.email is
 * indexed, and COLLATE forces the two tables' differing collations to agree so the index is still
 * usable. Phone gets no such fallback on purpose: there is no index that could serve it.
 * Anyone who cannot be resolved is dropped rather than guessed at — a journey that enrols the
 * wrong student is worse than one that enrols nobody.
 *
 * ONE OPEN, NOT EVERY OPEN
 * journey_messages stores opened_at / first_clicked_at as single timestamps, so it can only
 * report the FIRST open of a given message. That is the right semantic here anyway — a trigger
 * that re-fires because a mail client re-fetched the pixel would be a bug, not a feature — and
 * the campaign event tables are collapsed to their earliest row per (recipient, type) for the
 * same reason.
 */

require_once __DIR__ . '/JourneyConditions.php';

/** Does a table exist? WhatsApp and campaigns are separate installs; either can be absent. */
function journey_engagement_has_table(string $table): bool {
    global $conn;
    static $cache = [];
    if (array_key_exists($table, $cache)) return $cache[$table];
    $r = @$conn->query("SHOW TABLES LIKE '" . $conn->real_escape_string($table) . "'");
    return $cache[$table] = (bool)($r && $r->num_rows > 0);
}

/**
 * The builder's activity type + status → the concrete event names in each store.
 *
 * Returns null for a combination nothing records, which is how the caller tells "nobody did this
 * yet" (an empty result) from "this can never fire" (a configuration problem worth reporting).
 *
 * @return array{channel:string, campaign_types:array, journey_col:?string, link_clicks:bool}|null
 */
function journey_engagement_spec(string $activityType, string $status): ?array {
    $s = strtolower(trim($status));

    if ($activityType === 'Email activity') {
        switch ($s) {
            // 'open_bot' is deliberately EXCLUDED. Gmail and Outlook prefetch images, and a
            // journey that branches on a machine opening a mail is a journey that branches on
            // nothing — the bot classification exists precisely so this can be honest.
            case 'open':        return ['channel' => 'email', 'campaign_types' => ['open'],  'journey_col' => 'opened_at',       'link_clicks' => false];
            case 'click':       return ['channel' => 'email', 'campaign_types' => ['click'], 'journey_col' => 'first_clicked_at', 'link_clicks' => false];
            case 'hard bounce':
            case 'bounce':      return ['channel' => 'email', 'campaign_types' => ['bounce'], 'journey_col' => null, 'link_clicks' => false];
            case 'unsubscribe': return ['channel' => 'email', 'campaign_types' => ['unsubscribe'], 'journey_col' => null, 'link_clicks' => false];
            case 'spam':
            case 'spam report': return ['channel' => 'email', 'campaign_types' => ['spamreport'], 'journey_col' => null, 'link_clicks' => false];
            case 'deliver':
            case 'delivered':   return ['channel' => 'email', 'campaign_types' => [], 'journey_col' => 'delivered_at', 'link_clicks' => false];
        }
        return null;
    }

    if ($activityType === 'WhatsApp activity') {
        switch ($s) {
            case 'open / read':
            case 'open':
            case 'read':      return ['channel' => 'whatsapp', 'campaign_types' => ['read'],      'journey_col' => 'opened_at',    'link_clicks' => false];
            case 'deliver':
            case 'delivered': return ['channel' => 'whatsapp', 'campaign_types' => ['delivered'], 'journey_col' => 'delivered_at', 'link_clicks' => false];
            // Both kinds of tap count as a click: a quick-reply button arrives as a
            // 'button_click' event, and a URL button is only ever visible in wa_link_clicks.
            case 'click':     return ['channel' => 'whatsapp', 'campaign_types' => ['button_click'], 'journey_col' => 'first_clicked_at', 'link_clicks' => true];
            case 'reply':
            case 'replied':   return ['channel' => 'whatsapp', 'campaign_types' => ['replied'], 'journey_col' => null, 'link_clicks' => false];
            case 'fail':
            case 'failed':    return ['channel' => 'whatsapp', 'campaign_types' => ['failed'],  'journey_col' => null, 'link_clicks' => false];
        }
        return null;
    }

    // SMS, App push and Web push have no transport on this server, so they have no events
    // either. Returning null makes the caller say so plainly instead of polling nothing forever.
    return null;
}

/**
 * A human explanation of why a given activity type/status can never fire, for the "this journey
 * cannot start anybody" banner. Kept next to the mapping so the two cannot drift.
 */
function journey_engagement_unsupported_reason(string $activityType, string $status): string {
    if (in_array($activityType, ['SMS activity', 'App push activity', 'Web push activity'], true)) {
        return "$activityType has no provider configured on this server, so it never produces events. "
             . 'Use Email activity or WhatsApp activity instead.';
    }
    return "'$status' is not an event this panel records for $activityType, so nothing can match it.";
}

/**
 * Restricts an engagement query to one campaign or one journey.
 *
 * $scope: ['comm' => 'Any'|'Campaign'|'Journey', 'campaign_id' => int, 'journey_id' => int,
 *          'node_id' => string]
 *
 * This is what makes "opened THAT email" expressible rather than only "opened any email". Netcore
 * calls it Communication → Journey/Campaign → Message name, and without it an engagement trigger
 * is far too broad to build a real flow on: every marketing email anyone ever opened would
 * re-enter them.
 *
 * @return array{campaign: string, journey: string} SQL fragments, each already AND-prefixed
 */
function journey_engagement_scope_sql(array $scope): array {
    global $conn;
    $comm = (string)($scope['comm'] ?? 'Any');

    if ($comm === 'Campaign') {
        $cid = (int)($scope['campaign_id'] ?? 0);
        // An unfilled campaign picker must match NOTHING, not everything — silently widening
        // a scope is how a test journey mails the entire database.
        return ['campaign' => $cid > 0 ? " AND r.campaign_id = $cid" : ' AND 1=0',
                'journey'  => ' AND 1=0'];
    }

    if ($comm === 'Journey') {
        $jid = (int)($scope['journey_id'] ?? 0);
        $node = trim((string)($scope['node_id'] ?? ''));
        if ($jid <= 0) return ['campaign' => ' AND 1=0', 'journey' => ' AND 1=0'];
        $sql = " AND m.journey_id = $jid";
        if ($node !== '') $sql .= " AND m.node_id = '" . $conn->real_escape_string($node) . "'";
        return ['campaign' => ' AND 1=0', 'journey' => $sql];
    }

    return ['campaign' => '', 'journey' => ''];
}

/**
 * The builder's node config → the scope structure used above.
 *
 * The UI names the pieces the way Netcore does (Communication → Campaign / Journey → Message),
 * so the translation lives here rather than being spelled out at each of the three call sites
 * (trigger, condition, wait) that need it.
 */
function journey_engagement_scope_from_cfg(array $cfg): array {
    /*
     * The builder's pickers are plain string selects, so a campaign arrives as its LABEL —
     * "iCAT 175 Last Batch #9642" — with the id appended. Pulling the id back out here keeps the
     * canvas readable (a saved graph names the campaign rather than showing a bare number, which
     * matters when you reopen a journey six months later) without needing a value/label select
     * type threaded through every field in the builder. A plain integer still works, so nothing
     * saved by an API client has to know about the convention.
     */
    $id = static function ($v): int {
        if (is_int($v) || ctype_digit((string)$v)) return (int)$v;
        return preg_match('/#(\d+)\s*$/', (string)$v, $m) ? (int)$m[1] : 0;
    };

    $comm = (string)($cfg['comm'] ?? 'Any message');
    if ($comm === 'Campaign') {
        return ['comm' => 'Campaign', 'campaign_id' => $id($cfg['campaignId'] ?? 0)];
    }
    if ($comm === 'Journey') {
        /*
         * The message-step picker stores a label — "Welcome email (n4)" — with the node id in
         * brackets, the same convention the campaign and journey pickers use for their ids. The
         * "Any message …" entry has no bracketed id and therefore resolves to an empty node_id,
         * which is exactly right: no node filter means the whole journey.
         *
         * A bare node id still works, so anything saved before this picker existed, or written
         * by an API client, keeps behaving the same way.
         */
        $node = trim((string)($cfg['messageNodeId'] ?? ''));
        if ($node !== '' && preg_match('/\(([A-Za-z0-9_-]+)\)\s*$/', $node, $m)) {
            $node = $m[1];
        } elseif (!preg_match('/^[A-Za-z0-9_-]+$/', $node)) {
            /*
             * Anything that is not a bracketed id and not a bare id is one of the picker's
             * prose entries — "Any message in that journey", or the "(that journey has no Email
             * steps)" placeholder. Both mean NO node filter. Falling through with the prose as
             * a node id would silently match nothing, which is the worst of the three outcomes:
             * the step would look configured and fire for nobody.
             */
            $node = '';
        }

        return ['comm' => 'Journey',
                'journey_id' => $id($cfg['journeyRefId'] ?? 0),
                'node_id'    => $node];
    }
    return ['comm' => 'Any'];
}

/**
 * Is this scope actually pointing at something that exists on this channel?
 *
 * email_campaigns.id and wa_campaigns.id are INDEPENDENT auto-increment sequences, so campaign
 * #22 can be a real email campaign AND a completely unrelated WhatsApp campaign at the same
 * time. The picker stores the id inside a label ("test 23 (Copy) #22") and filters its options
 * by the activity type — but the stored value survives a later change of activity type, and at
 * that point the very same #22 silently starts meaning the other channel's campaign. The node
 * looks correctly configured and quietly reports on a campaign nobody chose.
 *
 * Cheap to rule out — one indexed lookup — and the answer is the difference between "nobody
 * engaged" and "you are looking at the wrong campaign".
 *
 * @return string|null a human-readable problem, or null when the scope is sound
 */
function journey_engagement_scope_problem(array $spec, array $scope): ?string {
    global $conn;
    if (($scope['comm'] ?? '') !== 'Campaign') return null;

    $cid = (int)($scope['campaign_id'] ?? 0);
    if ($cid <= 0) return 'This step is narrowed to a campaign but no campaign is selected, so it can never match.';

    $isWa  = ($spec['channel'] ?? '') === 'whatsapp';
    $table = $isWa ? 'wa_campaigns' : 'email_campaigns';
    $other = $isWa ? 'email_campaigns' : 'wa_campaigns';
    if (!journey_engagement_has_table($table)) return null;

    $r = @$conn->query("SELECT name FROM $table WHERE id = $cid LIMIT 1");
    if ($r && $r->num_rows > 0) return null;

    // Naming the other channel's campaign is the whole point: it turns "no such campaign" into
    // "you picked the WhatsApp one and this step reads email".
    $hint = '';
    if (journey_engagement_has_table($other)) {
        $o = @$conn->query("SELECT name FROM $other WHERE id = $cid LIMIT 1");
        if ($o && $row = $o->fetch_assoc()) {
            $hint = " There IS a $other campaign #$cid called \"" . $row['name'] . "\" — the two channels number "
                  . 'their campaigns separately, so re-pick the campaign after changing the activity type.';
        }
    }
    return "This step watches " . ($isWa ? 'WhatsApp' : 'email') . " activity on campaign #$cid, "
         . "but there is no $table with that id.$hint";
}

/**
 * The trigger's look-back, in hours.
 *
 * Accepts the builder's label ("Last 24 hours") or a bare number, the same tolerance the id
 * pickers have — a value written by an API client should not have to know the UI's wording.
 * Capped at 30 days: beyond that the engagement is too old to chase and the first tick would
 * scan a range no index helps with.
 */
function journey_backfill_hours($v): int {
    if (is_int($v) || ctype_digit((string)$v)) return max(0, min(720, (int)$v));

    $s = strtolower(trim((string)$v));
    if ($s === '' || strpos($s, 'now on') !== false || strpos($s, 'none') !== false) return 0;
    if (!preg_match('/(\d+)\s*(hour|day|week)/', $s, $m)) return 0;

    $n = (int)$m[1];
    $h = $m[2] === 'day' ? $n * 24 : ($m[2] === 'week' ? $n * 168 : $n);
    return max(0, min(720, $h));
}

/**
 * The watermark key for one engagement trigger.
 *
 * Two engagement triggers in the same journey (opened campaign A / opened campaign B) must not
 * share a cursor — whichever ticked first would swallow the other's rows — so the scope is part
 * of the key. It is hashed rather than spelled out because journey_event_cursors.source_key is
 * VARCHAR(64) and the readable form runs right up against that; channel and status stay in clear
 * text so the row is still recognisable when reading the table by hand.
 */
function journey_engagement_cursor_key(array $spec, string $status, array $scope): string {
    $slug = preg_replace('/[^a-z0-9]+/', '_', strtolower($status)) ?: 'event';
    $desc = ($scope['comm'] ?? 'Any') . '|' . (int)($scope['campaign_id'] ?? 0)
          . '|' . (int)($scope['journey_id'] ?? 0) . '|' . (string)($scope['node_id'] ?? '');
    return 'eng:' . $spec['channel'] . ':' . substr($slug, 0, 14) . ':' . substr(sha1($desc), 0, 10);
}

/**
 * New engagement rows in ($since, $until], oldest first — the trigger's polling query.
 *
 * Mirrors journey_event_new_rows() exactly in contract (exclusive lower bound, inclusive upper,
 * both supplied by the caller so a row written mid-tick cannot fall through the crack between
 * two windows) so the Activity trigger can use either without caring which.
 *
 * @return array<int, array{user_id:int, at:string}>
 */
function journey_engagement_new_rows(array $spec, array $scope, string $since, string $until, int $limit = 2000): array {
    global $conn;

    $sinceQ = "'" . $conn->real_escape_string($since) . "'";
    $untilQ = "'" . $conn->real_escape_string($until) . "'";
    $scopeSql = journey_engagement_scope_sql($scope);
    $parts = [];

    /* ── campaign broadcasts ───────────────────────────────────────────────────────────── */
    if ($spec['campaign_types'] && $scopeSql['campaign'] !== ' AND 1=0') {
        $types = "'" . implode("','", array_map([$conn, 'real_escape_string'], $spec['campaign_types'])) . "'";

        if ($spec['channel'] === 'email' && journey_engagement_has_table('email_campaign_events')) {
            // COALESCE, not a plain read: user_id is filled in at send time for anyone the
            // audience resolver could identify, and the LEFT JOIN picks up the rest by address.
            $parts[] = "SELECT COALESCE(r.user_id, u.user_id) AS user_id, MIN(e.created_at) AS at
                          FROM email_campaign_events e
                          INNER JOIN email_campaign_recipients r ON r.id = e.recipient_id
                          LEFT  JOIN users u ON r.user_id IS NULL
                                            AND u.email = r.email COLLATE utf8mb4_general_ci
                         WHERE e.event_type IN ($types)
                           AND e.created_at > $sinceQ AND e.created_at <= $untilQ
                           AND r.is_test = 0
                           {$scopeSql['campaign']}
                         GROUP BY COALESCE(r.user_id, u.user_id), e.recipient_id";
        }

        if ($spec['channel'] === 'whatsapp' && journey_engagement_has_table('wa_campaign_events')) {
            $parts[] = "SELECT r.user_id AS user_id, MIN(e.created_at) AS at
                          FROM wa_campaign_events e
                          INNER JOIN wa_campaign_recipients r ON r.id = e.recipient_id
                         WHERE e.event_type IN ($types)
                           AND e.created_at > $sinceQ AND e.created_at <= $untilQ
                           AND r.is_test = 0 AND r.user_id IS NOT NULL
                           {$scopeSql['campaign']}
                         GROUP BY r.user_id, e.recipient_id";
        }
    }

    /* ── tracked links inside WhatsApp messages ────────────────────────────────────────── */
    if (!empty($spec['link_clicks']) && $scopeSql['campaign'] !== ' AND 1=0'
        && journey_engagement_has_table('wa_link_clicks')) {
        /*
         * wa_link_clicks resolves identity itself at redirect time and stores user_id on the
         * click, so it needs no join at all in the common case. The LEFT JOIN to the recipient
         * row is only there to recover a user_id for a click logged before that resolution
         * existed, and to carry the campaign scope.
         */
        $parts[] = "SELECT COALESCE(c.user_id, r.user_id) AS user_id, MIN(c.clicked_at) AS at
                      FROM wa_link_clicks c
                      LEFT JOIN wa_campaign_recipients r ON r.id = c.recipient_id
                     WHERE c.clicked_at > $sinceQ AND c.clicked_at <= $untilQ
                       AND COALESCE(c.user_id, r.user_id) IS NOT NULL
                       {$scopeSql['campaign']}
                     GROUP BY COALESCE(c.user_id, r.user_id), c.recipient_id";
    }

    /* ── the journey engine's own sends ────────────────────────────────────────────────── */
    if (!empty($spec['journey_col']) && $scopeSql['journey'] !== ' AND 1=0') {
        $col = $spec['journey_col'];   // whitelisted by journey_engagement_spec(), never user input
        $ch  = $conn->real_escape_string($spec['channel']);
        $parts[] = "SELECT m.user_id AS user_id, m.$col AS at
                      FROM journey_messages m
                     WHERE m.channel = '$ch' AND m.user_id IS NOT NULL
                       AND m.$col IS NOT NULL
                       AND m.$col > $sinceQ AND m.$col <= $untilQ
                       {$scopeSql['journey']}";
    }

    if (!$parts) return [];

    // UNION ALL, then collapse: the same person can appear in two sources for the same act (a
    // journey email is also an email_campaign_events row when the ESP webhook lands), and the
    // trigger must see one event, not two. MIN() keeps the earliest, which is the real moment.
    $sql = 'SELECT user_id, MIN(at) AS at FROM (' . implode(' UNION ALL ', $parts) . ') x
             WHERE user_id > 0 AND at IS NOT NULL
             GROUP BY user_id
             ORDER BY at ASC LIMIT ' . (int)$limit;

    $r = @$conn->query($sql);
    if ($r === false) {
        journey_cond_log('engagement_new_rows SQL failed: ' . $conn->error);
        return [];
    }
    $out = [];
    while ($row = $r->fetch_assoc()) {
        $uid = (int)$row['user_id'];
        if ($uid > 0) $out[] = ['user_id' => $uid, 'at' => (string)$row['at']];
    }
    return $out;
}

/**
 * Did ONE student engage inside a window? The condition/wait counterpart of the query above.
 *
 * $fromSql / $toSql are the already-quoted literals journey_event_window() produces, or null for
 * an open-ended bound — identical to journey_event_happened(), so the two are interchangeable at
 * the call site.
 *
 * Returns null when the question is unanswerable (no such source), which the caller must not
 * treat as false: "we cannot tell" and "they did not" lead to different branches.
 */
function journey_engagement_happened(int $userId, array $spec, array $scope, ?string $fromSql, ?string $toSql): ?bool {
    global $conn;
    if ($userId <= 0) return null;

    $scopeSql = journey_engagement_scope_sql($scope);
    $win = fn(string $col) => ($fromSql ? " AND $col > $fromSql" : '') . ($toSql ? " AND $col <= $toSql" : '');
    $parts = [];

    if ($spec['campaign_types'] && $scopeSql['campaign'] !== ' AND 1=0') {
        $types = "'" . implode("','", array_map([$conn, 'real_escape_string'], $spec['campaign_types'])) . "'";

        if ($spec['channel'] === 'email' && journey_engagement_has_table('email_campaign_events')) {
            // One student, so the address fallback is a single indexed lookup rather than a join
            // across the whole recipient table — cheap enough to keep the same coverage as the
            // polling query above.
            $parts[] = "SELECT 1 FROM email_campaign_events e
                          INNER JOIN email_campaign_recipients r ON r.id = e.recipient_id
                         WHERE (r.user_id = $userId
                                OR (r.user_id IS NULL AND r.email COLLATE utf8mb4_general_ci
                                    = (SELECT email FROM users WHERE user_id = $userId)))
                           AND e.event_type IN ($types) AND r.is_test = 0"
                       . $win('e.created_at') . $scopeSql['campaign'] . ' LIMIT 1';
        }
        if ($spec['channel'] === 'whatsapp' && journey_engagement_has_table('wa_campaign_events')) {
            $parts[] = "SELECT 1 FROM wa_campaign_events e
                          INNER JOIN wa_campaign_recipients r ON r.id = e.recipient_id
                         WHERE r.user_id = $userId AND e.event_type IN ($types) AND r.is_test = 0"
                       . $win('e.created_at') . $scopeSql['campaign'] . ' LIMIT 1';
        }
    }

    if (!empty($spec['link_clicks']) && $scopeSql['campaign'] !== ' AND 1=0'
        && journey_engagement_has_table('wa_link_clicks')) {
        $parts[] = "SELECT 1 FROM wa_link_clicks c
                      LEFT JOIN wa_campaign_recipients r ON r.id = c.recipient_id
                     WHERE COALESCE(c.user_id, r.user_id) = $userId"
                   . $win('c.clicked_at') . $scopeSql['campaign'] . ' LIMIT 1';
    }

    if (!empty($spec['journey_col']) && $scopeSql['journey'] !== ' AND 1=0') {
        $col = $spec['journey_col'];
        $ch  = $conn->real_escape_string($spec['channel']);
        $parts[] = "SELECT 1 FROM journey_messages m
                     WHERE m.user_id = $userId AND m.channel = '$ch' AND m.$col IS NOT NULL"
                   . $win("m.$col") . $scopeSql['journey'] . ' LIMIT 1';
    }

    if (!$parts) return null;

    foreach ($parts as $sql) {
        $r = @$conn->query($sql);
        if ($r === false) { journey_cond_log('engagement_happened SQL failed: ' . $conn->error); continue; }
        if ($r->num_rows > 0) return true;
    }
    return false;
}

<?php
/*
 * /api/journeys/lib/JourneyWebhookSink.php
 *
 * Delivery receipts for journey messages.
 *
 * ── Why this file exists ─────────────────────────────────────────────────────
 * The engine knew when it handed a message to SendGrid or to Netcore, and nothing
 * after that. "Sent" meant "the provider accepted it", which is why a journey could
 * show 3 sent and 0 delivered forever: the provider's later callbacks — delivered,
 * read, bounced, failed — all landed in the campaign webhooks, which look the rid up
 * in email_campaign_recipients / wa_campaign_recipients, find nothing, and move on.
 *
 * ── Why it hooks into the EXISTING webhooks rather than adding new ones ──────
 * A provider posts to one URL. SendGrid's Event Webhook and the WhatsApp callback are
 * already registered and working for campaigns; adding second endpoints would mean
 * reconfiguring both providers and hoping nobody ever points one at the wrong place.
 * Instead each campaign webhook keeps its existing fast path untouched and, only when
 * the rid is NOT one of its own, offers the event here. Campaign traffic behaves
 * exactly as before; journey traffic stops being thrown away.
 *
 * Every function returns true when it claimed the event, so the caller can count it.
 */

require_once __DIR__ . '/../../../config/database.php';

/* ════════════════════════════════════════════════════════════════════════════
   Journeys inside the shared attribution ledger

   A journey conversion used to be counted by asking "did the goal happen between
   the click and the click + window?". That credits a journey for anything that
   merely FOLLOWS a click — including someone who clicked, left, and came back a
   day later by typing the address themselves. Campaigns never had that problem,
   because their proof is a cookie that the dashboard DELETES the moment a visitor
   arrives without one. Journeys now use that same proof.

   Reusing campaign_attributions rather than building a parallel ledger means the
   write path already exists end to end: the dashboard's record_conversion() and
   the Go payment service both pass `medium` and `campaign_id` through verbatim,
   so neither needs to learn what a journey is.

   TWO CONSTANTS MAKE THAT SAFE TO SHARE:

   OFFSET — the table's unique key is (user_id, campaign_id, event_key), with no
   medium in it. Journey 17 and campaign 17 would therefore be the same row, and
   INSERT IGNORE would silently drop whichever arrived second. Journey ids are
   moved into their own numeric range so the two can never meet. Changing the
   unique key would have been the tidier fix, but that table is written by PHP and
   by the Go payment service, and an ALTER there is not worth the risk.

   MEDIUM — deliberately 'journey', not 'journey_email' / 'journey_whatsapp'. It is
   shorter than the 'whatsapp' already stored in that column, so it cannot overflow
   a width nobody here can verify. The channel is not lost: the journey id says
   which journey, and journey_messages says which channel it sent on.
   ═══════════════════════════════════════════════════════════════════════════ */
if (!defined('JOURNEY_ATTR_OFFSET')) define('JOURNEY_ATTR_OFFSET', 1000000);
if (!defined('JOURNEY_ATTR_MEDIUM')) define('JOURNEY_ATTR_MEDIUM', 'journey');

/** The id a journey wears inside campaign_attributions. */
function journey_attr_campaign_id(int $journeyId): int {
    return $journeyId > 0 ? JOURNEY_ATTR_OFFSET + $journeyId : 0;
}

/**
 * The three parameters the dashboard turns into the attribution cookie — the same
 * three campaigns/track-click.php appends, so attribution.js needs no change and
 * cannot tell the difference.
 */
function journey_attr_query(int $journeyId, int $windowDays): string {
    return 'campaign_id=' . journey_attr_campaign_id($journeyId)
         . '&medium=' . JOURNEY_ATTR_MEDIUM
         . '&attr_window=' . max(1, min(90, $windowDays));
}

/** Journeys size their window in hours; the cookie and the ledger speak days. */
function journey_attr_window_days(int $goalWindowHours): int {
    return max(1, min(90, (int)ceil(($goalWindowHours ?: 72) / 24)));
}

/* ════════════════════════════════════════════════════════════════════════════
   Email — SendGrid / Elastic Email
   ═══════════════════════════════════════════════════════════════════════════ */

/**
 * @param string $rid   our 32-hex tracking id, echoed back by the provider
 * @param string $type  provider event name, already lower-cased
 * @param array  $evt   the raw event, stored on failures so the reason survives
 */
function journey_webhook_email_event(string $rid, string $type, array $evt = []): bool {
    global $conn;
    if (!preg_match('/^[a-f0-9]{32}$/', $rid)) return false;

    $esc = $conn->real_escape_string($rid);
    $r = $conn->query("SELECT id, journey_id, status FROM journey_messages
                        WHERE rid = '$esc' AND channel = 'email' LIMIT 1");
    $msg = $r ? $r->fetch_assoc() : null;
    if (!$msg) return false;

    $id = (int)$msg['id'];

    switch ($type) {
        case 'delivered':
            // The ONLY provider-confirmed delivery signal. The worker deliberately does
            // not assume sent == delivered, which is why this callback matters.
            $conn->query("UPDATE journey_messages SET delivered_at = COALESCE(delivered_at, NOW()) WHERE id = $id");
            return true;

        case 'open':
        case 'click':
            // Already counted first-party by track-open.php / track-click.php, which are
            // more reliable here because they also feed click-based conversion
            // attribution. Claim the event so it is not logged as unmatched.
            return true;

        case 'bounce':
        case 'dropped':
        case 'blocked':
            $reason = $evt['reason'] ?? ($evt['response'] ?? 'Bounced');
            $conn->query("UPDATE journey_messages
                             SET status = 'failed',
                                 error_message = '" . $conn->real_escape_string(mb_substr((string)$reason, 0, 480)) . "'
                           WHERE id = $id");
            return true;

        case 'spamreport':
        case 'unsubscribe':
            /*
             * Both mean "stop mailing this person". The address goes on the shared
             * blocklist, which the dispatcher already checks before every email — so a
             * complaint in a campaign protects journeys and vice versa. Doing this in
             * only one of the two systems is how you keep mailing someone who asked you
             * to stop.
             */
            journey_webhook_blocklist_from_message($id, $type === 'spamreport'
                ? 'Marked as spam via a journey email' : 'Unsubscribed from a journey email');
            return true;
    }
    return false;
}

function journey_webhook_blocklist_from_message(int $messageId, string $note): void {
    global $conn;
    $r = $conn->query("SELECT to_addr FROM journey_messages WHERE id = " . (int)$messageId . " LIMIT 1");
    $row = $r ? $r->fetch_assoc() : null;
    $email = trim((string)($row['to_addr'] ?? ''));
    if ($email === '' || !function_exists('lists_get_or_create_blocklist_id') || !function_exists('contact_upsert')) return;
    contact_upsert(['email' => $email], lists_get_or_create_blocklist_id(), $note);
}

/* ════════════════════════════════════════════════════════════════════════════
   WhatsApp — Meta Cloud API / Netcore
   ═══════════════════════════════════════════════════════════════════════════ */

/**
 * @param string $mapped normalised status: sent|delivered|read|failed
 * @param ?string $wamid provider message id (Meta route echoes it back)
 * @param ?string $rid   our tracking id, when the provider echoes it
 * @param ?string $phone normalised recipient number, for the Netcore route
 */
function journey_webhook_wa_event(string $mapped, ?string $wamid, ?string $rid, ?string $phone,
                                  ?string $reason = null, ?string $code = null): bool {
    global $conn;

    $msg = null;

    // Fast path: the provider gave us something that identifies the send directly.
    $where = [];
    if ($wamid) $where[] = "provider_message_id = '" . $conn->real_escape_string($wamid) . "'";
    if ($rid && preg_match('/^[a-f0-9]{32}$/', $rid)) $where[] = "rid = '" . $conn->real_escape_string($rid) . "'";
    if ($where) {
        $r = $conn->query("SELECT id, journey_id, status FROM journey_messages
                            WHERE channel = 'whatsapp' AND (" . implode(' OR ', $where) . ") LIMIT 1");
        $msg = $r ? $r->fetch_assoc() : null;
    }

    /*
     * PHONE FALLBACK — the same problem the campaign webhook solves the same way.
     *
     * On the Netcore route we share no identifier with the provider: its send response
     * carries a per-request uuid, its webhooks carry Meta wamids, and it does not echo
     * our header back. The recipient's number is the only value present on both sides.
     *
     * Scoped so it can only credit the right row: this feature's messages only, actually
     * sent, within 7 days, newest first. On the first match the wamid is written onto the
     * row so every later status for that message (delivered, then read) takes the fast
     * path above instead.
     */
    if (!$msg && $phone) {
        $p = $conn->real_escape_string($phone);
        $r = $conn->query("SELECT id, journey_id, status FROM journey_messages
                            WHERE channel = 'whatsapp' AND to_addr = '$p'
                              AND sent_at IS NOT NULL
                              AND sent_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)
                            ORDER BY sent_at DESC LIMIT 1");
        $msg = $r ? $r->fetch_assoc() : null;
        if ($msg && $wamid) {
            $conn->query("UPDATE journey_messages
                             SET provider_message_id = '" . $conn->real_escape_string($wamid) . "'
                           WHERE id = " . (int)$msg['id'] . "
                             AND (provider_message_id IS NULL OR provider_message_id = '')");
        }
    }

    if (!$msg) return false;
    $id = (int)$msg['id'];

    switch ($mapped) {
        case 'delivered':
            $conn->query("UPDATE journey_messages SET delivered_at = COALESCE(delivered_at, NOW()) WHERE id = $id");
            return true;

        case 'read':
            // WhatsApp "read" is this channel's equivalent of an email open, and the
            // report funnel reads them from the same column.
            $conn->query("UPDATE journey_messages
                             SET opened_at = COALESCE(opened_at, NOW()),
                                 delivered_at = COALESCE(delivered_at, NOW()),
                                 open_count = open_count + 1
                           WHERE id = $id");
            return true;

        case 'failed':
            $txt = trim(($code ? "$code: " : '') . (string)$reason);
            $conn->query("UPDATE journey_messages
                             SET status = 'failed',
                                 error_message = '" . $conn->real_escape_string(mb_substr($txt !== '' ? $txt : 'Failed at the provider', 0, 480)) . "'
                           WHERE id = $id");
            return true;

        case 'sent':
            $conn->query("UPDATE journey_messages SET sent_at = COALESCE(sent_at, NOW()) WHERE id = $id");
            return true;

        case 'button_click':
            // A tap on a template button. This is the WhatsApp equivalent of an email
            // click, and it is what makes last-click conversion attribution possible on
            // this channel — journey_recount_conversions() anchors on first_clicked_at.
            $conn->query("UPDATE journey_messages
                             SET first_clicked_at = COALESCE(first_clicked_at, NOW()),
                                 click_count = click_count + 1,
                                 opened_at = COALESCE(opened_at, NOW()),
                                 delivered_at = COALESCE(delivered_at, NOW())
                           WHERE id = $id");
            return true;

        case 'replied':
            // A reply proves the message arrived and was read, whatever the read receipt
            // said — WhatsApp suppresses read receipts for users who disable them.
            $conn->query("UPDATE journey_messages
                             SET delivered_at = COALESCE(delivered_at, NOW()),
                                 opened_at = COALESCE(opened_at, NOW())
                           WHERE id = $id");
            return true;
    }
    return false;
}

/**
 * When this feature last sent WhatsApp to a number, or null.
 *
 * The campaign webhook resolves Netcore receipts by phone over a 7-day window, and a
 * student who was in a WhatsApp campaign last week still has a matching row. Without
 * this, that stale campaign row claims every journey receipt for the same number —
 * which is exactly what happened: a journey's "131008 button requires a parameter"
 * rejection was written onto an old campaign recipient, and the journey message sat at
 * "sent" forever with no error.
 *
 * The webhook compares the two timestamps and gives the event to whichever actually
 * sent more recently.
 */
function journey_webhook_wa_last_sent(string $phone): ?string {
    global $conn;
    $p = $conn->real_escape_string($phone);
    $r = $conn->query("SELECT sent_at FROM journey_messages
                        WHERE channel = 'whatsapp' AND to_addr = '$p'
                          AND sent_at IS NOT NULL
                          AND sent_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)
                        ORDER BY sent_at DESC LIMIT 1");
    $row = $r ? $r->fetch_assoc() : null;
    return $row ? (string)$row['sent_at'] : null;
}

/**
 * A tap on a per-recipient tracked link — the rid names the exact message, so this is the one
 * WhatsApp click path that identifies a person WITHOUT a sign-in.
 *
 * Called from whatsapp/click.php when the landing page reports a wa_rid that belongs to no
 * campaign recipient.
 *
 * TWO things are written, and both matter:
 *
 *   the COUNT — first_clicked_at on the message, which is what Clicked totals and what
 *   conversion attribution anchors on.
 *
 *   the LOG — one wa_link_clicks row, so the tap is visible in the report immediately, carrying
 *   the phone number and user_id read from the message itself. Only the count used to be
 *   written, so a tap reported this way moved a number with nothing behind it to explain where
 *   it came from.
 *
 * The identity is taken from the MESSAGE, never from the URL. The landing page could pass a
 * phone parameter, but anything on a URL is typed by whoever is holding it; the rid is a
 * 128-bit value that exists only inside that one person's message, and the row it points at
 * already records exactly who we sent to.
 */
function journey_webhook_wa_click(string $rid): bool {
    global $conn;
    if (!preg_match('/^[a-f0-9]{32}$/', $rid)) return false;
    $esc = $conn->real_escape_string($rid);
    $r = $conn->query("SELECT id, journey_id, user_id, to_addr, first_clicked_at
                         FROM journey_messages WHERE rid = '$esc' LIMIT 1");
    $row = $r ? $r->fetch_assoc() : null;
    if (!$row) return false;

    $conn->query("UPDATE journey_messages
                     SET first_clicked_at = COALESCE(first_clicked_at, NOW()),
                         click_count = click_count + 1,
                         delivered_at = COALESCE(delivered_at, NOW()),
                         opened_at = COALESCE(opened_at, NOW())
                   WHERE id = " . (int)$row['id']);

    journey_log_wa_tap((int)$row['journey_id'], (int)$row['user_id'], (string)$row['to_addr']);
    return true;
}

/**
 * The same click, resolved by journey + phone instead of by rid.
 *
 * A fallback only. The rid names one message and is always tried first; this exists for the case
 * where the landing page has the number but the rid resolved to nothing — a message row cleaned
 * up, or a link forwarded and re-tapped after the original send was purged.
 *
 * Scoped hard so it cannot credit the wrong send: this journey only, this number only, actually
 * sent, and the most recent one. $attrCampaignId arrives in the offset form the cookie carries
 * (1000000 + journey_id), which is also what proves the caller is talking about a journey rather
 * than a campaign that happens to share the number.
 */
function journey_wa_click_by_phone(int $attrCampaignId, string $phone): bool {
    global $conn;

    $journeyId = $attrCampaignId - JOURNEY_ATTR_OFFSET;
    if ($journeyId <= 0 || $attrCampaignId <= JOURNEY_ATTR_OFFSET) return false;

    $digits = preg_replace('/\D+/', '', $phone);
    if (strlen($digits) < 10) return false;
    $esc = $conn->real_escape_string($digits);

    // Matched on the trailing digits so a stored +91… and a bare 10-digit arrival still meet.
    $r = @$conn->query("SELECT id, user_id, to_addr FROM journey_messages
                         WHERE journey_id = $journeyId
                           AND channel = 'whatsapp'
                           AND sent_at IS NOT NULL
                           AND REPLACE(REPLACE(to_addr,'+',''),' ','') LIKE '%$esc'
                         ORDER BY sent_at DESC LIMIT 1");
    $row = $r ? $r->fetch_assoc() : null;
    if (!$row) return false;

    @$conn->query("UPDATE journey_messages
                      SET first_clicked_at = COALESCE(first_clicked_at, NOW()),
                          click_count = click_count + 1,
                          delivered_at = COALESCE(delivered_at, NOW()),
                          opened_at = COALESCE(opened_at, NOW())
                    WHERE id = " . (int)$row['id']);

    journey_log_wa_tap($journeyId, (int)$row['user_id'], (string)$row['to_addr']);
    return true;
}

/**
 * One row per tap in the shared WhatsApp click log, so a journey tap appears in the report
 * beside the campaign ones instead of only as a number that moved.
 *
 * identity_key is the phone, which is the identity the reports deduplicate on — two logins from
 * two devices on one number stay one person. That is a real identity, unlike the per-browser
 * visitor key a static link has to fall back on, and it is why a per-recipient link can report
 * "one person tapped four times" where a static one can only say "four taps happened".
 *
 * Fails soft: wa_link_clicks belongs to the WhatsApp feature, and a journey that cannot write
 * its log line must still record the click itself.
 */
function journey_log_wa_tap(int $journeyId, int $userId, string $phone): void {
    global $conn;
    if ($journeyId <= 0) return;

    $phoneE = $conn->real_escape_string($phone);
    // The link this journey is bound to, when it has one. A per-recipient link carries no link
    // id at all, so 0 is the honest answer rather than a number invented to fill the column.
    $linkId = 0;
    $lr = @$conn->query("SELECT id FROM wa_links WHERE journey_id = $journeyId ORDER BY id DESC LIMIT 1");
    if ($lr && $lrow = $lr->fetch_assoc()) $linkId = (int)$lrow['id'];

    @$conn->query("INSERT INTO wa_link_clicks
                      (link_id, campaign_id, journey_id, recipient_id, visitor_key,
                       user_id, phone, email, identity_key, ip, user_agent, clicked_at)
                   VALUES ($linkId, NULL, $journeyId, NULL, NULL,
                           " . ($userId > 0 ? $userId : 'NULL') . ",
                           " . ($phone !== '' ? "'$phoneE'" : 'NULL') . ",
                           NULL,
                           '" . ($phone !== '' ? $phoneE : 'anon:' . bin2hex(random_bytes(6))) . "',
                           '" . $conn->real_escape_string(substr((string)($_SERVER['REMOTE_ADDR'] ?? ''), 0, 45)) . "',
                           '" . $conn->real_escape_string(substr((string)($_SERVER['HTTP_USER_AGENT'] ?? ''), 0, 255)) . "',
                           NOW())");
}

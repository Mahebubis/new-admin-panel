<?php
/*
 * /api/journeys/lib/JourneyEngine.php
 *
 * The execution engine. Everything else in this feature is a way of feeding it or
 * reading its output.
 *
 * One tick does six things, in this order, and the order matters:
 *
 *   1. lifecycle    scheduled → ongoing when start_at arrives; ongoing → completed
 *                   when end_at passes. NOTE a completed journey still drains:
 *                   students already sitting in a wait finish their steps. Ending a
 *                   journey stops new entries, it does not empty it.
 *   2. entries      poll each live trigger and create journey_entries rows
 *   3. waits        wake every due delay; resolve every wait-for-event
 *   4. steps        walk active entries until each hits a wait or an exit
 *   5. exits        journey-level exit criteria (the thing Netcore has no answer for)
 *   6. rollups      conversions, then node stats
 *
 * Each stage is wrapped so a single broken journey can only fail itself. A journey
 * that throws is stamped with last_error and left ongoing; a journey that throws on
 * consecutive ticks is not special-cased, because silently pausing someone's live
 * journey is worse than a stuck one you can see in the log.
 */

require_once __DIR__ . '/schema.php';
require_once __DIR__ . '/JourneyGraph.php';
require_once __DIR__ . '/JourneyConditions.php';
require_once __DIR__ . '/ContactActivity.php';
require_once __DIR__ . '/JourneyEngagement.php';
require_once __DIR__ . '/JourneyDispatch.php';
require_once __DIR__ . '/JourneyWebhookSink.php';
/*
 * Required HERE, at file scope, and deliberately not inside the function that uses it.
 * ConversionTracker.php defines $LIVE_ATTRIBUTED_EVENTS as a top-level variable, and a
 * require_once executed inside a function body would land that array in the FUNCTION's local
 * scope instead of the global one — so `global $LIVE_ATTRIBUTED_EVENTS` would then see nothing
 * and every goal would silently fall back to the loose window rule.
 */
require_once __DIR__ . '/../../campaigns/lib/ConversionTracker.php';

if (!defined('JOURNEY_WORKER_LOG')) define('JOURNEY_WORKER_LOG', __DIR__ . '/../worker.log');
/** Nodes walked for one entry in one tick before we yield. Guards runaway loops. */
if (!defined('JOURNEY_MAX_STEPS_PER_TICK')) define('JOURNEY_MAX_STEPS_PER_TICK', 40);
/** Entries advanced per journey per tick. */
if (!defined('JOURNEY_ENTRY_BATCH')) define('JOURNEY_ENTRY_BATCH', 300);
/** New entries created per trigger per tick — back-pressure against a 3.3M-row segment. */
if (!defined('JOURNEY_ENTRY_CREATE_LIMIT')) define('JOURNEY_ENTRY_CREATE_LIMIT', 1000);
/** Attempts at one message step before the student takes the Failed branch. Three,
 *  spaced 5 / 20 / 60 minutes apart, covers every outage short of an hour and a half. */
if (!defined('JOURNEY_MAX_SEND_ATTEMPTS')) define('JOURNEY_MAX_SEND_ATTEMPTS', 3);

function journey_log(string $msg): void {
    $line = '[' . date('Y-m-d H:i:s') . '] ' . $msg . PHP_EOL;
    @file_put_contents(JOURNEY_WORKER_LOG, $line, FILE_APPEND | LOCK_EX);
}

function journey_log_rotate(): void {
    if (!file_exists(JOURNEY_WORKER_LOG)) return;
    if (filesize(JOURNEY_WORKER_LOG) < 8 * 1024 * 1024) return;
    @rename(JOURNEY_WORKER_LOG, JOURNEY_WORKER_LOG . '.1');
}

/* ════════════════════════════════════════════════════════════════════════════
   THE TICK
   ═══════════════════════════════════════════════════════════════════════════ */

function journey_tick(?int $onlyJourneyId = null): array {
    global $conn;
    journeys_ensure_schema();
    journey_log_rotate();

    $stats = ['journeys' => 0, 'entered' => 0, 'woken' => 0, 'stepped' => 0, 'sent' => 0, 'errors' => 0];

    journey_lifecycle_sweep();

    /*
     * Re-evaluate quiet-hours holds against the CURRENT schedule before anything else runs.
     *
     * Two things depend on this happening every tick rather than only when somebody presses
     * Save. A window that has simply ended releases its people within the minute, without a
     * cron of its own. And a schedule edited while the panel was closed — or by another
     * admin — takes effect on the next tick instead of at whatever wake_at was stamped when
     * the hold was created. Cheap: it touches only rows tagged dnd_hold, of which there are
     * none at all outside a quiet window.
     */
    journey_dnd_release_holds($onlyJourneyId);
    journey_contact_updates_prune();

    $where = "status = 'ongoing'";
    if ($onlyJourneyId) $where = 'id = ' . (int)$onlyJourneyId;
    $res = $conn->query("SELECT * FROM journeys WHERE $where ORDER BY id");
    $journeys = [];
    while ($res && $row = $res->fetch_assoc()) $journeys[] = $row;

    if (!$journeys) {
        journey_log('tick: no live journeys');
        return $stats;
    }

    foreach ($journeys as $j) {
        $stats['journeys']++;
        $jid = (int)$j['id'];
        try {
            $graph = journey_graph_for_execution($j);
            if (!$graph) {
                journey_mark_error($jid, 'Journey has no usable graph — nothing to execute.');
                continue;
            }

            journey_retry_errored($jid);
            $stats['entered'] += journey_evaluate_entries($j, $graph);
            $stats['woken']   += journey_resolve_waits($j, $graph);
            $stats['stepped'] += journey_advance_entries($j, $graph);
            journey_apply_exit_criteria($j);

            // A journey that ran without throwing can still have admitted nobody
            // because its trigger is misconfigured. Surface that rather than clearing.
            $notes = journey_note_problem();
            $note  = $notes[$jid] ?? null;
            if ($note !== null) $stats['errors']++;
            $noteSql = $note === null ? 'NULL' : "'" . $conn->real_escape_string(mb_substr($note, 0, 990)) . "'";
            @$conn->query("UPDATE journeys SET last_worker_at = NOW(), last_error = $noteSql WHERE id = $jid");
            journey_note_problem($jid, null);
        } catch (Throwable $e) {
            $stats['errors']++;
            journey_log("journey #$jid \"{$j['name']}\": ERROR " . $e->getMessage());
            journey_mark_error($jid, $e->getMessage());
        }
    }

    foreach ($journeys as $j) {
        try {
            journey_backfill_clicks_from_ledger((int)$j['id']);
            journey_recount_conversions((int)$j['id']);
            journey_rollup_node_stats((int)$j['id']);
        }
        catch (Throwable $e) { journey_log("rollup #{$j['id']}: " . $e->getMessage()); }
    }

    journey_log(sprintf('tick done: %d journeys, %d entered, %d woken, %d stepped, %d errors',
        $stats['journeys'], $stats['entered'], $stats['woken'], $stats['stepped'], $stats['errors']));
    return $stats;
}

/*
 * Non-fatal problems found while running one journey — a trigger whose audience
 * query failed, an unknown event key, a segment that has been deleted.
 *
 * These used to go to the log file and nowhere else, which meant the tick could
 * report "0 errors" while the journey silently admitted nobody. Anything noted here
 * lands on journeys.last_error, so it shows up in the panel and in action=health
 * without anyone needing shell access to read worker.log.
 */
function journey_note_problem(?int $journeyId = null, ?string $msg = null): array {
    static $notes = [];
    if ($journeyId === null) return $notes;
    if ($msg === null) { unset($notes[$journeyId]); return $notes; }
    $notes[$journeyId] = $msg;
    journey_log("journey #$journeyId: $msg");
    return $notes;
}

function journey_mark_error(int $journeyId, string $msg): void {
    global $conn;
    @$conn->query("UPDATE journeys SET last_error = '" . $conn->real_escape_string(mb_substr($msg, 0, 990)) . "',
                         last_worker_at = NOW() WHERE id = " . (int)$journeyId);
}

/**
 * Deployed journeys execute their PINNED version, never the live draft. This is
 * what makes editing a running journey safe: your edit becomes version N+1 on the
 * next deploy and only new entrants see it.
 */
function journey_graph_for_execution(array $j): ?array {
    global $conn;
    // Cached per journey+version: this is called once per candidate entry, and a DB
    // round trip per student to fetch a graph that cannot change mid-tick is the
    // easiest accidental way to make a large segment poll take minutes.
    static $cache = [];
    $ck = $j['id'] . ':' . ($j['current_version_id'] ?? '0');
    if (isset($cache[$ck])) return $cache[$ck];

    $raw = $j['graph'];
    if (!empty($j['current_version_id'])) {
        $r = $conn->query("SELECT graph FROM journey_versions WHERE id = " . (int)$j['current_version_id'] . " LIMIT 1");
        $row = $r ? $r->fetch_assoc() : null;
        if ($row) $raw = $row['graph'];
    }
    $g = journey_graph_parse($raw);
    $cache[$ck] = $g['nodes'] ? $g : null;
    return $cache[$ck];
}

/* ════════════════════════════════════════════════════════════════════════════
   1. Lifecycle
   ═══════════════════════════════════════════════════════════════════════════ */

/**
 * Give students who died on an engine error another go.
 *
 * An 'errored' entry is never selected again by the step executor, so a bug that
 * throws once leaves that student stranded forever — and the only way back was a
 * hand-written UPDATE after the fix shipped. That is the wrong failure mode for
 * something running unattended: the fix goes out, and the people it was meant to
 * rescue stay stuck.
 *
 * Bounded on both sides so a PERMANENT error cannot become an infinite loop:
 *   - at most 3 retries per entry, counted on the row itself
 *   - never sooner than 5 minutes after the failure, so a retry lands on new code
 *     rather than hammering the same broken tick
 */
function journey_retry_errored(int $journeyId): void {
    global $conn;
    @$conn->query("UPDATE journey_entries
                      SET status = 'active', last_error = NULL, error_retries = error_retries + 1
                    WHERE journey_id = " . (int)$journeyId . "
                      AND status = 'errored'
                      AND error_retries < 3
                      AND updated_at <= DATE_SUB(NOW(), INTERVAL 5 MINUTE)");
    $n = $conn->affected_rows;
    if ($n > 0) journey_log("journey #$journeyId: retrying $n entr" . ($n === 1 ? 'y' : 'ies') . " that errored earlier.");
}

function journey_lifecycle_sweep(): void {
    global $conn;
    @$conn->query("UPDATE journeys SET status = 'ongoing', deployed_at = COALESCE(deployed_at, NOW())
                    WHERE status = 'scheduled' AND start_at IS NOT NULL AND start_at <= NOW()");
    // 'completed' stops NEW entries. Existing entries keep draining — documented
    // behaviour, and the reason a journey can still send after its end date.
    @$conn->query("UPDATE journeys SET status = 'completed', completed_at = NOW()
                    WHERE status = 'ongoing' AND end_type = 'date' AND end_at IS NOT NULL AND end_at <= NOW()");
}

/* ════════════════════════════════════════════════════════════════════════════
   2. Entry evaluation
   ═══════════════════════════════════════════════════════════════════════════ */

function journey_evaluate_entries(array $j, array $graph): int {
    $trigger = journey_trigger_node($graph);
    if (!$trigger) return 0;

    switch ($trigger['key']) {
        case 'trg_activity': return journey_entries_from_activity($j, $trigger);
        case 'trg_segment':  return journey_entries_from_audience($j, $trigger, 'segment');
        case 'trg_list':     return journey_entries_from_audience($j, $trigger, 'list');
        case 'trg_business': return journey_entries_from_business($j, $trigger);
    }
    return 0;
}

/** Cursor read/write. last_seen_at is exclusive on read, so no row is seen twice. */
function journey_cursor(int $journeyId, string $key): array {
    global $conn;
    $k = $conn->real_escape_string($key);
    $r = $conn->query("SELECT * FROM journey_event_cursors
                        WHERE journey_id = " . (int)$journeyId . " AND source_key = '$k' LIMIT 1");
    $row = $r ? $r->fetch_assoc() : null;
    if ($row) return $row;
    @$conn->query("INSERT IGNORE INTO journey_event_cursors (journey_id, source_key, last_seen_at, last_run_at)
                   VALUES (" . (int)$journeyId . ", '$k', NULL, NULL)");
    return ['journey_id' => $journeyId, 'source_key' => $key, 'last_seen_at' => null, 'last_run_at' => null, 'rows_seen' => 0];
}

function journey_cursor_save(int $journeyId, string $key, ?string $lastSeenAt, int $rows = 0): void {
    global $conn;
    $k = $conn->real_escape_string($key);
    $v = $lastSeenAt === null ? 'NULL' : "'" . $conn->real_escape_string($lastSeenAt) . "'";
    @$conn->query("UPDATE journey_event_cursors
                      SET last_seen_at = $v, last_run_at = NOW(), rows_seen = rows_seen + " . (int)$rows . "
                    WHERE journey_id = " . (int)$journeyId . " AND source_key = '$k'");
}

/**
 * Activity trigger — the watermark poller.
 *
 * The first tick after deploy does NOT sweep history: the cursor starts at the
 * deploy time, so publishing a journey with a `register` trigger cannot mail every
 * user who ever registered. That single line is the difference between a working
 * launch and an incident.
 */
function journey_entries_from_activity(array $j, array $node): int {
    global $conn;
    $cfg  = $node['cfg'] ?? [];
    $type = (string)($cfg['type'] ?? 'App / web activity');

    /*
     * Contact activity — added to the contact master, added to a list, or updated.
     * Polled by its own function below, because its sources are the contact tables rather
     * than $EVENT_SOURCE or the channel event stores, and because two of its three options
     * need a scope (which list, which attribute) baked into the cursor key.
     */
    if ($type === 'Contact activity') return journey_entries_from_contact_activity($j, $node);

    /*
     * Engagement triggers — "opened the email", "read the WhatsApp", "tapped the button".
     *
     * Same watermark machinery as an app event, only the source differs: instead of one of the
     * ~20 domain tables in $EVENT_SOURCE, the rows come from the channel event stores via
     * JourneyEngagement.php. The cursor key includes the scope so two engagement triggers in the
     * same journey (opened campaign A / opened campaign B) keep separate watermarks — sharing one
     * would let whichever ticked first swallow the other's rows.
     */
    if ($type !== 'App / web activity') {
        $status = (string)($cfg['status'] ?? '');
        $spec = journey_engagement_spec($type, $status);
        if (!$spec) {
            journey_note_problem((int)$j['id'], journey_engagement_unsupported_reason($type, $status));
            return 0;
        }

        $scope = journey_engagement_scope_from_cfg($cfg);

        // A scope pointing at a campaign that does not exist on this channel can never match.
        // Said once per tick rather than left as a permanent, unexplained zero.
        $scopeProblem = journey_engagement_scope_problem($spec, $scope);
        if ($scopeProblem !== null) { journey_note_problem((int)$j['id'], $scopeProblem); return 0; }

        $key   = journey_engagement_cursor_key($spec, $status, $scope);

        $cur = journey_cursor((int)$j['id'], $key);

        /*
         * Where a BRAND-NEW cursor starts reading from.
         *
         * deployed_at is right for the very first tick after publishing: the worker runs each
         * minute, so it covers the gap between publish and first tick, and a worker that was down
         * for an hour still picks up what it missed.
         *
         * It is badly wrong in one case, and that case is easy to hit. The cursor key encodes the
         * trigger's scope, so EDITING the trigger — pointing it at a different campaign, or
         * switching between Any message / Campaign / Journey — produces a different key and
         * therefore a brand-new cursor. Falling back to deployed_at then means the edited trigger
         * re-reads every matching event since the journey was first published, and re-enrols
         * people on engagement that is days old and was never theirs to react to. From the
         * outside that looks exactly like the journey firing at random.
         *
         * last_worker_at is the fix: once the engine has ticked this journey, everything before
         * that tick is already in the past as far as this journey is concerned, so a trigger
         * added afterwards has no business reaching back behind it. On a first publish
         * last_worker_at is null and this is a no-op.
         */
        $base = $j['deployed_at'] ?: date('Y-m-d H:i:s');
        if (!empty($j['last_worker_at']) && strtotime((string)$j['last_worker_at']) > strtotime((string)$base)) {
            $base = (string)$j['last_worker_at'];
        }
        $since = $cur['last_seen_at'] ?: $base;
        $until = date('Y-m-d H:i:s');

        /*
         * ── The look-back, and why this node needs one ──────────────────────────────────
         *
         * Every trigger normally starts counting from the moment the journey is published:
         * publishing a journey triggered on `register` must not mail everyone who ever
         * registered. For an ENGAGEMENT trigger that rule quietly breaks the most obvious
         * way to use it.
         *
         * The natural order of work is: send a campaign → see the opens → build a journey to
         * chase the people who opened it → publish. By the time it is published, every open
         * it was built for is already in the past, so the journey enrols nobody and there is
         * nothing on screen to say why. Two identical journeys published ten minutes apart
         * will disagree about the same open purely because of when the publish happened.
         *
         * So the trigger carries its own look-back, applied only on the FIRST tick after a
         * publish (last_run_at IS NULL — the watermark then takes over and nothing is ever
         * re-read). The repeat-frequency rule still applies to every candidate, so a
         * look-back cannot double-enrol somebody who is already in.
         *
         * Default 0 — "only from now on" — because retroactively enrolling people is a
         * decision, not a default. The builder offers 1 hour / 24 hours / 7 / 30 days.
         */
        $backfillH = journey_backfill_hours($cfg['backfillHours'] ?? 0);
        if ($backfillH > 0 && empty($cur['last_run_at'])) {
            $since = date('Y-m-d H:i:s', strtotime($since) - $backfillH * 3600);
            journey_log("journey #{$j['id']}: first run of '$key' — looking back {$backfillH}h to $since");
        }

        $rows = journey_engagement_new_rows($spec, $scope, $since, $until, JOURNEY_ENTRY_CREATE_LIMIT);
        $made = 0; $lastAt = $since;
        foreach ($rows as $row) {
            $lastAt = $row['at'];
            if (journey_try_create_entry($j, (int)$row['user_id'], $key, ['at' => $row['at']], $cfg)) $made++;
        }
        $advanceTo = count($rows) >= JOURNEY_ENTRY_CREATE_LIMIT ? $lastAt : $until;
        journey_cursor_save((int)$j['id'], $key, $advanceTo, count($rows));

        if ($rows) journey_log("journey #{$j['id']}: $type / $status — " . count($rows) . " new row(s), $made entered.");
        return $made;
    }

    $eventKey = (string)($cfg['event'] ?? '');
    if ($eventKey === '' || !journey_event_source($eventKey)) {
        journey_note_problem((int)$j['id'], "Unknown event '$eventKey' — it is not in \$EVENT_SOURCE (netcore/lib/segment_sql.php), so nobody can enter.");
        return 0;
    }

    $cur   = journey_cursor((int)$j['id'], $eventKey);
    $since = $cur['last_seen_at'] ?: ($j['deployed_at'] ?: date('Y-m-d H:i:s'));
    $until = date('Y-m-d H:i:s');

    $rows = journey_event_new_rows($eventKey, $since, $until, JOURNEY_ENTRY_CREATE_LIMIT);
    $made = 0;
    $lastAt = $since;

    foreach ($rows as $row) {
        $lastAt = $row['at'];
        if (journey_try_create_entry($j, (int)$row['user_id'], $eventKey, ['at' => $row['at']], $cfg)) $made++;
    }

    // Advance to the newest row we actually read, not to $until: if the LIMIT truncated
    // the batch, the next tick must resume from there rather than skipping the remainder.
    $advanceTo = count($rows) >= JOURNEY_ENTRY_CREATE_LIMIT ? $lastAt : $until;
    journey_cursor_save((int)$j['id'], $eventKey, $advanceTo, count($rows));

    if ($rows) journey_log("journey #{$j['id']}: event '$eventKey' — " . count($rows) . " new row(s), $made entered.");
    return $made;
}

/* ════════════════════════════════════════════════════════════════════════════
   Contact activity — the third kind of Activity trigger
   ═══════════════════════════════════════════════════════════════════════════ */

/**
 * "Start when a contact is added / listed / updated."
 *
 * Same watermark machinery as an app event or an engagement event — read rows newer than
 * the cursor, create an entry per row, move the cursor — with one thing done differently
 * and deliberately: THE CURSOR KEY CARRIES THE WHOLE CONFIGURATION.
 *
 * Two journeys watching two different lists, or the same journey re-pointed from list 12
 * to list 14, must not share a watermark: whichever ticked first would swallow the other's
 * rows and the second trigger would look permanently dead. The key is therefore
 * contact:list:12 rather than contact:list, and re-pointing the trigger starts a fresh
 * cursor at the current time rather than replaying list 12's history against list 14.
 *
 * See lib/ContactActivity.php for why "updated, specific attribute" reads a ledger while
 * "updated, any attribute" reads campaign_contacts.updated_at.
 */
function journey_entries_from_contact_activity(array $j, array $node): int {
    $cfg = $node['cfg'] ?? [];
    $what = (string)($cfg['contactActivity'] ?? '');
    if ($what === '') {
        journey_note_problem((int)$j['id'], 'The Contact activity trigger has no activity chosen, so nobody can enter.');
        return 0;
    }

    $jid   = (int)$j['id'];
    $until = date('Y-m-d H:i:s');

    /*
     * Where a brand-new cursor starts. Identical reasoning to the engagement trigger:
     * deployed_at covers the gap between publishing and the first tick (and a worker that
     * was down for an hour), while last_worker_at stops an EDITED trigger — which produces
     * a new cursor key — from reaching back over everything since the journey was first
     * published and enrolling people on activity that was never theirs to react to.
     */
    $base = $j['deployed_at'] ?: $until;
    if (!empty($j['last_worker_at']) && strtotime((string)$j['last_worker_at']) > strtotime((string)$base)) {
        $base = (string)$j['last_worker_at'];
    }

    switch ($what) {
        case 'Contact is added to contact master': {
            $key   = 'contact:master';
            $cur   = journey_cursor($jid, $key);
            $since = $cur['last_seen_at'] ?: $base;
            $rows  = journey_contact_rows_added($since, $until, JOURNEY_ENTRY_CREATE_LIMIT);
            return journey_contact_enrol($j, $cfg, $key, $rows, $since, $until,
                'contact added to master');
        }

        case 'Contact is added to List': {
            $scope = (string)($cfg['contactList'] ?? 'Any List');
            $ids   = [];
            if ($scope === 'Specific List') {
                $ids = journey_resolve_list_ids([(string)($cfg['contactListRef'] ?? '')]);
                if (!$ids) {
                    journey_note_problem($jid, "The Contact activity trigger names a list ('"
                        . (string)($cfg['contactListRef'] ?? '') . "') that no longer exists, so nobody can enter.");
                    return 0;
                }
            }
            $key   = 'contact:list:' . ($ids ? implode('-', $ids) : 'any');
            $cur   = journey_cursor($jid, $key);
            $since = $cur['last_seen_at'] ?: $base;
            $rows  = journey_contact_rows_listed($ids, $since, $until, JOURNEY_ENTRY_CREATE_LIMIT);
            return journey_contact_enrol($j, $cfg, $key, $rows, $since, $until,
                'contact added to ' . ($ids ? 'list ' . implode(',', $ids) : 'any list'));
        }

        case 'Contact is updated': {
            $scope = (string)($cfg['contactAttrScope'] ?? 'Any Attribute');
            if ($scope === 'Specific attribute') {
                $attr = strtoupper(trim((string)($cfg['contactAttr'] ?? '')));
                if ($attr === '') {
                    journey_note_problem($jid, 'The Contact activity trigger is set to a specific attribute but none is chosen, so nobody can enter.');
                    return 0;
                }
                $val   = trim((string)($cfg['contactValue'] ?? ''));
                $key   = 'contact:updated:' . $attr . ($val !== '' ? ':' . md5($val) : '');
                $cur   = journey_cursor($jid, $key);
                $since = $cur['last_seen_at'] ?: $base;
                $rows  = journey_contact_rows_updated_attr($attr, $val !== '' ? $val : null,
                                                           $since, $until, JOURNEY_ENTRY_CREATE_LIMIT);
                return journey_contact_enrol($j, $cfg, $key, $rows, $since, $until,
                    "attribute $attr updated" . ($val !== '' ? " to \"$val\"" : ''));
            }

            $key   = 'contact:updated:any';
            $cur   = journey_cursor($jid, $key);
            $since = $cur['last_seen_at'] ?: $base;
            $rows  = journey_contact_rows_updated_any($since, $until, JOURNEY_ENTRY_CREATE_LIMIT);
            return journey_contact_enrol($j, $cfg, $key, $rows, $since, $until, 'contact updated');
        }
    }

    journey_note_problem($jid, "Unknown contact activity '$what' — nobody can enter.");
    return 0;
}

/**
 * The half every branch above shares: create an entry per row, then move the cursor.
 *
 * The cursor advances to the newest row actually READ when the batch was truncated by the
 * limit, and to $until otherwise — the same rule the app-event poller uses, and the reason
 * a 50,000-row import is drained over several ticks instead of having its tail skipped.
 */
function journey_contact_enrol(array $j, array $cfg, string $cursorKey, array $rows,
                               string $since, string $until, string $label): int {
    $made = 0;
    $lastAt = $since;
    foreach ($rows as $row) {
        $lastAt = $row['at'];
        if (journey_try_create_entry($j, (int)$row['user_id'], $cursorKey,
                                     ['at' => $row['at'], 'email' => $row['email'] ?? ''], $cfg)) $made++;
    }
    $advanceTo = count($rows) >= JOURNEY_ENTRY_CREATE_LIMIT ? $lastAt : $until;
    journey_cursor_save((int)$j['id'], $cursorKey, $advanceTo, count($rows));

    if ($rows) {
        journey_log("journey #{$j['id']}: $label — " . count($rows) . " row(s), $made entered.");
    }
    return $made;
}

/** Segment / list triggers — polled on the configured cadence. */
function journey_entries_from_audience(array $j, array $node, string $kind): int {
    global $conn;
    $cfg = $node['cfg'] ?? [];
    $cur = journey_cursor((int)$j['id'], $kind);

    $everySeconds = journey_freq_seconds((string)($cfg['freq'] ?? 'Every day'), $cfg);
    if ($cur['last_run_at'] && (time() - strtotime($cur['last_run_at'])) < $everySeconds) return 0;

    $onlyNew = strtolower((string)($cfg['users'] ?? 'Only new ones')) !== 'all students';

    if ($kind === 'segment') {
        $ids = journey_resolve_segment_ids([(string)($cfg['segment'] ?? '')]);
        if (!$ids) { journey_note_problem((int)$j['id'], "Segment '{$cfg['segment']}' no longer exists, so nobody can enter."); return 0; }
        $r = $conn->query("SELECT config FROM netcore_segments WHERE id = " . (int)$ids[0] . " LIMIT 1");
        $row = $r ? $r->fetch_assoc() : null;
        $sql = $row ? buildSegmentSql(json_decode($row['config'], true)) : null;
        if (!$sql) { journey_note_problem((int)$j['id'], "Segment #{$ids[0]} has no usable rules, so nobody can enter."); return 0; }
        $userSql = "SELECT DISTINCT user_id FROM ($sql) AS s WHERE user_id IS NOT NULL LIMIT " . JOURNEY_ENTRY_CREATE_LIMIT;
    } else {
        $ids = journey_resolve_list_ids([(string)($cfg['list'] ?? '')]);
        if (!$ids) { journey_note_problem((int)$j['id'], "List '{$cfg['list']}' no longer exists, so nobody can enter."); return 0; }
        $in = implode(',', array_map('intval', $ids));
        /*
         * COLLATE is required here, not cosmetic. `users` is an older table
         * (utf8mb4_general_ci) while campaign_contacts was created under
         * utf8mb4_unicode_ci, and comparing two IMPLICIT-collation columns across
         * that boundary raises MySQL error #1267 — which is exactly what this query
         * did on the first live journey. segment_sql.php hits the same wall joining
         * ninety_nine_store_orders and solves it the same way.
         *
         * The explicit collation goes on the campaign_contacts side on purpose: that
         * side is already filtered down to one list, so losing its index costs
         * nothing, while users.email keeps its index for the 3.3M-row lookup.
         */
        /*
         * ONE student per email address, not per matching user row.
         *
         * `users` can hold more than one account for the same address, and the join is
         * on email — so DISTINCT u.user_id turned a 3-contact list into 4 students and
         * messaged the same person twice. GROUP BY the address and keep the oldest
         * account: deterministic, so a re-poll always resolves to the same student
         * rather than alternating between duplicates.
         */
        $userSql = "SELECT MIN(u.user_id) AS user_id
                      FROM campaign_list_members m
                      INNER JOIN campaign_contacts c ON c.id = m.contact_id
                      INNER JOIN users u ON u.email = c.email COLLATE utf8mb4_general_ci
                     WHERE m.list_id IN ($in) AND u.user_id IS NOT NULL
                     GROUP BY u.email
                     LIMIT " . JOURNEY_ENTRY_CREATE_LIMIT;
    }

    $q = @$conn->query($userSql);
    if ($q === false) { journey_note_problem((int)$j['id'], 'Audience query failed — ' . $conn->error); return 0; }

    $made = 0;
    while ($row = $q->fetch_assoc()) {
        $uid = (int)$row['user_id'];
        if ($onlyNew && journey_has_ever_entered((int)$j['id'], $uid)) continue;
        if (journey_try_create_entry($j, $uid, $kind, [], $cfg)) $made++;
    }
    journey_cursor_save((int)$j['id'], $kind, null, $made);
    journey_log("journey #{$j['id']}: $kind poll — $made entered.");
    return $made;
}

function journey_freq_seconds(string $freq, array $cfg): int {
    switch ($freq) {
        case 'Every hour':    return 3600;
        case 'Every week':    return 7 * 86400;
        case 'Every 2 weeks': return 14 * 86400;
        case 'Every month':   return 30 * 86400;
        case 'Every 2 months':return 60 * 86400;
        case 'Once every specific duration':
            $n = max(1, (int)($cfg['famount'] ?? 1));
            $u = (string)($cfg['funit'] ?? 'days');
            $mult = $u === 'months' ? 30 * 86400 : ($u === 'weeks' ? 7 * 86400 : 86400);
            return $n * $mult;
        case 'Every day':
        default:              return 86400;
    }
}

/**
 * Business events. The event comes from your scheduler ("batch_starts_tomorrow"),
 * the audience comes from the students' own data — context mapping joins the two:
 * cfg.map = [{a: 'batch_code', op: 'Is', v: 'BATCH_CODE'}] reads "the event's
 * batch_code equals the student's BATCH_CODE attribute".
 */
function journey_entries_from_business(array $j, array $node): int {
    global $conn;
    $cfg  = $node['cfg'] ?? [];
    $name = (string)($cfg['event'] ?? '');
    if ($name === '') return 0;

    $cur   = journey_cursor((int)$j['id'], 'business:' . $name);
    $since = $cur['last_seen_at'] ?: ($j['deployed_at'] ?: date('Y-m-d H:i:s'));
    $esc   = $conn->real_escape_string($name);
    $sq    = $conn->real_escape_string($since);

    $q = @$conn->query("SELECT * FROM journey_business_events
                         WHERE event_name = '$esc' AND occurred_at > '$sq'
                         ORDER BY occurred_at ASC LIMIT 200");
    if ($q === false) return 0;

    $made = 0; $lastAt = $since;
    while ($ev = $q->fetch_assoc()) {
        $lastAt  = $ev['occurred_at'];
        $payload = json_decode((string)$ev['payload'], true) ?: [];

        foreach (journey_business_audience($cfg, $payload) as $uid) {
            if (journey_try_create_entry($j, (int)$uid, $name, $payload, $cfg)) $made++;
        }
    }
    journey_cursor_save((int)$j['id'], 'business:' . $name, $lastAt, $made);
    if ($made) journey_log("journey #{$j['id']}: business event '$name' — $made entered.");
    return $made;
}

/** Resolves context mapping into a bounded list of user ids. */
function journey_business_audience(array $cfg, array $payload): array {
    global $conn;
    $map = (array)($cfg['map'] ?? []);
    if (!$map) return [];

    $wheres = [];
    foreach ($map as $rule) {
        $payloadKey = trim((string)($rule['a'] ?? ''));      // key on the business event
        $attrName   = trim((string)($rule['v'] ?? ''));      // student attribute to match
        if ($payloadKey === '' || $attrName === '') continue;
        if (!array_key_exists($payloadKey, $payload)) return [];   // event lacks the key → no audience

        $val = $conn->real_escape_string((string)$payload[$payloadKey]);
        $col = preg_replace('/[^A-Za-z0-9_]/', '', $attrName);
        if ($col === '') continue;
        // Match against a users column when one exists, else the attribute store.
        if (journey_users_has_column($col)) $wheres[] = "u.`$col` = '$val'";
        else                                $wheres[] = "ad.`$col` = '$val'";
    }
    if (!$wheres) return [];

    // Same collation boundary as the list join above — campaign_attribute_data is
    // utf8mb4_unicode_ci, users is utf8mb4_general_ci.
    // DISTINCT for the same reason as the list query: campaign_attribute_data can hold
    // more than one row per address, and the join would otherwise return a student once
    // per matching row and message them that many times.
    $sql = "SELECT DISTINCT u.user_id FROM users u
              LEFT JOIN campaign_attribute_data ad ON ad.email COLLATE utf8mb4_general_ci = u.email
             WHERE " . implode(' AND ', $wheres) . "
             LIMIT " . JOURNEY_ENTRY_CREATE_LIMIT;
    $q = @$conn->query($sql);
    if ($q === false) { journey_log('business audience query failed: ' . $conn->error); return []; }

    $out = [];
    while ($row = $q->fetch_assoc()) $out[] = (int)$row['user_id'];
    return $out;
}

function journey_users_has_column(string $col): bool {
    global $conn;
    static $cols = null;
    if ($cols === null) {
        $cols = [];
        $r = $conn->query("SHOW COLUMNS FROM users");
        while ($r && $row = $r->fetch_assoc()) $cols[strtolower($row['Field'])] = true;
    }
    return isset($cols[strtolower($col)]);
}

function journey_has_ever_entered(int $journeyId, int $userId): bool {
    global $conn;
    $r = $conn->query("SELECT 1 FROM journey_entries
                        WHERE journey_id = " . (int)$journeyId . " AND user_id = " . (int)$userId . " LIMIT 1");
    return $r && $r->num_rows > 0;
}

/**
 * The gatekeeper: repeat frequency, "skip if already inside", and the debounce all
 * decide here. Returns true only if a row was actually created.
 */
function journey_try_create_entry(array $j, int $userId, string $triggerKey, array $payload, array $cfg): bool {
    global $conn;
    if ($userId <= 0) return false;
    $jid = (int)$j['id'];

    /* "Skip the student if they are already inside this journey" — Netcore defines
       "inside" precisely as sitting at a wait or a delay, so this is a live state
       query, not a historical flag. */
    if (!empty($cfg['skip'])) {
        $r = $conn->query("SELECT 1 FROM journey_entries
                            WHERE journey_id = $jid AND user_id = $userId
                              AND status IN ('active','waiting') LIMIT 1");
        if ($r && $r->num_rows > 0) return false;
    }

    /* Repeat frequency. Rolling windows, not calendar ones: "every week" from a
       Wednesday means next Wednesday.

       'First time this happens' and 'Skip user if already in journey' are listed here as
       well as under their event-worded spellings, because the same dropdown serves an app
       event, an engagement event and a contact activity, and "First time this event
       happens" is the wrong sentence for "Contact is added to List". An unrecognised value
       used to fall straight through this switch and enforce nothing at all — so a trigger
       set to skip users already in the journey enrolled them anyway, every single tick. */
    $repeat = (string)($cfg['repeat'] ?? 'Every time this event happens');
    $windowSec = null;
    switch ($repeat) {
        case 'First time this event happens':
        case 'First time this happens':
            if (journey_has_ever_entered($jid, $userId)) return false;
            break;

        /* Netcore lists this as a frequency, and it means the same thing as the checkbox
           below it: someone sitting at a wait or a delay is "in the journey" and is not
           admitted a second time. Honoured whichever way it was set. */
        case 'Skip user if already in the journey':
        case 'Skip user if already in journey': {
            $r = $conn->query("SELECT 1 FROM journey_entries
                                WHERE journey_id = $jid AND user_id = $userId
                                  AND status IN ('active','waiting') LIMIT 1");
            if ($r && $r->num_rows > 0) return false;
            break;
        }

        case 'Every day':   $windowSec = 86400; break;
        case 'Every week':  $windowSec = 7 * 86400; break;
        case 'Every month': $windowSec = 30 * 86400; break;
        case 'Once every specific duration':
        case 'Once every (specific duration)':
            $n = max(1, (int)($cfg['ramount'] ?? 5));
            $u = (string)($cfg['runit'] ?? 'days');
            // Netcore's documented caps: 90 days / 5 weeks / 5 months.
            if ($u === 'weeks')  { $n = min($n, 5);  $windowSec = $n * 7 * 86400; }
            elseif ($u === 'months') { $n = min($n, 5); $windowSec = $n * 30 * 86400; }
            else { $n = min($n, 90); $windowSec = $n * 86400; }
            break;

        case 'Every time this event happens':
        case 'Every time this happens':
            break;   // no restriction, and named so an unknown value below is a real warning

        default:
            journey_log("journey #$jid: unknown repeat frequency \"$repeat\" — treated as "
                . '"every time". Re-pick the frequency on the trigger.');
    }
    if ($windowSec !== null) {
        $r = $conn->query("SELECT 1 FROM journey_entries
                            WHERE journey_id = $jid AND user_id = $userId
                              AND entered_at > DATE_SUB(NOW(), INTERVAL " . (int)$windowSec . " SECOND) LIMIT 1");
        if ($r && $r->num_rows > 0) return false;
    }

    /* Re-entrance debounce (Adobe's 5-minute default). Cheap insurance against a
       misbehaving client firing the same event twice in two seconds. */
    $deb = (int)($j['entry_debounce_seconds'] ?? 300);
    if ($deb > 0) {
        $r = $conn->query("SELECT 1 FROM journey_entries
                            WHERE journey_id = $jid AND user_id = $userId
                              AND entered_at > DATE_SUB(NOW(), INTERVAL $deb SECOND) LIMIT 1");
        if ($r && $r->num_rows > 0) return false;
    }

    /* Snapshot the contact. Merge tags must render what the message was
       personalised for, not what the profile drifted to during a 30-day wait. */
    // Column names match campaigns/lib/AudienceResolver.php: fname / lname / phone.
    $u = $conn->query("SELECT user_id, email, phone, fname, lname FROM users WHERE user_id = $userId LIMIT 1");
    $urow = $u ? $u->fetch_assoc() : null;
    if (!$urow) {
        // Fall back to a bare row so the entry still exists and the trace explains it,
        // rather than the student vanishing with no record of why.
        $urow = ['email' => null, 'phone' => null, 'fname' => null, 'lname' => null];
    }

    /*
     * THE LIST'S OWN PHONE WINS over the account's.
     *
     * A list is matched to a student by EMAIL, so the address agrees while the phone numbers
     * need not: `users` often holds an older number than the one just imported. Reading only
     * users.phone meant an admin who uploaded a list of numbers watched the journey message
     * completely different ones — undeliverable in the best case, a stranger in the worst.
     *
     * campaigns/lib/AudienceResolver.php has always resolved a list audience as
     * COALESCE(c.phone, u.phone); this makes journeys agree, so the same list reaches the same
     * numbers whether it is sent by a campaign or walked by a journey.
     *
     * Scoped to the lists THIS trigger names, not to campaign_contacts at large: the same
     * address can sit in several lists with different numbers, and only the selected one was
     * chosen by the admin. Applies to list triggers only — a segment or an activity event has no
     * contact row behind it, and users.phone is then the sole source there is.
     */
    if ($triggerKey === 'list') {
        $listIds = journey_resolve_list_ids([(string)($cfg['list'] ?? '')]);
        if ($listIds) {
            $in = implode(',', array_map('intval', $listIds));
            $cr = @$conn->query(
                "SELECT c.phone, c.first_name, c.last_name
                   FROM campaign_contacts c
                   INNER JOIN campaign_list_members m ON m.contact_id = c.id
                  WHERE m.list_id IN ($in)
                    AND c.email = '" . $conn->real_escape_string((string)($urow['email'] ?? '')) . "'
                  LIMIT 1");
            if ($cr && $crow = $cr->fetch_assoc()) {
                if (trim((string)($crow['phone'] ?? '')) !== '')      $urow['phone'] = $crow['phone'];
                if (trim((string)($crow['first_name'] ?? '')) !== '') $urow['fname'] = $crow['first_name'];
                if (trim((string)($crow['last_name'] ?? '')) !== '')  $urow['lname'] = $crow['last_name'];
            }
        }
    }

    $graph   = journey_graph_for_execution($j);
    $trigger = $graph ? journey_trigger_node($graph) : null;
    $first   = $trigger ? journey_first_node_after($graph, $trigger) : null;
    if (!$first) return false;

    $isControl = journey_pick_control($j, $userId, (string)($urow['email'] ?? '')) ? 1 : 0;

    $stmt = $conn->prepare(
        "INSERT INTO journey_entries
          (journey_id, version_id, user_id, email, phone, first_name, last_name,
           status, current_node, is_control, trigger_event, trigger_payload)
         VALUES (?,?,?,?,?,?,?, 'active', ?, ?, ?, ?)"
    );
    if (!$stmt) return false;
    $vid = $j['current_version_id'] !== null ? (int)$j['current_version_id'] : null;
    $em = $urow['email']; $ph = $urow['phone']; $fn = $urow['fname']; $ln = $urow['lname'];
    $nodeId = $first['id']; $pl = json_encode($payload);
    $stmt->bind_param('iiissssssss', $jid, $vid, $userId, $em, $ph, $fn, $ln, $nodeId, $isControl, $triggerKey, $pl);
    $ok = @$stmt->execute();
    $stmt->close();

    if ($ok) @$conn->query("UPDATE journeys SET entered_count = entered_count + 1 WHERE id = $jid");
    return (bool)$ok;
}

/** The node the trigger's single outgoing connector leads to (honouring its wait). */
function journey_first_node_after(array $graph, array $trigger): ?array {
    $edges = journey_out_edges($graph, $trigger['id'], 'Yes');
    if (!$edges) $edges = journey_out_edges($graph, $trigger['id']);
    if (!$edges) return null;
    return $graph['nodes'][$edges[0]['to']] ?? null;
}

/**
 * Control group. Percentage mode uses the same stable hash as splits, so a given
 * student is consistently in or out rather than re-diced on every entry.
 */
function journey_pick_control(array $j, int $userId, string $email): bool {
    $mode = (string)($j['control_mode'] ?? 'none');
    if ($mode === 'percent') {
        $pct = (int)$j['control_pct'];
        if ($pct <= 0) return false;
        if ($pct >= 100) return true;
        return (hexdec(substr(md5('ctrl:' . $j['id'] . ':' . $userId), 0, 8)) % 100) < $pct;
    }
    if ($mode === 'list') {
        static $sets = [];
        $jid = (int)$j['id'];
        if (!isset($sets[$jid])) {
            $sets[$jid] = [];
            foreach (preg_split('/[\s,;]+/', (string)$j['control_list']) ?: [] as $e) {
                $e = strtolower(trim($e));
                if ($e !== '') $sets[$jid][$e] = true;
            }
        }
        return isset($sets[$jid][strtolower($email)]);
    }
    return false;
}

/* ════════════════════════════════════════════════════════════════════════════
   3. Waits
   ═══════════════════════════════════════════════════════════════════════════ */

function journey_resolve_waits(array $j, array $graph): int {
    global $conn;
    $jid = (int)$j['id'];
    $woken = 0;

    /* ── delays ── */
    $q = $conn->query("SELECT * FROM journey_waits
                        WHERE journey_id = $jid AND status = 'pending' AND mode = 'delay' AND wake_at <= NOW()
                        ORDER BY wake_at LIMIT " . JOURNEY_ENTRY_BATCH);
    while ($q && $w = $q->fetch_assoc()) {
        // CAS: only the tick that flips 'pending' → 'fired' owns this wake-up.
        @$conn->query("UPDATE journey_waits SET status='fired', fired_at=NOW()
                        WHERE id=" . (int)$w['id'] . " AND status='pending'");
        if ($conn->affected_rows !== 1) continue;
        @$conn->query("UPDATE journey_entries SET status='active', current_node='"
                        . $conn->real_escape_string($w['node_id']) . "'
                       WHERE id = " . (int)$w['entry_id']);
        $woken++;
    }

    /* ── wait-for-event ──
       Two racing outcomes: the student acts (Happened) or the window closes
       (Timed out). Both flip the same row from 'pending', so exactly one wins and a
       student can never take both branches. */
    $q = $conn->query("SELECT w.*, e.user_id FROM journey_waits w
                        INNER JOIN journey_entries e ON e.id = w.entry_id
                       WHERE w.journey_id = $jid AND w.status = 'pending' AND w.mode = 'event'
                       ORDER BY w.id LIMIT " . JOURNEY_ENTRY_BATCH);
    $rows = [];
    while ($q && $w = $q->fetch_assoc()) $rows[] = $w;

    foreach ($rows as $w) {
        $from = "'" . $conn->real_escape_string((string)$w['watch_from']) . "'";

        /*
         * event_params is set only for an engagement wait, and holds the (type, status, scope)
         * the node was configured with — the same descriptor the condition evaluates, so
         * "wait until they open it" and "have they opened it" can never answer differently.
         */
        $p = $w['event_params'] ? json_decode((string)$w['event_params'], true) : null;
        if (is_array($p) && !empty($p['type'])) {
            $spec = journey_engagement_spec((string)$p['type'], (string)($p['status'] ?? ''));
            $happened = $spec
                ? journey_engagement_happened((int)$w['user_id'], $spec, (array)($p['scope'] ?? []), $from, 'NOW()')
                : null;
        } else {
            $happened = journey_event_happened((int)$w['user_id'], (string)$w['event_key'], $from, 'NOW()');
        }
        $expired = $w['expires_at'] && strtotime($w['expires_at']) <= time();

        if ($happened !== true && !$expired) continue;

        $nextNode = $happened === true ? $w['node_id'] : $w['timeout_node_id'];
        $newStatus = $happened === true ? 'fired' : 'expired';

        @$conn->query("UPDATE journey_waits SET status='$newStatus', fired_at=NOW()
                        WHERE id=" . (int)$w['id'] . " AND status='pending'");
        if ($conn->affected_rows !== 1) continue;

        if ($nextNode) {
            @$conn->query("UPDATE journey_entries SET status='active', current_node='"
                            . $conn->real_escape_string($nextNode) . "'
                           WHERE id = " . (int)$w['entry_id']);
        } else {
            journey_close_entry((int)$w['entry_id'], 'completed', 'path_end');
        }
        journey_record_step((int)$w['entry_id'], $jid, (string)$w['from_node_id'], 'flw_event',
            $happened === true ? 'Happened' : 'Timed out', 'ok',
            $happened === true ? 'Student did ' . $w['event_key'] : 'Window closed without the event');
        $woken++;
    }

    return $woken;
}

/* ════════════════════════════════════════════════════════════════════════════
   4. Step executor
   ═══════════════════════════════════════════════════════════════════════════ */

function journey_advance_entries(array $j, array $graph): int {
    global $conn;
    $jid = (int)$j['id'];
    $q = $conn->query("SELECT * FROM journey_entries
                        WHERE journey_id = $jid AND status = 'active'
                        ORDER BY id LIMIT " . JOURNEY_ENTRY_BATCH);
    $entries = [];
    while ($q && $row = $q->fetch_assoc()) $entries[] = $row;

    $n = 0;
    foreach ($entries as $entry) {
        try { journey_process_entry($j, $graph, $entry); $n++; }
        catch (Throwable $e) {
            journey_log("entry #{$entry['id']}: " . $e->getMessage());
            @$conn->query("UPDATE journey_entries SET status='errored',
                                  last_error='" . $conn->real_escape_string(mb_substr($e->getMessage(), 0, 990)) . "'
                            WHERE id = " . (int)$entry['id']);
        }
    }
    return $n;
}

/**
 * Walk one student forward until they hit a wait, an exit, or the per-tick step
 * budget. The budget is what stops a mis-drawn cycle from spinning forever: the
 * entry simply resumes on the next tick, and the step log makes the loop obvious.
 */
function journey_process_entry(array $j, array $graph, array $entry): void {
    global $conn;
    $jid = (int)$j['id'];
    $entryId = (int)$entry['id'];
    $nodeId = (string)$entry['current_node'];

    for ($i = 0; $i < JOURNEY_MAX_STEPS_PER_TICK; $i++) {
        $node = $graph['nodes'][$nodeId] ?? null;
        if (!$node) {
            journey_close_entry($entryId, 'errored', "Step '$nodeId' no longer exists in this version");
            return;
        }

        $res = journey_execute_node($j, $graph, $entry, $node);

        journey_record_step($entryId, $jid, $node['id'], $node['key'],
            $res['branch'] ?? null, $res['outcome'], (string)($res['detail'] ?? ''));

        @$conn->query("UPDATE journey_entries SET steps_taken = steps_taken + 1 WHERE id = $entryId");

        /* Held by quiet hours — do not advance. Re-queue THIS node for when the window ends,
           tagged so that shortening or switching off the schedule can release it early
           instead of leaving it sitting on a wake_at nobody wants any more. */
        if ($res['outcome'] === 'hold') {
            journey_queue_wait($entryId, $jid, $node['id'], $node['id'], null, (int)$res['retry_at'], 'dnd_hold');
            return;
        }

        /* A transient send failure. Same shape as a DND hold — park on THIS node and come
           back — but tagged 'retry', which is what puts it in the Outbox under "will try
           again" rather than under "quiet hours". The provider's own error travels with the
           row so the Outbox can show why, without anyone opening the worker log. */
        if ($res['outcome'] === 'retry') {
            journey_queue_wait($entryId, $jid, $node['id'], $node['id'], null, (int)$res['retry_at'],
                               'retry', (string)($res['detail'] ?? ''));
            return;
        }
        if ($res['outcome'] === 'exit') {
            journey_close_entry($entryId, 'exited', (string)($res['detail'] ?? 'Exit step'));
            return;
        }
        if ($res['outcome'] === 'wait') {
            return;   // the node queued its own wait row
        }
        if ($res['outcome'] === 'error') {
            journey_close_entry($entryId, 'errored', (string)($res['detail'] ?? 'Step failed'));
            return;
        }

        $branch = (string)($res['branch'] ?? '');
        $edges  = journey_out_edges($graph, $node['id'], $branch);
        if (!$edges) {
            /*
             * The student completes cleanly instead of accumulating invisibly — but the
             * reason goes on the step log as well as the entry.
             *
             * Closing silently was a genuine debugging trap: the RUNNING version of a
             * journey is the one pinned at publish time, so a step wired up on the canvas
             * afterwards does not exist for the engine. The report then showed a perfect
             * "Email → Sent" row, nothing after it, and no explanation anywhere — which
             * reads as "the delay is broken" when the truth is "this branch goes nowhere
             * in the version that is live". One row here answers that question.
             */
            journey_record_step($entryId, $jid, $node['id'], $node['key'], $branch, 'end',
                "Nothing is connected to the \"$branch\" output of this step in the version that is live, "
                . "so the path ends here. Re-publish the journey if you have since wired something up.");
            journey_close_entry($entryId, 'completed', "No connector from $branch");
            return;
        }
        $edge = $edges[0];

        /* Wait on the connector — Journey 2.0's model. */
        $wakeAt = journey_edge_wake_at($edge);
        if ($wakeAt !== null) {
            journey_queue_wait($entryId, $jid, $edge['to'], $node['id'], $edge['id'], $wakeAt);
            return;
        }
        $nodeId = $edge['to'];
        @$conn->query("UPDATE journey_entries SET current_node = '" . $conn->real_escape_string($nodeId) . "'
                        WHERE id = $entryId");
    }
    journey_log("entry #$entryId hit the per-tick step budget — resuming next tick (check for a loop).");
}

function journey_edge_wake_at(array $edge): ?int {
    $w = $edge['wait'] ?? null;
    if (!is_array($w)) return null;
    $amount = (int)($w['amount'] ?? 0);
    if ($amount <= 0) return null;
    $unit = (string)($w['unit'] ?? 'hours');
    $mult = $unit === 'minutes' ? 60 : ($unit === 'days' ? 86400 : 3600);
    return time() + $amount * $mult;
}

/**
 * Park the student until $wakeAtTs. THIS ROW IS THE "did the email go out?" LEDGER —
 * there is no second log to keep. It is written only after the step before it returned,
 * it names the node to run next, and journey_resolve_waits() wakes exactly one owner of
 * it. That is what makes "send B three minutes after A" hold for any A and any B.
 *
 * It therefore must not fail quietly. A swallowed INSERT used to leave the entry 'active'
 * and still sitting on the message node, so the next tick re-executed that node — a
 * duplicate send every minute, forever. Throwing hands the entry to the caller's guard,
 * which stamps it 'errored'; journey_retry_errored() picks it up five minutes later.
 */
function journey_queue_wait(int $entryId, int $journeyId, string $nextNodeId, string $fromNodeId,
                            ?string $edgeId, int $wakeAtTs, string $reason = 'delay',
                            ?string $lastError = null): void {
    global $conn;
    /*
     * `reason` is what lets quiet hours be released early and what lets the Outbox say why
     * somebody is sitting here — a plain delay, a message held by DND, or a send backing off
     * after a transient failure. Without it every pause looks identical and neither is
     * possible. See the migration note in lib/schema.php.
     */
    $reason = in_array($reason, ['delay', 'dnd_hold', 'retry'], true) ? $reason : 'delay';
    $held   = $reason === 'delay' ? null : date('Y-m-d H:i:s');

    $stmt = $conn->prepare("INSERT INTO journey_waits
        (entry_id, journey_id, node_id, from_node_id, edge_id, mode, wake_at, reason, held_since, last_error)
        VALUES (?,?,?,?,?, 'delay', ?,?,?,?)");
    if (!$stmt) throw new RuntimeException('Could not queue the delay: ' . $conn->error);
    $wake = date('Y-m-d H:i:s', $wakeAtTs);
    $err0 = $lastError === null ? null : mb_substr($lastError, 0, 490);
    $stmt->bind_param('iisssssss', $entryId, $journeyId, $nextNodeId, $fromNodeId, $edgeId,
                      $wake, $reason, $held, $err0);
    $ok  = @$stmt->execute();
    $err = $stmt->error;
    $stmt->close();
    if (!$ok) throw new RuntimeException('Could not queue the delay: ' . $err);
    @$conn->query("UPDATE journey_entries SET status='waiting' WHERE id = " . (int)$entryId);
}


/* ════════════════════════════════════════════════════════════════════════════
   Send retries — the machinery behind the Outbox
   ═══════════════════════════════════════════════════════════════════════════ */

/**
 * Which attempt this is, counted from the dispatch ledger.
 *
 * journey_messages holds one row per attempt at a (entry, node), including the failed
 * ones, so "how many times have we tried this" needs no separate counter — and cannot
 * drift out of step with what actually happened, which a counter would.
 */
function journey_attempt_no(int $entryId, string $nodeId): int {
    global $conn;
    $r = @$conn->query("SELECT COUNT(*) c FROM journey_messages
                         WHERE entry_id = " . (int)$entryId . "
                           AND node_id = '" . $conn->real_escape_string($nodeId) . "'");
    $row = $r ? $r->fetch_assoc() : null;
    return 1 + (int)($row['c'] ?? 0);
}

/** 5 minutes, then 20, then an hour. Long enough to outlast an outage, short enough
 *  that a message is not stale by the time it goes. */
function journey_retry_backoff(int $attempt): int {
    $ladder = [300, 1200, 3600];
    return $ladder[min($attempt, count($ladder)) - 1];
}

/**
 * Is this error worth trying again?
 *
 * The distinction that matters: a provider that was briefly unavailable will succeed on
 * the next attempt, while a rejected template or an invalid number will fail identically
 * forever, and retrying it three times just delays the Failed branch by 85 minutes and
 * writes three rows into the ledger for nothing.
 *
 * Matched on the message because that is all the transports hand back — they raise a
 * Throwable with the provider's text, not a typed error. Erring toward NOT retrying: an
 * unrecognised error takes the Failed branch immediately, which is the behaviour that was
 * there before, so nothing gets slower than it already was.
 */
function journey_error_is_transient(string $message): bool {
    $m = strtolower($message);

    // Never retry: the provider has made a decision that will not change.
    $permanent = ['not found', 'rejected', 'invalid', 'unsubscribe', 'blocked', 'blacklist',
                  'does not exist', 'no longer exists', 'not configured', 'unauthorized',
                  'unauthorised', 'forbidden', 'authentication', 'malformed', 'template'];
    foreach ($permanent as $p) if (strpos($m, $p) !== false) return false;

    $transient = ['timeout', 'timed out', 'temporarily', 'temporary', 'rate limit', 'too many requests',
                  'try again', 'unavailable', 'connection', 'could not reach', 'network',
                  'gateway', 'internal server error', 'throttl', 'overload', 'busy',
                  ' 429', ' 500', ' 502', ' 503', ' 504'];
    foreach ($transient as $t) if (strpos($m, $t) !== false) return true;

    return false;
}

function journey_close_entry(int $entryId, string $status, string $reason): void {
    global $conn;
    @$conn->query("UPDATE journey_entries
                      SET status = '" . $conn->real_escape_string($status) . "',
                          exited_at = NOW(),
                          exit_reason = '" . $conn->real_escape_string(mb_substr($reason, 0, 250)) . "'
                    WHERE id = " . (int)$entryId);
    // Any wait this student was holding is void the moment they leave.
    @$conn->query("UPDATE journey_waits SET status='cancelled' WHERE entry_id = " . (int)$entryId . " AND status='pending'");
}

function journey_record_step(int $entryId, int $journeyId, string $nodeId, string $nodeKey,
                             ?string $branch, string $outcome, string $detail): void {
    global $conn;
    $stmt = $conn->prepare("INSERT INTO journey_steps
        (entry_id, journey_id, node_id, node_key, branch, outcome, detail) VALUES (?,?,?,?,?,?,?)");
    if (!$stmt) return;
    $d = mb_substr($detail, 0, 490);
    $stmt->bind_param('iisssss', $entryId, $journeyId, $nodeId, $nodeKey, $branch, $outcome, $d);
    @$stmt->execute();
    $stmt->close();
}

/* ── the node executors ── */

function journey_execute_node(array $j, array $graph, array $entry, array $node): array {
    $cfg = $node['cfg'] ?? [];
    $uid = (int)($entry['user_id'] ?? 0);
    $ctx = [
        'journey_id' => (int)$j['id'], 'entry_id' => (int)$entry['id'], 'node_id' => $node['id'],
        'user_id' => $uid,
        /*
         * The attempt number, counted from what is already on the ledger rather than hard-coded.
         *
         * It used to be the literal 1, which quietly made retrying impossible: idem_key is
         * "entry:node:attempt" and is UNIQUE, so a second attempt at the same step collided with
         * the first and journey_claim_message() answered "already dispatched by a concurrent
         * run". A send that failed because the provider was down for ten seconds could therefore
         * never be tried again — its only route out of the step was the Failed branch.
         */
        'attempt' => journey_attempt_no((int)$entry['id'], (string)$node['id']),
    ];

    switch ($node['key']) {

        /* ── messages ── */
        case 'act_email': case 'act_wa': case 'act_sms': case 'act_push': case 'act_hook': {
            $res = journey_dispatch($j, $entry, $node, $ctx);
            switch ($res['outcome']) {
                case 'sent':
                    return ['outcome' => 'ok', 'branch' => $node['key'] === 'act_hook' ? 'Called' : 'Sent',
                            'detail' => $res['detail']];

                case 'failed': {
                    /*
                     * ── Retry before giving up ──────────────────────────────────────────
                     * A failed send is usually the provider having a bad ten seconds — a 500,
                     * a timeout, a rate limit — not a message that can never be delivered.
                     * Taking the Failed branch on the first error threw those away and, worse,
                     * did it silently: the report showed a Failed count and there was nothing
                     * anywhere to try again with.
                     *
                     * So a transient failure parks the entry on THIS node with a backoff and
                     * the Outbox shows it waiting, with the provider's own error on the row.
                     * Only when the attempts are spent does the student take the Failed branch,
                     * which is what that branch was always meant to mean: this person cannot
                     * be reached here, route them somewhere else.
                     */
                    $attempt = (int)$ctx['attempt'];
                    if ($attempt < JOURNEY_MAX_SEND_ATTEMPTS && journey_error_is_transient((string)($res['detail'] ?? ''))) {
                        return ['outcome'  => 'retry',
                                'retry_at' => time() + journey_retry_backoff($attempt),
                                'detail'   => 'Attempt ' . $attempt . ' of ' . JOURNEY_MAX_SEND_ATTEMPTS
                                              . ' failed, retrying: ' . $res['detail']];
                    }
                    return ['outcome' => 'ok', 'branch' => 'Failed',
                            'detail' => ($attempt > 1 ? "Gave up after $attempt attempts. " : '') . $res['detail']];
                }

                case 'hold':
                    return ['outcome' => 'hold', 'retry_at' => $res['retry_at'], 'detail' => $res['detail']];
                case 'suppressed':
                default:
                    // The student was NOT sent to, but they are NOT removed either. They
                    // continue down the Sent path. This is the deliberate break from
                    // Netcore, which drops a capped user out of the journey entirely.
                    return ['outcome' => 'suppressed',
                            'branch' => $node['key'] === 'act_hook' ? 'Called' : 'Sent',
                            'detail' => $res['detail']];
            }
        }

        /* ── other actions ── */
        case 'act_attr':
            return journey_do_update_attribute($entry, $cfg);

        case 'act_remove':
            return journey_do_remove_from_journey($entry, $cfg);

        case 'act_exit':
            return ['outcome' => 'exit', 'detail' => (string)($cfg['reason'] ?? 'Exit step')];

        /* ── conditions ── */
        case 'cnd_attr': {
            $ok = journey_check_attribute($entry, $cfg);
            $why = $uid <= 0 ? 'Anonymous student — attribute checks are skipped, False path taken.' : '';
            return ['outcome' => 'ok', 'branch' => $ok ? 'True' : 'False', 'detail' => $why];
        }

        case 'cnd_event': {
            $type = (string)($cfg['type'] ?? 'App / web activity');
            [$from, $to] = journey_event_window($cfg, 'NOW()');

            // Engagement — "did they open it / read it / tap it", looked at retrospectively.
            // Identical shape to the app-event branch below on purpose: same window widget, same
            // True/False outputs, so the two are indistinguishable to whoever drew the journey.
            if ($type !== 'App / web activity') {
                $status = (string)($cfg['status'] ?? '');
                $spec = journey_engagement_spec($type, $status);
                if (!$spec) {
                    return ['outcome' => 'error', 'detail' => journey_engagement_unsupported_reason($type, $status)];
                }
                $scope = journey_engagement_scope_from_cfg($cfg);
                // Same guard as the trigger: a campaign id that does not exist on this channel
                // would silently answer False for everybody, which is indistinguishable from a
                // student who genuinely did nothing.
                $scopeProblem = journey_engagement_scope_problem($spec, $scope);
                if ($scopeProblem !== null) return ['outcome' => 'error', 'detail' => $scopeProblem];

                $hit = journey_engagement_happened($uid, $spec, $scope, $from, $to);
                // null means unanswerable, not false — branching False on "we cannot tell" would
                // quietly send everyone down the did-not-engage path.
                if ($hit === null) return ['outcome' => 'error', 'detail' => "Cannot evaluate '$type / $status'."];
                return ['outcome' => 'ok', 'branch' => $hit ? 'True' : 'False'];
            }

            $key = (string)($cfg['event'] ?? '');
            $hit = journey_event_happened($uid, $key, $from, $to);
            if ($hit === null) return ['outcome' => 'error', 'detail' => "Cannot evaluate event '$key'."];
            return ['outcome' => 'ok', 'branch' => $hit ? 'True' : 'False'];
        }

        case 'cnd_in_segment': {
            $ok = journey_in_segment($uid, (array)($cfg['segments'] ?? []));
            return ['outcome' => 'ok', 'branch' => $ok ? 'True' : 'False'];
        }

        case 'cnd_in_list': {
            $ok = journey_in_list($uid, (string)($entry['email'] ?? ''), (array)($cfg['lists'] ?? []));
            return ['outcome' => 'ok', 'branch' => $ok ? 'True' : 'False'];
        }

        case 'cnd_reach':
            return ['outcome' => 'ok',
                    'branch'  => journey_reachable_branch($entry, (array)($cfg['channels'] ?? []))];

        case 'cnd_split': {
            $v = journey_split_variant((int)$j['id'], $node['id'], $uid, (array)($cfg['variants'] ?? []));
            if ($v === null) return ['outcome' => 'error', 'detail' => 'Split has no variants configured.'];
            return ['outcome' => 'ok', 'branch' => $v];
        }

        /* ── flow control ── */
        case 'flw_wait': {
            $edges = journey_out_edges($graph, $node['id'], 'Next');
            if (!$edges) return ['outcome' => 'ok', 'branch' => 'Next'];
            $wake = journey_wait_node_wake_at($cfg, (string)($j['timezone'] ?: 'Asia/Kolkata'));
            journey_queue_wait((int)$entry['id'], (int)$j['id'], $edges[0]['to'], $node['id'], $edges[0]['id'], $wake);
            return ['outcome' => 'wait', 'branch' => 'Next', 'detail' => 'Waiting until ' . date('Y-m-d H:i', $wake)];
        }

        case 'flw_event': {
            $yes = journey_out_edges($graph, $node['id'], 'Happened');
            $no  = journey_out_edges($graph, $node['id'], 'Timed out');
            $amount = max(1, (int)($cfg['amount'] ?? 24));
            $unit   = (string)($cfg['unit'] ?? 'hours');
            $mult   = $unit === 'minutes' ? 60 : ($unit === 'days' ? 86400 : 3600);

            /*
             * Two kinds of thing can be waited for, and this is where they diverge.
             *
             * An app event is named by a key from $EVENT_SOURCE. An engagement event is named by
             * a (channel, status, scope) triple, which does not fit in event_key's 64 characters
             * — so the key holds a short marker and the full descriptor goes in event_params,
             * the JSON column that already exists for exactly this sort of thing. Waiting for an
             * open is the whole point of this node in practice: "send the email, wait a day, and
             * chase only the people who didn't open it" is the journey everybody draws first.
             */
            $type = (string)($cfg['type'] ?? 'App / web activity');
            $params = null;
            if ($type !== 'App / web activity') {
                $status = (string)($cfg['status'] ?? '');
                $spec = journey_engagement_spec($type, $status);
                if (!$spec) {
                    return ['outcome' => 'error', 'detail' => journey_engagement_unsupported_reason($type, $status)];
                }
                $eventKey = '@eng:' . $spec['channel'] . ':' . substr(preg_replace('/[^a-z0-9]+/', '_', strtolower($status)), 0, 20);
                $params = ['type' => $type, 'status' => $status, 'scope' => journey_engagement_scope_from_cfg($cfg)];
                $label = "$type · $status";
            } else {
                $eventKey = (string)($cfg['event'] ?? '');
                $label = $eventKey ?: '?';
            }

            journey_queue_event_wait(
                (int)$entry['id'], (int)$j['id'], $node['id'],
                $yes ? $yes[0]['to'] : null, $no ? $no[0]['to'] : null,
                $eventKey, time() + $amount * $mult, $params
            );
            return ['outcome' => 'wait', 'detail' => 'Watching for ' . $label];
        }
    }

    return ['outcome' => 'error', 'detail' => "Unknown step type '{$node['key']}'."];
}

/** Wait node modes: fixed period, a time of day, or a day of the week. */
function journey_wait_node_wake_at(array $cfg, string $tzName): int {
    $mode = (string)($cfg['mode'] ?? 'A fixed period');
    $tz = new DateTimeZone($tzName);
    $now = new DateTime('now', $tz);

    if ($mode === 'A specific time of day') {
        $hm = (string)($cfg['time'] ?? '10:00');
        $t = (clone $now)->setTime((int)substr($hm, 0, 2), (int)substr($hm, 3, 2), 0);
        if ($t <= $now) $t->modify('+1 day');
        return $t->getTimestamp();
    }
    if ($mode === 'A specific day of the week') {
        $day = (string)($cfg['dow'] ?? 'Monday');
        $t = (clone $now)->modify('next ' . $day)->setTime(9, 0, 0);
        return $t->getTimestamp();
    }
    $amount = max(1, (int)($cfg['amount'] ?? 1));
    $unit   = (string)($cfg['unit'] ?? 'hours');
    $mult   = $unit === 'minutes' ? 60 : ($unit === 'days' ? 86400 : 3600);
    return time() + $amount * $mult;
}

function journey_queue_event_wait(int $entryId, int $journeyId, string $fromNodeId,
                                  ?string $yesNode, ?string $timeoutNode, string $eventKey, int $expiresTs,
                                  ?array $params = null): void {
    global $conn;
    // node_id is NOT NULL, and a branch with no connector legitimately yields null
    // here. Store '' instead: journey_resolve_waits() treats an empty target as
    // "path ends", which completes the student cleanly rather than failing the insert
    // and leaving them stuck on the node with no wait row at all.
    $yesNode = (string)($yesNode ?? '');

    $stmt = $conn->prepare("INSERT INTO journey_waits
        (entry_id, journey_id, node_id, from_node_id, mode, wake_at, event_key, event_params, watch_from, expires_at, timeout_node_id)
        VALUES (?,?,?,?, 'event', ?, ?, ?, NOW(), ?, ?)");
    if (!$stmt) return;
    // wake_at doubles as the polling deadline for event waits so the same index serves both.
    $exp = date('Y-m-d H:i:s', $expiresTs);
    // NULL for an app event, so the resolver can tell the two kinds apart without parsing the key.
    $paramsJson = $params === null ? null : json_encode($params);
    $stmt->bind_param('iisssssss', $entryId, $journeyId, $yesNode, $fromNodeId, $exp, $eventKey, $paramsJson, $exp, $timeoutNode);
    @$stmt->execute();
    $stmt->close();
    @$conn->query("UPDATE journey_entries SET status='waiting' WHERE id = " . (int)$entryId);
}

/**
 * Write a value back onto the student's profile.
 *
 * ── Why this is not simply "UPDATE users SET col = ?" ────────────────────────
 * The name in the dropdown is a CUSTOMER ATTRIBUTE (campaign_attributes), not a column
 * name, and the two are only occasionally the same word. An attribute is one of:
 *
 *   system   mapped to a real column somewhere — [FIR_NAME] → istudio_cit.users.fname.
 *            The value has to be written THROUGH that mapping, to the table the mapping
 *            names, joined on whichever of user_id / email that table carries.
 *   custom   backed by its own column in campaign_attribute_data, keyed by email.
 *
 * The previous version knew about neither. It looked for a `users` column called
 * FIR_NAME, did not find one, then ran an UPDATE against campaign_attribute_data for a
 * column that does not exist there either — so every write against a mapped attribute
 * silently did nothing and the step still reported success. Both real attributes on this
 * account are mapped ones, which is why the node never wrote anything at all.
 *
 * Resolution order, most specific first:
 *   1. a campaign_attributes row by that name  → write through its mapping
 *   2. a real `users` column by that name      → write it (covers ACTIVE, CITY, …, the
 *                                                raw column names the picker also offers)
 *   3. a campaign_attribute_data column        → last resort for an attribute row that
 *                                                was deleted but whose column remains
 *
 * The outcome is always 'ok' — a profile write that cannot land must not strand a student
 * mid-journey — but `detail` now says exactly what happened, and a write that reached
 * nothing says so instead of claiming a value was set.
 */
function journey_do_update_attribute(array $entry, array $cfg): array {
    global $conn;
    $attr = preg_replace('/[^A-Za-z0-9_]/', '', (string)($cfg['attr'] ?? ''));
    $val  = (string)($cfg['value'] ?? '');
    $uid  = (int)($entry['user_id'] ?? 0);
    if ($attr === '') return ['outcome' => 'ok', 'branch' => 'Done', 'detail' => 'No attribute chosen on this step — nothing written.'];

    $email = trim((string)($entry['email'] ?? ''));
    if ($uid <= 0 && $email === '') {
        return ['outcome' => 'ok', 'branch' => 'Done',
                'detail' => 'Anonymous student — there is no profile to write ' . $attr . ' onto.'];
    }

    /* ── 1. A real Customer Attribute ── */
    $row = journey_attribute_row($attr);
    if ($row) {
        if (($row['category'] ?? '') === 'system') {
            $db   = trim((string)($row['mapped_db'] ?? ''));
            $tbl  = trim((string)($row['mapped_table'] ?? ''));
            $col  = trim((string)($row['mapped_column'] ?? ''));
            $join = trim((string)($row['mapped_join_col'] ?? ''));
            if ($db === '' || $tbl === '' || $col === '' || $join === '') {
                return ['outcome' => 'ok', 'branch' => 'Done',
                        'detail' => "[$attr] is a mapped attribute with an incomplete mapping (Audience → Attributes), so there is nowhere to write it."];
            }
            /*
             * Identifiers come from an admin-created attribute row, never from the journey
             * graph, but they are still fenced to the character class MySQL allows inside a
             * backticked identifier — a stray backtick would otherwise break out of it.
             */
            if (!journey_safe_identifier($db) || !journey_safe_identifier($tbl)
                || !journey_safe_identifier($col) || !journey_safe_identifier($join)) {
                return ['outcome' => 'ok', 'branch' => 'Done',
                        'detail' => "[$attr] maps to a table name this engine will not write to."];
            }

            $n = 0;
            if ($join === 'user_id') {
                if ($uid <= 0) {
                    return ['outcome' => 'ok', 'branch' => 'Done',
                            'detail' => "[$attr] is keyed on user_id and this student has none."];
                }
                $stmt = $conn->prepare("UPDATE `$db`.`$tbl` SET `$col` = ? WHERE `$join` = ?");
                if (!$stmt) return ['outcome' => 'ok', 'branch' => 'Done', 'detail' => "Could not write [$attr]: " . $conn->error];
                $stmt->bind_param('si', $val, $uid);
                @$stmt->execute();
                $n = $stmt->affected_rows;
                $stmt->close();
            } else {
                if ($email === '') {
                    return ['outcome' => 'ok', 'branch' => 'Done',
                            'detail' => "[$attr] is keyed on email and this student has none on file."];
                }
                $stmt = $conn->prepare("UPDATE `$db`.`$tbl` SET `$col` = ? WHERE `$join` = ?");
                if (!$stmt) return ['outcome' => 'ok', 'branch' => 'Done', 'detail' => "Could not write [$attr]: " . $conn->error];
                $stmt->bind_param('ss', $val, $email);
                @$stmt->execute();
                $n = $stmt->affected_rows;
                $stmt->close();
            }
            /*
             * affected_rows is 0 both when nothing matched AND when the value was already
             * what we wrote, so it is reported rather than treated as a failure.
             */
            /*
             * Recorded in the contact-update ledger so a Contact-activity trigger elsewhere
             * can fire on "[FIR_NAME] was updated" — a journey writing a profile IS a
             * contact update, and one that no other journey could see would be a blind spot
             * exactly where journeys chain into each other. See lib/ContactActivity.php.
             */
            if ($email !== '') journey_contact_log_update($email, $attr, $val, 'journey', $uid);
            return ['outcome' => 'ok', 'branch' => 'Done',
                    'detail' => "[$attr] = \"$val\" -> $db.$tbl.$col"
                                . ($n > 0 ? ' (updated)' : ' (row unchanged — already this value, or no matching row)')];
        }

        /* custom → its own column in campaign_attribute_data, keyed by email */
        if ($email === '') {
            return ['outcome' => 'ok', 'branch' => 'Done',
                    'detail' => "[$attr] is stored against an email address and this student has none on file."];
        }
        if (function_exists('attribute_data_ensure_column')) attribute_data_ensure_column($attr);
        $col = substr($attr, 0, 64);
        /*
         * INSERT … ON DUPLICATE KEY, not a bare UPDATE: a student who has never had a
         * custom attribute written has no row in campaign_attribute_data at all, and the
         * UPDATE against them is the silent no-op that made this node look broken for
         * every freshly-imported contact.
         */
        $stmt = $conn->prepare("INSERT INTO campaign_attribute_data (email, `$col`) VALUES (?, ?)
                                ON DUPLICATE KEY UPDATE `$col` = VALUES(`$col`)");
        if (!$stmt) return ['outcome' => 'ok', 'branch' => 'Done', 'detail' => "Could not write [$attr]: " . $conn->error];
        $stmt->bind_param('ss', $email, $val);
        $okw = @$stmt->execute();
        $stmt->close();
        if ($okw) journey_contact_log_update($email, $attr, $val, 'journey', $uid);
        return ['outcome' => 'ok', 'branch' => 'Done',
                'detail' => $okw ? "[$attr] = \"$val\" -> campaign_attribute_data.$col" : "Could not write [$attr]."];
    }

    /* ── 2. A raw `users` column ── */
    if ($uid > 0 && journey_users_has_column($attr)) {
        $stmt = $conn->prepare("UPDATE users SET `$attr` = ? WHERE user_id = ?");
        if (!$stmt) return ['outcome' => 'ok', 'branch' => 'Done', 'detail' => "Could not write $attr: " . $conn->error];
        $stmt->bind_param('si', $val, $uid);
        @$stmt->execute();
        $n = $stmt->affected_rows;
        $stmt->close();
        if ($email !== '') journey_contact_log_update($email, $attr, $val, 'journey', $uid);
        return ['outcome' => 'ok', 'branch' => 'Done',
                'detail' => "users.$attr = \"$val\"" . ($n > 0 ? '' : ' (row unchanged)')];
    }

    /* ── 3. A leftover custom column ── */
    if ($email !== '' && journey_attribute_data_has_column($attr)) {
        $col = substr($attr, 0, 64);
        $stmt = $conn->prepare("INSERT INTO campaign_attribute_data (email, `$col`) VALUES (?, ?)
                                ON DUPLICATE KEY UPDATE `$col` = VALUES(`$col`)");
        if ($stmt) {
            $stmt->bind_param('ss', $email, $val);
            @$stmt->execute();
            $stmt->close();
            return ['outcome' => 'ok', 'branch' => 'Done', 'detail' => "$attr = \"$val\" -> campaign_attribute_data.$col"];
        }
    }

    return ['outcome' => 'ok', 'branch' => 'Done',
            'detail' => "There is no attribute called $attr any more (Audience → Attributes), so nothing was written. "
                      . 'The student continues to the next step.'];
}

function journey_safe_identifier(string $s): bool {
    return preg_match('/^[A-Za-z0-9_]+$/', $s) === 1;
}

/** One campaign_attributes row by name, case-insensitively. Cached — the worker
 *  walks thousands of entries through the same node in a single tick. */
function journey_attribute_row(string $name): ?array {
    global $conn;
    static $byName = null;
    if ($byName === null) {
        $byName = [];
        $r = @$conn->query("SELECT * FROM campaign_attributes");
        while ($r && $row = $r->fetch_assoc()) $byName[strtoupper((string)$row['name'])] = $row;
    }
    return $byName[strtoupper($name)] ?? null;
}

function journey_attribute_data_has_column(string $col): bool {
    global $conn;
    static $cols = null;
    if ($cols === null) {
        $cols = [];
        $r = @$conn->query("SHOW COLUMNS FROM campaign_attribute_data");
        while ($r && $row = $r->fetch_assoc()) $cols[strtolower($row['Field'])] = true;
    }
    return isset($cols[strtolower($col)]);
}

/**
 * Cross-journey suppression: when a student converts in journey A, pull them out of
 * nurture journey B — including any delay they are sitting in.
 */
function journey_do_remove_from_journey(array $entry, array $cfg): array {
    global $conn;
    $ref = (string)($cfg['journey'] ?? '');
    $uid = (int)($entry['user_id'] ?? 0);
    if ($ref === '' || $uid <= 0) return ['outcome' => 'ok', 'branch' => 'Done'];

    $targetId = is_numeric($ref) ? (int)$ref : 0;
    if (!$targetId) {
        $esc = $conn->real_escape_string($ref);
        $r = $conn->query("SELECT id FROM journeys WHERE name = '$esc' LIMIT 1");
        $row = $r ? $r->fetch_assoc() : null;
        $targetId = (int)($row['id'] ?? 0);
    }
    if (!$targetId) return ['outcome' => 'ok', 'branch' => 'Done', 'detail' => "Journey '$ref' not found."];

    $q = $conn->query("SELECT id FROM journey_entries
                        WHERE journey_id = $targetId AND user_id = $uid AND status IN ('active','waiting')");
    $n = 0;
    while ($q && $row = $q->fetch_assoc()) { journey_close_entry((int)$row['id'], 'exited', 'Removed by another journey'); $n++; }
    return ['outcome' => 'ok', 'branch' => 'Done', 'detail' => "Removed from $n entr" . ($n === 1 ? 'y' : 'ies') . " of '$ref'."];
}

/* ════════════════════════════════════════════════════════════════════════════
   5. Journey-level exit criteria
   ═══════════════════════════════════════════════════════════════════════════ */

/**
 * One rule — "exit anyone who fires exam_started" — replaces a dozen
 * condition/remove pairs drawn by hand at every conversion point. Netcore has no
 * equivalent; this is the single biggest structural gap the research called out.
 */
function journey_apply_exit_criteria(array $j): int {
    global $conn;
    $raw = $j['exit_criteria'] ?? null;
    if (!$raw) return 0;
    $rule = json_decode((string)$raw, true);
    $event = (string)($rule['event'] ?? '');
    if ($event === '' || !journey_event_source($event)) return 0;

    $jid = (int)$j['id'];
    $q = $conn->query("SELECT id, user_id, entered_at FROM journey_entries
                        WHERE journey_id = $jid AND status IN ('active','waiting') AND user_id IS NOT NULL
                        LIMIT " . JOURNEY_ENTRY_BATCH);
    $n = 0;
    while ($q && $row = $q->fetch_assoc()) {
        // Only events AFTER the student entered count — otherwise a historical
        // purchase would exit everyone the moment they walk in.
        $hit = journey_event_happened((int)$row['user_id'], $event,
            "'" . $conn->real_escape_string($row['entered_at']) . "'", 'NOW()');
        if ($hit === true) { journey_close_entry((int)$row['id'], 'exited', "Exit criteria: $event"); $n++; }
    }
    if ($n) journey_log("journey #$jid: exit criteria '$event' removed $n student(s).");
    return $n;
}

/* ════════════════════════════════════════════════════════════════════════════
   6. Rollups
   ═══════════════════════════════════════════════════════════════════════════ */

/**
 * Last-click attribution: a student counts as converted when they clicked a link
 * from one of THIS journey's messages and then did the goal event within the
 * window. Same rule the email campaigns use, so the two numbers are comparable.
 *
 * Revenue is recorded whenever the goal source exposes an amount, even if the
 * marketer picked a non-revenue goal.
 */
function journey_recount_conversions(int $journeyId): void {
    global $conn;
    $r = $conn->query("SELECT * FROM journeys WHERE id = " . (int)$journeyId . " LIMIT 1");
    $j = $r ? $r->fetch_assoc() : null;
    if (!$j || empty($j['goal_enabled']) || empty($j['goal_event'])) return;

    $hours = max(1, (int)$j['goal_window_hours']);

    /*
     * STRICT MODE — the goal reported itself, so we do not have to infer it.
     *
     * For the handful of events whose write path calls record_conversion() (signin,
     * register, payment_success, course_purchase, result_view, …) attribution was already
     * decided in the browser, at the moment the goal fired: the visitor arrived carrying
     * this journey's sticker, the dashboard kept it in the campaign_attr cookie, and a row
     * was written ONLY IF that cookie was still alive.
     *
     * That is a materially stronger claim than the window join below, and it is the reason
     * this branch exists. The window join credits a journey for anything that merely
     * follows a click — click the link, close the browser, come back tomorrow by typing the
     * address, buy something: counted. The cookie is deleted the instant someone arrives
     * without one, so the same visit produces no row and no credit.
     *
     * Control-group members are NOT switched over, and keep using the poll below: they are
     * never sent anything, so they can never carry a sticker, and their conversions have
     * always been measured from entry instead. That asymmetry predates this branch — the
     * treated group was already click-anchored while the holdout was entry-anchored — so
     * nothing about the lift comparison changes here.
     */
    /* Via the function, not the global — see campaigns_live_attributed_events(). A `global`
       here was silently empty whenever ConversionTracker.php happened to be required from
       inside a function, which turned strict mode off without anything saying so. */
    $liveEvents = function_exists('campaigns_live_attributed_events')
        ? campaigns_live_attributed_events()
        : (array)($GLOBALS['LIVE_ATTRIBUTED_EVENTS'] ?? []);
    $strict = in_array((string)$j['goal_event'], $liveEvents, true);

    /*
     * With no event source the POLL cannot run — the loop below skips itself on `!$src`. This
     * used to return outright, which also skipped the ledger read and the final count UPDATE;
     * a goal that lives only in campaign_attributions could then never be counted at all.
     */
    $src = journey_event_source((string)$j['goal_event']);

    $q = $conn->query("SELECT e.id AS entry_id, e.user_id, e.is_control,
                              MAX(m.first_clicked_at) AS clicked_at,
                              SUBSTRING_INDEX(GROUP_CONCAT(m.node_id ORDER BY m.first_clicked_at DESC), ',', 1) AS node_id
                         FROM journey_entries e
                         LEFT JOIN journey_messages m ON m.entry_id = e.id AND m.first_clicked_at IS NOT NULL
                        WHERE e.journey_id = " . (int)$journeyId . " AND e.user_id IS NOT NULL
                        GROUP BY e.id, e.user_id, e.is_control");

    while ($q && $row = $q->fetch_assoc()) {
        // In strict mode the treated group is counted from the ledger further down, and
        // must NOT also be polled — the poll is the loose rule this mode exists to replace,
        // and running both would put the counted-anyway rows straight back in.
        if ($strict && empty($row['is_control'])) continue;
        if (!$src) continue;

        // Control-group members never receive a message, so there is no click to
        // attribute from — their conversions are measured from entry instead. That is
        // exactly what makes the holdout comparable to the treated group.
        $from = $row['clicked_at'];
        if (!$from) {
            if (empty($row['is_control'])) continue;
            $er = $conn->query("SELECT entered_at FROM journey_entries WHERE id = " . (int)$row['entry_id']);
            $from = ($er ? $er->fetch_assoc()['entered_at'] : null);
            if (!$from) continue;
        }

        $fromQ = "'" . $conn->real_escape_string($from) . "'";
        $sql = 'SELECT ' . $src['date_col'] . ' AS at FROM ' . journey_event_from($src)
             . ' WHERE ' . $src['user_col'] . ' = ' . (int)$row['user_id']
             . ' AND ' . $src['date_col'] . ' >= ' . $fromQ
             . " AND " . $src['date_col'] . " <= DATE_ADD($fromQ, INTERVAL $hours HOUR)"
             . journey_event_extra_where($src)
             . ' ORDER BY ' . $src['date_col'] . ' ASC LIMIT 1';
        $cr = @$conn->query($sql);
        $crow = $cr ? $cr->fetch_assoc() : null;
        if (!$crow) continue;

        $stmt = $conn->prepare("INSERT IGNORE INTO journey_conversions
            (journey_id, entry_id, user_id, node_id, event_key, is_control, revenue, converted_at)
            VALUES (?,?,?,?,?,?,?,?)");
        if (!$stmt) continue;
        $ek = (string)$j['goal_event']; $rev = 0.0; $nid = (string)($row['node_id'] ?? '');
        $eid = (int)$row['entry_id']; $uid = (int)$row['user_id']; $ic = (int)$row['is_control'];
        $at = (string)$crow['at'];
        $stmt->bind_param('iiississ', $journeyId, $eid, $uid, $nid, $ek, $ic, $rev, $at);
        @$stmt->execute();
        $stmt->close();
    }

    /*
     * The ledger read runs ALWAYS, not only in strict mode.
     *
     * It used to be gated behind $strict, and that gate was load-bearing on a `global
     * $LIVE_ATTRIBUTED_EVENTS` — a top-level variable in ConversionTracker.php that is only
     * global if that file happened to be required from file scope. Any include path that pulled
     * it in from inside a function instead left the variable invisible here, $strict silently
     * false, and the ledger never read: campaign_attributions full of this journey's
     * conversions, and the journey reporting zero. Nothing in the UI could show that difference.
     *
     * Gating it was never necessary anyway. Every row this reads is keyed to THIS journey's
     * attribution id and THIS journey's goal event, so it is a conversion this journey earned by
     * construction — there is no looser interpretation to guard against. What $strict is
     * genuinely for is skipping the POLL for treated students (above), so the loose
     * click-window rule does not re-add what the cookie already proved; that is unchanged.
     *
     * Double counting is impossible regardless: journey_conversions is UNIQUE on
     * (entry_id, event_key) and every insert here is an INSERT IGNORE.
     */
    journey_recount_from_ledger($j, $hours);

    @$conn->query("UPDATE journeys j
                      SET conversion_count = (SELECT COUNT(*) FROM journey_conversions c WHERE c.journey_id = j.id),
                          revenue          = (SELECT COALESCE(SUM(revenue),0) FROM journey_conversions c WHERE c.journey_id = j.id)
                    WHERE j.id = " . (int)$journeyId);
}

/**
 * WhatsApp journey clicks, recovered from the attribution ledger.
 *
 * ── The problem this solves ──────────────────────────────────────────────────
 * A WhatsApp tracked link is byte-identical in every message ever sent, so a tap off a phone
 * names nobody. link.php can only put a name to it when the dashboard calls back carrying a
 * user_id — and that callback fires from App.jsx's mount effect, which React Router never
 * re-runs, because signing in is a client-side navigation and App is not remounted. So in the
 * ordinary tap → sign in → browse flow, the naming call is never made and the journey's Clicked
 * column stays at 0 no matter how many people really tapped.
 *
 * ── Why the ledger can answer it ─────────────────────────────────────────────
 * The tap DID leave a durable trace: link.php handed the browser this journey's sticker, and the
 * moment that visitor signed in, login.php wrote a campaign_attributions row carrying our
 * campaign_id and — crucially — clicked_at, which is the cookie's own timestamp, i.e. the real
 * moment of the tap. So the ledger already knows both who tapped and when. This copies that back
 * onto the message.
 *
 * Any event key counts, not just the goal: a plain 'signin' row is proof of the tap, and waiting
 * for a conversion before admitting the click happened would leave Clicked understating Converted.
 *
 * Runs before the recount so the same tick sees the click it just recovered. COALESCE everywhere:
 * a click already recorded first-hand — every email click, and any WhatsApp tap that did manage
 * the naming call — is the better record and is left exactly as it is.
 */
function journey_backfill_clicks_from_ledger(int $journeyId): void {
    global $conn;

    $attrId = journey_attr_campaign_id($journeyId);
    if ($attrId <= 0) return;

    $md = $conn->real_escape_string(JOURNEY_ATTR_MEDIUM);
    $rows = @$conn->query(
        "SELECT user_id, MIN(clicked_at) AS tapped_at
           FROM campaign_attributions
          WHERE campaign_id = $attrId AND medium = '$md' AND clicked_at IS NOT NULL
          GROUP BY user_id");
    if (!$rows) return;

    while ($row = $rows->fetch_assoc()) {
        $uid = (int)$row['user_id'];
        if ($uid <= 0) continue;
        $at = $conn->real_escape_string((string)$row['tapped_at']);

        /*
         * The newest message this journey actually sent them — the same last-click rule used
         * everywhere else. ORDER BY + LIMIT on a single-table UPDATE is what keeps a journey
         * that messaged one student at three steps from crediting all three for one tap.
         */
        @$conn->query(
            "UPDATE journey_messages
                SET first_clicked_at = COALESCE(first_clicked_at, '$at'),
                    click_count      = GREATEST(click_count, 1),
                    opened_at        = COALESCE(opened_at, '$at'),
                    delivered_at     = COALESCE(delivered_at, '$at')
              WHERE journey_id = " . (int)$journeyId . "
                AND user_id = $uid
                AND sent_at IS NOT NULL
              ORDER BY sent_at DESC
              LIMIT 1");
    }
}

/**
 * Treated-group conversions, read out of the shared attribution ledger.
 *
 * Every row here is already proof of attribution — it exists only because the visitor still
 * carried this journey's cookie when the goal fired — so there is no window arithmetic to do
 * and no event table to know about. The rows are copied into journey_conversions rather than
 * counted in place so that everything downstream (the report list, the per-node breakdown, the
 * control-vs-treated lift) keeps reading one table and needs no idea where a conversion came
 * from.
 *
 * The window IS still re-checked, for the same reason the campaigns re-check it: the cookie's
 * expiry is a client-side promise. A wrong browser clock or a hand-edited cookie could otherwise
 * manufacture a conversion months outside the window the journey actually asked for.
 *
 * Only the upper bound is bounded. clicked_at and attributed_at are written by different
 * machines — the Go payment service for purchases, PHP for everything else — so a second or two
 * of skew can legitimately put attributed_at marginally before clicked_at.
 *
 * INSERT IGNORE plus the entry lookup makes this safe to run every tick: a conversion already
 * copied stays exactly as it was, and a row whose user never entered this journey is skipped
 * rather than inventing an entry for them.
 */
function journey_recount_from_ledger(array $j, int $windowHours): void {
    global $conn;

    $journeyId = (int)$j['id'];
    $attrId    = journey_attr_campaign_id($journeyId);
    if ($attrId <= 0) return;

    $ek     = $conn->real_escape_string((string)$j['goal_event']);
    $md     = $conn->real_escape_string(JOURNEY_ATTR_MEDIUM);
    $days   = journey_attr_window_days($windowHours);

    $rows = @$conn->query(
        "SELECT ca.user_id, ca.attributed_at
           FROM campaign_attributions ca
          WHERE ca.campaign_id = $attrId
            AND ca.medium      = '$md'
            AND ca.event_key   = '$ek'
            AND (ca.clicked_at IS NULL
                 OR ca.attributed_at <= DATE_ADD(ca.clicked_at, INTERVAL $days DAY))");
    if (!$rows) {
        journey_log("journey #$journeyId: ledger query failed for goal '$ek' — " . $conn->error);
        return;
    }

    /*
     * Counted rather than left silent. "The ledger has rows but the journey reports zero" is
     * otherwise indistinguishable from "there are no rows", and the two have completely
     * different causes — the usual one being a conversion credited to somebody who never
     * entered this journey, which is legitimate and used to look exactly like a bug.
     */
    $seen = 0; $noEntry = 0; $inserted = 0; $unmatched = [];

    while ($row = $rows->fetch_assoc()) {
        $seen++;
        $uid = (int)$row['user_id'];
        if ($uid <= 0) continue;

        /*
         * Which entry, and which step gets the credit. Newest entry wins for a student who has
         * been through this journey more than once, and the node is the last one whose message
         * they actually clicked — the same last-click rule the poll uses.
         *
         * MATCHED ON user_id OR EMAIL, and the email half is not belt-and-braces.
         *
         * The two sides learn who the student is from different places. The entry takes its
         * user_id from the campaign recipient row that produced the engagement, which is filled
         * in by the audience resolver and is NULL for anyone who arrived on an imported list.
         * The ledger row takes its user_id from the logged-in session at the moment the goal
         * fired. One person can therefore appear as two different ids — or as an id on one side
         * and only an address on the other — and the conversion then belongs to nobody.
         *
         * That is not hypothetical: it is exactly what the worker log reported as "credited to
         * someone who never entered this journey" while campaign_attributions plainly held the
         * journey's own conversions.
         *
         * The email comparison is still an identity match, not a widening: it asks whether the
         * converting user's own address is the address this entry was created for. Two different
         * people cannot satisfy it.
         */
        $er = $conn->query(
            "SELECT e.id, e.is_control,
                    SUBSTRING_INDEX(GROUP_CONCAT(m.node_id ORDER BY m.first_clicked_at DESC), ',', 1) AS node_id
               FROM journey_entries e
               LEFT JOIN journey_messages m ON m.entry_id = e.id AND m.first_clicked_at IS NOT NULL
              WHERE e.journey_id = $journeyId
                AND (e.user_id = $uid
                     OR (e.email IS NOT NULL AND e.email <> ''
                         /*
                          * COLLATE is not optional here. journey_entries is utf8mb4_unicode_ci
                          * and users is utf8mb4_general_ci, so a bare `=` between the two raises
                          * MySQL 1267 (illegal mix of collations) — the query errors, $er comes
                          * back false, and the row is silently recorded as unmatched. Forcing one
                          * side is the same thing the campaign audience resolver does when it
                          * joins these two tables.
                          */
                         AND e.email COLLATE utf8mb4_general_ci
                             = (SELECT u2.email FROM users u2 WHERE u2.user_id = $uid)))
              GROUP BY e.id, e.is_control
              ORDER BY e.id DESC LIMIT 1");
        $entry = $er ? $er->fetch_assoc() : null;
        if (!$entry) {
            $noEntry++;
            // Name the id. "Somebody" is not enough to act on; this is the value to paste into
            // a query against journey_entries to see who the journey actually enrolled.
            if ($noEntry <= 3) $unmatched[] = $uid;
            continue;
        }

        $stmt = $conn->prepare("INSERT IGNORE INTO journey_conversions
            (journey_id, entry_id, user_id, node_id, event_key, is_control, revenue, converted_at)
            VALUES (?,?,?,?,?,?,?,?)");
        if (!$stmt) continue;
        $eid = (int)$entry['id']; $ic = (int)$entry['is_control'];
        $nid = (string)($entry['node_id'] ?? ''); $rev = 0.0;
        $goal = (string)$j['goal_event']; $at = (string)$row['attributed_at'];
        $stmt->bind_param('iiississ', $journeyId, $eid, $uid, $nid, $goal, $ic, $rev, $at);
        @$stmt->execute();
        // The statement's own count, not the connection's — after a prepared execute the
        // connection-level value is not reliably the one this INSERT produced.
        if ($stmt->affected_rows > 0) $inserted++;
        $stmt->close();
    }

    if ($seen > 0) {
        journey_log("journey #$journeyId: ledger goal '$ek' — $seen row(s), $inserted new"
                  . ($noEntry ? ", $noEntry unmatched (user_id " . implode(', ', $unmatched) . ')' : '')
                  . '.');
    }
}

function journey_rollup_node_stats(int $journeyId): void {
    global $conn;
    $jid = (int)$journeyId;

    @$conn->query("REPLACE INTO journey_node_stats (journey_id, node_id, stat_date, entered)
                   SELECT journey_id, node_id, DATE(created_at), COUNT(DISTINCT entry_id)
                     FROM journey_steps WHERE journey_id = $jid
                    GROUP BY journey_id, node_id, DATE(created_at)");

    @$conn->query("UPDATE journey_node_stats s
                     JOIN (SELECT journey_id, node_id, DATE(queued_at) d,
                                  SUM(status='sent') sent,
                                  SUM(delivered_at IS NOT NULL) delivered,
                                  SUM(opened_at IS NOT NULL) opened,
                                  SUM(first_clicked_at IS NOT NULL) clicked,
                                  SUM(status='suppressed') suppressed,
                                  SUM(status='failed') failed
                             FROM journey_messages WHERE journey_id = $jid
                            GROUP BY journey_id, node_id, DATE(queued_at)) m
                       ON m.journey_id = s.journey_id AND m.node_id = s.node_id AND m.d = s.stat_date
                      SET s.sent = m.sent, s.delivered = m.delivered, s.opened = m.opened,
                          s.clicked = m.clicked, s.suppressed = m.suppressed, s.failed = m.failed");

    /*
     * CLICKED COUNTS PEOPLE, and only people we can actually name.
     *
     * An earlier version added the unnamed WhatsApp taps to this, deduplicated by identity_key,
     * on the assumption that the key identifies a browser. It does not — it identifies a TAP.
     * WhatsApp opens links in its own in-app browser with a fresh storage context every time, so
     * localStorage never persists and each tap arrives wearing a brand-new visitor key. One
     * person tapping twelve times therefore looked like twelve people, and the report read 13
     * clicks for a single tester. An inflated number is worse than a missing one, because it
     * cannot be recognised as wrong.
     *
     * So this counts what can be proven: messages whose click was tied to a real person, either
     * by link.php at tap time or by the ledger backfill after they signed in. Taps that were
     * never followed by a sign-in are not people we can count — they are shown in full, one row
     * each, in the report's tap log, where "5 taps from 2 people" says exactly what is known
     * without pretending to know more.
     */
    @$conn->query("UPDATE journeys j SET
        active_count    = (SELECT COUNT(*) FROM journey_entries e WHERE e.journey_id = j.id AND e.status IN ('active','waiting')),
        entered_count   = (SELECT COUNT(*) FROM journey_entries e WHERE e.journey_id = j.id),
        sent_count      = (SELECT COUNT(*) FROM journey_messages m WHERE m.journey_id = j.id AND m.status='sent'),
        delivered_count = (SELECT COUNT(*) FROM journey_messages m WHERE m.journey_id = j.id AND m.delivered_at IS NOT NULL),
        opened_count    = (SELECT COUNT(*) FROM journey_messages m WHERE m.journey_id = j.id AND m.opened_at IS NOT NULL),
        clicked_count   = (SELECT COUNT(*) FROM journey_messages m WHERE m.journey_id = j.id AND m.first_clicked_at IS NOT NULL),
        suppressed_count= (SELECT COUNT(*) FROM journey_messages m WHERE m.journey_id = j.id AND m.status='suppressed')
        WHERE j.id = $jid");
}

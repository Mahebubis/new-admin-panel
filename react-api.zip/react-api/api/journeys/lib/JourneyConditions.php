<?php
/*
 * /api/journeys/lib/JourneyConditions.php
 *
 * Everything the engine needs to answer "which branch does this student take?",
 * plus the event queries the Activity trigger polls with.
 *
 * ── The one architectural fact that shapes this whole file ────────────────────
 * There is no event stream on this platform. `signin`, `exam_success`,
 * `course_purchase` and the other ~20 events are DERIVED at query time from
 * domain tables (signin_log, cit_results, payment_status …) through $EVENT_SOURCE
 * in netcore/lib/segment_sql.php, which the segment builder and ConversionTracker
 * already share. This file is the third consumer of that same registry — it does
 * not invent a parallel event vocabulary, so an event added there works in
 * segments, campaigns AND journeys with no further wiring.
 *
 * Two consequences worth knowing before reading further:
 *   1. "Has the student done X?" is an EXISTS query against a domain table, not a
 *      lookup in an events table. It is exact, but it costs a query per student
 *      per condition — hence the per-tick batching in JourneyEngine.
 *   2. The Activity trigger cannot be push-based. It is a watermark poller:
 *      "give me rows whose date_col moved past where I last read". Netcore fires
 *      in milliseconds; this fires within one cron tick. That is the honest
 *      ceiling of this data model and the docs say so out loud.
 */

require_once __DIR__ . '/../../netcore/lib/segment_sql.php';

/* ════════════════════════════════════════════════════════════════════════════
   Event sources
   ═══════════════════════════════════════════════════════════════════════════ */

function journey_event_source(string $eventKey): ?array {
    global $EVENT_SOURCE;
    return $EVENT_SOURCE[$eventKey] ?? null;
}

function journey_event_keys(): array {
    global $EVENT_SOURCE;
    return array_keys($EVENT_SOURCE ?: []);
}

/**
 * FROM + JOIN fragment for an event, so callers don't have to remember that some
 * sources are derived tables and some need a join to reach users.user_id.
 */
function journey_event_from(array $src): string {
    return $src['table'] . (isset($src['join']) && $src['join'] !== '' ? ' ' . $src['join'] : '');
}

function journey_event_extra_where(array $src): string {
    return (isset($src['where']) && trim((string)$src['where']) !== '') ? ' AND (' . $src['where'] . ')' : '';
}

/**
 * Did this user fire this event inside [$fromSql, $toSql]?
 *
 * $fromSql/$toSql are already-quoted SQL datetime literals or NULL for open-ended.
 * Returns null (not false) when the event key is unknown, so callers can tell
 * "definitely didn't happen" apart from "we can't evaluate this" — the engine
 * treats the latter as an error and stops the entry rather than silently sending
 * everyone down the False branch.
 */
function journey_event_happened(int $userId, string $eventKey, ?string $fromSql, ?string $toSql): ?bool {
    global $conn;
    $src = journey_event_source($eventKey);
    if (!$src) return null;

    $where = $src['user_col'] . ' = ' . (int)$userId;
    if ($fromSql) $where .= ' AND ' . $src['date_col'] . ' >= ' . $fromSql;
    if ($toSql)   $where .= ' AND ' . $src['date_col'] . ' <= ' . $toSql;
    $where .= journey_event_extra_where($src);

    $sql = 'SELECT 1 FROM ' . journey_event_from($src) . ' WHERE ' . $where . ' LIMIT 1';
    $r = @$conn->query($sql);
    if ($r === false) {
        journey_cond_log("event_happened SQL failed for '$eventKey': " . $conn->error);
        return null;
    }
    return $r->num_rows > 0;
}

/**
 * New rows on an event source since the watermark — how Activity triggers find
 * candidates. Returns [['user_id'=>int,'at'=>'Y-m-d H:i:s'], …] oldest first.
 *
 * `$since` is EXCLUSIVE and `$until` INCLUSIVE, and both are always passed by the
 * caller (never NOW() inline) so that a row written while the tick was running
 * cannot be skipped: the next tick's window starts exactly where this one ended.
 */
function journey_event_new_rows(string $eventKey, string $since, string $until, int $limit = 2000): array {
    global $conn;
    $src = journey_event_source($eventKey);
    if (!$src) return [];

    $sinceQ = "'" . $conn->real_escape_string($since) . "'";
    $untilQ = "'" . $conn->real_escape_string($until) . "'";

    $sql = 'SELECT ' . $src['user_col'] . ' AS user_id, ' . $src['date_col'] . ' AS at'
         . ' FROM ' . journey_event_from($src)
         . ' WHERE ' . $src['date_col'] . ' > ' . $sinceQ
         . ' AND '   . $src['date_col'] . ' <= ' . $untilQ
         . ' AND '   . $src['user_col'] . ' IS NOT NULL'
         . journey_event_extra_where($src)
         . ' ORDER BY ' . $src['date_col'] . ' ASC LIMIT ' . (int)$limit;

    $r = @$conn->query($sql);
    if ($r === false) {
        journey_cond_log("event_new_rows SQL failed for '$eventKey': " . $conn->error);
        return [];
    }
    $out = [];
    while ($row = $r->fetch_assoc()) {
        $uid = (int)$row['user_id'];
        if ($uid > 0) $out[] = ['user_id' => $uid, 'at' => (string)$row['at']];
    }
    return $out;
}

/**
 * Turns the builder's look-back widget into a concrete window.
 * cfg: { wtype, wamount, wfrom, wto }. Returns [fromSqlLiteral|null, toSqlLiteral|null].
 * 180 days is the documented hard ceiling and is enforced here, not just in the UI.
 */
function journey_event_window(array $cfg, string $nowSql): array {
    global $conn;
    $type = (string)($cfg['wtype'] ?? 'Past number of hours');
    $n    = max(1, (int)($cfg['wamount'] ?? 24));

    $q = fn($s) => "'" . $conn->real_escape_string($s) . "'";

    switch ($type) {
        case 'Past number of minutes':
            return ["DATE_SUB($nowSql, INTERVAL $n MINUTE)", $nowSql];
        case 'Past number of days':
            $n = min($n, 180);
            return ["DATE_SUB($nowSql, INTERVAL $n DAY)", $nowSql];
        case 'Custom date range':
            $from = trim((string)($cfg['wfrom'] ?? ''));
            $to   = trim((string)($cfg['wto'] ?? ''));
            return [$from !== '' ? $q($from . ' 00:00:00') : null,
                    $to   !== '' ? $q($to   . ' 23:59:59') : $nowSql];
        case 'Last 180 days':
            return ["DATE_SUB($nowSql, INTERVAL 180 DAY)", $nowSql];
        case 'Past number of hours':
        default:
            return ["DATE_SUB($nowSql, INTERVAL $n HOUR)", $nowSql];
    }
}

/* ════════════════════════════════════════════════════════════════════════════
   Check attribute
   ═══════════════════════════════════════════════════════════════════════════ */

/**
 * Ten operators, ALL/ANY matching, evaluated in PHP against a resolved value map
 * rather than as SQL — because the values come from two different places (columns
 * on `users`, plus the Customer Attributes store) and stitching that into one
 * WHERE clause per student would be slower than fetching the row once.
 *
 * Netcore states in its own node UI that attribute checks are NOT performed for
 * anonymous users. We keep that, but make the outcome explicit instead of
 * undefined: no user_id → False branch, and the step log records why (research
 * Part D 8 — "our rule should be stated in the product, not discovered").
 */
function journey_check_attribute(array $entry, array $cfg): bool {
    $rules = (array)($cfg['rules'] ?? []);
    if (!$rules) return true;                       // nothing to fail

    $userId = (int)($entry['user_id'] ?? 0);
    if ($userId <= 0) return false;                 // anonymous → False, always

    $vals = journey_attribute_values($userId, $entry);
    $any  = strtolower((string)($cfg['match'] ?? 'All rules')) === 'any rule';

    $result = !$any;                                // ALL starts true, ANY starts false
    foreach ($rules as $r) {
        $attr = strtoupper(trim((string)($r['a'] ?? '')));
        if ($attr === '') continue;
        $ok = journey_apply_operator($vals[$attr] ?? null, (string)($r['op'] ?? 'Is'), (string)($r['v'] ?? ''));
        if ($any) { if ($ok) return true; }
        else      { if (!$ok) return false; }
    }
    return $result;
}

/** users columns + campaign_attribute_data, upper-cased into one flat map. */
function journey_attribute_values(int $userId, array $entry = []): array {
    global $conn;
    static $cache = [];
    if (isset($cache[$userId])) return $cache[$userId];

    $out = [];
    $r = @$conn->query("SELECT * FROM users WHERE user_id = " . (int)$userId . " LIMIT 1");
    $row = $r ? $r->fetch_assoc() : null;
    if ($row) foreach ($row as $k => $v) $out[strtoupper($k)] = $v;

    // Friendly aliases the builder's ATTRS list uses.
    $out['FIRST_NAME'] = $out['FIRST_NAME'] ?? ($out['FNAME'] ?? ($entry['first_name'] ?? null));
    $out['LAST_NAME']  = $out['LAST_NAME']  ?? ($out['LNAME'] ?? ($entry['last_name'] ?? null));
    $out['MOBILE']     = $out['MOBILE']     ?? ($out['PHONE'] ?? ($entry['phone'] ?? null));

    // Customer Attributes (campaign_attributes → campaign_attribute_data), keyed by email.
    $email = (string)($row['email'] ?? ($entry['email'] ?? ''));
    if ($email !== '') {
        $esc = $conn->real_escape_string($email);
        $ar = @$conn->query("SELECT * FROM campaign_attribute_data WHERE email = '$esc' LIMIT 1");
        $arow = $ar ? $ar->fetch_assoc() : null;
        if ($arow) foreach ($arow as $k => $v) {
            $K = strtoupper($k);
            if ($K === 'EMAIL' || $K === 'ID') continue;
            if (!isset($out[$K]) || $out[$K] === null || $out[$K] === '') $out[$K] = $v;
        }
    }

    if (count($cache) > 500) $cache = [];   // keep a long worker run from growing unbounded
    $cache[$userId] = $out;
    return $out;
}

function journey_apply_operator($value, string $op, string $target): bool {
    $has = !($value === null || $value === '');
    $v = is_scalar($value) ? (string)$value : '';
    $t = $target;

    switch ($op) {
        case 'Exists':           return $has;
        case 'Does not exist':   return !$has;
        case 'Is':               return $has && strcasecmp($v, $t) === 0;
        case 'Is not':           return !$has || strcasecmp($v, $t) !== 0;
        case 'Contains':         return $has && stripos($v, $t) !== false;
        case 'Does not contain': return !$has || stripos($v, $t) === false;
        case 'Starts with':      return $has && stripos($v, $t) === 0;
        case 'Ends with':        return $has && $t !== '' && substr_compare($v, $t, -strlen($t), strlen($t), true) === 0;
        case 'Is one of':
        case 'Is not one of':
            $list = array_map('trim', preg_split('/[,\n]/', $t) ?: []);
            $in = false;
            foreach ($list as $item) if ($item !== '' && strcasecmp($v, $item) === 0) { $in = true; break; }
            return $op === 'Is one of' ? ($has && $in) : (!$has || !$in);
    }
    // An operator we don't know must not quietly pass everyone through.
    journey_cond_log("unknown attribute operator '$op' — treated as no-match");
    return false;
}

/* ════════════════════════════════════════════════════════════════════════════
   Segment / list membership
   ═══════════════════════════════════════════════════════════════════════════ */

/** Accepts ids or names — the builder used to store names, real data stores ids. */
function journey_resolve_segment_ids(array $refs): array {
    global $conn;
    $ids = [];
    foreach ($refs as $ref) {
        if (is_numeric($ref)) { $ids[] = (int)$ref; continue; }
        $esc = $conn->real_escape_string(trim((string)$ref));
        if ($esc === '') continue;
        $r = @$conn->query("SELECT id FROM netcore_segments WHERE name = '$esc' LIMIT 1");
        $row = $r ? $r->fetch_assoc() : null;
        if ($row) $ids[] = (int)$row['id'];
    }
    return array_values(array_unique(array_filter($ids)));
}

function journey_resolve_list_ids(array $refs): array {
    global $conn;
    $ids = [];
    foreach ($refs as $ref) {
        if (is_numeric($ref)) { $ids[] = (int)$ref; continue; }
        $esc = $conn->real_escape_string(trim((string)$ref));
        if ($esc === '') continue;
        $r = @$conn->query("SELECT id FROM campaign_lists WHERE name = '$esc' LIMIT 1");
        $row = $r ? $r->fetch_assoc() : null;
        if ($row) $ids[] = (int)$row['id'];
    }
    return array_values(array_unique(array_filter($ids)));
}

/** True if the user is in ANY of up to 5 segments (Netcore's semantics). */
function journey_in_segment(int $userId, array $segmentRefs): bool {
    global $conn;
    if ($userId <= 0) return false;
    $ids = array_slice(journey_resolve_segment_ids($segmentRefs), 0, 5);
    foreach ($ids as $id) {
        $r = @$conn->query("SELECT config FROM netcore_segments WHERE id = " . (int)$id . " LIMIT 1");
        $row = $r ? $r->fetch_assoc() : null;
        if (!$row) continue;
        $sql = buildSegmentSql(json_decode($row['config'], true));
        if (!$sql) continue;
        $q = @$conn->query("SELECT 1 FROM ($sql) AS s WHERE s.user_id = " . (int)$userId . " LIMIT 1");
        if ($q === false) { journey_cond_log("in_segment failed for segment #$id: " . $conn->error); continue; }
        if ($q->num_rows > 0) return true;
    }
    return false;
}

/** Lists are email-keyed (campaign_contacts ← campaign_list_members), not user-keyed. */
function journey_in_list(int $userId, string $email, array $listRefs): bool {
    global $conn;
    $ids = array_slice(journey_resolve_list_ids($listRefs), 0, 5);
    if (!$ids) return false;
    $email = trim($email);
    if ($email === '' && $userId > 0) {
        $r = @$conn->query("SELECT email FROM users WHERE user_id = " . (int)$userId . " LIMIT 1");
        $row = $r ? $r->fetch_assoc() : null;
        $email = (string)($row['email'] ?? '');
    }
    if ($email === '') return false;

    $esc = $conn->real_escape_string($email);
    $in  = implode(',', array_map('intval', $ids));
    $q = @$conn->query("SELECT 1 FROM campaign_list_members m
                          INNER JOIN campaign_contacts c ON c.id = m.contact_id
                         WHERE m.list_id IN ($in) AND c.email = '$esc' LIMIT 1");
    if ($q === false) { journey_cond_log('in_list failed: ' . $conn->error); return false; }
    return $q->num_rows > 0;
}

/* ════════════════════════════════════════════════════════════════════════════
   Split traffic — sticky variant assignment
   ═══════════════════════════════════════════════════════════════════════════ */

/**
 * Look up first, assign only if absent (spec 5.5). The assignment is a STABLE HASH
 * of user+node mapped onto the cumulative percentage bands, not a random draw:
 *   - a user re-entering the journey lands in the same variant, which is the
 *     documented behaviour;
 *   - the same user gets independent variants at two different split nodes,
 *     because the node id is in the hash;
 *   - re-running the engine on the same data produces the same allocation, which
 *     is what makes a split reproducible when you are debugging one.
 *
 * Netcore's documented wart — editing percentages after deploy moves already
 * assigned users — does not happen here: the stored row wins over the new bands.
 */
function journey_split_variant(int $journeyId, string $nodeId, int $userId, array $variants): ?string {
    global $conn;

    $keys = [];
    foreach ($variants as $v) {
        $k = (string)($v['key'] ?? '');
        if ($k !== '') $keys[$k] = max(0, (int)($v['pct'] ?? 0));
    }
    if (!$keys) return null;

    $nodeEsc = $conn->real_escape_string($nodeId);
    if ($userId > 0) {
        $r = @$conn->query("SELECT variant FROM journey_split_assignments
                             WHERE journey_id = " . (int)$journeyId . "
                               AND node_id = '$nodeEsc' AND user_id = " . (int)$userId . " LIMIT 1");
        $row = $r ? $r->fetch_assoc() : null;
        // Only honour a stored variant that still exists on the node — a deleted
        // variant would otherwise strand the user on a branch with no connector.
        if ($row && isset($keys[$row['variant']])) return (string)$row['variant'];
    }

    $total = array_sum($keys);
    if ($total <= 0) return (string)array_key_first($keys);

    $seed   = $userId > 0 ? ($journeyId . ':' . $nodeId . ':' . $userId) : uniqid('anon', true);
    $bucket = hexdec(substr(md5($seed), 0, 8)) % $total;

    $chosen = array_key_first($keys);
    $acc = 0;
    foreach ($keys as $k => $pct) {
        $acc += $pct;
        if ($bucket < $acc) { $chosen = $k; break; }
    }

    if ($userId > 0) {
        $ce = $conn->real_escape_string($chosen);
        @$conn->query("INSERT IGNORE INTO journey_split_assignments (journey_id, node_id, user_id, variant)
                       VALUES (" . (int)$journeyId . ", '$nodeEsc', " . (int)$userId . ", '$ce')");
    }
    return $chosen;
}

/* ════════════════════════════════════════════════════════════════════════════
   Reachable channel
   ═══════════════════════════════════════════════════════════════════════════ */

/**
 * Priority-ordered fallback, not a boolean gate: walk the marketer's channel order
 * and return the first branch the student is actually contactable on. Cheapest
 * first is the whole point — reaching someone on email instead of SMS is a real
 * cost saving at your volumes.
 *
 * Only channels with a working transport can be "reachable". SMS and App push have
 * no provider on this server, so a student is never routed down them — otherwise
 * the branch would silently swallow everyone who has a phone number.
 */
function journey_reachable_branch(array $entry, array $channels): string {
    global $conn;
    $order = $channels ?: JOURNEY_DEFAULT_CHANNELS;

    $email = trim((string)($entry['email'] ?? ''));
    $phone = trim((string)($entry['phone'] ?? ''));

    foreach ($order as $ch) {
        switch (strtolower(trim((string)$ch))) {
            case 'email':
                if ($email !== '' && !journey_is_blocklisted($email)) return (string)$ch;
                break;
            case 'whatsapp':
                if ($phone !== '' && journey_wa_reachable($phone)) return (string)$ch;
                break;
            // 'sms' / 'app push' deliberately never match — no transport, see docblock.
        }
    }
    return 'Unreachable';
}

/**
 * The blocklist is a LIST, not a table of its own — campaigns/lib/AudienceResolver.php's
 * blocklisted_emails() resolves it through lists_get_or_create_blocklist_id(). Reusing
 * that is the point: a contact blocked for campaigns is blocked for journeys, with no
 * second place to keep in sync.
 */
function journey_is_blocklisted(string $email): bool {
    static $set = null;
    if ($set === null) {
        $set = function_exists('blocklisted_emails') ? blocklisted_emails() : [];
    }
    return isset($set[strtolower($email)]);
}

/**
 * WhatsApp reachability. Opt-in is NOT required — Meta's rules make a
 * template-category decision, not a per-contact gate, and wa_optins is an
 * observation table here rather than a permission list. A number is reachable
 * when it looks like a dialable number and is not opted OUT.
 */
/**
 * Has this number opted out of WhatsApp?
 *
 * Split out of journey_wa_reachable() because the two questions are genuinely different:
 * reachability also requires a dialable number, whereas the dispatch gate has already
 * established there is a number and only wants to know about consent.
 */
function journey_wa_opted_out(string $phone): bool {
    global $conn;
    $digits = preg_replace('/\D+/', '', (string)$phone);
    if (strlen($digits) < 10) return false;
    $esc = $conn->real_escape_string($digits);
    $r = @$conn->query("SELECT 1 FROM wa_optins
                         WHERE REPLACE(REPLACE(phone,'+',''),' ','') LIKE '%$esc'
                           AND status = 'optout' LIMIT 1");
    return (bool)($r && $r->num_rows > 0);
}

function journey_wa_reachable(string $phone): bool {
    global $conn;
    $digits = preg_replace('/\D+/', '', $phone);
    if (strlen($digits) < 10) return false;
    $esc = $conn->real_escape_string($digits);
    /*
     * 'optout', not 'opted_out'. The column is ENUM('optin','optout') (whatsapp/lib/schema.php),
     * so the old spelling matched nothing in MySQL's non-strict comparison and this function
     * returned "reachable" for every number ever — including everyone who had replied STOP.
     * Journeys were the one path that ignored an opt-out; campaigns always read the same table
     * through wa_optin_map() and got it right.
     */
    $r = @$conn->query("SELECT 1 FROM wa_optins
                         WHERE REPLACE(REPLACE(phone,'+',''),' ','') LIKE '%$esc'
                           AND status = 'optout' LIMIT 1");
    return !($r && $r->num_rows > 0);
}

function journey_cond_log(string $msg): void {
    if (function_exists('journey_log')) { journey_log('[cond] ' . $msg); return; }
    error_log('[journey/cond] ' . $msg);
}

<?php
/*
 * /api/journeys/lib/ContactActivity.php
 *
 * The Contact-activity trigger: "start the journey when a contact is added, listed, or
 * updated". Netcore's three options, and the one place they are implemented.
 *
 * ── Why this file exists separately from JourneyConditions.php ───────────────
 * Two of the three options poll a table (campaign_contacts, campaign_list_members) the
 * same way an app event is polled, and could have lived beside them. The third cannot:
 *
 *   "Contact is updated, specific attribute X"
 *
 * is a question about a CHANGE, and nothing in this platform records changes to contact
 * attribute values. campaign_contacts.updated_at says the row moved; it does not say
 * which attribute moved, and campaign_attribute_data is a wide overwrite-in-place table
 * with no history at all. Answering "X changed" from that data is impossible — the best
 * a poller can do is "the row moved and X currently holds this value", which fires for
 * everyone whose city was already Pune the moment their phone number is corrected.
 *
 * So this file also owns a small append-only ledger, journey_contact_updates, and the two
 * code paths that actually change contact attribute values write one row each:
 *
 *   lists/lib/ContactImportWorker.php   every CSV import, per attribute per contact
 *   journeys/lib/JourneyEngine.php      the Update-attribute step
 *
 * A specific-attribute trigger reads the ledger and is therefore exact. An Any-attribute
 * trigger reads campaign_contacts.updated_at, because "something about this contact
 * changed" is exactly what that column means and no ledger is needed to answer it.
 *
 * The ledger is required by ContactImportWorker, which knows nothing else about journeys,
 * so everything here is defensive: a missing table logs and returns instead of throwing,
 * and an import must never fail because a journey table is not there yet.
 */

/*
 * campaign_contacts is utf8mb4_unicode_ci and `users` is utf8mb4_general_ci. Joining the
 * two on email without a COLLATE raises MySQL error #1267 — the same wall the list
 * trigger hit in JourneyEngine.php. Every join below goes through this constant so there
 * is one place to change it if either table is ever converted.
 */
if (!defined('JOURNEY_CONTACT_EMAIL_JOIN')) {
    define('JOURNEY_CONTACT_EMAIL_JOIN', 'COLLATE utf8mb4_general_ci');
}

/** Idempotent, and cheap after the first call in a request. */
function journey_contact_updates_ensure_table(): void {
    global $conn;
    static $done = false;
    if ($done || !$conn) return;
    $done = true;
    @$conn->query("CREATE TABLE IF NOT EXISTS journey_contact_updates (
        id          BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        email       VARCHAR(255) NOT NULL,
        user_id     BIGINT UNSIGNED DEFAULT NULL,
        attribute   VARCHAR(100) NOT NULL,
        new_value   VARCHAR(500) DEFAULT NULL,
        source      VARCHAR(32) NOT NULL DEFAULT 'import',
        occurred_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_attr_time (attribute, occurred_at),
        INDEX idx_time (occurred_at),
        INDEX idx_email (email)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
}

/**
 * Record that one attribute on one contact took a new value.
 *
 * Called from the import worker and from the Update-attribute step. Deliberately silent
 * on every failure: this is observation, and an import or a live journey must never break
 * because the ledger could not be written.
 *
 * @param string $source 'import' | 'journey' | 'manual'
 */
function journey_contact_log_update(string $email, string $attribute, ?string $value,
                                    string $source = 'import', ?int $userId = null): void {
    global $conn;
    if (!$conn) return;
    $email = trim($email);
    $attribute = strtoupper(trim($attribute));
    if ($email === '' || $attribute === '') return;

    journey_contact_updates_ensure_table();

    $stmt = @$conn->prepare("INSERT INTO journey_contact_updates (email, user_id, attribute, new_value, source)
                             VALUES (?,?,?,?,?)");
    if (!$stmt) return;
    $uid = $userId !== null && $userId > 0 ? $userId : null;
    $val = $value === null ? null : mb_substr($value, 0, 500);
    $stmt->bind_param('sisss', $email, $uid, $attribute, $val, $source);
    @$stmt->execute();
    $stmt->close();
}

/**
 * Trim the ledger. Called once per worker tick from journey_tick(); a contact-attribute
 * change is only ever interesting to a trigger for as long as the watermark could still
 * be behind it, and 90 days is far past any realistic worker outage.
 */
function journey_contact_updates_prune(int $keepDays = 90): void {
    global $conn;
    if (!$conn) return;
    // Once an hour is plenty — this is housekeeping, not part of the tick's real work.
    static $lastRun = 0;
    if (time() - $lastRun < 3600) return;
    $lastRun = time();
    @$conn->query("DELETE FROM journey_contact_updates
                    WHERE occurred_at < DATE_SUB(NOW(), INTERVAL " . max(1, $keepDays) . " DAY)
                    LIMIT 5000");
}

/* ════════════════════════════════════════════════════════════════════════════
   Reading — one function per option, all returning the same
   [['user_id'=>int, 'email'=>string, 'at'=>'Y-m-d H:i:s'], …] shape the
   watermark poller in JourneyEngine.php consumes, oldest first.
   ═══════════════════════════════════════════════════════════════════════════ */

/**
 * Contacts created since the watermark.
 *
 * INNER JOIN to users, not LEFT: a journey step personalises, messages and reports against
 * a student, and an imported address with no account behind it has none. Those contacts are
 * counted in `skipped` so the reason a 900-row import enrolled 300 people is visible rather
 * than being read as a broken trigger.
 */
function journey_contact_rows_added(string $since, string $until, int $limit): array {
    global $conn;
    $s = "'" . $conn->real_escape_string($since) . "'";
    $u = "'" . $conn->real_escape_string($until) . "'";
    $j = JOURNEY_CONTACT_EMAIL_JOIN;
    $sql = "SELECT u.user_id, c.email, c.created_at AS at
              FROM campaign_contacts c
              INNER JOIN users u ON c.email $j = u.email
             WHERE c.created_at > $s AND c.created_at <= $u
             ORDER BY c.created_at ASC LIMIT " . (int)$limit;
    return journey_contact_fetch($sql, 'contact added');
}

/**
 * Contacts added to a list since the watermark.
 *
 * $listIds empty means Any List. The blocklist is excluded from Any List on purpose:
 * being blocked is not an event anybody wants to start a marketing journey on, and an
 * Any-List trigger that enrols every hard bounce is a trap rather than a feature. Naming
 * the blocklist explicitly still works, for the journey that genuinely wants it.
 */
function journey_contact_rows_listed(array $listIds, string $since, string $until, int $limit): array {
    global $conn;
    $s = "'" . $conn->real_escape_string($since) . "'";
    $u = "'" . $conn->real_escape_string($until) . "'";
    $j = JOURNEY_CONTACT_EMAIL_JOIN;

    if ($listIds) {
        $filter = 'AND m.list_id IN (' . implode(',', array_map('intval', $listIds)) . ')';
    } else {
        $filter = "AND l.kind <> 'blocklist'";
    }

    $sql = "SELECT u.user_id, c.email, m.added_at AS at
              FROM campaign_list_members m
              INNER JOIN campaign_contacts c ON c.id = m.contact_id
              INNER JOIN campaign_lists l ON l.id = m.list_id
              INNER JOIN users u ON c.email $j = u.email
             WHERE m.added_at > $s AND m.added_at <= $u $filter
             ORDER BY m.added_at ASC LIMIT " . (int)$limit;
    return journey_contact_fetch($sql, 'contact added to list');
}

/**
 * Contacts whose record changed since the watermark — the Any-Attribute case.
 *
 * `updated_at > created_at` is what separates an update from the insert that created the
 * contact. Without it every new contact fires BOTH the added-to-master trigger and the
 * updated trigger, because MySQL stamps the two columns identically on INSERT. The one
 * second of slack absorbs a row whose insert and first update land inside the same second
 * during an import.
 */
function journey_contact_rows_updated_any(string $since, string $until, int $limit): array {
    global $conn;
    $s = "'" . $conn->real_escape_string($since) . "'";
    $u = "'" . $conn->real_escape_string($until) . "'";
    $j = JOURNEY_CONTACT_EMAIL_JOIN;
    $sql = "SELECT u.user_id, c.email, c.updated_at AS at
              FROM campaign_contacts c
              INNER JOIN users u ON c.email $j = u.email
             WHERE c.updated_at > $s AND c.updated_at <= $u
               AND c.updated_at > DATE_ADD(c.created_at, INTERVAL 1 SECOND)
             ORDER BY c.updated_at ASC LIMIT " . (int)$limit;
    return journey_contact_fetch($sql, 'contact updated');
}

/**
 * One named attribute changed since the watermark — read from the ledger, so this is a
 * genuine "it changed" and not "it currently equals something".
 *
 * $value narrows further to a change that landed on that exact value ("STATUS became
 * enrolled"), which is the form the reference product's Contact value field takes.
 */
function journey_contact_rows_updated_attr(string $attribute, ?string $value,
                                           string $since, string $until, int $limit): array {
    global $conn;
    journey_contact_updates_ensure_table();

    $s = "'" . $conn->real_escape_string($since) . "'";
    $u = "'" . $conn->real_escape_string($until) . "'";
    $a = "'" . $conn->real_escape_string(strtoupper(trim($attribute))) . "'";
    $j = JOURNEY_CONTACT_EMAIL_JOIN;

    $valueFilter = '';
    if ($value !== null && trim($value) !== '') {
        $valueFilter = " AND g.new_value = '" . $conn->real_escape_string(trim($value)) . "'";
    }

    /*
     * COALESCE on user_id: the ledger stamps one when the writer knew it (the journey step
     * always does), and falls back to the join for an import, which only ever carries an
     * email. The join is LEFT so a ledger row that already knows its user_id is not thrown
     * away when `users` has no matching address — which happens whenever the account's
     * email differs from the one on the imported contact row.
     */
    $sql = "SELECT COALESCE(g.user_id, u.user_id) AS user_id, g.email, g.occurred_at AS at
              FROM journey_contact_updates g
              LEFT JOIN users u ON g.email $j = u.email
             WHERE g.attribute = $a AND g.occurred_at > $s AND g.occurred_at <= $u $valueFilter
             ORDER BY g.occurred_at ASC LIMIT " . (int)$limit;
    return journey_contact_fetch($sql, "contact attribute $attribute updated");
}

function journey_contact_fetch(string $sql, string $label): array {
    global $conn;
    $r = @$conn->query($sql);
    if ($r === false) {
        if (function_exists('journey_log')) journey_log("[contact] $label query failed: " . $conn->error);
        return [];
    }
    $out = [];
    while ($row = $r->fetch_assoc()) {
        $uid = (int)($row['user_id'] ?? 0);
        if ($uid <= 0) continue;
        $out[] = ['user_id' => $uid, 'email' => (string)($row['email'] ?? ''), 'at' => (string)$row['at']];
    }
    return $out;
}

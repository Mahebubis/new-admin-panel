-- ═══════════════════════════════════════════════════════════════════════════════
-- Journey Orchestration — schema documentation
-- ═══════════════════════════════════════════════════════════════════════════════
--
-- These tables are created idempotently at runtime by lib/schema.php
-- (journeys_ensure_schema()). This file is the readable copy, matching the
-- convention of campaigns_schema.sql and whatsapp_schema.sql. lib/schema.php is
-- the source of truth — if the two ever disagree, that file wins.
--
-- Nothing here touches the existing campaign, WhatsApp, segment or list tables.
-- The journey engine READS them (netcore_segments, campaign_lists,
-- campaign_contacts, campaign_templates, wa_templates, wa_senders, users, and the
-- ~20 domain tables behind $EVENT_SOURCE) and writes only to its own.
--
--   1  journeys                    the journey and its live settings
--   2  journey_versions            immutable graph snapshots; entries pin to one
--   3  journey_entries             one row per student per entry
--   4  journey_steps               append-only audit trail (the per-user trace)
--   5  journey_waits               the scheduler's work queue
--   6  journey_split_assignments   sticky A/B variants, outliving any single entry
--   7  journey_messages            every dispatch INCLUDING the withheld ones
--   8  journey_event_cursors       trigger watermarks (no event stream exists)
--   9  journey_business_events     backend-fired events
--  10  journey_conversions         last-click attributed goal hits
--  11  journey_node_stats          async rollups the report reads
--
-- ── Index rationale, since these are the ones that matter under load ──────────
--   journey_waits (status, wake_at)      drives the entire scheduler: the tick is
--                                        one indexed range scan per pass.
--   journey_entries (journey_id, status) the step executor's batch claim.
--   journey_messages uq_idem             NOT a performance index — it is the
--                                        correctness guarantee that two concurrent
--                                        worker ticks cannot double-send.
--   journey_messages (user_id, sent_at)  the frequency-cap count.
-- ═══════════════════════════════════════════════════════════════════════════════

CREATE TABLE IF NOT EXISTS journeys (
    id              BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name            VARCHAR(255) NOT NULL,
    tags            JSON DEFAULT NULL,                        -- max 5, enforced in the API
    status          ENUM('draft','scheduled','ongoing','paused','stopped','completed','archived','failed')
                      NOT NULL DEFAULT 'draft',

    start_at        DATETIME DEFAULT NULL,
    end_type        ENUM('never','date') NOT NULL DEFAULT 'never',
    end_at          DATETIME DEFAULT NULL,
    timezone        VARCHAR(64) NOT NULL DEFAULT 'Asia/Kolkata',

    graph           JSON NOT NULL,                            -- { nodes:{}, edges:{} }
    settings        JSON DEFAULT NULL,                        -- verbatim UI blob; engine uses the columns below

    goal_enabled      TINYINT(1) NOT NULL DEFAULT 0,
    goal_event        VARCHAR(64) DEFAULT NULL,               -- a key from $EVENT_SOURCE
    goal_window_hours INT NOT NULL DEFAULT 72,
    goal_locked_at    DATETIME DEFAULT NULL,                  -- goal freezes on first deploy

    exit_criteria          JSON DEFAULT NULL,                 -- {event, window_hours} — Braze-style journey-level exit
    entry_debounce_seconds INT NOT NULL DEFAULT 300,          -- Adobe's re-entrance block

    dnd_enabled     TINYINT(1) NOT NULL DEFAULT 0,
    dnd_config      JSON DEFAULT NULL,                        -- [{day:0..6, enabled, from:'HH:MM', to:'HH:MM'}]
    fc_enabled      TINYINT(1) NOT NULL DEFAULT 0,
    fc_max_per_day  INT NOT NULL DEFAULT 2,
    ignore_fc        TINYINT(1) NOT NULL DEFAULT 0,           -- MoEngage-style per-flow overrides
    ignore_dnd       TINYINT(1) NOT NULL DEFAULT 0,
    counts_toward_fc TINYINT(1) NOT NULL DEFAULT 1,

    control_mode    ENUM('none','percent','list') NOT NULL DEFAULT 'none',
    control_pct     INT NOT NULL DEFAULT 0,
    control_list    LONGTEXT DEFAULT NULL,

    entered_count    BIGINT UNSIGNED NOT NULL DEFAULT 0,
    active_count     BIGINT UNSIGNED NOT NULL DEFAULT 0,
    sent_count       BIGINT UNSIGNED NOT NULL DEFAULT 0,
    delivered_count  BIGINT UNSIGNED NOT NULL DEFAULT 0,
    opened_count     BIGINT UNSIGNED NOT NULL DEFAULT 0,
    clicked_count    BIGINT UNSIGNED NOT NULL DEFAULT 0,
    conversion_count BIGINT UNSIGNED NOT NULL DEFAULT 0,
    revenue          DECIMAL(14,2) NOT NULL DEFAULT 0,
    suppressed_count BIGINT UNSIGNED NOT NULL DEFAULT 0,

    current_version_id BIGINT UNSIGNED DEFAULT NULL,          -- the version the worker executes
    last_error      VARCHAR(1000) DEFAULT NULL,
    last_worker_at  DATETIME DEFAULT NULL,                    -- cron heartbeat, read by action=health

    created_by      BIGINT UNSIGNED DEFAULT NULL,
    created_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    deployed_at     DATETIME DEFAULT NULL,
    completed_at    DATETIME DEFAULT NULL,

    INDEX idx_status (status),
    INDEX idx_status_start (status, start_at),
    INDEX idx_updated (updated_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS journey_versions (
    id          BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    journey_id  BIGINT UNSIGNED NOT NULL,
    version_no  INT UNSIGNED NOT NULL,
    name        VARCHAR(255) DEFAULT NULL,
    status      VARCHAR(32) DEFAULT NULL,
    graph       JSON NOT NULL,
    settings    JSON DEFAULT NULL,
    created_by  BIGINT UNSIGNED DEFAULT NULL,
    created_at  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_journey_version (journey_id, version_no),
    INDEX idx_journey (journey_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS journey_entries (
    id            BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    journey_id    BIGINT UNSIGNED NOT NULL,
    version_id    BIGINT UNSIGNED DEFAULT NULL,
    user_id       BIGINT UNSIGNED DEFAULT NULL,
    -- Contact snapshot taken AT ENTRY: a 30-day wait must not let the profile drift
    -- out from under the message that was personalised for it.
    email         VARCHAR(255) DEFAULT NULL,
    phone         VARCHAR(50) DEFAULT NULL,
    first_name    VARCHAR(255) DEFAULT NULL,
    last_name     VARCHAR(255) DEFAULT NULL,

    status        ENUM('active','waiting','completed','exited','errored') NOT NULL DEFAULT 'active',
    current_node  VARCHAR(64) DEFAULT NULL,
    is_control    TINYINT(1) NOT NULL DEFAULT 0,

    trigger_event   VARCHAR(64) DEFAULT NULL,
    trigger_payload JSON DEFAULT NULL,
    steps_taken     INT UNSIGNED NOT NULL DEFAULT 0,
    debounce_key    VARCHAR(80) DEFAULT NULL,

    entered_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    exited_at     DATETIME DEFAULT NULL,
    exit_reason   VARCHAR(255) DEFAULT NULL,
    last_error    VARCHAR(1000) DEFAULT NULL,
    updated_at    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

    INDEX idx_journey_status (journey_id, status),
    INDEX idx_journey_user (journey_id, user_id),
    INDEX idx_user (user_id),
    INDEX idx_entered (journey_id, entered_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS journey_steps (
    id          BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    entry_id    BIGINT UNSIGNED NOT NULL,
    journey_id  BIGINT UNSIGNED NOT NULL,
    node_id     VARCHAR(64) NOT NULL,
    node_key    VARCHAR(32) NOT NULL,
    branch      VARCHAR(64) DEFAULT NULL,
    outcome     VARCHAR(32) NOT NULL DEFAULT 'ok',   -- ok|suppressed|hold|wait|exit|error
    detail      VARCHAR(500) DEFAULT NULL,
    result      JSON DEFAULT NULL,
    created_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_entry (entry_id, id),
    INDEX idx_journey_node (journey_id, node_id),
    INDEX idx_created (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS journey_waits (
    id           BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    entry_id     BIGINT UNSIGNED NOT NULL,
    journey_id   BIGINT UNSIGNED NOT NULL,
    node_id      VARCHAR(64) NOT NULL,          -- the node to run when this fires
    from_node_id VARCHAR(64) DEFAULT NULL,
    edge_id      VARCHAR(64) DEFAULT NULL,
    mode         ENUM('delay','event') NOT NULL DEFAULT 'delay',

    wake_at      DATETIME NOT NULL,
    event_key    VARCHAR(64) DEFAULT NULL,
    event_params JSON DEFAULT NULL,
    watch_from   DATETIME DEFAULT NULL,
    expires_at   DATETIME DEFAULT NULL,
    timeout_node_id VARCHAR(64) DEFAULT NULL,

    status       ENUM('pending','fired','expired','cancelled') NOT NULL DEFAULT 'pending',
    fired_at     DATETIME DEFAULT NULL,
    created_at   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,

    INDEX idx_due (status, wake_at),
    INDEX idx_entry (entry_id),
    INDEX idx_journey_status (journey_id, status),
    INDEX idx_event_watch (status, mode, event_key)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS journey_split_assignments (
    journey_id  BIGINT UNSIGNED NOT NULL,
    node_id     VARCHAR(64) NOT NULL,
    user_id     BIGINT UNSIGNED NOT NULL,
    variant     VARCHAR(32) NOT NULL,
    assigned_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (journey_id, node_id, user_id),
    INDEX idx_variant (journey_id, node_id, variant)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS journey_messages (
    id            BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    journey_id    BIGINT UNSIGNED NOT NULL,
    entry_id      BIGINT UNSIGNED NOT NULL,
    node_id       VARCHAR(64) NOT NULL,
    user_id       BIGINT UNSIGNED DEFAULT NULL,
    channel       ENUM('email','whatsapp','sms','push','webhook') NOT NULL,
    to_addr       VARCHAR(255) DEFAULT NULL,
    subject       VARCHAR(998) DEFAULT NULL,
    preview       TEXT DEFAULT NULL,
    variant       VARCHAR(32) DEFAULT NULL,

    rid           CHAR(32) NOT NULL,               -- tracking id in the pixel / click URL
    idem_key      VARCHAR(128) NOT NULL,           -- entry:node:attempt

    status        ENUM('queued','sent','failed','suppressed') NOT NULL DEFAULT 'queued',
    -- control_group | frequency_cap | dnd_hold | no_address | blocklisted |
    -- not_configured | duplicate
    suppress_reason VARCHAR(64) DEFAULT NULL,
    provider      VARCHAR(32) DEFAULT NULL,
    provider_message_id VARCHAR(255) DEFAULT NULL,
    error_message VARCHAR(500) DEFAULT NULL,
    attempts      TINYINT UNSIGNED NOT NULL DEFAULT 0,

    queued_at     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    sent_at       DATETIME DEFAULT NULL,
    delivered_at  DATETIME DEFAULT NULL,
    opened_at     DATETIME DEFAULT NULL,
    first_clicked_at DATETIME DEFAULT NULL,        -- the anchor for last-click attribution
    open_count    INT NOT NULL DEFAULT 0,
    click_count   INT NOT NULL DEFAULT 0,

    UNIQUE KEY uq_rid (rid),
    UNIQUE KEY uq_idem (idem_key),
    INDEX idx_journey_node (journey_id, node_id, status),
    INDEX idx_entry (entry_id),
    INDEX idx_user_sent (user_id, sent_at),
    INDEX idx_provider_msg (provider_message_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS journey_event_cursors (
    journey_id   BIGINT UNSIGNED NOT NULL,
    source_key   VARCHAR(64) NOT NULL,        -- event key, or 'segment' / 'list' / 'business:<name>'
    last_seen_at DATETIME DEFAULT NULL,       -- EXCLUSIVE lower bound on the next read
    last_run_at  DATETIME DEFAULT NULL,
    rows_seen    BIGINT UNSIGNED NOT NULL DEFAULT 0,
    updated_at   TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (journey_id, source_key)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS journey_business_events (
    id           BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    event_name   VARCHAR(100) NOT NULL,
    payload      JSON DEFAULT NULL,
    occurred_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    created_at   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_name_time (event_name, occurred_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS journey_conversions (
    id           BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    journey_id   BIGINT UNSIGNED NOT NULL,
    entry_id     BIGINT UNSIGNED NOT NULL,
    user_id      BIGINT UNSIGNED NOT NULL,
    node_id      VARCHAR(64) DEFAULT NULL,     -- the message that got the last click
    message_id   BIGINT UNSIGNED DEFAULT NULL,
    event_key    VARCHAR(64) NOT NULL,
    is_control   TINYINT(1) NOT NULL DEFAULT 0,
    revenue      DECIMAL(14,2) NOT NULL DEFAULT 0,
    converted_at DATETIME NOT NULL,
    created_at   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_entry_event (entry_id, event_key),
    INDEX idx_journey (journey_id, converted_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS journey_node_stats (
    journey_id  BIGINT UNSIGNED NOT NULL,
    node_id     VARCHAR(64) NOT NULL,
    stat_date   DATE NOT NULL,
    entered     BIGINT UNSIGNED NOT NULL DEFAULT 0,
    sent        BIGINT UNSIGNED NOT NULL DEFAULT 0,
    delivered   BIGINT UNSIGNED NOT NULL DEFAULT 0,
    opened      BIGINT UNSIGNED NOT NULL DEFAULT 0,
    clicked     BIGINT UNSIGNED NOT NULL DEFAULT 0,
    suppressed  BIGINT UNSIGNED NOT NULL DEFAULT 0,
    failed      BIGINT UNSIGNED NOT NULL DEFAULT 0,
    waiting     BIGINT UNSIGNED NOT NULL DEFAULT 0,
    updated_at  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (journey_id, node_id, stat_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

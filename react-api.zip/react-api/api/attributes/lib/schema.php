<?php
/*
 * attributes_ensure_schema() — idempotent CREATE TABLE IF NOT EXISTS for the
 * Customer Attributes feature. Called at the top of every entrypoint in this
 * feature, mirrors campaigns/lib/schema.php's campaigns_ensure_schema().
 *
 * campaign_attributes: an attribute is either
 *   - 'system' (category), mapped to a real column in an existing table
 *     (mapped_db/mapped_table/mapped_column), correlated back to the
 *     recipient via mapped_join_col ('user_id' or 'email' — whichever exists
 *     on that same table, auto-detected at create time — see attributes.php's
 *     search_columns/create actions). Resolved live at send time, never
 *     copied/cached — see campaigns/lib/AttributeResolver.php.
 *   - 'custom' (category), backed by its OWN real column in campaign_attribute_data
 *     (one wide table, one column per custom attribute, keyed by email) — either
 *     typed in manually or (most commonly) auto-populated from an unrecognized CSV
 *     column during a Lists import (see lists/lib/ContactImportWorker.php's
 *     contact_upsert()/fan_out_extra_attributes()). Each new custom attribute gets
 *     its column added via ALTER TABLE the moment it's created.
 */
function attributes_ensure_schema() {
    global $conn;
    if (!$conn) return;

    try {
        $conn->query("CREATE TABLE IF NOT EXISTS campaign_attributes (
            id              INT AUTO_INCREMENT PRIMARY KEY,
            name            VARCHAR(100) NOT NULL,
            category        ENUM('custom','system') NOT NULL DEFAULT 'custom',
            data_type       ENUM('text','number','date','url','boolean') NOT NULL DEFAULT 'text',
            mapped_db       VARCHAR(64)  DEFAULT NULL,
            mapped_table    VARCHAR(128) DEFAULT NULL,
            mapped_column   VARCHAR(128) DEFAULT NULL,
            mapped_join_col VARCHAR(32)  DEFAULT NULL,
            default_value   VARCHAR(500) DEFAULT NULL,
            created_by      BIGINT UNSIGNED DEFAULT NULL,
            created_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            UNIQUE INDEX uq_name (name)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

        // One real column per custom attribute (added dynamically via ALTER TABLE — see
        // attribute_data_ensure_column() below), one row per email. This is what backs
        // every 'custom' (unmapped) attribute — a system-mapped attribute never touches
        // this table at all, its data lives in its own real source table instead.
        $conn->query("CREATE TABLE IF NOT EXISTS campaign_attribute_data (
            email VARCHAR(255) NOT NULL,
            PRIMARY KEY (email)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

        $conn->query("CREATE TABLE IF NOT EXISTS campaign_attribute_logs (
            id              BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            attribute_id    INT DEFAULT NULL,
            attribute_name  VARCHAR(100) NOT NULL,
            action          VARCHAR(100) NOT NULL,
            username        VARCHAR(100) DEFAULT NULL,
            status          ENUM('processed','failed') NOT NULL DEFAULT 'processed',
            created_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_created_at (created_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    } catch (\Throwable $e) {
        // Another concurrent request is doing this exact same idempotent setup right now —
        // every statement above is CREATE-IF-NOT-EXISTS, so whichever request finishes first
        // still leaves the schema correct; this request just continues instead of fatal-erroring.
        error_log('attributes_ensure_schema: ' . $e->getMessage());
    }
}

/** Normalizes a user-typed or CSV-header attribute name into the upper_snake_case form
 *  used in its XX_{name}_XX token — so "First Name" / "first-name" / "First_Name" all
 *  become FIRST_NAME. Shared by attributes.php (manual create) and
 *  lists/lib/ContactImportWorker.php (auto-create from an unrecognized CSV column). */
function normalize_attribute_name(string $raw): string {
    $s = strtoupper(trim($raw));
    $s = preg_replace('/[^A-Z0-9]+/', '_', $s);
    return trim($s, '_');
}

/** MySQL identifiers cap at 64 chars — campaign_attributes.name allows up to 100, so the
 *  physical column in campaign_attribute_data uses a truncated form. Truncation collisions
 *  are extremely unlikely in practice and are a pre-existing risk of this approach; not
 *  guarded against further since campaign_attributes.name itself is already unique. */
function attribute_column_name(string $attributeName): string {
    return substr($attributeName, 0, 64);
}

/** Idempotently adds a TEXT column to campaign_attribute_data for one custom (unmapped)
 *  attribute — called once when the attribute is first created (manually, or auto-created
 *  from an unrecognized CSV column) so the column always exists before anything tries to
 *  write or read it. */
function attribute_data_ensure_column(string $attributeName): void {
    global $conn;
    $col = attribute_column_name($attributeName);
    $colE = $conn->real_escape_string($col);
    $chk = $conn->query("SHOW COLUMNS FROM campaign_attribute_data LIKE '$colE'");
    if ($chk && $chk->num_rows === 0) {
        $conn->query("ALTER TABLE campaign_attribute_data ADD COLUMN `$col` TEXT DEFAULT NULL");
    }
}

/** Writes one row to campaign_attribute_logs — every create/edit/delete/auto-create goes
 *  through here so the Attribute Logs screen has a single consistent source. */
function attribute_log(?int $attributeId, string $attributeName, string $action, ?string $username, string $status = 'processed') {
    global $conn;
    $nameE = $conn->real_escape_string($attributeName);
    $actionE = $conn->real_escape_string($action);
    $userE = $username !== null ? "'" . $conn->real_escape_string($username) . "'" : 'NULL';
    $idSql = $attributeId !== null ? (int)$attributeId : 'NULL';
    $statusE = $conn->real_escape_string($status);
    $conn->query("INSERT INTO campaign_attribute_logs (attribute_id, attribute_name, action, username, status)
                  VALUES ($idSql, '$nameE', '$actionE', $userE, '$statusE')");
}

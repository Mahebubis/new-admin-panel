<?php
/*
 * /api/attributes/attributes.php
 *
 * action=list            &page &per_page &search   → paginated campaign_attributes
 * action=get              &id                       → single attribute row
 * action=search_columns   &q                         → cross-database column search for the mapping picker
 * action=create           &name &data_type &default_value
 *                          [&mapped_db &mapped_table &mapped_column]
 * action=update           &id &default_value [&name — only if still unmapped]
 * action=delete           &id
 * action=logs             &page &per_page            → paginated campaign_attribute_logs
 */
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../middleware/auth.php';
require_once __DIR__ . '/lib/schema.php';

attributes_ensure_schema();

$jwt = require_jwt();
require_permission('netcore_behaviour', $jwt);

function jin($k, $d = null) { $v = $_REQUEST[$k] ?? null; return ($v === null || $v === '') ? $d : $v; }

// Databases this feature is allowed to map attributes against — all 3 live on the same
// MySQL server (see config/database.php's DB_HOST comment), so a single connection can
// query any of them via db.table qualification.
const ATTRIBUTES_SEARCHABLE_DBS = ['istudio_cit', 'istudio_exam', 'istudio_main'];

/** Which of 'user_id' / 'email' (in that priority order) exists as a real column on
 *  $db.$table — the join key used to correlate that table's row back to a recipient.
 *  Returns null if neither exists (table can't be used as an attribute source). */
function detect_join_column(string $db, string $table): ?string {
    global $conn;
    $dbE = $conn->real_escape_string($db);
    $tableE = $conn->real_escape_string($table);
    $r = $conn->query("SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS
                        WHERE TABLE_SCHEMA='$dbE' AND TABLE_NAME='$tableE'
                          AND COLUMN_NAME IN ('user_id','email')");
    $found = [];
    while ($r && $row = $r->fetch_assoc()) $found[$row['COLUMN_NAME']] = true;
    if (isset($found['user_id'])) return 'user_id';
    if (isset($found['email'])) return 'email';
    return null;
}

$action = jin('action', '');

if ($action === 'list') {
    $page    = max(1, (int)jin('page', 1));
    $perPage = max(1, min(100, (int)jin('per_page', 25)));
    $search  = trim((string)jin('search', ''));
    $offset  = ($page - 1) * $perPage;

    $where = '';
    if ($search !== '') $where = "WHERE name LIKE '%" . $conn->real_escape_string($search) . "%'";

    $tr = $conn->query("SELECT COUNT(*) AS c FROM campaign_attributes $where");
    $total = $tr ? (int)$tr->fetch_assoc()['c'] : 0;

    $r = $conn->query("SELECT id, name, category, data_type, mapped_db, mapped_table, mapped_column, mapped_join_col, default_value, created_at, updated_at
                        FROM campaign_attributes $where
                        ORDER BY id DESC LIMIT $perPage OFFSET $offset");
    $rows = [];
    while ($r && $row = $r->fetch_assoc()) $rows[] = $row;

    api_success([
        'attributes' => $rows, 'total' => $total, 'page' => $page, 'per_page' => $perPage,
        'pages' => $total > 0 ? (int)ceil($total / $perPage) : 1,
    ]);
}

if ($action === 'get') {
    $id = (int)jin('id', 0);
    $r = $conn->query("SELECT * FROM campaign_attributes WHERE id=$id LIMIT 1");
    $row = $r ? $r->fetch_assoc() : null;
    if (!$row) api_error('Not found', 404);
    api_success(['attribute' => $row]);
}

if ($action === 'search_columns') {
    $q = trim((string)jin('q', ''));
    if (strlen($q) < 2) api_success(['results' => []]);
    $qE = $conn->real_escape_string($q);

    $dbList = implode(',', array_map(fn($d) => "'" . $conn->real_escape_string($d) . "'", ATTRIBUTES_SEARCHABLE_DBS));
    $r = $conn->query("SELECT TABLE_SCHEMA AS db, TABLE_NAME AS tbl, COLUMN_NAME AS col, DATA_TYPE AS data_type
                        FROM INFORMATION_SCHEMA.COLUMNS
                        WHERE TABLE_SCHEMA IN ($dbList)
                          AND (COLUMN_NAME LIKE '%$qE%' OR TABLE_NAME LIKE '%$qE%')
                        ORDER BY TABLE_NAME, COLUMN_NAME
                        LIMIT 200");

    // Group by table first so we only run detect_join_column() once per distinct table,
    // not once per matching column.
    $byTable = [];
    while ($r && $row = $r->fetch_assoc()) {
        $key = $row['db'] . '.' . $row['tbl'];
        $byTable[$key]['db'] = $row['db'];
        $byTable[$key]['table'] = $row['tbl'];
        $byTable[$key]['columns'][] = ['column' => $row['col'], 'data_type' => $row['data_type']];
    }

    $results = [];
    foreach ($byTable as $t) {
        $joinCol = detect_join_column($t['db'], $t['table']);
        if (!$joinCol) continue; // no user_id/email on this table — can't correlate to a recipient
        foreach ($t['columns'] as $c) {
            if ($c['column'] === $joinCol) continue; // don't offer the join key itself as a value column
            $results[] = ['db' => $t['db'], 'table' => $t['table'], 'column' => $c['column'], 'data_type' => $c['data_type'], 'join_col' => $joinCol];
        }
    }
    api_success(['results' => array_slice($results, 0, 100)]);
}

if ($action === 'create') {
    $rawName = trim((string)jin('name', ''));
    $dataType = jin('data_type', 'text');
    $defaultValue = jin('default_value', null);
    $mappedDb = trim((string)jin('mapped_db', ''));
    $mappedTable = trim((string)jin('mapped_table', ''));
    $mappedColumn = trim((string)jin('mapped_column', ''));

    if ($rawName === '') api_error('Attribute name required');
    $name = normalize_attribute_name($rawName);
    if ($name === '') api_error('Attribute name must contain at least one letter or number');
    if (!in_array($dataType, ['text', 'number', 'date', 'url', 'boolean'], true)) $dataType = 'text';

    $existing = $conn->query("SELECT id FROM campaign_attributes WHERE name='" . $conn->real_escape_string($name) . "' LIMIT 1");
    if ($existing && $existing->num_rows > 0) api_error("An attribute named $name already exists");

    $category = 'custom';
    $joinCol = null;
    if ($mappedDb !== '' && $mappedTable !== '' && $mappedColumn !== '') {
        if (!in_array($mappedDb, ATTRIBUTES_SEARCHABLE_DBS, true)) api_error('Invalid database');
        // Never trust the client's earlier search_columns response blindly — re-verify
        // server-side that this exact column really exists before wiring it up.
        $dbE = $conn->real_escape_string($mappedDb);
        $tableE = $conn->real_escape_string($mappedTable);
        $colE = $conn->real_escape_string($mappedColumn);
        $chk = $conn->query("SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS
                              WHERE TABLE_SCHEMA='$dbE' AND TABLE_NAME='$tableE' AND COLUMN_NAME='$colE'");
        if (!$chk || $chk->num_rows === 0) api_error('That table/column no longer exists');
        $joinCol = detect_join_column($mappedDb, $mappedTable);
        if (!$joinCol) api_error('That table has no user_id or email column to match it back to a recipient');
        $category = 'system';
    }

    $nameE = $conn->real_escape_string($name);
    $catE = $conn->real_escape_string($category);
    $typeE = $conn->real_escape_string($dataType);
    $defaultE = $defaultValue !== null ? "'" . $conn->real_escape_string($defaultValue) . "'" : 'NULL';
    $mDbE = $category === 'system' ? "'" . $conn->real_escape_string($mappedDb) . "'" : 'NULL';
    $mTableE = $category === 'system' ? "'" . $conn->real_escape_string($mappedTable) . "'" : 'NULL';
    $mColE = $category === 'system' ? "'" . $conn->real_escape_string($mappedColumn) . "'" : 'NULL';
    $mJoinE = $joinCol !== null ? "'" . $conn->real_escape_string($joinCol) . "'" : 'NULL';

    $conn->query("INSERT INTO campaign_attributes (name, category, data_type, mapped_db, mapped_table, mapped_column, mapped_join_col, default_value, created_by)
                  VALUES ('$nameE', '$catE', '$typeE', $mDbE, $mTableE, $mColE, $mJoinE, $defaultE, " . (int)($jwt['user_id'] ?? 0) . ")");
    $id = $conn->insert_id;
    if ($category === 'custom') attribute_data_ensure_column($name);
    attribute_log($id, $name, 'Attribute created', (string)($jwt['user_id'] ?? ''));
    api_success(['id' => $id, 'name' => $name]);
}

if ($action === 'update') {
    $id = (int)jin('id', 0);
    if (!$id) api_error('id required');
    $r = $conn->query("SELECT * FROM campaign_attributes WHERE id=$id LIMIT 1");
    $row = $r ? $r->fetch_assoc() : null;
    if (!$row) api_error('Not found', 404);

    $set = [];
    $defaultValue = jin('default_value', null);
    if ($defaultValue !== null) $set[] = "default_value='" . $conn->real_escape_string($defaultValue) . "'";

    // Renaming is only allowed while the attribute is still unmapped — once mapped, the
    // name (and its token) is locked, matching the reference product's own rule that a
    // mapped attribute "cannot be unmapped or changed".
    $rawName = jin('name', null);
    if ($rawName !== null && $row['category'] !== 'system') {
        $name = normalize_attribute_name($rawName);
        if ($name === '') api_error('Attribute name must contain at least one letter or number');
        $dup = $conn->query("SELECT id FROM campaign_attributes WHERE name='" . $conn->real_escape_string($name) . "' AND id<>$id LIMIT 1");
        if ($dup && $dup->num_rows > 0) api_error("An attribute named $name already exists");
        $set[] = "name='" . $conn->real_escape_string($name) . "'";
    }

    // "Select existing attribute" flow (CreateAttributeModal.jsx's second tab) — attach a
    // table.column mapping to an attribute that already exists (commonly a 'custom' one
    // auto-created from a CSV import), turning it into a 'system' attribute in place,
    // instead of creating a brand-new duplicate attribute for the same data.
    $mappedDb = trim((string)jin('mapped_db', ''));
    $mappedTable = trim((string)jin('mapped_table', ''));
    $mappedColumn = trim((string)jin('mapped_column', ''));
    if ($mappedDb !== '' && $mappedTable !== '' && $mappedColumn !== '') {
        if ($row['category'] === 'system') api_error('This attribute is already mapped — mappings cannot be changed once set');
        if (!in_array($mappedDb, ATTRIBUTES_SEARCHABLE_DBS, true)) api_error('Invalid database');
        $dbE = $conn->real_escape_string($mappedDb);
        $tableE = $conn->real_escape_string($mappedTable);
        $colE = $conn->real_escape_string($mappedColumn);
        $chk = $conn->query("SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS
                              WHERE TABLE_SCHEMA='$dbE' AND TABLE_NAME='$tableE' AND COLUMN_NAME='$colE'");
        if (!$chk || $chk->num_rows === 0) api_error('That table/column no longer exists');
        $joinCol = detect_join_column($mappedDb, $mappedTable);
        if (!$joinCol) api_error('That table has no user_id or email column to match it back to a recipient');

        $set[] = "category='system'";
        $set[] = "mapped_db='$dbE'";
        $set[] = "mapped_table='$tableE'";
        $set[] = "mapped_column='$colE'";
        $set[] = "mapped_join_col='" . $conn->real_escape_string($joinCol) . "'";
    }

    if ($set) $conn->query("UPDATE campaign_attributes SET " . implode(', ', $set) . " WHERE id=$id");
    attribute_log($id, $row['name'], 'Attribute edited', (string)($jwt['user_id'] ?? ''));
    api_success([]);
}

if ($action === 'delete') {
    $id = (int)jin('id', 0);
    if (!$id) api_error('id required');
    $r = $conn->query("SELECT name FROM campaign_attributes WHERE id=$id LIMIT 1");
    $row = $r ? $r->fetch_assoc() : null;
    if (!$row) api_error('Not found', 404);

    $conn->query("DELETE FROM campaign_attributes WHERE id=$id"); // FK cascade clears campaign_attribute_values
    attribute_log(null, $row['name'], 'Attribute deleted', (string)($jwt['user_id'] ?? ''));
    api_success([]);
}

if ($action === 'logs') {
    $page    = max(1, (int)jin('page', 1));
    $perPage = max(1, min(100, (int)jin('per_page', 25)));
    $offset  = ($page - 1) * $perPage;

    $tr = $conn->query("SELECT COUNT(*) AS c FROM campaign_attribute_logs");
    $total = $tr ? (int)$tr->fetch_assoc()['c'] : 0;

    $r = $conn->query("SELECT id, attribute_id, attribute_name, action, username, status, created_at
                        FROM campaign_attribute_logs
                        ORDER BY id DESC LIMIT $perPage OFFSET $offset");
    $rows = [];
    while ($r && $row = $r->fetch_assoc()) $rows[] = $row;

    api_success([
        'logs' => $rows, 'total' => $total, 'page' => $page, 'per_page' => $perPage,
        'pages' => $total > 0 ? (int)ceil($total / $perPage) : 1,
    ]);
}

api_error('Invalid action');

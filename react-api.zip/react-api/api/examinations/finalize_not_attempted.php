<?php
/**
 * Bulk-finalizes students who started an exam but never finished it
 * (the "Not Attempted Exam" list). Called once per CSV packet (<=1000
 * emails) from the frontend upload feature.
 *
 * For each email that still has an open, unscored attempt (same criteria
 * as not_attempted_exam.php's list), this scores it from cit_exam_data.data
 * using the option_id -> cit_options.is_correct match, then writes one row
 * each into cit_results (with not_attempted='yes') and result.
 */
ini_set('display_errors',0);
ob_start();
chdir('/home/istudio/public_html/cit/common');
include '/home/istudio/public_html/cit/common/helper.php';
ob_clean();

header('Content-Type: application/json');

global $conn;

if(!$conn){
    echo json_encode(["success"=>false,"message"=>"DB Connection Failed"]);
    exit;
}

$action=$_POST['action']??'';

if($action!=="finalize_chunk"){
    echo json_encode(["success"=>false,"message"=>"Invalid Action"]);
    exit;
}

$emails=json_decode($_POST['emails']??'', true);
if(!is_array($emails) || empty($emails)){
    echo json_encode(["success"=>false,"message"=>"No emails provided"]);
    exit;
}

// Hard cap defensively -- the frontend already sends packets of 1000.
$emails=array_slice(array_values(array_unique(array_map('trim', $emails))), 0, 1000);
$emails=array_filter($emails, fn($e)=>$e!=="");
if(empty($emails)){
    echo json_encode(["success"=>false,"message"=>"No emails provided"]);
    exit;
}

$citVersion=trim((string)fetch_setting('current_cit_version'));
if($citVersion===""){
    echo json_encode(["success"=>false,"message"=>"settings.current_cit_version is not set"]);
    exit;
}
$citVersionEsc=$conn->real_escape_string($citVersion);

$result=[
    "success"=>true,
    "processed"=>count($emails),
    "inserted"=>0,
    "already_finalized"=>0,
    "no_open_attempt"=>0,
    "not_found"=>0,
    "not_found_emails"=>[],
    "already_finalized_emails"=>[],
    "no_open_attempt_emails"=>[],
];

// ---- Step A: resolve emails -> user_id ----
$emailList=implode(',', array_map(fn($e)=>"'".$conn->real_escape_string($e)."'", $emails));

$emailToUser=[];
$r=$conn->query("SELECT user_id, email FROM users WHERE email IN ($emailList)");
if($r){
    while($row=$r->fetch_assoc()){
        $emailToUser[strtolower(trim($row['email']))]=(int)$row['user_id'];
    }
}

$userIdToEmail=[];
$userIds=[];
foreach($emails as $e){
    $key=strtolower(trim($e));
    if(isset($emailToUser[$key])){
        $uid=$emailToUser[$key];
        $userIds[]=$uid;
        $userIdToEmail[$uid]=$e;
    }else{
        $result['not_found']++;
        $result['not_found_emails'][]=$e;
    }
}
$userIds=array_values(array_unique($userIds));

if(empty($userIds)){
    echo json_encode($result);
    exit;
}

$userIdList=implode(',', array_map('intval', $userIds));

// ---- Step B: eligible = still-open attempt, not yet in cit_results ----
// GROUP BY collapses duplicate cit_exam_login rows for the same
// user/exam (seen in production -- same hash logged multiple times).
$eligible=[];
$q=$conn->query("
    SELECT l.user_id, l.exam_id, MIN(d.data) AS data
    FROM cit_exam_login l
    JOIN cit_exam_data d ON d.user_id=l.user_id AND d.exam_id=l.exam_id
    WHERE l.user_id IN ($userIdList)
    AND l.start_exam IS NOT NULL
    AND l.end_exam IS NULL
    AND NOT EXISTS (
        SELECT 1 FROM cit_results cr
        WHERE cr.user_id=l.user_id AND cr.exam_id=l.exam_id
    )
    GROUP BY l.user_id, l.exam_id
");
if($q){
    while($row=$q->fetch_assoc()){
        $eligible[]=$row;
    }
}

$eligibleUserIds=[];
foreach($eligible as $row){ $eligibleUserIds[(int)$row['user_id']]=true; }

// ---- Step C: matched users who are NOT eligible -- figure out why ----
$nonEligibleUserIds=array_diff($userIds, array_keys($eligibleUserIds));
if(!empty($nonEligibleUserIds)){
    $neList=implode(',', array_map('intval', $nonEligibleUserIds));
    $alreadyDone=[];
    $rr=$conn->query("SELECT DISTINCT user_id FROM cit_results WHERE user_id IN ($neList)");
    if($rr){ while($x=$rr->fetch_assoc()){ $alreadyDone[(int)$x['user_id']]=true; } }

    foreach($nonEligibleUserIds as $uid){
        $email=$userIdToEmail[$uid] ?? null;
        if(isset($alreadyDone[$uid])){
            $result['already_finalized']++;
            if($email) $result['already_finalized_emails'][]=$email;
        }else{
            $result['no_open_attempt']++;
            if($email) $result['no_open_attempt_emails'][]=$email;
        }
    }
}

if(empty($eligible)){
    echo json_encode($result);
    exit;
}

// ---- Step D: decode answers, collect option_ids + exam_ids for this batch ----
$oids=[];
$examIds=[];
foreach($eligible as &$row){
    $answers=json_decode($row['data'], true);
    $parsed=[];
    if(is_array($answers)){
        foreach($answers as $ans){
            if($ans===null || trim((string)$ans)==="") continue;
            $oid=(int)$ans;
            $parsed[]=$oid;
            $oids[$oid]=true;
        }
    }
    $row['_answers']=$parsed;
    $examIds[(int)$row['exam_id']]=true;
}
unset($row);

$correctMap=[];
if(!empty($oids)){
    $oidList=implode(',', array_map('intval', array_keys($oids)));
    $q2=$conn->query("SELECT option_id, is_correct FROM cit_options WHERE option_id IN ($oidList)");
    if($q2){ while($o=$q2->fetch_assoc()){ $correctMap[(int)$o['option_id']]=(int)$o['is_correct']; } }
}

// total_questions = every question belonging to the exam (not just attempted).
$totalQMap=[];
if(!empty($examIds)){
    $eidList=implode(',', array_map('intval', array_keys($examIds)));
    $q3=$conn->query("SELECT exam_id, COUNT(*) c FROM cit_questions WHERE exam_id IN ($eidList) GROUP BY exam_id");
    if($q3){ while($o=$q3->fetch_assoc()){ $totalQMap[(int)$o['exam_id']]=(int)$o['c']; } }
}

// ---- Step E: score each eligible row, batch-insert both tables ----
$now=date('Y-m-d H:i:s');
$crRows=[];
$resultRows=[];

foreach($eligible as $row){
    $uid=(int)$row['user_id'];
    $eid=(int)$row['exam_id'];
    $right=0; $wrong=0;

    foreach($row['_answers'] as $oid){
        if(isset($correctMap[$oid]) && $correctMap[$oid]===1){ $right++; } else { $wrong++; }
    }

    $totalQ=$totalQMap[$eid] ?? 0;
    $score=$totalQ>0 ? round(($right/$totalQ)*100, 2) : 0;

    $crRows[]="($uid,$eid,$right,$wrong,$totalQ,$score,NULL,'$now','completed','$citVersionEsc','yes')";
    $resultRows[]="($uid,$right,$wrong,$totalQ,NULL,NULL,1,1,'$now')";

    $result['inserted']++;
}

if(!empty($crRows)){
    $conn->query("
        INSERT INTO cit_results
        (user_id, exam_id, correct_answers, wrong_answers, total_questions, score, time_taken, timestamp, status, cit_version, not_attempted)
        VALUES ".implode(',', $crRows)
    );
}

if(!empty($resultRows)){
    $conn->query("
        INSERT INTO result
        (user_id, rightans, wrongans, total, rank, percentile, round, phase, created_at)
        VALUES ".implode(',', $resultRows)
    );
}

echo json_encode($result);

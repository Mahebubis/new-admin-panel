<?php
/**
 * Skeleton backend for not_attempted_exam.php
 * NOTE:
 * This file includes pagination/search and attempted counting.
 * Right/Wrong calculation logic matches each answer's selected option_id
 * (the value stored per question_id in cit_exam_data.data) against
 * cit_options.is_correct.
 */

ini_set('display_errors',0);
ob_start();
chdir('/home/istudio/public_html/cit/common');
include '/home/istudio/public_html/cit/common/helper.php';
ob_clean();

header('Content-Type: application/json');

global $conn;

if(!$conn){
    echo json_encode(["success"=>false,"message"=>"DB Connection Failed"]);
    exit;
}

$action=$_POST['action']??'';

if($action!=="fetch_all"){
    echo json_encode(["success"=>false,"message"=>"Invalid Action"]);
    exit;
}

$page=max(1,(int)($_POST['page']??1));
$per=max(1,(int)($_POST['per_page']??20));
$search=trim($_POST['search']??'');
$startDate=trim($_POST['start_date']??'');
$endDate=trim($_POST['end_date']??'');
$offset=($page-1)*$per;

$where="l.start_exam IS NOT NULL
AND l.end_exam IS NULL
AND l.start_exam>='2026-01-01 00:00:00'
AND NOT EXISTS (
    SELECT 1 FROM cit_results cr
    WHERE cr.user_id=l.user_id AND cr.exam_id=l.exam_id
)";

if($search!==""){
    $s=$conn->real_escape_string($search);
    $where.=" AND (
        u.fname LIKE '%$s%' OR
        u.lname LIKE '%$s%' OR
        u.email LIKE '%$s%' OR
        u.phone LIKE '%$s%'
    )";
}

// Optional start-date-of-exam range filter. When left blank, no range is
// applied and every matching row (all dates) is returned/exported.
if($startDate!==""){
    $sd=$conn->real_escape_string($startDate);
    $where.=" AND l.start_exam>='$sd 00:00:00'";
}
if($endDate!==""){
    $ed=$conn->real_escape_string($endDate);
    $where.=" AND l.start_exam<='$ed 23:59:59'";
}

$total=0;
$r=$conn->query("
SELECT COUNT(*) c
FROM cit_exam_login l
JOIN users u ON u.user_id=l.user_id
WHERE $where
");
if($r){ $total=(int)$r->fetch_assoc()['c']; }

$total_pages=max(1,ceil($total/$per));

$sql="
SELECT
l.user_id,
l.exam_id,
l.start_exam,
l.expected_end_exam,
u.fname,
u.lname,
u.email,
u.phone,
d.data
FROM cit_exam_login l
JOIN users u ON u.user_id=l.user_id
LEFT JOIN cit_exam_data d
ON d.user_id=l.user_id
AND d.exam_id=l.exam_id
WHERE $where
ORDER BY l.start_exam DESC
LIMIT $offset,$per
";

$res=$conn->query($sql);

// Pass 1: decode each row's answers. Each row's `data` JSON is a
// {question_id: option_id} map -- a null value means that question was
// left unanswered (skip it), a non-null value is the option_id the
// student selected. Collect every distinct option_id referenced across
// the whole result set (page or full export alike).
$data=[];
$oids=[];

while($row=$res->fetch_assoc()){

    $parsed=[];
    $answers=json_decode($row['data'],true);

    if(is_array($answers)){
        foreach($answers as $qid=>$ans){
            if($ans===null || trim((string)$ans)===""){
                continue;
            }
            $oid=(int)$ans;
            $parsed[]=$oid;
            $oids[$oid]=true;
        }
    }

    unset($row['data']);
    $row['_answers']=$parsed;
    $data[]=$row;
}

// Pass 2: ONE query fetches is_correct for every selected option_id
// needed by this whole batch, instead of one query per answered
// question per row (that N+1 pattern is what made this endpoint slow).
$correctMap=[];
if(!empty($oids)){
    $oidList=implode(',', array_map('intval', array_keys($oids)));
    $q=$conn->query("
        SELECT option_id, is_correct
        FROM cit_options
        WHERE option_id IN ($oidList)
    ");
    if($q){
        while($o=$q->fetch_assoc()){
            $correctMap[(int)$o['option_id']]=(int)$o['is_correct'];
        }
    }
}

// Pass 3: tally right/wrong per row from the in-memory map (no DB calls).
foreach($data as &$row){
    $attempted=0; $right=0; $wrong=0;

    foreach($row['_answers'] as $oid){
        $attempted++;
        if(isset($correctMap[$oid]) && $correctMap[$oid]===1){
            $right++;
        }else{
            $wrong++;
        }
    }

    $row['attempted_count']=$attempted;
    $row['right_count']=$right;
    $row['wrong_count']=$wrong;
    unset($row['_answers']);
}
unset($row);

// Pass 4: resolve each row's CIT version from exam_batch_for_reports by
// matching start_exam against [from_date, to_date] -- these incomplete
// attempts have no cit_results row yet (that's only written once an exam
// is scored), so there's no direct FK to read the version from. The still
// -open latest version's to_date has no time component (just seeded from
// exam_end_date), so it's treated as an open-ended upper bound instead of
// literal-string-compared, matching the Meta Ads Dashboard's convention.
$versionRanges=[];
$vres=$conn->query("SELECT exam_name, from_date, to_date FROM exam_batch_for_reports ORDER BY id DESC");
if($vres){
    while($vr=$vres->fetch_assoc()){
        $versionRanges[]=$vr;
    }
}

function resolveCitVersion($startExam, $versionRanges){
    foreach($versionRanges as $v){
        if($startExam < $v['from_date']) continue;
        $hasTime = (strpos((string)$v['to_date'], ':') !== false);
        if(!$hasTime || $startExam <= $v['to_date']){
            return $v['exam_name'];
        }
    }
    return null;
}

foreach($data as &$row){
    $row['cit_version']=resolveCitVersion($row['start_exam'], $versionRanges);
}
unset($row);

echo json_encode([
    "success"=>true,
    "page"=>$page,
    "per_page"=>$per,
    "total_count"=>$total,
    "total_pages"=>$total_pages,
    "data"=>$data
]);

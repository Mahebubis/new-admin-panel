<?php
/*
 * Meta WhatsApp Cloud API transport — sends without a BSP in the middle.
 *
 *   POST https://graph.facebook.com/v21.0/{phone_number_id}/messages
 *   Authorization: Bearer <Meta System User token>   (scope whatsapp_business_messaging)
 *   { "messaging_product":"whatsapp", "to":"919…", "type":"template",
 *     "template":{ "name":…, "language":{"code":…}, "components":[…] } }
 *   → 200 { "messages":[{"id":"wamid.HBg…"}] }
 *
 * Usable because both business numbers report platform_type CLOUD_API and account_mode LIVE —
 * i.e. Meta hosts them and a BSP is optional, not structural.
 *
 * This is now the ONLY transport: the Netcore BSP path was removed once both numbers were
 * confirmed as platform_type CLOUD_API.
 */
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/WaHelpers.php';

class MetaCloudTransport {
    private string $token;
    private string $phoneNumberId;
    private string $version;

    public function __construct(string $token, string $phoneNumberId, ?string $version = null) {
        $this->token         = trim($token);
        $this->phoneNumberId = trim($phoneNumberId);
        $this->version       = $version ?: WA_GRAPH_VERSION;
    }

    public function isConfigured(): bool { return $this->token !== '' && $this->phoneNumberId !== ''; }
    /** Meta has no `source` concept — delivery receipts are routed by the app's webhook. */
    public function hasSource(): bool { return true; }

    public function buildRequest(string $to, array $content, string $rid): array {
        if (($content['type'] ?? 'template') === 'text') {
            $text = (string)($content['body'] ?? '');
            $payload = [
                'messaging_product' => 'whatsapp',
                'recipient_type'    => 'individual',
                'to'                => $to,
                'type'              => 'text',
                'text'              => [
                    // Meta takes a real boolean here (Netcore wants the string "true"), and like
                    // Netcore it rejects a preview request when the body has no link.
                    'preview_url' => !empty($content['preview_url']) && preg_match('~(https?://|www\.)\S+~i', $text),
                    'body'        => $text,
                ],
            ];
        } else {
            $template = [
                'name'     => (string)($content['name'] ?? ''),
                'language' => ['code' => (string)($content['language'] ?? 'en')],
            ];
            $components = $content['components'] ?? [];
            if ($components) $template['components'] = $components;

            $payload = [
                'messaging_product' => 'whatsapp',
                'recipient_type'    => 'individual',
                'to'                => $to,
                'type'              => 'template',
                'template'          => $template,
            ];
        }

        return [
            'url'     => 'https://graph.facebook.com/' . $this->version . '/' . $this->phoneNumberId . '/messages',
            'headers' => ['Content-Type: application/json', 'Authorization: Bearer ' . $this->token],
            'body'    => json_encode($payload),
        ];
    }

    /**
     * @return array{ok: bool, message_id: ?string, error: ?string, code: ?string, retryable: bool}
     */
    public function parseResponse(int $status, ?string $body, string $curlError, ?string $rid): array {
        if ($curlError !== '') {
            return ['ok' => false, 'message_id' => null, 'error' => "Network error: $curlError", 'code' => 'network', 'retryable' => true];
        }

        $decoded = json_decode((string)$body, true);

        if ($status >= 200 && $status < 300 && isset($decoded['messages'][0]['id'])) {
            // wamid.* — the same id Meta echoes on every status webhook for this message.
            return ['ok' => true, 'message_id' => (string)$decoded['messages'][0]['id'], 'error' => null, 'code' => null, 'retryable' => false];
        }

        $err  = $decoded['error'] ?? [];
        $code = (string)($err['code'] ?? $status);
        $msg  = $err['error_user_msg'] ?? ($err['message'] ?? ($body ?: "HTTP $status"));
        $detail = $err['error_data']['details'] ?? '';
        if ($detail) $msg .= " — $detail";

        /*
         * Which failures are worth retrying. Meta's codes are specific enough to be precise:
         *   80007  business-level rate limit
         *   130429 cloud API throughput limit
         *   131056 pair rate limit (too many messages to this one person, too fast)
         *   131048 spam rate limit
         *   133016 number temporarily blocked/unregistered — transient
         * Everything else (unapproved template, bad number, no opt-in, per-user marketing cap)
         * will fail identically on a retry, so it must consume an attempt instead.
         */
        $retryableCodes = ['80007', '130429', '131056', '131048', '133016', '131000'];
        $retryable = $status === 429 || $status >= 500 || in_array($code, $retryableCodes, true);

        /*
         * ACCOUNT-level failures, translated.
         *
         * These have nothing to do with the recipient — the sending number itself is not usable,
         * so every single recipient will fail identically. Meta's own text for them is close to
         * useless ("Account not registered" says nothing about which account or what to do), and
         * the number that appears in the log line is the RECIPIENT's, which sends everyone looking
         * in exactly the wrong place. So the message is rewritten with the actual fix, and the
         * flag lets the worker stop the campaign instead of grinding the whole audience into the
         * same error one row at a time.
         */
        $account = self::accountLevelFault($code);
        if ($account !== null) {
            return ['ok' => false, 'message_id' => null, 'error' => "Meta $code: " . $account,
                    'code' => $code, 'retryable' => false, 'account_fault' => $account];
        }

        return ['ok' => false, 'message_id' => null, 'error' => "Meta $code: $msg", 'code' => $code, 'retryable' => $retryable];
    }

    /**
     * Plain-English cause + fix for the Meta codes that mean "this SENDING NUMBER cannot send",
     * or null when the code is about one recipient.
     *
     * 133010 is the one that actually bites: moving a phone number to a different WhatsApp
     * Business Account de-registers it from Cloud API, and Meta then rejects every send with a
     * message that reads like the recipient's account is the problem. The number has to be
     * registered again against the new WABA with its 6-digit two-step PIN.
     */
    public static function accountLevelFault(string $code): ?string {
        switch ($code) {
            case '133010':
                return 'this sending number is not registered on WhatsApp Cloud API. A number '
                     . 'moved to a different WhatsApp Business Account loses its registration, so it '
                     . 'has to be registered again against the new WABA. Fix: Settings → WhatsApp → '
                     . 'Sending numbers → Connect on this number, and finish the Register step with '
                     . 'its 6-digit two-step PIN.';
            case '133006':
                return 'this sending number has not been verified yet. Fix: Settings → WhatsApp → '
                     . 'Sending numbers → Connect, and complete the SMS/voice code step before registering.';
            case '133005':
                return 'the 6-digit two-step PIN was wrong. If nobody knows it, reset it in Meta '
                     . 'Business Manager → WhatsApp Manager → the number → Two-step verification, then register again.';
            case '133008':
                return 'too many wrong PIN attempts — Meta has locked registration on this number. '
                     . 'Wait for the cooldown Meta states, then try Connect again.';
            case '133009':
                return 'the two-step PIN is not in the format Meta accepts. It must be exactly 6 digits.';
            case '131031':
                return 'this WhatsApp Business Account is locked or restricted by Meta. Nothing in this '
                     . 'panel can clear it — check WhatsApp Manager → Account quality for the restriction.';
            case '200':
            case '10':
                return 'the access token cannot send from this number. Fix: Settings → WhatsApp → '
                     . 'Run diagnostics, which names the exact missing permission or asset.';
            default:
                return null;
        }
    }

    public function sendMessage(string $to, array $content, string $rid): array {
        if (!$this->isConfigured()) {
            return ['ok' => false, 'message_id' => null, 'error' => 'Meta token or phone number id missing for this sending number', 'code' => 'unconfigured', 'retryable' => false];
        }
        $req = $this->buildRequest($to, $content, $rid);
        [$status, $body, $curlErr] = wa_http_exec($req);
        return $this->parseResponse($status, $body, $curlErr, $rid);
    }
}

/**
 * Builds Meta's nested `components` array for one recipient.
 *
 * Meta is strict: a template approved with two body variables must be sent with exactly two body
 * parameters, in order. So the parameter count comes from the template's own placeholder count,
 * not from however many values happen to be filled in — a missing value becomes an empty string
 * rather than shortening the array and shifting everything after it.
 *
 * @param array $tpl      the campaign's snapshot of the template
 * @param array $resolved ['header' => [...], 'body' => [...], 'button_url_suffix' => '...']
 */
function meta_build_components(array $tpl, array $resolved): array {
    $components = [];

    $headerType = $tpl['header_type'] ?? 'none';
    if ($headerType === 'text') {
        $headerVars = wa_placeholder_count((string)($tpl['header_text'] ?? ''));
        if ($headerVars > 0) {
            $params = [];
            for ($i = 0; $i < $headerVars; $i++) {
                $params[] = ['type' => 'text', 'text' => (string)($resolved['header'][$i] ?? '')];
            }
            $components[] = ['type' => 'header', 'parameters' => $params];
        }
    } elseif (in_array($headerType, ['image', 'video', 'document'], true)) {
        $url = trim((string)($tpl['header_media_url'] ?? ''));
        if ($url !== '') {
            $components[] = ['type' => 'header', 'parameters' => [[
                'type' => $headerType, $headerType => ['link' => $url],
            ]]];
        }
    }

    $bodyVars = wa_placeholder_count((string)($tpl['body_text'] ?? ''));
    if ($bodyVars > 0) {
        $params = [];
        for ($i = 0; $i < $bodyVars; $i++) {
            $params[] = ['type' => 'text', 'text' => (string)($resolved['body'][$i] ?? '')];
        }
        $components[] = ['type' => 'body', 'parameters' => $params];
    }

    // Only a DYNAMIC url button takes a parameter. A static url or quick-reply button is baked
    // into the approved template and must NOT be sent as a component — doing so is an error.
    $buttons = $tpl['buttons'] ?? [];
    if (is_string($buttons)) $buttons = json_decode($buttons, true) ?: [];
    foreach (array_values($buttons) as $idx => $btn) {
        if (($btn['type'] ?? '') !== 'url' || empty($btn['dynamic'])) continue;
        $suffix = (string)($resolved['button_url_suffix'] ?? '');
        if ($suffix === '') continue;
        $components[] = [
            'type' => 'button', 'sub_type' => 'url', 'index' => (string)$idx,
            'parameters' => [['type' => 'text', 'text' => $suffix]],
        ];
    }

    return $components;
}

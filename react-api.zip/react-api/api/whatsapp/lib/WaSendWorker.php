<?php
/*
 * The WhatsApp campaign send pipeline: materialize audience → claim a batch → render →
 * send concurrently → write outcomes back.
 *
 * Structurally a sibling of campaigns/lib/SendWorker.php (same flock'd cron + instant-kick
 * model, same three-phase batch, same "retryable failures don't burn an attempt" rule), with
 * three WhatsApp-specific differences:
 *
 *   1. Recipients are numbers, not addresses — see WaAudienceResolver.php.
 *   2. Deduplication runs at materialize time and is recorded, not silently applied.
 *   3. `sent` means the provider ACCEPTED the message. delivered/read only ever come from
 *      the webhook — a 200 from the send API is not evidence a phone ever showed anything.
 */
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/schema.php';
require_once __DIR__ . '/WaHelpers.php';
require_once __DIR__ . '/WaLinks.php';
// Both transports, unconditionally: a single batch can contain campaigns on different routes,
// and netcore_build_attributes()/meta_build_components() are both needed at render time.
require_once __DIR__ . '/MetaCloudTransport.php';
require_once __DIR__ . '/NetcoreTransport.php';
require_once __DIR__ . '/WaParallelSender.php';
// Required at TOP LEVEL, never lazily inside a function: WaAudienceResolver pulls in the
// email pipeline's AudienceResolver, which pulls in netcore/lib/segment_sql.php, whose
// $EVENT_SOURCE/$PAYLOAD_COLUMNS are plain top-level variables. Loading that file from inside
// a function traps those arrays in the function's LOCAL scope and every segment then silently
// resolves to zero users. (This exact bug is documented in campaigns/lib/SendWorker.php.)
require_once __DIR__ . '/WaAudienceResolver.php';
require_once __DIR__ . '/../../campaigns/lib/MergeTags.php';
require_once __DIR__ . '/../../campaigns/lib/AttributeResolver.php';

/** One timestamped line per event in wa-worker.log — "did cron run", "how many numbers did it
 *  find", "what did Netcore actually say" answerable without SSH/DB access. */
function wa_log(string $msg): void {
    wa_log_rotate_if_needed();
    @file_put_contents(WA_WORKER_LOG_PATH, '[' . date('Y-m-d H:i:s') . '] ' . $msg . "\n", FILE_APPEND | LOCK_EX);
}

/**
 * Keeps wa-worker.log from growing without bound, by trimming the oldest half once it passes
 * WA_LOG_MAX_BYTES.
 *
 * Deliberately in-place rather than the usual .log.1/.log.2 rotation: on shared hosting nothing
 * cleans numbered files up, so they trade one growing file for several. Keeping the recent tail
 * in the same path means the file everyone already tails stays the file with the answers.
 *
 * The size check is sampled, not run on every call — the webhook can log several times a second,
 * and a stat() per line is pure waste when the file only crosses the threshold once a week.
 */
function wa_log_rotate_if_needed(): void {
    static $counter = 0;
    if ($counter++ % 200 !== 0) return;

    $path = WA_WORKER_LOG_PATH;
    clearstatcache(true, $path);          // filesize() is cached per request; the webhook is long-lived
    $size = @filesize($path);
    if ($size === false || $size <= WA_LOG_MAX_BYTES) return;

    $keep = intdiv(WA_LOG_MAX_BYTES, 2);
    $fp = @fopen($path, 'r');
    if (!$fp) return;
    // Seek back from the END, then discard the first (partial) line so the trimmed file never
    // starts mid-sentence.
    @fseek($fp, -$keep, SEEK_END);
    @fgets($fp);
    $tail = @stream_get_contents($fp);
    @fclose($fp);
    if ($tail === false) return;

    @file_put_contents($path,
        '[' . date('Y-m-d H:i:s') . "] --- log trimmed: older entries dropped at "
        . round($size / 1048576, 1) . " MB ---\n" . $tail, LOCK_EX);
}

/** Flip due `scheduled` campaigns to `running`. Uses PHP's clock, not MySQL's NOW() — the two
 *  can sit in different timezones on shared hosting, and scheduled_at was written with PHP's
 *  date(), so comparing against NOW() would silently shift when a campaign actually fires. */
function wa_activate_due_scheduled(): void {
    global $conn;
    $now = $conn->real_escape_string(date('Y-m-d H:i:s'));
    $dueR = $conn->query("SELECT id, name, scheduled_at FROM wa_campaigns WHERE status='scheduled' AND scheduled_at <= '$now'");
    $due = [];
    while ($dueR && $row = $dueR->fetch_assoc()) $due[] = "#{$row['id']} \"{$row['name']}\" (was due {$row['scheduled_at']})";

    static $loggedOnce = false;
    if (!$loggedOnce || $due) {
        wa_log('checking due scheduled campaigns at server-time ' . $now . ' -> ' . ($due ? implode(', ', $due) : 'none due'));
        $loggedOnce = true;
    }
    $conn->query("UPDATE wa_campaigns SET status='running', started_at=IFNULL(started_at, '$now')
                  WHERE status='scheduled' AND scheduled_at <= '$now'");
}

/**
 * Resolves the audience and writes recipient rows — run inside the background worker, not on
 * the admin's "Send now" click, so that click stays instant even for a 40k-number audience.
 *
 * Returns the number of rows actually queued (after every dedup/limit rule).
 */
/**
 * Fills in user_id on recipients that arrived without one, by matching phone then email.
 *
 * Idempotent and cheap — it only ever touches rows still NULL — so it is safe to call from the
 * materializer AND from the conversion recompute. The second caller matters: campaigns already
 * sent before this existed would otherwise be permanently uncountable, because their recipients
 * were stored with no identity to join on.
 *
 * Phone matching compares the LAST 10 DIGITS, which is what makes the two representations meet:
 * we store E.164 digits (919921079337), `users` holds whatever was typed ("+91 9921079337").
 */
function wa_backfill_recipient_user_ids(int $campaignId): void {
    global $conn;

    /*
     * The explicit COLLATE is REQUIRED, not defensive.
     *
     * `users` is an older table created under utf8mb4_general_ci; wa_campaign_recipients was
     * created with utf8mb4_unicode_ci. Comparing two IMPLICIT-collation string columns across
     * that boundary raises MySQL error #1267:
     *
     *     Illegal mix of collations (utf8mb4_general_ci,IMPLICIT)
     *                           and (utf8mb4_unicode_ci,IMPLICIT) for operation '='
     *
     * and on PHP 8.1+ mysqli throws it. An EXPLICIT collation on either side settles the
     * comparison. It goes on the RECIPIENTS side because that set is small (one campaign) while
     * users.email keeps its index for the lookup — the same reasoning, and the same fix, as the
     * ₹99-store join in netcore/lib/segment_sql.php.
     */
    $conn->query("UPDATE wa_campaign_recipients r
                    JOIN users u ON RIGHT(u.phone, 10) = RIGHT(r.phone, 10) COLLATE utf8mb4_general_ci
                     SET r.user_id = u.user_id
                   WHERE r.campaign_id = $campaignId AND r.user_id IS NULL AND r.phone <> ''");
    $conn->query("UPDATE wa_campaign_recipients r
                    JOIN users u ON u.email = r.email COLLATE utf8mb4_general_ci
                     SET r.user_id = u.user_id
                   WHERE r.campaign_id = $campaignId AND r.user_id IS NULL AND r.email <> ''");
}

function wa_materialize_recipients(int $campaignId): int {
    global $conn;

    $r = $conn->query("SELECT * FROM wa_campaigns WHERE id=$campaignId LIMIT 1");
    if (!$r) {
        // mysqli returns false silently on a failed query (e.g. a column an older DB never
        // got); without this that's indistinguishable from "campaign not found".
        wa_log("campaign #$campaignId: FATAL — campaign SELECT failed: " . $conn->error);
        return 0;
    }
    $campaign = $r->fetch_assoc();
    if (!$campaign) return 0;

    $config = [
        'audience_type'       => $campaign['audience_type'],
        'segment_ids'         => json_decode($campaign['segment_ids'] ?? '[]', true) ?: [],
        'exclude_segment_ids' => json_decode($campaign['exclude_segment_ids'] ?? '[]', true) ?: [],
        'list_ids'            => json_decode($campaign['list_ids'] ?? '[]', true) ?: [],
        'domain_filter'       => '', // email-only concept; never narrows a WhatsApp audience
    ];

    // Clear any previous non-test rows before re-materializing (re-scheduling a draft, requeue
    // after a 0-recipient run, etc.).
    $conn->query("DELETE FROM wa_campaign_recipients WHERE campaign_id=$campaignId AND is_test=0");

    $resolved = wa_resolve_audience($config);
    $rows = $resolved['recipients'];
    wa_log("campaign #$campaignId: audience -> " . count($rows) . " reachable number(s), {$resolved['unreachable']} without a usable phone, {$resolved['duplicates']} duplicate(s) merged");

    $skippedDedup = 0;

    // ── Cross-campaign deduplication ────────────────────────────────────────────────────
    if ((int)$campaign['dedup_enabled'] === 1) {
        $phones = array_column($rows, 'phone');
        $recent = wa_recently_messaged(
            $phones,
            (int)$campaign['dedup_window_hours'],
            (string)$campaign['dedup_scope'],
            $campaign['template_name'],
            $campaignId
        );
        if ($recent) {
            $before = count($rows);
            $rows = array_values(array_filter($rows, fn($x) => !isset($recent[$x['phone']])));
            $skippedDedup = $before - count($rows);
            wa_log("campaign #$campaignId: deduplication skipped $skippedDedup number(s) messaged in the last {$campaign['dedup_window_hours']}h (scope={$campaign['dedup_scope']})");
        }
    }

    // ── Opt-out suppression ─────────────────────────────────────────────────────────────
    // A number that replied STOP must never be messaged again, regardless of segment rules.
    $optins = wa_optin_map(array_column($rows, 'phone'));
    $before = count($rows);
    $rows = array_values(array_filter($rows, fn($x) => ($optins[$x['phone']] ?? '') !== 'optout'));
    $optedOut = $before - count($rows);
    if ($optedOut > 0) wa_log("campaign #$campaignId: $optedOut number(s) skipped — opted out");

    // ── Contact limit ───────────────────────────────────────────────────────────────────
    if ((int)$campaign['contact_limit_enabled'] === 1 && (int)$campaign['contact_limit'] > 0) {
        $limit = (int)$campaign['contact_limit'];
        if (count($rows) > $limit) {
            wa_log("campaign #$campaignId: contact limit $limit applied (audience was " . count($rows) . ")");
            $rows = array_slice($rows, 0, $limit);
        }
    }

    $total = count($rows);
    if ($total > 0) {
        foreach (array_chunk($rows, 500) as $chunk) {
            $values = [];
            foreach ($chunk as $u) {
                $rid   = bin2hex(random_bytes(16));
                $uid   = $u['user_id'] !== null && $u['user_id'] !== '' ? (int)$u['user_id'] : 'NULL';
                $phone = $conn->real_escape_string($u['phone']);
                $rawP  = $conn->real_escape_string((string)$u['raw_phone']);
                $email = $conn->real_escape_string((string)$u['email']);
                $fname = $conn->real_escape_string((string)$u['first_name']);
                $lname = $conn->real_escape_string((string)$u['last_name']);
                $values[] = "($campaignId, $uid, '$phone', '$rawP', '$email', '$fname', '$lname', 0, 'pending', '$rid')";
            }
            // INSERT IGNORE + uq_campaign_phone is the second half of the dedup guarantee: even
            // if a future caller hands this function a list it forgot to fold, the database
            // physically cannot store the same number twice for one campaign.
            $conn->query("INSERT IGNORE INTO wa_campaign_recipients
                (campaign_id, user_id, phone, raw_phone, email, first_name, last_name, is_test, status, rid)
                VALUES " . implode(',', $values));
        }
    }

    /*
     * Backfill user_id for recipients that arrived without one.
     *
     * Segment-sourced contacts come from `users` and already carry it. LIST-sourced contacts come
     * from campaign_contacts, which stores a phone and an email but no user_id — so they land here
     * with NULL, and NULL means invisible to anything that joins on identity: conversion goals,
     * per-user attributes, exam data. A campaign sent to a list would report 0 conversions
     * forever, no matter how many of those people actually converted.
     *
     * Matched on the last 10 digits so the two representations meet — we store E.164 digits
     * (919921079337) while `users` holds whatever was typed ("+91 9921079337", "9921079337").
     * Email is the second pass, for contacts whose stored number never normalised.
     *
     * Cheap enough to run every materialize: it touches only rows that are still NULL.
     */
    /*
     * Identity and attribution bookkeeping, both isolated from the send.
     *
     * These read columns added by later migrations (wa_campaign_recipients.user_id backfill,
     * wa_templates.click_target_url). On a server whose schema.php is a version behind, the
     * column is missing and mysqli — which PHP 8.1+ puts in exception mode by default — THROWS.
     * Uncaught, that killed the entire worker run between "audience -> N reachable" and the first
     * send, with display_errors off and nothing in the log to say why.
     *
     * Neither of these is worth failing a campaign over: one improves conversion matching, the
     * other fills in a click destination. Sending is the job.
     */
    try {
        wa_backfill_recipient_user_ids($campaignId);
    } catch (\Throwable $e) {
        wa_log("campaign #$campaignId: user_id backfill skipped — " . $e->getMessage());
    }

    try {
        // Snapshot the template's button destination onto the campaign: a template edited next
        // month must not retarget links already sitting in someone's WhatsApp. Only filled when
        // blank, so an explicit per-campaign override survives.
        $conn->query("UPDATE wa_campaigns c
                        JOIN wa_templates t ON t.id = c.template_id
                         SET c.click_target_url = t.click_target_url
                       WHERE c.id = $campaignId
                         AND (c.click_target_url IS NULL OR c.click_target_url = '')
                         AND t.click_target_url IS NOT NULL AND t.click_target_url <> ''");
    } catch (\Throwable $e) {
        wa_log("campaign #$campaignId: click destination not copied from the template — " . $e->getMessage());
    }

    /*
     * Point the template's tracked link at THIS campaign.
     *
     * The id inside the approved template ("…/login/23") is fixed forever — Meta approved that
     * exact string and it cannot vary per send. So the wa_links row is the only place that can
     * say which campaign a tap belongs to, and it has to be rebound every time the template goes
     * out. Without this a re-used template would keep crediting whichever campaign sent it first.
     *
     * The goal and window are copied across at the same moment for the same reason c.php read
     * them from the campaign: link.php hands them to the landing page, which sizes the attribution
     * cookie from them.
     *
     * Isolated like its neighbours — a campaign is not worth failing over a tracking row.
     */
    try {
        $lr = $conn->query("SELECT t.link_id
                              FROM wa_campaigns c
                              JOIN wa_templates t ON t.id = c.template_id
                             WHERE c.id = $campaignId LIMIT 1");
        $linkId = (int)(($lr ? $lr->fetch_assoc() : [])['link_id'] ?? 0);
        if ($linkId > 0) {
            wa_link_bind_campaign(
                $linkId,
                $campaignId,
                (string)($campaign['goal_event_name'] ?? ''),
                (int)($campaign['goal_window_days'] ?? 2)
            );
            wa_log("campaign #$campaignId: tracked link #$linkId bound to this campaign");
        }
    } catch (\Throwable $e) {
        wa_log("campaign #$campaignId: tracked link not bound — " . $e->getMessage());
    }

    // Count the rows that actually landed rather than trusting $total — INSERT IGNORE may have
    // collapsed more than we folded in PHP.
    $cR = $conn->query("SELECT COUNT(*) AS c FROM wa_campaign_recipients WHERE campaign_id=$campaignId AND is_test=0");
    $queued = $cR ? (int)$cR->fetch_assoc()['c'] : $total;

    $conn->query("UPDATE wa_campaigns
                     SET total_recipients=$queued, skipped_dedup_count=" . (int)$skippedDedup . ", materialized_at=NOW()
                   WHERE id=$campaignId");
    return $queued;
}

/**
 * Renders one recipient's message content — the campaign's variable values with merge tags
 * resolved for this specific person, ready to hand to the transport's buildRequest().
 *
 * @return array{content: array, preview: string}
 */
function wa_render_for_recipient(array $campaign, array $recipient, array $attrTokens): array {
    $vars = json_decode($campaign['variables'] ?? '{}', true) ?: [];

    $resolveList = function ($list) use ($recipient, $attrTokens) {
        $out = [];
        foreach ((array)$list as $v) $out[] = substitute_merge_tags((string)$v, $recipient, $attrTokens);
        return $out;
    };

    if (($campaign['message_type'] ?? 'template') === 'text') {
        $body = substitute_merge_tags((string)$campaign['text_content'], $recipient, $attrTokens);
        return [
            'content' => ['type' => 'text', 'body' => $body, 'preview_url' => (int)$campaign['preview_url'] === 1],
            'preview' => $body,
        ];
    }

    $headerValues = $resolveList($vars['header'] ?? []);
    $bodyValues   = $resolveList($vars['body'] ?? []);
    $buttonSuffix = substitute_merge_tags((string)($vars['button_url_suffix'] ?? ''), $recipient, $attrTokens);

    /*
     * ATTRIBUTION IN THE BUTTON URL — the two tokens that make a WhatsApp link tap countable.
     *
     * Substituted here rather than through the merge-tag resolver because neither is a property
     * of the CONTACT: both identify THIS send to THIS person, and exist only on the recipient row
     * and the campaign.
     *
     *   XX_WA_ATTR_XX          the whole attribution query string. Put in a template button
     *                          approved as  https://dashboard.…/login?{{1}}  the visitor lands
     *                          directly on your platform already carrying everything it needs to
     *                          log the click and set the attribution cookie. No redirect hop, so
     *                          nothing to go wrong between the tap and the page.
     *
     *   XX_WA_CLICK_TOKEN_XX   just the rid, for the  …/c.php?t={{1}}  form, where our own server
     *                          records the click before forwarding. Use this one only if you want
     *                          the panel's own Clicked column to move.
     *
     * Both are safe to leave in a campaign that doesn't use them: an unmatched token is simply
     * never substituted, and a static button carries no variable at all.
     */
    $rid = (string)($recipient['rid'] ?? '');

    /*
     * Default the button variable to XX_WA_ATTR_XX when it was left blank.
     *
     * A dynamic URL button MUST be given a value — Meta rejects the send outright without one —
     * and on a campaign with a conversion goal there is exactly one sensible value it could be.
     * Making an admin type the same token into every campaign is a step that adds no information
     * and silently costs every conversion when it is forgotten.
     *
     * Only applied when all three are true: the template has a dynamic url button, the campaign
     * has a goal, and nothing was typed. An explicit value always wins.
     */
    /*
     * auto_button_attr lets a caller keep its goal while opting OUT of that defaulting.
     *
     * A journey has to: it needs goal_event_name for the `goal=` in its tracked link, but a
     * filled button block is refused by Netcore (131008 — it accepts the block and never passes
     * the value to Meta). Absent for campaigns, which keep the old behaviour exactly.
     */
    $autoButtonAttr = !array_key_exists('auto_button_attr', $campaign) || !empty($campaign['auto_button_attr']);

    if ($autoButtonAttr && trim($buttonSuffix) === '' && trim((string)($campaign['goal_event_name'] ?? '')) !== '') {
        $btns = $campaign['buttons'] ?? [];
        if (is_string($btns)) $btns = json_decode($btns, true) ?: [];
        foreach ((array)$btns as $b) {
            if (($b['type'] ?? '') !== 'url' || empty($b['dynamic'])) continue;
            /*
             * WHICH token to default to depends on where the approved button already points,
             * because the suffix is appended to that base and the two bases want opposite things:
             *
             *     …/api/whatsapp/c.php?t={{1}}   wants the bare rid   → XX_WA_CLICK_TOKEN_XX
             *     …/login?{{1}}                  wants the query str  → XX_WA_ATTR_XX
             *
             * Defaulting to the query string for a c.php button produced ?t=campaign_id=45&…,
             * which fails c.php's 32-hex shape check and lands every visitor on the fallback
             * page with the click uncounted — the worst possible outcome, since the template was
             * approved in exactly the shape that CAN name people.
             */
            $buttonSuffix = strpos((string)($b['url'] ?? ''), '/c.php') !== false
                ? 'XX_WA_CLICK_TOKEN_XX'
                : 'XX_WA_ATTR_XX';
            break;
        }
    }

    /*
     * Expand the attribution tokens in EVERY value that reaches WhatsApp — header, body and
     * button alike — not only the button suffix.
     *
     * A tracked BUTTON is not currently deliverable through Netcore: their API ignores the
     * button's parameter in every documented shape we can construct, and WhatsApp then refuses
     * the message with "131008 buttons: Button at index 0 of type Url requires a parameter". And
     * on the Meta route the button URL is frozen at approval, so it is identical in every copy
     * and can never name anybody. Either way the working place for a per-recipient link is the
     * message TEXT:
     *
     *     body:      Please log in here: {{1}}
     *     variable:  XX_WA_TRACKED_URL_XX
     *
     * Body variables travel in `attributes`, the one part of Netcore's template payload that is
     * proven to work, and WhatsApp auto-links whatever arrives — so the recipient still taps a
     * link, it just isn't a button. The template needs no re-approval, because body variables
     * are free text.
     */
    $headerValues = array_map($expandAttr, $headerValues);
    $bodyValues   = array_map($expandAttr, $bodyValues);
    $buttonSuffix = $expandAttr($buttonSuffix);

    $content = [
        'type'     => 'template',
        'name'     => $campaign['template_name'],
        'language' => $campaign['template_language'] ?: 'en',
    ];

    $tpl = [
        'header_type'      => $campaign['header_type'],
        'header_text'      => $campaign['header_text'],
        'header_media_url' => $campaign['header_media_url'],
        'body_text'        => $campaign['body_text'],
        'buttons'          => $campaign['buttons'],
    ];
    $values = ['header' => $headerValues, 'body' => $bodyValues, 'button_url_suffix' => $buttonSuffix];

    /*
     * BOTH shapes are built, and the transport takes the one it understands: Meta wants nested
     * components[], Netcore wants a flat attributes[]. Rendering is pure CPU on already-resolved
     * values, so computing the unused one costs nothing measurable — and it keeps this function
     * from needing to know which route the campaign is on, which is decided per campaign and can
     * differ between two campaigns processed in the same batch.
     */
    $content['components'] = meta_build_components($tpl, $values);
    $content['attributes'] = netcore_build_attributes($tpl, $values);
    // Netcore keeps the button's value out of `attributes` — mixing them is error 132000.
    $content['buttons']    = netcore_build_buttons($tpl, $values);
    // Netcore carries a media header as its own block rather than a component parameter.
    $content['header_type']      = $campaign['header_type'];
    $content['header_media_url'] = $campaign['header_media_url'];

    return [
        'content' => $content,
        // Human-readable copy of exactly what this person was sent, stored on their row so the
        // report can show it without re-deriving anything.
        'preview' => wa_fill_placeholders((string)$campaign['body_text'], $bodyValues),
    ];
}

/**
 * Processes one chunk of pending recipients (per running campaign, or a single $campaignId
 * for the instant "Send now" kick). Concurrency-safe by virtue of the caller's flock().
 */
function wa_process_batch(int $limit = 200, ?int $campaignId = null): array {
    global $conn;
    wa_activate_due_scheduled();

    $filter = $campaignId ? 'id = ' . (int)$campaignId : "status = 'running'";
    $ids = [];
    $res = $conn->query("SELECT id FROM wa_campaigns WHERE $filter");
    while ($res && $row = $res->fetch_assoc()) $ids[] = (int)$row['id'];

    static $tickLogged = false;
    if (!$tickLogged) {
        wa_log('tick: ' . count($ids) . ' running campaign(s) to check'
            . ($campaignId ? " (instant kick for campaign #$campaignId)" : ' (cron sweep)'));
        $tickLogged = true;
    }

    $processed = 0; $sent = 0; $failed = 0;
    $settings  = wa_settings_row() ?: [];

    foreach ($ids as $cid) {
        try {
            $campRes = $conn->query("SELECT * FROM wa_campaigns WHERE id=$cid LIMIT 1");
            $campaign = $campRes ? $campRes->fetch_assoc() : null;

            /*
             * Both skips below used to be a bare `continue`, which made this the one path that could
             * do nothing and say nothing: an instant kick selects a campaign BY ID regardless of
             * status, so a campaign that isn't 'running' produced "processed: 0" with no line
             * explaining why, and no amount of re-kicking would ever change it. Whatever the worker
             * declines to do, it now says so.
             */
            if (!$campaign) {
                wa_log("campaign #$cid: skipped — no such campaign row");
                continue;
            }
            if ($campaign['status'] !== 'running') {
                wa_log("campaign #$cid \"{$campaign['name']}\": skipped — status is '{$campaign['status']}', and only 'running' campaigns are sent."
                    . " Open it in the wizard and press Send now, or use Resume on the report.");
                continue;
            }

            if (empty($campaign['materialized_at'])) {
                wa_log("campaign #$cid \"{$campaign['name']}\": resolving audience (type={$campaign['audience_type']}, segments={$campaign['segment_ids']}, lists={$campaign['list_ids']})…");
                $n = wa_materialize_recipients($cid);
                if ($n === 0) {
                    wa_log("campaign #$cid: 0 reachable recipients -> marking FAILED (nothing was sent)");
                    $conn->query("UPDATE wa_campaigns SET status='failed', completed_at=NOW() WHERE id=$cid");
                    continue;
                }
                // Re-read: materialize stamped total_recipients/materialized_at on the row.
                $campRes = $conn->query("SELECT * FROM wa_campaigns WHERE id=$cid LIMIT 1");
                $campaign = $campRes ? $campRes->fetch_assoc() : $campaign;
            }

            // Re-check live status right before claiming — a Suspend click can land while this tick
            // was busy waiting on slow API calls for an earlier batch.
            $liveR = $conn->query("SELECT status FROM wa_campaigns WHERE id=$cid LIMIT 1");
            $live  = $liveR ? $liveR->fetch_assoc() : null;
            if (!$live || $live['status'] !== 'running') continue;

            $conn->query("UPDATE wa_campaign_recipients SET status='processing'
                           WHERE campaign_id=$cid AND status='pending' AND is_test=0 ORDER BY id LIMIT " . (int)$limit);
            $claimedR = $conn->query("SELECT * FROM wa_campaign_recipients
                                       WHERE campaign_id=$cid AND status='processing' AND is_test=0 ORDER BY id LIMIT " . (int)$limit);
            $claimed = [];
            while ($claimedR && $row = $claimedR->fetch_assoc()) $claimed[] = $row;
            if (!$claimed) {
                // Same reasoning as the status skips above: say what was found, so "nothing happened"
                // is never the whole story. finalize() decides sent-vs-failed and logs its own line.
                $cntR = $conn->query("SELECT status, COUNT(*) c FROM wa_campaign_recipients
                                       WHERE campaign_id=$cid AND is_test=0 GROUP BY status");
                $parts = [];
                while ($cntR && $cr = $cntR->fetch_assoc()) $parts[] = "{$cr['status']}={$cr['c']}";
                wa_log("campaign #$cid: nothing left to claim (" . ($parts ? implode(', ', $parts) : 'no recipient rows at all') . ')');
                wa_finalize_if_drained($cid);
                continue;
            }

            $sender    = wa_sender_for_campaign($campaign);
            // The campaign's snapshotted route wins over the number's current default, so changing a
            // number's provider never re-routes a campaign that is already part-way through sending.
            $provider  = wa_resolve_provider($sender, $campaign['send_provider'] ?? null);
            $transport = wa_transport_for_sender($settings, $sender, $provider);

            // Settled once per batch rather than discovered 200 times over the network: without
            // credentials every single request is a guaranteed 401. The missing piece differs by
            // route, so the message names the one that actually applies.
            $blocker = null;
            if (!$transport->isConfigured()) {
                $blocker = $provider === 'netcore'
                    ? 'No Netcore API key on ' . ($campaign['business_number'] ?: 'the sending number')
                        . ' — add it in Settings → Sending numbers → Edit'
                    : 'Meta token or phone number ID missing for ' . ($campaign['business_number'] ?: 'the sending number')
                        . ' — check WhatsApp settings';
            }
            if ($blocker) wa_log("campaign #$cid: $blocker — this batch will be marked failed");
            else wa_log("campaign #$cid: sending via " . strtoupper($provider)
                . ' as ' . ($sender['business_number'] ?? 'unknown number'));

            // Customer Attributes resolved ONCE for the whole batch (one query per attribute), not
            // once per recipient — same batching as the email worker.
            $attributes = load_all_attributes();
            $attrByEmail = $attributes ? resolve_attribute_values_batch($attributes, $claimed) : [];

            // ── Phase 1: render everything (pure CPU, no network) ──
            $jobs = []; $rowsById = []; $previews = [];
            foreach ($claimed as $rec) {
                $processed++;
                $rowsById[$rec['id']] = $rec;
                if ($blocker) continue;

                $attrTokens = $attrByEmail[strtolower((string)$rec['email'])] ?? [];
                $rendered   = wa_render_for_recipient($campaign, $rec, $attrTokens);
                $previews[$rec['id']] = $rendered['preview'];
                $jobs[] = [
                    'key' => $rec['id'],
                    'rid' => $rec['rid'],
                    'req' => $transport->buildRequest($rec['phone'], $rendered['content'], $rec['rid']),
                ];
            }

            // ── Phase 2: send them concurrently ──
            if ($blocker) {
                $results = [];
                foreach ($rowsById as $id => $_) {
                    $results[$id] = ['ok' => false, 'message_id' => null, 'error' => $blocker, 'code' => 'unconfigured', 'retryable' => false];
                }
            } else {
                $startedAt = microtime(true);
                $results = wa_send_parallel($transport, $jobs, WA_SEND_CONCURRENCY);
                $elapsed = max(0.001, microtime(true) - $startedAt);
                if ($jobs) {
                    wa_log(sprintf('campaign #%d: %d sends in %.1fs (%.0f/s, concurrency %d)',
                        $cid, count($jobs), $elapsed, count($jobs) / $elapsed, WA_SEND_CONCURRENCY));
                }
            }

            // ── Phase 3: write outcomes back in a handful of queries ──
            // The campaign's own Retry toggle decides whether a recipient gets more than one go:
            // with it off, both a permanent rejection AND a provider-busy response settle the
            // recipient immediately instead of going back in the queue.
            $retryOn = (int)($campaign['retry_enabled'] ?? 1) === 1;
            $maxAttempts = $retryOn ? WA_MAX_ATTEMPTS : 1;

            $sentIds = []; $messageIds = []; $failures = []; $retryables = [];
            $accountFault = null;   // set when the SENDING NUMBER is the problem, not the recipient
            foreach ($results as $id => $res) {
                if ($accountFault === null && !empty($res['account_fault'])) $accountFault = (string)$res['account_fault'];
                if (!empty($res['ok'])) {
                    $sentIds[] = (int)$id;
                    $messageIds[(int)$id] = (string)($res['message_id'] ?? '');
                } elseif (!empty($res['retryable']) && $retryOn) {
                    $retryables[(int)$id] = $res['error'] ?? 'Provider busy';
                } else {
                    $failures[(int)$id] = ['error' => $res['error'] ?? 'Unknown send error', 'code' => $res['code'] ?? null];
                }
            }

            if ($sentIds) {
                $idCases = ''; $bodyCases = '';
                foreach ($sentIds as $id) {
                    $idCases   .= " WHEN $id THEN '" . $conn->real_escape_string($messageIds[$id] ?? '') . "'";
                    $bodyCases .= " WHEN $id THEN '" . $conn->real_escape_string(mb_substr((string)($previews[$id] ?? ''), 0, 4000)) . "'";
                }
                $inList = implode(',', $sentIds);
                $conn->query("UPDATE wa_campaign_recipients
                                 SET status='sent', sent_at=NOW(),
                                     wa_message_id = CASE id$idCases ELSE wa_message_id END,
                                     rendered_body = CASE id$bodyCases ELSE rendered_body END
                               WHERE id IN ($inList)");
                // delivered_count/read_count are deliberately NOT touched here — "sent" only means
                // the provider accepted the API call. Real delivery arrives later via webhook.php.
                $conn->query("UPDATE wa_campaigns SET sent_count = sent_count + " . count($sentIds) . " WHERE id=$cid");
                foreach ($sentIds as $id) wa_record_event($cid, $id, 'sent');
                $sent += count($sentIds);
            }

            /*
             * The sending number itself is unusable — stop, don't grind.
             *
             * An account-level rejection (#133010 "not registered on Cloud API" above all) fails
             * every recipient identically, so continuing would burn a 40,000-row audience into the
             * same error, mark them all permanently failed, and leave the campaign unresendable
             * once the number is fixed. Instead the round is rolled back to 'pending', the campaign
             * is SUSPENDED with the reason attached, and Resume picks up exactly where it stopped.
             */
            if ($accountFault !== null) {
                $back = array_merge(array_keys($failures), array_keys($retryables));
                if ($back) {
                    $conn->query("UPDATE wa_campaign_recipients SET status='pending'
                                   WHERE id IN (" . implode(',', array_map('intval', $back)) . ")");
                }
                $reason = 'Sending stopped: ' . $accountFault;
                $conn->query("UPDATE wa_campaigns SET status='suspended',
                                     last_error='" . $conn->real_escape_string(mb_substr($reason, 0, 500)) . "'
                               WHERE id=$cid");
                wa_log("campaign #$cid: SUSPENDED — $accountFault");
                wa_log("campaign #$cid: " . count($back) . " recipient(s) put back to pending, none consumed. "
                     . "Fix the number, then press Resume on the campaign.");
                continue;
            }

            if ($failures) {
                wa_mark_failed_batch($cid, $failures, $rowsById, $maxAttempts);
                $failed += count($failures);
                $sampleId = array_key_first($failures);
                wa_log("campaign #$cid: " . count($failures) . " permanent rejection(s), e.g. "
                    . ($rowsById[$sampleId]['phone'] ?? '?') . ' -> ' . $failures[$sampleId]['error']);
            }

            if ($retryables) {
                // Straight back to 'pending' with attempts untouched: the provider said "not now",
                // not "never". Burning an attempt here would permanently fail thousands of perfectly
                // good numbers after three rate-limit bursts.
                $conn->query("UPDATE wa_campaign_recipients SET status='pending'
                               WHERE id IN (" . implode(',', array_keys($retryables)) . ")");
                $sampleId = array_key_first($retryables);
                wa_log("campaign #$cid: " . count($retryables) . ' rate-limited/retryable, requeued (attempts NOT consumed), e.g. '
                    . $retryables[$sampleId] . ' — lower WA_SEND_CONCURRENCY if this is constant');
                sleep(WA_RATE_LIMIT_BACKOFF_SECONDS);
            }

            wa_finalize_if_drained($cid);
        } catch (\Throwable $e) {
            /*
             * One campaign must never take the whole run down.
             *
             * mysqli throws on PHP 8.1+, display_errors is off in the worker, and this loop is
             * the only thing standing between an unexpected exception and a run that simply
             * stops — no "COMPLETED", no "run finished", nothing in the log at all. That is
             * exactly how campaign #13 vanished mid-materialize after a schema migration lagged
             * behind the code that read the new column.
             *
             * The campaign is left 'running' on purpose rather than failed: the cause is usually
             * environmental (a missing column, a lock, a timeout), so the next tick should retry
             * it rather than write it off permanently.
             */
            wa_log("campaign #$cid: ABORTED — [" . get_class($e) . '] ' . $e->getMessage()
                . ' (left running; the next tick will retry it)');
            continue;
        }
    }

    return ['processed' => $processed, 'sent' => $sent, 'failed' => $failed, 'campaigns' => count($ids)];
}

/**
 * $maxAttempts strikes → 'failed', otherwise back to 'pending' — in two queries rather than one
 * per recipient. Only ever called with PERMANENT failures (provider-busy takes the requeue path
 * above, unless the campaign has Retry switched off, in which case $maxAttempts is 1 and
 * everything settles on the first try).
 */
function wa_mark_failed_batch(int $campaignId, array $failures, array $rowsById, int $maxAttempts = WA_MAX_ATTEMPTS): void {
    global $conn;
    if (!$failures) return;

    $byStatus = ['failed' => [], 'pending' => []];
    $errCases = ''; $codeCases = '';
    foreach ($failures as $id => $f) {
        $id = (int)$id;
        $attempts = (int)($rowsById[$id]['attempts'] ?? 0) + 1;
        $byStatus[$attempts >= $maxAttempts ? 'failed' : 'pending'][] = $id;
        $errCases  .= " WHEN $id THEN '" . $conn->real_escape_string(substr((string)$f['error'], 0, 480)) . "'";
        $codeCases .= " WHEN $id THEN '" . $conn->real_escape_string(substr((string)($f['code'] ?? ''), 0, 60)) . "'";
    }

    foreach ($byStatus as $status => $ids) {
        if (!$ids) continue;
        $inList = implode(',', $ids);
        $failedAt = $status === 'failed' ? ', failed_at=NOW()' : '';
        // attempts + 1 rather than a computed literal, so a concurrent write can't be
        // overwritten with a stale value.
        $conn->query("UPDATE wa_campaign_recipients
                         SET status='$status', attempts = attempts + 1$failedAt,
                             error_message = CASE id$errCases ELSE error_message END,
                             error_code    = CASE id$codeCases ELSE error_code END
                       WHERE id IN ($inList)");
        if ($status === 'failed') {
            $conn->query("UPDATE wa_campaigns SET failed_count = failed_count + " . count($ids) . " WHERE id=$campaignId");
            foreach ($ids as $id) {
                wa_record_event($campaignId, $id, 'failed', $failures[$id]['code'] ?? null, $failures[$id]['error'] ?? null);
            }
        }
    }
}

function wa_record_event(int $campaignId, int $recipientId, string $type, ?string $code = null, ?string $detail = null): void {
    global $conn;
    $codeSql   = $code === null ? 'NULL' : "'" . $conn->real_escape_string(substr($code, 0, 60)) . "'";
    $detailSql = $detail === null ? 'NULL' : "'" . $conn->real_escape_string(substr($detail, 0, 480)) . "'";
    $conn->query("INSERT INTO wa_campaign_events (campaign_id, recipient_id, event_type, error_code, detail)
                  VALUES ($campaignId, $recipientId, '" . $conn->real_escape_string($type) . "', $codeSql, $detailSql)");
}

/**
 * Closes out a campaign once its queue is empty.
 *
 * "Nothing left pending" is NOT the same as "everyone got it" — a recipient that fails
 * WA_MAX_ATTEMPTS times also leaves the queue. So the final status depends on whether
 * anything actually succeeded, which is what stops a campaign showing SENT when every single
 * message was rejected (e.g. an unapproved template name).
 */
function wa_finalize_if_drained(int $campaignId): void {
    global $conn;
    $r = $conn->query("SELECT COUNT(*) AS c FROM wa_campaign_recipients
                        WHERE campaign_id=$campaignId AND is_test=0 AND status IN ('pending','processing')");
    $remaining = $r ? (int)$r->fetch_assoc()['c'] : 0;
    if ($remaining > 0) return;

    $s = $conn->query("SELECT COUNT(*) AS c FROM wa_campaign_recipients
                        WHERE campaign_id=$campaignId AND is_test=0 AND status IN ('sent','delivered','read')");
    $sentCount = $s ? (int)$s->fetch_assoc()['c'] : 0;
    $finalStatus = $sentCount > 0 ? 'sent' : 'failed';
    $conn->query("UPDATE wa_campaigns SET status='$finalStatus', completed_at=NOW()
                   WHERE id=$campaignId AND status='running'");
    wa_log("campaign #$campaignId: COMPLETED -> status=$finalStatus ($sentCount accepted by the provider)");
}

/**
 * Re-decides a finished campaign's status after a webhook changes a recipient's outcome.
 *
 * wa_finalize_if_drained() runs the moment the last message is ACCEPTED by the provider, and at
 * that instant every recipient reads 'sent' — so the campaign is marked 'sent'. The rejections
 * arrive seconds to minutes later, on the webhook, and flip those rows to 'failed'. Nothing was
 * re-checking the campaign, so one where every single message was rejected still showed a green
 * SENT badge next to "Failed 2".
 *
 * Only ever touches a campaign that has already finished, and never while recipients are still
 * pending or processing — a mid-send failure must not prematurely fail the whole campaign.
 *
 * Idempotent: it computes the status the data implies and writes only when that differs.
 */
function wa_reconcile_campaign_status(int $campaignId): void {
    global $conn;

    $r = $conn->query("SELECT status FROM wa_campaigns WHERE id=$campaignId LIMIT 1");
    $row = $r ? $r->fetch_assoc() : null;
    // 'running' is the worker's business; 'draft'/'scheduled'/'suspended' are the admin's.
    if (!$row || !in_array($row['status'], ['sent', 'failed'], true)) return;

    $c = $conn->query("SELECT SUM(status IN ('pending','processing')) AS busy,
                              SUM(status IN ('sent','delivered','read')) AS ok
                         FROM wa_campaign_recipients
                        WHERE campaign_id=$campaignId AND is_test=0");
    $s = $c ? $c->fetch_assoc() : null;
    if (!$s || (int)$s['busy'] > 0) return;

    $want = (int)$s['ok'] > 0 ? 'sent' : 'failed';
    if ($want === $row['status']) return;

    /*
     * When a campaign is being demoted to 'failed', carry the REASON up with it.
     *
     * Without this the campaign row says FAILED and stops there. The actual explanation —
     * "131042: no payment method is set up for your WhatsApp Business account", with Meta's own
     * fix URL in it — sits on the individual recipient rows and in wa-worker.log, which means
     * the first question after every failed campaign is "why?" and the only people who can
     * answer it are the ones willing to open a log file or write SQL.
     *
     * The most common error among the failures is the one that goes up, not the first: a
     * campaign that half-failed on invalid numbers and half on an account-level problem should
     * report the account-level problem, because that is the one worth acting on and it will be
     * the majority. GROUP BY does that far more honestly than picking a row at random.
     */
    $err = null;
    if ($want === 'failed') {
        $er = $conn->query("SELECT error_code, error_message, COUNT(*) c
                              FROM wa_campaign_recipients
                             WHERE campaign_id=$campaignId AND is_test=0 AND status='failed'
                               AND error_message IS NOT NULL AND error_message <> ''
                             GROUP BY error_code, error_message
                             ORDER BY c DESC LIMIT 1");
        $e = $er ? $er->fetch_assoc() : null;
        if ($e) {
            $err = ($e['error_code'] !== '' && $e['error_code'] !== null ? $e['error_code'] . ': ' : '')
                 . (string)$e['error_message'];
        }
    }

    $sets = "status='$want'";
    // Cleared on the way back UP as well: a campaign that turns out to have succeeded must not
    // keep a stale failure message hanging off it.
    $sets .= ', last_error=' . ($err === null ? 'NULL' : "'" . $conn->real_escape_string(mb_substr($err, 0, 490)) . "'");

    $conn->query("UPDATE wa_campaigns SET $sets WHERE id=$campaignId");
    wa_log("campaign #$campaignId: status corrected to $want — "
        . ($want === 'failed'
            ? 'every message was rejected after the provider accepted it'
              . ($err !== null ? ' (' . mb_substr($err, 0, 200) . ')' : '')
            : 'a recipient succeeded after all'));
}

/**
 * Fire-and-forget kick so "Send now" doesn't wait for the next cron minute — opens a socket
 * to the worker endpoint and closes it without reading the response. Cron remains the
 * reliable safety net that finishes whatever this didn't get to.
 */
function wa_trigger_worker_async(int $campaignId): void {
    $path = WA_WORKER_PATH . '?cron_secret=' . urlencode(WA_CRON_SECRET) . '&campaign_id=' . $campaignId;
    $fp = @fsockopen('ssl://' . WA_WORKER_HOST, 443, $errno, $errstr, 1);
    if (!$fp) return;
    stream_set_timeout($fp, 1);
    fwrite($fp, "GET $path HTTP/1.1\r\nHost: " . WA_WORKER_HOST . "\r\nConnection: Close\r\n\r\n");
    fclose($fp);
}

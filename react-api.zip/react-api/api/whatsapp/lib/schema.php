<?php
/*
 * whatsapp_ensure_schema() — idempotent CREATE TABLE IF NOT EXISTS for the 6 tables backing
 * the WhatsApp Campaigns builder. Called at the top of every entrypoint in this feature,
 * mirroring campaigns/lib/schema.php's campaigns_ensure_schema(). SQL is documented (kept in
 * sync by hand) in ../whatsapp_schema.sql.
 *
 * Everything here is metadata-only (CREATE IF NOT EXISTS / SHOW COLUMNS) except the single
 * settings-row seed, which is guarded behind a SELECT for exactly the reason spelled out in
 * the email version: it's the one real row-level unique-key write, and concurrent requests
 * can deadlock on it.
 */
require_once __DIR__ . '/config.php';

function whatsapp_ensure_schema() {
    global $conn;
    if (!$conn) return;

    try {
        $conn->query("CREATE TABLE IF NOT EXISTS wa_campaigns (
            id                  INT AUTO_INCREMENT PRIMARY KEY,
            name                VARCHAR(255) NOT NULL,
            tags                VARCHAR(500) DEFAULT NULL,
            status              ENUM('draft','scheduled','running','sent','suspended','failed') NOT NULL DEFAULT 'draft',
            channel             ENUM('whatsapp') NOT NULL DEFAULT 'whatsapp',

            -- Setup step 'Advanced' — stored for reference, same as the email builder
            ga_source VARCHAR(255) DEFAULT NULL, ga_medium VARCHAR(255) DEFAULT NULL, ga_campaign VARCHAR(255) DEFAULT NULL,
            ga_content VARCHAR(255) DEFAULT NULL, ga_term VARCHAR(255) DEFAULT NULL,

            -- Audience step (identical semantics to email — the SAME segments and lists feed
            -- both channels; only the reachability rule differs: a phone number, not an email)
            audience_type       ENUM('all_contacts','segments') NOT NULL DEFAULT 'segments',
            segment_ids         JSON DEFAULT NULL,
            exclude_segment_ids JSON DEFAULT NULL,
            list_ids            JSON DEFAULT NULL,
            reachable_count     INT NOT NULL DEFAULT 0,

            -- Deduplication: 'Avoid duplicate communication to contacts'. Within a single
            -- campaign duplicates are collapsed unconditionally (uq_campaign_phone below);
            -- these columns control the OPTIONAL cross-campaign window on top of that.
            dedup_enabled       TINYINT(1) NOT NULL DEFAULT 0,
            dedup_window_hours  INT NOT NULL DEFAULT 24,
            dedup_scope         ENUM('all_campaigns','same_template') NOT NULL DEFAULT 'all_campaigns',
            skipped_dedup_count INT NOT NULL DEFAULT 0,

            -- Content step
            message_type      ENUM('template','text') NOT NULL DEFAULT 'template',
            template_id       INT DEFAULT NULL,
            template_name     VARCHAR(255) DEFAULT NULL,
            template_language VARCHAR(16) DEFAULT 'en',
            template_category VARCHAR(32) DEFAULT NULL,
            header_type       ENUM('none','text','image','video','document') NOT NULL DEFAULT 'none',
            header_text       VARCHAR(500) DEFAULT NULL,
            header_media_url  VARCHAR(1000) DEFAULT NULL,
            body_text         TEXT DEFAULT NULL,
            footer_text       VARCHAR(255) DEFAULT NULL,
            buttons           JSON DEFAULT NULL,
            -- Per-variable values chosen in the wizard, e.g.
            -- {'header':['XX_USER_FNAME_XX'],'body':['XX_USER_FNAME_XX','iCAT 174'],'button_url_suffix':''}
            -- Values may contain merge tags; they're resolved per recipient at send time.
            variables         JSON DEFAULT NULL,
            text_content      TEXT DEFAULT NULL,
            preview_url       TINYINT(1) NOT NULL DEFAULT 1,

            -- Sending identity, snapshotted when the campaign is sent/scheduled
            -- Sending identity, snapshotted from wa_senders when the campaign is sent/scheduled
            -- so a later edit to (or deletion of) the sender can't change what an already-
            -- queued campaign goes out as.
            source_id       VARCHAR(100) DEFAULT NULL,
            business_number VARCHAR(32) DEFAULT NULL,
            sender_id       INT DEFAULT NULL,
            waba_id         VARCHAR(64) DEFAULT NULL,

            -- Schedule step
            schedule_type   ENUM('now','later') NOT NULL DEFAULT 'now',
            scheduled_at    DATETIME DEFAULT NULL,
            contact_limit_enabled TINYINT(1) NOT NULL DEFAULT 0,
            contact_limit   INT DEFAULT NULL,
            retry_enabled   TINYINT(1) NOT NULL DEFAULT 1,

            -- Denormalized rollup stats
            total_recipients INT NOT NULL DEFAULT 0,
            sent_count INT NOT NULL DEFAULT 0, delivered_count INT NOT NULL DEFAULT 0,
            read_count INT NOT NULL DEFAULT 0, failed_count INT NOT NULL DEFAULT 0,
            click_count INT NOT NULL DEFAULT 0, reply_count INT NOT NULL DEFAULT 0,

            created_by  BIGINT UNSIGNED DEFAULT NULL,
            created_at  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            started_at DATETIME DEFAULT NULL, completed_at DATETIME DEFAULT NULL, materialized_at DATETIME DEFAULT NULL,

            INDEX idx_status_scheduled (status, scheduled_at),
            INDEX idx_created_at (created_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

        /*
         * uq_campaign_phone is the deduplication guarantee, enforced by the database rather
         * than by application bookkeeping: the materializer inserts with INSERT IGNORE, so a
         * number reachable through three different selected segments/lists collapses to
         * exactly one row — there is no code path that can send the same person the same
         * campaign twice. is_test is part of the key so a test send to your own number never
         * blocks that number from also being in the real audience.
         */
        $conn->query("CREATE TABLE IF NOT EXISTS wa_campaign_recipients (
            id            BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            campaign_id   INT NOT NULL,
            user_id       BIGINT UNSIGNED DEFAULT NULL,
            phone         VARCHAR(24) NOT NULL,
            raw_phone     VARCHAR(32) DEFAULT NULL,
            email         VARCHAR(255) DEFAULT NULL,
            first_name    VARCHAR(255) DEFAULT NULL, last_name VARCHAR(255) DEFAULT NULL,
            is_test       TINYINT(1) NOT NULL DEFAULT 0,
            status        ENUM('pending','processing','sent','delivered','read','failed','skipped') NOT NULL DEFAULT 'pending',
            skip_reason   VARCHAR(190) DEFAULT NULL,
            rid           CHAR(32) NOT NULL,
            attempts      TINYINT UNSIGNED NOT NULL DEFAULT 0,
            error_code    VARCHAR(64) DEFAULT NULL,
            error_message VARCHAR(500) DEFAULT NULL,
            wa_message_id VARCHAR(120) DEFAULT NULL,
            rendered_body TEXT DEFAULT NULL,
            queued_at     TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            sent_at DATETIME DEFAULT NULL, delivered_at DATETIME DEFAULT NULL,
            read_at DATETIME DEFAULT NULL, failed_at DATETIME DEFAULT NULL,
            click_count INT NOT NULL DEFAULT 0,

            UNIQUE INDEX uq_rid (rid),
            UNIQUE INDEX uq_campaign_phone (campaign_id, is_test, phone),
            INDEX idx_campaign_status (campaign_id, status),
            INDEX idx_wa_message_id (wa_message_id),
            INDEX idx_phone_sent (phone, sent_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

        $conn->query("CREATE TABLE IF NOT EXISTS wa_campaign_events (
            id           BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            campaign_id  INT NOT NULL,
            recipient_id BIGINT UNSIGNED NOT NULL,
            event_type   ENUM('sent','delivered','read','failed','button_click','replied') NOT NULL,
            error_code   VARCHAR(64) DEFAULT NULL,
            detail       VARCHAR(500) DEFAULT NULL,
            meta         JSON DEFAULT NULL,
            created_at   TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_campaign_type (campaign_id, event_type),
            INDEX idx_recipient (recipient_id),
            INDEX idx_created_at (created_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

        /*
         * Our own record of a WhatsApp message template. WhatsApp itself only ever accepts a
         * template that Meta has already APPROVED, so `name`/`language` here must match the
         * approved template exactly — everything else (body preview, variable labels, sample
         * values) exists so the wizard can render a real preview and offer a variable-mapping
         * UI without a round-trip to the provider on every keystroke.
         */
        $conn->query("CREATE TABLE IF NOT EXISTS wa_templates (
            id              INT AUTO_INCREMENT PRIMARY KEY,
            name            VARCHAR(255) NOT NULL,
            meta_template_id VARCHAR(64) DEFAULT NULL,
            display_name    VARCHAR(255) DEFAULT NULL,
            category        ENUM('marketing','utility','authentication') NOT NULL DEFAULT 'utility',
            language        VARCHAR(16) NOT NULL DEFAULT 'en',
            header_type     ENUM('none','text','image','video','document') NOT NULL DEFAULT 'none',
            header_text     VARCHAR(500) DEFAULT NULL,
            header_media_url VARCHAR(1000) DEFAULT NULL,
            body_text       TEXT NOT NULL,
            footer_text     VARCHAR(255) DEFAULT NULL,
            buttons         JSON DEFAULT NULL,
            variable_labels JSON DEFAULT NULL,
            sample_values   JSON DEFAULT NULL,
            approval_status ENUM('approved','pending','rejected','unknown') NOT NULL DEFAULT 'pending',
            status          ENUM('active','archived') NOT NULL DEFAULT 'active',
            created_by      BIGINT UNSIGNED DEFAULT NULL,
            created_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            UNIQUE INDEX uq_name_lang (name, language),
            INDEX idx_status (status, category)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

        /*
         * Account-level credentials ONLY — one row, one API key.
         *
         * The `source_id`/`waba_id`/`business_number`/`business_name` columns are legacy: the
         * first build assumed a single sending number. They are kept purely so the one-time
         * migration below can lift their values into wa_senders, and are no longer read or
         * written by anything else. Who a campaign sends AS now lives in wa_senders.
         */
        $conn->query("CREATE TABLE IF NOT EXISTS wa_settings (
            id                   INT AUTO_INCREMENT PRIMARY KEY,
            provider             VARCHAR(32) NOT NULL DEFAULT 'netcore',
            is_active            TINYINT(1) NOT NULL DEFAULT 1,
            api_key              TEXT DEFAULT NULL,
            api_base_url         VARCHAR(500) DEFAULT NULL,
            source_id            VARCHAR(100) DEFAULT NULL,
            waba_id              VARCHAR(64) DEFAULT NULL,
            business_number      VARCHAR(32) DEFAULT NULL,
            business_name        VARCHAR(255) DEFAULT NULL,
            default_country_code VARCHAR(6) NOT NULL DEFAULT '91',
            webhook_secret       VARCHAR(255) DEFAULT NULL,
            -- Meta System User token, used ONLY to read the template list from the WABA
            -- (GET /{waba_id}/message_templates). Netcore has no template endpoint, and Meta
            -- is the authority on approval status anyway.
            meta_access_token    TEXT DEFAULT NULL,
            updated_at           TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            UNIQUE INDEX uq_provider (provider)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

        /*
         * One row per sending number — the shape Netcore's own panel exposes, where a WABA
         * (the account, e.g. 1229117948963194) owns several business numbers and each number
         * has its OWN API key, generated under Business number → Edit → Integrate API.
         *
         * That per-number key is what makes a message go out from that number; there is no
         * separate sender id in the payload. `waba_id` groups numbers for the picker and is
         * never sent. `source_id` is optional and unrelated to identity — it is the routing
         * tag matched against a webhook's "Source key / callbackData" so delivery receipts
         * come back to the right endpoint.
         */
        $conn->query("CREATE TABLE IF NOT EXISTS wa_senders (
            id              INT AUTO_INCREMENT PRIMARY KEY,
            waba_id         VARCHAR(64) NOT NULL,
            waba_name       VARCHAR(255) DEFAULT NULL,
            business_number VARCHAR(32) NOT NULL,
            display_name    VARCHAR(255) DEFAULT NULL,
            -- Who actually carries the message for this number:
            --   'netcore' → waapi.pepipost.com, authenticated with this number's api_key
            --   'meta'    → Meta Cloud API directly, using phone_number_id + the account's
            --               Meta token. Both numbers report platform_type CLOUD_API, so Meta
            --               hosts them either way and the BSP is an optional layer.
            provider        ENUM('netcore','meta') NOT NULL DEFAULT 'meta',
            phone_number_id VARCHAR(32) DEFAULT NULL,
            -- Two-factor PIN set when the number was registered for Cloud API. Needed again on
            -- any re-registration, so it is kept rather than left to memory.
            registration_pin VARCHAR(12) DEFAULT NULL,
            api_key         TEXT DEFAULT NULL,
            source_id       VARCHAR(100) DEFAULT NULL,
            quality_rating  VARCHAR(32) DEFAULT NULL,
            messaging_limit VARCHAR(64) DEFAULT NULL,
            is_default      TINYINT(1) NOT NULL DEFAULT 0,
            is_active       TINYINT(1) NOT NULL DEFAULT 1,
            notes           VARCHAR(500) DEFAULT NULL,
            created_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            UNIQUE INDEX uq_number (business_number),
            INDEX idx_waba (waba_id, is_active)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

        /*
         * WhatsApp will not deliver to a number that hasn't opted in. This mirrors the
         * provider's consent state locally so the wizard can warn BEFORE a send instead of
         * discovering it as a per-number failure afterwards; the provider remains the source
         * of truth, this is a cache written whenever we call the consent API ourselves.
         */
        $conn->query("CREATE TABLE IF NOT EXISTS wa_optins (
            id         BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            phone      VARCHAR(24) NOT NULL,
            status     ENUM('optin','optout') NOT NULL DEFAULT 'optin',
            source     VARCHAR(32) DEFAULT 'WEB',
            -- What the person actually did, verbatim where possible ('Replied \"STOP\"…'). An
            -- opt-out with no provenance is one nobody dares to remove.
            reason     VARCHAR(255) DEFAULT NULL,
            -- When the block STARTED, not when the row was last written — see wa_record_optin().
            blocked_at TIMESTAMP NULL DEFAULT NULL,
            updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            UNIQUE INDEX uq_phone (phone),
            -- The Blocklist screen's only query: opted-out numbers, newest block first.
            INDEX idx_status_blocked (status, blocked_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

        // Additive, for installs created before the blocklist screen existed.
        foreach ([
            'reason'     => "ALTER TABLE wa_optins ADD COLUMN reason VARCHAR(255) DEFAULT NULL AFTER source",
            'blocked_at' => "ALTER TABLE wa_optins ADD COLUMN blocked_at TIMESTAMP NULL DEFAULT NULL AFTER reason",
        ] as $col => $ddl) {
            $chk = $conn->query("SHOW COLUMNS FROM wa_optins LIKE '$col'");
            if ($chk && $chk->num_rows === 0) $conn->query($ddl);
        }
        $idx = $conn->query("SHOW INDEX FROM wa_optins WHERE Key_name='idx_status_blocked'");
        if ($idx && $idx->num_rows === 0) $conn->query("ALTER TABLE wa_optins ADD INDEX idx_status_blocked (status, blocked_at)");

        // Guarded separately — the one real row-level write in this function. After the first
        // request seeds it, the SELECT finds a row and nothing is attempted again.
        $seed = $conn->query("SELECT 1 FROM wa_settings LIMIT 1");
        if (!$seed || $seed->num_rows === 0) {
            $cc = $conn->real_escape_string(WA_DEFAULT_COUNTRY_CODE);
            /*
             * api_key / api_base_url / source_id are left blank on purpose. The Settings page is
             * the one place credentials are entered, and a blank value produces a clear "not
             * configured yet" banner instead of silent 401s from a placeholder.
             *
             * 'netcore' here is the ROW KEY, not a provider choice — wa_settings_row() looks the
             * single settings row up by it. Renaming it would mean a migration for no behavioural
             * gain, so it stays as an internal identifier and is stripped from the API response.
             */
            $conn->query("INSERT IGNORE INTO wa_settings
                (provider, is_active, api_key, default_country_code)
                VALUES ('netcore', 1, '', '$cc')");
        }

        // Blanks the BSP endpoint left behind by older installs. Nothing reads this column any
        // more; it is cleared so it can't reappear in a settings response and suggest that
        // messages still route through a third party.
        $conn->query("UPDATE wa_settings SET api_base_url = NULL WHERE api_base_url LIKE '%pepipost%'");

        /*
         * One-time lift of the old single-sender columns into wa_senders. Guarded on the table
         * being empty AND the legacy columns holding something, so it runs at most once and is
         * a no-op on a fresh install (where those columns were never filled in).
         */
        $senderCheck = $conn->query("SELECT 1 FROM wa_senders LIMIT 1");
        if (!$senderCheck || $senderCheck->num_rows === 0) {
            $legacy = $conn->query("SELECT source_id, waba_id, business_number, business_name
                                      FROM wa_settings WHERE provider='netcore' LIMIT 1");
            $lrow = $legacy ? $legacy->fetch_assoc() : null;
            $hasLegacy = $lrow && (trim((string)$lrow['source_id']) !== '' || trim((string)$lrow['business_number']) !== '');
            if ($hasLegacy) {
                $conn->query("INSERT IGNORE INTO wa_senders
                    (waba_id, waba_name, business_number, display_name, source_id, is_default, is_active) VALUES ("
                    . "'" . $conn->real_escape_string((string)$lrow['waba_id']) . "', "
                    . "'" . $conn->real_escape_string((string)$lrow['business_name']) . "', "
                    . "'" . $conn->real_escape_string((string)($lrow['business_number'] ?: 'unknown')) . "', "
                    . "'" . $conn->real_escape_string((string)$lrow['business_name']) . "', "
                    . "'" . $conn->real_escape_string((string)$lrow['source_id']) . "', 1, 1)");
            }
        }

        // Additive columns for a DB created by the first build of this feature (which had no
        // sender concept at all).
        $chk = $conn->query("SHOW COLUMNS FROM wa_campaigns LIKE 'sender_id'");
        if ($chk && $chk->num_rows === 0) {
            $conn->query("ALTER TABLE wa_campaigns ADD COLUMN sender_id INT DEFAULT NULL AFTER business_number");
            $conn->query("ALTER TABLE wa_campaigns ADD COLUMN waba_id VARCHAR(64) DEFAULT NULL AFTER sender_id");
        }
        // Per-number API key, added once it became clear Netcore issues the key per business
        // number rather than per account. Seeded from the account key so an install that was
        // already sending keeps working with no re-entry.
        $chk3 = $conn->query("SHOW COLUMNS FROM wa_settings LIKE 'meta_access_token'");
        if ($chk3 && $chk3->num_rows === 0) {
            $conn->query("ALTER TABLE wa_settings ADD COLUMN meta_access_token TEXT DEFAULT NULL AFTER webhook_secret");
        }
        /*
         * Meta App Secret — used ONLY to verify X-Hub-Signature-256 on incoming webhooks.
         *
         * Distinct from webhook_secret (the verify token, which is used once for the GET
         * handshake) and from meta_access_token (which authorizes our outgoing calls). Three
         * different values with three different jobs; conflating the first two is what silently
         * rejected every genuine webhook before this column existed.
         */
        $chk7 = $conn->query("SHOW COLUMNS FROM wa_settings LIKE 'meta_app_secret'");
        if ($chk7 && $chk7->num_rows === 0) {
            $conn->query("ALTER TABLE wa_settings ADD COLUMN meta_app_secret VARCHAR(255) DEFAULT NULL AFTER meta_access_token");
        }
        // Meta's own id for a template we submitted, so its approval status can be re-checked
        // individually (GET /{template_id}?fields=status) without re-syncing the whole WABA.
        $chk4 = $conn->query("SHOW COLUMNS FROM wa_templates LIKE 'meta_template_id'");
        if ($chk4 && $chk4->num_rows === 0) {
            $conn->query("ALTER TABLE wa_templates ADD COLUMN meta_template_id VARCHAR(64) DEFAULT NULL AFTER name");
        }

        $chk5 = $conn->query("SHOW COLUMNS FROM wa_senders LIKE 'provider'");
        if ($chk5 && $chk5->num_rows === 0) {
            $conn->query("ALTER TABLE wa_senders ADD COLUMN provider ENUM('netcore','meta') NOT NULL DEFAULT 'meta' AFTER display_name");
            $conn->query("ALTER TABLE wa_senders ADD COLUMN phone_number_id VARCHAR(32) DEFAULT NULL AFTER provider");
        }
        $chk6 = $conn->query("SHOW COLUMNS FROM wa_senders LIKE 'registration_pin'");
        if ($chk6 && $chk6->num_rows === 0) {
            $conn->query("ALTER TABLE wa_senders ADD COLUMN registration_pin VARCHAR(12) DEFAULT NULL AFTER phone_number_id");
        }
        /*
         * The forced "everything is Meta now" migration that used to live here has been removed.
         *
         * Meta Cloud API turned out to be blocked at the account level — our app is not connected
         * to the WABA, so every direct send returns "#200 You do not have the necessary
         * permissions" — while Netcore's app IS connected and sends fine. Rewriting the column on
         * every request would have silently overridden an admin choosing the route that works.
         *
         * provider is now a real per-number setting again, and a campaign snapshots its own
         * choice in wa_campaigns.send_provider below.
         */

        // Which API a campaign went out through, snapshotted at send time so changing a number's
        // provider later cannot rewrite the history of an already-sent campaign. NULL means
        // "whatever the sending number is set to", which is what an existing row should do.
        $chk8 = $conn->query("SHOW COLUMNS FROM wa_campaigns LIKE 'send_provider'");
        if ($chk8 && $chk8->num_rows === 0) {
            $conn->query("ALTER TABLE wa_campaigns ADD COLUMN send_provider ENUM('meta','netcore') DEFAULT NULL AFTER waba_id");
        }

        /*
         * Why a campaign stopped, in words, when the cause is the SENDING NUMBER rather than any
         * one recipient — a Cloud API registration that was never done, a locked WABA, a token
         * that cannot use the number. Without this the panel could only show a red FAILED badge
         * next to a per-recipient error whose text names the recipient's phone, which is the one
         * number that is not the problem.
         */
        $chk9 = $conn->query("SHOW COLUMNS FROM wa_campaigns LIKE 'last_error'");
        if ($chk9 && $chk9->num_rows === 0) {
            $conn->query("ALTER TABLE wa_campaigns ADD COLUMN last_error VARCHAR(500) DEFAULT NULL AFTER status");
        }

        /*
         * Conversion goal — same three columns and the same event keys as the email side, so a
         * campaign asking "how many signed in after this?" means the identical thing on both
         * channels and the two numbers can sit next to each other.
         *
         * Attribution differs, though, and deliberately: email counts a conversion only after a
         * tracked click, WhatsApp counts exposure inside the window. WhatsApp template buttons
         * are baked into the approved template and cannot be rewritten per recipient, so there is
         * no click to attribute to. See WaConversionTracker.php.
         */
        /*
         * Click tracking, and the attribution mode it unlocks.
         *
         * WhatsApp reports nothing when someone taps a URL button — the phone just opens a
         * browser. The only way to observe it is to make the link point at US first: the template
         * button carries a per-recipient token, c.php records the tap and forwards to the real
         * destination.
         *
         * Attribution then works exactly as it does for email: the click is recorded, the visitor
         * arrives at the destination carrying campaign_id / medium / attr_window, the dashboard
         * stores that, and record_conversion() writes the campaign_attributions row when the goal
         * fires. Someone who never tapped is never credited; someone who tapped, closed the
         * browser and returned the next day still is.
         *
         * goal_attribution is kept for the rare template whose button URL is static and therefore
         * untrackable — 'exposure' is the only measure possible there. It is not offered as a
         * choice in the wizard; nothing but that fallback should ever set it.
         */
        $chk10 = $conn->query("SHOW COLUMNS FROM wa_campaign_recipients LIKE 'first_clicked_at'");
        if ($chk10 && $chk10->num_rows === 0) {
            $conn->query("ALTER TABLE wa_campaign_recipients
                          ADD COLUMN first_clicked_at DATETIME DEFAULT NULL AFTER click_count,
                          ADD INDEX idx_clicked (campaign_id, first_clicked_at)");
        }

        $chk11 = $conn->query("SHOW COLUMNS FROM wa_campaigns LIKE 'click_target_url'");
        if ($chk11 && $chk11->num_rows === 0) {
            $conn->query("ALTER TABLE wa_campaigns
                          ADD COLUMN click_target_url VARCHAR(1000) DEFAULT NULL,
                          ADD COLUMN goal_attribution ENUM('exposure','click') NOT NULL DEFAULT 'click'");
        }
        // Existing installs were created with 'exposure' as the default before attribution was
        // wired through the dashboard; click is now the only mode the wizard produces.
        $conn->query("ALTER TABLE wa_campaigns MODIFY COLUMN goal_attribution
                      ENUM('exposure','click') NOT NULL DEFAULT 'click'");

        /*
         * Where a tracked button actually sends people.
         *
         * On the TEMPLATE, not the campaign: the button URL is part of what Meta approved, so its
         * real destination is a property of the template and identical for every campaign that
         * uses it. Asking for it once per campaign would be asking the same question repeatedly
         * and inviting a different answer each time.
         *
         * Campaigns snapshot it at send time (wa_campaigns.click_target_url) so editing the
         * template later cannot retarget links already sitting in someone's WhatsApp.
         */
        $chk12 = $conn->query("SHOW COLUMNS FROM wa_templates LIKE 'click_target_url'");
        if ($chk12 && $chk12->num_rows === 0) {
            $conn->query("ALTER TABLE wa_templates ADD COLUMN click_target_url VARCHAR(1000) DEFAULT NULL AFTER buttons");
        }

        /*
         * wa_links — one short, PERMANENT id per template, standing in for the whole attribution
         * query string.
         *
         * WHY THIS EXISTS AT ALL
         * The first design put the attribution on the link itself, as a per-recipient variable:
         *
         *     https://dashboard.internshipstudio.com/login?{{1}}
         *
         * Meta refused to approve it. Every submission came back INCORRECT_CATEGORY, under both
         * UTILITY and MARKETING — a variable that becomes a query string is indistinguishable, to
         * a reviewer, from a tracking parameter bolted onto a login page, and the templates on
         * this WABA that carry a plain static link (whats_app_link, whatsapp_common_link) are the
         * ones that got approved.
         *
         * So the campaign context moves OFF the URL and into a row here. The template is approved
         * with a link that has no variable in it at all:
         *
         *     https://dashboard.internshipstudio.com/login/23
         *
         * and 23 is this table's primary key. The landing page reads the 23, asks link.php what it
         * means, and gets back the same campaign_id / medium / attr_window that c.php used to put
         * in the query string — so everything downstream (the attribution cookie,
         * campaign_attributions, the conversion cron) is byte-for-byte the email flow and needed
         * no changes.
         *
         * ONE ROW PER TEMPLATE, not per campaign, because the id is baked into what Meta approved
         * and cannot differ between sends. campaign_id below is therefore the LAST campaign that
         * sent this template — rebound on every send, which is what makes a re-used template
         * credit the send that is actually running rather than one from three months ago.
         *
         * The trade: a static link is the same for everyone, so the tap alone no longer says WHICH
         * person tapped. link.php recovers that as soon as they are logged in, by matching the
         * campaign's recipient list on user_id. Until then it is a campaign-level click, which is
         * exactly what the approved templates on this account could ever have measured.
         *
         * AUTO_INCREMENT starts at 101 only so the ids are never one character long — a bare "/1"
         * on the end of a URL reads like a typo and invites someone to try "/2".
         */
        $conn->query("CREATE TABLE IF NOT EXISTS wa_links (
            id               INT AUTO_INCREMENT PRIMARY KEY,
            template_id      INT DEFAULT NULL,
            target_url       VARCHAR(1000) NOT NULL,
            campaign_id      INT DEFAULT NULL,
            goal_event_name  VARCHAR(255) DEFAULT NULL,
            goal_window_days INT NOT NULL DEFAULT 2,
            click_count      INT NOT NULL DEFAULT 0,
            bound_at         DATETIME DEFAULT NULL,
            created_at       TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            UNIQUE KEY uq_template (template_id),
            KEY idx_campaign (campaign_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 AUTO_INCREMENT=101");

        $chk13 = $conn->query("SHOW COLUMNS FROM wa_templates LIKE 'link_id'");
        if ($chk13 && $chk13->num_rows === 0) {
            $conn->query("ALTER TABLE wa_templates ADD COLUMN link_id INT DEFAULT NULL AFTER click_target_url");
        }
        /*
         * ── Multi-WABA templates and category drift ─────────────────────────────────
         * Added here, in the schema every WhatsApp entrypoint already runs, rather than only
         * in lib/WaTemplateWabas.php: wa_inbox.php and wa_campaigns.php filter on
         * auto_disabled and would fatal against a column that does not exist yet.
         *
         *   meta_category        what META has this filed as today. `category` stays what the
         *                        template was BUILT and submitted as — drift is the difference
         *                        between the two, so they cannot be the same column.
         *   auto_disabled        set when they disagree. A drifted template stops being
         *                        selectable in campaigns, journeys and the live-chat composer,
         *                        because a UTILITY template silently reclassified as MARKETING
         *                        is billed differently, needs marketing opt-in, and is dropped
         *                        for anyone over their marketing cap.
         *   disabled_reason      the sentence shown on the card.
         *   category_checked_at  throttles the re-read against Meta.
         */
        $waTplCols = [
            'meta_category'       => "ALTER TABLE wa_templates ADD COLUMN meta_category VARCHAR(32) DEFAULT NULL AFTER category",
            'auto_disabled'       => "ALTER TABLE wa_templates ADD COLUMN auto_disabled TINYINT(1) NOT NULL DEFAULT 0 AFTER approval_status",
            'disabled_reason'     => "ALTER TABLE wa_templates ADD COLUMN disabled_reason VARCHAR(400) DEFAULT NULL AFTER auto_disabled",
            'category_checked_at' => "ALTER TABLE wa_templates ADD COLUMN category_checked_at DATETIME DEFAULT NULL AFTER disabled_reason",
        ];
        foreach ($waTplCols as $col => $ddl) {
            $chk = $conn->query("SHOW COLUMNS FROM wa_templates LIKE '$col'");
            if ($chk && $chk->num_rows === 0) $conn->query($ddl);
        }

        /*
         * WhatsApp inbound media moved off local disk and into S3 (see wa_media_fetch() in
         * lib/WaInbox.php). These two columns are the reference that replaces the file:
         * media_s3_key for deleting it, media_s3_url for reading it. local_path stays, and
         * stays populated for anything downloaded before the move, so old conversations keep
         * opening — but nothing writes to it any more.
         */
        $waMsgCols = [
            'media_s3_key' => "ALTER TABLE wa_messages ADD COLUMN media_s3_key VARCHAR(400) DEFAULT NULL AFTER local_path",
            'media_s3_url' => "ALTER TABLE wa_messages ADD COLUMN media_s3_url VARCHAR(700) DEFAULT NULL AFTER media_s3_key",
        ];
        foreach ($waMsgCols as $col => $ddl) {
            $chk = $conn->query("SHOW COLUMNS FROM wa_messages LIKE '$col'");
            if ($chk && $chk->num_rows === 0) $conn->query($ddl);
        }


        /*
         * A link belongs to whoever SENT it last — and that is no longer always a campaign.
         *
         * The id is frozen into the approved template, so one template used by a WhatsApp
         * campaign AND by a journey step hands out the same /login/101 to both. With only
         * campaign_id here, every journey tap resolved to whichever campaign happened to bind
         * the link last: the journey's Clicked column stayed at 0 and that campaign's climbed
         * with taps it never earned.
         *
         * BOTH ids are kept, not one polymorphic pair, because the login-time correction below
         * needs to ask "when did each of them last message this person?" and compare. owner_kind
         * is only the tiebreak for an ANONYMOUS tap, where there is nobody to ask about.
         */
        $chk14 = $conn->query("SHOW COLUMNS FROM wa_links LIKE 'owner_kind'");
        if ($chk14 && $chk14->num_rows === 0) {
            $conn->query("ALTER TABLE wa_links
                          ADD COLUMN owner_kind VARCHAR(16) NOT NULL DEFAULT 'campaign' AFTER campaign_id,
                          ADD COLUMN journey_id INT DEFAULT NULL AFTER owner_kind,
                          ADD KEY idx_journey (journey_id)");
        }

        /*
         * wa_link_clicks — EVERY tap, one row each. A log, not a counter.
         *
         * Counters answer "how many" and nothing else. When the number looked wrong there was no
         * way to ask why, because the taps that produced it had already been added together and
         * thrown away. This keeps them: every tap, with whatever was known about the person at the
         * moment it happened, so any figure on the report can be opened and checked.
         *
         * Deliberately NO unique constraint. Deduplication is a question asked at read time, and
         * asking it at write time destroys the evidence.
         *
         * identity_key IS THE DEDUPLICATION KEY, in this order of preference:
         *
         *   phone            the real identity. Two logins, three devices, one number — one person.
         *   email            when there is no number on the account.
         *   visitor:<random> a value the browser keeps for itself. It names nobody; it only says
         *                    "this browser has been here before", which is the most that can be
         *                    known about a tap from a logged-out phone. A static tracked link is
         *                    identical in every message, so an anonymous tap carries no identity
         *                    at all — without this, unique clicks could only ever read 0.
         *
         * The anonymous case resolves itself: when the visitor signs in, link.php rewrites the
         * earlier rows for that visitor_key with the real phone and email, so a tap that began
         * anonymous ends up counted under the person who made it rather than as a second stranger.
         *
         * Rows are per CAMPAIGN, not per link: the link id is frozen into the approved template
         * and outlives every campaign that uses it, so keying on the link alone would make a
         * second campaign's audience look like returning visitors.
         */
        /*
         * COLLATE is stated explicitly on this table. Without it MySQL 8 applies the server
         * default (utf8mb4_0900_ai_ci) while every neighbouring table in this feature names
         * utf8mb4_unicode_ci — and joining wa_link_clicks.phone to
         * wa_campaign_recipients.phone across that boundary raises error 1267, "Illegal mix
         * of collations", which is a 500 rather than a wrong answer.
         *
         * Existing installs keep whatever they were created with, so the queries that cross
         * that boundary still state COLLATE on the comparison itself (see the clicks action
         * in wa_campaigns.php). This only stops NEW installs inheriting the problem.
         */
        $conn->query("CREATE TABLE IF NOT EXISTS wa_link_clicks (
            id           BIGINT AUTO_INCREMENT PRIMARY KEY,
            link_id      INT NOT NULL,
            campaign_id  INT DEFAULT NULL,
            recipient_id INT DEFAULT NULL,
            visitor_key  VARCHAR(64) DEFAULT NULL,
            user_id      INT DEFAULT NULL,
            phone        VARCHAR(20) DEFAULT NULL,
            email        VARCHAR(190) DEFAULT NULL,
            identity_key VARCHAR(190) NOT NULL,
            ip           VARCHAR(45) DEFAULT NULL,
            user_agent   VARCHAR(255) DEFAULT NULL,
            clicked_at   DATETIME NOT NULL,
            KEY idx_campaign (campaign_id, clicked_at),
            KEY idx_identity (campaign_id, identity_key),
            KEY idx_visitor (campaign_id, visitor_key),
            KEY idx_link (link_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

        // Same reason as wa_links above: a tap logged with only a campaign_id cannot later be
        // read back as a journey's. NULL campaign_id + a journey_id is a journey tap.
        $chk15 = $conn->query("SHOW COLUMNS FROM wa_link_clicks LIKE 'journey_id'");
        if ($chk15 && $chk15->num_rows === 0) {
            $conn->query("ALTER TABLE wa_link_clicks
                          ADD COLUMN journey_id INT DEFAULT NULL AFTER campaign_id,
                          ADD KEY idx_journey (journey_id, clicked_at)");
        }

        $chk9 = $conn->query("SHOW COLUMNS FROM wa_campaigns LIKE 'goal_event_name'");
        if ($chk9 && $chk9->num_rows === 0) {
            $conn->query("ALTER TABLE wa_campaigns
                          ADD COLUMN goal_event_name  VARCHAR(255) DEFAULT NULL AFTER send_provider,
                          ADD COLUMN goal_window_days INT NOT NULL DEFAULT 2   AFTER goal_event_name,
                          ADD COLUMN conversion_count INT NOT NULL DEFAULT 0   AFTER goal_window_days");
        }

        $chk2 = $conn->query("SHOW COLUMNS FROM wa_senders LIKE 'api_key'");
        if ($chk2 && $chk2->num_rows === 0) {
            $conn->query("ALTER TABLE wa_senders ADD COLUMN api_key TEXT DEFAULT NULL AFTER display_name");
            $conn->query("UPDATE wa_senders s
                            JOIN wa_settings t ON t.provider = 'netcore'
                             SET s.api_key = t.api_key
                           WHERE (s.api_key IS NULL OR s.api_key = '') AND t.api_key <> ''");
        }
    } catch (\Throwable $e) {
        // Another concurrent request is running this same idempotent setup. Every statement
        // above is CREATE-IF-NOT-EXISTS / INSERT-IGNORE, so whoever wins still leaves the
        // schema correct and this request continues instead of fatal-erroring the page.
        error_log('whatsapp_ensure_schema: ' . $e->getMessage());
    }
}

/** The single settings row (account-level credentials), or null before it's seeded. */
function wa_settings_row(): ?array {
    global $conn;
    $r = $conn->query("SELECT * FROM wa_settings WHERE provider='netcore' LIMIT 1");
    $row = $r ? $r->fetch_assoc() : null;
    return $row ?: null;
}

/** Every configured sending number, default first. */
function wa_senders_all(bool $activeOnly = false): array {
    global $conn;
    $where = $activeOnly ? 'WHERE is_active = 1' : '';
    $r = $conn->query("SELECT * FROM wa_senders $where ORDER BY is_default DESC, waba_id ASC, id ASC");
    $rows = [];
    while ($r && $row = $r->fetch_assoc()) $rows[] = $row;
    return $rows;
}

function wa_sender_by_id(?int $id): ?array {
    global $conn;
    if (!$id) return null;
    $r = $conn->query("SELECT * FROM wa_senders WHERE id=" . (int)$id . ' LIMIT 1');
    $row = $r ? $r->fetch_assoc() : null;
    return $row ?: null;
}

/**
 * The number a campaign uses when it hasn't picked one: the flagged default, else the first
 * active number that can actually send.
 *
 * "Can send" depends on the route — a Netcore number needs its API key, a Meta number needs its
 * phone number ID — so readiness is checked per provider. The old single check on api_key dated
 * from when Netcore was the only route, and would now push a perfectly good Meta number to the
 * back of the queue for lacking a key it has no use for.
 */
function wa_default_sender(): ?array {
    global $conn;
    $r = $conn->query("SELECT * FROM wa_senders
                        WHERE is_active = 1
                        ORDER BY is_default DESC,
                                 (provider = 'netcore' AND (api_key IS NULL OR api_key = '')) ASC,
                                 (provider <> 'netcore' AND (phone_number_id IS NULL OR phone_number_id = '')) ASC,
                                 id ASC
                        LIMIT 1");
    $row = $r ? $r->fetch_assoc() : null;
    return $row ?: null;
}

/**
 * The API key a given sender sends with: its own, falling back to the account-level key.
 *
 * The fallback exists for the single-number case and for installs that entered one key before
 * this was per-number — with two numbers configured, each needs its own or both would go out
 * as whichever number the shared key belongs to.
 */
/**
 * The transport a message actually goes out through.
 *
 * Both routes are live and neither is a fallback for the other:
 *
 *   meta     Cloud API direct. No middleman, richer errors, but it only works once the Meta app
 *            is connected to the WABA — otherwise every send is "#200 permissions".
 *   netcore  The BSP. Works today because Netcore's app holds that connection.
 *
 * Template approval status is read from Meta's Graph API either way: Netcore's messaging API has
 * no template endpoint, and Meta is the authority on what is approved regardless of who delivers
 * it. So this function decides delivery only.
 *
 * @param ?string $override the campaign's snapshotted send_provider, when it has one
 */
function wa_transport_for_sender(array $settings, ?array $sender, ?string $override = null) {
    $provider = wa_resolve_provider($sender, $override);

    if ($provider === 'netcore') {
        require_once __DIR__ . '/NetcoreTransport.php';
        return new NetcoreTransport(
            // Per business number, not per account — that key is what decides which number a
            // message goes out from, so an account-level fallback would send as the wrong one.
            trim((string)($sender['api_key'] ?? '')),
            trim((string)($sender['source_id'] ?? '')),
            trim((string)($settings['api_base_url'] ?? '')) ?: null
        );
    }

    require_once __DIR__ . '/MetaCloudTransport.php';
    return new MetaCloudTransport(
        trim((string)($settings['meta_access_token'] ?? '')),
        trim((string)($sender['phone_number_id'] ?? ''))
    );
}

/**
 * 'meta' or 'netcore', in priority order: the campaign's own choice, then the sending number's
 * default, then Meta.
 *
 * Anything unrecognised resolves to 'meta' rather than erroring — an unreadable value must not
 * be able to stop a campaign, and Meta's failure mode (a descriptive rejection) is far easier to
 * diagnose than a silently mis-routed send.
 */
function wa_resolve_provider(?array $sender, ?string $override = null): string {
    $v = strtolower(trim((string)($override ?: ($sender['provider'] ?? ''))));
    return $v === 'netcore' ? 'netcore' : 'meta';
}

/**
 * The sender a given campaign will actually go out through.
 *
 * Falls back to the default number when the campaign's chosen sender was deleted, rather than
 * failing the send — but the caller still validates that whatever comes back has a Source ID,
 * because sending without one is accepted by the API and silently discarded.
 */
function wa_sender_for_campaign(array $campaign): ?array {
    $chosen = wa_sender_by_id(isset($campaign['sender_id']) ? (int)$campaign['sender_id'] : null);
    return $chosen ?: wa_default_sender();
}

<?php
/*
 * Netcore Cloud (Pepipost) WhatsApp transport — sending through the BSP instead of Meta directly.
 *
 *   POST https://waapi.pepipost.com/api/v2/message/
 *   Authorization: Bearer <the API key issued for THIS business number>
 *   { "message": [ { "recipient_whatsapp": "919…", "message_type": "template", … } ] }
 *
 * Restored after the Meta Cloud API path turned out to be blocked at the account level: our app
 * is not connected to the WABA (Meta answers every send with "#200 You do not have the necessary
 * permissions"), and only Netcore or a new WABA can change that. Netcore's app IS connected, so
 * this path works today — hence both existing side by side rather than one replacing the other.
 *
 * WHY THIS IS A SEPARATE CLASS AND NOT A FLAG
 * The two APIs disagree on essentially every detail of the same message:
 *
 *                    Meta Cloud API              Netcore
 *   language         {"code": "en"}              {"locale": "en", "policy": "deterministic"}
 *   variables        nested components[]         flat attributes[]
 *   media header     component parameter         its own type_media_template block
 *   preview_url      real boolean                the STRING "false"
 *   envelope         one message object          a message[] array
 *   correlation      the returned wamid          the x-apiheader we send, echoed on webhooks
 *
 * Every one of those was learned from a rejection, and each has a comment where it bites.
 *
 * Templates are NOT read from here. Netcore's messaging API has no template endpoint at all —
 * its documented surface is consent, send-message, media, webhooks and reports — so approval
 * status keeps coming from Meta's Graph API regardless of which transport sends. That split is
 * deliberate: Meta is the authority on what is approved, Netcore is only a delivery route.
 */
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/WaHelpers.php';

class NetcoreTransport {
    private string $apiKey;
    private string $source;
    private string $baseUrl;

    public function __construct(string $apiKey, string $source = '', ?string $baseUrl = null) {
        $this->apiKey  = trim($apiKey);
        $this->source  = trim($source);
        // Trailing slash normalised once, so callers can store the base either way.
        $this->baseUrl = rtrim($baseUrl ?: 'https://waapi.pepipost.com/api/v2/', '/') . '/';
    }

    /** Netcore issues the key PER business number, so the key alone identifies the sender. */
    public function isConfigured(): bool { return $this->apiKey !== ''; }

    /**
     * Whether delivery receipts can be routed back to us.
     *
     * The `source` is Netcore's webhook routing tag, not part of the sender's identity: without
     * it the endpoint receives events for every message on that number, including other systems
     * sharing it. Messages still send — only reporting gets noisier.
     */
    public function hasSource(): bool { return $this->source !== ''; }

    public function buildRequest(string $to, array $content, string $rid): array {
        $msg = [
            'recipient_whatsapp' => $to,
            'recipient_type'     => 'individual',
        ];
        if ($this->source !== '') $msg['source'] = $this->source;

        if (($content['type'] ?? 'template') === 'text') {
            $text = (string)($content['body'] ?? '');
            $msg['message_type'] = 'text';
            $msg['type_text'] = [[
                'content' => $text,
                /*
                 * The literal string "false", not a boolean — and it must be "false" whenever the
                 * body has no link. Sending true without a URL is rejected with
                 *   8006 "if preview url is true then you must set at least one url"
                 * which reads like a bug in our code rather than a payload rule.
                 */
                'preview_url' => (!empty($content['preview_url']) && preg_match('~(https?://|www\.)\S+~i', $text)) ? 'true' : 'false',
            ]];
        } elseif (($content['type'] ?? '') === 'media') {
            /*
             * A standalone attachment (Live Chat, not a campaign). Unlike Meta, Netcore never
             * takes a media id — it fetches the URL itself at send time, which is why the file
             * is published under a signed public URL before we get here (wa_public_media_url).
             * The block is its own message type rather than a parameter, mirroring the
             * media_template shape below.
             */
            $m = $content['media'] ?? [];
            $msg['message_type'] = 'media';
            $block = ['type' => (string)($m['type'] ?? 'image'), 'url' => (string)($m['url'] ?? '')];
            if (!empty($m['caption']))  $block['caption']  = (string)$m['caption'];
            if (!empty($m['filename'])) $block['filename'] = (string)$m['filename'];
            $msg['type_media'] = [$block];
        } else {
            $block = [
                'name'       => (string)($content['name'] ?? ''),
                'attributes' => array_values(array_map('strval', $content['attributes'] ?? [])),
                /*
                 * locale, NOT code. Meta's key name here produces
                 *   8006 "Template language locale cannot be null or blank"
                 * — the field is simply absent as far as Netcore is concerned, so the error names
                 * a value you did send. 'deterministic' means "use exactly this language", which
                 * is the only sane choice when the template was approved in one language.
                 */
                'language'   => [
                    'locale' => (string)($content['language'] ?? 'en'),
                    'policy' => 'deterministic',
                ],
            ];

            // Kept out of `attributes` — that array is the body's parameter list, and putting the
            // button's value in it produces error 132000 (see netcore_build_attributes).
            if (!empty($content['buttons'])) $block['buttons'] = $content['buttons'];

            $mediaUrl  = trim((string)($content['header_media_url'] ?? ''));
            $mediaType = (string)($content['header_type'] ?? 'none');

            if ($mediaUrl !== '' && in_array($mediaType, ['image', 'video', 'document'], true)) {
                // A media header is its own message type here, not a parameter on the template.
                $block['media'] = ['type' => $mediaType, 'url' => $mediaUrl];
                $msg['message_type']       = 'media_template';
                $msg['type_media_template'] = [$block];
            } else {
                $msg['message_type']  = 'template';
                $msg['type_template'] = [$block];
            }
        }

        /*
         * The outgoing body, logged once per run.
         *
         * Netcore's rejections name a field ("buttons: Button at index 0 of type Url requires a
         * parameter") without showing what it actually received, so the only way to tell "we sent
         * the wrong shape" from "we sent nothing" is to look at what left here. Every hour spent
         * on this integration so far has ended with reading one raw payload.
         *
         * Once per run, not per message: a 40k campaign would otherwise write 40k copies.
         */
        if (function_exists('wa_log')) {
            static $loggedRequest = false;
            if (!$loggedRequest) {
                $loggedRequest = true;
                wa_log('netcore: request body -> ' . mb_substr(json_encode(['message' => [$msg]]), 0, 700));
            }
        }

        return [
            'url'     => $this->baseUrl . 'message/',
            'headers' => [
                'Content-Type: application/json',
                'Authorization: Bearer ' . $this->apiKey,
                // Echoed verbatim on every webhook for this message. It is how a delivery receipt
                // finds its recipient row when the provider's own id isn't in the payload —
                // webhook.php reads it back as `x-apiheader`.
                'x-apiheader: ' . $rid,
            ],
            'body'    => json_encode(['message' => [$msg]]),
        ];
    }

    /**
     * @return array{ok: bool, message_id: ?string, error: ?string, code: ?string, retryable: bool}
     */
    public function parseResponse(int $status, ?string $body, string $curlError, ?string $rid): array {
        if ($curlError !== '') {
            return ['ok' => false, 'message_id' => null, 'error' => "Network error: $curlError", 'code' => 'network', 'retryable' => true];
        }

        $decoded = json_decode((string)$body, true);
        if (!is_array($decoded)) {
            return ['ok' => false, 'message_id' => null, 'error' => 'Unreadable response: ' . mb_substr((string)$body, 0, 200),
                    'code' => (string)$status, 'retryable' => $status >= 500];
        }

        /*
         * The message id is SEARCHED FOR, not read from a fixed path.
         *
         * Enumerating candidate paths was a guess, and it was wrong: the id came back under none
         * of them, so every send stored our own rid instead and no delivery receipt could ever be
         * correlated — campaigns reported "2 accepted" and 0 delivered forever. Netcore's response
         * shape also differs between message types, so any fixed path is one message type away
         * from being wrong again.
         *
         * A recursive hunt for the first key that looks like a message id is robust to all of
         * that, and there is nothing else in these responses it could confuse for one.
         */
        $id = wa_find_message_id($decoded);

        $statusText = strtolower((string)($decoded['status'] ?? ''));
        $ok = $status >= 200 && $status < 300
            && ($id !== null || in_array($statusText, ['success', 'ok', 'queued', 'accepted'], true))
            && !isset($decoded['error']);

        if ($ok) {
            /*
             * No per-message id is the NORMAL case here, not a fault worth warning about.
             * Netcore acknowledges the request, not the message:
             *
             *   {"status":"success","message":"Request received successfully.",
             *    "data":{"id":"6aafb690-5c38-4fd6-bec4-c3d3a91af04e"}}
             *
             * That uuid identifies the API call, and never appears again — the webhooks that
             * follow report Meta wamids instead, and Netcore does not echo the x-apiheader we
             * send. So nothing we hold at send time can ever be matched against a receipt.
             *
             * The rid is kept as a placeholder so the row has a stable handle, and correlation is
             * done by recipient phone number in webhook.php, which is the only value present on
             * both sides. The response shape is still logged once per run so a future change to
             * their API shows up here instead of silently breaking delivery counts.
             */
            if ($id === null && function_exists('wa_log')) {
                static $loggedShape = false;
                if (!$loggedShape) {
                    $loggedShape = true;
                    wa_log('netcore: no per-message id in the response (expected — receipts are matched by phone). Raw: '
                        . mb_substr(preg_replace('/\s+/', ' ', (string)$body), 0, 300));
                }
            }
            return ['ok' => true, 'message_id' => $id ?? $rid, 'error' => null, 'code' => null, 'retryable' => false];
        }

        $err  = $decoded['error'] ?? [];
        $code = (string)($err['code'] ?? ($decoded['code'] ?? $status));
        $msg  = $err['message'] ?? ($decoded['message'] ?? ($body ?: "HTTP $status"));
        if (is_array($msg)) $msg = json_encode($msg);

        /*
         * 8006 is Netcore's catch-all validation error and is never worth retrying — the payload
         * will be identical next time. Genuine transients are throttling and 5xx.
         */
        $retryable = $status === 429 || $status >= 500
            || in_array($code, ['429', '503', '1001'], true)
            || stripos((string)$msg, 'rate limit') !== false;

        return ['ok' => false, 'message_id' => null, 'error' => "Netcore $code: $msg", 'code' => $code, 'retryable' => $retryable];
    }

    public function sendMessage(string $to, array $content, string $rid): array {
        if (!$this->isConfigured()) {
            return ['ok' => false, 'message_id' => null,
                    'error' => 'No Netcore API key set for this sending number — add it in Settings → Sending numbers → Edit',
                    'code' => 'unconfigured', 'retryable' => false];
        }
        $req = $this->buildRequest($to, $content, $rid);
        [$status, $body, $curlErr] = wa_http_exec($req);
        return $this->parseResponse($status, $body, $curlErr, $rid);
    }
}

/**
 * The first value in a decoded response that looks like a provider message id.
 *
 * Walks the whole structure rather than trusting a path, because Netcore's envelope varies by
 * message type and by endpoint version. The key test is deliberately narrow — a key whose name is
 * about message identity — so it can't latch onto a request id, a template id or a phone number.
 *
 * Values are sanity-checked for length too: an id short enough to be a status code ("1", "ok") is
 * not an id, and storing one would make every message in a batch correlate to the same row.
 */
function wa_find_message_id($node): ?string {
    if (!is_array($node)) return null;

    foreach ($node as $key => $value) {
        if (is_string($key)
            && preg_match('/^(wamid|mid|message_?id|msg_?id|messageId)$/i', $key)
            && (is_string($value) || is_numeric($value))) {
            $v = trim((string)$value);
            if ($v !== '' && strlen($v) >= 8) return $v;
        }
    }
    // Breadth-first: a top-level id outranks one nested inside a per-recipient block.
    foreach ($node as $value) {
        if (is_array($value)) {
            $found = wa_find_message_id($value);
            if ($found !== null) return $found;
        }
    }
    return null;
}

/**
 * The flat ordered variable list Netcore expects, in place of Meta's nested components.
 *
 * Length comes from the template's own placeholder count, not from however many values happen to
 * be filled in: a template approved with two variables must be sent with exactly two, in order,
 * and a missing one becomes an empty string rather than shortening the list and shifting every
 * value after it into the wrong slot.
 *
 * Header variables lead, because Netcore numbers a template's placeholders continuously across
 * header and body rather than restarting per component the way Meta does.
 */
function netcore_build_attributes(array $tpl, array $resolved): array {
    $out = [];

    if (($tpl['header_type'] ?? 'none') === 'text') {
        $headerVars = wa_placeholder_count((string)($tpl['header_text'] ?? ''));
        for ($i = 0; $i < $headerVars; $i++) $out[] = (string)($resolved['header'][$i] ?? '');
    }

    $bodyVars = wa_placeholder_count((string)($tpl['body_text'] ?? ''));
    for ($i = 0; $i < $bodyVars; $i++) $out[] = (string)($resolved['body'][$i] ?? '');

    /*
     * The dynamic BUTTON value is deliberately NOT appended here.
     *
     * It used to be, and Netcore rejected every such message with:
     *
     *   132000  body: number of localizable_params (1) does not match the expected number of
     *           params (0)
     *
     * `attributes` is the BODY's parameter list and nothing else. A template with no body
     * variables but a tracked button therefore looked like it had one body param too many, and
     * WhatsApp refused the whole message — accepted by the API, then failed on the webhook, which
     * is the hardest failure of all to read. The button's value goes in its own block; see
     * netcore_build_buttons().
     */
    return $out;
}

/**
 * The button parameter block, which Netcore carries separately from `attributes`.
 *
 * Only a DYNAMIC url button takes a value: a static url or a quick-reply is baked into the
 * template Meta approved, and sending a parameter for one is an error in its own right.
 *
 * @return array [] when this template has nothing to fill — the key is then omitted entirely
 *               rather than sent empty, which is itself a rejection.
 */
function netcore_build_buttons(array $tpl, array $resolved): array {
    $buttons = $tpl['buttons'] ?? [];
    if (is_string($buttons)) $buttons = json_decode($buttons, true) ?: [];

    foreach ((array)$buttons as $btn) {
        if (($btn['type'] ?? '') !== 'url' || empty($btn['dynamic'])) continue;
        $suffix = (string)($resolved['button_url_suffix'] ?? '');
        if ($suffix === '') continue;
        /*
         * A FLAT list of values, mirroring `attributes`.
         *
         * The object form [{type, index, parameter}] was ignored outright — Netcore replied
         *   131008  buttons: Button at index 0 of type Url requires a parameter
         * i.e. it saw the button, found no value, and passed Meta's complaint back. Their API is
         * consistently positional (attributes is a bare list of body values), so buttons is read
         * the same way: one value per button that takes one, in template order.
         */
        return [$suffix];
    }
    return [];
}

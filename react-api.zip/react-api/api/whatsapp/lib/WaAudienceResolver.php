<?php
/*
 * Turns a WhatsApp campaign's Audience-step config into actual reachable numbers.
 *
 * The segment/list resolution itself is NOT reimplemented here — it reuses the email
 * pipeline's resolve_audience_users() (campaigns/lib/AudienceResolver.php), which already
 * returns `phone` alongside email/name for both halves of an audience (segments over `users`
 * and lists over `campaign_contacts`). That is deliberate: an admin picking "iCAT 174
 * registrations" must get the same people whichever channel they pick, and two independent
 * copies of segment SQL would inevitably drift.
 *
 * What IS specific to this channel:
 *   - reachability means a usable phone number, not an email address
 *   - numbers arrive in a dozen shapes (9921079337, +91 99210 79337, 0992..., 91-992...)
 *     and must be normalized to WhatsApp's E.164-digits form before they can be compared,
 *     de-duplicated, or sent to
 *   - deduplication (the DB-level intra-campaign guarantee plus the optional cross-campaign
 *     window) is applied here, on normalized numbers
 */
require_once __DIR__ . '/../../campaigns/lib/AudienceResolver.php';
require_once __DIR__ . '/schema.php';

/**
 * Normalizes one phone number to the digits-only international form WhatsApp expects
 * (country code + subscriber number, no '+', no spaces/dashes/parens).
 *
 * Returns null when the value cannot be a real mobile number — that's what makes a contact
 * "unreachable" on this channel, and unreachable contacts are counted and skipped rather
 * than sent as a guaranteed provider rejection.
 */
function wa_normalize_phone(?string $raw, string $defaultCc = WA_DEFAULT_COUNTRY_CODE): ?string {
    $raw = trim((string)$raw);
    if ($raw === '') return null;

    $hadPlus = str_starts_with($raw, '+');
    $digits  = preg_replace('/\D+/', '', $raw);
    if ($digits === '') return null;

    // Trunk prefix: a domestic 0 before the subscriber number (011..., 09921079337).
    if (strlen($digits) > 10 && str_starts_with($digits, '0')) {
        $digits = ltrim($digits, '0');
    }
    // "00" international prefix written out in full.
    if (str_starts_with($digits, '00')) $digits = substr($digits, 2);

    $cc = preg_replace('/\D+/', '', $defaultCc) ?: WA_DEFAULT_COUNTRY_CODE;

    if (!$hadPlus && strlen($digits) === 10) {
        // A bare national mobile — the overwhelmingly common shape in this database.
        $digits = $cc . $digits;
    }

    // Anything outside the E.164 envelope is junk data (landline fragments, "NA", ids that
    // ended up in a phone column), not a number worth burning a send attempt on.
    $len = strlen($digits);
    if ($len < 10 || $len > 15) return null;

    // A 10-digit Indian mobile never starts below 6; after prefixing, a 91XXXXXXXXXX whose
    // subscriber part starts 0-5 is a mangled record, not a real number.
    if ($cc === '91' && $len === 12 && str_starts_with($digits, '91')) {
        $sub = substr($digits, 2);
        if (!preg_match('/^[6-9]\d{9}$/', $sub)) return null;
    }

    return $digits;
}

/** Country code configured in Settings, falling back to the build-time default. */
function wa_default_cc(): string {
    $s = wa_settings_row();
    $cc = trim((string)($s['default_country_code'] ?? ''));
    return $cc !== '' ? $cc : WA_DEFAULT_COUNTRY_CODE;
}

/**
 * The campaign's audience as WhatsApp-ready rows, de-duplicated by normalized number.
 *
 * @param array $config audience_type / segment_ids / exclude_segment_ids / list_ids
 * @return array{recipients: array, unreachable: int, duplicates: int}
 *         `recipients` rows carry phone + the identity fields merge tags and Customer
 *         Attributes need downstream (attributes are keyed by email — see
 *         campaigns/lib/AttributeResolver.php — which is why email is carried along even
 *         though this channel never sends to it).
 */
function wa_resolve_audience(array $config): array {
    $cc    = wa_default_cc();
    $users = resolve_audience_users($config);

    $byPhone = [];
    $unreachable = 0;
    $duplicates  = 0;

    foreach ($users as $u) {
        $phone = wa_normalize_phone($u['phone'] ?? '', $cc);
        if ($phone === null) { $unreachable++; continue; }
        if (isset($byPhone[$phone])) {
            // Same person reachable through several selected segments/lists, or two contact
            // records sharing a number. Collapsed here AND guarded by uq_campaign_phone at
            // insert time — this count is what the Audience step reports as "duplicates
            // merged", so the number is visible rather than silently swallowed.
            $duplicates++;
            // Prefer whichever copy actually carries a user_id: that's what unlocks mapped
            // Customer Attributes and exam data for this recipient.
            if (empty($byPhone[$phone]['user_id']) && !empty($u['user_id'])) {
                $byPhone[$phone] = wa_recipient_row($phone, $u);
            }
            continue;
        }
        $byPhone[$phone] = wa_recipient_row($phone, $u);
    }

    return ['recipients' => array_values($byPhone), 'unreachable' => $unreachable, 'duplicates' => $duplicates];
}

function wa_recipient_row(string $phone, array $u): array {
    return [
        'phone'      => $phone,
        'raw_phone'  => (string)($u['phone'] ?? ''),
        'user_id'    => $u['user_id'] ?? null,
        'email'      => (string)($u['email'] ?? ''),
        'first_name' => (string)($u['first_name'] ?? ''),
        'last_name'  => (string)($u['last_name'] ?? ''),
    ];
}

/**
 * Live "reachable contacts" figure for the Audience step.
 *
 * Unlike the email side's resolve_audience_count() this cannot be a pure COUNT(*) in SQL:
 * reachability depends on whether a stored phone string normalizes to a real number, and two
 * different strings ("+91 99210 79337" and "9921079337") are the SAME person. Both facts only
 * exist after PHP-side normalization, so the rows are resolved and folded here. It stays
 * responsive because the Audience step debounces this call (450ms) exactly like email does.
 */
function wa_resolve_audience_count(array $config): array {
    $res = wa_resolve_audience($config);
    return [
        'count'       => count($res['recipients']),
        'unreachable' => $res['unreachable'],
        'duplicates'  => $res['duplicates'],
    ];
}

/**
 * Cross-campaign deduplication: of the given normalized numbers, which ones already received
 * a WhatsApp campaign message inside the window?
 *
 * This is the optional layer ON TOP of the always-on intra-campaign dedup. Scope
 * 'all_campaigns' means "don't message this person again about anything this soon";
 * 'same_template' narrows it to repeats of the same approved template, which is the useful
 * setting for recurring reminders that legitimately go out to overlapping audiences.
 *
 * @param string[] $phones
 * @return array<string,true> phone => true for every number that must be skipped
 */
function wa_recently_messaged(array $phones, int $windowHours, string $scope, ?string $templateName, int $excludeCampaignId): array {
    global $conn;
    if (!$phones || $windowHours <= 0) return [];

    $since = date('Y-m-d H:i:s', time() - ($windowHours * 3600));
    $out = [];

    // Chunked so a 40k-number audience doesn't build one enormous IN() list.
    foreach (array_chunk($phones, 1000) as $chunk) {
        $list = implode(',', array_map(fn($p) => "'" . $conn->real_escape_string($p) . "'", $chunk));
        $where = "r.phone IN ($list)
                  AND r.is_test = 0
                  AND r.campaign_id <> " . (int)$excludeCampaignId . "
                  AND r.status IN ('sent','delivered','read')
                  AND r.sent_at >= '" . $conn->real_escape_string($since) . "'";
        if ($scope === 'same_template' && $templateName !== null && $templateName !== '') {
            $where .= " AND c.template_name = '" . $conn->real_escape_string($templateName) . "'";
        }
        $r = $conn->query("SELECT DISTINCT r.phone
                             FROM wa_campaign_recipients r
                             JOIN wa_campaigns c ON c.id = r.campaign_id
                            WHERE $where");
        while ($r && $row = $r->fetch_assoc()) $out[$row['phone']] = true;
    }
    return $out;
}

/** Locally-cached consent state — phone => 'optin'|'optout'. */
function wa_optin_map(array $phones): array {
    global $conn;
    if (!$phones) return [];
    $out = [];
    foreach (array_chunk($phones, 1000) as $chunk) {
        $list = implode(',', array_map(fn($p) => "'" . $conn->real_escape_string($p) . "'", $chunk));
        $r = $conn->query("SELECT phone, status FROM wa_optins WHERE phone IN ($list)");
        while ($r && $row = $r->fetch_assoc()) $out[$row['phone']] = $row['status'];
    }
    return $out;
}

/**
 * Records consent locally after the provider accepted it (or after a webhook / a STOP reply
 * reports an opt-out).
 *
 * `reason` and `blocked_at` exist so the WhatsApp Blocklist screen can answer "why is this number
 * on here?" — an opt-out with no provenance is one nobody dares remove. blocked_at is stamped
 * only on the way OUT and cleared on the way back in, so it always reads as the moment the block
 * started rather than the moment the row was last touched.
 */
function wa_record_optin(string $phone, string $status = 'optin', string $source = 'WEB', ?string $reason = null): void {
    global $conn;
    $p   = $conn->real_escape_string($phone);
    $s   = $status === 'optout' ? 'optout' : 'optin';
    $src = $conn->real_escape_string($source);
    $rsn = $reason === null || $reason === '' ? 'NULL' : "'" . $conn->real_escape_string(mb_substr($reason, 0, 255)) . "'";
    $blk = $s === 'optout' ? 'NOW()' : 'NULL';

    $conn->query("INSERT INTO wa_optins (phone, status, source, reason, blocked_at)
                  VALUES ('$p', '$s', '$src', $rsn, $blk)
                  ON DUPLICATE KEY UPDATE
                    status = '$s', source = '$src', reason = $rsn,
                    -- Keep the ORIGINAL block time when a number is re-reported as opted out
                    -- (webhook re-delivery, a second STOP); only a genuine transition restamps it.
                    blocked_at = IF('$s' = 'optout', COALESCE(blocked_at, NOW()), NULL)");
}

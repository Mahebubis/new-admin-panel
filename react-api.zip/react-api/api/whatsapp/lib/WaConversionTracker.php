<?php
/*
 * Conversion counting for WhatsApp campaigns.
 *
 * Answers one question per campaign: of the people we messaged, how many went on to do the thing
 * we were trying to make them do — sign in, view a result, buy a course — within N days?
 *
 * TWO MODES, because WhatsApp makes the honest one conditional.
 *
 *   click     The recipient tapped the campaign's button, and did the goal event within N days
 *             OF THAT TAP. This is the same claim the email side makes, and it is the one worth
 *             reporting: the campaign demonstrably carried them there.
 *
 *             It works only when the template's button URL is DYNAMIC, so each message can carry
 *             a per-recipient token pointing at c.php — WhatsApp itself reports nothing when a
 *             link button is tapped, so a static URL is unobservable by anyone, ever.
 *
 *             Note what it does NOT require: converting in that same visit. Tap the button, close
 *             the browser, come back tomorrow by typing the address — still counted, because the
 *             window runs from the click, not from the session.
 *
 *   exposure  The recipient received the message and did the goal event within N days OF THE
 *             SEND. Requires no template change, but credits people the campaign had nothing to
 *             do with — someone who would have signed in anyway is indistinguishable from someone
 *             it persuaded.
 *
 * exposure is the default because it always works; click is what to switch to once the template
 * carries a tracked button. The UI names which mode produced a number rather than presenting the
 * two as interchangeable.
 *
 * $EVENT_SOURCE (netcore/lib/segment_sql.php) is reused rather than re-derived: it already maps
 * every event key to its table, user column, date column and extra conditions, and is the same
 * map the segment builder and the email tracker use. Three copies of that mapping would drift.
 */
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/../../netcore/lib/segment_sql.php';
// $LIVE_ATTRIBUTED_EVENTS — the single list of events whose write path calls record_conversion().
// Imported rather than re-declared so adding an event there enables it on both channels at once.
require_once __DIR__ . '/../../campaigns/lib/ConversionTracker.php';

/** The value c.php puts on the redirect, and the value campaign_attributions rows for this
 *  channel carry. It is what keeps WhatsApp campaign #11 from being counted as email #11 — the
 *  two share that table and their ids overlap. */
if (!defined('WA_ATTRIBUTION_MEDIUM')) define('WA_ATTRIBUTION_MEDIUM', 'whatsapp');

/** Window bounds, matching the email side so the two channels can't disagree about what "7 days"
 *  means. Below 1 is meaningless; above 90 the claim stops being credible. */
function wa_goal_window_days(array $campaign): int {
    return max(1, min(90, (int)($campaign['goal_window_days'] ?: 2)));
}

/**
 * The SQL pieces that enumerate WHICH recipients converted, so the report can count them, list
 * them and search them from one definition.
 *
 * Returns null when the campaign has no goal, or names an event this install doesn't know how to
 * source — callers render "no goal set" rather than an error, because an unset goal is a normal
 * state, not a failure.
 *
 * @return ?array{select:string, from:string, order:string, count:string}
 */
function wa_conversion_list_sql(array $campaign, string $search = ''): ?array {
    global $conn, $EVENT_SOURCE, $LIVE_ATTRIBUTED_EVENTS;

    $campaignId = (int)$campaign['id'];
    $eventKey   = trim((string)($campaign['goal_event_name'] ?? ''));
    if ($eventKey === '') return null;

    $windowDays = wa_goal_window_days($campaign);
    $clickMode  = (string)($campaign['goal_attribution'] ?? 'exposure') === 'click';

    /*
     * LIVE ATTRIBUTION — the same fast path the email tracker takes, for the same events.
     *
     * For these, attribution was already decided at the moment the goal fired: the visitor
     * arrived from c.php with campaign_id / medium / attr_window on the URL, the dashboard's
     * attribution.js stored that, and record_conversion() wrote a campaign_attributions row only
     * if the cookie was still live. Counting is then a plain WHERE — no window arithmetic, no
     * per-event table plumbing, and one query covers every event on the list.
     *
     * It is also the STRICTER measure, which is the point: the cookie is cleared the moment
     * someone arrives without a campaign, so a row existing means this campaign genuinely carried
     * them into the action rather than merely preceding it.
     *
     * `medium` is non-negotiable here. campaign_attributions is shared with email and keyed by a
     * bare campaign_id, so WhatsApp #11 and email #11 are indistinguishable without it.
     *
     * Only in click mode: exposure mode is explicitly "did it after receiving", which no cookie
     * can express, so it stays on the window join below.
     */
    if ($clickMode && in_array($eventKey, (array)$LIVE_ATTRIBUTED_EVENTS, true)) {
        $ek = $conn->real_escape_string($eventKey);
        $md = $conn->real_escape_string(WA_ATTRIBUTION_MEDIUM);
        $s  = $conn->real_escape_string($search);
        $searchSql = $search !== ''
            ? " AND (u.email LIKE '%$s%' OR u.phone LIKE '%$s%'
                     OR CONCAT(COALESCE(u.fname,''),' ',COALESCE(u.lname,'')) LIKE '%$s%')"
            : '';

        // Same upper-bound-only re-check as the email side: attributed_at and clicked_at are
        // written by different machines, so a second of clock skew can put them out of order on
        // a legitimate conversion, and bounding the lower end would silently drop it.
        $windowSql = " AND (ca.clicked_at IS NULL
                            OR ca.attributed_at <= DATE_ADD(ca.clicked_at, INTERVAL $windowDays DAY))";

        $from = "FROM campaign_attributions ca
                 LEFT JOIN users u ON u.user_id = ca.user_id
                 WHERE ca.campaign_id = $campaignId
                   AND ca.medium = '$md'
                   AND ca.event_key = '$ek'$windowSql$searchSql";

        return [
            'mode'   => 'live',
            // One line per PERSON, matching the count. Every column is aggregated rather than
            // bare so the GROUP BY is legal under ONLY_FULL_GROUP_BY, which is on by default from
            // MySQL 5.7 — a bare u.email here would fail the whole report on a strict server.
            // MIN() on the two timestamps reports the FIRST conversion, which is the one the
            // campaign can claim.
            'select' => "SELECT MIN(ca.user_id) AS user_id, MIN(u.email) AS email,
                                MIN(TRIM(CONCAT(COALESCE(u.fname,''),' ',COALESCE(u.lname,'')))) AS name,
                                MIN(u.phone) AS phone, MIN(ca.medium) AS medium,
                                MIN(ca.clicked_at) AS clicked_at,
                                MIN(ca.attributed_at) AS converted_at,
                                COUNT(*) AS firings",
            'from'   => $from,
            // The SAME expression the count groups on, so the list can never be a different
            // length from the number above it.
            'group'  => " GROUP BY COALESCE(NULLIF(u.phone,''), NULLIF(u.email,''), CAST(ca.user_id AS CHAR))",
            // The ALIAS, not ca.attributed_at: the raw column is neither grouped nor aggregated,
            // which ONLY_FULL_GROUP_BY rejects outright.
            'order'  => ' ORDER BY converted_at DESC',
            /*
             * DISTINCT ON THE PERSON, not on the row — and "the person" means their phone number,
             * falling back to their email.
             *
             * Two reasons it is not COUNT(*). campaign_attributions holds one row per goal EVENT:
             * record_conversion() writes again every time the event fires while the cookie is
             * live, so someone signing in three times counted three times — enough to push
             * Converted above the number of people the campaign was sent to, which is how this was
             * spotted. And two accounts sharing one number are one human being, which user_id
             * alone cannot see.
             *
             * user_id is the last fallback rather than the key, for rows whose account carries
             * neither a number nor an address. The window branch below counts DISTINCT r.id, one
             * row per recipient, which is already one row per number.
             */
            'count'  => "SELECT COUNT(DISTINCT COALESCE(NULLIF(u.phone,''), NULLIF(u.email,''),
                                                        CAST(ca.user_id AS CHAR))) AS c $from",
        ];
    }

    $src = $EVENT_SOURCE[$eventKey] ?? null;
    if (!$src) return null;
    $join       = $src['join'] ?? '';
    $whereExtra = ($src['where'] ?? '') !== '' ? " AND ({$src['where']})" : '';

    /*
     * $EVENT_SOURCE stores several columns unqualified — 'signin' is ['table' => 'signin_log',
     * 'user_col' => 'user_id'] — because the segment builder that map was written for selects
     * FROM that table alone, where a bare `user_id` is unambiguous.
     *
     * Here it is joined against wa_campaign_recipients, which ALSO has user_id, and MySQL
     * rejects the whole query with "Column 'user_id' in on clause is ambiguous". The email
     * tracker never hit this because every event that would trip it (signin, register,
     * exam_success…) is in its $LIVE_ATTRIBUTED_EVENTS list and takes a different code path.
     *
     * Derived-table sources (course_purchase's UNION) already carry their own alias and qualify
     * their own columns, so they are left exactly as written.
     */
    $isDerived = str_starts_with(ltrim((string)$src['table']), '(');
    // A dot means it is already qualified. Backticks do NOT — exam_success's date_col is
    // `` `timestamp` ``, quoted because it's a reserved word, and it still needs its table.
    $qualify = function (string $col) use ($src, $isDerived): string {
        if ($isDerived || strpos($col, '.') !== false) return $col;
        return $src['table'] . '.' . $col;
    };
    $userCol = $qualify((string)$src['user_col']);
    $dateCol = $qualify((string)$src['date_col']);

    $s = $conn->real_escape_string($search);
    $searchSql = $search !== ''
        ? " AND (r.phone LIKE '%$s%' OR r.email LIKE '%$s%'
                 OR CONCAT(COALESCE(r.first_name,''),' ',COALESCE(r.last_name,'')) LIKE '%$s%')"
        : '';

    /*
     * THE WINDOW JOIN — reached for events that have no live-attribution write path, and for
     * exposure mode regardless.
     *
     *   click     first_clicked_at. The visitor tapped the button, so the campaign demonstrably
     *             brought them there. It does NOT require converting in that same visit — tap,
     *             close the browser, return tomorrow, still counted. Used when the event isn't on
     *             $LIVE_ATTRIBUTED_EVENTS, i.e. nothing writes a campaign_attributions row for it.
     *
     *   exposure  sent_at. Counts anyone who did the event after receiving the message, including
     *             people the campaign had no hand in. Weaker, but the only option when the
     *             template's button URL is static and clicks cannot be observed at all.
     *
     * sent_at, not queued_at, in exposure mode: a campaign can sit in the queue, and crediting
     * that wait would inflate every count.
     */
    $anchor = $clickMode ? 'r.first_clicked_at' : 'r.sent_at';

    /*
     * Recipients with no user_id are excluded either way: there is nothing to match an event
     * against. That used to silently zero out every list-sourced campaign, which is why
     * wa_backfill_recipient_user_ids() resolves them from phone and email first.
     */
    $from = "FROM wa_campaign_recipients r
             INNER JOIN {$src['table']} $join
                     ON $userCol = r.user_id
              WHERE r.campaign_id = $campaignId
                AND r.is_test = 0
                AND r.user_id IS NOT NULL
                AND $anchor IS NOT NULL
                AND $dateCol >= $anchor
                AND $dateCol <= DATE_ADD($anchor, INTERVAL $windowDays DAY)
                $whereExtra$searchSql";

    return [
        // DISTINCT on the recipient: someone who signs in five times inside the window converted
        // once, not five times.
        'select' => "SELECT DISTINCT r.id, r.user_id, r.phone, r.email,
                            TRIM(CONCAT(COALESCE(r.first_name,''),' ',COALESCE(r.last_name,''))) AS name,
                            r.sent_at, r.first_clicked_at, MIN($dateCol) AS converted_at",
        'from'   => $from,
        'group'  => ' GROUP BY r.id',
        'order'  => ' ORDER BY converted_at DESC',
        'count'  => "SELECT COUNT(DISTINCT r.id) AS c $from",
    ];
}

/** The conversion count for one campaign, or null when it has no usable goal. */
function wa_conversion_count(array $campaign): ?int {
    global $conn;
    $sql = wa_conversion_list_sql($campaign);
    if (!$sql) return null;
    $r = $conn->query($sql['count']);
    return $r ? (int)$r->fetch_assoc()['c'] : 0;
}

/**
 * Refreshes the stored count for one campaign.
 *
 * Stored rather than computed on every report load because the join can touch large event tables
 * (signin_log especially) and the report is opened far more often than the number changes.
 */
function wa_recompute_one(array $campaign): void {
    global $conn;
    /*
     * Identity first. A list-sourced recipient is stored with no user_id, and the count below
     * joins on exactly that — so without this, a campaign sent to a list reports 0 conversions
     * regardless of how many people converted. Runs here as well as at materialize time so
     * campaigns sent before the backfill existed become countable too, without re-sending.
     */
    if (function_exists('wa_backfill_recipient_user_ids')) {
        wa_backfill_recipient_user_ids((int)$campaign['id']);
    }
    $n = wa_conversion_count($campaign);
    if ($n === null) return;
    $conn->query("UPDATE wa_campaigns SET conversion_count = " . (int)$n . ' WHERE id = ' . (int)$campaign['id']);
}

/**
 * Recomputes every sent campaign with a goal, called from the worker's cron tick.
 *
 * Bounded on two axes, because this runs every minute and must never become the reason a cron
 * tick overruns: only campaigns completed within the last 90 days, and only up to 40 per tick.
 * A conversion that lands later than that is outside any credible attribution window anyway.
 */
function wa_recompute_conversions(): void {
    global $conn;

    $r = $conn->query("SELECT id, goal_event_name, goal_window_days, goal_attribution, completed_at
                         FROM wa_campaigns
                        WHERE status = 'sent'
                          AND goal_event_name IS NOT NULL AND goal_event_name <> ''
                          AND (completed_at IS NULL OR completed_at >= DATE_SUB(NOW(), INTERVAL 90 DAY))
                        ORDER BY completed_at DESC
                        LIMIT 40");
    while ($r && $row = $r->fetch_assoc()) {
        try {
            wa_recompute_one($row);
        } catch (\Throwable $e) {
            // One campaign whose event table is missing or renamed must not stop the rest, and
            // must not take the worker down with it.
            if (function_exists('wa_log')) {
                wa_log("conversions FAILED for campaign #{$row['id']} (goal={$row['goal_event_name']}) — " . $e->getMessage());
            }
        }
    }
}

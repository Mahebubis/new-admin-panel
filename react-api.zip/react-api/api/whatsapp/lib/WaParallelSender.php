<?php
/*
 * Runs many WhatsApp sends concurrently.
 *
 * Same shape and reasoning as campaigns/lib/ParallelSender.php — a send is almost entirely
 * network WAIT, so sequential sending caps throughput at (1 / latency) no matter how fast the
 * machine is, while curl_multi makes it (concurrency / latency). It is a separate function
 * rather than a reuse of esp_send_parallel() because that one is typed to EspTransport, an
 * email-only interface (sendEmail/subject/from-address) the WhatsApp transport has no
 * business implementing.
 */
require_once __DIR__ . '/WaHelpers.php';

/**
 * @param object $transport MetaCloudTransport — only parseResponse() is
 *                          called here, and both expose it identically. Deliberately untyped
 *                          so this file needs no knowledge of which providers exist.
 * @param array $jobs each ['key' => mixed, 'rid' => string, 'req' => built request]
 *                    `key` is echoed back as the result key — the worker passes the recipient
 *                    row id so results map straight back to rows.
 * @return array<mixed, array{ok: bool, message_id: ?string, error: ?string, code: ?string, retryable: bool}>
 */
function wa_send_parallel($transport, array $jobs, int $concurrency = 16, int $timeout = 20): array {
    $results = [];
    if (!$jobs) return $results;

    $queue = array_values($jobs);
    $total = count($queue);
    $concurrency = max(1, min($concurrency, $total));

    if ($concurrency === 1) {
        foreach ($queue as $job) {
            [$status, $body, $err] = wa_http_exec($job['req'], $timeout);
            $results[$job['key']] = $transport->parseResponse($status, $body, $err, $job['rid'] ?? null);
        }
        return $results;
    }

    $mh = curl_multi_init();
    $next = 0;
    $inFlight = [];

    // PHP 8 hands back CurlHandle OBJECTS, not resources — (int)$ch is a TypeError there.
    $handleId = fn($ch) => is_object($ch) ? spl_object_id($ch) : (int)$ch;

    $launch = function () use (&$queue, &$next, &$inFlight, $mh, $timeout, $total, $handleId) {
        if ($next >= $total) return false;
        $job = $queue[$next++];
        $ch = curl_init($job['req']['url']);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST           => true,
            CURLOPT_POSTFIELDS     => $job['req']['body'],
            CURLOPT_HTTPHEADER     => $job['req']['headers'],
            CURLOPT_TIMEOUT        => $timeout,
        ]);
        curl_multi_add_handle($mh, $ch);
        $inFlight[$handleId($ch)] = $job;
        return true;
    };

    for ($i = 0; $i < $concurrency; $i++) {
        if (!$launch()) break;
    }

    do {
        $status = curl_multi_exec($mh, $running);
        if ($status !== CURLM_OK) break;
        // Block until a handle has activity instead of spinning the CPU. Guarded on $running
        // because select() returns immediately (and can return -1) with nothing in flight.
        if ($running > 0) curl_multi_select($mh, 1.0);

        while ($done = curl_multi_info_read($mh)) {
            $ch  = $done['handle'];
            $id  = $handleId($ch);
            $job = $inFlight[$id] ?? null;

            if ($job !== null) {
                $body = curl_multi_getcontent($ch);
                $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
                // $done['result'] is the cURL-level outcome (timeout, DNS, TLS); curl_error()
                // alone is unreliable once a handle leaves the multi stack.
                $err  = $done['result'] !== CURLE_OK ? (curl_error($ch) ?: 'cURL error ' . $done['result']) : '';
                $results[$job['key']] = $transport->parseResponse($code, $body, $err, $job['rid'] ?? null);
                unset($inFlight[$id]);
            }

            curl_multi_remove_handle($mh, $ch);
            curl_close($ch);
            $launch(); // backfill the freed slot so the window stays saturated
        }
    } while ($running > 0 || $inFlight);

    curl_multi_close($mh);
    return $results;
}

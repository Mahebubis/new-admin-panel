<?php
/*
 * /api/whatsapp/lib/WaLinks.php — turning a plain destination into a tracked one.
 *
 * The whole scheme in one line:
 *
 *     you type    https://dashboard.internshipstudio.com/login
 *     Meta gets   https://dashboard.internshipstudio.com/login/23
 *
 * where 23 is a wa_links row that knows the campaign, the goal and the attribution window. See
 * the long note above the CREATE TABLE in schema.php for why the campaign context had to move off
 * the query string and into a row — the short version is that Meta would not approve a template
 * whose link carried a variable, and would approve one whose link was static.
 *
 * Nothing in here is WhatsApp-specific by accident: email keeps its own ?campaign_id&medium=email
 * redirect through track-click.php and is untouched. This is the WhatsApp-only detour that ends
 * up producing the identical three values at the landing page.
 */

/**
 * Splits a URL at the first '?' or '#'.
 *
 * @return array{0:string,1:string} [path part, query+fragment part]
 */
function wa_link_split(string $url): array {
    $cut = strcspn($url, '?#');
    return [substr($url, 0, $cut), substr($url, $cut)];
}

/**
 * The plain destination carrying this link's id.
 *
 *     https://dashboard.internshipstudio.com/login  ->  …/login/23
 *
 * A PATH SEGMENT, and that is a settled question rather than a preference: exam_live_link_v3 was
 * APPROVED by Meta carrying exactly this shape, after every variable-bearing version had been
 * refused. Meta holds the approved URL and sends that string, not ours, so changing the form here
 * would only make our copy disagree with what actually goes out — a new form means a new template
 * and a new review.
 *
 * The landing page needs a route for it (see the dashboard's "/login/:waLinkId"). The alternative
 * "?id=23" form needs no route and is still read by the dashboard, so a template approved that way
 * keeps working — but nothing should be generated in that shape while the approved one is this.
 *
 * The id goes in BEFORE any query string: appending it to "…/login?next=x" would change the query
 * value rather than the path.
 */
function wa_tracked_link(string $targetUrl, int $linkId): string {
    $targetUrl = trim($targetUrl);
    if ($targetUrl === '' || $linkId <= 0) return $targetUrl;

    [$path, $tail] = wa_link_split($targetUrl);
    if ($path === '') return $targetUrl;

    return rtrim($path, '/') . '/' . $linkId . $tail;
}

/**
 * Rewrites every mention of the plain destination inside a piece of template text (or a button
 * URL) to the tracked form.
 *
 * This is what lets the editor show a non-technical person a plain link while Meta receives the
 * tracked one — they never type the id and cannot get it wrong.
 *
 * IDEMPOTENT, which matters more than it sounds: the body stored after a save already carries the
 * id, and saving again must not append a second one. The pattern therefore also matches an
 * already-tracked link in EITHER form — the current "?id=23" and the earlier "/23" path form — and
 * the two leftovers from the abandoned variable-based scheme ("?{{1}}" and "?XX_WA_ATTR_XX"). An
 * old template migrates to the current form by simply being re-saved.
 */
function wa_link_rewrite(string $text, string $targetUrl, int $linkId): string {
    if ($text === '' || $linkId <= 0) return $text;

    [$base] = wa_link_split(trim($targetUrl));
    $base = rtrim($base, '/');
    if ($base === '') return $text;

    $tracked = wa_tracked_link($targetUrl, $linkId);
    $pattern = '~' . preg_quote($base, '~')
             . '(?:/\d+)?(?:[?&]id=\d+)?(?:\?(?:\{\{\d+\}\}|XX_WA_ATTR_XX))?~i';

    // preg_replace_callback rather than preg_replace: a '$' or a backslash in the URL would be
    // read as a backreference in a replacement string and silently mangle the link.
    return preg_replace_callback($pattern, static function () use ($tracked) { return $tracked; }, $text);
}

/**
 * Returns the link id for a template, creating it on first use.
 *
 * Stable by design — the id is part of what Meta approved, so re-saving a template must return
 * the SAME number. Changing the destination updates target_url and keeps the id, which means a
 * link already sitting in someone's WhatsApp starts pointing at the new page instead of breaking.
 *
 * @return int the link id, or 0 when there is nothing to track
 */
function wa_link_ensure(int $templateId, string $targetUrl): int {
    global $conn;

    $targetUrl = trim($targetUrl);
    if ($templateId <= 0 || $targetUrl === '') return 0;
    $esc = $conn->real_escape_string($targetUrl);

    $r      = $conn->query("SELECT link_id FROM wa_templates WHERE id=$templateId LIMIT 1");
    $row    = $r ? $r->fetch_assoc() : null;
    $linkId = (int)($row['link_id'] ?? 0);

    if ($linkId > 0) {
        $chk = $conn->query("SELECT id FROM wa_links WHERE id=$linkId LIMIT 1");
        if ($chk && $chk->num_rows > 0) {
            $conn->query("UPDATE wa_links SET target_url='$esc' WHERE id=$linkId");
            return $linkId;
        }
        // Pointer to a row that no longer exists — fall through and mint a new one rather than
        // handing out an id that link.php would refuse to resolve.
    }

    // uq_template means a half-finished earlier save left a usable row; adopt it.
    $r2  = $conn->query("SELECT id FROM wa_links WHERE template_id=$templateId LIMIT 1");
    $ex  = $r2 ? $r2->fetch_assoc() : null;
    if ($ex) {
        $linkId = (int)$ex['id'];
        $conn->query("UPDATE wa_links SET target_url='$esc' WHERE id=$linkId");
    } else {
        $conn->query("INSERT INTO wa_links (template_id, target_url) VALUES ($templateId, '$esc')");
        $linkId = (int)$conn->insert_id;
    }

    if ($linkId > 0) $conn->query("UPDATE wa_templates SET link_id=$linkId WHERE id=$templateId");
    return $linkId;
}

/**
 * Points a template's link at the campaign that is sending right now.
 *
 * Called once per send, from the worker. The id in the approved template never changes, so this
 * row is the only thing that can say which campaign a tap belongs to — and rebinding on every
 * send is what stops a re-used template from crediting a campaign that finished months ago.
 *
 * A tap that arrives AFTER the next campaign has rebound the link is credited to that newer
 * campaign. That is the honest reading: the same link was re-sent, and there is no information
 * anywhere that could separate the two audiences. Give a template its own copy per campaign if
 * you need them kept apart.
 */
function wa_link_bind_campaign(int $linkId, int $campaignId, ?string $goalEvent, int $windowDays): void {
    global $conn;
    if ($linkId <= 0 || $campaignId <= 0) return;

    $windowDays = max(1, min(90, $windowDays ?: 2));
    $goal = ($goalEvent === null || trim($goalEvent) === '')
        ? 'NULL'
        : "'" . $conn->real_escape_string(trim($goalEvent)) . "'";

    $conn->query("UPDATE wa_links
                     SET campaign_id      = $campaignId,
                         owner_kind       = 'campaign',
                         goal_event_name  = $goal,
                         goal_window_days = $windowDays,
                         bound_at         = NOW()
                   WHERE id = $linkId");
}

/**
 * The journey twin of wa_link_bind_campaign(), called once per journey WhatsApp send.
 *
 * WHY THIS HAS TO EXIST
 * The link id lives inside the approved template, so a template shared by a campaign and a
 * journey hands the same /login/101 to both audiences. Only the campaign ever wrote itself onto
 * that row, so every journey tap resolved to a campaign — crediting clicks to a send that never
 * happened, and leaving the journey message with no first_clicked_at, which is the anchor its
 * own conversion counting depends on. Binding here is what gives a journey tap an owner.
 *
 * journey_id is written ALONGSIDE campaign_id rather than clearing it. The campaign that used
 * this template last is still the right answer for its own recipients, and link.php compares the
 * two once it knows who tapped. owner_kind records who sent most recently, which is the only
 * answer available while the visitor is still anonymous.
 */
function wa_link_bind_journey(int $linkId, int $journeyId, ?string $goalEvent, int $windowDays): void {
    global $conn;
    if ($linkId <= 0 || $journeyId <= 0) return;

    $windowDays = max(1, min(90, $windowDays ?: 2));
    $goal = ($goalEvent === null || trim($goalEvent) === '')
        ? 'NULL'
        : "'" . $conn->real_escape_string(trim($goalEvent)) . "'";

    $conn->query("UPDATE wa_links
                     SET journey_id       = $journeyId,
                         owner_kind       = 'journey',
                         goal_event_name  = $goal,
                         goal_window_days = $windowDays,
                         bound_at         = NOW()
                   WHERE id = $linkId");
}

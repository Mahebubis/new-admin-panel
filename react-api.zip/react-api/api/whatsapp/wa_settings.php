<?php
/*
 * /api/whatsapp/wa_settings.php — WhatsApp Business API credentials and sending numbers.
 *
 * Credentials are account-level (one API key). Sending identity is NOT: a WABA owns several
 * business numbers and each has its own Source ID, so those live in wa_senders and a campaign
 * picks one.
 *
 * action=get                                   → settings row (api_key masked) + every sender
 * action=save   &meta_access_token &default_country_code &webhook_secret
 * action=sender_save   [&id] &waba_id &waba_name &business_number &display_name &source_id
 *                      &quality_rating &messaging_limit &is_default &is_active &notes
 * action=sender_delete &id
 * action=sender_default &id
 * action=test          &phone                  → verifies the credentials against the provider
 * action=optin  &phones (comma/newline separated) [&type=optin|optout]
 * action=optin_list &page &per_page &search
 */
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../middleware/auth.php';
require_once __DIR__ . '/lib/config.php';
require_once __DIR__ . '/lib/schema.php';
require_once __DIR__ . '/lib/WaHelpers.php';
require_once __DIR__ . '/lib/WaAudienceResolver.php';

whatsapp_ensure_schema();

$jwt = require_jwt();
require_permission('netcore_behaviour', $jwt);

function jin($k, $d = null) { $v = $_REQUEST[$k] ?? null; return ($v === null || $v === '') ? $d : $v; }

/** Shows enough of a credential to recognize it, never enough to use it. */
function wa_mask(string $k): string {
    if ($k === '') return 'not set';
    if (strlen($k) <= 10) return str_repeat('•', max(0, strlen($k) - 2)) . substr($k, -2);
    return substr($k, 0, 6) . str_repeat('•', 10) . substr($k, -4);
}

$action = jin('action', '');

if ($action === 'get') {
    $row = wa_settings_row();
    if (!$row) api_error('Settings row missing', 500);

    $row['meta_token_masked']  = wa_mask(trim((string)($row['meta_access_token'] ?? '')));
    $row['has_meta_token']     = trim((string)($row['meta_access_token'] ?? '')) !== '';
    $row['app_secret_masked']  = wa_mask(trim((string)($row['meta_app_secret'] ?? '')));
    $row['has_app_secret']     = trim((string)($row['meta_app_secret'] ?? '')) !== '';
    // never return a raw credential
    unset($row['api_key'], $row['meta_access_token'], $row['meta_app_secret']);
    // Legacy single-sender columns — migrated into wa_senders, kept out of the response so no
    // caller can start depending on them again.
    unset($row['source_id'], $row['waba_id'], $row['business_number'], $row['business_name']);
    $row['is_active'] = (int)$row['is_active'];

    $fullRow    = wa_settings_row() ?: [];
    $metaToken  = trim((string)($fullRow['meta_access_token'] ?? ''));
    $senders = array_map(function ($s) use ($metaToken) {
        $s['id']              = (int)$s['id'];
        $s['is_default']      = (int)$s['is_default'];
        $s['is_active']       = (int)$s['is_active'];
        /*
         * Readiness depends on the route this number sends through — the two APIs need entirely
         * different credentials:
         *   meta     the account's Meta token + this number's phone_number_id
         *   netcore  this number's own API key (issued per business number)
         * A single combined check would mark a perfectly configured Netcore number "not ready"
         * for lacking a Meta credential it never uses.
         */
        $s['provider'] = ($s['provider'] ?? 'meta') === 'netcore' ? 'netcore' : 'meta';
        $s['has_api_key'] = trim((string)($s['api_key'] ?? '')) !== '';
        $s['api_key_masked'] = wa_mask(trim((string)($s['api_key'] ?? '')));
        $s['ready'] = $s['provider'] === 'netcore'
            ? $s['has_api_key']
            : ($metaToken !== '' && trim((string)$s['phone_number_id']) !== '');
        $s['has_source'] = trim((string)($s['source_id'] ?? '')) !== '';
        $s['has_pin'] = trim((string)($s['registration_pin'] ?? '')) !== '';
        unset($s['api_key'], $s['registration_pin']); // never return a raw credential
        return $s;
    }, wa_senders_all());

    $usable = array_filter($senders, fn($s) => $s['ready'] && $s['is_active'] === 1);
    $row['ready']          = count($usable) > 0;
    $row['sender_count']   = count($senders);
    $row['usable_senders'] = count($usable);

    /*
     * Netcore-era leftovers, stripped from the response rather than returned as dead weight:
     *
     *   api_base_url  the BSP endpoint. Never read since the move to Meta Cloud API — every
     *                 request is built from WA_GRAPH_BASE — but seeing a pepipost URL in the
     *                 settings payload reasonably reads as "we're still going through Netcore".
     *   provider      the row KEY that wa_settings_row() selects on, not a provider choice.
     *
     * The columns themselves stay: dropping them buys nothing and would need a migration.
     */
    unset($row['api_base_url'], $row['provider']);

    $tplR = $conn->query("SELECT COUNT(*) AS c FROM wa_templates WHERE status='active'");
    $row['template_count'] = $tplR ? (int)$tplR->fetch_assoc()['c'] : 0;
    $optR = $conn->query("SELECT COUNT(*) AS c FROM wa_optins WHERE status='optin'");
    $row['optin_count'] = $optR ? (int)$optR->fetch_assoc()['c'] : 0;

    api_success([
        'settings' => $row,
        'senders'  => array_values($senders),
        'webhook_path' => '/api/whatsapp/webhook.php',
        // Lets the page tell you when the deployed backend is older than the UI driving it.
        'api_version' => WA_API_VERSION,
    ]);
}

if ($action === 'save') {
    // Account-level credentials only — sending identity is per number (sender_save below).
    $set = [];
    foreach (['default_country_code', 'webhook_secret', 'meta_access_token', 'meta_app_secret'] as $f) {
        $v = jin($f, null);
        if ($v === null) continue;
        // Leave a credential untouched when the client echoes back the masked placeholder — that
        // means the admin edited other fields without retyping it.
        if (($f === 'meta_access_token' || $f === 'meta_app_secret') && strpos((string)$v, '•') !== false) continue;
        $set[] = "$f='" . $conn->real_escape_string(trim((string)$v)) . "'";
    }
    if ($set) $conn->query("UPDATE wa_settings SET " . implode(', ', $set) . " WHERE provider='netcore'");
    api_success([]);
}

/* ── Sending numbers ────────────────────────────────────────────────────────────────────── */

if ($action === 'sender_save') {
    $id     = (int)jin('id', 0);
    $waba   = trim((string)jin('waba_id', ''));
    $number = trim((string)jin('business_number', ''));
    if ($waba === '')   api_error('WABA ID is required');
    if ($number === '') api_error('Business number is required');

    // Stored exactly as Netcore displays it minus the cosmetics, so two spellings of the same
    // number ("+91 8237850238" / "918237850238") can't become two sender rows with different
    // Source IDs — uq_number would not catch that on its own.
    $number = '+' . ltrim(preg_replace('/\D+/', '', $number), '0');
    if (strlen($number) < 8) api_error('That does not look like a business number');

    /*
     * Provider defaults to whatever the row already is, NOT to a hardcoded value. An edit form
     * that doesn't send the field must never silently re-route a number to the other API —
     * that would change where live campaigns go out from, as a side effect of fixing a typo in
     * the display name.
     */
    $existing = $id > 0 ? wa_sender_by_id($id) : null;
    $providerIn = jin('provider', null);
    $provider = $providerIn !== null
        ? ($providerIn === 'netcore' ? 'netcore' : 'meta')
        : (string)($existing['provider'] ?? 'meta');

    $fields = [
        'waba_id'         => $waba,
        'waba_name'       => (string)jin('waba_name', ''),
        'business_number' => $number,
        'display_name'    => (string)jin('display_name', ''),
        'provider'        => $provider,
        'phone_number_id' => trim((string)jin('phone_number_id', '')),
        'source_id'       => trim((string)jin('source_id', '')),
        'quality_rating'  => (string)jin('quality_rating', ''),
        'messaging_limit' => (string)jin('messaging_limit', ''),
        'notes'           => (string)jin('notes', ''),
    ];
    $set = [];
    foreach ($fields as $c => $v) $set[] = "`$c`='" . $conn->real_escape_string($v) . "'";
    $set[] = 'is_active=' . ((int)jin('is_active', 1) === 1 ? 1 : 0);

    /*
     * The Netcore API key, issued per business number under Business number → Edit → Integrate
     * API. Only written when something real was typed: the form echoes back a masked placeholder
     * when the admin didn't touch the field, and storing that would replace a working key with
     * a row of bullets.
     */
    $apiKey = jin('api_key', null);
    if ($apiKey !== null && strpos((string)$apiKey, '•') === false) {
        $set[] = "api_key='" . $conn->real_escape_string(trim((string)$apiKey)) . "'";
    }


    if ($id > 0) {
        $dup = $conn->query("SELECT id FROM wa_senders WHERE business_number='" . $conn->real_escape_string($number) . "' AND id <> $id LIMIT 1");
        if ($dup && $dup->num_rows > 0) api_error("$number is already saved as a sending number");
        $conn->query("UPDATE wa_senders SET " . implode(', ', $set) . " WHERE id=$id");
    } else {
        $dup = $conn->query("SELECT id FROM wa_senders WHERE business_number='" . $conn->real_escape_string($number) . "' LIMIT 1");
        if ($dup && $dup->num_rows > 0) api_error("$number is already saved as a sending number");
        $conn->query("INSERT INTO wa_senders SET " . implode(', ', $set));
        $id = $conn->insert_id;
    }

    // The first number saved becomes the default automatically — otherwise a single-number
    // setup would have no default at all and every campaign would need an explicit pick.
    $anyDefault = $conn->query("SELECT 1 FROM wa_senders WHERE is_default=1 LIMIT 1");
    $makeDefault = (int)jin('is_default', 0) === 1 || !$anyDefault || $anyDefault->num_rows === 0;
    if ($makeDefault) {
        $conn->query("UPDATE wa_senders SET is_default=0");
        $conn->query("UPDATE wa_senders SET is_default=1 WHERE id=$id");
    }
    api_success(['id' => $id]);
}

/*
 * Pulls the business numbers straight from the WABA — GET /{waba_id}/phone_numbers — so nobody
 * has to transcribe a phone_number_id by hand. That id is what Meta Cloud API sends through, and
 * a single wrong digit produces a 404 with no hint about which number was meant.
 *
 * Existing rows are updated in place (id, name, quality) and their provider/api_key are left
 * alone, so running this never silently re-routes a number that is already sending.
 */
if ($action === 'import_numbers') {
    $settings = wa_settings_row() ?: [];
    $token = trim((string)($settings['meta_access_token'] ?? ''));
    if ($token === '') api_error('Add a Meta access token in Settings → Template sync first.');

    $wabaId = trim((string)jin('waba_id', ''));
    if ($wabaId === '') {
        $existing = wa_senders_all();
        $wabaId = trim((string)($existing[0]['waba_id'] ?? ''));
    }
    if ($wabaId === '') api_error('No WABA ID known yet — add one sending number by hand first, or pass waba_id.');

    $url = WA_GRAPH_BASE . WA_GRAPH_VERSION . '/' . rawurlencode($wabaId) . '/phone_numbers'
         . '?fields=' . rawurlencode('id,display_phone_number,verified_name,quality_rating,platform_type,account_mode') . '&limit=100';

    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HTTPHEADER     => ['Authorization: Bearer ' . $token],
        CURLOPT_TIMEOUT        => 25,
    ]);
    $body = curl_exec($ch);
    $status = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $err = curl_error($ch);
    curl_close($ch);

    if ($err !== '') api_error('Could not reach Meta: ' . $err);
    $decoded = json_decode((string)$body, true);
    if ($status < 200 || $status >= 300 || !is_array($decoded)) {
        $msg = $decoded['error']['message'] ?? (is_string($body) ? mb_substr($body, 0, 300) : "HTTP $status");
        api_error('Meta refused the request: ' . $msg);
    }

    $imported = 0; $updated = 0; $rows = [];
    foreach ((array)($decoded['data'] ?? []) as $p) {
        $pid = trim((string)($p['id'] ?? ''));
        $display = trim((string)($p['display_phone_number'] ?? ''));
        if ($pid === '' || $display === '') continue;

        // Same normalization sender_save uses, so a number imported here and one typed by hand
        // can never become two rows.
        $number = '+' . ltrim(preg_replace('/\D+/', '', $display), '0');
        $numberE = $conn->real_escape_string($number);

        $set = [
            "waba_id='" . $conn->real_escape_string($wabaId) . "'",
            "business_number='$numberE'",
            "phone_number_id='" . $conn->real_escape_string($pid) . "'",
            "quality_rating='" . $conn->real_escape_string((string)($p['quality_rating'] ?? '')) . "'",
        ];
        $name = trim((string)($p['verified_name'] ?? ''));

        $exists = $conn->query("SELECT id, display_name FROM wa_senders WHERE business_number='$numberE' LIMIT 1");
        $row = $exists ? $exists->fetch_assoc() : null;
        if ($row) {
            // Don't clobber a display name the admin chose themselves.
            if (trim((string)$row['display_name']) === '' && $name !== '') {
                $set[] = "display_name='" . $conn->real_escape_string($name) . "'";
            }
            $conn->query("UPDATE wa_senders SET " . implode(', ', $set) . ' WHERE id=' . (int)$row['id']);
            $updated++;
        } else {
            $set[] = "display_name='" . $conn->real_escape_string($name) . "'";
            $set[] = "waba_name='" . $conn->real_escape_string($name) . "'";
            // New numbers land on Meta, since that's the only provider we have credentials for
            // without a per-number Netcore key.
            $set[] = "provider='meta'";
            $conn->query("INSERT INTO wa_senders SET " . implode(', ', $set));
            $imported++;
        }
        $rows[] = ['number' => $number, 'phone_number_id' => $pid, 'quality' => $p['quality_rating'] ?? '',
                   'platform' => $p['platform_type'] ?? '', 'mode' => $p['account_mode'] ?? ''];
    }

    // Any number saved before this existed has no default flag; make sure one is set.
    $anyDefault = $conn->query("SELECT 1 FROM wa_senders WHERE is_default=1 LIMIT 1");
    if (!$anyDefault || $anyDefault->num_rows === 0) {
        $first = $conn->query("SELECT id FROM wa_senders ORDER BY id ASC LIMIT 1");
        $fr = $first ? $first->fetch_assoc() : null;
        if ($fr) $conn->query("UPDATE wa_senders SET is_default=1 WHERE id=" . (int)$fr['id']);
    }

    api_success(['imported' => $imported, 'updated' => $updated, 'numbers' => $rows]);
}

if ($action === 'sender_default') {
    $id = (int)jin('id', 0);
    if (!$id) api_error('id required');
    $conn->query("UPDATE wa_senders SET is_default=0");
    $conn->query("UPDATE wa_senders SET is_default=1 WHERE id=$id");
    api_success([]);
}

if ($action === 'sender_delete') {
    $id = (int)jin('id', 0);
    if (!$id) api_error('id required');

    // Campaigns snapshot source_id/business_number when they are sent or scheduled, so removing
    // a number never changes anything already queued. A DRAFT pointing at it would silently
    // fall back to the default, which is worth saying out loud rather than discovering later.
    $inUse = $conn->query("SELECT COUNT(*) AS c FROM wa_campaigns WHERE sender_id=$id AND status IN ('draft','scheduled')");
    $count = $inUse ? (int)$inUse->fetch_assoc()['c'] : 0;

    $wasDefault = $conn->query("SELECT is_default FROM wa_senders WHERE id=$id LIMIT 1");
    $wasDefaultRow = $wasDefault ? $wasDefault->fetch_assoc() : null;

    $conn->query("DELETE FROM wa_senders WHERE id=$id");
    // Don't leave the account with no default at all — activeProvider-style silent fallbacks
    // are exactly what makes this integration hard to debug.
    if ($wasDefaultRow && (int)$wasDefaultRow['is_default'] === 1) {
        $next = $conn->query("SELECT id FROM wa_senders WHERE is_active=1 ORDER BY id ASC LIMIT 1");
        $nextRow = $next ? $next->fetch_assoc() : null;
        if ($nextRow) $conn->query("UPDATE wa_senders SET is_default=1 WHERE id=" . (int)$nextRow['id']);
    }
    api_success(['affected_drafts' => $count]);
}

/*
 * Credential check.
 *
 * The honest test is a real read against the WABA — it proves the token is live, carries the
 * whatsapp_business_management scope, and can actually see this business account. It does NOT
 * prove a template is approved or that a number can send; only a delivered message does, which
 * is why the campaign preflight checks those separately.
 */
if ($action === 'test') {
    $token = wa_meta_token();
    if ($token === '') api_error('Add a Meta access token first');

    $sender = wa_sender_by_id((int)jin('sender_id', 0)) ?: wa_default_sender();
    $wabaId = trim((string)($sender['waba_id'] ?? ''));
    if ($wabaId === '') api_error('No WABA ID known yet — add a sending number first');

    $res = wa_graph_call('GET', WA_GRAPH_BASE . WA_GRAPH_VERSION . '/' . rawurlencode($wabaId)
        . '?fields=' . rawurlencode('id,name,timezone_id,message_template_namespace'), $token);

    $notes = [];
    if ($res['ok']) {
        $all = wa_senders_all();
        $noId = array_values(array_filter($all, fn($s) => trim((string)$s['phone_number_id']) === ''));
        if (!$all) {
            $notes[] = 'No sending numbers yet — press "Refresh from Meta" to pull them in.';
        } elseif ($noId) {
            $notes[] = 'These numbers have no phone number ID and cannot send: '
                . implode(', ', array_map(fn($s) => $s['business_number'], $noId))
                . '. "Refresh from Meta" fills them in.';
        }
        $tplR = $conn->query("SELECT COUNT(*) AS c FROM wa_templates WHERE status='active' AND approval_status='approved'");
        if ($tplR && (int)$tplR->fetch_assoc()['c'] === 0) {
            $notes[] = 'No approved templates registered yet. Outside the 24-hour service window WhatsApp only delivers approved templates — sync them from the Templates page.';
        }
    }

    api_success([
        'ok'      => $res['ok'],
        'message' => $res['ok']
            ? 'Token is valid — connected to "' . ($res['data']['name'] ?? $wabaId) . '".'
            : ($res['error'] ?: 'Meta rejected the request'),
        'notes'   => $notes,
    ]);
}

/*
 * action=diagnose — why can't this token send?
 *
 * Exists because Meta answers every permission problem with the same opaque sentence:
 *
 *   (#200) You do not have the necessary permissions to send messages on behalf of this
 *   WhatsApp Business Account
 *
 * That one error covers at least three unrelated causes, and the fix for each is different.
 * Reading the token's own metadata back from Meta separates them definitively, so nobody has to
 * guess or run curl by hand:
 *
 *   scopes[]          which permissions the token was MINTED with. A scope cannot be added to an
 *                     existing token — a missing one means generating a new token, full stop.
 *   granular_scopes[] which ASSETS each scope may act on. This is the one people miss: the scope
 *                     can be present while target_ids doesn't include the WABA, because the asset
 *                     was assigned to the system user AFTER the token was generated.
 *   is_valid/expires  a plain expired token reports #190, not #200, but it's free to rule out.
 */
if ($action === 'diagnose') {
    $token = wa_meta_token();
    if ($token === '') api_error('Add a Meta access token first');

    $sender = wa_sender_by_id((int)jin('sender_id', 0)) ?: wa_default_sender();
    $wabaId = trim((string)($sender['waba_id'] ?? ''));
    $pni    = trim((string)($sender['phone_number_id'] ?? ''));

    // The token inspects itself: input_token and access_token are both this token, which is
    // allowed and avoids needing a separate app token.
    $dbg = wa_graph_call('GET', WA_GRAPH_BASE . WA_GRAPH_VERSION . '/debug_token'
        . '?input_token=' . rawurlencode($token) . '&access_token=' . rawurlencode($token), $token);

    if (!$dbg['ok']) {
        api_success([
            'ok'     => false,
            'checks' => [[
                'ok' => false, 'title' => 'Could not inspect the token',
                'detail' => $dbg['error'] . ' — this usually means the token is expired or was revoked. Generate a new one.',
            ]],
        ]);
    }

    $d          = $dbg['data']['data'] ?? [];
    $scopes     = array_map('strval', (array)($d['scopes'] ?? []));
    $granular   = (array)($d['granular_scopes'] ?? []);
    $isValid    = !empty($d['is_valid']);
    $expiresAt  = (int)($d['expires_at'] ?? 0);
    $type       = (string)($d['type'] ?? 'UNKNOWN');

    /**
     * The asset ids a scope may act on, or null when the scope carries no target_ids at all.
     *
     * That null is the important case, and it is NOT "all assets" — for a System User token it
     * means the opposite: the permission was granted but no WhatsApp Business Account has been
     * assigned to the system user, so the scope applies to nothing. Meta writes it as a bare
     * {"scope":"whatsapp_business_messaging"} with no target_ids, which reads like a pass and is
     * the single most misleading thing in this response.
     */
    $targetsFor = function (string $scope) use ($granular): ?array {
        foreach ($granular as $g) {
            if ((string)($g['scope'] ?? '') === $scope) {
                return isset($g['target_ids']) ? array_map('strval', (array)$g['target_ids']) : null;
            }
        }
        return null;
    };
    $scopeCovers = function (string $scope) use ($scopes, $targetsFor, $wabaId): array {
        if (!in_array($scope, $scopes, true)) return [false, 'not granted on this token'];
        $t = $targetsFor($scope);
        if ($t === null || !$t) {
            return [false, 'granted, but no WhatsApp Business Account is assigned to it '
                . '(Meta returned this scope with no target_ids)'];
        }
        if ($wabaId === '') return [true, 'granted for ' . count($t) . ' asset(s)'];
        return in_array($wabaId, $t, true)
            ? [true, 'granted for this WABA']
            : [false, 'granted, but NOT for WABA ' . $wabaId . ' (covers: ' . implode(', ', $t) . ')'];
    };

    [$msgOk, $msgWhy] = $scopeCovers('whatsapp_business_messaging');
    [$mgmOk, $mgmWhy] = $scopeCovers('whatsapp_business_management');

    $checks = [];
    $checks[] = [
        'ok' => $isValid, 'title' => 'Token is live',
        'detail' => $isValid
            ? ($type === 'SYSTEM_USER' ? 'System User token' : "Type: $type")
                . ($expiresAt > 0 ? ' — expires ' . date('M d, Y', $expiresAt) : ' — never expires')
            : 'Meta reports this token as invalid. Generate a new one.',
    ];
    $checks[] = [
        'ok' => $msgOk, 'title' => 'whatsapp_business_messaging (sending)',
        'detail' => $msgOk ? $msgWhy : $msgWhy . '. This is what causes #200.',
        'fix' => $msgOk ? null : (in_array('whatsapp_business_messaging', $scopes, true)
            // Scope present, asset missing — by far the most common shape of #200, because
            // ticking the permission during token creation feels like it should be enough.
            ? 'Business settings → Users → System users → user ' . ($d['user_id'] ?? '')
                . ' → Assigned assets → Add assets → WhatsApp accounts → tick this WABA → Full control.'
                . ' Then generate a NEW token — the asset list is baked in when a token is created.'
            : 'The token was generated without this scope, and a scope cannot be added afterwards. Generate a new token with whatsapp_business_messaging, whatsapp_business_management and business_management all ticked.'),
    ];
    $checks[] = [
        'ok' => $mgmOk, 'title' => 'whatsapp_business_management (templates)',
        'detail' => $mgmOk ? $mgmWhy : $mgmWhy,
        'fix' => $mgmOk ? null : 'Include this scope when you generate the token.',
    ];

    // Reading the WABA back proves management access end to end.
    if ($wabaId !== '') {
        $waba = wa_graph_call('GET', WA_GRAPH_BASE . WA_GRAPH_VERSION . '/' . rawurlencode($wabaId) . '?fields=id,name', $token);
        $checks[] = [
            'ok' => $waba['ok'], 'title' => 'Can read the WhatsApp Business Account',
            'detail' => $waba['ok'] ? 'Connected to "' . ($waba['data']['name'] ?? $wabaId) . '"' : $waba['error'],
        ];
    }

    /*
     * The decisive check: read the sending number itself. If this succeeds but a send still
     * returns #200, the remaining explanation is that the APP has no access to the WABA — a
     * different grant from the system user's, and the last thing left to rule out.
     */
    if ($pni !== '') {
        $num = wa_graph_call('GET', WA_GRAPH_BASE . WA_GRAPH_VERSION . '/' . rawurlencode($pni)
            . '?fields=id,display_phone_number,verified_name,platform_type,code_verification_status', $token);
        $checks[] = [
            'ok' => $num['ok'], 'title' => 'Can read the sending number',
            'detail' => $num['ok']
                ? ($num['data']['display_phone_number'] ?? $pni) . ' — ' . ($num['data']['platform_type'] ?? 'unknown platform')
                : $num['error'],
            'fix' => $num['ok'] ? null : 'Business settings → Accounts → WhatsApp accounts → this WABA → Connected apps → add your app.',
        ];
    }

    $allOk = true;
    foreach ($checks as $c) if (!$c['ok']) $allOk = false;

    api_success([
        'ok'        => $allOk,
        'checks'    => $checks,
        'scopes'    => $scopes,
        'waba_id'   => $wabaId,
        'summary'   => $allOk
            ? 'Everything the API can check looks correct. If sends still fail with #200, the APP itself has no access to this WABA — Business settings → Accounts → WhatsApp accounts → Connected apps.'
            : 'Fix the red rows below, then generate a fresh token and paste it above.',
    ]);
}

/* ── Business phone numbers ─────────────────────────────────────────────────────────────── */

/**
 * Adds a brand-new phone number to the WABA — step 1 of Meta's four-step flow:
 *   1. add      POST /{waba_id}/phone_numbers        {cc, phone_number, verified_name}
 *   2. request  POST /{phone_number_id}/request_code {code_method, language}
 *   3. verify   POST /{phone_number_id}/verify_code  {code}
 *   4. register POST /{phone_number_id}/register     {messaging_product, pin}
 *
 * Meta requires the business to be verified before step 1 succeeds, and the number must not
 * already be attached to another WhatsApp account.
 */
if ($action === 'number_add') {
    $token = wa_meta_token();
    if ($token === '') api_error('Add a Meta access token first');

    $cc     = preg_replace('/\D+/', '', (string)jin('cc', ''));
    $number = preg_replace('/\D+/', '', (string)jin('phone_number', ''));
    $name   = trim((string)jin('verified_name', ''));
    if ($cc === '' || $number === '') api_error('Country code and phone number are both required');
    if ($name === '') api_error('A display name is required — this is what recipients see');

    $wabaId = trim((string)jin('waba_id', ''));
    if ($wabaId === '') {
        $existing = wa_senders_all();
        $wabaId = trim((string)($existing[0]['waba_id'] ?? ''));
    }
    if ($wabaId === '') api_error('No WABA ID known yet');

    $res = wa_graph_call('POST', WA_GRAPH_BASE . WA_GRAPH_VERSION . '/' . rawurlencode($wabaId) . '/phone_numbers', $token, [
        'cc'            => $cc,
        'phone_number'  => $number,
        'verified_name' => $name,
    ]);
    if (!$res['ok']) api_error($res['error']);

    $pid = (string)($res['data']['id'] ?? '');
    if ($pid === '') api_error('Meta accepted the request but returned no phone number ID');

    $display  = '+' . $cc . $number;
    $displayE = $conn->real_escape_string($display);
    // Stored immediately so the number stays visible (and its verification resumable) even if
    // the admin closes the dialog part-way through.
    $conn->query("INSERT INTO wa_senders (waba_id, waba_name, business_number, display_name, phone_number_id, is_active)
                  VALUES ('" . $conn->real_escape_string($wabaId) . "',
                          '" . $conn->real_escape_string($name) . "',
                          '$displayE',
                          '" . $conn->real_escape_string($name) . "',
                          '" . $conn->real_escape_string($pid) . "', 1)
                  ON DUPLICATE KEY UPDATE phone_number_id=VALUES(phone_number_id), display_name=VALUES(display_name)");

    api_success(['phone_number_id' => $pid, 'business_number' => $display]);
}

/** Step 2 — ask Meta to send the verification code by SMS or voice call. */
if ($action === 'number_request_code') {
    $token = wa_meta_token();
    if ($token === '') api_error('Add a Meta access token first');
    $pid = trim((string)jin('phone_number_id', ''));
    if ($pid === '') api_error('phone_number_id required');

    $method = strtoupper((string)jin('code_method', 'SMS'));
    if (!in_array($method, ['SMS', 'VOICE'], true)) $method = 'SMS';

    $res = wa_graph_call('POST', WA_GRAPH_BASE . WA_GRAPH_VERSION . '/' . rawurlencode($pid) . '/request_code', $token, [
        'code_method' => $method,
        'language'    => (string)jin('language', 'en'),
    ]);
    if (!$res['ok']) api_error($res['error']);
    api_success(['sent_by' => $method]);
}

/** Step 3 — hand Meta the 6-digit code the phone received. */
if ($action === 'number_verify_code') {
    $token = wa_meta_token();
    if ($token === '') api_error('Add a Meta access token first');
    $pid  = trim((string)jin('phone_number_id', ''));
    $code = preg_replace('/\D+/', '', (string)jin('code', ''));
    if ($pid === '' || $code === '') api_error('phone_number_id and code are both required');

    $res = wa_graph_call('POST', WA_GRAPH_BASE . WA_GRAPH_VERSION . '/' . rawurlencode($pid) . '/verify_code', $token, ['code' => $code]);
    if (!$res['ok']) api_error($res['error']);
    api_success([]);
}

/**
 * Step 4 — register the number for Cloud API messaging.
 *
 * The PIN is the number's two-factor PIN, needed again if it is ever re-registered — so it is
 * stored on the sender row rather than left for someone to remember.
 */
if ($action === 'number_register') {
    $token = wa_meta_token();
    if ($token === '') api_error('Add a Meta access token first');
    $pid = trim((string)jin('phone_number_id', ''));
    $pin = preg_replace('/\D+/', '', (string)jin('pin', ''));
    if ($pid === '') api_error('phone_number_id required');
    if (strlen($pin) !== 6) api_error('The PIN must be exactly 6 digits');

    $res = wa_graph_call('POST', WA_GRAPH_BASE . WA_GRAPH_VERSION . '/' . rawurlencode($pid) . '/register', $token, [
        'messaging_product' => 'whatsapp',
        'pin'               => $pin,
    ]);
    if (!$res['ok']) api_error($res['error']);

    $conn->query("UPDATE wa_senders SET registration_pin='" . $conn->real_escape_string($pin) . "'
                   WHERE phone_number_id='" . $conn->real_escape_string($pid) . "'");
    api_success([]);
}

/**
 * Live status for one number, straight from Meta — verification, display-name review, quality
 * and throughput. This is what makes "is my new number usable yet?" answerable without leaving
 * the panel, since the answer changes over minutes to days while Meta reviews the name.
 */
if ($action === 'number_status') {
    $token = wa_meta_token();
    if ($token === '') api_error('Add a Meta access token first');
    $pid = trim((string)jin('phone_number_id', ''));
    if ($pid === '') api_error('phone_number_id required');

    $fields = 'id,display_phone_number,verified_name,code_verification_status,name_status,quality_rating,platform_type,account_mode,throughput,messaging_limit_tier';
    $res = wa_graph_call('GET', WA_GRAPH_BASE . WA_GRAPH_VERSION . '/' . rawurlencode($pid) . '?fields=' . rawurlencode($fields), $token);
    if (!$res['ok']) api_error($res['error']);

    $d = $res['data'];
    // Cached locally so the sending-numbers list can show quality without a Meta round-trip.
    $conn->query("UPDATE wa_senders SET quality_rating='" . $conn->real_escape_string((string)($d['quality_rating'] ?? '')) . "'
                   WHERE phone_number_id='" . $conn->real_escape_string($pid) . "'");
    api_success(['status' => $d]);
}

/*
 * Consent.
 *
 * Meta has no opt-in API — consent is the business's own record, kept off-platform. What this
 * list does is enforce opt-OUT: a number recorded here is excluded from every campaign at
 * audience-resolve time, and a contact replying STOP is added automatically by the webhook.
 */
if ($action === 'optin') {
    $type = jin('type', 'optin') === 'optout' ? 'optout' : 'optin';
    $raw = (string)jin('phones', '');
    $inputs = array_values(array_filter(array_map('trim', preg_split('/[,;\n]+/', $raw))));
    if (!$inputs) api_error('Enter at least one number');

    $cc = wa_default_cc();
    $valid = []; $invalid = [];
    foreach ($inputs as $in) {
        $p = wa_normalize_phone($in, $cc);
        if ($p === null) { $invalid[] = $in; continue; }
        $valid[$p] = true;
    }
    $valid = array_keys($valid);
    if (!$valid) api_error('None of those look like valid WhatsApp numbers');

    // A reason typed by whoever did this, so the Blocklist screen can say who blocked a number
    // and why — the same provenance a STOP reply records for itself.
    $reason = trim((string)jin('reason', ''));
    if ($reason === '') {
        $reason = $type === 'optout' ? 'Blocked by an admin from the panel' : 'Opted back in by an admin from the panel';
    }

    foreach ($valid as $p) wa_record_optin($p, $type, 'ADMIN', $reason);
    api_success(['registered' => count($valid), 'invalid' => $invalid, 'errors' => [], 'type' => $type]);
}

/*
 * Whether the Meta app is subscribed to this WABA's webhooks.
 *
 * This is the step that is easy to miss and impossible to guess: setting a Callback URL on the
 * app is NOT enough — the app must also be subscribed to the specific WhatsApp Business Account
 * (POST /{waba_id}/subscribed_apps). Without it Meta accepts the URL, verifies it, and then
 * never sends a single event, so Delivered/Read stay at 0 with everything looking correct.
 */
if ($action === 'webhook_status') {
    $token = wa_meta_token();
    if ($token === '') api_error('Add a Meta access token first');

    $senders = wa_senders_all();
    $wabaId = trim((string)($senders[0]['waba_id'] ?? ''));
    if ($wabaId === '') api_error('No WABA ID known yet');

    $res = wa_graph_call('GET', WA_GRAPH_BASE . WA_GRAPH_VERSION . '/' . rawurlencode($wabaId) . '/subscribed_apps', $token);
    if (!$res['ok']) api_error($res['error']);

    $apps = (array)($res['data']['data'] ?? []);
    api_success([
        'subscribed'  => count($apps) > 0,
        'apps'        => array_map(fn($a) => [
            'id'   => $a['whatsapp_business_api_data']['id'] ?? '',
            'name' => $a['whatsapp_business_api_data']['name'] ?? '',
        ], $apps),
        'waba_id'     => $wabaId,
    ]);
}

/** Subscribes the token's app to this WABA so its webhooks actually fire. */
if ($action === 'webhook_subscribe') {
    $token = wa_meta_token();
    if ($token === '') api_error('Add a Meta access token first');

    $senders = wa_senders_all();
    $wabaId = trim((string)($senders[0]['waba_id'] ?? ''));
    if ($wabaId === '') api_error('No WABA ID known yet');

    $res = wa_graph_call('POST', WA_GRAPH_BASE . WA_GRAPH_VERSION . '/' . rawurlencode($wabaId) . '/subscribed_apps', $token);
    if (!$res['ok']) api_error($res['error']);
    api_success(['subscribed' => !empty($res['data']['success'])]);
}

/*
 * Both the consent table and the WhatsApp Blocklist screen read this.
 *
 * They are the same rows seen from two angles: the blocklist is simply
 * `?status=optout`, because an opted-out number and a blocklisted one are not two states we
 * track separately — a second table would only give the two a chance to disagree, and the one
 * that campaign sending consults (wa_optins, via wa_optin_map) is the one that decides whether
 * a message goes out.
 */
if ($action === 'optin_list') {
    $page    = max(1, (int)jin('page', 1));
    $perPage = max(1, min(200, (int)jin('per_page', 20)));
    $search  = trim((string)jin('search', ''));
    $status  = (string)jin('status', '');
    $offset  = ($page - 1) * $perPage;

    $clauses = [];
    if ($search !== '') $clauses[] = "phone LIKE '%" . $conn->real_escape_string($search) . "%'";
    if ($status === 'optout' || $status === 'optin') $clauses[] = "status = '$status'";
    $where = $clauses ? 'WHERE ' . implode(' AND ', $clauses) : '';

    $tr = $conn->query("SELECT COUNT(*) AS c FROM wa_optins $where");
    $total = $tr ? (int)$tr->fetch_assoc()['c'] : 0;

    // Blocked numbers sort by when the block STARTED; everything else by last touch. COALESCE
    // keeps one query serving both views without a branch.
    $r = $conn->query("SELECT phone, status, source, reason, blocked_at, updated_at
                         FROM wa_optins $where
                        ORDER BY COALESCE(blocked_at, updated_at) DESC
                        LIMIT $perPage OFFSET $offset");
    $rows = [];
    while ($r && $row = $r->fetch_assoc()) $rows[] = $row;

    // The badge on the Blocklist tab, and the "N numbers blocked" line — always the full count,
    // never the filtered page's.
    $br = $conn->query("SELECT COUNT(*) AS c FROM wa_optins WHERE status='optout'");
    $blockedTotal = $br ? (int)$br->fetch_assoc()['c'] : 0;

    api_success(['optins' => $rows, 'total' => $total, 'page' => $page, 'per_page' => $perPage,
                 'blocked_total' => $blockedTotal,
                 'pages' => $total > 0 ? (int)ceil($total / $perPage) : 1]);
}

api_error('Invalid action');

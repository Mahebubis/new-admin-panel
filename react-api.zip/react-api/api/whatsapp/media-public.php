<?php
/*
 * Signed, expiring public read of ONE file in the WhatsApp media cache.
 *
 * Why this exists: Netcore does not accept an uploaded media id the way Meta's Cloud API does —
 * it fetches the attachment from a URL at send time, from its own servers, with no knowledge of
 * the panel's session. So an attachment sent from Live Chat on a Netcore-routed number has to be
 * readable without a JWT for as long as the BSP needs to pull it.
 *
 * "Without a JWT" is not "without protection". Every URL carries an HMAC over the exact filename
 * and an expiry (wa_public_media_url() in lib/WaInbox.php), so:
 *   - the media directory cannot be enumerated: a URL is only good for the one file it names,
 *   - a leaked URL is dead within the hour,
 *   - nothing here reads the database, so a bad request costs one hash and a 403.
 *
 * This is the ONLY unauthenticated entry point in the WhatsApp API surface. Everything else,
 * including the inbound-media view the panel itself uses (wa_inbox.php?action=media), stays
 * behind the gate.
 */
require_once __DIR__ . '/lib/config.php';

/** Text/plain, never HTML: nothing here should ever be rendered by a browser as a page. */
function media_public_deny(int $code, string $why): void {
    http_response_code($code);
    header('Content-Type: text/plain; charset=utf-8');
    header('X-Content-Type-Options: nosniff');
    echo $why;
    exit;
}

$file = basename((string)($_GET['f'] ?? ''));
$exp  = (int)($_GET['e'] ?? 0);
$sig  = (string)($_GET['s'] ?? '');

if ($file === '' || $exp <= 0 || $sig === '') media_public_deny(400, 'Bad request');
if ($exp < time())                            media_public_deny(410, 'This link has expired');

// hash_equals, not ===, so a wrong signature costs the same time as a right one and the
// comparison cannot be walked byte by byte.
$expected = hash_hmac('sha256', $file . '|' . $exp, WA_CRON_SECRET);
if (!hash_equals($expected, $sig)) media_public_deny(403, 'Invalid signature');

$dir = defined('WA_MEDIA_DIR') ? WA_MEDIA_DIR : __DIR__ . '/media';
$path = $dir . '/' . $file;

// realpath() closes the door on a filename that escapes the directory. basename() above already
// strips path separators, but the check is cheap and this is the one file anyone can reach.
$real = realpath($path);
if ($real === false || strpos($real, realpath($dir) ?: $dir) !== 0 || !is_file($real)) {
    media_public_deny(404, 'Not found');
}

$mime = 'application/octet-stream';
if (function_exists('finfo_open')) {
    $fi = finfo_open(FILEINFO_MIME_TYPE);
    if ($fi) { $detected = finfo_file($fi, $real); finfo_close($fi); if ($detected) $mime = $detected; }
}

header('Content-Type: ' . $mime);
header('Content-Length: ' . filesize($real));
header('X-Content-Type-Options: nosniff');
// Inline, and never cached by a shared proxy — the URL is single-purpose and short-lived.
header('Content-Disposition: inline; filename="' . preg_replace('/[^\w. \-()]+/u', '_', $file) . '"');
header('Cache-Control: private, max-age=3600');
readfile($real);

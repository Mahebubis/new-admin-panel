<?php
/*
 * /api/whatsapp/c.php — the WhatsApp click tracker.
 *
 *   WhatsApp link  →  c.php?t=<recipient rid>  →  records WHO tapped  →  302 to the real page
 *
 * WHY THIS FILE HAS TO EXIST
 * WhatsApp tells nobody when a link is tapped. The phone opens a browser and that is the end of
 * it — no webhook from Meta, none from Netcore, nothing to subscribe to. (Meta's
 * `marketing_messages_link_click` event exists, but it carries a tracking_token rather than a
 * phone number, so it cannot be resolved to a person either — see wa_apply_user_actions().) The
 * click is only observable if the link points here first.
 *
 * WHY IT IS THE ONLY WAY TO GET A **NAMED** CLICK
 * Every other shape of link is anonymous by construction:
 *
 *   the approved BUTTON url   frozen at approval, byte-identical in every copy of the message
 *                             ever sent. Nothing in it says who tapped.
 *   a static  …/login/23      the same string for everybody. link.php counts the tap, but the
 *                             best it can say is "a visitor", and it only ever learns a name if
 *                             that visitor later signs in on the same browser.
 *   …/login?campaign_id=…     carries the person, but goes STRAIGHT to the landing page, so the
 *                             tap is only counted if that page calls click.php back. When it
 *                             doesn't, the click silently never happened — no error anywhere,
 *                             the Clicked column simply stays at 0 forever.
 *
 * A link through here has none of those failure modes. Our own server is hit by the tap itself,
 * and the rid in the query string is a 128-bit value that names exactly one recipient row — so
 * the click is counted, logged with that person's phone, email and user id, and shown by name in
 * the report before the visitor has finished loading the destination. Nothing else has to
 * cooperate.
 *
 * That is also what makes honest conversion attribution possible. Without it a "conversion" can
 * only mean "received the message, and later did the thing" — which credits the campaign for
 * people who would have signed in anyway. With it, a conversion means "clicked THROUGH this
 * message, and then did the thing", which is the claim you actually want to make.
 *
 * And it deliberately keeps counting after the visit ends: the window runs from the CLICK, so
 * someone who taps, closes the browser, and comes back the next day by typing the address still
 * converts. What it will not do is credit someone who never tapped at all.
 *
 * ── HOW TO POINT A MESSAGE AT IT ─────────────────────────────────────────────
 *
 *   BODY VARIABLE (recommended — needs no template re-approval, because body variables are
 *   free text and Meta does not police their contents):
 *
 *       template body:  Your exam is live. Open it here: {{1}}
 *       campaign var:   XX_WA_TRACKED_URL_XX
 *
 *   the send worker expands that per recipient into  …/c.php?t=<their rid>.
 *
 *   DYNAMIC BUTTON, for a template approved as  …/api/whatsapp/c.php?t={{1}}  — set the button
 *   variable to XX_WA_CLICK_TOKEN_XX. Meta has historically refused variable-bearing button
 *   URLs, and Netcore drops the button parameter outright (131008), which is why the body
 *   variable above is the path that actually works.
 *
 *   STATIC, ANONYMOUS:  …/c.php?l=<link id>  counts the tap and forwards it, but cannot name
 *   anybody. Only worth using where a template genuinely has no variable to spare.
 *
 * NO AUTH, deliberately: this is opened by a phone tapping a link, and it must be as fast and as
 * unconditional as a redirect can be. The worst a forged rid can do is add a click to a campaign
 * — the endpoint writes nothing else and returns nothing at all.
 */
ini_set('display_errors', 0);
error_reporting(E_ALL & ~E_WARNING & ~E_NOTICE & ~E_DEPRECATED);

require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/lib/config.php';
require_once __DIR__ . '/lib/schema.php';

/** Last-resort destination, used when a click can't be resolved to a campaign. Better to land the
 *  visitor somewhere real than to show them an error page they can do nothing about. */
if (!defined('WA_CLICK_FALLBACK_URL')) define('WA_CLICK_FALLBACK_URL', 'https://internshipstudio.com/');

/** Sends the visitor on their way and stops. Called on every path, including failures — a
 *  tracking problem is ours, never the customer's. */
function wa_click_redirect(string $url): void {
    if (!preg_match('~^https?://~i', $url)) $url = WA_CLICK_FALLBACK_URL;
    header('Location: ' . $url, true, 302);
    header('Cache-Control: no-store, no-cache, must-revalidate');
    exit;
}

/**
 * Appends the attribution parameters to the destination.
 *
 *   campaign_id   which send gets the credit
 *   medium        'whatsapp' rather than 'email', so the two channels stay separable in
 *                 campaign_attributions (they share that table and would otherwise collide on
 *                 campaign_id — WhatsApp #11 and email #11 are different campaigns)
 *   attr_window   the sender's own goal window, which sizes the attribution cookie's expiry at
 *                 the other end
 *   goal          the event that counts as the conversion
 *   phone/wa_rid  WHO this is. Carried through even though the click is already recorded here,
 *                 because the landing page can then greet them, pre-fill a form, or report a
 *                 second event against the right person — all without a session.
 *
 * The dashboard's src/utils/attribution.js reads campaign_id / medium / attr_window and nothing
 * else — see campaigns/track-click.php, which builds the identical string. Matching it exactly
 * is the point: a WhatsApp visitor is then attributed by the same code, on the same terms, as an
 * email one, and record_conversion() writes the campaign_attributions row when the goal fires.
 *
 * http_build_query, and an existing query string is preserved: the destination may already carry
 * its own parameters, and appending with a bare '?' would corrupt them.
 */
function wa_click_target(string $target, array $params): string {
    $target = trim($target);
    if ($target === '') $target = WA_CLICK_FALLBACK_URL;

    /*
     * No campaign_id, nothing to attribute. Returning the bare destination is deliberate rather
     * than tidy-minded: attribution.js DELETES an existing cookie when a visitor arrives without
     * one, so appending a lone attr_window would be worse than useless — it would look like an
     * attribution while carrying none.
     */
    if ((int)($params['campaign_id'] ?? 0) <= 0) return $target;

    $params['attr_window'] = max(1, min(90, (int)($params['attr_window'] ?? 2)));
    foreach ($params as $k => $v) {
        if ($v === null || $v === '') unset($params[$k]);
    }

    return $target . (strpos($target, '?') === false ? '?' : '&') . http_build_query($params);
}

$rid    = trim((string)($_GET['t'] ?? ''));
$linkId = (int)($_GET['l'] ?? 0);

// Shape check before touching the database: the rid is exactly 32 hex characters, so anything
// else is a crawler or a mangled link and deserves no query.
$hasRid = (bool)preg_match('/^[a-f0-9]{32}$/i', $rid);
if (!$hasRid && $linkId <= 0) wa_click_redirect(WA_CLICK_FALLBACK_URL);

/*
 * whatsapp_ensure_schema() is deliberately NOT called here, unlike everywhere else in this
 * feature. It runs a long series of SHOW COLUMNS / ALTER probes, and this endpoint sits between
 * a person's tap and the page they are waiting for — a redirect is the one place where that cost
 * is paid by the customer. Every table touched below must already exist for a message to have
 * been sent at all, and the one column that legitimately may not (wa_link_clicks.journey_id, an
 * upgrade-time addition) is handled by the prepare() fallback in wa_click_log().
 */

$ipAddr = substr((string)($_SERVER['REMOTE_ADDR'] ?? ''), 0, 45);
$ua     = substr((string)($_SERVER['HTTP_USER_AGENT'] ?? ''), 0, 255);

/**
 * One tap, one row in wa_link_clicks — the table the report's "who clicked" list reads.
 *
 * This is the half that used to be missing, and its absence produced the exact opposite of what
 * anyone would expect: a tap on the ANONYMOUS static button appeared in the list (as a visitor),
 * while a tap on the tracked link — the one that knows precisely who tapped — appeared nowhere.
 * The counters moved, so the campaign's Clicked figure was right and the list behind it was
 * empty. Setting tracking up correctly made clicks vanish from the report.
 *
 * No de-duplication, deliberately, and consistent with the rest of this table: it records taps,
 * and the report decides at read time whether the question is "how many taps" or "how many
 * people". A second tap by the same person is a second row and one person.
 */
function wa_click_log(int $linkId, ?int $campaignId, ?int $journeyId, ?int $recipientId,
                      ?int $userId, string $phone, string $email, string $identity,
                      ?string $visitorKey, string $ip, string $ua): void {
    global $conn;

    $stmt = @$conn->prepare(
        "INSERT INTO wa_link_clicks
            (link_id, campaign_id, journey_id, recipient_id, visitor_key, user_id, phone, email,
             identity_key, ip, user_agent, clicked_at)
         VALUES (?,?,?,?,?,?,?,?,?,?,?,NOW())"
    );
    // journey_id is added by an upgrade step rather than the original CREATE TABLE, so a backend
    // that has not run it yet has no such column. Fall back to the eleven-column form instead of
    // losing the row — an old schema should cost the journey split, not the click.
    if (!$stmt) {
        $stmt = @$conn->prepare(
            "INSERT INTO wa_link_clicks
                (link_id, campaign_id, recipient_id, visitor_key, user_id, phone, email,
                 identity_key, ip, user_agent, clicked_at)
             VALUES (?,?,?,?,?,?,?,?,?,?,NOW())"
        );
        if (!$stmt) return;
        // 10 placeholders: link, campaign, recipient, visitor, user, phone, email, identity, ip, ua
        $stmt->bind_param('iiisisssss', $linkId, $campaignId, $recipientId, $visitorKey,
                          $userId, $phone, $email, $identity, $ip, $ua);
        @$stmt->execute();
        $stmt->close();
        return;
    }
    // 11 placeholders: the same, plus journey_id in third position.
    $stmt->bind_param('iiiisisssss', $linkId, $campaignId, $journeyId, $recipientId, $visitorKey,
                      $userId, $phone, $email, $identity, $ip, $ua);
    @$stmt->execute();
    $stmt->close();
}

/* ════════════════════════════════════════════════════════════════════════════
   IDENTIFIED TAP — the rid names one recipient row.
   ═══════════════════════════════════════════════════════════════════════════ */
if ($hasRid) {
    $ridEsc = $conn->real_escape_string(strtolower($rid));

    /*
     * Three sources for the destination, narrowest first: the campaign's own snapshot, then the
     * template's live value, then the wa_links row the template's tracked link points at.
     *
     * The third is not belt-and-braces. A template IMPORTED from Meta has its link only inside
     * its approved body text, so click_target_url can legitimately be blank on both the campaign
     * and the template — and without this the visitor would be forwarded to the fallback
     * homepage instead of the page the message promised them. Landing somewhere wrong is far
     * worse than an uncounted click.
     */
    $r = $conn->query("SELECT r.id, r.campaign_id, r.first_clicked_at, r.delivered_at, r.read_at,
                              r.phone, r.email, r.user_id,
                              c.goal_window_days, c.goal_event_name,
                              t.link_id,
                              COALESCE(NULLIF(c.click_target_url, ''),
                                       NULLIF(t.click_target_url, ''),
                                       l.target_url) AS click_target_url
                         FROM wa_campaign_recipients r
                         JOIN wa_campaigns c ON c.id = r.campaign_id
                         LEFT JOIN wa_templates t ON t.id = c.template_id
                         LEFT JOIN wa_links l     ON l.id = t.link_id
                        WHERE r.rid = '$ridEsc' LIMIT 1");
    $row = $r ? $r->fetch_assoc() : null;

    /*
     * Not a campaign recipient — the tap may belong to a JOURNEY step. Journey WhatsApp sends
     * carry their own rid in journey_messages and go out through this same template plumbing, so
     * the link is indistinguishable from a campaign's. Without this branch a journey tap landed
     * on the fallback page with nothing recorded, and because first_clicked_at anchors
     * last-click attribution, its conversions could never be credited either.
     *
     * file_exists-guarded: this backend deploys folder by folder, and requiring a file that has
     * not been uploaded yet is fatal — on a redirect endpoint that means a white page instead of
     * the destination.
     */
    if (!$row) {
        $sink = __DIR__ . '/../journeys/lib/JourneyWebhookSink.php';
        if (file_exists($sink)) {
            require_once $sink;

            $jr = @$conn->query("SELECT m.id, m.journey_id, m.user_id, m.to_addr,
                                        j.goal_event, j.goal_window_hours
                                   FROM journey_messages m
                                   LEFT JOIN journeys j ON j.id = m.journey_id
                                  WHERE m.rid = '$ridEsc' LIMIT 1");
            $jrow = $jr ? $jr->fetch_assoc() : null;

            if ($jrow) {
                // The journey's own credit — click_count, first_clicked_at, and the delivered /
                // opened stamps a tap implies. Reused rather than reimplemented so a journey tap
                // counts identically whether it arrived here or through the landing page.
                journey_webhook_wa_click(strtolower($rid));

                $journeyId  = (int)$jrow['journey_id'];
                $windowDays = journey_attr_window_days((int)($jrow['goal_window_hours'] ?? 0));

                /*
                 * Where to send them. A journey's step does not record its destination on the
                 * message, so it is read from the wa_links row this journey most recently bound
                 * — which is what wa_link_bind_journey() writes on every journey WhatsApp send.
                 *
                 * Exact for the ordinary journey, which sends one WhatsApp template. A journey
                 * with SEVERAL WhatsApp steps pointing at different destinations can send a late
                 * tap on an early step to the newer step's page, because nothing on the message
                 * says which template produced it. Journeys are not routed through here by
                 * default for exactly that reason — JourneyDispatch still builds a direct link —
                 * so this branch only runs when a journey deliberately uses a tracked-link body
                 * variable, and the counting it buys is worth the ambiguity.
                 */
                $lr = @$conn->query("SELECT id, target_url FROM wa_links
                                      WHERE journey_id = $journeyId AND target_url <> ''
                                      ORDER BY bound_at DESC, id DESC LIMIT 1");
                $lrow    = $lr ? $lr->fetch_assoc() : null;
                $jLinkId = (int)($lrow['id'] ?? 0);
                $target  = (string)($lrow['target_url'] ?? '');

                $jPhone = preg_replace('/\D+/', '', (string)($jrow['to_addr'] ?? ''));
                $jUser  = (int)($jrow['user_id'] ?? 0);
                $jIdent = $jPhone !== '' ? $jPhone : 'rid:' . substr(strtolower($rid), 0, 24);

                if ($jLinkId > 0) $conn->query("UPDATE wa_links SET click_count = click_count + 1 WHERE id = $jLinkId");
                wa_click_log($jLinkId, null, $journeyId, null, $jUser > 0 ? $jUser : null,
                             $jPhone, '', $jIdent, null, $ipAddr, $ua);

                /*
                 * A journey hands back ITS OWN id, moved into the journey range and marked with
                 * medium 'journey', so the conversion it earns cannot be credited to a campaign
                 * that merely shares the template — and cannot collide with a campaign of the
                 * same number. Only a journey with a goal gets a sticker at all: handing one out
                 * otherwise gives the dashboard something to store with nothing to attribute,
                 * and would overwrite an attribution the visitor legitimately arrived with.
                 */
                $goal = trim((string)($jrow['goal_event'] ?? ''));
                wa_click_redirect(wa_click_target($target, $goal === '' ? [] : [
                    'campaign_id' => journey_attr_campaign_id($journeyId),
                    'medium'      => JOURNEY_ATTR_MEDIUM,
                    'attr_window' => $windowDays,
                    'goal'        => $goal,
                    'phone'       => $jPhone,
                    'wa_rid'      => strtolower($rid),
                ]));
            }
        }
        // A rid that matches nothing at all: a stale link from a deleted campaign, or a guess.
        wa_click_redirect(WA_CLICK_FALLBACK_URL);
    }

    $recipientId = (int)$row['id'];
    $campaignId  = (int)$row['campaign_id'];
    $isFirst     = empty($row['first_clicked_at']);

    /*
     * Every tap increments click_count — five taps is five taps, and that's a real engagement
     * signal. But first_clicked_at is written ONCE, because it anchors the attribution window:
     * letting a later tap move it would quietly extend the window every time someone revisited,
     * and a conversion could then be credited indefinitely.
     *
     * ── A TAP PROVES THE MESSAGE WAS DELIVERED AND READ ──────────────────────
     *
     * delivered_at and read_at are stamped here too, and this is not bookkeeping tidiness — it
     * is the only way these two figures can be right for a large share of recipients. WhatsApp
     * read receipts are the RECIPIENT's setting: anyone who has them switched off, or who has
     * not added the business as a contact, generates no `read` webhook ever. Their message is
     * genuinely read; Meta simply never says so, and the campaign ends up reporting Delivered 1,
     * Read 0, Clicked 2 — three numbers that cannot all be true.
     *
     * A tap resolves it, because a tap is stronger evidence than a receipt: somebody opened the
     * message, found the link and pressed it. COALESCE means a real receipt that arrived first
     * keeps its own earlier timestamp, so this only ever fills a gap.
     */
    $wasUnread  = empty($row['read_at']);
    $wasUndeliv = empty($row['delivered_at']);

    $conn->query("UPDATE wa_campaign_recipients
                     SET click_count      = click_count + 1,
                         first_clicked_at = COALESCE(first_clicked_at, NOW()),
                         delivered_at     = COALESCE(delivered_at, NOW()),
                         read_at          = COALESCE(read_at, NOW()),
                         status           = CASE WHEN status IN ('sent','delivered') THEN 'read' ELSE status END
                   WHERE id = $recipientId");

    // The campaign rollups move only for the transitions that actually happened. Incrementing
    // unconditionally would double-count a recipient whose real read receipt had already arrived
    // and already been counted — these columns are totals, not derived on read.
    $bump = ['click_count = click_count + 1'];
    if ($wasUnread)  $bump[] = 'read_count = read_count + 1';
    if ($wasUndeliv) $bump[] = 'delivered_count = delivered_count + 1';
    $conn->query("UPDATE wa_campaigns SET " . implode(', ', $bump) . " WHERE id = $campaignId");

    $tplLinkId = (int)($row['link_id'] ?? 0);
    if ($tplLinkId > 0) $conn->query("UPDATE wa_links SET click_count = click_count + 1 WHERE id = $tplLinkId");

    /*
     * The identity ladder, same order the rest of this feature uses: the phone is the person,
     * the email is the fallback when there is no number. There is no third case here — a tap
     * that reached this branch carried a rid, so it always belongs to a known recipient row.
     * identity_key being a real phone rather than a visitor key is exactly what makes these rows
     * collapse correctly in the unique "People" view and show a NAME instead of "Anonymous
     * visitor".
     */
    $phone = preg_replace('/\D+/', '', (string)($row['phone'] ?? ''));
    $email = strtolower(trim((string)($row['email'] ?? '')));
    $uid   = (int)($row['user_id'] ?? 0);
    $ident = $phone !== '' ? $phone : ($email !== '' ? $email : 'rid:' . substr(strtolower($rid), 0, 24));

    wa_click_log($tplLinkId, $campaignId, null, $recipientId, $uid > 0 ? $uid : null,
                 $phone, $email, $ident, null, $ipAddr, $ua);

    // Only the first tap becomes a timeline event; the rest are already in the counter and would
    // otherwise bury everything else in the report's event list.
    if ($isFirst) {
        $conn->query("INSERT INTO wa_campaign_events (campaign_id, recipient_id, event_type, detail)
                      VALUES ($campaignId, $recipientId, 'button_click', 'WhatsApp tracked link tap')");
    }

    wa_click_redirect(wa_click_target((string)($row['click_target_url'] ?? ''), [
        'campaign_id' => $campaignId,
        'medium'      => 'whatsapp',
        'attr_window' => (int)($row['goal_window_days'] ?: 2),
        'goal'        => (string)($row['goal_event_name'] ?? ''),
        'phone'       => $phone,
        'wa_rid'      => strtolower($rid),
    ]));
}

/* ════════════════════════════════════════════════════════════════════════════
   STATIC TAP — …/c.php?l=<link id>, the same link in everybody's message.

   Counted, forwarded, and honestly anonymous. Worth having because the alternative static shape
   — a link straight to the landing page — is not counted AT ALL unless that page calls back,
   and a click that is anonymous is still enormously more useful than a click that is invisible.

   No attempt is made to guess who this is. An IP+user-agent hash is used as the identity so the
   report's unique count is something other than zero; it is not a person and never pretends to
   be one. Use a body variable and XX_WA_TRACKED_URL_XX if you want names.
   ═══════════════════════════════════════════════════════════════════════════ */
$lr = $conn->query("SELECT l.id, l.target_url, l.campaign_id, l.owner_kind,
                           c.goal_event_name, c.goal_window_days
                      FROM wa_links l
                      LEFT JOIN wa_campaigns c ON c.id = l.campaign_id
                     WHERE l.id = $linkId LIMIT 1");
$link = $lr ? $lr->fetch_assoc() : null;
if (!$link) wa_click_redirect(WA_CLICK_FALLBACK_URL);

$conn->query("UPDATE wa_links SET click_count = click_count + 1 WHERE id = $linkId");

$campaignId = (int)($link['campaign_id'] ?? 0);
// Only a campaign-owned link moves a campaign counter. A link most recently sent by a journey
// still carries the campaign that used it before, and crediting that campaign would invent a
// click on a send that did not happen.
$ownedByCampaign = $campaignId > 0 && (string)($link['owner_kind'] ?? 'campaign') !== 'journey';
if ($ownedByCampaign) {
    $conn->query("UPDATE wa_campaigns SET click_count = click_count + 1 WHERE id = $campaignId");
}

wa_click_log($linkId, $ownedByCampaign ? $campaignId : null, null, null, null, '', '',
             'anon:' . substr(md5($ipAddr . '|' . $ua), 0, 24), null, $ipAddr, $ua);

wa_click_redirect(wa_click_target((string)$link['target_url'], $ownedByCampaign ? [
    'campaign_id' => $campaignId,
    'medium'      => 'whatsapp',
    'attr_window' => (int)($link['goal_window_days'] ?: 2),
    'goal'        => (string)($link['goal_event_name'] ?? ''),
] : []));

<?php
/*
 * /api/whatsapp/link.php — "what does /login/23 mean?"
 *
 * The landing page's half of the static-link scheme. A WhatsApp template is approved with a link
 * that carries no variable and no query string at all:
 *
 *     https://dashboard.internshipstudio.com/login/23
 *
 * The phone opens that page directly — cit3 is never contacted by the tap — so the page reads the
 * 23 off its own path and asks here what it stands for. What comes back is exactly the three
 * values that c.php used to hand over in the query string:
 *
 *     { campaign_id: 91, medium: "whatsapp", attr_window: 2 }
 *
 * which is what attribution.js already knows how to turn into the campaign_attr cookie. Nothing
 * downstream changes: same cookie, same campaign_attributions row, same conversion cron, same
 * rules as email. The only difference is how the three values reached the browser.
 *
 * IT ALSO RECORDS THE CLICK, because with a static link there is no other witness. A tap is
 * counted against the link and against whichever send OWNS it. Per-PERSON click attribution comes
 * back the moment the visitor is identified: pass user_id once they are logged in and the matching
 * recipient row — or journey message — is credited too.
 *
 * OWNER: a campaign OR a journey. The id is frozen into the approved template, so one template
 * used by both hands the same /login/23 to both audiences and the tap itself says nothing about
 * where it came from. See the long note at "WHO OWNS THIS TAP" below for how that is decided.
 *
 * NO AUTH, deliberately — same reasoning as c.php. This is a phone opening a link, and it must
 * answer as unconditionally as a redirect. A link id is not a secret: it is printed in the
 * message. The worst a forged call can do is add a click to a campaign, and the endpoint writes
 * nothing else and returns nothing that isn't already in the message the visitor is holding.
 */
ini_set('display_errors', 0);
error_reporting(E_ALL & ~E_WARNING & ~E_NOTICE & ~E_DEPRECATED);
header('Content-Type: application/json');

/*
 * CORS, because the caller is the dashboard's own JavaScript on a different host
 * (dashboard.internshipstudio.com reaching cit3.internshipstudio.com). Restricted to this
 * business's own origins rather than '*'.
 */
$origin = $_SERVER['HTTP_ORIGIN'] ?? '';
if ($origin !== '' && preg_match('~^https?://([a-z0-9-]+\.)*internshipstudio\.com$~i', $origin)) {
    header('Access-Control-Allow-Origin: ' . $origin);
    header('Vary: Origin');
    header('Access-Control-Allow-Headers: Content-Type');
    header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
}
if (($_SERVER['REQUEST_METHOD'] ?? '') === 'OPTIONS') { http_response_code(204); exit; }

require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/lib/config.php';
require_once __DIR__ . '/lib/schema.php';

whatsapp_ensure_schema();

function link_out(bool $ok, array $extra = [], string $message = ''): void {
    echo json_encode(array_merge(['success' => $ok, 'message' => $message], $extra));
    exit;
}

$linkId = (int)($_REQUEST['id'] ?? 0);
if ($linkId <= 0) link_out(false, [], 'id required');

/*
 * The sender's own goal window, not the link's stored copy, when the two disagree — the link
 * row is a cache written at send time and the campaign (or journey) is the source of truth.
 */
$r = $conn->query("SELECT l.id, l.target_url, l.campaign_id, l.owner_kind, l.journey_id,
                          l.goal_event_name, l.goal_window_days,
                          c.goal_event_name  AS c_goal,
                          c.goal_window_days AS c_window,
                          c.status           AS c_status
                     FROM wa_links l
                     LEFT JOIN wa_campaigns c ON c.id = l.campaign_id
                    WHERE l.id = $linkId LIMIT 1");
$row = $r ? $r->fetch_assoc() : null;

if (!$row) link_out(false, [], 'Unknown link');

/*
 * The journey's goal is read in a SECOND, suppressed query rather than joined above on purpose.
 * `journeys` belongs to another feature and is created by its own ensure_schema; joining it here
 * would mean a server without the journeys tables resolves NO link at all and every WhatsApp
 * campaign tap starts answering "Unknown link". A missing table must cost journeys their goal
 * window, not break the campaigns that were working before journeys existed.
 */
$row['j_goal'] = null;
$row['j_window_hours'] = null;
if ((int)($row['journey_id'] ?? 0) > 0) {
    $jr = @$conn->query("SELECT goal_event, goal_window_hours FROM journeys
                          WHERE id = " . (int)$row['journey_id'] . " LIMIT 1");
    if ($jr && $jrow0 = $jr->fetch_assoc()) {
        $row['j_goal'] = $jrow0['goal_event'];
        $row['j_window_hours'] = $jrow0['goal_window_hours'];
    }
}

$campaignId = (int)($row['campaign_id'] ?? 0);
$journeyId  = (int)($row['journey_id']  ?? 0);

/*
 * Who tapped, when that is known at all. Read up here rather than beside its use below because
 * the owner decision immediately after needs it, and so does the unique-click row further down —
 * a visitor who signs in must be attached to their existing row, not counted a second time.
 */
$userId = (int)($_REQUEST['user_id'] ?? 0);

/* ════════════════════════════════════════════════════════════════════════════
   WHO OWNS THIS TAP — a campaign, or a journey?

   The link id is frozen into the Meta-approved template, so one template used by both hands
   out the identical /login/<id> to both audiences. There is nothing in the tap itself that
   says which send it came from; it has to be worked out here, and it is worked out twice,
   because the two moments know different amounts:

     ANONYMOUS (the first tap, straight off the phone, logged out)
       Nobody to ask about. owner_kind — whoever sent this template most recently — is the only
       answer available, and it is the same rule the campaigns already lived by.

     IDENTIFIED (the credit_only call the dashboard makes after sign-in)
       Now there IS somebody to ask about, so guessing stops: ask the campaign and the journey
       when each of them last messaged THIS person, and give the tap to whichever actually did
       it more recently. This is what stops a campaign sent to a different audience yesterday
       from claiming a journey message sent to this person an hour ago.
   ═══════════════════════════════════════════════════════════════════════════ */
$owner = ((string)($row['owner_kind'] ?? 'campaign') === 'journey' && $journeyId > 0)
    ? 'journey' : 'campaign';

if ($userId > 0 && $campaignId > 0 && $journeyId > 0) {
    $cq = $conn->query("SELECT sent_at FROM wa_campaign_recipients
                         WHERE campaign_id = $campaignId AND user_id = $userId
                           AND is_test = 0 AND sent_at IS NOT NULL
                         ORDER BY sent_at DESC LIMIT 1");
    $jq = @$conn->query("SELECT sent_at FROM journey_messages
                         WHERE journey_id = $journeyId AND user_id = $userId
                           AND channel = 'whatsapp' AND sent_at IS NOT NULL
                         ORDER BY sent_at DESC LIMIT 1");
    $cAt = ($cq && $cr2 = $cq->fetch_assoc()) ? strtotime((string)$cr2['sent_at']) : 0;
    $jAt = ($jq && $jr2 = $jq->fetch_assoc()) ? strtotime((string)$jr2['sent_at']) : 0;
    // Only override when one of them actually messaged this person; two zeroes means neither
    // did (a forwarded message, a shared phone) and owner_kind stays the answer.
    if ($cAt || $jAt) $owner = $jAt > $cAt ? 'journey' : 'campaign';
}

if ($owner === 'journey') {
    // Journeys size the window in HOURS; the cookie and the report both speak days.
    $window = (int)ceil(((int)($row['j_window_hours'] ?: 48)) / 24);
    $goal   = (string)($row['j_goal'] ?: $row['goal_event_name'] ?: '');
} else {
    $window = (int)($row['c_window'] ?: $row['goal_window_days'] ?: 2);
    $goal   = (string)($row['c_goal'] ?: $row['goal_event_name'] ?: '');
}
$window = max(1, min(90, $window));

/*
 * CREDIT-ONLY MODE — "you already counted this tap; now you know who made it".
 *
 * A visitor arriving from WhatsApp is logged OUT, so the first call carries no user_id and the
 * tap can only be counted at campaign level. The dashboard calls again once they have signed in,
 * and that second call must attach the person WITHOUT counting a second tap — otherwise every
 * conversion would arrive having apparently clicked twice.
 */
$creditOnly = !empty($_REQUEST['credit_only']);

/*
 * Count the tap. The link counter always moves; the owner's counter moves with it so the report
 * and the link agree.
 *
 * A link that has never been sent (no campaign and no journey) still resolves and still gets its
 * click counted — that is the "I opened the template preview to check the link works" case, and
 * refusing it would make the link look broken during setup.
 *
 * Nothing is added to a journey here. journeys.clicked_count is not a counter that is incremented;
 * it is RECOMPUTED every worker tick from journey_messages.first_clicked_at, so a number written
 * onto the journey row would be erased within the minute. A journey tap is credited by stamping
 * the message below, which is also what its conversion attribution anchors on.
 */
if (!$creditOnly) {
    $conn->query("UPDATE wa_links SET click_count = click_count + 1 WHERE id = $linkId");
    if ($owner === 'campaign' && $campaignId > 0) {
        $conn->query("UPDATE wa_campaigns SET click_count = click_count + 1 WHERE id = $campaignId");
    }
}

/*
 * WHO THIS IS, as far as anyone can tell.
 *
 * Phone first, then email — that is the identity the report deduplicates on, so two logins from
 * two devices on one number stay one person. Read from `users` when they are signed in; the
 * campaign's own recipient row is the fallback, since a list-sourced audience may carry a number
 * the account doesn't.
 */
$visitorRaw = trim((string)($_REQUEST['visitor'] ?? ''));
$visitorKey = preg_match('/^[a-zA-Z0-9_-]{8,64}$/', $visitorRaw) ? $visitorRaw : '';

$phone = '';
$email = '';
if ($userId > 0) {
    $ur = $conn->query("SELECT phone, email FROM users WHERE user_id = $userId LIMIT 1");
    if ($ur && $urow = $ur->fetch_assoc()) {
        $phone = preg_replace('/\D+/', '', (string)($urow['phone'] ?? ''));
        $email = strtolower(trim((string)($urow['email'] ?? '')));
    }
}

/*
 * identity_key — what "unique" means on this report.
 *
 * A visitor: key is not a person and never pretends to be one. It is the only handle a logged-out
 * tap on a static link leaves behind, and it exists so the unique count can be something other
 * than zero until they sign in. The moment they do, the backfill below replaces it everywhere.
 */
$identity = $phone !== '' ? $phone
          : ($email !== '' ? $email
          : ($visitorKey !== '' ? 'visitor:' . $visitorKey : 'anon:' . substr(md5(
                ($_SERVER['REMOTE_ADDR'] ?? '') . '|' . ($_SERVER['HTTP_USER_AGENT'] ?? '')), 0, 24)));

/*
 * RETROSPECTIVE IDENTIFICATION.
 *
 * The tap that matters most arrives logged out, so it is logged under a visitor: key. When the
 * same browser comes back signed in, those earlier rows are rewritten with the real phone and
 * email — otherwise one person who tapped, signed in, and tapped again would be counted as two:
 * a stranger and a customer.
 *
 * Scoped to this sender and to rows that are still unidentified, so it can never overwrite a
 * different person's row or move a click between senders.
 */
if ($visitorKey !== '' && $identity !== '' && ($phone !== '' || $email !== '')
    && ($campaignId > 0 || $journeyId > 0)) {
    $scope = $owner === 'journey' ? "journey_id = $journeyId" : "campaign_id = $campaignId";
    $conn->query("UPDATE wa_link_clicks
                     SET user_id      = $userId,
                         phone        = " . ($phone !== '' ? "'" . $conn->real_escape_string($phone) . "'" : 'NULL') . ",
                         email        = " . ($email !== '' ? "'" . $conn->real_escape_string($email) . "'" : 'NULL') . ",
                         identity_key = '" . $conn->real_escape_string($identity) . "'
                   WHERE $scope
                     AND visitor_key = '" . $conn->real_escape_string($visitorKey) . "'
                     AND user_id IS NULL");
}

/*
 * THE LOG LINE. Every tap, one row, never merged — see the note above the CREATE TABLE.
 *
 * Skipped for the credit-only call, which is not a tap: it is the same tap being reported a
 * second time now that there is a name to attach to it, and its whole job was the backfill above.
 */
if (!$creditOnly) {
    // Exactly one of campaign_id / journey_id is filled: a tap belongs to one send, and a row
    // carrying both would be counted twice the moment either report reads it.
    $conn->query("INSERT INTO wa_link_clicks
                      (link_id, campaign_id, journey_id, recipient_id, visitor_key, user_id, phone, email,
                       identity_key, ip, user_agent, clicked_at)
                  VALUES (
                      $linkId,
                      " . ($owner === 'campaign' && $campaignId > 0 ? $campaignId : 'NULL') . ",
                      " . ($owner === 'journey'  && $journeyId  > 0 ? $journeyId  : 'NULL') . ",
                      NULL,
                      " . ($visitorKey !== '' ? "'" . $conn->real_escape_string($visitorKey) . "'" : 'NULL') . ",
                      " . ($userId > 0 ? $userId : 'NULL') . ",
                      " . ($phone !== '' ? "'" . $conn->real_escape_string($phone) . "'" : 'NULL') . ",
                      " . ($email !== '' ? "'" . $conn->real_escape_string($email) . "'" : 'NULL') . ",
                      '" . $conn->real_escape_string($identity) . "',
                      '" . $conn->real_escape_string(substr((string)($_SERVER['REMOTE_ADDR'] ?? ''), 0, 45)) . "',
                      '" . $conn->real_escape_string(substr((string)($_SERVER['HTTP_USER_AGENT'] ?? ''), 0, 255)) . "',
                      NOW())");
    $clickRowId = (int)$conn->insert_id;
}

/*
 * Per-person credit, when the visitor is known.
 *
 * A static link is identical for everyone, so the tap by itself is anonymous. But the dashboard
 * knows who is logged in, and this campaign's recipient list is a small set — so one user_id turns
 * an anonymous campaign click back into "this person clicked". Optional on purpose: a logged-out
 * arrival still counts at campaign level and still gets the cookie, and the conversion is
 * attributed later by campaign_attributions exactly as it is for email.
 *
 * first_clicked_at is written ONCE because it anchors the attribution window; letting a later tap
 * move it would quietly extend the window on every revisit.
 */
$clickRowId  = $clickRowId ?? 0;
$recipientId = 0;

/*
 * The journey half of the same idea, and the ONLY way a journey WhatsApp tap is ever credited.
 *
 * A journey has no click counter to increment — journeys.clicked_count is recomputed from
 * journey_messages.first_clicked_at on every worker tick — so the stamp on the message IS the
 * click. It is also the anchor journey_recount_conversions() measures the goal window from, so
 * without this a journey WhatsApp step could never report a conversion, no matter what the
 * student went on to do.
 *
 * Newest message first: a journey can message the same person at several steps, and the tap
 * belongs to the one they were most recently sent.
 *
 * Consequence worth knowing: this needs a user_id, so it only fires on the credit_only call the
 * dashboard makes AFTER sign-in. A tap that never signs in stays anonymous and is countable only
 * in wa_link_clicks. That is inherent to a static link that is byte-identical for every
 * recipient — there is nothing in the tap itself that names anyone.
 */
if ($owner === 'journey' && $journeyId > 0 && $userId > 0) {
    $jm = @$conn->query("SELECT id, first_clicked_at FROM journey_messages
                         WHERE journey_id = $journeyId AND user_id = $userId
                           AND channel = 'whatsapp' AND sent_at IS NOT NULL
                         ORDER BY sent_at DESC LIMIT 1");
    $jrow = $jm ? $jm->fetch_assoc() : null;
    if ($jrow) {
        $jmId = (int)$jrow['id'];
        // Same idempotency rule as the campaign branch: the credit_only call is the SAME tap
        // being named, not a second one, so it may only write while the stamp is still empty.
        @$conn->query("UPDATE journey_messages
                         SET click_count = click_count + 1,
                             first_clicked_at = COALESCE(first_clicked_at, NOW()),
                             opened_at    = COALESCE(opened_at, NOW()),
                             delivered_at = COALESCE(delivered_at, NOW())
                       WHERE id = $jmId"
                       . ($creditOnly ? " AND first_clicked_at IS NULL" : ''));
    }
}

if ($owner === 'campaign' && $campaignId > 0 && $userId > 0) {
    $rr = $conn->query("SELECT id, first_clicked_at FROM wa_campaign_recipients
                         WHERE campaign_id = $campaignId AND user_id = $userId AND is_test = 0
                         LIMIT 1");
    $rec = $rr ? $rr->fetch_assoc() : null;
    if ($rec) {
        $recipientId = (int)$rec['id'];
        $isFirst     = empty($rec['first_clicked_at']);
        /*
         * The WHERE clause is what makes the post-login call idempotent: it writes only while
         * first_clicked_at is still NULL, so being told about the same tap twice — once
         * anonymously, once with a name attached — credits this person exactly once.
         */
        $conn->query("UPDATE wa_campaign_recipients
                         SET click_count = click_count + 1,
                             first_clicked_at = COALESCE(first_clicked_at, NOW())
                       WHERE id = $recipientId"
                       . ($creditOnly ? " AND first_clicked_at IS NULL" : ''));
        // Only the first tap becomes a timeline event; the rest are in the counter already and
        // would otherwise bury every other event in the report.
        if ($isFirst) {
            $conn->query("INSERT INTO wa_campaign_events (campaign_id, recipient_id, event_type, detail)
                          VALUES ($campaignId, $recipientId, 'button_click', 'WhatsApp link tap (link #$linkId)')");
        }
        // Tie the log line to the audience row, so the click log can show which recipient a tap
        // belongs to without re-deriving it from the phone every time it is read.
        if ($clickRowId > 0) {
            $conn->query("UPDATE wa_link_clicks SET recipient_id = $recipientId WHERE id = $clickRowId");
        }
    }
}

/*
 * THE STICKER — what the dashboard turns into the campaign_attr cookie.
 *
 * A journey does NOT hand back the campaign that merely shares this template; that would credit
 * it with a conversion the journey earned. It hands back its own id, moved into the journey range
 * and marked with medium 'journey', so the row it eventually produces in campaign_attributions is
 * unmistakably the journey's and cannot collide with a campaign of the same number.
 *
 * Why a journey wants a cookie at all, when its delivery counts need none: the cookie is the only
 * thing that can tell "this message carried them into the purchase" from "they clicked once, left,
 * and came back on their own two days later". The dashboard deletes it the moment a visitor
 * arrives without one, and that deletion is the whole point.
 *
 * attribution.js reads campaign_id / medium / attr_window generically, so it needs no change and
 * cannot tell a journey from a campaign — which is exactly why this reuses those field names.
 */
$attrCampaignId = $campaignId;
$attrMedium     = 'whatsapp';
if ($owner === 'journey') {
    $sink = __DIR__ . '/../journeys/lib/JourneyWebhookSink.php';
    // Only a journey with a goal gets a sticker. Handing one out otherwise would give the
    // dashboard something to store with nothing to attribute — and, worse, would overwrite an
    // attribution the visitor legitimately arrived with. Matches journeys/track-click.php,
    // which appends its parameters on the same condition.
    if (file_exists($sink) && trim((string)($row['j_goal'] ?? '')) !== '') {
        require_once $sink;
        $attrCampaignId = journey_attr_campaign_id($journeyId);
        $attrMedium     = JOURNEY_ATTR_MEDIUM;
    } else {
        // No goal, or journeys not deployed: hand back nothing rather than the wrong campaign.
        $attrCampaignId = 0;
    }
}

link_out(true, [
    'link_id'      => $linkId,
    'campaign_id'  => $attrCampaignId,
    'journey_id'   => $owner === 'journey' ? $journeyId : 0,
    'owner'        => $owner,
    'medium'       => $attrMedium,
    'attr_window'  => $window,
    'goal'         => $goal,
    'target'       => (string)$row['target_url'],
    'recipient_id' => $recipientId,
], 'ok');

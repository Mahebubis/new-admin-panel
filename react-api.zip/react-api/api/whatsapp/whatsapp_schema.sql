-- WhatsApp Campaigns — schema documentation.
--
-- These statements are created idempotently at runtime by lib/schema.php
-- (whatsapp_ensure_schema()); this file is living documentation, matching the convention
-- used by campaigns/campaigns_schema.sql and internship-system/assignments_schema.sql.
--
-- Deliberately separate from the email builder's email_campaigns/* tables: the two channels
-- share an AUDIENCE (the same netcore_segments and campaign_lists feed both) but nothing
-- else — a WhatsApp send has no subject, no HTML, no bounce, and its delivery lifecycle
-- (accepted → delivered → read) has no email equivalent.

CREATE TABLE IF NOT EXISTS wa_campaigns (
    id                  INT AUTO_INCREMENT PRIMARY KEY,
    name                VARCHAR(255) NOT NULL,
    tags                VARCHAR(500) DEFAULT NULL,
    status              ENUM('draft','scheduled','running','sent','suspended','failed') NOT NULL DEFAULT 'draft',
    channel             ENUM('whatsapp') NOT NULL DEFAULT 'whatsapp',

    ga_source VARCHAR(255) DEFAULT NULL, ga_medium VARCHAR(255) DEFAULT NULL, ga_campaign VARCHAR(255) DEFAULT NULL,
    ga_content VARCHAR(255) DEFAULT NULL, ga_term VARCHAR(255) DEFAULT NULL,

    audience_type       ENUM('all_contacts','segments') NOT NULL DEFAULT 'segments',
    segment_ids         JSON DEFAULT NULL,
    exclude_segment_ids JSON DEFAULT NULL,
    list_ids            JSON DEFAULT NULL,
    reachable_count     INT NOT NULL DEFAULT 0,

    -- Deduplication. Within one campaign duplicates are collapsed unconditionally by
    -- wa_campaign_recipients.uq_campaign_phone; these columns are the OPTIONAL
    -- cross-campaign window layered on top.
    dedup_enabled       TINYINT(1) NOT NULL DEFAULT 0,
    dedup_window_hours  INT NOT NULL DEFAULT 24,
    dedup_scope         ENUM('all_campaigns','same_template') NOT NULL DEFAULT 'all_campaigns',
    skipped_dedup_count INT NOT NULL DEFAULT 0,

    message_type      ENUM('template','text') NOT NULL DEFAULT 'template',
    template_id       INT DEFAULT NULL,
    template_name     VARCHAR(255) DEFAULT NULL,
    template_language VARCHAR(16) DEFAULT 'en',
    template_category VARCHAR(32) DEFAULT NULL,
    header_type       ENUM('none','text','image','video','document') NOT NULL DEFAULT 'none',
    header_text       VARCHAR(500) DEFAULT NULL,
    header_media_url  VARCHAR(1000) DEFAULT NULL,
    body_text         TEXT DEFAULT NULL,
    footer_text       VARCHAR(255) DEFAULT NULL,
    buttons           JSON DEFAULT NULL,
    variables         JSON DEFAULT NULL,
    text_content      TEXT DEFAULT NULL,
    preview_url       TINYINT(1) NOT NULL DEFAULT 1,

    -- Sending identity, snapshotted from wa_senders when the campaign is sent/scheduled.
    source_id       VARCHAR(100) DEFAULT NULL,
    business_number VARCHAR(32) DEFAULT NULL,
    sender_id       INT DEFAULT NULL,
    waba_id         VARCHAR(64) DEFAULT NULL,

    schedule_type   ENUM('now','later') NOT NULL DEFAULT 'now',
    scheduled_at    DATETIME DEFAULT NULL,
    contact_limit_enabled TINYINT(1) NOT NULL DEFAULT 0,
    contact_limit   INT DEFAULT NULL,
    retry_enabled   TINYINT(1) NOT NULL DEFAULT 1,

    total_recipients INT NOT NULL DEFAULT 0,
    sent_count INT NOT NULL DEFAULT 0, delivered_count INT NOT NULL DEFAULT 0,
    read_count INT NOT NULL DEFAULT 0, failed_count INT NOT NULL DEFAULT 0,
    click_count INT NOT NULL DEFAULT 0, reply_count INT NOT NULL DEFAULT 0,

    created_by  BIGINT UNSIGNED DEFAULT NULL,
    created_at  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    started_at DATETIME DEFAULT NULL, completed_at DATETIME DEFAULT NULL, materialized_at DATETIME DEFAULT NULL,

    INDEX idx_status_scheduled (status, scheduled_at),
    INDEX idx_created_at (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- uq_campaign_phone is the deduplication guarantee: the materializer uses INSERT IGNORE, so
-- a number reachable through several selected segments/lists collapses to exactly one row.
CREATE TABLE IF NOT EXISTS wa_campaign_recipients (
    id            BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    campaign_id   INT NOT NULL,
    user_id       BIGINT UNSIGNED DEFAULT NULL,
    phone         VARCHAR(24) NOT NULL,
    raw_phone     VARCHAR(32) DEFAULT NULL,
    email         VARCHAR(255) DEFAULT NULL,
    first_name    VARCHAR(255) DEFAULT NULL, last_name VARCHAR(255) DEFAULT NULL,
    is_test       TINYINT(1) NOT NULL DEFAULT 0,
    status        ENUM('pending','processing','sent','delivered','read','failed','skipped') NOT NULL DEFAULT 'pending',
    skip_reason   VARCHAR(190) DEFAULT NULL,
    rid           CHAR(32) NOT NULL,
    attempts      TINYINT UNSIGNED NOT NULL DEFAULT 0,
    error_code    VARCHAR(64) DEFAULT NULL,
    error_message VARCHAR(500) DEFAULT NULL,
    wa_message_id VARCHAR(120) DEFAULT NULL,
    rendered_body TEXT DEFAULT NULL,
    queued_at     TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    sent_at DATETIME DEFAULT NULL, delivered_at DATETIME DEFAULT NULL,
    read_at DATETIME DEFAULT NULL, failed_at DATETIME DEFAULT NULL,
    click_count INT NOT NULL DEFAULT 0,

    UNIQUE INDEX uq_rid (rid),
    UNIQUE INDEX uq_campaign_phone (campaign_id, is_test, phone),
    INDEX idx_campaign_status (campaign_id, status),
    INDEX idx_wa_message_id (wa_message_id),
    INDEX idx_phone_sent (phone, sent_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS wa_campaign_events (
    id           BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    campaign_id  INT NOT NULL,
    recipient_id BIGINT UNSIGNED NOT NULL,
    event_type   ENUM('sent','delivered','read','failed','button_click','replied') NOT NULL,
    error_code   VARCHAR(64) DEFAULT NULL,
    detail       VARCHAR(500) DEFAULT NULL,
    meta         JSON DEFAULT NULL,
    created_at   TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_campaign_type (campaign_id, event_type),
    INDEX idx_recipient (recipient_id),
    INDEX idx_created_at (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS wa_templates (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    name            VARCHAR(255) NOT NULL,
    display_name    VARCHAR(255) DEFAULT NULL,
    category        ENUM('marketing','utility','authentication') NOT NULL DEFAULT 'utility',
    language        VARCHAR(16) NOT NULL DEFAULT 'en',
    header_type     ENUM('none','text','image','video','document') NOT NULL DEFAULT 'none',
    header_text     VARCHAR(500) DEFAULT NULL,
    header_media_url VARCHAR(1000) DEFAULT NULL,
    body_text       TEXT NOT NULL,
    footer_text     VARCHAR(255) DEFAULT NULL,
    buttons         JSON DEFAULT NULL,
    variable_labels JSON DEFAULT NULL,
    sample_values   JSON DEFAULT NULL,
    approval_status ENUM('approved','pending','rejected','unknown') NOT NULL DEFAULT 'pending',
    status          ENUM('active','archived') NOT NULL DEFAULT 'active',
    created_by      BIGINT UNSIGNED DEFAULT NULL,
    created_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE INDEX uq_name_lang (name, language),
    INDEX idx_status (status, category)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Account-level credentials ONLY (one row, one API key). source_id/waba_id/business_number/
-- business_name are legacy columns from the first build, which assumed a single sending
-- number; they survive only so whatsapp_ensure_schema() can lift their values into wa_senders.
CREATE TABLE IF NOT EXISTS wa_settings (
    id                   INT AUTO_INCREMENT PRIMARY KEY,
    provider             VARCHAR(32) NOT NULL DEFAULT 'netcore',
    is_active            TINYINT(1) NOT NULL DEFAULT 1,
    api_key              TEXT DEFAULT NULL,
    api_base_url         VARCHAR(500) DEFAULT NULL,
    source_id            VARCHAR(100) DEFAULT NULL,
    waba_id              VARCHAR(64) DEFAULT NULL,
    business_number      VARCHAR(32) DEFAULT NULL,
    business_name        VARCHAR(255) DEFAULT NULL,
    default_country_code VARCHAR(6) NOT NULL DEFAULT '91',
    webhook_secret       VARCHAR(255) DEFAULT NULL,
    updated_at           TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE INDEX uq_provider (provider)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- One row per sending number. A WABA (the account) owns several business numbers, and each
-- number has its OWN API key (Netcore panel → Business number → Edit → Integrate API). That
-- per-number key is what makes a message go out from that number. waba_id groups numbers for
-- the picker and is never sent; source_id is optional and only routes delivery receipts to a
-- webhook whose "Source key / callbackData" matches.
CREATE TABLE IF NOT EXISTS wa_senders (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    waba_id         VARCHAR(64) NOT NULL,
    waba_name       VARCHAR(255) DEFAULT NULL,
    business_number VARCHAR(32) NOT NULL,
    display_name    VARCHAR(255) DEFAULT NULL,
    api_key         TEXT DEFAULT NULL,
    source_id       VARCHAR(100) DEFAULT NULL,
    quality_rating  VARCHAR(32) DEFAULT NULL,
    messaging_limit VARCHAR(64) DEFAULT NULL,
    is_default      TINYINT(1) NOT NULL DEFAULT 0,
    is_active       TINYINT(1) NOT NULL DEFAULT 1,
    notes           VARCHAR(500) DEFAULT NULL,
    created_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE INDEX uq_number (business_number),
    INDEX idx_waba (waba_id, is_active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS wa_optins (
    id         BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    phone      VARCHAR(24) NOT NULL,
    status     ENUM('optin','optout') NOT NULL DEFAULT 'optin',
    source     VARCHAR(32) DEFAULT 'WEB',
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE INDEX uq_phone (phone)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT IGNORE INTO wa_settings (provider, is_active, api_key, api_base_url, default_country_code)
VALUES ('netcore', 1, '', 'https://waapi.pepipost.com/api/v2/', '91');

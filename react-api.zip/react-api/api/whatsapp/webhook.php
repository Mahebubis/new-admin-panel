<?php
/*
 * /api/whatsapp/webhook.php — inbound delivery-status receiver.
 *
 * This is the ONLY thing that can move a campaign's delivered / read / clicked numbers. The
 * send API answering 200 means "accepted for delivery", nothing more — a message can be
 * accepted and then silently dropped (unapproved template, number never opted in), so
 * treating an accept as a delivery would report a campaign as fully delivered while nobody
 * received anything. Until this URL is registered in the Netcore panel, Delivered/Read stay
 * at 0 by design and the report says so rather than inventing numbers.
 *
 * Register as:  https://cit3.internshipstudio.com/admin/react-api/api/whatsapp/webhook.php
 * in the Netcore panel under Business number → Edit → Webhook Integration. The SAME URL can be
 * registered on several tabs and this file handles each:
 *   Event    → delivered / read / failed / button click   (required for any reporting)
 *   Incoming → replies, including "STOP" as an opt-out    (recommended)
 *   Consent  → opt-in / opt-out / blocklist changes       (recommended — feeds suppression)
 *   Template → Meta approval decisions                    (optional — keeps badges honest)
 *
 * The optional "Source key or ID" on that form is worth setting: without it the webhook
 * receives events for EVERY message on that business number, including traffic from other
 * systems sharing it. Events we can't match to a recipient are ignored, but scoping by source
 * key keeps the volume (and the log) to this panel's own sends.
 *
 * Payload shapes differ between provider versions, so parsing is deliberately tolerant: the
 * handler walks the JSON for anything carrying a message id + status and correlates it back
 * through wa_message_id (the provider's own id) or x-apiheader (our rid, echoed verbatim).
 */
ini_set('display_errors', 0);
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/lib/config.php';
require_once __DIR__ . '/lib/schema.php';
require_once __DIR__ . '/lib/WaSendWorker.php';
require_once __DIR__ . '/lib/WaInbox.php';

whatsapp_ensure_schema();
wa_inbox_ensure_schema();

/*
 * Meta's webhook verification handshake. When you register this URL on a Meta app, Meta first
 * sends GET ?hub.mode=subscribe&hub.verify_token=…&hub.challenge=… and expects the challenge
 * echoed back as plain text. Fail this and the subscription is never created — so it runs
 * before anything else, and before the POST body is read.
 *
 * The verify token is the same "webhook secret" field in Settings, so there's one value to
 * manage rather than two.
 */
if (($_SERVER['REQUEST_METHOD'] ?? '') === 'GET' && isset($_GET['hub_mode'], $_GET['hub_challenge'])
    || isset($_GET['hub.mode'], $_GET['hub.challenge'])) {
    // PHP rewrites dots in query keys to underscores, so both spellings are accepted.
    $mode      = $_GET['hub.mode']         ?? ($_GET['hub_mode'] ?? '');
    $challenge = $_GET['hub.challenge']    ?? ($_GET['hub_challenge'] ?? '');
    $token     = $_GET['hub.verify_token'] ?? ($_GET['hub_verify_token'] ?? '');

    $expected = trim((string)(wa_settings_row()['webhook_secret'] ?? ''));
    // With no secret configured yet, the handshake is allowed through — otherwise you could
    // never complete the first registration.
    if ($mode === 'subscribe' && ($expected === '' || hash_equals($expected, (string)$token))) {
        wa_log('webhook: Meta verification handshake accepted');
        http_response_code(200);
        header('Content-Type: text/plain');
        echo $challenge;
        exit;
    }
    wa_log('webhook: Meta verification REJECTED — verify token did not match the webhook secret');
    http_response_code(403);
    echo 'forbidden';
    exit;
}

// Always 200 — a webhook that answers anything else gets retried, then disabled, by most
// providers. Parsing problems are logged instead.
http_response_code(200);

$raw = file_get_contents('php://input');
if ($raw === '' || $raw === false) { echo 'ok'; exit; }

$settings = wa_settings_row() ?: [];

/*
 * Authenticating a webhook POST.
 *
 * Meta does NOT echo a shared secret back on delivery. It signs the RAW request body:
 *
 *     X-Hub-Signature-256: sha256=<hmac_sha256(raw_body, APP SECRET)>
 *
 * The App Secret is a different value from the Verify token — the verify token is used once, for
 * the GET handshake above, and never again.
 *
 * Netcore authenticates completely differently: it signs nothing and instead calls back whatever
 * URL you registered, so the shared secret has to travel on the query string.
 *
 * Policy, per caller rather than per configured credential:
 *   signed + app secret set  → the signature MUST verify (a forged status could mark a campaign
 *                              delivered, or inject a message into someone's inbox)
 *   unsigned + secret set    → ?secret= must match the webhook secret
 *   nothing configured       → accept, logged once a day rather than once a call
 *
 * hash_equals throughout: a timing-safe comparison is the entire point of a shared secret.
 */
$appSecret   = trim((string)($settings['meta_app_secret'] ?? ''));
$verifyToken = trim((string)($settings['webhook_secret'] ?? ''));
$sig         = (string)($_SERVER['HTTP_X_HUB_SIGNATURE_256'] ?? '');
$manual      = (string)($_GET['secret'] ?? ($_SERVER['HTTP_X_WEBHOOK_SECRET'] ?? ''));

/*
 * ONE endpoint, TWO senders — and they can prove who they are in different ways.
 *
 *   Meta     signs the raw body with the app secret and sends X-Hub-Signature-256.
 *   Netcore  does no such thing. It has never heard of the app secret, so demanding a signature
 *            from it silently rejects every delivery receipt it sends.
 *
 * The check therefore keys off which mechanism the caller actually used, rather than off which
 * credential we happen to have configured. That distinction is not cosmetic: enforcing Meta's
 * signature globally is exactly what made campaigns sent through Netcore report 0 delivered
 * while the log filled with rejections.
 *
 * Netcore's proof is the shared secret on the query string, which is why its callback URL must
 * be registered as  …/webhook.php?secret=<the webhook secret>.
 */
if ($sig !== '' && $appSecret !== '') {
    // Signed: this is Meta, and the signature must be right.
    if (!hash_equals('sha256=' . hash_hmac('sha256', $raw, $appSecret), $sig)) {
        wa_log('webhook: rejected — X-Hub-Signature-256 did not match the app secret');
        echo 'ok';
        exit;
    }
} elseif ($verifyToken !== '') {
    // Unsigned: the only other caller we accept is one carrying the shared secret.
    if (!hash_equals($verifyToken, $manual)) {
        wa_log('webhook: rejected an unsigned call with a bad/missing ?secret= '
            . '(Netcore callbacks must be registered as …/webhook.php?secret=<your webhook secret>)');
        echo 'ok';
        exit;
    }
} else {
    // Rate-limited to one line a day: this used to be logged per call, which buried every other
    // line in the file under thousands of identical warnings.
    static $warned = false;
    $stamp = __DIR__ . '/.webhook-unsigned-warned';
    if (!$warned && (!file_exists($stamp) || filemtime($stamp) < time() - 86400)) {
        wa_log('webhook: accepting UNSIGNED callbacks — set the Meta app secret in Settings to verify X-Hub-Signature-256');
        @touch($stamp);
        $warned = true;
    }
}

$payload = json_decode($raw, true);
if (!is_array($payload)) {
    wa_log('webhook: unparseable body — ' . substr($raw, 0, 400));
    echo 'ok';
    exit;
}

/** Collects every {id, status} pair anywhere in the payload. */
function wa_collect_statuses(array $node, array &$out): void {
    $idKeys     = ['message_id', 'messageId', 'id', 'wamid', 'mid'];
    $statusKeys = ['status', 'event', 'event_type', 'state'];

    $id = null; $status = null; $rid = null; $reason = null; $code = null;
    foreach ($idKeys as $k) {
        if (isset($node[$k]) && (is_string($node[$k]) || is_numeric($node[$k]))) { $id = (string)$node[$k]; break; }
    }
    /*
     * Meta's Cloud API shape: entry[].changes[].value.statuses[] = {id: "wamid…", status:
     * "sent|delivered|read|failed", errors: [{code, title, error_data:{details}}]}. The id and
     * status keys already match the loops above; only the nested error array needs pulling out,
     * otherwise a Meta failure would arrive with no reason attached.
     */
    if (isset($node['errors'][0]) && is_array($node['errors'][0])) {
        $e = $node['errors'][0];
        $reason = $e['error_data']['details'] ?? ($e['title'] ?? ($e['message'] ?? null));
        if (isset($e['code'])) $code = (string)$e['code'];
    }
    foreach ($statusKeys as $k) {
        if (isset($node[$k]) && is_string($node[$k])) { $status = strtolower($node[$k]); break; }
    }
    foreach (['x-apiheader', 'x_apiheader', 'apiheader', 'custom_id'] as $k) {
        if (isset($node[$k]) && is_string($node[$k])) { $rid = $node[$k]; break; }
    }
    // Guarded on being unset: Meta's nested errors[] was already read above and is more
    // specific than any flat key, so it must not be overwritten here.
    if ($reason === null) {
        /*
         * Widened well past Meta's own vocabulary because a BSP wraps the rejection in its own
         * envelope, and the reason is the single most useful field on a failure — "Reported
         * failed by WhatsApp" tells an admin nothing they can act on. Netcore in particular
         * nests it under error{}/errors[] with `title`/`details` rather than a flat key.
         */
        foreach (['status_remark', 'reason', 'error_message', 'description', 'detail', 'details',
                  'error_desc', 'errorMessage', 'failure_reason', 'title', 'message'] as $k) {
            if (isset($node[$k]) && is_string($node[$k]) && trim($node[$k]) !== '') { $reason = $node[$k]; break; }
        }
    }
    if ($reason === null && isset($node['error']) && is_array($node['error'])) {
        $e = $node['error'];
        $reason = $e['error_data']['details'] ?? ($e['details'] ?? ($e['title'] ?? ($e['message'] ?? null)));
        if ($code === null && isset($e['code'])) $code = (string)$e['code'];
    }
    if ($code === null) {
        foreach (['error_code', 'code', 'errorCode'] as $k) {
            if (isset($node[$k]) && (is_string($node[$k]) || is_numeric($node[$k]))) { $code = (string)$node[$k]; break; }
        }
    }

    /*
     * The recipient's number, pulled out alongside the id because with Netcore it is the ONLY
     * thing linking an event to a recipient. Their send response returns a per-REQUEST uuid
     * ({"data":{"id":"6aafb690-…"}}), their webhooks report Meta wamids, and they do not echo the
     * x-apiheader we send — so no identifier we hold at send time ever appears again.
     */
    $phone = null;
    foreach (['recipient_whatsapp', 'mobile', 'msisdn', 'mobile_number', 'phone', 'wa_id', 'recipient', 'to'] as $k) {
        if (isset($node[$k]) && (is_string($node[$k]) || is_numeric($node[$k]))) { $phone = (string)$node[$k]; break; }
    }

    if ($status !== null && ($id !== null || $rid !== null)) {
        $out[] = ['id' => $id, 'rid' => $rid, 'phone' => $phone, 'status' => $status, 'reason' => $reason, 'code' => $code];
        // Stop here rather than also walking this node's children: a node carrying both an id
        // and a status IS the message record, and descending into it would collect the same
        // event a second time — which would double-count clicks and replies (delivered/read
        // are protected by the forward-only rank check below, those two are not).
        return;
    }
    foreach ($node as $child) {
        if (is_array($child)) wa_collect_statuses($child, $out);
    }
}

/**
 * The recipient's number, read out of a Meta wamid.
 *
 * A wamid is base64 after the "wamid." prefix, and the decoded bytes begin with a short header
 * followed by the recipient's number as plain ASCII digits:
 *
 *   wamid.HBgMOTE5NzY3Njk0NDE0FQIA…  →  \x1c\x18\x0c 919767694414 …
 *
 * Used ONLY as a fallback, when the payload carries no phone field of its own — Netcore's event
 * webhook is the case that needs it. It is a heuristic on an undocumented encoding, so nothing is
 * trusted on its say-so: whatever comes out is looked up against recipients WE actually messaged
 * recently, and a wrong guess simply finds no row rather than mis-crediting one.
 */
function wa_phone_from_wamid(?string $wamid): ?string {
    if ($wamid === null || strpos($wamid, 'wamid.') !== 0) return null;
    $b64 = substr($wamid, 6);
    // wamids use standard base64 but are sometimes passed through URL-safe encoders.
    $decoded = base64_decode(strtr($b64, '-_', '+/'), false);
    if ($decoded === false || $decoded === '') return null;
    return preg_match('/(\d{10,15})/', $decoded, $m) ? $m[1] : null;
}

/*
 * The same endpoint is registered on the panel's Consent tab as well as its Event tab, because
 * an opt-out made anywhere — the Netcore UI, a STOP reply, another system on the same number —
 * has to reach our suppression list or the next campaign will message that person again.
 *
 * Consent payloads carry a phone number and an optin/optout state but no message id, so they
 * never match the status collector above and need their own pass.
 */
function wa_apply_consent_events(array $node, int &$applied): void {
    $phone = null; $state = null;
    foreach (['mobile', 'recipient', 'recipient_whatsapp', 'phone', 'mobile_number', 'msisdn'] as $k) {
        if (isset($node[$k]) && (is_string($node[$k]) || is_numeric($node[$k]))) { $phone = (string)$node[$k]; break; }
    }
    foreach (['type', 'status', 'consent', 'consent_status', 'event'] as $k) {
        if (isset($node[$k]) && is_string($node[$k])) {
            $v = strtolower(trim($node[$k]));
            if (in_array($v, ['optin', 'opt-in', 'opt_in', 'optout', 'opt-out', 'opt_out', 'blocklist', 'blocked'], true)) {
                $state = $v; break;
            }
        }
    }

    if ($phone !== null && $state !== null) {
        $normalized = wa_normalize_phone($phone, wa_default_cc());
        if ($normalized !== null) {
            // Blocklisted is treated as opted out: either way we must not message them.
            $isOut = strpos($state, 'out') !== false || strpos($state, 'block') !== false;
            wa_record_optin($normalized, $isOut ? 'optout' : 'optin', 'WEBHOOK');
            $applied++;
            wa_log("webhook: consent $state for $normalized");
        }
        return;
    }
    foreach ($node as $child) {
        if (is_array($child)) wa_apply_consent_events($child, $applied);
    }
}

/*
 * Registered on the Template tab too: Meta's approval decisions arrive here, and an approval
 * badge that silently goes stale is worse than none — the wizard uses it to warn before a send.
 * Only ever updates a template we already know about, so an unrelated payload can't create rows.
 */
function wa_apply_template_events(array $node, int &$applied): void {
    global $conn;
    $name = null; $status = null;
    foreach (['template_name', 'templateName', 'name'] as $k) {
        if (isset($node[$k]) && is_string($node[$k]) && preg_match('/^[a-z0-9_]+$/', $node[$k])) { $name = $node[$k]; break; }
    }
    foreach (['status', 'event', 'template_status'] as $k) {
        if (isset($node[$k]) && is_string($node[$k])) {
            $v = strtolower(trim($node[$k]));
            if (in_array($v, ['approved', 'rejected', 'pending', 'paused', 'disabled'], true)) { $status = $v; break; }
        }
    }

    if ($name !== null && $status !== null) {
        // 'paused'/'disabled' are not deliverable, so they map to the same warning state as a
        // rejection rather than being dropped on the floor.
        $mapped = $status === 'approved' ? 'approved' : ($status === 'pending' ? 'pending' : 'rejected');
        $conn->query("UPDATE wa_templates SET approval_status='" . $conn->real_escape_string($mapped) . "'
                       WHERE name='" . $conn->real_escape_string($name) . "'");
        if ($conn->affected_rows > 0) {
            $applied++;
            wa_log("webhook: template $name -> $mapped");
        }
        return;
    }
    foreach ($node as $child) {
        if (is_array($child)) wa_apply_template_events($child, $applied);
    }
}

$consentApplied = 0;
wa_apply_consent_events($payload, $consentApplied);
$templateApplied = 0;
wa_apply_template_events($payload, $templateApplied);

/*
 * Live Chat ingestion — inbound replies, and delivery statuses for replies WE sent from the
 * inbox. Runs before the campaign correlation below and cannot collide with it: it reads only
 * Meta's documented entry[].changes[].value shape and writes only to wa_conversations /
 * wa_messages, while the pass below writes only to wa_campaign_recipients.
 *
 * Wrapped because a malformed inbound payload must never cost us the delivery statuses in the
 * same request — those are what keep the campaign reports honest.
 */
$inbox = ['messages' => 0, 'statuses' => 0, 'clicks' => 0, 'click_events' => 0];
try {
    $inbox = array_merge($inbox, wa_ingest_webhook($payload));
} catch (\Throwable $e) {
    wa_log('webhook: inbox ingestion failed — ' . $e->getMessage());
}

$events = [];
wa_collect_statuses($payload, $events);
if (!$events) {
    // click_events, not clicks: a link tap we recognized but chose not to credit (another app's
    // traffic on this WABA) is still a understood payload and must not be dumped as unknown.
    if ($consentApplied === 0 && $templateApplied === 0 && $inbox['messages'] === 0
        && $inbox['statuses'] === 0 && $inbox['click_events'] === 0) {
        wa_log('webhook: no recognizable events in payload — ' . substr($raw, 0, 400));
    }
    echo 'ok';
    exit;
}

// Provider vocabulary → our recipient statuses. Anything unrecognized is logged, not guessed.
$MAP = [
    'sent' => 'sent', 'accepted' => 'sent', 'submitted' => 'sent',
    'delivered' => 'delivered', 'delivery' => 'delivered',
    'read' => 'read', 'seen' => 'read',
    'failed' => 'failed', 'undelivered' => 'failed', 'rejected' => 'failed', 'error' => 'failed',
    'click' => 'button_click', 'button_click' => 'button_click', 'clicked' => 'button_click',
    'reply' => 'replied', 'replied' => 'replied', 'inbound' => 'replied',
];

/*
 * The Journey engine's half of this endpoint, loaded only if it is actually on disk.
 *
 * This backend deploys folder by folder, so whatsapp/ can be newer than journeys/. A bare
 * require of a file that has not been uploaded yet is a FATAL — which would silently stop
 * every campaign delivery receipt below, turning a missing journeys feature into a broken
 * WhatsApp report. Missing sink = journeys get no counts, campaigns are untouched.
 */
function journey_sink_ready(): bool {
    static $ready = null;
    if ($ready !== null) return $ready;
    $sink = __DIR__ . '/../journeys/lib/JourneyWebhookSink.php';
    if (!file_exists($sink)) {
        wa_log('webhook: journeys/lib/JourneyWebhookSink.php is not deployed — '
             . 'journey WhatsApp messages will stay at "sent" with no delivered/read');
        return $ready = false;
    }
    require_once $sink;
    return $ready = function_exists('journey_webhook_wa_event');
}

$applied = 0;
foreach ($events as $ev) {
    $mapped = $MAP[$ev['status']] ?? null;
    if ($mapped === null) { wa_log("webhook: ignoring unknown status \"{$ev['status']}\""); continue; }

    $where = [];
    if (!empty($ev['id']))  $where[] = "wa_message_id='" . $conn->real_escape_string($ev['id']) . "'";
    if (!empty($ev['rid'])) $where[] = "rid='" . $conn->real_escape_string($ev['rid']) . "'";

    $rec = null;
    if ($where) {
        $r = $conn->query("SELECT id, campaign_id, status FROM wa_campaign_recipients
                            WHERE " . implode(' OR ', $where) . ' LIMIT 1');
        $rec = $r ? $r->fetch_assoc() : null;
    }

    /*
     * PHONE FALLBACK — what makes delivery tracking work on the Netcore route.
     *
     * Meta hands back the wamid at send time, so its receipts match on id and never reach this.
     * Netcore shares no identifier with us at all: its send response carries a per-request uuid,
     * its webhooks carry Meta wamids, and it does not echo our x-apiheader. The recipient's number
     * is the only thing present on both sides.
     *
     * Scoped tightly so it can only ever credit the right row:
     *   - our campaigns only, non-test, actually sent
     *   - within 7 days, newest first — well past any real delivery delay, and short enough that
     *     a receipt can't attach to a months-old campaign to the same person
     *
     * On the first match the event's id is written onto the row, so every LATER status for that
     * message (delivered, then read) matches by id on the fast path above and this runs once per
     * message rather than once per event.
     */
    if (!$rec) {
        $phone = $ev['phone'] ?? null;
        if ($phone === null) $phone = wa_phone_from_wamid($ev['id'] ?? null);
        $normalized = $phone !== null ? wa_normalize_phone($phone, wa_default_cc()) : null;

        if ($normalized !== null) {
            $pr = $conn->query("SELECT id, campaign_id, status, sent_at FROM wa_campaign_recipients
                                 WHERE phone='" . $conn->real_escape_string($normalized) . "'
                                   AND is_test = 0
                                   AND sent_at IS NOT NULL
                                   AND sent_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)
                                 ORDER BY sent_at DESC LIMIT 1");
            $rec = $pr ? $pr->fetch_assoc() : null;

            /*
             * The Journey engine sends to the same numbers over the same WABA, and this
             * phone fallback reaches back 7 days — so a campaign a student was in last
             * week will happily claim a receipt that belongs to a journey message sent
             * two minutes ago. Whichever actually sent LAST is the right owner.
             */
            $jSentAt = journey_sink_ready() ? journey_webhook_wa_last_sent($normalized) : null;
            if ($jSentAt !== null && (!$rec || strtotime($jSentAt) > strtotime((string)$rec['sent_at']))) {
                if (journey_webhook_wa_event($mapped, $ev['id'] ?? null, $ev['rid'] ?? null, $normalized,
                                             $ev['reason'] ?? null, $ev['code'] ?? null)) {
                    wa_log('webhook: applied to a JOURNEY message for ' . $normalized . ' (status=' . $ev['status'] . ')');
                    $applied++;
                    continue;
                }
            }

            if ($rec && !empty($ev['id'])) {
                $conn->query("UPDATE wa_campaign_recipients
                                 SET wa_message_id='" . $conn->real_escape_string($ev['id']) . "'
                               WHERE id=" . (int)$rec['id'] . " AND (wa_message_id IS NULL OR wa_message_id = rid)");
            }
        }
    }

    /*
     * "received, 0 applied" on its own is unfalsifiable — it means either "someone else's traffic
     * on a shared WABA" (expected, ignore it) or "our own message whose id we stored differently"
     * (a real correlation bug). Those need telling apart, so the first unmatched event per request
     * prints the identifiers it looked for. Compare against:
     *
     *   SELECT wa_message_id, rid FROM wa_campaign_recipients WHERE campaign_id = N;
     *
     * One line per request, not per event: this endpoint is called several times a second.
     */
    if (!$rec) {
        /*
         * No campaign recipient — try the Journey engine before writing it off. Journey
         * sends live in journey_messages with their own rid and provider_message_id, and
         * this WABA's webhook is the only callback either feature gets. Without this
         * hand-off every journey WhatsApp stayed at "sent" with no delivered or read.
         *
         * The sink repeats the same phone fallback used above, for the same reason: on
         * the Netcore route the recipient's number is the only identifier both sides share.
         */
        $jPhone = $ev['phone'] ?? wa_phone_from_wamid($ev['id'] ?? null);
        $jPhone = $jPhone !== null ? wa_normalize_phone($jPhone, wa_default_cc()) : null;
        if (journey_sink_ready()
            && journey_webhook_wa_event($mapped, $ev['id'] ?? null, $ev['rid'] ?? null, $jPhone,
                                        $ev['reason'] ?? null, $ev['code'] ?? null)) {
            wa_log('webhook: applied to a JOURNEY message (status=' . $ev['status']
                 . ', phone=' . ($jPhone ?? 'unknown') . ')');
            $applied++;
            continue;
        }

        static $loggedUnmatched = false;
        if (!$loggedUnmatched) {
            $loggedUnmatched = true;
            /*
             * The recipient's number is printed too, and it is the field that makes this line
             * worth reading. This WABA's callback receives events for every app subscribed to
             * it, so an unmatched event is USUALLY somebody else's traffic and entirely
             * expected — but it looks identical to our own message whose id we stored wrongly.
             * Without the number there is no way to tell those apart from the log, and a page
             * of "no recipient matches this event" is equally consistent with "all fine" and
             * "delivery tracking is broken".
             *
             * With it: recognise the number and it is ours, so the correlation is at fault;
             * don't, and it is another app's and there is nothing to fix.
             */
            $logPhone = $ev['phone'] ?? wa_phone_from_wamid($ev['id'] ?? null);
            $logPhone = $logPhone !== null ? wa_normalize_phone($logPhone, wa_default_cc()) : null;
            wa_log('webhook: no recipient matches this event — status=' . $ev['status']
                . ' to=' . ($logPhone ?? 'unknown')
                . ' id=' . ($ev['id']  !== null ? substr($ev['id'], 0, 60)  : 'none')
                . ' rid=' . ($ev['rid'] !== null ? substr($ev['rid'], 0, 40) : 'none'));
        }
        continue;
    }

    $recId = (int)$rec['id'];
    $cid   = (int)$rec['campaign_id'];

    /*
     * Status only ever moves FORWARD along sent → delivered → read. WhatsApp does not
     * guarantee webhook ordering, and a late-arriving "delivered" must not overwrite a "read"
     * that already landed — otherwise the read count silently decays over the life of a
     * campaign. Rank comparison, not blind assignment.
     */
    $rank = ['pending' => 0, 'processing' => 1, 'sent' => 2, 'delivered' => 3, 'read' => 4];
    $current = $rec['status'];

    if (in_array($mapped, ['delivered', 'read'], true)) {
        if (($rank[$mapped] ?? 0) > ($rank[$current] ?? 0)) {
            $col = $mapped === 'read' ? 'read_at' : 'delivered_at';
            $conn->query("UPDATE wa_campaign_recipients SET status='$mapped', $col=NOW() WHERE id=$recId");
            $counter = $mapped === 'read' ? 'read_count' : 'delivered_count';
            $conn->query("UPDATE wa_campaigns SET $counter = $counter + 1 WHERE id=$cid");
            wa_record_event($cid, $recId, $mapped);
            $applied++;
        }
    } elseif ($mapped === 'failed') {
        /*
         * A failure with no reason attached is the least useful row in the whole system — the
         * report can only say "Reported failed by WhatsApp", which names the messenger and not
         * the problem. When that happens the raw payload is logged ONCE per request so the
         * provider's actual field names can be added to the search above, rather than guessed at.
         */
        static $loggedFailure = false;
        if (!$loggedFailure) {
            $loggedFailure = true;
            $ev['reason'] === null
                // No reason at all: dump the payload so the provider's field name can be added.
                ? wa_log('webhook: a FAILED status carried no reason — raw payload: '
                    . mb_substr(preg_replace('/\s+/', ' ', $raw), 0, 700))
                /*
                 * A reason we DID understand still belongs in the log, not only on the recipient
                 * row. A rejection is the single most actionable line this file ever writes, and
                 * burying it in the database means the first question after every failed campaign
                 * is "why", answered only by someone willing to write SQL.
                 */
                : wa_log('webhook: REJECTED ' . ($ev['phone'] ?? 'a recipient')
                    . ' — ' . ($ev['code'] !== null ? $ev['code'] . ': ' : '')
                    . mb_substr((string)$ev['reason'], 0, 300));
        }

        // A failure reported after acceptance is the real outcome, so it always wins.
        if ($current !== 'failed') {
            $err = $conn->real_escape_string(substr((string)($ev['reason'] ?? 'Reported failed by WhatsApp'), 0, 480));
            $code = $conn->real_escape_string(substr((string)($ev['code'] ?? ''), 0, 60));
            $conn->query("UPDATE wa_campaign_recipients SET status='failed', failed_at=NOW(),
                                 error_message='$err', error_code='$code' WHERE id=$recId");
            $conn->query("UPDATE wa_campaigns SET failed_count = failed_count + 1 WHERE id=$cid");
            wa_record_event($cid, $recId, 'failed', $ev['code'] ?? null, $ev['reason'] ?? null);
            // The campaign was marked 'sent' the moment the provider accepted these messages.
            // This rejection may mean none of them actually succeeded, so the verdict is re-taken
            // rather than left as the optimistic one recorded seconds earlier.
            wa_reconcile_campaign_status($cid);
            $applied++;
        }
    } elseif ($mapped === 'button_click') {
        $conn->query("UPDATE wa_campaign_recipients SET click_count = click_count + 1 WHERE id=$recId");
        $conn->query("UPDATE wa_campaigns SET click_count = click_count + 1 WHERE id=$cid");
        wa_record_event($cid, $recId, 'button_click', null, $ev['reason'] ?? null);
        $applied++;
    } elseif ($mapped === 'replied') {
        $conn->query("UPDATE wa_campaigns SET reply_count = reply_count + 1 WHERE id=$cid");
        wa_record_event($cid, $recId, 'replied', null, $ev['reason'] ?? null);
        // "STOP" is the universal WhatsApp opt-out. Honouring it here is what keeps a future
        // campaign from messaging someone who explicitly asked us not to.
        if ($ev['reason'] !== null && preg_match('/\b(stop|unsubscribe|opt\s*out)\b/i', $ev['reason'])) {
            $pR = $conn->query("SELECT phone FROM wa_campaign_recipients WHERE id=$recId LIMIT 1");
            $pRow = $pR ? $pR->fetch_assoc() : null;
            if ($pRow) {
                wa_record_optin($pRow['phone'], 'optout', 'REPLY');
                wa_log("webhook: {$pRow['phone']} opted out via reply");
            }
        }
        $applied++;
    }
}

wa_log('webhook: ' . count($events) . ' status event(s) received, ' . $applied . ' applied'
    . ($consentApplied ? ", $consentApplied consent change(s)" : '')
    . ($templateApplied ? ", $templateApplied template update(s)" : '')
    . ($inbox['messages'] ? ", {$inbox['messages']} inbound message(s)" : '')
    . ($inbox['statuses'] ? ", {$inbox['statuses']} chat status update(s)" : '')
    . ($inbox['clicks'] ? ", {$inbox['clicks']} link click(s)" : ''));
echo 'ok';

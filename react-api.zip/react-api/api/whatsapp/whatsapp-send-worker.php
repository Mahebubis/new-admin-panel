<?php
/*
 * Cron / instant-kick entrypoint for the WhatsApp campaign batch sender.
 *
 * Cron (the reliable safety net — one line, alongside the email worker's):
 *   * * * * * /usr/local/bin/php /home/istudio/public_html/admin/react-api/api/whatsapp/whatsapp-send-worker.php >> /home/istudio/logs/wa-worker.log 2>&1
 *
 * HTTP fallback (used internally by wa_trigger_worker_async() for the instant "Send now"
 * kick — requires the shared secret, NOT a public endpoint):
 *   GET .../whatsapp-send-worker.php?cron_secret=...&campaign_id=123
 */
ini_set('display_errors', 0);
error_reporting(E_ALL & ~E_WARNING & ~E_NOTICE & ~E_DEPRECATED);
$_SERVER['REQUEST_METHOD'] = $_SERVER['REQUEST_METHOD'] ?? 'CLI';

// PHP 8.1+ makes mysqli THROW on connection failure instead of setting ->connect_error, and
// with display_errors off an uncaught exception here would vanish without a trace — which is
// exactly how the email worker once died silently on every cron tick.
try {
    require_once __DIR__ . '/../../config/database.php';
} catch (\Throwable $e) {
    @file_put_contents(__DIR__ . '/wa-worker.log', '[' . date('Y-m-d H:i:s') . '] FATAL — could not connect to the database: '
        . '[' . get_class($e) . '] ' . $e->getMessage() . "\n", FILE_APPEND | LOCK_EX);
    exit;
}

require_once __DIR__ . '/lib/config.php';
require_once __DIR__ . '/lib/schema.php';
require_once __DIR__ . '/lib/WaSendWorker.php';
require_once __DIR__ . '/../attributes/lib/schema.php';

whatsapp_ensure_schema();
attributes_ensure_schema();

$isCli = (php_sapi_name() === 'cli');
$isAuthorizedHttp = !$isCli && ($_GET['cron_secret'] ?? '') === WA_CRON_SECRET;
if (!$isCli && !$isAuthorizedHttp) {
    http_response_code(403);
    echo "forbidden\n";
    exit;
}

$campaignId = isset($_GET['campaign_id']) ? (int)$_GET['campaign_id'] : null;
if ($isCli && isset($argv[1])) $campaignId = (int)$argv[1];

// Logged here (not only from inside wa_process_batch) so a run that never gets past the lock
// check below still leaves a trace — the instant kick's HTTP response is fire-and-forget and
// read by nobody, so this file is the only proof it fired at all.
wa_log('worker invoked via ' . ($isCli ? 'CLI (cron)' : 'HTTP (instant Send now kick)')
    . ($campaignId ? ", campaign_id=$campaignId" : ', no specific campaign_id (cron sweep)'));

// Exclusive lock — an overlapping cron tick (or a tick racing an instant kick) must not
// double-send. Its own lock file, separate from the email worker's, so the two channels never
// block each other.
$lockFp = fopen(sys_get_temp_dir() . '/wa_campaign_worker.lock', 'c');
if (!$lockFp || !flock($lockFp, LOCK_EX | LOCK_NB)) {
    wa_log('skip — another WhatsApp worker run is already in progress');
    exit;
}

// No execution ceiling: cron runs this via CLI (usually already 0), but the instant kick
// arrives over HTTP where the default 30s would kill the run mid-campaign and strand a block
// of recipients in 'processing'.
@set_time_limit(0);
ignore_user_abort(true);

$deadline = microtime(true) + WA_WORKER_MAX_RUNTIME_SECONDS;
$result = ['processed' => 0, 'sent' => 0, 'failed' => 0, 'campaigns' => 0];
$rounds = 0;

do {
    $round = wa_process_batch(WA_SEND_BATCH_SIZE, $campaignId);
    $rounds++;
    $result['processed'] += $round['processed'];
    $result['sent']      += $round['sent'];
    $result['failed']    += $round['failed'];
    $result['campaigns']  = $round['campaigns'];
    // Nothing claimed means every running campaign is drained (or none are) — stop rather than
    // spinning through the campaign lookup until the deadline for no reason.
    if ($round['processed'] === 0) break;
} while (microtime(true) < $deadline);

wa_log("run finished after $rounds batch round(s): " . json_encode($result)
    . (microtime(true) >= $deadline ? ' — hit the ' . WA_WORKER_MAX_RUNTIME_SECONDS . 's budget, next tick picks up the rest' : ''));

/*
 * Conversion counts, refreshed after sending rather than on their own cron — the same pattern the
 * email worker uses. Wrapped because a goal pointing at a table this install doesn't have must
 * cost a stale number, not a dead worker: sending is the job that actually matters here.
 */
try {
    require_once __DIR__ . '/lib/WaConversionTracker.php';
    wa_recompute_conversions();
} catch (\Throwable $e) {
    wa_log('conversion recompute skipped — ' . $e->getMessage());
}

flock($lockFp, LOCK_UN);
fclose($lockFp);

<?php
/**
 * lms_api.php
 * ---------------------------------------------------------------------------
 * SINGLE-FILE admin API for the "LMS System" panel (Learnyst-style LMS).
 *
 * Hierarchy:
 *   lms_courses                       (the main card — "Software Testing", ...)
 *     -> lms_sections                 (Module 1, Module 2, Lecture 1 ...)
 *          -> lms_lessons             (video / article / pdf / quiz / form)
 *               -> lms_lesson_attachments  (S3 files + links)
 *               -> lms_lesson_fields       (dynamic form builder — the data we
 *                    collect from the learner for THIS lesson; same builder
 *                    shape as internship_assignment_fields)
 *                    -> lms_form_responses (what learners submitted)
 *     -> lms_quizzes -> lms_quiz_questions -> lms_quiz_attempts
 *     -> lms_enrollments / lms_progress
 *
 * Learners are the EXISTING `users` rows. The Learners tab reads users who
 * purchased an internship (internship_payment) plus anyone already enrolled in
 * an LMS course; "Add learner" registers a brand-new `users` row exactly the
 * way user_dashboard/api/register.php does, and the CSV importer does the same
 * in bulk (mirrors the Netcore contact-import wizard's upload -> map -> run).
 *
 * Routes (all as ?resource=X&action=Y):
 *   dashboard     : stats
 *   courses       : list|get|create|update|delete|trash|restore|duplicate|publish|reorder|thumbnail
 *   sections      : list|create|update|delete|reorder
 *   lessons       : list|get|create|update|delete|reorder|move|toggle_hidden|upload_video
 *   attachments   : list|create|update|delete|reorder     (multipart on create)
 *   fields        : list|create|update|delete|toggle|reorder
 *   responses     : list|export|delete
 *   quizzes       : list|get|create|update|delete|duplicate|toggle
 *   questions     : list|create|update|delete|reorder|bulk_create
 *   attempts      : list|get|delete
 *   learners      : list|get|create|import_preview|import_run|import_history
 *   enrollments   : list|create|update|delete|bulk_create
 *   reports       : progress|quiz|course_funnel|portal_access
 *   support       : list|get|reply|status|delete    (the learner portal's help desk)
 *   settings      : get|save
 *   editor        : upload_image
 *
 * Responses: { "status":"success", "data":{...} } | { "status":"error", ... }
 *
 * Bootstrap / error handling / S3 approach mirror assignments_api.php so the
 * whole internship-system + LMS family behaves identically in production.
 * Access is gated by the React admin panel's permission system, not here.
 * ---------------------------------------------------------------------------
 */

@ini_set('display_errors', '0');
error_reporting(E_ALL);

define('LMS_LOG_FILE', __DIR__ . '/lms_errors.log');
@ini_set('log_errors', '1');
@ini_set('error_log', LMS_LOG_FILE);

function lms_log($label, $msg) {
    $line = '[' . date('Y-m-d H:i:s') . '] ' . $label . ': ' . $msg
          . '  {' . ($_SERVER['REQUEST_METHOD'] ?? 'CLI') . ' '
          . ($_SERVER['REQUEST_URI'] ?? '') . '}' . PHP_EOL;
    @file_put_contents(LMS_LOG_FILE, $line, FILE_APPEND | LOCK_EX);
}

set_error_handler(function ($no, $str, $file, $line) {
    if (strpos($file, 'lms_api.php') !== false) {
        lms_log('PHP-ERROR(' . $no . ')', $str . ' in ' . $file . ':' . $line);
    }
    return true;
});

/* shared bootstrap — provides global $conn (same as internship-system/*) */
ob_start();
chdir('/home/istudio/public_html/cit/common');
include '/home/istudio/public_html/cit/common/helper.php';
ob_clean();

/* AWS SDK — same vendor autoload + bucket/creds as assignments_api.php */
require_once '/home/istudio/public_html/istudio_dashboard/api/vendor/autoload.php';
use Aws\S3\S3Client;
use Aws\Exception\AwsException;

header('Content-Type: application/json');

register_shutdown_function(function () {
    $e = error_get_last();
    if ($e && in_array($e['type'], [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR], true)) {
        lms_log('FATAL', $e['message'] . ' in ' . $e['file'] . ':' . $e['line']);
        if (!headers_sent()) header('Content-Type: application/json');
        echo json_encode(['status' => 'error', 'message' => 'Server error: ' . $e['message']]);
    }
});

set_exception_handler(function ($e) {
    lms_log('EXCEPTION', get_class($e) . ': ' . $e->getMessage()
        . ' in ' . $e->getFile() . ':' . $e->getLine());
    if (!headers_sent()) {
        http_response_code(500);
        header('Content-Type: application/json');
    }
    echo json_encode(['status' => 'error', 'message' => 'Server error: ' . $e->getMessage()]);
    exit;
});

/* ====== helpers ====== */
function lms_out($p) { echo json_encode($p); exit; }
function lms_error($m, $c = 400) {
    lms_log('API-ERROR(' . $c . ')', $m);
    http_response_code($c);
    lms_out(['status' => 'error', 'message' => $m]);
}
function lms_ok($d = null, $m = '') {
    $r = ['status' => 'success'];
    if ($m !== '') $r['message'] = $m;
    if ($d !== null) $r['data'] = $d;
    lms_out($r);
}
function lms_input() {
    $i = $_POST;
    if (empty($i)) {
        $j = json_decode(file_get_contents('php://input'), true);
        if (is_array($j)) $i = $j;
    }
    return $i;
}
function lms_esc($conn, $v) { return $conn->real_escape_string((string)$v); }
function lms_int($v, $d = 0) { return $v === null || $v === '' ? $d : (int)$v; }
function lms_json_decode($s) {
    if ($s === null || $s === '') return [];
    $d = json_decode($s, true);
    return is_array($d) ? $d : [];
}
/** Always store JSON arrays/objects as a JSON string, never a bare scalar. */
function lms_json_col($v) {
    if ($v === null || $v === '') return null;
    if (is_array($v)) return json_encode($v);
    $d = json_decode($v, true);
    return is_array($d) ? json_encode($d) : json_encode([$v]);
}
function lms_slug($s) {
    $s = strtolower(trim((string)$s));
    $s = preg_replace('/[^a-z0-9]+/', '-', $s);
    return trim($s, '-') ?: 'course';
}

/* ====== S3 (same bucket / creds as assignments_api.php) ====== */
const LMS_S3_BUCKET = 'internshipstudio-prod-data-bucket-new';
const LMS_S3_REGION = 'ap-south-1';

function lms_s3_client() {
    return new S3Client([
        'version'     => 'latest',
        'region'      => LMS_S3_REGION,
        'credentials' => [
            'key'    => 'AKIAYVYU7O43T344J2MD',
            'secret' => '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',
        ],
    ]);
}

/** Uploads $_FILES entry to S3 under $prefix, returns [url, key, name, size, mime] or null. */
function lms_s3_put($file, $prefix) {
    if (!isset($file['tmp_name']) || !is_uploaded_file($file['tmp_name'])) return null;
    $orig = preg_replace('/[^A-Za-z0-9._-]+/', '_', $file['name'] ?? 'file');
    $key  = rtrim($prefix, '/') . '/' . date('Y/m') . '/' . uniqid('', true) . '_' . $orig;
    $mime = $file['type'] ?: 'application/octet-stream';
    try {
        lms_s3_client()->putObject([
            'Bucket'      => LMS_S3_BUCKET,
            'Key'         => $key,
            'SourceFile'  => $file['tmp_name'],
            'ContentType' => $mime,
        ]);
    } catch (AwsException $e) {
        lms_log('S3-UPLOAD-FAIL', $key . ': ' . $e->getMessage());
        return null;
    }
    return [
        'url'  => 'https://' . LMS_S3_BUCKET . '.s3.' . LMS_S3_REGION . '.amazonaws.com/' . $key,
        'key'  => $key,
        'name' => $file['name'] ?? $orig,
        'size' => (int)($file['size'] ?? 0),
        'mime' => $mime,
    ];
}
function lms_s3_delete($key) {
    if (!$key) return;
    try { lms_s3_client()->deleteObject(['Bucket' => LMS_S3_BUCKET, 'Key' => $key]); }
    catch (AwsException $e) { lms_log('S3-DELETE-FAIL', $key . ': ' . $e->getMessage()); }
}

/* ═══════════════════════════════════════════════════════════════════════════
   SCHEMA — created on first hit, then a no-op forever after
   ═══════════════════════════════════════════════════════════════════════════ */
$conn->query("CREATE TABLE IF NOT EXISTS lms_courses (
    id             INT AUTO_INCREMENT PRIMARY KEY,
    title          VARCHAR(255) NOT NULL,
    slug           VARCHAR(255)      DEFAULT NULL,
    subtitle       VARCHAR(500)      DEFAULT NULL,
    description    LONGTEXT          DEFAULT NULL,
    category       VARCHAR(120)      DEFAULT NULL,
    thumbnail_url  TEXT              DEFAULT NULL,
    thumbnail_key  VARCHAR(512)      DEFAULT NULL,
    price          DECIMAL(10,2)     DEFAULT 0,
    sale_price     DECIMAL(10,2)     DEFAULT 0,
    is_free        TINYINT(1)        DEFAULT 0,
    validity_days  INT               DEFAULT 365,
    encryption     ENUM('encrypted','unencrypted') DEFAULT 'unencrypted',
    instructor     VARCHAR(255)      DEFAULT NULL,
    tags           TEXT              DEFAULT NULL,
    seo_title      VARCHAR(255)      DEFAULT NULL,
    seo_description VARCHAR(500)     DEFAULT NULL,
    internship_id  INT               DEFAULT 0,
    internship_name VARCHAR(255)     DEFAULT NULL,
    sort_order     INT               DEFAULT 0,
    status         ENUM('draft','published','unpublished','trashed') DEFAULT 'draft',
    created_by     INT               DEFAULT 0,
    created_at     TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,
    updated_at     TIMESTAMP    DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_status_order (status, sort_order),
    INDEX idx_internship (internship_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

$conn->query("CREATE TABLE IF NOT EXISTS lms_sections (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    course_id   INT          NOT NULL,
    title       VARCHAR(255) NOT NULL,
    description TEXT              DEFAULT NULL,
    drip_days   INT               DEFAULT 0,
    sort_order  INT               DEFAULT 0,
    status      ENUM('active','inactive') DEFAULT 'active',
    created_at  TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,
    updated_at  TIMESTAMP    DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_course_order (course_id, sort_order)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

$conn->query("CREATE TABLE IF NOT EXISTS lms_lessons (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    course_id       INT          NOT NULL,
    section_id      INT          NOT NULL,
    title           VARCHAR(255) NOT NULL,
    lesson_type     ENUM('video','article','pdf','quiz','live','form') DEFAULT 'video',
    video_provider  VARCHAR(30)       DEFAULT 'url',
    video_url       TEXT              DEFAULT NULL,
    video_key       VARCHAR(512)      DEFAULT NULL,
    duration_secs   INT               DEFAULT 0,
    content         LONGTEXT          DEFAULT NULL,
    quiz_id         INT               DEFAULT 0,
    is_free_preview TINYINT(1)        DEFAULT 0,
    is_hidden       TINYINT(1)        DEFAULT 0,
    drip_days       INT               DEFAULT 0,
    sort_order      INT               DEFAULT 0,
    status          ENUM('draft','published') DEFAULT 'published',
    created_at      TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,
    updated_at      TIMESTAMP    DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_section_order (section_id, sort_order),
    INDEX idx_course (course_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

$conn->query("CREATE TABLE IF NOT EXISTS lms_lesson_attachments (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    lesson_id   INT          NOT NULL,
    kind        VARCHAR(10)       DEFAULT 'file',
    title       VARCHAR(255)      DEFAULT NULL,
    description TEXT              DEFAULT NULL,
    file_url    TEXT         NOT NULL,
    file_key    VARCHAR(512)      DEFAULT NULL,
    file_name   VARCHAR(255)      DEFAULT NULL,
    file_type   VARCHAR(40)       DEFAULT NULL,
    file_size   BIGINT            DEFAULT 0,
    mime_type   VARCHAR(150)      DEFAULT NULL,
    sort_order  INT               DEFAULT 0,
    status      ENUM('active','inactive') DEFAULT 'active',
    created_at  TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_lesson_order (lesson_id, sort_order)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

/* the per-lesson dynamic form builder — same column shape as
   internship_assignment_fields so the React builder is a straight reuse */
$conn->query("CREATE TABLE IF NOT EXISTS lms_lesson_fields (
    id                  INT AUTO_INCREMENT PRIMARY KEY,
    lesson_id           INT          NOT NULL,
    field_order         INT               DEFAULT 0,
    field_type          VARCHAR(30)  NOT NULL,
    label               VARCHAR(500) NOT NULL,
    placeholder         VARCHAR(500)      DEFAULT NULL,
    help_text           VARCHAR(1000)     DEFAULT NULL,
    is_required         TINYINT(1)        DEFAULT 1,
    options             TEXT              DEFAULT NULL,
    accepted_extensions VARCHAR(255)      DEFAULT NULL,
    max_file_size_mb    INT               DEFAULT 25,
    status              ENUM('active','inactive') DEFAULT 'active',
    created_at          TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,
    updated_at          TIMESTAMP    DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_lesson_order (lesson_id, field_order)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

$conn->query("CREATE TABLE IF NOT EXISTS lms_form_responses (
    id         INT AUTO_INCREMENT PRIMARY KEY,
    lesson_id  INT NOT NULL,
    course_id  INT NOT NULL,
    user_id    INT NOT NULL,
    payload    LONGTEXT DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_lesson (lesson_id, created_at),
    INDEX idx_user (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

$conn->query("CREATE TABLE IF NOT EXISTS lms_quizzes (
    id                INT AUTO_INCREMENT PRIMARY KEY,
    course_id         INT          DEFAULT 0,
    title             VARCHAR(255) NOT NULL,
    description       TEXT              DEFAULT NULL,
    instructions      LONGTEXT          DEFAULT NULL,
    duration_mins     INT               DEFAULT 0,
    pass_percentage   INT               DEFAULT 40,
    max_attempts      INT               DEFAULT 0,
    shuffle_questions TINYINT(1)        DEFAULT 0,
    shuffle_options   TINYINT(1)        DEFAULT 0,
    show_answers      ENUM('never','after_submit','after_pass') DEFAULT 'after_submit',
    negative_marking  TINYINT(1)        DEFAULT 0,
    show_result       TINYINT(1)        DEFAULT 1,
    is_graded         TINYINT(1)        DEFAULT 1,
    status            ENUM('draft','published') DEFAULT 'draft',
    created_by        INT               DEFAULT 0,
    created_at        TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,
    updated_at        TIMESTAMP    DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_course (course_id, status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

$conn->query("CREATE TABLE IF NOT EXISTS lms_quiz_questions (
    id             INT AUTO_INCREMENT PRIMARY KEY,
    quiz_id        INT          NOT NULL,
    question_type  VARCHAR(30)       DEFAULT 'single',
    question       LONGTEXT     NOT NULL,
    image_url      TEXT              DEFAULT NULL,
    options        TEXT              DEFAULT NULL,
    correct        TEXT              DEFAULT NULL,
    marks          DECIMAL(6,2)      DEFAULT 1,
    negative_marks DECIMAL(6,2)      DEFAULT 0,
    explanation    LONGTEXT          DEFAULT NULL,
    difficulty     ENUM('easy','medium','hard') DEFAULT 'medium',
    sort_order     INT               DEFAULT 0,
    status         ENUM('active','inactive') DEFAULT 'active',
    created_at     TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,
    updated_at     TIMESTAMP    DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_quiz_order (quiz_id, sort_order)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

$conn->query("CREATE TABLE IF NOT EXISTS lms_quiz_attempts (
    id           INT AUTO_INCREMENT PRIMARY KEY,
    quiz_id      INT NOT NULL,
    course_id    INT DEFAULT 0,
    user_id      INT NOT NULL,
    score        DECIMAL(8,2) DEFAULT 0,
    total_marks  DECIMAL(8,2) DEFAULT 0,
    percentage   DECIMAL(6,2) DEFAULT 0,
    passed       TINYINT(1)   DEFAULT 0,
    answers      LONGTEXT     DEFAULT NULL,
    started_at   TIMESTAMP    NULL DEFAULT NULL,
    submitted_at TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_quiz_user (quiz_id, user_id),
    INDEX idx_user (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

$conn->query("CREATE TABLE IF NOT EXISTS lms_enrollments (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    course_id   INT NOT NULL,
    user_id     INT NOT NULL,
    access_type ENUM('paid','free','trial') DEFAULT 'paid',
    amount      DECIMAL(10,2) DEFAULT 0,
    source      VARCHAR(60)   DEFAULT 'admin',
    expiry_date DATE          DEFAULT NULL,
    status      ENUM('active','expired','revoked') DEFAULT 'active',
    enrolled_at TIMESTAMP     DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uniq_course_user (course_id, user_id),
    INDEX idx_user (user_id),
    INDEX idx_course_status (course_id, status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

$conn->query("CREATE TABLE IF NOT EXISTS lms_progress (
    id           INT AUTO_INCREMENT PRIMARY KEY,
    user_id      INT NOT NULL,
    course_id    INT NOT NULL,
    lesson_id    INT NOT NULL,
    status       ENUM('started','completed') DEFAULT 'started',
    watched_secs INT DEFAULT 0,
    updated_at   TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uniq_user_lesson (user_id, lesson_id),
    INDEX idx_course_user (course_id, user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

$conn->query("CREATE TABLE IF NOT EXISTS lms_import_logs (
    id            INT AUTO_INCREMENT PRIMARY KEY,
    file_name     VARCHAR(255) DEFAULT NULL,
    course_id     INT          DEFAULT 0,
    total_rows    INT          DEFAULT 0,
    created_rows  INT          DEFAULT 0,
    existing_rows INT          DEFAULT 0,
    enrolled_rows INT          DEFAULT 0,
    failed_rows   INT          DEFAULT 0,
    errors        LONGTEXT     DEFAULT NULL,
    created_by    INT          DEFAULT 0,
    created_at    TIMESTAMP    DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

/* Backing store for lms_cached_count() — see that function for why the counts
   behind the paginated unions are cached at all. */
$conn->query("CREATE TABLE IF NOT EXISTS lms_count_cache (
    sig        CHAR(32) PRIMARY KEY,
    total      INT NOT NULL DEFAULT 0,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

$conn->query("CREATE TABLE IF NOT EXISTS lms_settings (
    setting_key   VARCHAR(80) PRIMARY KEY,
    setting_value LONGTEXT DEFAULT NULL,
    updated_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

/* ───────────────────────────────────────────────────────────────────────────
   ninety_nine_store_orders — the ₹99 store's own order table, which the public
   store writes to. The LMS panel now reads it as a learner source and writes
   to it when an admin adds someone by hand, so it needs two columns the store
   never had:

     user_id  the matching users.user_id, when the buyer's email is registered.
              Store checkout does not require an account, so it stays NULL for
              everyone who only ever bought a ₹99 course — that is why every
              read below LEFT JOINs and falls back to matching on email.
     source   'store' for a real checkout, 'admin' for a row an admin created
              from this panel. This is what the "Added by us" filter keys on.

   Added the same way the rest of this file provisions schema: guarded, so the
   first request after a deploy migrates and every request after it is a no-op.
   Both columns are NULLable with defaults, so the live store keeps inserting
   exactly as it does today without knowing they exist.
   ─────────────────────────────────────────────────────────────────────────── */
function lms_table_exists($conn, $table) {
    $t = $conn->real_escape_string($table);
    $r = $conn->query("SELECT 1 FROM information_schema.TABLES
                       WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = '$t' LIMIT 1");
    return (bool)($r && $r->num_rows);
}

function lms_column_exists($conn, $table, $column) {
    $t = $conn->real_escape_string($table);
    $c = $conn->real_escape_string($column);
    $r = $conn->query("SELECT 1 FROM information_schema.COLUMNS
                       WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = '$t'
                         AND COLUMN_NAME = '$c' LIMIT 1");
    return (bool)($r && $r->num_rows);
}

function lms_add_column($conn, $table, $column, $ddl) {
    if (!lms_table_exists($conn, $table)) return false;
    if (lms_column_exists($conn, $table, $column)) return false;
    return (bool)$conn->query("ALTER TABLE `$table` ADD COLUMN $ddl");
}

function lms_add_index($conn, $table, $index, $ddl) {
    if (!lms_table_exists($conn, $table)) return false;
    $t = $conn->real_escape_string($table);
    $i = $conn->real_escape_string($index);
    $r = $conn->query("SELECT 1 FROM information_schema.STATISTICS
                       WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = '$t'
                         AND INDEX_NAME = '$i' LIMIT 1");
    if ($r && $r->num_rows) return false;
    return (bool)$conn->query("ALTER TABLE `$t` ADD $ddl");
}

/* Four information_schema probes on every single API call would be pure
   overhead once the columns exist, so the whole migration sits behind one
   cheap lms_settings read. Bump LMS_STORE_SCHEMA_VERSION to make it run
   again after adding something new here. */
define('LMS_STORE_SCHEMA_VERSION', '5');

/* The password a hand-added learner gets unless the admin types another.
   Lives up here, not with the helpers at the foot of the file: every route
   ends in exit(), so a define() placed after the router would never run and
   the constant would be undefined at the exact moment it is needed. Function
   declarations hoist; define() calls do not. */
define('LMS_DEFAULT_PASSWORD', '123@istudio');

/**
 * Force a string expression into ONE charset + collation.
 *
 * The tables this file UNIONs together were created years apart and do not
 * agree: ninety_nine_store_orders is utf8mb4_0900_ai_ci, the lms_* tables are
 * utf8mb4_unicode_ci, and the older istudio tables are older still. MySQL
 * refuses to UNION columns whose collations differ — "Illegal mix of
 * collations for operation 'UNION'" — and it does so at parse time, so ONE
 * unconverted column kills the whole query.
 *
 * CONVERT() first (a latin1 column has to reach utf8mb4 before a utf8mb4
 * collation can be applied to it), COLLATE second.
 */
function lms_col($expr) {
    return "CONVERT($expr USING utf8mb4) COLLATE utf8mb4_unicode_ci";
}

/**
 * Cheap TTL cache for the COUNT(*) behind a paginated union.
 *
 * The count re-materialises the entire union — the same work as the page
 * itself — which doubled the cost of every single request, including each
 * click through the pager where the number cannot have changed. Keyed on the
 * filter signature so any change to the filters recomputes immediately.
 */
function lms_cached_count($conn, $sig, $sql, $ttl = 120) {
    $key = md5($sig);
    $r = $conn->query("SELECT total FROM lms_count_cache
                        WHERE sig = '$key' AND updated_at > (NOW() - INTERVAL $ttl SECOND) LIMIT 1");
    if ($r && $r->num_rows) return (int)$r->fetch_assoc()['total'];

    $c = $conn->query($sql);
    if ($c === false) return null;
    $total = (int)$c->fetch_assoc()['c'];

    $conn->query("INSERT INTO lms_count_cache (sig, total) VALUES ('$key', $total)
                  ON DUPLICATE KEY UPDATE total = VALUES(total), updated_at = NOW()");
    return $total;
}

$lms_schema_at = $conn->query("SELECT setting_value FROM lms_settings
                               WHERE setting_key = 'store_schema_version' LIMIT 1");
$lms_schema_at = $lms_schema_at && $lms_schema_at->num_rows
    ? (string)$lms_schema_at->fetch_assoc()['setting_value'] : '';

if ($lms_schema_at !== LMS_STORE_SCHEMA_VERSION) {
    lms_add_column($conn, 'ninety_nine_store_orders', 'user_id',
        '`user_id` BIGINT UNSIGNED NULL DEFAULT NULL AFTER `id`');
    lms_add_column($conn, 'ninety_nine_store_orders', 'source',
        "`source` VARCHAR(20) NOT NULL DEFAULT 'store' AFTER `provider`");
    lms_add_index($conn, 'ninety_nine_store_orders', 'idx_user_id', 'INDEX `idx_user_id` (`user_id`)');
    lms_add_index($conn, 'ninety_nine_store_orders', 'idx_source',  'INDEX `idx_source` (`source`)');

    /* CREATE TABLE IF NOT EXISTS above is a no-op on an install that already
       has lms_courses, so a column added to that statement never reaches an
       existing database. It has to be migrated in as well. */
    lms_add_column($conn, 'lms_courses', 'internship_name',
        '`internship_name` VARCHAR(255) NULL DEFAULT NULL AFTER `internship_id`');

    /* ── watch tracking ────────────────────────────────────────────────────
       lms_progress only ever held "furthest point reached" (watched_secs),
       which answers "can we resume?" but not "how much of this video did they
       actually watch?" — a learner who scrubs to the end has watched_secs at
       the end and nothing behind it.

       The portal now reports both, so the columns split three ways:
         last_position_secs  where the playhead is NOW  → what resume seeks to
         watched_secs        the furthest point reached → what progress uses
         watch_time_secs     seconds genuinely played, summed from the deltas
                             between timeupdate ticks, so a scrub adds nothing
       duration_secs is the length the player itself reported, which is the
       only reliable figure when an admin left the lesson's own duration at 0. */
    lms_add_column($conn, 'lms_progress', 'last_position_secs',
        '`last_position_secs` INT NOT NULL DEFAULT 0');
    lms_add_column($conn, 'lms_progress', 'duration_secs',
        '`duration_secs` INT NOT NULL DEFAULT 0');
    lms_add_column($conn, 'lms_progress', 'watch_time_secs',
        '`watch_time_secs` INT NOT NULL DEFAULT 0');
    lms_add_column($conn, 'lms_progress', 'play_count',
        '`play_count` INT NOT NULL DEFAULT 0');
    lms_add_column($conn, 'lms_progress', 'first_played_at',
        '`first_played_at` DATETIME NULL DEFAULT NULL');
    lms_add_column($conn, 'lms_progress', 'last_played_at',
        '`last_played_at` DATETIME NULL DEFAULT NULL');
    lms_add_column($conn, 'lms_progress', 'completed_at',
        '`completed_at` DATETIME NULL DEFAULT NULL');
    lms_add_index($conn, 'lms_progress', 'idx_user_updated',
        'INDEX `idx_user_updated` (`user_id`, `updated_at`)');

    /* (status, id) is exactly how the Enrollments list reads these tables:
       filter on status, then walk id backwards for the newest page. Without
       it MySQL scans the clustered index and throws away every row that is
       not 'success' — and on payment_status that is most of them.

       payment_status is the large one, so this ALTER can take a few seconds
       the first time. It runs once; the schema-version row above stops it
       from being attempted again. If the request times out mid-ALTER the
       index still completes server-side — MySQL DDL does not half-apply. */
    lms_add_index($conn, 'payment_status', 'idx_status_id',
        'INDEX `idx_status_id` (`status`, `id`)');
    lms_add_index($conn, 'ninety_nine_store_orders', 'idx_status_id',
        'INDEX `idx_status_id` (`status`, `id`)');
    lms_add_index($conn, 'lms_enrollments', 'idx_status_id',
        'INDEX `idx_status_id` (`status`, `id`)');

    $conn->query("INSERT INTO lms_settings (setting_key, setting_value)
                  VALUES ('store_schema_version', '" . LMS_STORE_SCHEMA_VERSION . "')
                  ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)");
}

/**
 * Which gateway is live right now.
 *
 * Owned by the main site, not the LMS: `settings`.settings_key='payment_method'
 * is the same row user_dashboard/api/get_payment_method.php reads to decide
 * whether checkout opens Razorpay or Cashfree. Reading it here keeps a
 * hand-added order labelled with the gateway a real buyer would have used.
 * Falls back to 'cashfree' for the same reason that endpoint does — a missing
 * row must not change behaviour.
 */
function lms_active_payment_provider($conn) {
    static $cached = null;
    if ($cached !== null) return $cached;

    $cached = 'cashfree';
    $r = @$conn->query("SELECT settings_value FROM settings
                        WHERE settings_key = 'payment_method' LIMIT 1");
    if ($r && ($row = $r->fetch_assoc())) {
        $v = strtolower(trim((string)($row['settings_value'] ?? '')));
        if ($v !== '') $cached = $v;
    }
    return $cached;
}

/**
 * Order / payment ids for a hand-added learner.
 *
 * Prefixed 'training' so these are obvious at a glance in phpMyAdmin and in
 * any gateway reconciliation: no Razorpay or Cashfree id ever starts that way,
 * so a row carrying one provably never went through a real checkout.
 */
function lms_training_ref($prefix = 'training') {
    return $prefix . '_' . date('YmdHis') . '_' . bin2hex(random_bytes(4));
}

/* ═══════════════════════════════════════════════════════════════════════════
   ROUTER
   ═══════════════════════════════════════════════════════════════════════════ */
$resource = $_GET['resource'] ?? '';
$action   = $_GET['action']   ?? '';
$in       = lms_input();

/* ───────────────────────── DASHBOARD ───────────────────────── */
if ($resource === 'dashboard') {
    $one = function ($sql) use ($conn) {
        $r = $conn->query($sql);
        return $r ? (float)($r->fetch_row()[0] ?? 0) : 0;
    };

    $stats = [
        'courses'        => (int)$one("SELECT COUNT(*) FROM lms_courses WHERE status <> 'trashed'"),
        'published'      => (int)$one("SELECT COUNT(*) FROM lms_courses WHERE status = 'published'"),
        'draft'          => (int)$one("SELECT COUNT(*) FROM lms_courses WHERE status IN ('draft','unpublished')"),
        'trashed'        => (int)$one("SELECT COUNT(*) FROM lms_courses WHERE status = 'trashed'"),
        'sections'       => (int)$one("SELECT COUNT(*) FROM lms_sections"),
        'lessons'        => (int)$one("SELECT COUNT(*) FROM lms_lessons"),
        'quizzes'        => (int)$one("SELECT COUNT(*) FROM lms_quizzes"),
        'questions'      => (int)$one("SELECT COUNT(*) FROM lms_quiz_questions WHERE status = 'active'"),
        'enrollments'    => (int)$one("SELECT COUNT(*) FROM lms_enrollments WHERE status = 'active'"),
        'learners'       => (int)$one("SELECT COUNT(DISTINCT user_id) FROM lms_enrollments"),
        'attempts'       => (int)$one("SELECT COUNT(*) FROM lms_quiz_attempts"),
        'responses'      => (int)$one("SELECT COUNT(*) FROM lms_form_responses"),
        'video_seconds'  => (int)$one("SELECT COALESCE(SUM(duration_secs),0) FROM lms_lessons"),
        'revenue'        => $one("SELECT COALESCE(SUM(amount),0) FROM lms_enrollments WHERE status='active'"),
        'completions'    => (int)$one("SELECT COUNT(*) FROM lms_progress WHERE status='completed'"),
    ];

    /* enrollments per month, last 12 months — feeds the bar chart */
    $months = [];
    $r = $conn->query("SELECT DATE_FORMAT(enrolled_at,'%Y-%m') ym, COUNT(*) c,
                              COALESCE(SUM(amount),0) amt
                       FROM lms_enrollments
                       WHERE enrolled_at >= DATE_SUB(CURDATE(), INTERVAL 12 MONTH)
                       GROUP BY ym ORDER BY ym");
    while ($r && ($row = $r->fetch_assoc())) {
        $months[$row['ym']] = ['count' => (int)$row['c'], 'amount' => (float)$row['amt']];
    }
    $series = [];
    for ($i = 11; $i >= 0; $i--) {
        $ym = date('Y-m', strtotime("-$i month"));
        $series[] = [
            'month'  => date("M 'y", strtotime($ym . '-01')),
            'count'  => $months[$ym]['count']  ?? 0,
            'amount' => $months[$ym]['amount'] ?? 0,
        ];
    }

    /* top courses by enrollment */
    $top = [];
    $r = $conn->query("SELECT c.id, c.title, c.thumbnail_url,
                              COUNT(e.id) enrolls, COALESCE(SUM(e.amount),0) revenue
                       FROM lms_courses c
                       LEFT JOIN lms_enrollments e ON e.course_id = c.id
                       WHERE c.status <> 'trashed'
                       GROUP BY c.id ORDER BY enrolls DESC, c.id DESC LIMIT 5");
    while ($r && ($row = $r->fetch_assoc())) {
        $top[] = [
            'id'        => (int)$row['id'],
            'title'     => $row['title'],
            'thumbnail' => $row['thumbnail_url'],
            'enrolls'   => (int)$row['enrolls'],
            'revenue'   => (float)$row['revenue'],
        ];
    }

    /* recent enrollments feed */
    $recent = [];
    $r = $conn->query("SELECT e.id, e.enrolled_at, e.access_type, e.amount,
                              u.name, u.email, c.title course_title
                       FROM lms_enrollments e
                       LEFT JOIN users u ON u.user_id = e.user_id
                       LEFT JOIN lms_courses c ON c.id = e.course_id
                       ORDER BY e.enrolled_at DESC LIMIT 8");
    while ($r && ($row = $r->fetch_assoc())) $recent[] = $row;

    lms_ok(['stats' => $stats, 'series' => $series, 'top_courses' => $top, 'recent' => $recent]);
}

/* ───────────────────────── COURSES ───────────────────────── */
if ($resource === 'courses') {

    if ($action === 'list' || $action === '') {
        $status = $_GET['status'] ?? 'all';
        $q      = trim($_GET['q'] ?? '');
        $where  = $status === 'all' ? "c.status <> 'trashed'" : "c.status = '" . lms_esc($conn, $status) . "'";
        if ($q !== '') {
            $qe = lms_esc($conn, $q);
            $where .= " AND (c.title LIKE '%$qe%' OR c.category LIKE '%$qe%')";
        }
        $sql = "SELECT c.*,
                   (SELECT COUNT(*) FROM lms_sections s WHERE s.course_id = c.id) section_count,
                   (SELECT COUNT(*) FROM lms_lessons  l WHERE l.course_id = c.id) lesson_count,
                   (SELECT COUNT(*) FROM lms_lessons  l WHERE l.course_id = c.id AND l.lesson_type='quiz') quiz_lesson_count,
                   (SELECT COALESCE(SUM(l.duration_secs),0) FROM lms_lessons l WHERE l.course_id = c.id) total_secs,
                   (SELECT COUNT(*) FROM lms_enrollments e WHERE e.course_id = c.id AND e.status='active') enroll_count,
                   (SELECT COUNT(*) FROM lms_sections s WHERE s.course_id = c.id AND s.drip_days > 0) drip_sections,
                   (SELECT COUNT(DISTINCT f.lesson_id) FROM lms_lesson_fields f
                      JOIN lms_lessons l2 ON l2.id = f.lesson_id
                     WHERE l2.course_id = c.id) form_count
                FROM lms_courses c
                WHERE $where
                ORDER BY c.sort_order ASC, c.id DESC";
        $res = $conn->query($sql);
        if ($res === false) lms_error('Could not read lms_courses: ' . $conn->error, 500);

        $rows = [];
        while ($row = $res->fetch_assoc()) {
            $row['id']            = (int)$row['id'];
            $row['price']         = (float)$row['price'];
            $row['sale_price']    = (float)$row['sale_price'];
            $row['is_free']       = (int)$row['is_free'];
            $row['section_count'] = (int)$row['section_count'];
            $row['lesson_count']  = (int)$row['lesson_count'];
            $row['quiz_lesson_count'] = (int)$row['quiz_lesson_count'];
            $row['total_secs']    = (int)$row['total_secs'];
            $row['enroll_count']  = (int)$row['enroll_count'];
            $row['tags']          = lms_json_decode($row['tags']);
            $rows[] = $row;
        }

        /* the counter strip above the grid (Total / Published / Draft / Trashed) */
        $counts = ['total' => 0, 'published' => 0, 'draft' => 0, 'trashed' => 0];
        $cr = $conn->query("SELECT status, COUNT(*) c FROM lms_courses GROUP BY status");
        while ($cr && ($c = $cr->fetch_assoc())) {
            if ($c['status'] === 'trashed') $counts['trashed'] = (int)$c['c'];
            else {
                $counts['total'] += (int)$c['c'];
                if ($c['status'] === 'published') $counts['published'] += (int)$c['c'];
                else $counts['draft'] += (int)$c['c'];
            }
        }
        lms_ok(['courses' => $rows, 'counts' => $counts]);
    }

    if ($action === 'get') {
        $id  = lms_int($_GET['id'] ?? 0);
        $res = $conn->query("SELECT * FROM lms_courses WHERE id = $id");
        $row = $res ? $res->fetch_assoc() : null;
        if (!$row) lms_error('Course not found', 404);
        $row['id']   = (int)$row['id'];
        $row['tags'] = lms_json_decode($row['tags']);

        /* The learner portal shows a course only when EVERY one of these is
           true, so the builder reports all three rather than making an admin
           discover them one failed login at a time:

             lms_courses.status = 'published'
             a lms_enrollments row exists for that learner
             at least one lesson is published and not hidden

           Buying the internship does NOT create the enrolment — the
           internship system and the LMS are separate tables — which is the
           one that surprises people. buyers_of tells the UI how many people
           a single "grant access" click would cover. */
        $one = function ($sql) use ($conn) {
            $r = $conn->query($sql);
            return $r ? (int)array_values($r->fetch_assoc())[0] : 0;
        };
        $row['enrolled_count']  = $one("SELECT COUNT(*) FROM lms_enrollments
                                         WHERE course_id = $id AND status <> 'revoked'");
        $row['visible_lessons'] = $one("SELECT COUNT(*) FROM lms_lessons
                                         WHERE course_id = $id AND status = 'published' AND is_hidden = 0");

        $row['buyers_of'] = 0;
        $link = trim((string)($row['internship_name'] ?? ''));
        if ($link !== '') {
            $le = lms_esc($conn, $link);
            $row['buyers_of'] = $one("SELECT COUNT(DISTINCT user_id) FROM internship_payment
                                       WHERE internship = '$le'");
        }

        lms_ok(['course' => $row]);
    }

    if ($action === 'create' || $action === 'update') {
        $title = trim($in['title'] ?? '');
        if ($title === '') lms_error('Course title is required');

        $cols = [
            'title'           => $title,
            'slug'            => lms_slug($in['slug'] ?? $title),
            'subtitle'        => $in['subtitle'] ?? '',
            'description'     => $in['description'] ?? '',
            'category'        => $in['category'] ?? '',
            'internship_name' => $in['internship_name'] ?? '',
            'internship_name' => $in['internship_name'] ?? '',
            'instructor'      => $in['instructor'] ?? '',
            'seo_title'       => $in['seo_title'] ?? '',
            'seo_description' => $in['seo_description'] ?? '',
            'encryption'      => in_array($in['encryption'] ?? '', ['encrypted', 'unencrypted'], true)
                                   ? $in['encryption'] : 'unencrypted',
            'status'          => in_array($in['status'] ?? '', ['draft', 'published', 'unpublished', 'trashed'], true)
                                   ? $in['status'] : 'draft',
        ];
        $nums = [
            'price'         => (float)($in['price'] ?? 0),
            'sale_price'    => (float)($in['sale_price'] ?? 0),
            'is_free'       => !empty($in['is_free']) ? 1 : 0,
            'validity_days' => lms_int($in['validity_days'] ?? 365, 365),
            'internship_id' => lms_int($in['internship_id'] ?? 0),
            'sort_order'    => lms_int($in['sort_order'] ?? 0),
        ];

        $sets = [];
        foreach ($cols as $k => $v) $sets[] = "$k = '" . lms_esc($conn, $v) . "'";
        foreach ($nums as $k => $v) $sets[] = "$k = " . ($k === 'price' || $k === 'sale_price' ? (float)$v : (int)$v);
        /* thumbnail_url is only touched when the client actually sends it.
           It is NOT part of $cols above, because those are written on every
           save — and a screen that does not know about the thumbnail (the
           create drawer, say) would then blank an image someone uploaded.

           A pasted URL also replaces any S3 object we were holding for this
           course, so that object is deleted rather than left to bill storage
           forever with nothing pointing at it. */
        if (array_key_exists('thumbnail_url', $in)) {
            $newThumb = trim((string)$in['thumbnail_url']);
            $sets[] = "thumbnail_url = '" . lms_esc($conn, $newThumb) . "'";

            $oldId = lms_int($in['id'] ?? 0);
            if ($oldId) {
                $kr  = $conn->query("SELECT thumbnail_key, thumbnail_url FROM lms_courses WHERE id = $oldId");
                $old = $kr ? $kr->fetch_assoc() : null;
                if ($old && !empty($old['thumbnail_key']) && $old['thumbnail_url'] !== $newThumb) {
                    lms_s3_delete($old['thumbnail_key']);
                    $sets[] = 'thumbnail_key = NULL';
                }
            }
        }

        $tags = lms_json_col($in['tags'] ?? null);
        $sets[] = 'tags = ' . ($tags === null ? 'NULL' : "'" . lms_esc($conn, $tags) . "'");

        if ($action === 'create') {
            $sets[] = 'created_by = ' . lms_int($in['created_by'] ?? 0);
            if (!$conn->query('INSERT INTO lms_courses SET ' . implode(', ', $sets))) {
                lms_error('Could not create course: ' . $conn->error, 500);
            }
            lms_ok(['id' => $conn->insert_id], 'Course created');
        }

        $id = lms_int($in['id'] ?? 0);
        if (!$id) lms_error('Course id is required');
        if (!$conn->query('UPDATE lms_courses SET ' . implode(', ', $sets) . " WHERE id = $id")) {
            lms_error('Could not update course: ' . $conn->error, 500);
        }

        /* ── re-date the people already enrolled ───────────────────────────
           validity_days only decides the expiry a NEW enrolment is stamped
           with, so switching a course to lifetime used to leave every existing
           learner still counting down to the date they were given. That is
           never what "this course no longer expires" is meant to mean, so the
           editor offers to carry the change across and this applies it.

           0 days = lifetime = no expiry date at all. Otherwise every active
           enrolment is re-dated from the day that learner enrolled, which is
           the same sum lms_enroll() does at enrolment time. */
        $applied = 0;
        if (!empty($in['apply_validity_to_enrollments'])) {
            $days = (int)$nums['validity_days'];
            $sql  = $days > 0
                ? "UPDATE lms_enrollments
                      SET expiry_date = DATE_ADD(DATE(enrolled_at), INTERVAL $days DAY)
                    WHERE course_id = $id AND status <> 'revoked'"
                : "UPDATE lms_enrollments
                      SET expiry_date = NULL
                    WHERE course_id = $id AND status <> 'revoked'";
            if ($conn->query($sql)) $applied = $conn->affected_rows;
            else lms_error('Course saved, but the learners could not be re-dated: ' . $conn->error, 500);
        }

        lms_ok(['id' => $id, 'enrollments_updated' => $applied], $applied
            ? "Course updated · $applied learner" . ($applied === 1 ? '' : 's') . ' re-dated'
            : 'Course updated');
    }

    if ($action === 'thumbnail') {
        $id = lms_int($_POST['id'] ?? 0);
        if (!$id) lms_error('Course id is required');
        if (empty($_FILES['file'])) lms_error('No file uploaded');
        $up = lms_s3_put($_FILES['file'], 'lms/course-thumbnails');
        if (!$up) lms_error('Upload to S3 failed', 500);

        /* drop the previous object so thumbnails don't accumulate in the bucket */
        $old = $conn->query("SELECT thumbnail_key FROM lms_courses WHERE id = $id");
        $oldKey = $old ? ($old->fetch_assoc()['thumbnail_key'] ?? '') : '';

        $conn->query("UPDATE lms_courses
                      SET thumbnail_url = '" . lms_esc($conn, $up['url']) . "',
                          thumbnail_key = '" . lms_esc($conn, $up['key']) . "'
                      WHERE id = $id");
        if ($oldKey && $oldKey !== $up['key']) lms_s3_delete($oldKey);
        lms_ok(['url' => $up['url']], 'Thumbnail updated');
    }

    if ($action === 'publish') {
        $id = lms_int($in['id'] ?? 0);
        $to = ($in['status'] ?? 'published') === 'published' ? 'published' : 'unpublished';
        if (!$id) lms_error('Course id is required');
        $conn->query("UPDATE lms_courses SET status = '$to' WHERE id = $id");
        lms_ok(['id' => $id, 'status' => $to], $to === 'published' ? 'Course published' : 'Course unpublished');
    }

    if ($action === 'trash' || $action === 'restore') {
        $id = lms_int($in['id'] ?? 0);
        if (!$id) lms_error('Course id is required');
        $to = $action === 'trash' ? 'trashed' : 'draft';
        $conn->query("UPDATE lms_courses SET status = '$to' WHERE id = $id");
        lms_ok(['id' => $id], $action === 'trash' ? 'Moved to trash' : 'Restored');
    }

    if ($action === 'duplicate') {
        $id = lms_int($in['id'] ?? 0);
        if (!$id) lms_error('Course id is required');
        $src = $conn->query("SELECT * FROM lms_courses WHERE id = $id");
        $c   = $src ? $src->fetch_assoc() : null;
        if (!$c) lms_error('Course not found', 404);

        $title = lms_esc($conn, $c['title'] . ' (Copy)');
        $conn->query("INSERT INTO lms_courses
            (title, slug, subtitle, description, category, thumbnail_url, price, sale_price,
             is_free, validity_days, encryption, instructor, tags, internship_id, status)
            SELECT '$title', CONCAT(slug,'-copy'), subtitle, description, category, thumbnail_url,
                   price, sale_price, is_free, validity_days, encryption, instructor, tags,
                   internship_id, 'draft'
            FROM lms_courses WHERE id = $id");
        $newId = $conn->insert_id;

        /* deep-copy sections, then each section's lessons (fields/attachments are
           intentionally NOT copied — they usually need per-course rewriting) */
        $sr = $conn->query("SELECT * FROM lms_sections WHERE course_id = $id ORDER BY sort_order");
        while ($sr && ($s = $sr->fetch_assoc())) {
            $st = lms_esc($conn, $s['title']);
            $sd = lms_esc($conn, (string)$s['description']);
            $conn->query("INSERT INTO lms_sections (course_id, title, description, drip_days, sort_order, status)
                          VALUES ($newId, '$st', '$sd', " . (int)$s['drip_days'] . ", " . (int)$s['sort_order'] . ", '" . $s['status'] . "')");
            $newSec = $conn->insert_id;
            $oldSec = (int)$s['id'];
            $conn->query("INSERT INTO lms_lessons
                (course_id, section_id, title, lesson_type, video_provider, video_url, duration_secs,
                 content, quiz_id, is_free_preview, is_hidden, drip_days, sort_order, status)
                SELECT $newId, $newSec, title, lesson_type, video_provider, video_url, duration_secs,
                       content, quiz_id, is_free_preview, is_hidden, drip_days, sort_order, status
                FROM lms_lessons WHERE section_id = $oldSec");
        }
        lms_ok(['id' => $newId], 'Course duplicated');
    }

    if ($action === 'delete') {
        $id = lms_int($in['id'] ?? 0);
        if (!$id) lms_error('Course id is required');
        /* collect S3 keys before the rows disappear */
        $keys = [];
        $r = $conn->query("SELECT a.file_key FROM lms_lesson_attachments a
                           JOIN lms_lessons l ON l.id = a.lesson_id
                           WHERE l.course_id = $id AND a.file_key <> ''");
        while ($r && ($k = $r->fetch_assoc())) $keys[] = $k['file_key'];
        $r = $conn->query("SELECT thumbnail_key FROM lms_courses WHERE id = $id AND thumbnail_key <> ''");
        while ($r && ($k = $r->fetch_assoc())) $keys[] = $k['thumbnail_key'];

        $conn->query("DELETE f FROM lms_lesson_fields f JOIN lms_lessons l ON l.id = f.lesson_id WHERE l.course_id = $id");
        $conn->query("DELETE a FROM lms_lesson_attachments a JOIN lms_lessons l ON l.id = a.lesson_id WHERE l.course_id = $id");
        $conn->query("DELETE FROM lms_form_responses WHERE course_id = $id");
        $conn->query("DELETE FROM lms_lessons     WHERE course_id = $id");
        $conn->query("DELETE FROM lms_sections    WHERE course_id = $id");
        $conn->query("DELETE FROM lms_progress    WHERE course_id = $id");
        $conn->query("DELETE FROM lms_enrollments WHERE course_id = $id");
        $conn->query("DELETE FROM lms_courses     WHERE id = $id");

        foreach ($keys as $k) lms_s3_delete($k);
        lms_ok(null, 'Course deleted permanently');
    }

    if ($action === 'reorder') {
        $order = $in['order'] ?? [];
        if (!is_array($order)) lms_error('order must be an array of ids');
        foreach ($order as $i => $cid) {
            $conn->query('UPDATE lms_courses SET sort_order = ' . (int)$i . ' WHERE id = ' . (int)$cid);
        }
        lms_ok(null, 'Order saved');
    }

    /* Reproduces, condition by condition, the exact query the learner portal
       runs (training_dashboard/api/catalog.php -> learn_enrollment_rows) for
       ONE email. Guessing which of the four requirements is missing — and
       whether the person who bought is even the person who logged in — is what
       turns "it still isn't showing" into a long back-and-forth. */
    if ($action === 'access_check') {
        $id    = lms_int($_GET['id'] ?? 0);
        $email = strtolower(trim($_GET['email'] ?? ''));
        if (!$id)         lms_error('Course id is required');
        if ($email === '') lms_error('Enter the email the learner signs in with');

        $c = $conn->query("SELECT title, status FROM lms_courses WHERE id = $id");
        $course = $c ? $c->fetch_assoc() : null;
        if (!$course) lms_error('Course not found', 404);

        $ee = lms_esc($conn, $email);
        $u  = $conn->query("SELECT user_id, name FROM users WHERE email = '$ee' LIMIT 1");
        $user = $u ? $u->fetch_assoc() : null;

        $lessons = 0;
        $lr = $conn->query("SELECT COUNT(*) c FROM lms_lessons
                             WHERE course_id = $id AND status = 'published' AND is_hidden = 0");
        if ($lr) $lessons = (int)$lr->fetch_assoc()['c'];

        $checks = [
            ['key' => 'course_published', 'label' => 'Course is published',
             'ok' => $course['status'] === 'published',
             'detail' => 'Status is "' . $course['status'] . '"'],
            ['key' => 'has_lessons', 'label' => 'Has at least one visible lesson',
             'ok' => $lessons > 0,
             'detail' => $lessons . ' published, unhidden lesson(s)'],
            ['key' => 'account', 'label' => 'That email has an account',
             'ok' => (bool)$user,
             'detail' => $user ? 'user_id ' . $user['user_id'] : 'No users row for ' . $email],
        ];

        $enr = null;
        if ($user) {
            $uid = (int)$user['user_id'];
            $er  = $conn->query("SELECT status, expiry_date, access_type, enrolled_at
                                   FROM lms_enrollments
                                  WHERE course_id = $id AND user_id = $uid LIMIT 1");
            $enr = $er ? $er->fetch_assoc() : null;

            $checks[] = ['key' => 'enrolled', 'label' => 'Enrolled in this course',
                'ok' => (bool)$enr,
                'detail' => $enr
                    ? 'Enrolled ' . $enr['enrolled_at'] . ' (' . $enr['access_type'] . ')'
                    : 'No lms_enrollments row — buying the internship does not create one'];

            if ($enr) {
                $checks[] = ['key' => 'not_revoked', 'label' => 'Enrollment is not revoked',
                    'ok' => $enr['status'] !== 'revoked',
                    'detail' => 'Status is "' . $enr['status'] . '"'];
                $expired = $enr['expiry_date'] && $enr['expiry_date'] < date('Y-m-d');
                $checks[] = ['key' => 'not_expired', 'label' => 'Access has not expired',
                    'ok' => !$expired,
                    'detail' => $enr['expiry_date'] ? 'Expires ' . $enr['expiry_date'] : 'Lifetime access'];
            }

            /* Bought the internship but was never enrolled: the single most
               common cause, and the one an admin cannot see from the DB
               without knowing these are two different tables. */
            $bought = [];
            $br = $conn->query("SELECT DISTINCT internship FROM internship_payment WHERE user_id = $uid");
            while ($br && ($r = $br->fetch_assoc())) $bought[] = $r['internship'];
            $checks[] = ['key' => 'internships', 'label' => 'Internships this account bought',
                'ok' => count($bought) > 0, 'info' => true,
                'detail' => $bought ? implode(', ', $bought) : 'None'];
        }

        $blocking = [];
        foreach ($checks as $ch) {
            if (empty($ch['info']) && !$ch['ok']) $blocking[] = $ch['label'];
        }

        lms_ok([
            'course'   => $course['title'],
            'email'    => $email,
            'user'     => $user ? ['user_id' => (int)$user['user_id'], 'name' => $user['name']] : null,
            'checks'   => $checks,
            'can_see'  => count($blocking) === 0,
            'blocking' => $blocking,
        ]);
    }

    lms_error('Unknown courses action: ' . $action);
}

/* ───────────────────────── SECTIONS ───────────────────────── */
if ($resource === 'sections') {

    if ($action === 'list') {
        $cid = lms_int($_GET['course_id'] ?? 0);
        if (!$cid) lms_error('course_id is required');

        $sections = [];
        $res = $conn->query("SELECT * FROM lms_sections WHERE course_id = $cid ORDER BY sort_order ASC, id ASC");
        while ($res && ($s = $res->fetch_assoc())) {
            $s['id']         = (int)$s['id'];
            $s['sort_order'] = (int)$s['sort_order'];
            $s['drip_days']  = (int)$s['drip_days'];
            $s['lessons']    = [];
            $sections[$s['id']] = $s;
        }

        if ($sections) {
            $ids = implode(',', array_keys($sections));
            $lr = $conn->query("SELECT l.id, l.section_id, l.title, l.lesson_type, l.video_url,
                                       l.duration_secs, l.is_free_preview, l.is_hidden, l.sort_order,
                                       l.status, l.quiz_id,
                                       (SELECT COUNT(*) FROM lms_lesson_attachments a
                                          WHERE a.lesson_id = l.id AND a.status='active') attachment_count,
                                       (SELECT COUNT(*) FROM lms_lesson_fields f
                                          WHERE f.lesson_id = l.id AND f.status='active') field_count,
                                       (SELECT COUNT(*) FROM lms_form_responses r
                                          WHERE r.lesson_id = l.id) response_count
                                FROM lms_lessons l
                                WHERE l.section_id IN ($ids)
                                ORDER BY l.sort_order ASC, l.id ASC");
            while ($lr && ($l = $lr->fetch_assoc())) {
                $sid = (int)$l['section_id'];
                $l['id']               = (int)$l['id'];
                $l['duration_secs']    = (int)$l['duration_secs'];
                $l['is_free_preview']  = (int)$l['is_free_preview'];
                $l['is_hidden']        = (int)$l['is_hidden'];
                $l['sort_order']       = (int)$l['sort_order'];
                $l['quiz_id']          = (int)$l['quiz_id'];
                $l['attachment_count'] = (int)$l['attachment_count'];
                $l['field_count']      = (int)$l['field_count'];
                $l['response_count']   = (int)$l['response_count'];
                if (isset($sections[$sid])) $sections[$sid]['lessons'][] = $l;
            }
        }

        $cr = $conn->query("SELECT * FROM lms_courses WHERE id = $cid");
        $course = $cr ? $cr->fetch_assoc() : null;
        if ($course) $course['tags'] = lms_json_decode($course['tags']);

        lms_ok(['course' => $course, 'sections' => array_values($sections)]);
    }

    if ($action === 'create') {
        $cid   = lms_int($in['course_id'] ?? 0);
        $title = trim($in['title'] ?? '');
        if (!$cid)         lms_error('course_id is required');
        if ($title === '') lms_error('Section title is required');

        $r    = $conn->query("SELECT COALESCE(MAX(sort_order), -1) + 1 n FROM lms_sections WHERE course_id = $cid");
        $next = $r ? (int)$r->fetch_assoc()['n'] : 0;

        $conn->query("INSERT INTO lms_sections (course_id, title, description, drip_days, sort_order)
                      VALUES ($cid, '" . lms_esc($conn, $title) . "',
                              '" . lms_esc($conn, $in['description'] ?? '') . "',
                              " . lms_int($in['drip_days'] ?? 0) . ", $next)");
        lms_ok(['id' => $conn->insert_id], 'Section added');
    }

    if ($action === 'update') {
        $id = lms_int($in['id'] ?? 0);
        if (!$id) lms_error('Section id is required');
        $sets = [
            "title = '"       . lms_esc($conn, trim($in['title'] ?? '')) . "'",
            "description = '" . lms_esc($conn, $in['description'] ?? '') . "'",
            'drip_days = '    . lms_int($in['drip_days'] ?? 0),
        ];
        if (isset($in['status']) && in_array($in['status'], ['active', 'inactive'], true)) {
            $sets[] = "status = '" . $in['status'] . "'";
        }
        $conn->query('UPDATE lms_sections SET ' . implode(', ', $sets) . " WHERE id = $id");
        lms_ok(['id' => $id], 'Section updated');
    }

    if ($action === 'delete') {
        $id = lms_int($in['id'] ?? 0);
        if (!$id) lms_error('Section id is required');
        $keys = [];
        $r = $conn->query("SELECT a.file_key FROM lms_lesson_attachments a
                           JOIN lms_lessons l ON l.id = a.lesson_id
                           WHERE l.section_id = $id AND a.file_key <> ''");
        while ($r && ($k = $r->fetch_assoc())) $keys[] = $k['file_key'];

        $conn->query("DELETE f FROM lms_lesson_fields f JOIN lms_lessons l ON l.id = f.lesson_id WHERE l.section_id = $id");
        $conn->query("DELETE a FROM lms_lesson_attachments a JOIN lms_lessons l ON l.id = a.lesson_id WHERE l.section_id = $id");
        $conn->query("DELETE FROM lms_lessons  WHERE section_id = $id");
        $conn->query("DELETE FROM lms_sections WHERE id = $id");
        foreach ($keys as $k) lms_s3_delete($k);
        lms_ok(null, 'Section deleted');
    }

    if ($action === 'reorder') {
        $order = $in['order'] ?? [];
        if (!is_array($order)) lms_error('order must be an array of ids');
        foreach ($order as $i => $sid) {
            $conn->query('UPDATE lms_sections SET sort_order = ' . (int)$i . ' WHERE id = ' . (int)$sid);
        }
        lms_ok(null, 'Sections reordered');
    }

    lms_error('Unknown sections action: ' . $action);
}

/* ───────────────────────── LESSONS ───────────────────────── */
if ($resource === 'lessons') {

    if ($action === 'get') {
        $id  = lms_int($_GET['id'] ?? 0);
        $res = $conn->query("SELECT l.*, s.title section_title, c.title course_title
                             FROM lms_lessons l
                             LEFT JOIN lms_sections s ON s.id = l.section_id
                             LEFT JOIN lms_courses  c ON c.id = l.course_id
                             WHERE l.id = $id");
        $l = $res ? $res->fetch_assoc() : null;
        if (!$l) lms_error('Lesson not found', 404);
        foreach (['id', 'course_id', 'section_id', 'duration_secs', 'is_free_preview', 'is_hidden', 'quiz_id', 'drip_days'] as $k) {
            $l[$k] = (int)$l[$k];
        }

        /* sibling navigation — powers the "2 / 9 Lesson  < >" header */
        $sibs = [];
        $sr = $conn->query("SELECT id, title FROM lms_lessons
                            WHERE section_id = " . (int)$l['section_id'] . "
                            ORDER BY sort_order ASC, id ASC");
        while ($sr && ($s = $sr->fetch_assoc())) $sibs[] = ['id' => (int)$s['id'], 'title' => $s['title']];

        lms_ok(['lesson' => $l, 'siblings' => $sibs]);
    }

    if ($action === 'create') {
        $cid = lms_int($in['course_id'] ?? 0);
        $sid = lms_int($in['section_id'] ?? 0);
        if (!$cid || !$sid) lms_error('course_id and section_id are required');
        $title = trim($in['title'] ?? '') ?: 'Untitled lesson';
        $type  = in_array($in['lesson_type'] ?? '', ['video', 'article', 'pdf', 'quiz', 'live', 'form'], true)
                   ? $in['lesson_type'] : 'video';

        $r    = $conn->query("SELECT COALESCE(MAX(sort_order), -1) + 1 n FROM lms_lessons WHERE section_id = $sid");
        $next = $r ? (int)$r->fetch_assoc()['n'] : 0;

        $conn->query("INSERT INTO lms_lessons
            (course_id, section_id, title, lesson_type, sort_order, status)
            VALUES ($cid, $sid, '" . lms_esc($conn, $title) . "', '$type', $next, 'draft')");
        lms_ok(['id' => $conn->insert_id], 'Lesson added');
    }

    if ($action === 'update') {
        $id = lms_int($in['id'] ?? 0);
        if (!$id) lms_error('Lesson id is required');

        $sets = [];
        if (isset($in['title']))          $sets[] = "title = '"          . lms_esc($conn, trim($in['title'])) . "'";
        if (isset($in['content']))        $sets[] = "content = '"        . lms_esc($conn, $in['content']) . "'";
        if (isset($in['video_url']))      $sets[] = "video_url = '"      . lms_esc($conn, $in['video_url']) . "'";
        if (isset($in['video_provider'])) $sets[] = "video_provider = '" . lms_esc($conn, $in['video_provider']) . "'";
        if (isset($in['lesson_type']) && in_array($in['lesson_type'], ['video', 'article', 'pdf', 'quiz', 'live', 'form'], true)) {
            $sets[] = "lesson_type = '" . $in['lesson_type'] . "'";
        }
        if (isset($in['status']) && in_array($in['status'], ['draft', 'published'], true)) {
            $sets[] = "status = '" . $in['status'] . "'";
        }
        foreach (['duration_secs', 'quiz_id', 'drip_days'] as $k) {
            if (isset($in[$k])) $sets[] = "$k = " . lms_int($in[$k]);
        }
        foreach (['is_free_preview', 'is_hidden'] as $k) {
            if (isset($in[$k])) $sets[] = "$k = " . (!empty($in[$k]) ? 1 : 0);
        }
        if (!$sets) lms_error('Nothing to update');

        $conn->query('UPDATE lms_lessons SET ' . implode(', ', $sets) . " WHERE id = $id");
        lms_ok(['id' => $id], 'Lesson saved');
    }

    if ($action === 'upload_video') {
        $id = lms_int($_POST['id'] ?? 0);
        if (!$id) lms_error('Lesson id is required');
        if (empty($_FILES['file'])) lms_error('No file uploaded');
        $up = lms_s3_put($_FILES['file'], 'lms/lesson-videos');
        if (!$up) lms_error('Upload to S3 failed', 500);

        $old = $conn->query("SELECT video_key FROM lms_lessons WHERE id = $id");
        $oldKey = $old ? ($old->fetch_assoc()['video_key'] ?? '') : '';

        $conn->query("UPDATE lms_lessons
                      SET video_url = '" . lms_esc($conn, $up['url']) . "',
                          video_key = '" . lms_esc($conn, $up['key']) . "',
                          video_provider = 's3',
                          duration_secs = " . lms_int($_POST['duration_secs'] ?? 0) . "
                      WHERE id = $id");
        if ($oldKey && $oldKey !== $up['key']) lms_s3_delete($oldKey);
        lms_ok(['url' => $up['url'], 'name' => $up['name'], 'size' => $up['size']], 'Video uploaded');
    }

    if ($action === 'toggle_hidden') {
        $id = lms_int($in['id'] ?? 0);
        if (!$id) lms_error('Lesson id is required');
        $conn->query("UPDATE lms_lessons SET is_hidden = 1 - is_hidden WHERE id = $id");
        lms_ok(null, 'Visibility updated');
    }

    if ($action === 'move') {
        $id  = lms_int($in['id'] ?? 0);
        $sid = lms_int($in['section_id'] ?? 0);
        if (!$id || !$sid) lms_error('id and section_id are required');
        $r    = $conn->query("SELECT COALESCE(MAX(sort_order), -1) + 1 n FROM lms_lessons WHERE section_id = $sid");
        $next = $r ? (int)$r->fetch_assoc()['n'] : 0;
        $conn->query("UPDATE lms_lessons SET section_id = $sid, sort_order = $next WHERE id = $id");
        lms_ok(null, 'Lesson moved');
    }

    if ($action === 'delete') {
        $id = lms_int($in['id'] ?? 0);
        if (!$id) lms_error('Lesson id is required');
        $keys = [];
        $r = $conn->query("SELECT file_key FROM lms_lesson_attachments WHERE lesson_id = $id AND file_key <> ''");
        while ($r && ($k = $r->fetch_assoc())) $keys[] = $k['file_key'];
        $r = $conn->query("SELECT video_key FROM lms_lessons WHERE id = $id AND video_key <> ''");
        while ($r && ($k = $r->fetch_assoc())) $keys[] = $k['video_key'];

        $conn->query("DELETE FROM lms_lesson_fields      WHERE lesson_id = $id");
        $conn->query("DELETE FROM lms_lesson_attachments WHERE lesson_id = $id");
        $conn->query("DELETE FROM lms_form_responses     WHERE lesson_id = $id");
        $conn->query("DELETE FROM lms_progress           WHERE lesson_id = $id");
        $conn->query("DELETE FROM lms_lessons            WHERE id = $id");
        foreach ($keys as $k) lms_s3_delete($k);
        lms_ok(null, 'Lesson deleted');
    }

    if ($action === 'reorder') {
        $order = $in['order'] ?? [];
        if (!is_array($order)) lms_error('order must be an array of ids');
        foreach ($order as $i => $lid) {
            $conn->query('UPDATE lms_lessons SET sort_order = ' . (int)$i . ' WHERE id = ' . (int)$lid);
        }
        lms_ok(null, 'Lessons reordered');
    }

    lms_error('Unknown lessons action: ' . $action);
}

/* ───────────────────────── ATTACHMENTS ───────────────────────── */
if ($resource === 'attachments') {

    if ($action === 'list') {
        $lid = lms_int($_GET['lesson_id'] ?? 0);
        if (!$lid) lms_error('lesson_id is required');
        $rows = [];
        $res = $conn->query("SELECT * FROM lms_lesson_attachments
                             WHERE lesson_id = $lid ORDER BY sort_order ASC, id ASC");
        while ($res && ($r = $res->fetch_assoc())) {
            $r['id'] = (int)$r['id']; $r['file_size'] = (int)$r['file_size'];
            $r['sort_order'] = (int)$r['sort_order'];
            $rows[] = $r;
        }
        lms_ok(['attachments' => $rows]);
    }

    if ($action === 'create') {
        $lid  = lms_int($_POST['lesson_id'] ?? 0);
        $kind = ($_POST['kind'] ?? 'file') === 'link' ? 'link' : 'file';
        if (!$lid) lms_error('lesson_id is required');

        $r    = $conn->query("SELECT COALESCE(MAX(sort_order), -1) + 1 n FROM lms_lesson_attachments WHERE lesson_id = $lid");
        $next = $r ? (int)$r->fetch_assoc()['n'] : 0;

        if ($kind === 'link') {
            $url = trim($_POST['file_url'] ?? '');
            if ($url === '') lms_error('Link URL is required');
            $conn->query("INSERT INTO lms_lesson_attachments
                (lesson_id, kind, title, description, file_url, file_type, sort_order)
                VALUES ($lid, 'link',
                        '" . lms_esc($conn, $_POST['title'] ?? '') . "',
                        '" . lms_esc($conn, $_POST['description'] ?? '') . "',
                        '" . lms_esc($conn, $url) . "', 'link', $next)");
            lms_ok(['id' => $conn->insert_id], 'Link added');
        }

        if (empty($_FILES['file'])) lms_error('No file uploaded');
        $up = lms_s3_put($_FILES['file'], 'lms/lesson-attachments');
        if (!$up) lms_error('Upload to S3 failed', 500);

        $ext  = strtolower(pathinfo($up['name'], PATHINFO_EXTENSION));
        $map  = ['pdf' => 'pdf', 'doc' => 'doc', 'docx' => 'doc', 'xls' => 'excel', 'xlsx' => 'excel',
                 'csv' => 'excel', 'ppt' => 'ppt', 'pptx' => 'ppt', 'mp4' => 'video', 'mov' => 'video',
                 'zip' => 'zip', 'rar' => 'zip', 'png' => 'image', 'jpg' => 'image', 'jpeg' => 'image',
                 'gif' => 'image', 'webp' => 'image'];
        $ftype = $map[$ext] ?? 'other';

        $conn->query("INSERT INTO lms_lesson_attachments
            (lesson_id, kind, title, description, file_url, file_key, file_name, file_type,
             file_size, mime_type, sort_order)
            VALUES ($lid, 'file',
                    '" . lms_esc($conn, $_POST['title'] ?? $up['name']) . "',
                    '" . lms_esc($conn, $_POST['description'] ?? '') . "',
                    '" . lms_esc($conn, $up['url'])  . "',
                    '" . lms_esc($conn, $up['key'])  . "',
                    '" . lms_esc($conn, $up['name']) . "',
                    '$ftype', " . (int)$up['size'] . ",
                    '" . lms_esc($conn, $up['mime']) . "', $next)");
        lms_ok(['id' => $conn->insert_id, 'url' => $up['url']], 'Attachment uploaded');
    }

    if ($action === 'update') {
        $id = lms_int($in['id'] ?? 0);
        if (!$id) lms_error('Attachment id is required');
        $conn->query("UPDATE lms_lesson_attachments SET
                        title = '"       . lms_esc($conn, $in['title'] ?? '') . "',
                        description = '" . lms_esc($conn, $in['description'] ?? '') . "'
                      WHERE id = $id");
        lms_ok(null, 'Attachment updated');
    }

    if ($action === 'delete') {
        $id = lms_int($in['id'] ?? 0);
        if (!$id) lms_error('Attachment id is required');
        $r   = $conn->query("SELECT file_key FROM lms_lesson_attachments WHERE id = $id");
        $key = $r ? ($r->fetch_assoc()['file_key'] ?? '') : '';
        $conn->query("DELETE FROM lms_lesson_attachments WHERE id = $id");
        if ($key) lms_s3_delete($key);
        lms_ok(null, 'Attachment removed');
    }

    if ($action === 'reorder') {
        $order = $in['order'] ?? [];
        foreach ((array)$order as $i => $aid) {
            $conn->query('UPDATE lms_lesson_attachments SET sort_order = ' . (int)$i . ' WHERE id = ' . (int)$aid);
        }
        lms_ok(null, 'Reordered');
    }

    lms_error('Unknown attachments action: ' . $action);
}

/* ───────────────── FIELDS (per-lesson dynamic form builder) ───────────────── */
if ($resource === 'fields') {

    if ($action === 'list') {
        $lid = lms_int($_GET['lesson_id'] ?? 0);
        if (!$lid) lms_error('lesson_id is required');
        $rows = [];
        $res  = $conn->query("SELECT * FROM lms_lesson_fields
                              WHERE lesson_id = $lid ORDER BY field_order ASC, id ASC");
        while ($res && ($f = $res->fetch_assoc())) {
            $f['id']               = (int)$f['id'];
            $f['field_order']      = (int)$f['field_order'];
            $f['is_required']      = (int)$f['is_required'];
            $f['max_file_size_mb'] = (int)$f['max_file_size_mb'];
            $f['options']          = lms_json_decode($f['options']);
            $rows[] = $f;
        }
        lms_ok(['fields' => $rows]);
    }

    if ($action === 'create' || $action === 'update') {
        $lid   = lms_int($in['lesson_id'] ?? 0);
        $label = trim($in['label'] ?? '');
        if ($action === 'create' && !$lid) lms_error('lesson_id is required');
        if ($label === '') lms_error('Field label is required');

        $sets = [
            "field_type = '"          . lms_esc($conn, $in['field_type'] ?? 'text') . "'",
            "label = '"               . lms_esc($conn, $label) . "'",
            "placeholder = '"         . lms_esc($conn, $in['placeholder'] ?? '') . "'",
            "help_text = '"           . lms_esc($conn, $in['help_text'] ?? '') . "'",
            'is_required = '          . (!empty($in['is_required']) ? 1 : 0),
            "accepted_extensions = '" . lms_esc($conn, $in['accepted_extensions'] ?? '') . "'",
            'max_file_size_mb = '     . lms_int($in['max_file_size_mb'] ?? 25, 25),
        ];
        $opts   = lms_json_col($in['options'] ?? null);
        $sets[] = 'options = ' . ($opts === null ? 'NULL' : "'" . lms_esc($conn, $opts) . "'");
        if (isset($in['status']) && in_array($in['status'], ['active', 'inactive'], true)) {
            $sets[] = "status = '" . $in['status'] . "'";
        }

        if ($action === 'create') {
            $r    = $conn->query("SELECT COALESCE(MAX(field_order), -1) + 1 n FROM lms_lesson_fields WHERE lesson_id = $lid");
            $next = $r ? (int)$r->fetch_assoc()['n'] : 0;
            $sets[] = "lesson_id = $lid";
            $sets[] = "field_order = $next";
            $conn->query('INSERT INTO lms_lesson_fields SET ' . implode(', ', $sets));
            lms_ok(['id' => $conn->insert_id], 'Field added');
        }

        $id = lms_int($in['id'] ?? 0);
        if (!$id) lms_error('Field id is required');
        $conn->query('UPDATE lms_lesson_fields SET ' . implode(', ', $sets) . " WHERE id = $id");
        lms_ok(['id' => $id], 'Field updated');
    }

    if ($action === 'toggle') {
        $id = lms_int($in['id'] ?? 0);
        if (!$id) lms_error('Field id is required');
        $conn->query("UPDATE lms_lesson_fields
                      SET status = IF(status = 'active', 'inactive', 'active') WHERE id = $id");
        lms_ok(null, 'Field toggled');
    }

    if ($action === 'delete') {
        $id = lms_int($in['id'] ?? 0);
        if (!$id) lms_error('Field id is required');
        $conn->query("DELETE FROM lms_lesson_fields WHERE id = $id");
        lms_ok(null, 'Field removed');
    }

    if ($action === 'reorder') {
        $order = $in['order'] ?? [];
        foreach ((array)$order as $i => $fid) {
            $conn->query('UPDATE lms_lesson_fields SET field_order = ' . (int)$i . ' WHERE id = ' . (int)$fid);
        }
        lms_ok(null, 'Fields reordered');
    }

    lms_error('Unknown fields action: ' . $action);
}

/* ───────────────────────── FORM RESPONSES ───────────────────────── */
if ($resource === 'responses') {

    if ($action === 'list') {
        $lid    = lms_int($_GET['lesson_id'] ?? 0);
        $cid    = lms_int($_GET['course_id'] ?? 0);
        $limit  = min(500, max(1, lms_int($_GET['limit'] ?? 100, 100)));
        $offset = max(0, lms_int($_GET['offset'] ?? 0));

        $where = [];
        if ($lid) $where[] = "r.lesson_id = $lid";
        if ($cid) $where[] = "r.course_id = $cid";
        $w = $where ? 'WHERE ' . implode(' AND ', $where) : '';

        $tr    = $conn->query("SELECT COUNT(*) c FROM lms_form_responses r $w");
        $total = $tr ? (int)$tr->fetch_assoc()['c'] : 0;

        $rows = [];
        $res = $conn->query("SELECT r.*, u.name, u.email, u.phone, l.title lesson_title, c.title course_title
                             FROM lms_form_responses r
                             LEFT JOIN users u       ON u.user_id = r.user_id
                             LEFT JOIN lms_lessons l ON l.id = r.lesson_id
                             LEFT JOIN lms_courses c ON c.id = r.course_id
                             $w ORDER BY r.created_at DESC LIMIT $limit OFFSET $offset");
        while ($res && ($r = $res->fetch_assoc())) {
            $r['id']      = (int)$r['id'];
            $r['payload'] = lms_json_decode($r['payload']);
            $rows[] = $r;
        }
        lms_ok(['responses' => $rows, 'total' => $total]);
    }

    if ($action === 'delete') {
        $id = lms_int($in['id'] ?? 0);
        if (!$id) lms_error('Response id is required');
        $conn->query("DELETE FROM lms_form_responses WHERE id = $id");
        lms_ok(null, 'Response deleted');
    }

    lms_error('Unknown responses action: ' . $action);
}

/* ───────────────────────── QUIZZES ───────────────────────── */
if ($resource === 'quizzes') {

    if ($action === 'list') {
        $cid   = lms_int($_GET['course_id'] ?? 0);
        $q     = trim($_GET['q'] ?? '');
        $where = [];
        if ($cid) $where[] = "q.course_id = $cid";
        if ($q !== '') $where[] = "q.title LIKE '%" . lms_esc($conn, $q) . "%'";
        $w = $where ? 'WHERE ' . implode(' AND ', $where) : '';

        $rows = [];
        $res = $conn->query("SELECT q.*, c.title course_title,
                                (SELECT COUNT(*) FROM lms_quiz_questions qq
                                   WHERE qq.quiz_id = q.id AND qq.status='active') question_count,
                                (SELECT COALESCE(SUM(qq.marks),0) FROM lms_quiz_questions qq
                                   WHERE qq.quiz_id = q.id AND qq.status='active') total_marks,
                                (SELECT COUNT(*) FROM lms_quiz_attempts a WHERE a.quiz_id = q.id) attempt_count,
                                (SELECT COALESCE(AVG(a.percentage),0) FROM lms_quiz_attempts a WHERE a.quiz_id = q.id) avg_score
                             FROM lms_quizzes q
                             LEFT JOIN lms_courses c ON c.id = q.course_id
                             $w ORDER BY q.id DESC");
        while ($res && ($r = $res->fetch_assoc())) {
            $r['id']             = (int)$r['id'];
            $r['course_id']      = (int)$r['course_id'];
            $r['question_count'] = (int)$r['question_count'];
            $r['total_marks']    = (float)$r['total_marks'];
            $r['attempt_count']  = (int)$r['attempt_count'];
            $r['avg_score']      = round((float)$r['avg_score'], 1);
            $rows[] = $r;
        }
        lms_ok(['quizzes' => $rows]);
    }

    if ($action === 'get') {
        $id  = lms_int($_GET['id'] ?? 0);
        $res = $conn->query("SELECT * FROM lms_quizzes WHERE id = $id");
        $q   = $res ? $res->fetch_assoc() : null;
        if (!$q) lms_error('Quiz not found', 404);
        $q['id'] = (int)$q['id'];

        $questions = [];
        $qr = $conn->query("SELECT * FROM lms_quiz_questions WHERE quiz_id = $id ORDER BY sort_order ASC, id ASC");
        while ($qr && ($row = $qr->fetch_assoc())) {
            $row['id']         = (int)$row['id'];
            $row['marks']      = (float)$row['marks'];
            $row['negative_marks'] = (float)$row['negative_marks'];
            $row['sort_order'] = (int)$row['sort_order'];
            $row['options']    = lms_json_decode($row['options']);
            $row['correct']    = lms_json_decode($row['correct']);
            $questions[] = $row;
        }
        lms_ok(['quiz' => $q, 'questions' => $questions]);
    }

    if ($action === 'create' || $action === 'update') {
        $title = trim($in['title'] ?? '');
        if ($title === '') lms_error('Quiz title is required');

        $sets = [
            "title = '"        . lms_esc($conn, $title) . "'",
            "description = '"  . lms_esc($conn, $in['description'] ?? '') . "'",
            "instructions = '" . lms_esc($conn, $in['instructions'] ?? '') . "'",
            'course_id = '        . lms_int($in['course_id'] ?? 0),
            'duration_mins = '    . lms_int($in['duration_mins'] ?? 0),
            'pass_percentage = '  . lms_int($in['pass_percentage'] ?? 40, 40),
            'max_attempts = '     . lms_int($in['max_attempts'] ?? 0),
            'shuffle_questions = '. (!empty($in['shuffle_questions']) ? 1 : 0),
            'shuffle_options = '  . (!empty($in['shuffle_options'])   ? 1 : 0),
            'negative_marking = ' . (!empty($in['negative_marking'])  ? 1 : 0),
            'show_result = '      . (!empty($in['show_result'])       ? 1 : 0),
            'is_graded = '        . (!empty($in['is_graded'])         ? 1 : 0),
        ];
        if (in_array($in['show_answers'] ?? '', ['never', 'after_submit', 'after_pass'], true)) {
            $sets[] = "show_answers = '" . $in['show_answers'] . "'";
        }
        if (in_array($in['status'] ?? '', ['draft', 'published'], true)) {
            $sets[] = "status = '" . $in['status'] . "'";
        }

        if ($action === 'create') {
            $conn->query('INSERT INTO lms_quizzes SET ' . implode(', ', $sets));
            lms_ok(['id' => $conn->insert_id], 'Quiz created');
        }
        $id = lms_int($in['id'] ?? 0);
        if (!$id) lms_error('Quiz id is required');
        $conn->query('UPDATE lms_quizzes SET ' . implode(', ', $sets) . " WHERE id = $id");
        lms_ok(['id' => $id], 'Quiz updated');
    }

    if ($action === 'toggle') {
        $id = lms_int($in['id'] ?? 0);
        if (!$id) lms_error('Quiz id is required');
        $conn->query("UPDATE lms_quizzes
                      SET status = IF(status = 'published', 'draft', 'published') WHERE id = $id");
        lms_ok(null, 'Quiz status changed');
    }

    if ($action === 'duplicate') {
        $id = lms_int($in['id'] ?? 0);
        if (!$id) lms_error('Quiz id is required');
        $r = $conn->query("SELECT title FROM lms_quizzes WHERE id = $id");
        $t = $r ? ($r->fetch_assoc()['title'] ?? '') : '';
        if ($t === '') lms_error('Quiz not found', 404);
        $nt = lms_esc($conn, $t . ' (Copy)');
        $conn->query("INSERT INTO lms_quizzes
            (course_id, title, description, instructions, duration_mins, pass_percentage,
             max_attempts, shuffle_questions, shuffle_options, show_answers, negative_marking,
             show_result, is_graded, status)
            SELECT course_id, '$nt', description, instructions, duration_mins, pass_percentage,
                   max_attempts, shuffle_questions, shuffle_options, show_answers, negative_marking,
                   show_result, is_graded, 'draft'
            FROM lms_quizzes WHERE id = $id");
        $newId = $conn->insert_id;
        $conn->query("INSERT INTO lms_quiz_questions
            (quiz_id, question_type, question, image_url, options, correct, marks,
             negative_marks, explanation, difficulty, sort_order, status)
            SELECT $newId, question_type, question, image_url, options, correct, marks,
                   negative_marks, explanation, difficulty, sort_order, status
            FROM lms_quiz_questions WHERE quiz_id = $id");
        lms_ok(['id' => $newId], 'Quiz duplicated');
    }

    if ($action === 'delete') {
        $id = lms_int($in['id'] ?? 0);
        if (!$id) lms_error('Quiz id is required');
        $conn->query("DELETE FROM lms_quiz_questions WHERE quiz_id = $id");
        $conn->query("DELETE FROM lms_quiz_attempts  WHERE quiz_id = $id");
        $conn->query("UPDATE lms_lessons SET quiz_id = 0 WHERE quiz_id = $id");
        $conn->query("DELETE FROM lms_quizzes WHERE id = $id");
        lms_ok(null, 'Quiz deleted');
    }

    lms_error('Unknown quizzes action: ' . $action);
}

/* ───────────────────────── QUIZ QUESTIONS ───────────────────────── */
if ($resource === 'questions') {

    if ($action === 'create' || $action === 'update') {
        $qid  = lms_int($in['quiz_id'] ?? 0);
        $text = trim($in['question'] ?? '');
        if ($action === 'create' && !$qid) lms_error('quiz_id is required');
        if ($text === '') lms_error('Question text is required');

        $sets = [
            "question_type = '" . lms_esc($conn, $in['question_type'] ?? 'single') . "'",
            "question = '"      . lms_esc($conn, $text) . "'",
            "image_url = '"     . lms_esc($conn, $in['image_url'] ?? '') . "'",
            "explanation = '"   . lms_esc($conn, $in['explanation'] ?? '') . "'",
            'marks = '          . (float)($in['marks'] ?? 1),
            'negative_marks = ' . (float)($in['negative_marks'] ?? 0),
        ];
        if (in_array($in['difficulty'] ?? '', ['easy', 'medium', 'hard'], true)) {
            $sets[] = "difficulty = '" . $in['difficulty'] . "'";
        }
        if (in_array($in['status'] ?? '', ['active', 'inactive'], true)) {
            $sets[] = "status = '" . $in['status'] . "'";
        }
        $o = lms_json_col($in['options'] ?? null);
        $c = lms_json_col($in['correct'] ?? null);
        $sets[] = 'options = ' . ($o === null ? 'NULL' : "'" . lms_esc($conn, $o) . "'");
        $sets[] = 'correct = ' . ($c === null ? 'NULL' : "'" . lms_esc($conn, $c) . "'");

        if ($action === 'create') {
            $r    = $conn->query("SELECT COALESCE(MAX(sort_order), -1) + 1 n FROM lms_quiz_questions WHERE quiz_id = $qid");
            $next = $r ? (int)$r->fetch_assoc()['n'] : 0;
            $sets[] = "quiz_id = $qid";
            $sets[] = "sort_order = $next";
            $conn->query('INSERT INTO lms_quiz_questions SET ' . implode(', ', $sets));
            lms_ok(['id' => $conn->insert_id], 'Question added');
        }
        $id = lms_int($in['id'] ?? 0);
        if (!$id) lms_error('Question id is required');
        $conn->query('UPDATE lms_quiz_questions SET ' . implode(', ', $sets) . " WHERE id = $id");
        lms_ok(['id' => $id], 'Question updated');
    }

    /* paste-a-block bulk import — one question per line:
       "Question text | option A | option B* | option C"  (* marks the answer) */
    if ($action === 'bulk_create') {
        $qid   = lms_int($in['quiz_id'] ?? 0);
        $lines = preg_split('/\r\n|\r|\n/', (string)($in['text'] ?? ''));
        if (!$qid) lms_error('quiz_id is required');

        $r    = $conn->query("SELECT COALESCE(MAX(sort_order), -1) + 1 n FROM lms_quiz_questions WHERE quiz_id = $qid");
        $next = $r ? (int)$r->fetch_assoc()['n'] : 0;

        $added = 0; $skipped = [];
        foreach ($lines as $ln => $line) {
            $line = trim($line);
            if ($line === '') continue;
            $parts = array_map('trim', explode('|', $line));
            $text  = array_shift($parts);
            if ($text === '' || count($parts) < 2) { $skipped[] = 'Line ' . ($ln + 1) . ': needs a question and at least 2 options'; continue; }

            $opts = []; $correct = [];
            foreach ($parts as $i => $p) {
                $isAns = substr($p, -1) === '*';
                if ($isAns) $p = rtrim(substr($p, 0, -1));
                $val = 'opt_' . ($i + 1);
                $opts[] = ['value' => $val, 'label' => $p];
                if ($isAns) $correct[] = $val;
            }
            if (!$correct) { $skipped[] = 'Line ' . ($ln + 1) . ': no option marked with *'; continue; }

            $type = count($correct) > 1 ? 'multi' : 'single';
            $conn->query("INSERT INTO lms_quiz_questions
                (quiz_id, question_type, question, options, correct, marks, sort_order)
                VALUES ($qid, '$type',
                        '" . lms_esc($conn, $text) . "',
                        '" . lms_esc($conn, json_encode($opts))    . "',
                        '" . lms_esc($conn, json_encode($correct)) . "',
                        " . (float)($in['marks'] ?? 1) . ", " . ($next + $added) . ")");
            $added++;
        }
        lms_ok(['added' => $added, 'skipped' => $skipped],
               $added . ' question' . ($added === 1 ? '' : 's') . ' imported');
    }

    if ($action === 'delete') {
        $id = lms_int($in['id'] ?? 0);
        if (!$id) lms_error('Question id is required');
        $conn->query("DELETE FROM lms_quiz_questions WHERE id = $id");
        lms_ok(null, 'Question deleted');
    }

    if ($action === 'reorder') {
        $order = $in['order'] ?? [];
        foreach ((array)$order as $i => $qq) {
            $conn->query('UPDATE lms_quiz_questions SET sort_order = ' . (int)$i . ' WHERE id = ' . (int)$qq);
        }
        lms_ok(null, 'Questions reordered');
    }

    lms_error('Unknown questions action: ' . $action);
}

/* ───────────────────────── QUIZ ATTEMPTS ───────────────────────── */
if ($resource === 'attempts') {

    if ($action === 'list') {
        $qid    = lms_int($_GET['quiz_id'] ?? 0);
        $uid    = lms_int($_GET['user_id'] ?? 0);
        $limit  = min(500, max(1, lms_int($_GET['limit'] ?? 100, 100)));
        $offset = max(0, lms_int($_GET['offset'] ?? 0));

        $where = [];
        if ($qid) $where[] = "a.quiz_id = $qid";
        if ($uid) $where[] = "a.user_id = $uid";
        $w = $where ? 'WHERE ' . implode(' AND ', $where) : '';

        $tr    = $conn->query("SELECT COUNT(*) c FROM lms_quiz_attempts a $w");
        $total = $tr ? (int)$tr->fetch_assoc()['c'] : 0;

        $rows = [];
        $res = $conn->query("SELECT a.*, u.name, u.email, q.title quiz_title
                             FROM lms_quiz_attempts a
                             LEFT JOIN users u       ON u.user_id = a.user_id
                             LEFT JOIN lms_quizzes q ON q.id = a.quiz_id
                             $w ORDER BY a.submitted_at DESC LIMIT $limit OFFSET $offset");
        while ($res && ($r = $res->fetch_assoc())) {
            $r['id']         = (int)$r['id'];
            $r['score']      = (float)$r['score'];
            $r['percentage'] = (float)$r['percentage'];
            $r['passed']     = (int)$r['passed'];
            unset($r['answers']);   // keep the list payload light
            $rows[] = $r;
        }
        lms_ok(['attempts' => $rows, 'total' => $total]);
    }

    if ($action === 'get') {
        $id  = lms_int($_GET['id'] ?? 0);
        $res = $conn->query("SELECT a.*, u.name, u.email FROM lms_quiz_attempts a
                             LEFT JOIN users u ON u.user_id = a.user_id WHERE a.id = $id");
        $a = $res ? $res->fetch_assoc() : null;
        if (!$a) lms_error('Attempt not found', 404);
        $a['answers'] = lms_json_decode($a['answers']);
        lms_ok(['attempt' => $a]);
    }

    if ($action === 'delete') {
        $id = lms_int($in['id'] ?? 0);
        if (!$id) lms_error('Attempt id is required');
        $conn->query("DELETE FROM lms_quiz_attempts WHERE id = $id");
        lms_ok(null, 'Attempt deleted');
    }

    lms_error('Unknown attempts action: ' . $action);
}

/* ───────────────────────── LEARNERS ─────────────────────────
   The learner pool is the existing `users` table. By default we show only
   users who actually bought something (internship_payment) or who are already
   enrolled in an LMS course — "scope=all" widens it to every registered user.
   ─────────────────────────────────────────────────────────── */
if ($resource === 'learners') {

    /* ── list ────────────────────────────────────────────────────────────
       A learner is anyone who appears in ANY of the four places we sell or
       grant access from:

         internship_payment        a paid internship
         payment_status            an internship checkout (incl. failed/initiated)
         ninety_nine_store_orders  a ₹99-store course, or a row an admin added here
         lms_enrollments           granted an LMS course directly

       Three of those key on users.user_id; the store keys on email and may
       have no account at all. So the identity of a row is user_id when there
       is one and the lowercased email when there is not — that is what makes
       "unique users" well defined across all four.

       The query runs in two phases ON PURPOSE. Phase 1 resolves just the page
       of identities (ids and emails, LIMIT applied). Phase 2 then fetches the
       counters for those <=200 identities with a handful of grouped queries.
       The obvious one-query version puts six correlated subqueries in the
       SELECT list of a UNION, which MySQL evaluates for every candidate row
       BEFORE the LIMIT — on this users table that is the ~25s response the
       old buyers scope was already rewritten once to avoid. Keep both phases.
       ───────────────────────────────────────────────────────────────────── */
    if ($action === 'list') {
        $q        = trim($_GET['q'] ?? '');
        $source   = $_GET['source'] ?? 'all';    // all|internship|store|admin|lms|registered
        $scope    = $_GET['scope']  ?? '';       // legacy: buyers|enrolled|all
        $course   = lms_int($_GET['course_id'] ?? 0);
        $intern   = trim($_GET['internship'] ?? '');
        /* Completed purchases only, unless the caller asks otherwise.
           payment_status records every checkout ATTEMPT, and abandoned ones
           outnumber paid ones several times over. Including them put ~270k
           people in this list who never bought anything — and because they
           have no internship_payment row and no store order, every counter
           column rendered as "—". A row of dashes is not a learner. */
        $pstatus  = strtolower(trim($_GET['pay_status'] ?? 'success')); // success|initiated|failed|any
        $provider = strtolower(trim($_GET['provider'] ?? ''));    // razorpay|cashfree
        $account  = $_GET['account'] ?? '';      // yes = has a users row, no = store-only
        $active   = $_GET['active']  ?? '';      // 1 | 0
        $from     = trim($_GET['from'] ?? '');
        $to       = trim($_GET['to'] ?? '');
        $sort     = $_GET['sort'] ?? 'recent';   // recent|oldest|name
        $limit    = min(200, max(1, lms_int($_GET['limit'] ?? 30, 30)));
        $offset   = max(0, lms_int($_GET['offset'] ?? 0));

        /* The old UI sent scope=buyers|enrolled|all. Map it forward so a tab
           left open on the previous build does not silently change population. */
        if ($source === 'all' && $scope !== '') {
            if ($scope === 'buyers')   $source = 'internship';
            if ($scope === 'enrolled') $source = 'lms';
        }

        $hasStore = lms_table_exists($conn, 'ninety_nine_store_orders');
        $dFrom = preg_match('/^\d{4}-\d{2}-\d{2}$/', $from) ? $from : '';
        $dTo   = preg_match('/^\d{4}-\d{2}-\d{2}$/', $to)   ? $to   : '';

        /* ── phase 1: the identity pool ───────────────────────────────── */
        $storeWhere = ['1'];
        if ($source === 'admin') $storeWhere[] = "o.source = 'admin'";
        if ($source === 'store') $storeWhere[] = "o.source <> 'admin'";
        if ($pstatus === 'any') $pstatus = '';
        if ($pstatus !== '' && in_array($pstatus, ['initiated', 'success', 'failed'], true)) {
            $storeWhere[] = "o.status = '" . lms_esc($conn, $pstatus) . "'";
        }
        if ($provider !== '') $storeWhere[] = "o.provider = '" . lms_esc($conn, $provider) . "'";
        if ($dFrom !== '')    $storeWhere[] = "DATE(o.created_at) >= '$dFrom'";
        if ($dTo !== '')      $storeWhere[] = "DATE(o.created_at) <= '$dTo'";
        $storeW = implode(' AND ', $storeWhere);

        $psWhere = ['1'];
        if ($pstatus !== '') $psWhere[] = "ps.status = '" . lms_esc($conn, $pstatus) . "'";
        if ($dFrom !== '')   $psWhere[] = "DATE(ps.timestamp) >= '$dFrom'";
        if ($dTo !== '')     $psWhere[] = "DATE(ps.timestamp) <= '$dTo'";
        $psW = implode(' AND ', $psWhere);

        $ipWhere = ['1'];
        if ($intern !== '') $ipWhere[] = "ip.internship = '" . lms_esc($conn, $intern) . "'";
        if ($dFrom !== '')  $ipWhere[] = "DATE(ip.paid_at) >= '$dFrom'";
        if ($dTo !== '')    $ipWhere[] = "DATE(ip.paid_at) <= '$dTo'";
        $ipW = implode(' AND ', $ipWhere);

        /* Each branch yields (user_id, email). Store rows carry an email even
           when user_id is NULL — that is what the email fallback exists for.

           DISTINCT inside every branch is load-bearing, not tidiness. A buyer
           with nine internship payments contributes nine identical rows to the
           union without it, and payment_status is the largest table of the
           four. With user_id indexed each branch collapses to an index-only
           scan, so what reaches the outer GROUP BY is roughly one row per
           person per source rather than one row per transaction. */
        $parts = [];
        if ($source === 'all' || $source === 'internship') {
            $parts[] = "SELECT DISTINCT ip.user_id, NULL AS email FROM internship_payment ip WHERE $ipW";
            $parts[] = "SELECT DISTINCT ps.user_id, NULL AS email FROM payment_status ps WHERE $psW";
        }
        if ($source === 'all' || $source === 'lms') {
            $lw = $course ? "WHERE le.course_id = $course" : '';
            $parts[] = "SELECT DISTINCT le.user_id, NULL AS email FROM lms_enrollments le $lw";
        }
        if ($hasStore && in_array($source, ['all', 'store', 'admin'], true)) {
            $parts[] = "SELECT DISTINCT o.user_id, " . lms_col('LOWER(o.email)') . " AS email
                          FROM ninety_nine_store_orders o WHERE $storeW";
        }
        if ($source === 'registered') {
            /* Everyone with an account, bought or not — the widest view. */
            $parts = ["SELECT u.user_id, NULL AS email FROM users u WHERE u.user_id > 0"];
        }
        if (!$parts) $parts = ["SELECT NULL AS user_id, NULL AS email FROM users WHERE 0"];

        /* UNION, not UNION ALL + GROUP BY.
           The GROUP BY version materialised every transaction row (roughly
           700k across the four sources) into a temp table and only then
           collapsed it — which is where the 12s went. UNION dedupes as it
           writes, through the temp table's own unique key, so the same result
           costs one pass instead of two and never holds the un-collapsed set
           in memory. Each branch is already DISTINCT, so the merge is small.

           The identity column is built here rather than per branch so the
           expression, and therefore its collation, is defined exactly once. */
        $pool = "SELECT COALESCE(" . lms_col('CAST(pool.user_id AS CHAR)') . ",
                                  " . lms_col("CONCAT('e:', pool.email)") . ") AS ident,
                        pool.user_id, pool.email
                   FROM (" . implode(' UNION ', $parts) . ") pool
                  WHERE pool.user_id IS NOT NULL OR pool.email IS NOT NULL";

        /* Filters that need the users row hang off the join below. */
        $idWhere = ['1'];
        if ($account === 'yes') $idWhere[] = 'p.user_id IS NOT NULL';
        if ($account === 'no')  $idWhere[] = 'p.user_id IS NULL';
        if ($active === '1' || $active === '0') $idWhere[] = 'u.active = ' . (int)$active;
        if ($q !== '') {
            $qe = lms_esc($conn, $q);
            $idWhere[] = "(u.email LIKE '%$qe%' OR u.name LIKE '%$qe%'
                           OR u.phone LIKE '%$qe%' OR p.email LIKE '%$qe%')";
        }
        $idW = 'WHERE ' . implode(' AND ', $idWhere);

        $order = 'ORDER BY p.user_id DESC';
        if ($sort === 'oldest') $order = 'ORDER BY p.user_id ASC';
        if ($sort === 'name')   $order = 'ORDER BY COALESCE(' . lms_col('u.name') . ', '
                                        . lms_col('p.email') . ') ASC';

        /* The join to users is only needed when a filter actually reads a
           users column — otherwise counting the pool alone is the same number
           for a fraction of the work. */
        $needsUser = $active !== '' || $q !== '';
        $countSql  = $needsUser
            ? "SELECT COUNT(*) c FROM ($pool) p LEFT JOIN users u ON u.user_id = p.user_id $idW"
            : "SELECT COUNT(*) c FROM ($pool) p $idW";
        $total = lms_cached_count($conn, 'learners|' . $countSql, $countSql);
        if ($total === null) lms_error('Could not count learners: ' . $conn->error, 500);

        $res = $conn->query("SELECT p.ident, p.user_id, p.email pool_email,
                                    u.name, u.fname, u.lname, u.email, u.phone,
                                    u.active, u.registered_at created_at
                               FROM ($pool) p
                               LEFT JOIN users u ON u.user_id = p.user_id
                               $idW $order LIMIT $limit OFFSET $offset");
        if ($res === false) lms_error('Could not read learners: ' . $conn->error, 500);

        $rows = []; $uids = []; $emails = [];
        while ($r = $res->fetch_assoc()) {
            $uid   = $r['user_id'] !== null ? (int)$r['user_id'] : 0;
            $email = strtolower((string)($r['email'] ?: $r['pool_email'] ?: ''));
            if ($uid)          $uids[]   = $uid;
            if ($email !== '') $emails[] = "'" . lms_esc($conn, $email) . "'";

            $rows[$r['ident']] = [
                'ident'        => $r['ident'],
                'user_id'      => $uid,
                'has_account'  => $uid > 0,
                'name'         => $r['name'],
                'fname'        => $r['fname'],
                'lname'        => $r['lname'],
                'email'        => $email,
                'phone'        => $r['phone'],
                'active'       => $r['active'],
                'created_at'   => $r['created_at'],
                'purchases'    => 0,  'internships'   => null, 'last_paid_at' => null,
                'store_orders' => 0,  'store_courses' => null, 'store_spend'  => 0.0,
                'lms_courses'  => 0,  'lessons_done'  => 0,    'quiz_attempts' => 0,
                'sources'      => [],
            ];
        }

        /* ── phase 2: counters, only for the rows on this page ─────────── */
        if ($rows) {
            $uidList   = $uids   ? implode(',', array_unique($uids))   : '';
            $emailList = $emails ? implode(',', array_unique($emails)) : '';

            $byUid = []; $byEmail = [];
            foreach ($rows as $k => $r) {
                if ($r['user_id'])     $byUid[$r['user_id']] = $k;
                if ($r['email'] !== '') $byEmail[$r['email']] = $k;
            }

            $apply = function ($sql, $key, $fn) use ($conn, &$rows, $byUid, $byEmail) {
                $res = $conn->query($sql);
                while ($res && ($r = $res->fetch_assoc())) {
                    $k = $key === 'uid'
                        ? ($byUid[(int)$r['k']] ?? null)
                        : ($byEmail[strtolower((string)$r['k'])] ?? null);
                    if ($k !== null) $fn($rows[$k], $r);
                }
            };

            if ($uidList !== '') {
                $apply("SELECT user_id k, COUNT(*) n,
                               GROUP_CONCAT(DISTINCT internship SEPARATOR ', ') list,
                               MAX(paid_at) last_at
                          FROM internship_payment WHERE user_id IN ($uidList) GROUP BY user_id",
                    'uid', function (&$row, $r) {
                        $row['purchases']    = (int)$r['n'];
                        $row['internships']  = $r['list'];
                        $row['last_paid_at'] = $r['last_at'];
                        if ((int)$r['n'] > 0) $row['sources'][] = 'internship';
                    });

                /* internship_payment is the fulfilment table and payment_status
                   is the checkout table, and they do not always agree — an old
                   payment can sit in one without the other. Reading both is
                   what stops a genuine buyer showing an empty Internships
                   column just because their row landed in the other table.
                   Counters merge rather than overwrite for the same reason. */
                $apply("SELECT user_id k, COUNT(*) n,
                               GROUP_CONCAT(DISTINCT internship_name SEPARATOR ', ') list,
                               MAX(timestamp) last_at
                          FROM payment_status
                         WHERE user_id IN ($uidList) AND status = 'success'
                         GROUP BY user_id",
                    'uid', function (&$row, $r) {
                        $row['purchases'] = max($row['purchases'], (int)$r['n']);
                        if (empty($row['internships'])) $row['internships'] = $r['list'];
                        if (empty($row['last_paid_at'])) $row['last_paid_at'] = $r['last_at'];
                        if ((int)$r['n'] > 0) $row['sources'][] = 'internship';
                    });

                $apply("SELECT user_id k, COUNT(*) n FROM lms_enrollments
                         WHERE user_id IN ($uidList) AND status = 'active' GROUP BY user_id",
                    'uid', function (&$row, $r) {
                        $row['lms_courses'] = (int)$r['n'];
                        if ((int)$r['n'] > 0) $row['sources'][] = 'lms';
                    });

                $apply("SELECT user_id k, COUNT(*) n FROM lms_progress
                         WHERE user_id IN ($uidList) AND status = 'completed' GROUP BY user_id",
                    'uid', function (&$row, $r) { $row['lessons_done'] = (int)$r['n']; });

                $apply("SELECT user_id k, COUNT(*) n FROM lms_quiz_attempts
                         WHERE user_id IN ($uidList) GROUP BY user_id",
                    'uid', function (&$row, $r) { $row['quiz_attempts'] = (int)$r['n']; });
            }

            /* Store rows are matched by user_id where we have one and by email
               where we do not, so each keying needs its own pass. */
            if ($hasStore) {
                $agg = "COUNT(*) n,
                        GROUP_CONCAT(DISTINCT course_name SEPARATOR ', ') list,
                        SUM(CASE WHEN status = 'success' THEN amount ELSE 0 END) spend,
                        MAX(CASE WHEN source = 'admin' THEN 1 ELSE 0 END) by_admin";
                $fill = function (&$row, $r) {
                    $row['store_orders']  = (int)$r['n'];
                    $row['store_courses'] = $r['list'];
                    $row['store_spend']   = (float)$r['spend'];
                    $row['sources'][]     = (int)$r['by_admin'] ? 'admin' : 'store';
                };
                if ($uidList !== '') {
                    $apply("SELECT user_id k, $agg FROM ninety_nine_store_orders
                             WHERE user_id IN ($uidList) GROUP BY user_id", 'uid', $fill);
                }
                if ($emailList !== '') {
                    $apply("SELECT LOWER(email) k, $agg FROM ninety_nine_store_orders
                             WHERE user_id IS NULL AND LOWER(email) IN ($emailList)
                             GROUP BY LOWER(email)", 'email', $fill);
                }
            }
        }

        foreach ($rows as &$r) {
            $r['sources'] = array_values(array_unique($r['sources']));
            if (!$r['name'] && $r['email']) $r['name'] = $r['email'];
        }
        unset($r);

        lms_ok([
            'learners' => array_values($rows),
            'total'    => $total,
            'provider' => lms_active_payment_provider($conn),
        ]);
    }

    if ($action === 'get') {
        $uid = lms_int($_GET['user_id'] ?? 0);
        if (!$uid) lms_error('user_id is required');
        $res = $conn->query("SELECT user_id, name, fname, lname, email, phone, state, country, active, registered_at created_at
                             FROM users WHERE user_id = $uid");
        $u = $res ? $res->fetch_assoc() : null;
        if (!$u) lms_error('Learner not found', 404);

        $enr = [];
        $r = $conn->query("SELECT e.*, c.title course_title FROM lms_enrollments e
                           LEFT JOIN lms_courses c ON c.id = e.course_id
                           WHERE e.user_id = $uid ORDER BY e.enrolled_at DESC");
        while ($r && ($row = $r->fetch_assoc())) $enr[] = $row;

        $att = [];
        $r = $conn->query("SELECT a.id, a.quiz_id, a.score, a.total_marks, a.percentage, a.passed,
                                  a.submitted_at, q.title quiz_title
                           FROM lms_quiz_attempts a
                           LEFT JOIN lms_quizzes q ON q.id = a.quiz_id
                           WHERE a.user_id = $uid ORDER BY a.submitted_at DESC LIMIT 25");
        while ($r && ($row = $r->fetch_assoc())) $att[] = $row;

        $pur = [];
        $r = $conn->query("SELECT internship, batch, paid_at, payment_id
                           FROM internship_payment WHERE user_id = $uid ORDER BY paid_at DESC");
        while ($r && ($row = $r->fetch_assoc())) $pur[] = $row;

        lms_ok(['learner' => $u, 'enrollments' => $enr, 'attempts' => $att, 'purchases' => $pur]);
    }

    /* Add one learner by hand.
       Always writes a ninety_nine_store_orders row so the purchase shows up in
       the same places a real ₹99 checkout would. Whether a users account is
       ALSO created is the admin's choice (create_account, default on): with it
       the learner can sign in and the order carries their user_id; without it
       the order is stored against the email alone and user_id stays NULL. */
    if ($action === 'create') {
        $email = strtolower(trim($in['email'] ?? ''));
        $name  = trim($in['name'] ?? '');
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) lms_error('A valid learner email is required');
        if ($name === '') lms_error('Learner full name is required');

        $createAccount = !isset($in['create_account']) || (string)$in['create_account'] === '1'
                         || $in['create_account'] === true;

        $who = lms_resolve_learner($conn, $email, $name, $in['phone'] ?? '',
                                   (string)($in['password'] ?? ''), $createAccount);
        if (!empty($who['error'])) lms_error($who['error'], 500);
        $uid = (int)$who['user_id'];

        $order = lms_store_order_insert($conn, [
            'user_id'     => $uid,
            'name'        => $name,
            'email'       => $email,
            'phone'       => $in['phone'] ?? '',
            'state'       => $in['state'] ?? '',
            'course_name' => $in['course_name'] ?? '',
            'course_slug' => $in['course_slug'] ?? '',
            'batch'       => $in['batch'] ?? '',
            'amount'      => $in['amount'] ?? 0,
            'status'      => $in['order_status'] ?? 'success',
        ]);
        if (!$order['ok']) lms_error('Could not record the order: ' . $order['message'], 500);

        /* Only an account can be enrolled into an LMS course — there is no
           user_id to hang the enrolment on otherwise. */
        $cid = lms_int($in['course_id'] ?? 0);
        if ($cid && $uid) lms_enroll($conn, $cid, $uid, $in);

        lms_ok([
            'user_id'  => $uid,
            'order_id' => $order['id'],
            'existing' => $uid > 0 && !$who['created'],
            'account'  => $uid > 0,
            'password' => $who['password'],
            'provider' => lms_active_payment_provider($conn),
        ], $who['created']
            ? 'Learner registered and order recorded'
            : ($uid > 0
                ? 'Order recorded against the existing account'
                : 'Order recorded — no account exists for this email yet'));
    }

    /* CSV import — step 1: parse headers + suggest a mapping (upload -> map -> run,
       same three-step shape as the Netcore contact importer) */
    if ($action === 'import_preview') {
        if (empty($_FILES['file'])) lms_error('No CSV file uploaded');
        $tmp = $_FILES['file']['tmp_name'];
        if (!is_uploaded_file($tmp)) lms_error('Upload failed');

        $fh = fopen($tmp, 'r');
        if (!$fh) lms_error('Could not read the uploaded file');
        $headers = fgetcsv($fh);
        if (!$headers) { fclose($fh); lms_error('The CSV appears to be empty'); }
        $headers = array_map(fn($h) => trim((string)$h, " \t\n\r\0\x0B\xEF\xBB\xBF"), $headers);

        $sample = fgetcsv($fh) ?: [];
        $rows   = 0;
        rewind($fh); fgetcsv($fh);
        while (fgetcsv($fh) !== false) $rows++;
        fclose($fh);

        /* stash the file so import_run doesn't need a second upload */
        $token = bin2hex(random_bytes(12));
        $dir   = sys_get_temp_dir() . '/lms_imports';
        if (!is_dir($dir)) @mkdir($dir, 0700, true);
        @copy($tmp, "$dir/$token.csv");

        $guess = [];
        foreach ($headers as $h) {
            $k = strtolower(preg_replace('/[^a-z0-9]/i', '', $h));
            if (in_array($k, ['email', 'emailaddress', 'mail'], true))            $guess[$h] = 'email';
            elseif (in_array($k, ['name', 'fullname', 'learnername'], true))      $guess[$h] = 'name';
            elseif (in_array($k, ['phone', 'mobile', 'phonenumber', 'contact'], true)) $guess[$h] = 'phone';
            elseif (in_array($k, ['amount', 'price', 'paid'], true))              $guess[$h] = 'amount';
            elseif (in_array($k, ['expiry', 'expirydate', 'validtill'], true))    $guess[$h] = 'expiry_date';
            elseif (in_array($k, ['state', 'region'], true))                      $guess[$h] = 'state';
            elseif (in_array($k, ['course', 'coursename', 'training'], true))     $guess[$h] = 'course_name';
            elseif (in_array($k, ['batch', 'batchdate'], true))                   $guess[$h] = 'batch';
            else $guess[$h] = 'skip';
        }

        lms_ok([
            'token'      => $token,
            'headers'    => $headers,
            'sample_row' => $sample,
            'total_rows' => $rows,
            'mapping'    => $guess,
            'file_name'  => $_FILES['file']['name'] ?? 'import.csv',
        ]);
    }

    /* CSV import — step 2: register missing users, enrol everyone, log the run */
    if ($action === 'import_run') {
        $token   = preg_replace('/[^a-f0-9]/', '', (string)($in['token'] ?? ''));
        $mapping = is_array($in['mapping'] ?? null) ? $in['mapping'] : lms_json_decode($in['mapping'] ?? '');
        $cid     = lms_int($in['course_id'] ?? 0);
        $path    = sys_get_temp_dir() . '/lms_imports/' . $token . '.csv';
        if (!$token || !is_file($path)) lms_error('Import session expired — please upload the file again');
        if (!in_array('email', array_values($mapping), true)) lms_error('Map at least one column to Email');

        $fh      = fopen($path, 'r');
        $headers = array_map(fn($h) => trim((string)$h, " \t\n\r\0\x0B\xEF\xBB\xBF"), fgetcsv($fh) ?: []);
        $idx     = [];
        foreach ($headers as $i => $h) {
            $target = $mapping[$h] ?? 'skip';
            if ($target !== 'skip') $idx[$target] = $i;
        }

        /* Same two switches the single-add form exposes, applied to every row. */
        $createAccount = !isset($in['create_account']) || (string)$in['create_account'] === '1'
                         || $in['create_account'] === true;
        $writeOrders   = !isset($in['write_orders']) || (string)$in['write_orders'] === '1'
                         || $in['write_orders'] === true;
        $rowPassword   = (string)($in['password'] ?? '');
        $courseName    = trim((string)($in['course_name'] ?? ''));

        $total = 0; $created = 0; $existing = 0; $enrolled = 0; $failed = 0; $errors = [];
        $ordered = 0; $noAccount = 0;
        while (($row = fgetcsv($fh)) !== false) {
            if (count(array_filter($row, fn($v) => trim((string)$v) !== '')) === 0) continue;
            $total++;
            $get   = fn($k) => isset($idx[$k]) ? trim((string)($row[$idx[$k]] ?? '')) : '';
            $email = strtolower($get('email'));

            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                $failed++;
                if (count($errors) < 50) $errors[] = "Row $total: invalid email '" . substr($email, 0, 60) . "'";
                continue;
            }

            $who = lms_resolve_learner($conn, $email, $get('name') ?: $email,
                                       $get('phone'), $rowPassword, $createAccount);
            if (!empty($who['error'])) {
                $failed++;
                if (count($errors) < 50) $errors[] = "Row $total: " . $who['error'];
                continue;
            }
            $uid = (int)$who['user_id'];
            if ($who['created'])   $created++;
            elseif ($uid > 0)      $existing++;
            else                   $noAccount++;

            /* The order row is written whether or not an account exists — an
               email with no users row still gets its purchase recorded, just
               with user_id left NULL. */
            if ($writeOrders) {
                $o = lms_store_order_insert($conn, [
                    'user_id'     => $uid,
                    'name'        => $get('name') ?: $email,
                    'email'       => $email,
                    'phone'       => $get('phone'),
                    'state'       => $get('state'),
                    'course_name' => $get('course_name') ?: $courseName,
                    'batch'       => $get('batch'),
                    'amount'      => $get('amount') !== '' ? (float)$get('amount') : (float)($in['amount'] ?? 0),
                    'status'      => $in['order_status'] ?? 'success',
                ]);
                if ($o['ok']) $ordered++;
                elseif (count($errors) < 50) $errors[] = "Row $total: order not saved — " . $o['message'];
            }

            if ($cid && $uid) {
                $ok = lms_enroll($conn, $cid, $uid, [
                    'access_type' => $in['access_type'] ?? 'paid',
                    'amount'      => $get('amount') !== '' ? (float)$get('amount') : (float)($in['amount'] ?? 0),
                    'expiry_date' => $get('expiry_date') ?: ($in['expiry_date'] ?? ''),
                    'source'      => 'import',
                ]);
                if ($ok) $enrolled++;
            }
        }
        fclose($fh);
        @unlink($path);

        $conn->query("INSERT INTO lms_import_logs
            (file_name, course_id, total_rows, created_rows, existing_rows, enrolled_rows, failed_rows, errors, created_by)
            VALUES ('" . lms_esc($conn, $in['file_name'] ?? 'import.csv') . "', $cid, $total, $created,
                    $existing, $enrolled, $failed,
                    '" . lms_esc($conn, json_encode($errors)) . "', " . lms_int($in['created_by'] ?? 0) . ")");

        lms_ok([
            'total' => $total, 'created' => $created, 'existing' => $existing,
            'enrolled' => $enrolled, 'failed' => $failed, 'errors' => $errors,
            'ordered' => $ordered, 'no_account' => $noAccount,
            'provider' => lms_active_payment_provider($conn),
        ], "Imported $total row" . ($total === 1 ? '' : 's'));
    }

    if ($action === 'import_history') {
        $rows = [];
        $res = $conn->query("SELECT l.*, c.title course_title FROM lms_import_logs l
                             LEFT JOIN lms_courses c ON c.id = l.course_id
                             ORDER BY l.id DESC LIMIT 50");
        while ($res && ($r = $res->fetch_assoc())) {
            $r['errors'] = lms_json_decode($r['errors']);
            $rows[] = $r;
        }
        lms_ok(['imports' => $rows]);
    }

    /* Everything the Users/Enrollments filter bars need to populate their
       dropdowns, in one round trip. Kept separate from list so the page can
       cache it once instead of re-deriving DISTINCTs on every keystroke. */
    if ($action === 'filters') {
        /* The catalogue comes from internship_list, NOT from DISTINCT over
           internship_payment. The payment table records whatever string was
           live at the time, so years of renames sit in it side by side —
           "AR VR Internship" and "AR-VR Internship" are the same product and
           both showed up in the dropdown. internship_list is the maintained
           list of 31 real internships. */
        $internships = [];
        $r = $conn->query("SELECT internship_name FROM internship_list
                            WHERE internship_name <> ''
                            ORDER BY priority ASC, internship_name ASC");
        while ($r && ($row = $r->fetch_assoc())) {
            $internships[] = ['name' => $row['internship_name'], 'group' => 'Internships'];
        }

        /* The ₹99 store's courses are a separate catalogue with no table of
           its own yet, so it is these four plus whatever has actually been
           sold. array_unique keeps a name from appearing twice once one of
           the four has its first order. */
        $storeCatalogue = ['Résumé Building', 'LinkedIn Optimisation',
                           'HR Interview', 'Prompt Engineering Course'];

        $courses = [];
        $r = $conn->query("SELECT id, title FROM lms_courses
                            WHERE status <> 'trashed' ORDER BY title LIMIT 200");
        while ($r && ($row = $r->fetch_assoc())) {
            $courses[] = ['id' => (int)$row['id'], 'title' => $row['title']];
        }

        $storeCourses = []; $providers = []; $batches = [];
        if (lms_table_exists($conn, 'ninety_nine_store_orders')) {
            $r = $conn->query("SELECT DISTINCT course_name FROM ninety_nine_store_orders
                                WHERE course_name <> '' ORDER BY course_name LIMIT 200");
            while ($r && ($row = $r->fetch_assoc())) $storeCourses[] = $row['course_name'];

            $r = $conn->query("SELECT DISTINCT provider FROM ninety_nine_store_orders
                                WHERE provider <> '' ORDER BY provider LIMIT 20");
            while ($r && ($row = $r->fetch_assoc())) $providers[] = $row['provider'];

            $r = $conn->query("SELECT DISTINCT batch FROM ninety_nine_store_orders
                                WHERE batch IS NOT NULL AND batch <> '' ORDER BY batch LIMIT 100");
            while ($r && ($row = $r->fetch_assoc())) $batches[] = $row['batch'];
        }
        if (!$providers) $providers = ['razorpay', 'cashfree'];

        $storeCourses = array_values(array_unique(array_merge($storeCatalogue, $storeCourses)));
        sort($storeCourses);

        /* One flat list for every "which product?" picker in the panel:
           internships first, then ₹99 courses, each tagged with its group so
           the dropdown can show headings. Sending it pre-merged means the
           three screens that need it cannot drift apart. */
        $catalogue = $internships;
        foreach ($storeCourses as $c) $catalogue[] = ['name' => $c, 'group' => '99 courses'];

        lms_ok([
            'internships'      => array_column($internships, 'name'),
            'catalogue'        => $catalogue,
            'courses'          => $courses,
            'store_courses'    => $storeCourses,
            'providers'        => $providers,
            'batches'          => $batches,
            'active_provider'  => lms_active_payment_provider($conn),
            'default_password' => LMS_DEFAULT_PASSWORD,
        ]);
    }

    lms_error('Unknown learners action: ' . $action);
}

/* ───────────────────────── ENROLLMENTS ───────────────────────── */
if ($resource === 'enrollments') {

    /* ── list ────────────────────────────────────────────────────────────
       "Enrollment" here means every way a learner has ever been given (or
       tried to buy) access, not just the LMS table:

         lms         lms_enrollments          — granted an LMS course
         internship  payment_status           — an internship checkout
         store       ninety_nine_store_orders — a ₹99-store course

       They are UNIONed into one row shape so the screen can show them in a
       single list and filter across them. Each row keeps a 'kind' and a 'ref'
       (kind + primary key) so the UI can tell them apart and act on the right
       table — only 'lms' rows are editable, because they are the only ones
       this panel owns.

       Progress is filled in afterwards, for the LMS rows on the current page
       only. Computing it inside the UNION would run the lesson counters over
       every candidate row before the LIMIT.
       ───────────────────────────────────────────────────────────────────── */
    if ($action === 'list') {
        $cid      = lms_int($_GET['course_id'] ?? 0);
        $q        = trim($_GET['q'] ?? '');
        $source   = $_GET['source'] ?? 'all';     // all|lms|internship|store
        /* Completed purchases only, unless the caller explicitly asks for a
           different status. An abandoned checkout is not an enrolment — the
           screen was showing far more 'initiated' rows than real ones, and
           they are the bulk of payment_status, so excluding them is both the
           correct list AND much less to read. */
        $status   = strtolower(trim($_GET['status'] ?? 'success'));
        $access   = strtolower(trim($_GET['access_type'] ?? ''));
        $provider = strtolower(trim($_GET['provider'] ?? ''));
        $from     = trim($_GET['from'] ?? '');
        $to       = trim($_GET['to'] ?? '');
        $minAmt   = $_GET['min_amount'] ?? '';
        $sort     = $_GET['sort'] ?? 'recent';    // recent|oldest|amount|name
        $limit    = min(200, max(1, lms_int($_GET['limit'] ?? 30, 30)));
        $offset   = max(0, lms_int($_GET['offset'] ?? 0));

        $hasStore = lms_table_exists($conn, 'ninety_nine_store_orders');
        $dFrom = preg_match('/^\d{4}-\d{2}-\d{2}$/', $from) ? $from : '';
        $dTo   = preg_match('/^\d{4}-\d{2}-\d{2}$/', $to)   ? $to   : '';
        $qe    = $q === '' ? '' : lms_esc($conn, $q);
        $amt   = $minAmt === '' ? null : (float)$minAmt;

        /* Three parallel lists, one entry per branch: the SELECT itself, the
           ORDER BY that caps it, and a COUNT for the total. See the union
           assembly below for why each branch has to be capped on its own. */
        $parts = []; $branchOrder = []; $countParts = [];

        /* ── LMS enrolments ─────────────────────────────────────────────── */
        if ($source === 'all' || $source === 'lms') {
            $w = ['1'];
            if ($cid) $w[] = "e.course_id = $cid";
            /* An LMS grant has no 'success' — its live state is 'active'. */
            $eStatus = $status === 'success' ? 'active' : $status;
            if ($eStatus !== '') $w[] = "e.status = '" . lms_esc($conn, $eStatus) . "'";
            if ($access !== '')  $w[] = "e.access_type = '" . lms_esc($conn, $access) . "'";
            if ($dFrom !== '')   $w[] = "DATE(e.enrolled_at) >= '$dFrom'";
            if ($dTo !== '')     $w[] = "DATE(e.enrolled_at) <= '$dTo'";
            if ($amt !== null)   $w[] = "e.amount >= $amt";
            if ($qe !== '')      $w[] = "(u.email LIKE '%$qe%' OR u.name LIKE '%$qe%' OR c.title LIKE '%$qe%')";
            /* A provider filter is a payment-gateway question; LMS grants
               never went through one, so asking for a gateway excludes them. */
            if ($provider !== '') $w[] = '0';
            $ww = implode(' AND ', $w);

            $parts[] = "SELECT " . lms_col("'lms'") . " kind, e.id ref_id, e.user_id,
                               " . lms_col('u.name') . " name, " . lms_col('u.email') . " email,
                               " . lms_col('u.phone') . " phone,
                               e.course_id, " . lms_col('c.title') . " course_title,
                               " . lms_col('NULL') . " batch,
                               " . lms_col('e.access_type') . " access_type, e.amount,
                               " . lms_col('e.status') . " status,
                               " . lms_col('NULL') . " provider,
                               " . lms_col('NULL') . " order_id,
                               " . lms_col('NULL') . " payment_id,
                               e.expiry_date, e.enrolled_at created_at
                          FROM lms_enrollments e
                          LEFT JOIN users u       ON u.user_id = e.user_id
                          LEFT JOIN lms_courses c ON c.id      = e.course_id
                         WHERE $ww";
            $branchOrder[] = 'ORDER BY e.id DESC';
            /* The joins are only in the count when a filter actually reads
               them. Counting 500k rows through two LEFT JOINs that nothing in
               the WHERE clause touches is pure waste. */
            $countParts[]  = $qe === ''
                ? "SELECT COUNT(*) FROM lms_enrollments e WHERE $ww"
                : "SELECT COUNT(*) FROM lms_enrollments e
                     LEFT JOIN users u       ON u.user_id = e.user_id
                     LEFT JOIN lms_courses c ON c.id      = e.course_id
                    WHERE $ww";
        }

        /* ── internship checkouts ───────────────────────────────────────── */
        if (($source === 'all' || $source === 'internship') && !$cid) {
            $w = ['1'];
            if ($status !== '') $w[] = "ps.status = '" . lms_esc($conn, $status) . "'";
            if ($dFrom !== '')  $w[] = "DATE(ps.timestamp) >= '$dFrom'";
            if ($dTo !== '')    $w[] = "DATE(ps.timestamp) <= '$dTo'";
            if ($amt !== null)  $w[] = "ps.amount >= $amt";
            if ($qe !== '')     $w[] = "(u.email LIKE '%$qe%' OR u.name LIKE '%$qe%'
                                         OR ps.internship_name LIKE '%$qe%')";
            /* payment_status predates the multi-gateway split and has no
               provider column, so a gateway filter cannot match these. */
            if ($provider !== '') $w[] = '0';
            if ($access !== '' && $access !== 'paid') $w[] = '0';
            $ww = implode(' AND ', $w);

            $parts[] = "SELECT " . lms_col("'internship'") . " kind, ps.id ref_id, ps.user_id,
                               " . lms_col('u.name') . " name, " . lms_col('u.email') . " email,
                               " . lms_col('u.phone') . " phone,
                               0 course_id, " . lms_col('ps.internship_name') . " course_title,
                               " . lms_col('ps.batch_date') . " batch,
                               " . lms_col("'paid'") . " access_type, ps.amount,
                               " . lms_col('ps.status') . " status,
                               " . lms_col('NULL') . " provider,
                               " . lms_col('ps.order_id') . " order_id,
                               " . lms_col('ps.payment_id') . " payment_id,
                               NULL expiry_date, ps.timestamp created_at
                          FROM payment_status ps
                          LEFT JOIN users u ON u.user_id = ps.user_id
                         WHERE $ww";
            $branchOrder[] = 'ORDER BY ps.id DESC';
            $countParts[]  = $qe === ''
                ? "SELECT COUNT(*) FROM payment_status ps WHERE $ww"
                : "SELECT COUNT(*) FROM payment_status ps
                     LEFT JOIN users u ON u.user_id = ps.user_id
                    WHERE $ww";
        }

        /* ── ₹99 store orders ───────────────────────────────────────────── */
        if ($hasStore && ($source === 'all' || $source === 'store') && !$cid) {
            $w = ['1'];
            if ($status !== '')   $w[] = "o.status = '" . lms_esc($conn, $status) . "'";
            if ($provider !== '') $w[] = "o.provider = '" . lms_esc($conn, $provider) . "'";
            if ($dFrom !== '')    $w[] = "DATE(o.created_at) >= '$dFrom'";
            if ($dTo !== '')      $w[] = "DATE(o.created_at) <= '$dTo'";
            if ($amt !== null)    $w[] = "o.amount >= $amt";
            if ($qe !== '')       $w[] = "(o.email LIKE '%$qe%' OR o.first_name LIKE '%$qe%'
                                           OR o.last_name LIKE '%$qe%' OR o.course_name LIKE '%$qe%')";
            if ($access !== '' && $access !== 'paid') $w[] = '0';
            $ww = implode(' AND ', $w);

            $parts[] = "SELECT " . lms_col('o.source') . " kind, o.id ref_id, o.user_id,
                               " . lms_col("TRIM(CONCAT(COALESCE(o.first_name,''), ' ', COALESCE(o.last_name,'')))") . " name,
                               " . lms_col('o.email') . " email,
                               " . lms_col('o.phone_number') . " phone,
                               0 course_id, " . lms_col('o.course_name') . " course_title,
                               " . lms_col('o.batch') . " batch,
                               " . lms_col("'paid'") . " access_type, o.amount,
                               " . lms_col('o.status') . " status,
                               " . lms_col('o.provider') . " provider,
                               " . lms_col('o.order_id') . " order_id,
                               " . lms_col('o.payment_id') . " payment_id,
                               NULL expiry_date, o.created_at
                          FROM ninety_nine_store_orders o
                         WHERE $ww";
            $branchOrder[] = 'ORDER BY o.id DESC';
            $countParts[]  = "SELECT COUNT(*) FROM ninety_nine_store_orders o WHERE $ww";
        }

        if (!$parts) lms_ok(['enrollments' => [], 'total' => 0]);

        /* ── why each branch carries its own ORDER BY … LIMIT ──────────────
           "SELECT * FROM (a UNION ALL b UNION ALL c) ORDER BY created_at DESC
           LIMIT 30" makes MySQL materialise EVERY row of all three branches —
           half a million of them — and filesort the lot to hand back thirty.
           That was the twelve seconds.

           Only the newest ($offset + $limit) rows of any ONE branch can reach
           the page, so each branch is capped at exactly that many before the
           merge. Three capped branches produce a few hundred rows and sorting
           those costs nothing.

           The cap sorts on the PRIMARY KEY rather than the date column: all
           three tables are auto-increment with an insert-time timestamp, so id
           order and date order agree, and "ORDER BY id DESC LIMIT n" walks the
           clustered index backwards and stops after n rows — no index on the
           date column required. The outer ORDER BY below still sorts by the
           real column, so the page is date-ordered either way.

           Caveat worth knowing: 'amount' and 'name' sorts still order the
           merged page, not the whole dataset, because the cap is by recency.
           Sorting half a million rows by amount on every keystroke is not a
           trade worth making — recency is the axis this screen is read on. */
        $cap = $offset + $limit;
        $capped = [];
        foreach ($parts as $idx => $part) {
            $capped[] = '(' . $part . ' ' . $branchOrder[$idx] . " LIMIT $cap)";
        }
        $union = implode(' UNION ALL ', $capped);

        $order = 'ORDER BY created_at DESC';
        if ($sort === 'oldest') $order = 'ORDER BY created_at ASC';
        if ($sort === 'amount') $order = 'ORDER BY amount DESC';
        if ($sort === 'name')   $order = 'ORDER BY name ASC';

        /* Sum each branch's own COUNT(*) rather than counting the union.
           UNION ALL keeps every row, so the sum IS the total — and three
           indexed counts beat materialising 500k rows in order to count them.
           Cached anyway, because even three counts are not free at this size. */
        $total = lms_cached_count($conn, 'enrollments|' . implode('|', $countParts),
            'SELECT (' . implode(') + (', $countParts) . ') AS c');
        if ($total === null) lms_error('Could not count enrollments: ' . $conn->error, 500);

        $res = $conn->query("SELECT * FROM ($union) x $order LIMIT $limit OFFSET $offset");
        if ($res === false) lms_error('Could not read enrollments: ' . $conn->error, 500);

        $rows = []; $lmsKeys = [];
        while ($r = $res->fetch_assoc()) {
            $kind = $r['kind'] === 'admin' ? 'admin' : $r['kind'];
            $row = [
                'ref'           => $kind . ':' . $r['ref_id'],
                'kind'          => $kind,
                'id'            => (int)$r['ref_id'],
                'editable'      => $kind === 'lms',
                'user_id'       => (int)$r['user_id'],
                'name'          => $r['name'] ?: $r['email'],
                'email'         => $r['email'],
                'phone'         => $r['phone'],
                'course_id'     => (int)$r['course_id'],
                'course_title'  => $r['course_title'],
                'batch'         => $r['batch'],
                'access_type'   => $r['access_type'],
                'amount'        => (float)$r['amount'],
                'status'        => $r['status'],
                'provider'      => $r['provider'],
                'order_id'      => $r['order_id'],
                'payment_id'    => $r['payment_id'],
                'expiry_date'   => $r['expiry_date'],
                'enrolled_at'   => $r['created_at'],
                'total_lessons' => 0, 'done_lessons' => 0, 'progress' => 0,
            ];
            if ($kind === 'lms') $lmsKeys[] = count($rows);
            $rows[] = $row;
        }

        /* Progress for the LMS rows on this page only. */
        if ($lmsKeys) {
            $courseIds = [];
            foreach ($lmsKeys as $k) $courseIds[$rows[$k]['course_id']] = true;
            $cList = implode(',', array_map('intval', array_keys($courseIds))) ?: '0';

            $lessons = [];
            $lr = $conn->query("SELECT course_id, COUNT(*) n FROM lms_lessons
                                 WHERE course_id IN ($cList) GROUP BY course_id");
            while ($lr && ($r = $lr->fetch_assoc())) $lessons[(int)$r['course_id']] = (int)$r['n'];

            $pairs = [];
            foreach ($lmsKeys as $k) {
                $pairs[] = '(' . (int)$rows[$k]['user_id'] . ',' . (int)$rows[$k]['course_id'] . ')';
            }
            $done = [];
            $dr = $conn->query("SELECT user_id, course_id, COUNT(*) n FROM lms_progress
                                 WHERE status = 'completed'
                                   AND (user_id, course_id) IN (" . implode(',', $pairs) . ")
                                 GROUP BY user_id, course_id");
            while ($dr && ($r = $dr->fetch_assoc())) {
                $done[$r['user_id'] . ':' . $r['course_id']] = (int)$r['n'];
            }

            foreach ($lmsKeys as $k) {
                $t = $lessons[$rows[$k]['course_id']] ?? 0;
                $d = $done[$rows[$k]['user_id'] . ':' . $rows[$k]['course_id']] ?? 0;
                $rows[$k]['total_lessons'] = $t;
                $rows[$k]['done_lessons']  = $d;
                $rows[$k]['progress']      = $t > 0 ? (int)round($d * 100 / $t) : 0;
            }
        }

        lms_ok(['enrollments' => $rows, 'total' => $total]);
    }

    if ($action === 'create') {
        $cid = lms_int($in['course_id'] ?? 0);
        $uid = lms_int($in['user_id'] ?? 0);
        if (!$cid || !$uid) lms_error('course_id and user_id are required');
        lms_enroll($conn, $cid, $uid, $in);
        lms_ok(null, 'Learner enrolled');
    }

    /* enrol every buyer of a given internship into a course in one shot */
    if ($action === 'bulk_create') {
        $cid  = lms_int($in['course_id'] ?? 0);
        $uids = $in['user_ids'] ?? [];
        $internship = trim($in['internship'] ?? '');
        if (!$cid) lms_error('course_id is required');

        if ($internship !== '' && !is_array($uids)) $uids = [];
        if ($internship !== '') {
            $ie = lms_esc($conn, $internship);
            $r = $conn->query("SELECT DISTINCT user_id FROM internship_payment WHERE internship = '$ie'");
            while ($r && ($row = $r->fetch_assoc())) $uids[] = (int)$row['user_id'];
        }
        if (!is_array($uids) || !$uids) lms_error('Select at least one learner (or an internship to pull buyers from)');

        $n = 0;
        foreach ($uids as $uid) { if (lms_enroll($conn, $cid, (int)$uid, $in)) $n++; }
        lms_ok(['enrolled' => $n], "$n learner" . ($n === 1 ? '' : 's') . ' enrolled');
    }

    if ($action === 'update') {
        $id = lms_int($in['id'] ?? 0);
        if (!$id) lms_error('Enrollment id is required');
        $sets = [];
        if (in_array($in['status'] ?? '', ['active', 'expired', 'revoked'], true)) {
            $sets[] = "status = '" . $in['status'] . "'";
        }
        if (in_array($in['access_type'] ?? '', ['paid', 'free', 'trial'], true)) {
            $sets[] = "access_type = '" . $in['access_type'] . "'";
        }
        if (isset($in['amount']))      $sets[] = 'amount = ' . (float)$in['amount'];
        if (isset($in['expiry_date'])) {
            $d = trim((string)$in['expiry_date']);
            $sets[] = 'expiry_date = ' . ($d === '' ? 'NULL' : "'" . lms_esc($conn, $d) . "'");
        }
        if (!$sets) lms_error('Nothing to update');
        $conn->query('UPDATE lms_enrollments SET ' . implode(', ', $sets) . " WHERE id = $id");
        lms_ok(null, 'Enrollment updated');
    }

    if ($action === 'delete') {
        $id = lms_int($in['id'] ?? 0);
        if (!$id) lms_error('Enrollment id is required');
        $conn->query("DELETE FROM lms_enrollments WHERE id = $id");
        lms_ok(null, 'Enrollment removed');
    }

    lms_error('Unknown enrollments action: ' . $action);
}

/* ───────────────────────── REPORTS ───────────────────────── */
if ($resource === 'reports') {

    if ($action === 'progress') {
        $cid = lms_int($_GET['course_id'] ?? 0);
        if (!$cid) lms_error('course_id is required');

        $tr = $conn->query("SELECT COUNT(*) c FROM lms_lessons WHERE course_id = $cid");
        $totalLessons = $tr ? (int)$tr->fetch_assoc()['c'] : 0;

        $rows = [];
        $res = $conn->query("SELECT u.user_id, u.name, u.email,
                                    COUNT(CASE WHEN p.status='completed' THEN 1 END) done,
                                    COALESCE(SUM(p.watched_secs),0) watched,
                                    MAX(p.updated_at) last_active
                             FROM lms_enrollments e
                             LEFT JOIN users u       ON u.user_id = e.user_id
                             LEFT JOIN lms_progress p ON p.user_id = e.user_id AND p.course_id = e.course_id
                             WHERE e.course_id = $cid
                             GROUP BY u.user_id ORDER BY done DESC, u.user_id DESC");
        while ($res && ($r = $res->fetch_assoc())) {
            $r['done']     = (int)$r['done'];
            $r['watched']  = (int)$r['watched'];
            $r['progress'] = $totalLessons ? round($r['done'] * 100 / $totalLessons) : 0;
            $rows[] = $r;
        }
        lms_ok(['total_lessons' => $totalLessons, 'rows' => $rows]);
    }

    if ($action === 'quiz') {
        $qid = lms_int($_GET['quiz_id'] ?? 0);
        if (!$qid) lms_error('quiz_id is required');
        $sum = $conn->query("SELECT COUNT(*) attempts, COALESCE(AVG(percentage),0) avg_pct,
                                    COALESCE(MAX(percentage),0) max_pct, COALESCE(MIN(percentage),0) min_pct,
                                    SUM(passed) passed
                             FROM lms_quiz_attempts WHERE quiz_id = $qid");
        $s = $sum ? $sum->fetch_assoc() : [];

        /* per-question accuracy, computed from the stored answer maps */
        $questions = [];
        $qr = $conn->query("SELECT id, question, correct, marks FROM lms_quiz_questions
                            WHERE quiz_id = $qid AND status='active' ORDER BY sort_order");
        while ($qr && ($q = $qr->fetch_assoc())) {
            $questions[(int)$q['id']] = [
                'id' => (int)$q['id'], 'question' => $q['question'],
                'correct' => lms_json_decode($q['correct']), 'right' => 0, 'wrong' => 0,
            ];
        }
        $ar = $conn->query("SELECT answers FROM lms_quiz_attempts WHERE quiz_id = $qid");
        while ($ar && ($a = $ar->fetch_assoc())) {
            foreach (lms_json_decode($a['answers']) as $qidKey => $given) {
                $k = (int)$qidKey;
                if (!isset($questions[$k])) continue;
                $exp  = $questions[$k]['correct'];
                $got  = is_array($given) ? $given : [$given];
                sort($exp); sort($got);
                if ($exp == $got) $questions[$k]['right']++; else $questions[$k]['wrong']++;
            }
        }
        lms_ok(['summary' => $s, 'questions' => array_values($questions)]);
    }

    if ($action === 'course_funnel') {
        $rows = [];
        $res = $conn->query("SELECT c.id, c.title,
                                (SELECT COUNT(*) FROM lms_enrollments e WHERE e.course_id = c.id) enrolled,
                                (SELECT COUNT(DISTINCT p.user_id) FROM lms_progress p WHERE p.course_id = c.id) started,
                                (SELECT COUNT(*) FROM lms_lessons l WHERE l.course_id = c.id) lessons,
                                (SELECT COUNT(*) FROM lms_progress p WHERE p.course_id = c.id AND p.status='completed') completions,
                                (SELECT COALESCE(SUM(e.amount),0) FROM lms_enrollments e WHERE e.course_id = c.id) revenue
                             FROM lms_courses c WHERE c.status <> 'trashed'
                             ORDER BY enrolled DESC");
        while ($res && ($r = $res->fetch_assoc())) {
            foreach (['enrolled', 'started', 'lessons', 'completions'] as $k) $r[$k] = (int)$r[$k];
            $r['revenue'] = (float)$r['revenue'];
            $r['completion_rate'] = ($r['enrolled'] && $r['lessons'])
                ? round($r['completions'] * 100 / ($r['enrolled'] * $r['lessons'])) : 0;
            $rows[] = $r;
        }
        lms_ok(['rows' => $rows]);
    }

    /* ─────────────────── portal access (training.internshipstudio.com) ──────
       Who actually OPENED the learning portal, and where their time went.

       The tables read here are written by the portal, not by this file — see
       training_dashboard/public/api/_bootstrap.php (learn_install) and
       track.php. They live in the same istudio_cit database, so no second
       connection is needed, but they only exist once the portal has served a
       request: `tracked => false` is the honest answer on a fresh database,
       and the UI explains that rather than showing an error.

       Enrollment is not access. A learner can be enrolled in four courses and
       have never signed in; the funnel and progress reports above cannot tell
       the difference, which is exactly the gap this fills. */
    if ($action === 'portal_access') {
        if (!lms_table_exists($conn, 'lms_learner_visits')) {
            lms_ok([
                'tracked'  => false,
                'summary'  => new stdClass(),
                'students' => [],
                'courses'  => [],
            ]);
        }

        /* Window, in days; 0 (the default) means everything ever recorded.
           Cast to int, so it is safe to interpolate below. */
        $days = max(0, lms_int($_GET['days'] ?? 0));

        /* A visit is filtered by when it STARTED, a page view by when the
           learner entered that screen — both are the moment the time began
           accruing, which is what a date filter is expected to mean. */
        $vCut = $days ? "v.started_at  >= DATE_SUB(NOW(), INTERVAL $days DAY)" : '1';
        $pCut = $days ? "pv.entered_at >= DATE_SUB(NOW(), INTERVAL $days DAY)" : '1';

        $one = function ($sql) use ($conn) {
            $r = $conn->query($sql);
            return $r ? ($r->fetch_row()[0] ?? 0) : 0;
        };

        /* ── headline numbers ── */
        $sr = $conn->query("SELECT COUNT(DISTINCT v.user_id) students,
                                   COUNT(*) visits,
                                   COALESCE(SUM(v.page_views),0) page_views,
                                   COALESCE(SUM(v.duration_secs),0) seconds,
                                   MIN(v.started_at) first_seen,
                                   MAX(v.last_seen_at) last_seen
                            FROM lms_learner_visits v WHERE $vCut");
        $s = ($sr ? $sr->fetch_assoc() : []) ?: [];

        $summary = [
            'students'   => (int)($s['students'] ?? 0),
            'visits'     => (int)($s['visits'] ?? 0),
            'page_views' => (int)($s['page_views'] ?? 0),
            'seconds'    => (int)($s['seconds'] ?? 0),
            'first_seen' => $s['first_seen'] ?? null,
            'last_seen'  => $s['last_seen'] ?? null,
            /* Deliberately ignores the selected window, so "is anyone still
               using this?" has one stable answer whatever the filter says. */
            'active_7d'  => (int)$one("SELECT COUNT(DISTINCT user_id) FROM lms_learner_visits
                                       WHERE last_seen_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)"),
        ];
        $summary['avg_seconds'] = $summary['students']
            ? (int)round($summary['seconds'] / $summary['students']) : 0;

        /* Enrolled-but-never-arrived: the number the funnel cannot show. */
        $summary['enrolled_students'] = (int)$one("SELECT COUNT(DISTINCT user_id) FROM lms_enrollments");
        $summary['never_accessed']    = (int)$one("SELECT COUNT(*) FROM (
                                                     SELECT DISTINCT e.user_id FROM lms_enrollments e
                                                     WHERE NOT EXISTS (SELECT 1 FROM lms_learner_visits v
                                                                       WHERE v.user_id = e.user_id)
                                                   ) t");

        /* Sign-ins and Skill Lab hand-offs, when those tables are present. */
        if (lms_table_exists($conn, 'lms_learner_logins')) {
            $lCut = $days ? "created_at >= DATE_SUB(NOW(), INTERVAL $days DAY)" : '1';
            $summary['logins']        = (int)$one("SELECT COUNT(*) FROM lms_learner_logins
                                                   WHERE outcome = 'success' AND $lCut");
            $summary['failed_logins'] = (int)$one("SELECT COUNT(*) FROM lms_learner_logins
                                                   WHERE outcome = 'failed' AND $lCut");
        }
        if (lms_table_exists($conn, 'lms_portal_handoffs')) {
            $hCut = $days ? "created_at >= DATE_SUB(NOW(), INTERVAL $days DAY)" : '1';
            $summary['handoff_clicks'] = (int)$one("SELECT COUNT(*) FROM lms_portal_handoffs WHERE $hCut");
            $summary['handoff_landed'] = (int)$one("SELECT COUNT(*) FROM lms_portal_handoffs
                                                    WHERE consumed_at IS NOT NULL AND $hCut");
        }

        /* ── one row per student who arrived ── */
        $students = [];
        $res = $conn->query("SELECT v.user_id, u.name, u.email,
                                    COUNT(*) visits,
                                    COALESCE(SUM(v.page_views),0) page_views,
                                    COALESCE(SUM(v.duration_secs),0) seconds,
                                    MIN(v.started_at) first_seen,
                                    MAX(v.last_seen_at) last_seen
                             FROM lms_learner_visits v
                             LEFT JOIN users u ON u.user_id = v.user_id
                             WHERE $vCut
                             GROUP BY v.user_id
                             ORDER BY seconds DESC, visits DESC");
        while ($res && ($r = $res->fetch_assoc())) {
            $students[(int)$r['user_id']] = [
                'user_id'     => (int)$r['user_id'],
                'name'        => $r['name'],
                'email'       => $r['email'],
                'visits'      => (int)$r['visits'],
                'page_views'  => (int)$r['page_views'],
                'seconds'     => (int)$r['seconds'],
                'first_seen'  => $r['first_seen'],
                'last_seen'   => $r['last_seen'],
                'courses'     => [],   // filled in below
                'course_secs' => 0,    // of that time, how much was inside a course
            ];
        }

        /* ── the same time, split by course ──
           course_id is stamped by the client on every course and lesson screen;
           0 means a screen belonging to no course (home, enrollments), so that
           time is reported separately rather than dropped. */
        $courses = [];
        $res = $conn->query("SELECT pv.user_id, pv.course_id, c.title,
                                    COALESCE(SUM(pv.seconds),0) seconds,
                                    COUNT(DISTINCT pv.lesson_id) screens,
                                    MAX(pv.last_seen_at) last_seen
                             FROM lms_learner_page_views pv
                             LEFT JOIN lms_courses c ON c.id = pv.course_id
                             WHERE pv.course_id > 0 AND $pCut
                             GROUP BY pv.user_id, pv.course_id
                             ORDER BY seconds DESC");
        while ($res && ($r = $res->fetch_assoc())) {
            $uid  = (int)$r['user_id'];
            $cid  = (int)$r['course_id'];
            $secs = (int)$r['seconds'];
            /* A deleted course still owns its time; name it rather than hide it. */
            $title = ($r['title'] !== null && $r['title'] !== '')
                ? $r['title'] : "Course #$cid (removed)";

            if (isset($students[$uid])) {
                $students[$uid]['courses'][] = [
                    'course_id' => $cid,
                    'title'     => $title,
                    'seconds'   => $secs,
                    /* lesson_id is 0 on the course overview screen, so that
                       pseudo-lesson is not counted as a lesson opened. */
                    'lessons'   => max(0, (int)$r['screens'] - 1),
                    'last_seen' => $r['last_seen'],
                ];
                $students[$uid]['course_secs'] += $secs;
            }

            if (!isset($courses[$cid])) {
                $courses[$cid] = ['course_id' => $cid, 'title' => $title,
                                  'students' => 0, 'seconds' => 0, 'last_seen' => null];
            }
            $courses[$cid]['students']++;
            $courses[$cid]['seconds'] += $secs;
            if ($r['last_seen'] > $courses[$cid]['last_seen']) {
                $courses[$cid]['last_seen'] = $r['last_seen'];
            }
        }

        /* Enrolled headcount per course, so "5 of 20 enrolled learners have
           opened this course" can be read straight off the table. */
        $enrolled = [];
        $res = $conn->query("SELECT course_id, COUNT(DISTINCT user_id) c
                             FROM lms_enrollments GROUP BY course_id");
        while ($res && ($r = $res->fetch_assoc())) $enrolled[(int)$r['course_id']] = (int)$r['c'];

        $courses = array_values($courses);
        foreach ($courses as &$c) {
            $c['enrolled']    = $enrolled[$c['course_id']] ?? 0;
            $c['avg_seconds'] = $c['students'] ? (int)round($c['seconds'] / $c['students']) : 0;
            $c['reach']       = $c['enrolled'] ? (int)round($c['students'] * 100 / $c['enrolled']) : 0;
        }
        unset($c);
        usort($courses, fn($a, $b) => $b['seconds'] <=> $a['seconds']);

        /* Time on screens outside any course — the portal shell itself. */
        $summary['course_seconds'] = array_sum(array_column($courses, 'seconds'));
        $summary['other_seconds']  = (int)$one("SELECT COALESCE(SUM(pv.seconds),0)
                                                FROM lms_learner_page_views pv
                                                WHERE pv.course_id = 0 AND $pCut");

        lms_ok([
            'tracked'  => true,
            'days'     => $days,
            'summary'  => $summary,
            'students' => array_values($students),
            'courses'  => $courses,
        ]);
    }

    lms_error('Unknown reports action: ' . $action);
}

/* ───────────────────────── SUPPORT ─────────────────────────
   The other end of the learner portal's help desk. A learner raises a ticket
   at training.internshipstudio.com/support (public/api/support.php); the reply
   written here lands in the thread they are already watching, because both
   sides read the same two tables in istudio_cit.

   Nothing is emailed. The learner_unread counter is what makes the reply
   visible: their portal shows a badge from it, and opening the thread clears
   it — see the DDL comment in the portal's _bootstrap.php. */

/** The same DDL the portal runs, so whichever side is deployed first wins. */
function lms_support_install($conn) {
    $conn->query("CREATE TABLE IF NOT EXISTS lms_support_tickets (
        id              INT AUTO_INCREMENT PRIMARY KEY,
        user_id         INT          NOT NULL,
        subject         VARCHAR(190) NOT NULL,
        topic           VARCHAR(60)       DEFAULT 'other',
        course_id       INT               DEFAULT 0,
        status          ENUM('open','answered','closed') DEFAULT 'open',
        messages        INT               DEFAULT 0,
        admin_unread    INT               DEFAULT 0,
        learner_unread  INT               DEFAULT 0,
        last_message_at DATETIME          DEFAULT NULL,
        created_at      TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_user_created (user_id, created_at),
        INDEX idx_status (status, last_message_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $conn->query("CREATE TABLE IF NOT EXISTS lms_support_messages (
        id         INT AUTO_INCREMENT PRIMARY KEY,
        ticket_id  INT          NOT NULL,
        sender     ENUM('learner','admin') NOT NULL DEFAULT 'learner',
        author     VARCHAR(120)      DEFAULT NULL,
        body       TEXT,
        file_url   VARCHAR(500)      DEFAULT NULL,
        file_name  VARCHAR(190)      DEFAULT NULL,
        file_type  VARCHAR(90)       DEFAULT NULL,
        file_size  INT               DEFAULT 0,
        created_at TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_ticket (ticket_id, id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
}

if ($resource === 'support') {
    lms_support_install($conn);

    /* Kept in step with SUPPORT_TOPICS in the portal's support.php. A ticket
       raised before a topic was added still renders — the key falls through as
       its own label rather than showing nothing. */
    $topics = [
        'video'       => "A video won't play or keeps buffering",
        'access'      => 'I cannot open a course I have paid for',
        'certificate' => 'My certificate has not arrived',
        'quiz'        => 'A quiz or assignment is not accepting my answer',
        'progress'    => 'My progress or completion is not saving',
        'attachment'  => 'A PDF or attachment will not open',
        'login'       => 'Trouble signing in to the portal',
        'other'       => 'Something else',
    ];

    $shapeMessage = fn($r) => [
        'id'         => (int)$r['id'],
        'sender'     => $r['sender'],
        'author'     => $r['author'],
        'body'       => $r['body'],
        'file_url'   => $r['file_url'],
        'file_name'  => $r['file_name'],
        'file_type'  => $r['file_type'],
        'file_size'  => (int)$r['file_size'],
        'created_at' => $r['created_at'],
    ];

    $shapeTicket = function ($r) use ($topics) {
        return [
            'id'              => (int)$r['id'],
            'user_id'         => (int)$r['user_id'],
            'name'            => $r['name'] ?? null,
            'email'           => $r['email'] ?? null,
            'subject'         => $r['subject'],
            'topic'           => $r['topic'],
            'topic_label'     => $topics[$r['topic']] ?? $r['topic'],
            'course_id'       => (int)$r['course_id'],
            'course_title'    => $r['course_title'] ?? null,
            'status'          => $r['status'],
            'messages'        => (int)$r['messages'],
            /* "unread" to an admin means messages from the learner. */
            'unread'          => (int)$r['admin_unread'],
            'last_message_at' => $r['last_message_at'],
            'created_at'      => $r['created_at'],
            'preview'         => $r['preview'] ?? null,
        ];
    };

    if ($action === 'list' || $action === '') {
        $status = $_GET['status'] ?? 'all';
        $q      = trim($_GET['q'] ?? '');
        $cid    = lms_int($_GET['course_id'] ?? 0);

        $where = ['1'];
        if (in_array($status, ['open', 'answered', 'closed'], true)) {
            $where[] = "t.status = '" . lms_esc($conn, $status) . "'";
        } elseif ($status === 'unanswered') {
            /* The queue that actually needs working: something the learner
               said is still unread, whatever the status column says. */
            $where[] = 't.admin_unread > 0';
        }
        if ($cid) $where[] = "t.course_id = $cid";
        if ($q !== '') {
            $qe = lms_esc($conn, $q);
            $where[] = "(t.subject LIKE '%$qe%' OR u.name LIKE '%$qe%'
                         OR u.email LIKE '%$qe%' OR t.id = " . (int)$q . ")";
        }

        $rows = [];
        $res = $conn->query("SELECT t.*, u.name, u.email, c.title course_title,
                                    (SELECT m.body FROM lms_support_messages m
                                      WHERE m.ticket_id = t.id ORDER BY m.id DESC LIMIT 1) preview
                             FROM lms_support_tickets t
                             LEFT JOIN users u       ON u.user_id = t.user_id
                             LEFT JOIN lms_courses c ON c.id = t.course_id
                             WHERE " . implode(' AND ', $where) . "
                             ORDER BY t.admin_unread DESC,
                                      COALESCE(t.last_message_at, t.created_at) DESC, t.id DESC
                             LIMIT 400");
        if ($res === false) lms_error('Could not read lms_support_tickets: ' . $conn->error, 500);
        while ($row = $res->fetch_assoc()) $rows[] = $shapeTicket($row);

        /* The strip above the list, always over ALL tickets rather than the
           filtered set — a count that moves when you filter is not a count. */
        $counts = ['total' => 0, 'open' => 0, 'answered' => 0, 'closed' => 0, 'unanswered' => 0];
        $cr = $conn->query("SELECT status, COUNT(*) c, SUM(admin_unread > 0) waiting
                            FROM lms_support_tickets GROUP BY status");
        while ($cr && ($c = $cr->fetch_assoc())) {
            $counts[$c['status']]   = (int)$c['c'];
            $counts['total']       += (int)$c['c'];
            $counts['unanswered'] += (int)$c['waiting'];
        }

        lms_ok(['tickets' => $rows, 'counts' => $counts]);
    }

    if ($action === 'get') {
        $id = lms_int($_GET['id'] ?? 0);
        if (!$id) lms_error('A ticket id is required');

        $res = $conn->query("SELECT t.*, u.name, u.email, c.title course_title
                             FROM lms_support_tickets t
                             LEFT JOIN users u       ON u.user_id = t.user_id
                             LEFT JOIN lms_courses c ON c.id = t.course_id
                             WHERE t.id = $id LIMIT 1");
        $t = $res ? $res->fetch_assoc() : null;
        if (!$t) lms_error('That ticket could not be found', 404);

        $messages = [];
        $mr = $conn->query("SELECT * FROM lms_support_messages WHERE ticket_id = $id ORDER BY id ASC");
        while ($mr && ($m = $mr->fetch_assoc())) $messages[] = $shapeMessage($m);

        /* Reading the thread is what clears the admin-side badge. */
        if ((int)$t['admin_unread'] > 0) {
            $conn->query("UPDATE lms_support_tickets SET admin_unread = 0 WHERE id = $id");
            $t['admin_unread'] = 0;
        }

        /* Enough context to answer without leaving the screen: what else this
           learner has raised, and what they are enrolled in. */
        $history = [];
        $hr = $conn->query("SELECT id, subject, status, created_at FROM lms_support_tickets
                            WHERE user_id = " . (int)$t['user_id'] . " AND id <> $id
                            ORDER BY id DESC LIMIT 6");
        while ($hr && ($h = $hr->fetch_assoc())) {
            $history[] = ['id' => (int)$h['id'], 'subject' => $h['subject'],
                          'status' => $h['status'], 'created_at' => $h['created_at']];
        }

        lms_ok(['ticket' => $shapeTicket($t), 'messages' => $messages, 'history' => $history]);
    }

    if ($action === 'reply') {
        $id = lms_int($in['ticket_id'] ?? 0);
        if (!$id) lms_error('A ticket id is required');

        $body = trim((string)($in['body'] ?? ''));
        if ($body === '') lms_error('Type a reply before sending');
        $body = mb_substr($body, 0, 6000);

        $res = $conn->query("SELECT id FROM lms_support_tickets WHERE id = $id LIMIT 1");
        if (!$res || !$res->num_rows) lms_error('That ticket could not be found', 404);

        /* There is no admin session in this file — the React panel is the thing
           that knows who is signed in, so it sends the name. Anything missing
           becomes "Support team", which is what the learner should see anyway
           when a reply is not from a named person. */
        $author = trim((string)($in['author'] ?? ''));
        $author = $author === '' ? 'Support team' : mb_substr($author, 0, 120);

        $conn->query("INSERT INTO lms_support_messages (ticket_id, sender, author, body)
                      VALUES ($id, 'admin', '" . lms_esc($conn, $author) . "',
                              '" . lms_esc($conn, $body) . "')");

        /* status goes to 'answered' unless the admin closed it in the same
           action — see the `close` flag the drawer sends with its last word. */
        $close  = !empty($in['close']);
        $status = $close ? 'closed' : 'answered';

        $conn->query("UPDATE lms_support_tickets
                      SET messages = messages + 1,
                          learner_unread = learner_unread + 1,
                          admin_unread = 0,
                          status = '" . $status . "',
                          last_message_at = NOW()
                      WHERE id = $id");

        lms_ok(['ticket_id' => $id], $close ? 'Replied and closed' : 'Reply sent');
    }

    if ($action === 'status') {
        $id = lms_int($in['id'] ?? 0);
        $st = (string)($in['status'] ?? '');
        if (!$id) lms_error('A ticket id is required');
        if (!in_array($st, ['open', 'answered', 'closed'], true)) lms_error('Unknown status: ' . $st);

        $conn->query("UPDATE lms_support_tickets SET status = '" . lms_esc($conn, $st) . "' WHERE id = $id");
        lms_ok(null, 'Ticket marked ' . $st);
    }

    if ($action === 'delete') {
        $id = lms_int($in['id'] ?? 0);
        if (!$id) lms_error('A ticket id is required');
        /* The messages go with it — nothing else references them, and leaving
           orphans behind would keep the thread in every count. */
        $conn->query("DELETE FROM lms_support_messages WHERE ticket_id = $id");
        $conn->query("DELETE FROM lms_support_tickets WHERE id = $id");
        lms_ok(null, 'Ticket deleted');
    }

    lms_error('Unknown support action: ' . $action);
}

/* ───────────────────────── SETTINGS ───────────────────────── */
if ($resource === 'settings') {

    if ($action === 'get') {
        $out = [];
        $res = $conn->query("SELECT setting_key, setting_value FROM lms_settings");
        while ($res && ($r = $res->fetch_assoc())) {
            /* Never ship the hash to the client — the UI only needs to know
               whether a password exists and when it was last changed. */
            if ($r['setting_key'] === 'store_login_password_hash') {
                $out['store_login_password_set'] = $r['setting_value'] !== '' ? '1' : '0';
                continue;
            }
            $out[$r['setting_key']] = $r['setting_value'];
        }
        lms_ok(['settings' => $out]);
    }

    if ($action === 'save') {
        $settings = is_array($in['settings'] ?? null) ? $in['settings'] : lms_json_decode($in['settings'] ?? '');
        foreach ($settings as $k => $v) {
            $ke = lms_esc($conn, substr((string)$k, 0, 80));
            $ve = lms_esc($conn, is_array($v) ? json_encode($v) : (string)$v);
            $conn->query("INSERT INTO lms_settings (setting_key, setting_value) VALUES ('$ke', '$ve')
                          ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)");
        }
        lms_ok(null, 'Settings saved');
    }

    /* The single shared password ₹99-store buyers use to open the learning
       portal (training.internshipstudio.com). Stored ONLY as a bcrypt hash —
       the plaintext is shown back to the admin once, on save, and never read
       from the database again, so a database dump does not hand anyone a
       working login. Clearing it closes that sign-in path entirely. */
    if ($action === 'set_store_password') {
        $pw = (string)($in['password'] ?? '');

        if ($pw === '') {
            $conn->query("DELETE FROM lms_settings WHERE setting_key = 'store_login_password_hash'");
            $conn->query("INSERT INTO lms_settings (setting_key, setting_value) VALUES ('store_login_password_set_at', '')
                          ON DUPLICATE KEY UPDATE setting_value = ''");
            lms_ok(['set' => false], 'Store login password removed — store-only buyers can no longer sign in');
        }

        if (strlen($pw) < 8) lms_error('Use at least 8 characters — this password is shared with every store buyer');

        $hash = lms_esc($conn, password_hash($pw, PASSWORD_BCRYPT));
        $conn->query("INSERT INTO lms_settings (setting_key, setting_value)
                      VALUES ('store_login_password_hash', '$hash')
                      ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)");
        $now = date('Y-m-d H:i:s');
        $conn->query("INSERT INTO lms_settings (setting_key, setting_value)
                      VALUES ('store_login_password_set_at', '$now')
                      ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)");

        lms_ok(['set' => true, 'set_at' => $now], 'Store login password updated');
    }

    lms_error('Unknown settings action: ' . $action);
}

/* ───────────────────────── EDITOR IMAGE UPLOAD ───────────────────────── */
if ($resource === 'editor' && $action === 'upload_image') {
    if (empty($_FILES['image'])) lms_error('No image uploaded');
    $up = lms_s3_put($_FILES['image'], 'lms/editor');
    if (!$up) lms_error('Upload to S3 failed', 500);
    lms_ok(['url' => $up['url']]);
}

lms_error('Unknown resource: ' . $resource, 404);

/* ═══════════════════════════════════════════════════════════════════════════
   SHARED PROCEDURES
   ═══════════════════════════════════════════════════════════════════════════ */

/**
 * Creates a `users` row plus the satellite rows the rest of the platform
 * expects (additional_details / user_steps), mirroring register.php.
 * Returns ['ok'=>bool, 'user_id'=>int, 'password'=>string, 'message'=>string].
 */
/**
 * Resolve an email to a users.user_id, optionally registering the account.
 *
 * Returns ['user_id' => int, 'created' => bool, 'password' => string].
 * user_id is 0 when the email is unknown AND $createAccount is false — that is
 * a deliberate outcome, not a failure: the caller still writes the order row,
 * just without an account attached to it.
 */
function lms_resolve_learner($conn, $email, $name, $phone, $password, $createAccount) {
    $ee  = lms_esc($conn, strtolower(trim($email)));
    $chk = $conn->query("SELECT user_id FROM users WHERE email = '$ee' LIMIT 1");
    if ($chk && $chk->num_rows) {
        return ['user_id' => (int)$chk->fetch_assoc()['user_id'], 'created' => false, 'password' => ''];
    }
    if (!$createAccount) {
        return ['user_id' => 0, 'created' => false, 'password' => ''];
    }
    $r = lms_register_user($conn, $email, $name ?: $email, $phone,
                           $password !== '' ? $password : LMS_DEFAULT_PASSWORD);
    if (!$r['ok']) return ['user_id' => 0, 'created' => false, 'password' => '', 'error' => $r['message']];
    return ['user_id' => (int)$r['user_id'], 'created' => true, 'password' => $r['password']];
}

/**
 * Write one row into the ₹99 store's order table on behalf of an admin.
 *
 * order_id and payment_id are minted with the 'training' prefix so a row that
 * never touched a real checkout is identifiable on sight — no Razorpay or
 * Cashfree reference ever looks like that. razorpay_order_id stays NULL for
 * the same reason: there is no gateway order behind this. 'provider' records
 * whichever gateway was live at the time (settings.payment_method) so the row
 * reconciles alongside genuine ones, and source='admin' is what the
 * "Added by us" filter reads.
 */
function lms_store_order_insert($conn, $d) {
    $name  = trim((string)($d['name'] ?? ''));
    $parts = preg_split('/\s+/', $name, 2);
    $first = trim((string)($d['first_name'] ?? ($parts[0] ?? '')));
    $last  = trim((string)($d['last_name']  ?? ($parts[1] ?? '')));
    if ($first === '') $first = (string)$d['email'];

    $courseName = trim((string)($d['course_name'] ?? '')) ?: 'Training Course';
    $courseSlug = trim((string)($d['course_slug'] ?? '')) ?: lms_slug($courseName);
    $amount     = (float)($d['amount'] ?? 0);

    /* 'courses' mirrors what the store writes for a multi-course cart, so the
       ₹99 panel and any report reading that JSON keeps working unchanged. */
    $courses = json_encode([[
        'name'  => $courseName,
        'slug'  => $courseSlug,
        'price' => $amount,
    ]], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

    $status = in_array($d['status'] ?? '', ['initiated', 'success', 'failed'], true)
        ? $d['status'] : 'success';

    $uid = (int)($d['user_id'] ?? 0);

    $sql = "INSERT INTO ninety_nine_store_orders
              (user_id, first_name, last_name, email, phone_number, state,
               course_slug, course_name, courses, course_count, batch,
               order_id, razorpay_order_id, payment_id, provider, source,
               from_main, amount, status)
            VALUES ("
        . ($uid > 0 ? $uid : 'NULL') . ",
               '" . lms_esc($conn, $first) . "',
               '" . lms_esc($conn, $last) . "',
               '" . lms_esc($conn, strtolower((string)$d['email'])) . "',
               '" . lms_esc($conn, preg_replace('/[^0-9+]/', '', (string)($d['phone'] ?? ''))) . "',
               " . (trim((string)($d['state'] ?? '')) === '' ? 'NULL' : "'" . lms_esc($conn, $d['state']) . "'") . ",
               '" . lms_esc($conn, $courseSlug) . "',
               '" . lms_esc($conn, $courseName) . "',
               '" . lms_esc($conn, $courses) . "',
               1,
               " . (trim((string)($d['batch'] ?? '')) === '' ? 'NULL' : "'" . lms_esc($conn, $d['batch']) . "'") . ",
               '" . lms_esc($conn, lms_training_ref()) . "',
               NULL,
               '" . lms_esc($conn, lms_training_ref()) . "',
               '" . lms_esc($conn, lms_active_payment_provider($conn)) . "',
               'admin',
               'no',
               $amount,
               '$status')";

    if (!$conn->query($sql)) return ['ok' => false, 'message' => $conn->error];
    return ['ok' => true, 'id' => (int)$conn->insert_id];
}

function lms_register_user($conn, $email, $name, $phone = '', $password = '') {
    $name  = trim($name);
    $parts = preg_split('/\s+/', $name, 2);
    $fname = $parts[0] ?? $name;
    $lname = $parts[1] ?? '';
    $phone = preg_replace('/[^0-9+]/', '', (string)$phone);

    if ($password === '') {
        $password = substr(str_shuffle('0123456789abcdefghijkmnopqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ'), 0, 10);
    }
    $hash = password_hash($password, PASSWORD_BCRYPT);

    /* username must be unique — suffix a counter until it is */
    $base = preg_replace('/[^a-z0-9]/', '', strtolower($fname)) ?: 'learner';
    $username = $base;
    for ($i = 1; $i <= 50; $i++) {
        $ue = $conn->real_escape_string($username);
        $r  = $conn->query("SELECT user_id FROM users WHERE username = '$ue' LIMIT 1");
        if (!$r || !$r->num_rows) break;
        $username = $base . $i;
    }

    $stmt = $conn->prepare("INSERT INTO users
        (username, fname, lname, name, email, password, temp_password, phone, role, active)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, 4, 1)");
    if (!$stmt) return ['ok' => false, 'message' => 'Prepare failed: ' . $conn->error];
    $stmt->bind_param('ssssssss', $username, $fname, $lname, $name, $email, $hash, $password, $phone);
    if (!$stmt->execute()) {
        $err = $stmt->error;
        $stmt->close();
        return ['ok' => false, 'message' => 'Insert failed: ' . $err];
    }
    $uid = $stmt->insert_id;
    $stmt->close();

    /* satellite rows — non-fatal if the table shape differs on this box */
    @$conn->query("INSERT IGNORE INTO additional_details (user_id) VALUES ($uid)");
    @$conn->query("INSERT IGNORE INTO user_steps (user_id) VALUES ($uid)");

    return ['ok' => true, 'user_id' => $uid, 'password' => $password, 'message' => ''];
}

/** Idempotent enrol (the unique key makes a repeat call a no-op update). */
function lms_enroll($conn, $courseId, $userId, $opts = []) {
    $courseId = (int)$courseId;
    $userId   = (int)$userId;
    if (!$courseId || !$userId) return false;

    $type   = in_array($opts['access_type'] ?? '', ['paid', 'free', 'trial'], true) ? $opts['access_type'] : 'paid';
    $amount = (float)($opts['amount'] ?? 0);
    $source = $conn->real_escape_string((string)($opts['source'] ?? 'admin'));
    $expiry = trim((string)($opts['expiry_date'] ?? ''));

    /* fall back to the course's own validity window when no date was given */
    if ($expiry === '') {
        $r = $conn->query("SELECT validity_days FROM lms_courses WHERE id = $courseId");
        $days = $r ? (int)($r->fetch_assoc()['validity_days'] ?? 0) : 0;
        if ($days > 0) $expiry = date('Y-m-d', strtotime("+$days days"));
    }
    $expSql = $expiry === '' ? 'NULL' : "'" . $conn->real_escape_string($expiry) . "'";

    return (bool)$conn->query("INSERT INTO lms_enrollments
        (course_id, user_id, access_type, amount, source, expiry_date, status)
        VALUES ($courseId, $userId, '$type', $amount, '$source', $expSql, 'active')
        ON DUPLICATE KEY UPDATE
            access_type = VALUES(access_type),
            amount      = VALUES(amount),
            expiry_date = VALUES(expiry_date),
            status      = 'active'");
}

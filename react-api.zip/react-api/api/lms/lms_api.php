<?php
/**
 * lms_api.php
 * ---------------------------------------------------------------------------
 * SINGLE-FILE admin API for the "LMS System" panel (Learnyst-style LMS).
 *
 * Hierarchy:
 *   lms_courses                       (the main card — "Software Testing", ...)
 *     -> lms_sections                 (Module 1, Module 2, Lecture 1 ...)
 *          -> lms_lessons             (video / article / pdf / quiz / form)
 *               -> lms_lesson_attachments  (S3 files + links)
 *               -> lms_lesson_fields       (dynamic form builder — the data we
 *                    collect from the learner for THIS lesson; same builder
 *                    shape as internship_assignment_fields)
 *                    -> lms_form_responses (what learners submitted)
 *     -> lms_quizzes -> lms_quiz_questions -> lms_quiz_attempts
 *     -> lms_enrollments / lms_progress
 *
 * Learners are the EXISTING `users` rows. The Learners tab reads users who
 * purchased an internship (internship_payment) plus anyone already enrolled in
 * an LMS course; "Add learner" registers a brand-new `users` row exactly the
 * way user_dashboard/api/register.php does, and the CSV importer does the same
 * in bulk (mirrors the Netcore contact-import wizard's upload -> map -> run).
 *
 * Routes (all as ?resource=X&action=Y):
 *   dashboard     : stats
 *   courses       : list|get|create|update|delete|trash|restore|duplicate|publish|reorder|thumbnail
 *   sections      : list|create|update|delete|reorder
 *   lessons       : list|get|create|update|delete|reorder|move|toggle_hidden|upload_video
 *   attachments   : list|create|update|delete|reorder     (multipart on create)
 *   fields        : list|create|update|delete|toggle|reorder
 *   responses     : list|export|delete
 *   quizzes       : list|get|create|update|delete|duplicate|toggle
 *   questions     : list|create|update|delete|reorder|bulk_create
 *   attempts      : list|get|delete
 *   learners      : list|get|create|import_preview|import_run|import_history
 *   enrollments   : list|create|update|delete|bulk_create
 *   reports       : progress|quiz|course_funnel
 *   settings      : get|save
 *   editor        : upload_image
 *
 * Responses: { "status":"success", "data":{...} } | { "status":"error", ... }
 *
 * Bootstrap / error handling / S3 approach mirror assignments_api.php so the
 * whole internship-system + LMS family behaves identically in production.
 * Access is gated by the React admin panel's permission system, not here.
 * ---------------------------------------------------------------------------
 */

@ini_set('display_errors', '0');
error_reporting(E_ALL);

define('LMS_LOG_FILE', __DIR__ . '/lms_errors.log');
@ini_set('log_errors', '1');
@ini_set('error_log', LMS_LOG_FILE);

function lms_log($label, $msg) {
    $line = '[' . date('Y-m-d H:i:s') . '] ' . $label . ': ' . $msg
          . '  {' . ($_SERVER['REQUEST_METHOD'] ?? 'CLI') . ' '
          . ($_SERVER['REQUEST_URI'] ?? '') . '}' . PHP_EOL;
    @file_put_contents(LMS_LOG_FILE, $line, FILE_APPEND | LOCK_EX);
}

set_error_handler(function ($no, $str, $file, $line) {
    if (strpos($file, 'lms_api.php') !== false) {
        lms_log('PHP-ERROR(' . $no . ')', $str . ' in ' . $file . ':' . $line);
    }
    return true;
});

/* shared bootstrap — provides global $conn (same as internship-system/*) */
ob_start();
chdir('/home/istudio/public_html/cit/common');
include '/home/istudio/public_html/cit/common/helper.php';
ob_clean();

/* AWS SDK — same vendor autoload + bucket/creds as assignments_api.php */
require_once '/home/istudio/public_html/istudio_dashboard/api/vendor/autoload.php';
use Aws\S3\S3Client;
use Aws\Exception\AwsException;

header('Content-Type: application/json');

register_shutdown_function(function () {
    $e = error_get_last();
    if ($e && in_array($e['type'], [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR], true)) {
        lms_log('FATAL', $e['message'] . ' in ' . $e['file'] . ':' . $e['line']);
        if (!headers_sent()) header('Content-Type: application/json');
        echo json_encode(['status' => 'error', 'message' => 'Server error: ' . $e['message']]);
    }
});

set_exception_handler(function ($e) {
    lms_log('EXCEPTION', get_class($e) . ': ' . $e->getMessage()
        . ' in ' . $e->getFile() . ':' . $e->getLine());
    if (!headers_sent()) {
        http_response_code(500);
        header('Content-Type: application/json');
    }
    echo json_encode(['status' => 'error', 'message' => 'Server error: ' . $e->getMessage()]);
    exit;
});

/* ====== helpers ====== */
function lms_out($p) { echo json_encode($p); exit; }
function lms_error($m, $c = 400) {
    lms_log('API-ERROR(' . $c . ')', $m);
    http_response_code($c);
    lms_out(['status' => 'error', 'message' => $m]);
}
function lms_ok($d = null, $m = '') {
    $r = ['status' => 'success'];
    if ($m !== '') $r['message'] = $m;
    if ($d !== null) $r['data'] = $d;
    lms_out($r);
}
function lms_input() {
    $i = $_POST;
    if (empty($i)) {
        $j = json_decode(file_get_contents('php://input'), true);
        if (is_array($j)) $i = $j;
    }
    return $i;
}
function lms_esc($conn, $v) { return $conn->real_escape_string((string)$v); }
function lms_int($v, $d = 0) { return $v === null || $v === '' ? $d : (int)$v; }
function lms_json_decode($s) {
    if ($s === null || $s === '') return [];
    $d = json_decode($s, true);
    return is_array($d) ? $d : [];
}
/** Always store JSON arrays/objects as a JSON string, never a bare scalar. */
function lms_json_col($v) {
    if ($v === null || $v === '') return null;
    if (is_array($v)) return json_encode($v);
    $d = json_decode($v, true);
    return is_array($d) ? json_encode($d) : json_encode([$v]);
}
function lms_slug($s) {
    $s = strtolower(trim((string)$s));
    $s = preg_replace('/[^a-z0-9]+/', '-', $s);
    return trim($s, '-') ?: 'course';
}

/* ====== S3 (same bucket / creds as assignments_api.php) ====== */
const LMS_S3_BUCKET = 'internshipstudio-prod-data-bucket-new';
const LMS_S3_REGION = 'ap-south-1';

function lms_s3_client() {
    return new S3Client([
        'version'     => 'latest',
        'region'      => LMS_S3_REGION,
        'credentials' => [
            'key'    => 'AKIAYVYU7O43T344J2MD',
            'secret' => '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',
        ],
    ]);
}

/** Uploads $_FILES entry to S3 under $prefix, returns [url, key, name, size, mime] or null. */
function lms_s3_put($file, $prefix) {
    if (!isset($file['tmp_name']) || !is_uploaded_file($file['tmp_name'])) return null;
    $orig = preg_replace('/[^A-Za-z0-9._-]+/', '_', $file['name'] ?? 'file');
    $key  = rtrim($prefix, '/') . '/' . date('Y/m') . '/' . uniqid('', true) . '_' . $orig;
    $mime = $file['type'] ?: 'application/octet-stream';
    try {
        lms_s3_client()->putObject([
            'Bucket'      => LMS_S3_BUCKET,
            'Key'         => $key,
            'SourceFile'  => $file['tmp_name'],
            'ContentType' => $mime,
        ]);
    } catch (AwsException $e) {
        lms_log('S3-UPLOAD-FAIL', $key . ': ' . $e->getMessage());
        return null;
    }
    return [
        'url'  => 'https://' . LMS_S3_BUCKET . '.s3.' . LMS_S3_REGION . '.amazonaws.com/' . $key,
        'key'  => $key,
        'name' => $file['name'] ?? $orig,
        'size' => (int)($file['size'] ?? 0),
        'mime' => $mime,
    ];
}
function lms_s3_delete($key) {
    if (!$key) return;
    try { lms_s3_client()->deleteObject(['Bucket' => LMS_S3_BUCKET, 'Key' => $key]); }
    catch (AwsException $e) { lms_log('S3-DELETE-FAIL', $key . ': ' . $e->getMessage()); }
}

/* ═══════════════════════════════════════════════════════════════════════════
   SCHEMA — created on first hit, then a no-op forever after
   ═══════════════════════════════════════════════════════════════════════════ */
$conn->query("CREATE TABLE IF NOT EXISTS lms_courses (
    id             INT AUTO_INCREMENT PRIMARY KEY,
    title          VARCHAR(255) NOT NULL,
    slug           VARCHAR(255)      DEFAULT NULL,
    subtitle       VARCHAR(500)      DEFAULT NULL,
    description    LONGTEXT          DEFAULT NULL,
    category       VARCHAR(120)      DEFAULT NULL,
    thumbnail_url  TEXT              DEFAULT NULL,
    thumbnail_key  VARCHAR(512)      DEFAULT NULL,
    price          DECIMAL(10,2)     DEFAULT 0,
    sale_price     DECIMAL(10,2)     DEFAULT 0,
    is_free        TINYINT(1)        DEFAULT 0,
    validity_days  INT               DEFAULT 365,
    encryption     ENUM('encrypted','unencrypted') DEFAULT 'unencrypted',
    instructor     VARCHAR(255)      DEFAULT NULL,
    tags           TEXT              DEFAULT NULL,
    seo_title      VARCHAR(255)      DEFAULT NULL,
    seo_description VARCHAR(500)     DEFAULT NULL,
    internship_id  INT               DEFAULT 0,
    sort_order     INT               DEFAULT 0,
    status         ENUM('draft','published','unpublished','trashed') DEFAULT 'draft',
    created_by     INT               DEFAULT 0,
    created_at     TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,
    updated_at     TIMESTAMP    DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_status_order (status, sort_order),
    INDEX idx_internship (internship_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

$conn->query("CREATE TABLE IF NOT EXISTS lms_sections (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    course_id   INT          NOT NULL,
    title       VARCHAR(255) NOT NULL,
    description TEXT              DEFAULT NULL,
    drip_days   INT               DEFAULT 0,
    sort_order  INT               DEFAULT 0,
    status      ENUM('active','inactive') DEFAULT 'active',
    created_at  TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,
    updated_at  TIMESTAMP    DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_course_order (course_id, sort_order)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

$conn->query("CREATE TABLE IF NOT EXISTS lms_lessons (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    course_id       INT          NOT NULL,
    section_id      INT          NOT NULL,
    title           VARCHAR(255) NOT NULL,
    lesson_type     ENUM('video','article','pdf','quiz','live','form') DEFAULT 'video',
    video_provider  VARCHAR(30)       DEFAULT 'url',
    video_url       TEXT              DEFAULT NULL,
    video_key       VARCHAR(512)      DEFAULT NULL,
    duration_secs   INT               DEFAULT 0,
    content         LONGTEXT          DEFAULT NULL,
    quiz_id         INT               DEFAULT 0,
    is_free_preview TINYINT(1)        DEFAULT 0,
    is_hidden       TINYINT(1)        DEFAULT 0,
    drip_days       INT               DEFAULT 0,
    sort_order      INT               DEFAULT 0,
    status          ENUM('draft','published') DEFAULT 'published',
    created_at      TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,
    updated_at      TIMESTAMP    DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_section_order (section_id, sort_order),
    INDEX idx_course (course_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

$conn->query("CREATE TABLE IF NOT EXISTS lms_lesson_attachments (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    lesson_id   INT          NOT NULL,
    kind        VARCHAR(10)       DEFAULT 'file',
    title       VARCHAR(255)      DEFAULT NULL,
    description TEXT              DEFAULT NULL,
    file_url    TEXT         NOT NULL,
    file_key    VARCHAR(512)      DEFAULT NULL,
    file_name   VARCHAR(255)      DEFAULT NULL,
    file_type   VARCHAR(40)       DEFAULT NULL,
    file_size   BIGINT            DEFAULT 0,
    mime_type   VARCHAR(150)      DEFAULT NULL,
    sort_order  INT               DEFAULT 0,
    status      ENUM('active','inactive') DEFAULT 'active',
    created_at  TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_lesson_order (lesson_id, sort_order)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

/* the per-lesson dynamic form builder — same column shape as
   internship_assignment_fields so the React builder is a straight reuse */
$conn->query("CREATE TABLE IF NOT EXISTS lms_lesson_fields (
    id                  INT AUTO_INCREMENT PRIMARY KEY,
    lesson_id           INT          NOT NULL,
    field_order         INT               DEFAULT 0,
    field_type          VARCHAR(30)  NOT NULL,
    label               VARCHAR(500) NOT NULL,
    placeholder         VARCHAR(500)      DEFAULT NULL,
    help_text           VARCHAR(1000)     DEFAULT NULL,
    is_required         TINYINT(1)        DEFAULT 1,
    options             TEXT              DEFAULT NULL,
    accepted_extensions VARCHAR(255)      DEFAULT NULL,
    max_file_size_mb    INT               DEFAULT 25,
    status              ENUM('active','inactive') DEFAULT 'active',
    created_at          TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,
    updated_at          TIMESTAMP    DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_lesson_order (lesson_id, field_order)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

$conn->query("CREATE TABLE IF NOT EXISTS lms_form_responses (
    id         INT AUTO_INCREMENT PRIMARY KEY,
    lesson_id  INT NOT NULL,
    course_id  INT NOT NULL,
    user_id    INT NOT NULL,
    payload    LONGTEXT DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_lesson (lesson_id, created_at),
    INDEX idx_user (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

$conn->query("CREATE TABLE IF NOT EXISTS lms_quizzes (
    id                INT AUTO_INCREMENT PRIMARY KEY,
    course_id         INT          DEFAULT 0,
    title             VARCHAR(255) NOT NULL,
    description       TEXT              DEFAULT NULL,
    instructions      LONGTEXT          DEFAULT NULL,
    duration_mins     INT               DEFAULT 0,
    pass_percentage   INT               DEFAULT 40,
    max_attempts      INT               DEFAULT 0,
    shuffle_questions TINYINT(1)        DEFAULT 0,
    shuffle_options   TINYINT(1)        DEFAULT 0,
    show_answers      ENUM('never','after_submit','after_pass') DEFAULT 'after_submit',
    negative_marking  TINYINT(1)        DEFAULT 0,
    show_result       TINYINT(1)        DEFAULT 1,
    is_graded         TINYINT(1)        DEFAULT 1,
    status            ENUM('draft','published') DEFAULT 'draft',
    created_by        INT               DEFAULT 0,
    created_at        TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,
    updated_at        TIMESTAMP    DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_course (course_id, status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

$conn->query("CREATE TABLE IF NOT EXISTS lms_quiz_questions (
    id             INT AUTO_INCREMENT PRIMARY KEY,
    quiz_id        INT          NOT NULL,
    question_type  VARCHAR(30)       DEFAULT 'single',
    question       LONGTEXT     NOT NULL,
    image_url      TEXT              DEFAULT NULL,
    options        TEXT              DEFAULT NULL,
    correct        TEXT              DEFAULT NULL,
    marks          DECIMAL(6,2)      DEFAULT 1,
    negative_marks DECIMAL(6,2)      DEFAULT 0,
    explanation    LONGTEXT          DEFAULT NULL,
    difficulty     ENUM('easy','medium','hard') DEFAULT 'medium',
    sort_order     INT               DEFAULT 0,
    status         ENUM('active','inactive') DEFAULT 'active',
    created_at     TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,
    updated_at     TIMESTAMP    DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_quiz_order (quiz_id, sort_order)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

$conn->query("CREATE TABLE IF NOT EXISTS lms_quiz_attempts (
    id           INT AUTO_INCREMENT PRIMARY KEY,
    quiz_id      INT NOT NULL,
    course_id    INT DEFAULT 0,
    user_id      INT NOT NULL,
    score        DECIMAL(8,2) DEFAULT 0,
    total_marks  DECIMAL(8,2) DEFAULT 0,
    percentage   DECIMAL(6,2) DEFAULT 0,
    passed       TINYINT(1)   DEFAULT 0,
    answers      LONGTEXT     DEFAULT NULL,
    started_at   TIMESTAMP    NULL DEFAULT NULL,
    submitted_at TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_quiz_user (quiz_id, user_id),
    INDEX idx_user (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

$conn->query("CREATE TABLE IF NOT EXISTS lms_enrollments (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    course_id   INT NOT NULL,
    user_id     INT NOT NULL,
    access_type ENUM('paid','free','trial') DEFAULT 'paid',
    amount      DECIMAL(10,2) DEFAULT 0,
    source      VARCHAR(60)   DEFAULT 'admin',
    expiry_date DATE          DEFAULT NULL,
    status      ENUM('active','expired','revoked') DEFAULT 'active',
    enrolled_at TIMESTAMP     DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uniq_course_user (course_id, user_id),
    INDEX idx_user (user_id),
    INDEX idx_course_status (course_id, status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

$conn->query("CREATE TABLE IF NOT EXISTS lms_progress (
    id           INT AUTO_INCREMENT PRIMARY KEY,
    user_id      INT NOT NULL,
    course_id    INT NOT NULL,
    lesson_id    INT NOT NULL,
    status       ENUM('started','completed') DEFAULT 'started',
    watched_secs INT DEFAULT 0,
    updated_at   TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uniq_user_lesson (user_id, lesson_id),
    INDEX idx_course_user (course_id, user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

$conn->query("CREATE TABLE IF NOT EXISTS lms_import_logs (
    id            INT AUTO_INCREMENT PRIMARY KEY,
    file_name     VARCHAR(255) DEFAULT NULL,
    course_id     INT          DEFAULT 0,
    total_rows    INT          DEFAULT 0,
    created_rows  INT          DEFAULT 0,
    existing_rows INT          DEFAULT 0,
    enrolled_rows INT          DEFAULT 0,
    failed_rows   INT          DEFAULT 0,
    errors        LONGTEXT     DEFAULT NULL,
    created_by    INT          DEFAULT 0,
    created_at    TIMESTAMP    DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

$conn->query("CREATE TABLE IF NOT EXISTS lms_settings (
    setting_key   VARCHAR(80) PRIMARY KEY,
    setting_value LONGTEXT DEFAULT NULL,
    updated_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

/* ═══════════════════════════════════════════════════════════════════════════
   ROUTER
   ═══════════════════════════════════════════════════════════════════════════ */
$resource = $_GET['resource'] ?? '';
$action   = $_GET['action']   ?? '';
$in       = lms_input();

/* ───────────────────────── DASHBOARD ───────────────────────── */
if ($resource === 'dashboard') {
    $one = function ($sql) use ($conn) {
        $r = $conn->query($sql);
        return $r ? (float)($r->fetch_row()[0] ?? 0) : 0;
    };

    $stats = [
        'courses'        => (int)$one("SELECT COUNT(*) FROM lms_courses WHERE status <> 'trashed'"),
        'published'      => (int)$one("SELECT COUNT(*) FROM lms_courses WHERE status = 'published'"),
        'draft'          => (int)$one("SELECT COUNT(*) FROM lms_courses WHERE status IN ('draft','unpublished')"),
        'trashed'        => (int)$one("SELECT COUNT(*) FROM lms_courses WHERE status = 'trashed'"),
        'sections'       => (int)$one("SELECT COUNT(*) FROM lms_sections"),
        'lessons'        => (int)$one("SELECT COUNT(*) FROM lms_lessons"),
        'quizzes'        => (int)$one("SELECT COUNT(*) FROM lms_quizzes"),
        'questions'      => (int)$one("SELECT COUNT(*) FROM lms_quiz_questions WHERE status = 'active'"),
        'enrollments'    => (int)$one("SELECT COUNT(*) FROM lms_enrollments WHERE status = 'active'"),
        'learners'       => (int)$one("SELECT COUNT(DISTINCT user_id) FROM lms_enrollments"),
        'attempts'       => (int)$one("SELECT COUNT(*) FROM lms_quiz_attempts"),
        'responses'      => (int)$one("SELECT COUNT(*) FROM lms_form_responses"),
        'video_seconds'  => (int)$one("SELECT COALESCE(SUM(duration_secs),0) FROM lms_lessons"),
        'revenue'        => $one("SELECT COALESCE(SUM(amount),0) FROM lms_enrollments WHERE status='active'"),
        'completions'    => (int)$one("SELECT COUNT(*) FROM lms_progress WHERE status='completed'"),
    ];

    /* enrollments per month, last 12 months — feeds the bar chart */
    $months = [];
    $r = $conn->query("SELECT DATE_FORMAT(enrolled_at,'%Y-%m') ym, COUNT(*) c,
                              COALESCE(SUM(amount),0) amt
                       FROM lms_enrollments
                       WHERE enrolled_at >= DATE_SUB(CURDATE(), INTERVAL 12 MONTH)
                       GROUP BY ym ORDER BY ym");
    while ($r && ($row = $r->fetch_assoc())) {
        $months[$row['ym']] = ['count' => (int)$row['c'], 'amount' => (float)$row['amt']];
    }
    $series = [];
    for ($i = 11; $i >= 0; $i--) {
        $ym = date('Y-m', strtotime("-$i month"));
        $series[] = [
            'month'  => date("M 'y", strtotime($ym . '-01')),
            'count'  => $months[$ym]['count']  ?? 0,
            'amount' => $months[$ym]['amount'] ?? 0,
        ];
    }

    /* top courses by enrollment */
    $top = [];
    $r = $conn->query("SELECT c.id, c.title, c.thumbnail_url,
                              COUNT(e.id) enrolls, COALESCE(SUM(e.amount),0) revenue
                       FROM lms_courses c
                       LEFT JOIN lms_enrollments e ON e.course_id = c.id
                       WHERE c.status <> 'trashed'
                       GROUP BY c.id ORDER BY enrolls DESC, c.id DESC LIMIT 5");
    while ($r && ($row = $r->fetch_assoc())) {
        $top[] = [
            'id'        => (int)$row['id'],
            'title'     => $row['title'],
            'thumbnail' => $row['thumbnail_url'],
            'enrolls'   => (int)$row['enrolls'],
            'revenue'   => (float)$row['revenue'],
        ];
    }

    /* recent enrollments feed */
    $recent = [];
    $r = $conn->query("SELECT e.id, e.enrolled_at, e.access_type, e.amount,
                              u.name, u.email, c.title course_title
                       FROM lms_enrollments e
                       LEFT JOIN users u ON u.user_id = e.user_id
                       LEFT JOIN lms_courses c ON c.id = e.course_id
                       ORDER BY e.enrolled_at DESC LIMIT 8");
    while ($r && ($row = $r->fetch_assoc())) $recent[] = $row;

    lms_ok(['stats' => $stats, 'series' => $series, 'top_courses' => $top, 'recent' => $recent]);
}

/* ───────────────────────── COURSES ───────────────────────── */
if ($resource === 'courses') {

    if ($action === 'list' || $action === '') {
        $status = $_GET['status'] ?? 'all';
        $q      = trim($_GET['q'] ?? '');
        $where  = $status === 'all' ? "c.status <> 'trashed'" : "c.status = '" . lms_esc($conn, $status) . "'";
        if ($q !== '') {
            $qe = lms_esc($conn, $q);
            $where .= " AND (c.title LIKE '%$qe%' OR c.category LIKE '%$qe%')";
        }
        $sql = "SELECT c.*,
                   (SELECT COUNT(*) FROM lms_sections s WHERE s.course_id = c.id) section_count,
                   (SELECT COUNT(*) FROM lms_lessons  l WHERE l.course_id = c.id) lesson_count,
                   (SELECT COUNT(*) FROM lms_lessons  l WHERE l.course_id = c.id AND l.lesson_type='quiz') quiz_lesson_count,
                   (SELECT COALESCE(SUM(l.duration_secs),0) FROM lms_lessons l WHERE l.course_id = c.id) total_secs,
                   (SELECT COUNT(*) FROM lms_enrollments e WHERE e.course_id = c.id AND e.status='active') enroll_count
                FROM lms_courses c
                WHERE $where
                ORDER BY c.sort_order ASC, c.id DESC";
        $res = $conn->query($sql);
        if ($res === false) lms_error('Could not read lms_courses: ' . $conn->error, 500);

        $rows = [];
        while ($row = $res->fetch_assoc()) {
            $row['id']            = (int)$row['id'];
            $row['price']         = (float)$row['price'];
            $row['sale_price']    = (float)$row['sale_price'];
            $row['is_free']       = (int)$row['is_free'];
            $row['section_count'] = (int)$row['section_count'];
            $row['lesson_count']  = (int)$row['lesson_count'];
            $row['quiz_lesson_count'] = (int)$row['quiz_lesson_count'];
            $row['total_secs']    = (int)$row['total_secs'];
            $row['enroll_count']  = (int)$row['enroll_count'];
            $row['tags']          = lms_json_decode($row['tags']);
            $rows[] = $row;
        }

        /* the counter strip above the grid (Total / Published / Draft / Trashed) */
        $counts = ['total' => 0, 'published' => 0, 'draft' => 0, 'trashed' => 0];
        $cr = $conn->query("SELECT status, COUNT(*) c FROM lms_courses GROUP BY status");
        while ($cr && ($c = $cr->fetch_assoc())) {
            if ($c['status'] === 'trashed') $counts['trashed'] = (int)$c['c'];
            else {
                $counts['total'] += (int)$c['c'];
                if ($c['status'] === 'published') $counts['published'] += (int)$c['c'];
                else $counts['draft'] += (int)$c['c'];
            }
        }
        lms_ok(['courses' => $rows, 'counts' => $counts]);
    }

    if ($action === 'get') {
        $id  = lms_int($_GET['id'] ?? 0);
        $res = $conn->query("SELECT * FROM lms_courses WHERE id = $id");
        $row = $res ? $res->fetch_assoc() : null;
        if (!$row) lms_error('Course not found', 404);
        $row['id']   = (int)$row['id'];
        $row['tags'] = lms_json_decode($row['tags']);
        lms_ok(['course' => $row]);
    }

    if ($action === 'create' || $action === 'update') {
        $title = trim($in['title'] ?? '');
        if ($title === '') lms_error('Course title is required');

        $cols = [
            'title'           => $title,
            'slug'            => lms_slug($in['slug'] ?? $title),
            'subtitle'        => $in['subtitle'] ?? '',
            'description'     => $in['description'] ?? '',
            'category'        => $in['category'] ?? '',
            'instructor'      => $in['instructor'] ?? '',
            'seo_title'       => $in['seo_title'] ?? '',
            'seo_description' => $in['seo_description'] ?? '',
            'encryption'      => in_array($in['encryption'] ?? '', ['encrypted', 'unencrypted'], true)
                                   ? $in['encryption'] : 'unencrypted',
            'status'          => in_array($in['status'] ?? '', ['draft', 'published', 'unpublished', 'trashed'], true)
                                   ? $in['status'] : 'draft',
        ];
        $nums = [
            'price'         => (float)($in['price'] ?? 0),
            'sale_price'    => (float)($in['sale_price'] ?? 0),
            'is_free'       => !empty($in['is_free']) ? 1 : 0,
            'validity_days' => lms_int($in['validity_days'] ?? 365, 365),
            'internship_id' => lms_int($in['internship_id'] ?? 0),
            'sort_order'    => lms_int($in['sort_order'] ?? 0),
        ];

        $sets = [];
        foreach ($cols as $k => $v) $sets[] = "$k = '" . lms_esc($conn, $v) . "'";
        foreach ($nums as $k => $v) $sets[] = "$k = " . ($k === 'price' || $k === 'sale_price' ? (float)$v : (int)$v);
        $tags = lms_json_col($in['tags'] ?? null);
        $sets[] = 'tags = ' . ($tags === null ? 'NULL' : "'" . lms_esc($conn, $tags) . "'");

        if ($action === 'create') {
            $sets[] = 'created_by = ' . lms_int($in['created_by'] ?? 0);
            if (!$conn->query('INSERT INTO lms_courses SET ' . implode(', ', $sets))) {
                lms_error('Could not create course: ' . $conn->error, 500);
            }
            lms_ok(['id' => $conn->insert_id], 'Course created');
        }

        $id = lms_int($in['id'] ?? 0);
        if (!$id) lms_error('Course id is required');
        if (!$conn->query('UPDATE lms_courses SET ' . implode(', ', $sets) . " WHERE id = $id")) {
            lms_error('Could not update course: ' . $conn->error, 500);
        }
        lms_ok(['id' => $id], 'Course updated');
    }

    if ($action === 'thumbnail') {
        $id = lms_int($_POST['id'] ?? 0);
        if (!$id) lms_error('Course id is required');
        if (empty($_FILES['file'])) lms_error('No file uploaded');
        $up = lms_s3_put($_FILES['file'], 'lms/course-thumbnails');
        if (!$up) lms_error('Upload to S3 failed', 500);

        /* drop the previous object so thumbnails don't accumulate in the bucket */
        $old = $conn->query("SELECT thumbnail_key FROM lms_courses WHERE id = $id");
        $oldKey = $old ? ($old->fetch_assoc()['thumbnail_key'] ?? '') : '';

        $conn->query("UPDATE lms_courses
                      SET thumbnail_url = '" . lms_esc($conn, $up['url']) . "',
                          thumbnail_key = '" . lms_esc($conn, $up['key']) . "'
                      WHERE id = $id");
        if ($oldKey && $oldKey !== $up['key']) lms_s3_delete($oldKey);
        lms_ok(['url' => $up['url']], 'Thumbnail updated');
    }

    if ($action === 'publish') {
        $id = lms_int($in['id'] ?? 0);
        $to = ($in['status'] ?? 'published') === 'published' ? 'published' : 'unpublished';
        if (!$id) lms_error('Course id is required');
        $conn->query("UPDATE lms_courses SET status = '$to' WHERE id = $id");
        lms_ok(['id' => $id, 'status' => $to], $to === 'published' ? 'Course published' : 'Course unpublished');
    }

    if ($action === 'trash' || $action === 'restore') {
        $id = lms_int($in['id'] ?? 0);
        if (!$id) lms_error('Course id is required');
        $to = $action === 'trash' ? 'trashed' : 'draft';
        $conn->query("UPDATE lms_courses SET status = '$to' WHERE id = $id");
        lms_ok(['id' => $id], $action === 'trash' ? 'Moved to trash' : 'Restored');
    }

    if ($action === 'duplicate') {
        $id = lms_int($in['id'] ?? 0);
        if (!$id) lms_error('Course id is required');
        $src = $conn->query("SELECT * FROM lms_courses WHERE id = $id");
        $c   = $src ? $src->fetch_assoc() : null;
        if (!$c) lms_error('Course not found', 404);

        $title = lms_esc($conn, $c['title'] . ' (Copy)');
        $conn->query("INSERT INTO lms_courses
            (title, slug, subtitle, description, category, thumbnail_url, price, sale_price,
             is_free, validity_days, encryption, instructor, tags, internship_id, status)
            SELECT '$title', CONCAT(slug,'-copy'), subtitle, description, category, thumbnail_url,
                   price, sale_price, is_free, validity_days, encryption, instructor, tags,
                   internship_id, 'draft'
            FROM lms_courses WHERE id = $id");
        $newId = $conn->insert_id;

        /* deep-copy sections, then each section's lessons (fields/attachments are
           intentionally NOT copied — they usually need per-course rewriting) */
        $sr = $conn->query("SELECT * FROM lms_sections WHERE course_id = $id ORDER BY sort_order");
        while ($sr && ($s = $sr->fetch_assoc())) {
            $st = lms_esc($conn, $s['title']);
            $sd = lms_esc($conn, (string)$s['description']);
            $conn->query("INSERT INTO lms_sections (course_id, title, description, drip_days, sort_order, status)
                          VALUES ($newId, '$st', '$sd', " . (int)$s['drip_days'] . ", " . (int)$s['sort_order'] . ", '" . $s['status'] . "')");
            $newSec = $conn->insert_id;
            $oldSec = (int)$s['id'];
            $conn->query("INSERT INTO lms_lessons
                (course_id, section_id, title, lesson_type, video_provider, video_url, duration_secs,
                 content, quiz_id, is_free_preview, is_hidden, drip_days, sort_order, status)
                SELECT $newId, $newSec, title, lesson_type, video_provider, video_url, duration_secs,
                       content, quiz_id, is_free_preview, is_hidden, drip_days, sort_order, status
                FROM lms_lessons WHERE section_id = $oldSec");
        }
        lms_ok(['id' => $newId], 'Course duplicated');
    }

    if ($action === 'delete') {
        $id = lms_int($in['id'] ?? 0);
        if (!$id) lms_error('Course id is required');
        /* collect S3 keys before the rows disappear */
        $keys = [];
        $r = $conn->query("SELECT a.file_key FROM lms_lesson_attachments a
                           JOIN lms_lessons l ON l.id = a.lesson_id
                           WHERE l.course_id = $id AND a.file_key <> ''");
        while ($r && ($k = $r->fetch_assoc())) $keys[] = $k['file_key'];
        $r = $conn->query("SELECT thumbnail_key FROM lms_courses WHERE id = $id AND thumbnail_key <> ''");
        while ($r && ($k = $r->fetch_assoc())) $keys[] = $k['thumbnail_key'];

        $conn->query("DELETE f FROM lms_lesson_fields f JOIN lms_lessons l ON l.id = f.lesson_id WHERE l.course_id = $id");
        $conn->query("DELETE a FROM lms_lesson_attachments a JOIN lms_lessons l ON l.id = a.lesson_id WHERE l.course_id = $id");
        $conn->query("DELETE FROM lms_form_responses WHERE course_id = $id");
        $conn->query("DELETE FROM lms_lessons     WHERE course_id = $id");
        $conn->query("DELETE FROM lms_sections    WHERE course_id = $id");
        $conn->query("DELETE FROM lms_progress    WHERE course_id = $id");
        $conn->query("DELETE FROM lms_enrollments WHERE course_id = $id");
        $conn->query("DELETE FROM lms_courses     WHERE id = $id");

        foreach ($keys as $k) lms_s3_delete($k);
        lms_ok(null, 'Course deleted permanently');
    }

    if ($action === 'reorder') {
        $order = $in['order'] ?? [];
        if (!is_array($order)) lms_error('order must be an array of ids');
        foreach ($order as $i => $cid) {
            $conn->query('UPDATE lms_courses SET sort_order = ' . (int)$i . ' WHERE id = ' . (int)$cid);
        }
        lms_ok(null, 'Order saved');
    }

    lms_error('Unknown courses action: ' . $action);
}

/* ───────────────────────── SECTIONS ───────────────────────── */
if ($resource === 'sections') {

    if ($action === 'list') {
        $cid = lms_int($_GET['course_id'] ?? 0);
        if (!$cid) lms_error('course_id is required');

        $sections = [];
        $res = $conn->query("SELECT * FROM lms_sections WHERE course_id = $cid ORDER BY sort_order ASC, id ASC");
        while ($res && ($s = $res->fetch_assoc())) {
            $s['id']         = (int)$s['id'];
            $s['sort_order'] = (int)$s['sort_order'];
            $s['drip_days']  = (int)$s['drip_days'];
            $s['lessons']    = [];
            $sections[$s['id']] = $s;
        }

        if ($sections) {
            $ids = implode(',', array_keys($sections));
            $lr = $conn->query("SELECT l.id, l.section_id, l.title, l.lesson_type, l.video_url,
                                       l.duration_secs, l.is_free_preview, l.is_hidden, l.sort_order,
                                       l.status, l.quiz_id,
                                       (SELECT COUNT(*) FROM lms_lesson_attachments a
                                          WHERE a.lesson_id = l.id AND a.status='active') attachment_count,
                                       (SELECT COUNT(*) FROM lms_lesson_fields f
                                          WHERE f.lesson_id = l.id AND f.status='active') field_count,
                                       (SELECT COUNT(*) FROM lms_form_responses r
                                          WHERE r.lesson_id = l.id) response_count
                                FROM lms_lessons l
                                WHERE l.section_id IN ($ids)
                                ORDER BY l.sort_order ASC, l.id ASC");
            while ($lr && ($l = $lr->fetch_assoc())) {
                $sid = (int)$l['section_id'];
                $l['id']               = (int)$l['id'];
                $l['duration_secs']    = (int)$l['duration_secs'];
                $l['is_free_preview']  = (int)$l['is_free_preview'];
                $l['is_hidden']        = (int)$l['is_hidden'];
                $l['sort_order']       = (int)$l['sort_order'];
                $l['quiz_id']          = (int)$l['quiz_id'];
                $l['attachment_count'] = (int)$l['attachment_count'];
                $l['field_count']      = (int)$l['field_count'];
                $l['response_count']   = (int)$l['response_count'];
                if (isset($sections[$sid])) $sections[$sid]['lessons'][] = $l;
            }
        }

        $cr = $conn->query("SELECT * FROM lms_courses WHERE id = $cid");
        $course = $cr ? $cr->fetch_assoc() : null;
        if ($course) $course['tags'] = lms_json_decode($course['tags']);

        lms_ok(['course' => $course, 'sections' => array_values($sections)]);
    }

    if ($action === 'create') {
        $cid   = lms_int($in['course_id'] ?? 0);
        $title = trim($in['title'] ?? '');
        if (!$cid)         lms_error('course_id is required');
        if ($title === '') lms_error('Section title is required');

        $r    = $conn->query("SELECT COALESCE(MAX(sort_order), -1) + 1 n FROM lms_sections WHERE course_id = $cid");
        $next = $r ? (int)$r->fetch_assoc()['n'] : 0;

        $conn->query("INSERT INTO lms_sections (course_id, title, description, drip_days, sort_order)
                      VALUES ($cid, '" . lms_esc($conn, $title) . "',
                              '" . lms_esc($conn, $in['description'] ?? '') . "',
                              " . lms_int($in['drip_days'] ?? 0) . ", $next)");
        lms_ok(['id' => $conn->insert_id], 'Section added');
    }

    if ($action === 'update') {
        $id = lms_int($in['id'] ?? 0);
        if (!$id) lms_error('Section id is required');
        $sets = [
            "title = '"       . lms_esc($conn, trim($in['title'] ?? '')) . "'",
            "description = '" . lms_esc($conn, $in['description'] ?? '') . "'",
            'drip_days = '    . lms_int($in['drip_days'] ?? 0),
        ];
        if (isset($in['status']) && in_array($in['status'], ['active', 'inactive'], true)) {
            $sets[] = "status = '" . $in['status'] . "'";
        }
        $conn->query('UPDATE lms_sections SET ' . implode(', ', $sets) . " WHERE id = $id");
        lms_ok(['id' => $id], 'Section updated');
    }

    if ($action === 'delete') {
        $id = lms_int($in['id'] ?? 0);
        if (!$id) lms_error('Section id is required');
        $keys = [];
        $r = $conn->query("SELECT a.file_key FROM lms_lesson_attachments a
                           JOIN lms_lessons l ON l.id = a.lesson_id
                           WHERE l.section_id = $id AND a.file_key <> ''");
        while ($r && ($k = $r->fetch_assoc())) $keys[] = $k['file_key'];

        $conn->query("DELETE f FROM lms_lesson_fields f JOIN lms_lessons l ON l.id = f.lesson_id WHERE l.section_id = $id");
        $conn->query("DELETE a FROM lms_lesson_attachments a JOIN lms_lessons l ON l.id = a.lesson_id WHERE l.section_id = $id");
        $conn->query("DELETE FROM lms_lessons  WHERE section_id = $id");
        $conn->query("DELETE FROM lms_sections WHERE id = $id");
        foreach ($keys as $k) lms_s3_delete($k);
        lms_ok(null, 'Section deleted');
    }

    if ($action === 'reorder') {
        $order = $in['order'] ?? [];
        if (!is_array($order)) lms_error('order must be an array of ids');
        foreach ($order as $i => $sid) {
            $conn->query('UPDATE lms_sections SET sort_order = ' . (int)$i . ' WHERE id = ' . (int)$sid);
        }
        lms_ok(null, 'Sections reordered');
    }

    lms_error('Unknown sections action: ' . $action);
}

/* ───────────────────────── LESSONS ───────────────────────── */
if ($resource === 'lessons') {

    if ($action === 'get') {
        $id  = lms_int($_GET['id'] ?? 0);
        $res = $conn->query("SELECT l.*, s.title section_title, c.title course_title
                             FROM lms_lessons l
                             LEFT JOIN lms_sections s ON s.id = l.section_id
                             LEFT JOIN lms_courses  c ON c.id = l.course_id
                             WHERE l.id = $id");
        $l = $res ? $res->fetch_assoc() : null;
        if (!$l) lms_error('Lesson not found', 404);
        foreach (['id', 'course_id', 'section_id', 'duration_secs', 'is_free_preview', 'is_hidden', 'quiz_id', 'drip_days'] as $k) {
            $l[$k] = (int)$l[$k];
        }

        /* sibling navigation — powers the "2 / 9 Lesson  < >" header */
        $sibs = [];
        $sr = $conn->query("SELECT id, title FROM lms_lessons
                            WHERE section_id = " . (int)$l['section_id'] . "
                            ORDER BY sort_order ASC, id ASC");
        while ($sr && ($s = $sr->fetch_assoc())) $sibs[] = ['id' => (int)$s['id'], 'title' => $s['title']];

        lms_ok(['lesson' => $l, 'siblings' => $sibs]);
    }

    if ($action === 'create') {
        $cid = lms_int($in['course_id'] ?? 0);
        $sid = lms_int($in['section_id'] ?? 0);
        if (!$cid || !$sid) lms_error('course_id and section_id are required');
        $title = trim($in['title'] ?? '') ?: 'Untitled lesson';
        $type  = in_array($in['lesson_type'] ?? '', ['video', 'article', 'pdf', 'quiz', 'live', 'form'], true)
                   ? $in['lesson_type'] : 'video';

        $r    = $conn->query("SELECT COALESCE(MAX(sort_order), -1) + 1 n FROM lms_lessons WHERE section_id = $sid");
        $next = $r ? (int)$r->fetch_assoc()['n'] : 0;

        $conn->query("INSERT INTO lms_lessons
            (course_id, section_id, title, lesson_type, sort_order, status)
            VALUES ($cid, $sid, '" . lms_esc($conn, $title) . "', '$type', $next, 'draft')");
        lms_ok(['id' => $conn->insert_id], 'Lesson added');
    }

    if ($action === 'update') {
        $id = lms_int($in['id'] ?? 0);
        if (!$id) lms_error('Lesson id is required');

        $sets = [];
        if (isset($in['title']))          $sets[] = "title = '"          . lms_esc($conn, trim($in['title'])) . "'";
        if (isset($in['content']))        $sets[] = "content = '"        . lms_esc($conn, $in['content']) . "'";
        if (isset($in['video_url']))      $sets[] = "video_url = '"      . lms_esc($conn, $in['video_url']) . "'";
        if (isset($in['video_provider'])) $sets[] = "video_provider = '" . lms_esc($conn, $in['video_provider']) . "'";
        if (isset($in['lesson_type']) && in_array($in['lesson_type'], ['video', 'article', 'pdf', 'quiz', 'live', 'form'], true)) {
            $sets[] = "lesson_type = '" . $in['lesson_type'] . "'";
        }
        if (isset($in['status']) && in_array($in['status'], ['draft', 'published'], true)) {
            $sets[] = "status = '" . $in['status'] . "'";
        }
        foreach (['duration_secs', 'quiz_id', 'drip_days'] as $k) {
            if (isset($in[$k])) $sets[] = "$k = " . lms_int($in[$k]);
        }
        foreach (['is_free_preview', 'is_hidden'] as $k) {
            if (isset($in[$k])) $sets[] = "$k = " . (!empty($in[$k]) ? 1 : 0);
        }
        if (!$sets) lms_error('Nothing to update');

        $conn->query('UPDATE lms_lessons SET ' . implode(', ', $sets) . " WHERE id = $id");
        lms_ok(['id' => $id], 'Lesson saved');
    }

    if ($action === 'upload_video') {
        $id = lms_int($_POST['id'] ?? 0);
        if (!$id) lms_error('Lesson id is required');
        if (empty($_FILES['file'])) lms_error('No file uploaded');
        $up = lms_s3_put($_FILES['file'], 'lms/lesson-videos');
        if (!$up) lms_error('Upload to S3 failed', 500);

        $old = $conn->query("SELECT video_key FROM lms_lessons WHERE id = $id");
        $oldKey = $old ? ($old->fetch_assoc()['video_key'] ?? '') : '';

        $conn->query("UPDATE lms_lessons
                      SET video_url = '" . lms_esc($conn, $up['url']) . "',
                          video_key = '" . lms_esc($conn, $up['key']) . "',
                          video_provider = 's3',
                          duration_secs = " . lms_int($_POST['duration_secs'] ?? 0) . "
                      WHERE id = $id");
        if ($oldKey && $oldKey !== $up['key']) lms_s3_delete($oldKey);
        lms_ok(['url' => $up['url'], 'name' => $up['name'], 'size' => $up['size']], 'Video uploaded');
    }

    if ($action === 'toggle_hidden') {
        $id = lms_int($in['id'] ?? 0);
        if (!$id) lms_error('Lesson id is required');
        $conn->query("UPDATE lms_lessons SET is_hidden = 1 - is_hidden WHERE id = $id");
        lms_ok(null, 'Visibility updated');
    }

    if ($action === 'move') {
        $id  = lms_int($in['id'] ?? 0);
        $sid = lms_int($in['section_id'] ?? 0);
        if (!$id || !$sid) lms_error('id and section_id are required');
        $r    = $conn->query("SELECT COALESCE(MAX(sort_order), -1) + 1 n FROM lms_lessons WHERE section_id = $sid");
        $next = $r ? (int)$r->fetch_assoc()['n'] : 0;
        $conn->query("UPDATE lms_lessons SET section_id = $sid, sort_order = $next WHERE id = $id");
        lms_ok(null, 'Lesson moved');
    }

    if ($action === 'delete') {
        $id = lms_int($in['id'] ?? 0);
        if (!$id) lms_error('Lesson id is required');
        $keys = [];
        $r = $conn->query("SELECT file_key FROM lms_lesson_attachments WHERE lesson_id = $id AND file_key <> ''");
        while ($r && ($k = $r->fetch_assoc())) $keys[] = $k['file_key'];
        $r = $conn->query("SELECT video_key FROM lms_lessons WHERE id = $id AND video_key <> ''");
        while ($r && ($k = $r->fetch_assoc())) $keys[] = $k['video_key'];

        $conn->query("DELETE FROM lms_lesson_fields      WHERE lesson_id = $id");
        $conn->query("DELETE FROM lms_lesson_attachments WHERE lesson_id = $id");
        $conn->query("DELETE FROM lms_form_responses     WHERE lesson_id = $id");
        $conn->query("DELETE FROM lms_progress           WHERE lesson_id = $id");
        $conn->query("DELETE FROM lms_lessons            WHERE id = $id");
        foreach ($keys as $k) lms_s3_delete($k);
        lms_ok(null, 'Lesson deleted');
    }

    if ($action === 'reorder') {
        $order = $in['order'] ?? [];
        if (!is_array($order)) lms_error('order must be an array of ids');
        foreach ($order as $i => $lid) {
            $conn->query('UPDATE lms_lessons SET sort_order = ' . (int)$i . ' WHERE id = ' . (int)$lid);
        }
        lms_ok(null, 'Lessons reordered');
    }

    lms_error('Unknown lessons action: ' . $action);
}

/* ───────────────────────── ATTACHMENTS ───────────────────────── */
if ($resource === 'attachments') {

    if ($action === 'list') {
        $lid = lms_int($_GET['lesson_id'] ?? 0);
        if (!$lid) lms_error('lesson_id is required');
        $rows = [];
        $res = $conn->query("SELECT * FROM lms_lesson_attachments
                             WHERE lesson_id = $lid ORDER BY sort_order ASC, id ASC");
        while ($res && ($r = $res->fetch_assoc())) {
            $r['id'] = (int)$r['id']; $r['file_size'] = (int)$r['file_size'];
            $r['sort_order'] = (int)$r['sort_order'];
            $rows[] = $r;
        }
        lms_ok(['attachments' => $rows]);
    }

    if ($action === 'create') {
        $lid  = lms_int($_POST['lesson_id'] ?? 0);
        $kind = ($_POST['kind'] ?? 'file') === 'link' ? 'link' : 'file';
        if (!$lid) lms_error('lesson_id is required');

        $r    = $conn->query("SELECT COALESCE(MAX(sort_order), -1) + 1 n FROM lms_lesson_attachments WHERE lesson_id = $lid");
        $next = $r ? (int)$r->fetch_assoc()['n'] : 0;

        if ($kind === 'link') {
            $url = trim($_POST['file_url'] ?? '');
            if ($url === '') lms_error('Link URL is required');
            $conn->query("INSERT INTO lms_lesson_attachments
                (lesson_id, kind, title, description, file_url, file_type, sort_order)
                VALUES ($lid, 'link',
                        '" . lms_esc($conn, $_POST['title'] ?? '') . "',
                        '" . lms_esc($conn, $_POST['description'] ?? '') . "',
                        '" . lms_esc($conn, $url) . "', 'link', $next)");
            lms_ok(['id' => $conn->insert_id], 'Link added');
        }

        if (empty($_FILES['file'])) lms_error('No file uploaded');
        $up = lms_s3_put($_FILES['file'], 'lms/lesson-attachments');
        if (!$up) lms_error('Upload to S3 failed', 500);

        $ext  = strtolower(pathinfo($up['name'], PATHINFO_EXTENSION));
        $map  = ['pdf' => 'pdf', 'doc' => 'doc', 'docx' => 'doc', 'xls' => 'excel', 'xlsx' => 'excel',
                 'csv' => 'excel', 'ppt' => 'ppt', 'pptx' => 'ppt', 'mp4' => 'video', 'mov' => 'video',
                 'zip' => 'zip', 'rar' => 'zip', 'png' => 'image', 'jpg' => 'image', 'jpeg' => 'image',
                 'gif' => 'image', 'webp' => 'image'];
        $ftype = $map[$ext] ?? 'other';

        $conn->query("INSERT INTO lms_lesson_attachments
            (lesson_id, kind, title, description, file_url, file_key, file_name, file_type,
             file_size, mime_type, sort_order)
            VALUES ($lid, 'file',
                    '" . lms_esc($conn, $_POST['title'] ?? $up['name']) . "',
                    '" . lms_esc($conn, $_POST['description'] ?? '') . "',
                    '" . lms_esc($conn, $up['url'])  . "',
                    '" . lms_esc($conn, $up['key'])  . "',
                    '" . lms_esc($conn, $up['name']) . "',
                    '$ftype', " . (int)$up['size'] . ",
                    '" . lms_esc($conn, $up['mime']) . "', $next)");
        lms_ok(['id' => $conn->insert_id, 'url' => $up['url']], 'Attachment uploaded');
    }

    if ($action === 'update') {
        $id = lms_int($in['id'] ?? 0);
        if (!$id) lms_error('Attachment id is required');
        $conn->query("UPDATE lms_lesson_attachments SET
                        title = '"       . lms_esc($conn, $in['title'] ?? '') . "',
                        description = '" . lms_esc($conn, $in['description'] ?? '') . "'
                      WHERE id = $id");
        lms_ok(null, 'Attachment updated');
    }

    if ($action === 'delete') {
        $id = lms_int($in['id'] ?? 0);
        if (!$id) lms_error('Attachment id is required');
        $r   = $conn->query("SELECT file_key FROM lms_lesson_attachments WHERE id = $id");
        $key = $r ? ($r->fetch_assoc()['file_key'] ?? '') : '';
        $conn->query("DELETE FROM lms_lesson_attachments WHERE id = $id");
        if ($key) lms_s3_delete($key);
        lms_ok(null, 'Attachment removed');
    }

    if ($action === 'reorder') {
        $order = $in['order'] ?? [];
        foreach ((array)$order as $i => $aid) {
            $conn->query('UPDATE lms_lesson_attachments SET sort_order = ' . (int)$i . ' WHERE id = ' . (int)$aid);
        }
        lms_ok(null, 'Reordered');
    }

    lms_error('Unknown attachments action: ' . $action);
}

/* ───────────────── FIELDS (per-lesson dynamic form builder) ───────────────── */
if ($resource === 'fields') {

    if ($action === 'list') {
        $lid = lms_int($_GET['lesson_id'] ?? 0);
        if (!$lid) lms_error('lesson_id is required');
        $rows = [];
        $res  = $conn->query("SELECT * FROM lms_lesson_fields
                              WHERE lesson_id = $lid ORDER BY field_order ASC, id ASC");
        while ($res && ($f = $res->fetch_assoc())) {
            $f['id']               = (int)$f['id'];
            $f['field_order']      = (int)$f['field_order'];
            $f['is_required']      = (int)$f['is_required'];
            $f['max_file_size_mb'] = (int)$f['max_file_size_mb'];
            $f['options']          = lms_json_decode($f['options']);
            $rows[] = $f;
        }
        lms_ok(['fields' => $rows]);
    }

    if ($action === 'create' || $action === 'update') {
        $lid   = lms_int($in['lesson_id'] ?? 0);
        $label = trim($in['label'] ?? '');
        if ($action === 'create' && !$lid) lms_error('lesson_id is required');
        if ($label === '') lms_error('Field label is required');

        $sets = [
            "field_type = '"          . lms_esc($conn, $in['field_type'] ?? 'text') . "'",
            "label = '"               . lms_esc($conn, $label) . "'",
            "placeholder = '"         . lms_esc($conn, $in['placeholder'] ?? '') . "'",
            "help_text = '"           . lms_esc($conn, $in['help_text'] ?? '') . "'",
            'is_required = '          . (!empty($in['is_required']) ? 1 : 0),
            "accepted_extensions = '" . lms_esc($conn, $in['accepted_extensions'] ?? '') . "'",
            'max_file_size_mb = '     . lms_int($in['max_file_size_mb'] ?? 25, 25),
        ];
        $opts   = lms_json_col($in['options'] ?? null);
        $sets[] = 'options = ' . ($opts === null ? 'NULL' : "'" . lms_esc($conn, $opts) . "'");
        if (isset($in['status']) && in_array($in['status'], ['active', 'inactive'], true)) {
            $sets[] = "status = '" . $in['status'] . "'";
        }

        if ($action === 'create') {
            $r    = $conn->query("SELECT COALESCE(MAX(field_order), -1) + 1 n FROM lms_lesson_fields WHERE lesson_id = $lid");
            $next = $r ? (int)$r->fetch_assoc()['n'] : 0;
            $sets[] = "lesson_id = $lid";
            $sets[] = "field_order = $next";
            $conn->query('INSERT INTO lms_lesson_fields SET ' . implode(', ', $sets));
            lms_ok(['id' => $conn->insert_id], 'Field added');
        }

        $id = lms_int($in['id'] ?? 0);
        if (!$id) lms_error('Field id is required');
        $conn->query('UPDATE lms_lesson_fields SET ' . implode(', ', $sets) . " WHERE id = $id");
        lms_ok(['id' => $id], 'Field updated');
    }

    if ($action === 'toggle') {
        $id = lms_int($in['id'] ?? 0);
        if (!$id) lms_error('Field id is required');
        $conn->query("UPDATE lms_lesson_fields
                      SET status = IF(status = 'active', 'inactive', 'active') WHERE id = $id");
        lms_ok(null, 'Field toggled');
    }

    if ($action === 'delete') {
        $id = lms_int($in['id'] ?? 0);
        if (!$id) lms_error('Field id is required');
        $conn->query("DELETE FROM lms_lesson_fields WHERE id = $id");
        lms_ok(null, 'Field removed');
    }

    if ($action === 'reorder') {
        $order = $in['order'] ?? [];
        foreach ((array)$order as $i => $fid) {
            $conn->query('UPDATE lms_lesson_fields SET field_order = ' . (int)$i . ' WHERE id = ' . (int)$fid);
        }
        lms_ok(null, 'Fields reordered');
    }

    lms_error('Unknown fields action: ' . $action);
}

/* ───────────────────────── FORM RESPONSES ───────────────────────── */
if ($resource === 'responses') {

    if ($action === 'list') {
        $lid    = lms_int($_GET['lesson_id'] ?? 0);
        $cid    = lms_int($_GET['course_id'] ?? 0);
        $limit  = min(500, max(1, lms_int($_GET['limit'] ?? 100, 100)));
        $offset = max(0, lms_int($_GET['offset'] ?? 0));

        $where = [];
        if ($lid) $where[] = "r.lesson_id = $lid";
        if ($cid) $where[] = "r.course_id = $cid";
        $w = $where ? 'WHERE ' . implode(' AND ', $where) : '';

        $tr    = $conn->query("SELECT COUNT(*) c FROM lms_form_responses r $w");
        $total = $tr ? (int)$tr->fetch_assoc()['c'] : 0;

        $rows = [];
        $res = $conn->query("SELECT r.*, u.name, u.email, u.phone, l.title lesson_title, c.title course_title
                             FROM lms_form_responses r
                             LEFT JOIN users u       ON u.user_id = r.user_id
                             LEFT JOIN lms_lessons l ON l.id = r.lesson_id
                             LEFT JOIN lms_courses c ON c.id = r.course_id
                             $w ORDER BY r.created_at DESC LIMIT $limit OFFSET $offset");
        while ($res && ($r = $res->fetch_assoc())) {
            $r['id']      = (int)$r['id'];
            $r['payload'] = lms_json_decode($r['payload']);
            $rows[] = $r;
        }
        lms_ok(['responses' => $rows, 'total' => $total]);
    }

    if ($action === 'delete') {
        $id = lms_int($in['id'] ?? 0);
        if (!$id) lms_error('Response id is required');
        $conn->query("DELETE FROM lms_form_responses WHERE id = $id");
        lms_ok(null, 'Response deleted');
    }

    lms_error('Unknown responses action: ' . $action);
}

/* ───────────────────────── QUIZZES ───────────────────────── */
if ($resource === 'quizzes') {

    if ($action === 'list') {
        $cid   = lms_int($_GET['course_id'] ?? 0);
        $q     = trim($_GET['q'] ?? '');
        $where = [];
        if ($cid) $where[] = "q.course_id = $cid";
        if ($q !== '') $where[] = "q.title LIKE '%" . lms_esc($conn, $q) . "%'";
        $w = $where ? 'WHERE ' . implode(' AND ', $where) : '';

        $rows = [];
        $res = $conn->query("SELECT q.*, c.title course_title,
                                (SELECT COUNT(*) FROM lms_quiz_questions qq
                                   WHERE qq.quiz_id = q.id AND qq.status='active') question_count,
                                (SELECT COALESCE(SUM(qq.marks),0) FROM lms_quiz_questions qq
                                   WHERE qq.quiz_id = q.id AND qq.status='active') total_marks,
                                (SELECT COUNT(*) FROM lms_quiz_attempts a WHERE a.quiz_id = q.id) attempt_count,
                                (SELECT COALESCE(AVG(a.percentage),0) FROM lms_quiz_attempts a WHERE a.quiz_id = q.id) avg_score
                             FROM lms_quizzes q
                             LEFT JOIN lms_courses c ON c.id = q.course_id
                             $w ORDER BY q.id DESC");
        while ($res && ($r = $res->fetch_assoc())) {
            $r['id']             = (int)$r['id'];
            $r['course_id']      = (int)$r['course_id'];
            $r['question_count'] = (int)$r['question_count'];
            $r['total_marks']    = (float)$r['total_marks'];
            $r['attempt_count']  = (int)$r['attempt_count'];
            $r['avg_score']      = round((float)$r['avg_score'], 1);
            $rows[] = $r;
        }
        lms_ok(['quizzes' => $rows]);
    }

    if ($action === 'get') {
        $id  = lms_int($_GET['id'] ?? 0);
        $res = $conn->query("SELECT * FROM lms_quizzes WHERE id = $id");
        $q   = $res ? $res->fetch_assoc() : null;
        if (!$q) lms_error('Quiz not found', 404);
        $q['id'] = (int)$q['id'];

        $questions = [];
        $qr = $conn->query("SELECT * FROM lms_quiz_questions WHERE quiz_id = $id ORDER BY sort_order ASC, id ASC");
        while ($qr && ($row = $qr->fetch_assoc())) {
            $row['id']         = (int)$row['id'];
            $row['marks']      = (float)$row['marks'];
            $row['negative_marks'] = (float)$row['negative_marks'];
            $row['sort_order'] = (int)$row['sort_order'];
            $row['options']    = lms_json_decode($row['options']);
            $row['correct']    = lms_json_decode($row['correct']);
            $questions[] = $row;
        }
        lms_ok(['quiz' => $q, 'questions' => $questions]);
    }

    if ($action === 'create' || $action === 'update') {
        $title = trim($in['title'] ?? '');
        if ($title === '') lms_error('Quiz title is required');

        $sets = [
            "title = '"        . lms_esc($conn, $title) . "'",
            "description = '"  . lms_esc($conn, $in['description'] ?? '') . "'",
            "instructions = '" . lms_esc($conn, $in['instructions'] ?? '') . "'",
            'course_id = '        . lms_int($in['course_id'] ?? 0),
            'duration_mins = '    . lms_int($in['duration_mins'] ?? 0),
            'pass_percentage = '  . lms_int($in['pass_percentage'] ?? 40, 40),
            'max_attempts = '     . lms_int($in['max_attempts'] ?? 0),
            'shuffle_questions = '. (!empty($in['shuffle_questions']) ? 1 : 0),
            'shuffle_options = '  . (!empty($in['shuffle_options'])   ? 1 : 0),
            'negative_marking = ' . (!empty($in['negative_marking'])  ? 1 : 0),
            'show_result = '      . (!empty($in['show_result'])       ? 1 : 0),
            'is_graded = '        . (!empty($in['is_graded'])         ? 1 : 0),
        ];
        if (in_array($in['show_answers'] ?? '', ['never', 'after_submit', 'after_pass'], true)) {
            $sets[] = "show_answers = '" . $in['show_answers'] . "'";
        }
        if (in_array($in['status'] ?? '', ['draft', 'published'], true)) {
            $sets[] = "status = '" . $in['status'] . "'";
        }

        if ($action === 'create') {
            $conn->query('INSERT INTO lms_quizzes SET ' . implode(', ', $sets));
            lms_ok(['id' => $conn->insert_id], 'Quiz created');
        }
        $id = lms_int($in['id'] ?? 0);
        if (!$id) lms_error('Quiz id is required');
        $conn->query('UPDATE lms_quizzes SET ' . implode(', ', $sets) . " WHERE id = $id");
        lms_ok(['id' => $id], 'Quiz updated');
    }

    if ($action === 'toggle') {
        $id = lms_int($in['id'] ?? 0);
        if (!$id) lms_error('Quiz id is required');
        $conn->query("UPDATE lms_quizzes
                      SET status = IF(status = 'published', 'draft', 'published') WHERE id = $id");
        lms_ok(null, 'Quiz status changed');
    }

    if ($action === 'duplicate') {
        $id = lms_int($in['id'] ?? 0);
        if (!$id) lms_error('Quiz id is required');
        $r = $conn->query("SELECT title FROM lms_quizzes WHERE id = $id");
        $t = $r ? ($r->fetch_assoc()['title'] ?? '') : '';
        if ($t === '') lms_error('Quiz not found', 404);
        $nt = lms_esc($conn, $t . ' (Copy)');
        $conn->query("INSERT INTO lms_quizzes
            (course_id, title, description, instructions, duration_mins, pass_percentage,
             max_attempts, shuffle_questions, shuffle_options, show_answers, negative_marking,
             show_result, is_graded, status)
            SELECT course_id, '$nt', description, instructions, duration_mins, pass_percentage,
                   max_attempts, shuffle_questions, shuffle_options, show_answers, negative_marking,
                   show_result, is_graded, 'draft'
            FROM lms_quizzes WHERE id = $id");
        $newId = $conn->insert_id;
        $conn->query("INSERT INTO lms_quiz_questions
            (quiz_id, question_type, question, image_url, options, correct, marks,
             negative_marks, explanation, difficulty, sort_order, status)
            SELECT $newId, question_type, question, image_url, options, correct, marks,
                   negative_marks, explanation, difficulty, sort_order, status
            FROM lms_quiz_questions WHERE quiz_id = $id");
        lms_ok(['id' => $newId], 'Quiz duplicated');
    }

    if ($action === 'delete') {
        $id = lms_int($in['id'] ?? 0);
        if (!$id) lms_error('Quiz id is required');
        $conn->query("DELETE FROM lms_quiz_questions WHERE quiz_id = $id");
        $conn->query("DELETE FROM lms_quiz_attempts  WHERE quiz_id = $id");
        $conn->query("UPDATE lms_lessons SET quiz_id = 0 WHERE quiz_id = $id");
        $conn->query("DELETE FROM lms_quizzes WHERE id = $id");
        lms_ok(null, 'Quiz deleted');
    }

    lms_error('Unknown quizzes action: ' . $action);
}

/* ───────────────────────── QUIZ QUESTIONS ───────────────────────── */
if ($resource === 'questions') {

    if ($action === 'create' || $action === 'update') {
        $qid  = lms_int($in['quiz_id'] ?? 0);
        $text = trim($in['question'] ?? '');
        if ($action === 'create' && !$qid) lms_error('quiz_id is required');
        if ($text === '') lms_error('Question text is required');

        $sets = [
            "question_type = '" . lms_esc($conn, $in['question_type'] ?? 'single') . "'",
            "question = '"      . lms_esc($conn, $text) . "'",
            "image_url = '"     . lms_esc($conn, $in['image_url'] ?? '') . "'",
            "explanation = '"   . lms_esc($conn, $in['explanation'] ?? '') . "'",
            'marks = '          . (float)($in['marks'] ?? 1),
            'negative_marks = ' . (float)($in['negative_marks'] ?? 0),
        ];
        if (in_array($in['difficulty'] ?? '', ['easy', 'medium', 'hard'], true)) {
            $sets[] = "difficulty = '" . $in['difficulty'] . "'";
        }
        if (in_array($in['status'] ?? '', ['active', 'inactive'], true)) {
            $sets[] = "status = '" . $in['status'] . "'";
        }
        $o = lms_json_col($in['options'] ?? null);
        $c = lms_json_col($in['correct'] ?? null);
        $sets[] = 'options = ' . ($o === null ? 'NULL' : "'" . lms_esc($conn, $o) . "'");
        $sets[] = 'correct = ' . ($c === null ? 'NULL' : "'" . lms_esc($conn, $c) . "'");

        if ($action === 'create') {
            $r    = $conn->query("SELECT COALESCE(MAX(sort_order), -1) + 1 n FROM lms_quiz_questions WHERE quiz_id = $qid");
            $next = $r ? (int)$r->fetch_assoc()['n'] : 0;
            $sets[] = "quiz_id = $qid";
            $sets[] = "sort_order = $next";
            $conn->query('INSERT INTO lms_quiz_questions SET ' . implode(', ', $sets));
            lms_ok(['id' => $conn->insert_id], 'Question added');
        }
        $id = lms_int($in['id'] ?? 0);
        if (!$id) lms_error('Question id is required');
        $conn->query('UPDATE lms_quiz_questions SET ' . implode(', ', $sets) . " WHERE id = $id");
        lms_ok(['id' => $id], 'Question updated');
    }

    /* paste-a-block bulk import — one question per line:
       "Question text | option A | option B* | option C"  (* marks the answer) */
    if ($action === 'bulk_create') {
        $qid   = lms_int($in['quiz_id'] ?? 0);
        $lines = preg_split('/\r\n|\r|\n/', (string)($in['text'] ?? ''));
        if (!$qid) lms_error('quiz_id is required');

        $r    = $conn->query("SELECT COALESCE(MAX(sort_order), -1) + 1 n FROM lms_quiz_questions WHERE quiz_id = $qid");
        $next = $r ? (int)$r->fetch_assoc()['n'] : 0;

        $added = 0; $skipped = [];
        foreach ($lines as $ln => $line) {
            $line = trim($line);
            if ($line === '') continue;
            $parts = array_map('trim', explode('|', $line));
            $text  = array_shift($parts);
            if ($text === '' || count($parts) < 2) { $skipped[] = 'Line ' . ($ln + 1) . ': needs a question and at least 2 options'; continue; }

            $opts = []; $correct = [];
            foreach ($parts as $i => $p) {
                $isAns = substr($p, -1) === '*';
                if ($isAns) $p = rtrim(substr($p, 0, -1));
                $val = 'opt_' . ($i + 1);
                $opts[] = ['value' => $val, 'label' => $p];
                if ($isAns) $correct[] = $val;
            }
            if (!$correct) { $skipped[] = 'Line ' . ($ln + 1) . ': no option marked with *'; continue; }

            $type = count($correct) > 1 ? 'multi' : 'single';
            $conn->query("INSERT INTO lms_quiz_questions
                (quiz_id, question_type, question, options, correct, marks, sort_order)
                VALUES ($qid, '$type',
                        '" . lms_esc($conn, $text) . "',
                        '" . lms_esc($conn, json_encode($opts))    . "',
                        '" . lms_esc($conn, json_encode($correct)) . "',
                        " . (float)($in['marks'] ?? 1) . ", " . ($next + $added) . ")");
            $added++;
        }
        lms_ok(['added' => $added, 'skipped' => $skipped],
               $added . ' question' . ($added === 1 ? '' : 's') . ' imported');
    }

    if ($action === 'delete') {
        $id = lms_int($in['id'] ?? 0);
        if (!$id) lms_error('Question id is required');
        $conn->query("DELETE FROM lms_quiz_questions WHERE id = $id");
        lms_ok(null, 'Question deleted');
    }

    if ($action === 'reorder') {
        $order = $in['order'] ?? [];
        foreach ((array)$order as $i => $qq) {
            $conn->query('UPDATE lms_quiz_questions SET sort_order = ' . (int)$i . ' WHERE id = ' . (int)$qq);
        }
        lms_ok(null, 'Questions reordered');
    }

    lms_error('Unknown questions action: ' . $action);
}

/* ───────────────────────── QUIZ ATTEMPTS ───────────────────────── */
if ($resource === 'attempts') {

    if ($action === 'list') {
        $qid    = lms_int($_GET['quiz_id'] ?? 0);
        $uid    = lms_int($_GET['user_id'] ?? 0);
        $limit  = min(500, max(1, lms_int($_GET['limit'] ?? 100, 100)));
        $offset = max(0, lms_int($_GET['offset'] ?? 0));

        $where = [];
        if ($qid) $where[] = "a.quiz_id = $qid";
        if ($uid) $where[] = "a.user_id = $uid";
        $w = $where ? 'WHERE ' . implode(' AND ', $where) : '';

        $tr    = $conn->query("SELECT COUNT(*) c FROM lms_quiz_attempts a $w");
        $total = $tr ? (int)$tr->fetch_assoc()['c'] : 0;

        $rows = [];
        $res = $conn->query("SELECT a.*, u.name, u.email, q.title quiz_title
                             FROM lms_quiz_attempts a
                             LEFT JOIN users u       ON u.user_id = a.user_id
                             LEFT JOIN lms_quizzes q ON q.id = a.quiz_id
                             $w ORDER BY a.submitted_at DESC LIMIT $limit OFFSET $offset");
        while ($res && ($r = $res->fetch_assoc())) {
            $r['id']         = (int)$r['id'];
            $r['score']      = (float)$r['score'];
            $r['percentage'] = (float)$r['percentage'];
            $r['passed']     = (int)$r['passed'];
            unset($r['answers']);   // keep the list payload light
            $rows[] = $r;
        }
        lms_ok(['attempts' => $rows, 'total' => $total]);
    }

    if ($action === 'get') {
        $id  = lms_int($_GET['id'] ?? 0);
        $res = $conn->query("SELECT a.*, u.name, u.email FROM lms_quiz_attempts a
                             LEFT JOIN users u ON u.user_id = a.user_id WHERE a.id = $id");
        $a = $res ? $res->fetch_assoc() : null;
        if (!$a) lms_error('Attempt not found', 404);
        $a['answers'] = lms_json_decode($a['answers']);
        lms_ok(['attempt' => $a]);
    }

    if ($action === 'delete') {
        $id = lms_int($in['id'] ?? 0);
        if (!$id) lms_error('Attempt id is required');
        $conn->query("DELETE FROM lms_quiz_attempts WHERE id = $id");
        lms_ok(null, 'Attempt deleted');
    }

    lms_error('Unknown attempts action: ' . $action);
}

/* ───────────────────────── LEARNERS ─────────────────────────
   The learner pool is the existing `users` table. By default we show only
   users who actually bought something (internship_payment) or who are already
   enrolled in an LMS course — "scope=all" widens it to every registered user.
   ─────────────────────────────────────────────────────────── */
if ($resource === 'learners') {

    if ($action === 'list') {
        $q      = trim($_GET['q'] ?? '');
        $scope  = $_GET['scope'] ?? 'buyers';       // buyers | enrolled | all
        $course = lms_int($_GET['course_id'] ?? 0);
        $limit  = min(200, max(1, lms_int($_GET['limit'] ?? 30, 30)));
        $offset = max(0, lms_int($_GET['offset'] ?? 0));

        $where = ["u.user_id > 0"];
        if ($q !== '') {
            $qe = lms_esc($conn, $q);
            $where[] = "(u.email LIKE '%$qe%' OR u.name LIKE '%$qe%' OR u.phone LIKE '%$qe%')";
        }
        if ($scope === 'buyers') {
            $where[] = "(EXISTS (SELECT 1 FROM internship_payment ip WHERE ip.user_id = u.user_id)
                         OR EXISTS (SELECT 1 FROM lms_enrollments le WHERE le.user_id = u.user_id))";
        } elseif ($scope === 'enrolled') {
            $where[] = $course
                ? "EXISTS (SELECT 1 FROM lms_enrollments le WHERE le.user_id = u.user_id AND le.course_id = $course)"
                : "EXISTS (SELECT 1 FROM lms_enrollments le WHERE le.user_id = u.user_id)";
        }
        $w = 'WHERE ' . implode(' AND ', $where);

        $tr    = $conn->query("SELECT COUNT(*) c FROM users u $w");
        $total = $tr ? (int)$tr->fetch_assoc()['c'] : 0;

        $rows = [];
        $res = $conn->query("SELECT u.user_id, u.name, u.fname, u.lname, u.email, u.phone,
                                    u.active, u.created_at,
                                    (SELECT COUNT(*) FROM internship_payment ip WHERE ip.user_id = u.user_id) purchases,
                                    (SELECT GROUP_CONCAT(DISTINCT ip.internship SEPARATOR ', ')
                                       FROM internship_payment ip WHERE ip.user_id = u.user_id) internships,
                                    (SELECT MAX(ip.paid_at) FROM internship_payment ip WHERE ip.user_id = u.user_id) last_paid_at,
                                    (SELECT COUNT(*) FROM lms_enrollments le WHERE le.user_id = u.user_id AND le.status='active') lms_courses,
                                    (SELECT COUNT(*) FROM lms_progress p WHERE p.user_id = u.user_id AND p.status='completed') lessons_done,
                                    (SELECT COUNT(*) FROM lms_quiz_attempts qa WHERE qa.user_id = u.user_id) quiz_attempts
                             FROM users u $w
                             ORDER BY u.user_id DESC LIMIT $limit OFFSET $offset");
        if ($res === false) lms_error('Could not read learners: ' . $conn->error, 500);
        while ($r = $res->fetch_assoc()) {
            $r['user_id']      = (int)$r['user_id'];
            $r['purchases']    = (int)$r['purchases'];
            $r['lms_courses']  = (int)$r['lms_courses'];
            $r['lessons_done'] = (int)$r['lessons_done'];
            $r['quiz_attempts']= (int)$r['quiz_attempts'];
            $rows[] = $r;
        }
        lms_ok(['learners' => $rows, 'total' => $total]);
    }

    if ($action === 'get') {
        $uid = lms_int($_GET['user_id'] ?? 0);
        if (!$uid) lms_error('user_id is required');
        $res = $conn->query("SELECT user_id, name, fname, lname, email, phone, state, country, active, created_at
                             FROM users WHERE user_id = $uid");
        $u = $res ? $res->fetch_assoc() : null;
        if (!$u) lms_error('Learner not found', 404);

        $enr = [];
        $r = $conn->query("SELECT e.*, c.title course_title FROM lms_enrollments e
                           LEFT JOIN lms_courses c ON c.id = e.course_id
                           WHERE e.user_id = $uid ORDER BY e.enrolled_at DESC");
        while ($r && ($row = $r->fetch_assoc())) $enr[] = $row;

        $att = [];
        $r = $conn->query("SELECT a.id, a.quiz_id, a.score, a.total_marks, a.percentage, a.passed,
                                  a.submitted_at, q.title quiz_title
                           FROM lms_quiz_attempts a
                           LEFT JOIN lms_quizzes q ON q.id = a.quiz_id
                           WHERE a.user_id = $uid ORDER BY a.submitted_at DESC LIMIT 25");
        while ($r && ($row = $r->fetch_assoc())) $att[] = $row;

        $pur = [];
        $r = $conn->query("SELECT internship, batch, paid_at, payment_id
                           FROM internship_payment WHERE user_id = $uid ORDER BY paid_at DESC");
        while ($r && ($row = $r->fetch_assoc())) $pur[] = $row;

        lms_ok(['learner' => $u, 'enrollments' => $enr, 'attempts' => $att, 'purchases' => $pur]);
    }

    /* Registers a genuinely new `users` row — same shape as
       user_dashboard/api/register.php (role 4 = learner), then optionally
       enrolls them into a course in one go. */
    if ($action === 'create') {
        $email = strtolower(trim($in['email'] ?? ''));
        $name  = trim($in['name'] ?? '');
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) lms_error('A valid learner email is required');
        if ($name === '') lms_error('Learner full name is required');

        $ee  = lms_esc($conn, $email);
        $chk = $conn->query("SELECT user_id FROM users WHERE email = '$ee' LIMIT 1");
        if ($chk && $chk->num_rows) {
            $existing = (int)$chk->fetch_assoc()['user_id'];
            $cid = lms_int($in['course_id'] ?? 0);
            if ($cid) lms_enroll($conn, $cid, $existing, $in);
            lms_ok(['user_id' => $existing, 'existing' => true],
                   'That email is already registered — enrolled the existing learner instead');
        }

        $res = lms_register_user($conn, $email, $name, $in['phone'] ?? '', $in['password'] ?? '');
        if (!$res['ok']) lms_error($res['message'], 500);

        $cid = lms_int($in['course_id'] ?? 0);
        if ($cid) lms_enroll($conn, $cid, $res['user_id'], $in);

        lms_ok(['user_id' => $res['user_id'], 'existing' => false, 'password' => $res['password']],
               'Learner registered');
    }

    /* CSV import — step 1: parse headers + suggest a mapping (upload -> map -> run,
       same three-step shape as the Netcore contact importer) */
    if ($action === 'import_preview') {
        if (empty($_FILES['file'])) lms_error('No CSV file uploaded');
        $tmp = $_FILES['file']['tmp_name'];
        if (!is_uploaded_file($tmp)) lms_error('Upload failed');

        $fh = fopen($tmp, 'r');
        if (!$fh) lms_error('Could not read the uploaded file');
        $headers = fgetcsv($fh);
        if (!$headers) { fclose($fh); lms_error('The CSV appears to be empty'); }
        $headers = array_map(fn($h) => trim((string)$h, " \t\n\r\0\x0B\xEF\xBB\xBF"), $headers);

        $sample = fgetcsv($fh) ?: [];
        $rows   = 0;
        rewind($fh); fgetcsv($fh);
        while (fgetcsv($fh) !== false) $rows++;
        fclose($fh);

        /* stash the file so import_run doesn't need a second upload */
        $token = bin2hex(random_bytes(12));
        $dir   = sys_get_temp_dir() . '/lms_imports';
        if (!is_dir($dir)) @mkdir($dir, 0700, true);
        @copy($tmp, "$dir/$token.csv");

        $guess = [];
        foreach ($headers as $h) {
            $k = strtolower(preg_replace('/[^a-z0-9]/i', '', $h));
            if (in_array($k, ['email', 'emailaddress', 'mail'], true))            $guess[$h] = 'email';
            elseif (in_array($k, ['name', 'fullname', 'learnername'], true))      $guess[$h] = 'name';
            elseif (in_array($k, ['phone', 'mobile', 'phonenumber', 'contact'], true)) $guess[$h] = 'phone';
            elseif (in_array($k, ['amount', 'price', 'paid'], true))              $guess[$h] = 'amount';
            elseif (in_array($k, ['expiry', 'expirydate', 'validtill'], true))    $guess[$h] = 'expiry_date';
            else $guess[$h] = 'skip';
        }

        lms_ok([
            'token'      => $token,
            'headers'    => $headers,
            'sample_row' => $sample,
            'total_rows' => $rows,
            'mapping'    => $guess,
            'file_name'  => $_FILES['file']['name'] ?? 'import.csv',
        ]);
    }

    /* CSV import — step 2: register missing users, enrol everyone, log the run */
    if ($action === 'import_run') {
        $token   = preg_replace('/[^a-f0-9]/', '', (string)($in['token'] ?? ''));
        $mapping = is_array($in['mapping'] ?? null) ? $in['mapping'] : lms_json_decode($in['mapping'] ?? '');
        $cid     = lms_int($in['course_id'] ?? 0);
        $path    = sys_get_temp_dir() . '/lms_imports/' . $token . '.csv';
        if (!$token || !is_file($path)) lms_error('Import session expired — please upload the file again');
        if (!in_array('email', array_values($mapping), true)) lms_error('Map at least one column to Email');

        $fh      = fopen($path, 'r');
        $headers = array_map(fn($h) => trim((string)$h, " \t\n\r\0\x0B\xEF\xBB\xBF"), fgetcsv($fh) ?: []);
        $idx     = [];
        foreach ($headers as $i => $h) {
            $target = $mapping[$h] ?? 'skip';
            if ($target !== 'skip') $idx[$target] = $i;
        }

        $total = 0; $created = 0; $existing = 0; $enrolled = 0; $failed = 0; $errors = [];
        while (($row = fgetcsv($fh)) !== false) {
            if (count(array_filter($row, fn($v) => trim((string)$v) !== '')) === 0) continue;
            $total++;
            $get   = fn($k) => isset($idx[$k]) ? trim((string)($row[$idx[$k]] ?? '')) : '';
            $email = strtolower($get('email'));

            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                $failed++;
                if (count($errors) < 50) $errors[] = "Row $total: invalid email '" . substr($email, 0, 60) . "'";
                continue;
            }

            $ee  = lms_esc($conn, $email);
            $chk = $conn->query("SELECT user_id FROM users WHERE email = '$ee' LIMIT 1");
            if ($chk && $chk->num_rows) {
                $uid = (int)$chk->fetch_assoc()['user_id'];
                $existing++;
            } else {
                $r = lms_register_user($conn, $email, $get('name') ?: $email, $get('phone'), '');
                if (!$r['ok']) {
                    $failed++;
                    if (count($errors) < 50) $errors[] = "Row $total: " . $r['message'];
                    continue;
                }
                $uid = $r['user_id'];
                $created++;
            }

            if ($cid) {
                $ok = lms_enroll($conn, $cid, $uid, [
                    'access_type' => $in['access_type'] ?? 'paid',
                    'amount'      => $get('amount') !== '' ? (float)$get('amount') : (float)($in['amount'] ?? 0),
                    'expiry_date' => $get('expiry_date') ?: ($in['expiry_date'] ?? ''),
                    'source'      => 'import',
                ]);
                if ($ok) $enrolled++;
            }
        }
        fclose($fh);
        @unlink($path);

        $conn->query("INSERT INTO lms_import_logs
            (file_name, course_id, total_rows, created_rows, existing_rows, enrolled_rows, failed_rows, errors, created_by)
            VALUES ('" . lms_esc($conn, $in['file_name'] ?? 'import.csv') . "', $cid, $total, $created,
                    $existing, $enrolled, $failed,
                    '" . lms_esc($conn, json_encode($errors)) . "', " . lms_int($in['created_by'] ?? 0) . ")");

        lms_ok([
            'total' => $total, 'created' => $created, 'existing' => $existing,
            'enrolled' => $enrolled, 'failed' => $failed, 'errors' => $errors,
        ], "Imported $total row" . ($total === 1 ? '' : 's'));
    }

    if ($action === 'import_history') {
        $rows = [];
        $res = $conn->query("SELECT l.*, c.title course_title FROM lms_import_logs l
                             LEFT JOIN lms_courses c ON c.id = l.course_id
                             ORDER BY l.id DESC LIMIT 50");
        while ($res && ($r = $res->fetch_assoc())) {
            $r['errors'] = lms_json_decode($r['errors']);
            $rows[] = $r;
        }
        lms_ok(['imports' => $rows]);
    }

    lms_error('Unknown learners action: ' . $action);
}

/* ───────────────────────── ENROLLMENTS ───────────────────────── */
if ($resource === 'enrollments') {

    if ($action === 'list') {
        $cid    = lms_int($_GET['course_id'] ?? 0);
        $q      = trim($_GET['q'] ?? '');
        $limit  = min(200, max(1, lms_int($_GET['limit'] ?? 30, 30)));
        $offset = max(0, lms_int($_GET['offset'] ?? 0));

        $where = [];
        if ($cid) $where[] = "e.course_id = $cid";
        if ($q !== '') {
            $qe = lms_esc($conn, $q);
            $where[] = "(u.email LIKE '%$qe%' OR u.name LIKE '%$qe%')";
        }
        $w = $where ? 'WHERE ' . implode(' AND ', $where) : '';

        $tr = $conn->query("SELECT COUNT(*) c FROM lms_enrollments e LEFT JOIN users u ON u.user_id = e.user_id $w");
        $total = $tr ? (int)$tr->fetch_assoc()['c'] : 0;

        $rows = [];
        $res = $conn->query("SELECT e.*, u.name, u.email, u.phone, c.title course_title,
                                (SELECT COUNT(*) FROM lms_lessons l WHERE l.course_id = e.course_id) total_lessons,
                                (SELECT COUNT(*) FROM lms_progress p
                                   WHERE p.user_id = e.user_id AND p.course_id = e.course_id
                                     AND p.status='completed') done_lessons
                             FROM lms_enrollments e
                             LEFT JOIN users u       ON u.user_id = e.user_id
                             LEFT JOIN lms_courses c ON c.id = e.course_id
                             $w ORDER BY e.enrolled_at DESC LIMIT $limit OFFSET $offset");
        while ($res && ($r = $res->fetch_assoc())) {
            $r['id']            = (int)$r['id'];
            $r['amount']        = (float)$r['amount'];
            $r['total_lessons'] = (int)$r['total_lessons'];
            $r['done_lessons']  = (int)$r['done_lessons'];
            $r['progress']      = $r['total_lessons'] > 0
                ? round($r['done_lessons'] * 100 / $r['total_lessons']) : 0;
            $rows[] = $r;
        }
        lms_ok(['enrollments' => $rows, 'total' => $total]);
    }

    if ($action === 'create') {
        $cid = lms_int($in['course_id'] ?? 0);
        $uid = lms_int($in['user_id'] ?? 0);
        if (!$cid || !$uid) lms_error('course_id and user_id are required');
        lms_enroll($conn, $cid, $uid, $in);
        lms_ok(null, 'Learner enrolled');
    }

    /* enrol every buyer of a given internship into a course in one shot */
    if ($action === 'bulk_create') {
        $cid  = lms_int($in['course_id'] ?? 0);
        $uids = $in['user_ids'] ?? [];
        $internship = trim($in['internship'] ?? '');
        if (!$cid) lms_error('course_id is required');

        if ($internship !== '' && !is_array($uids)) $uids = [];
        if ($internship !== '') {
            $ie = lms_esc($conn, $internship);
            $r = $conn->query("SELECT DISTINCT user_id FROM internship_payment WHERE internship = '$ie'");
            while ($r && ($row = $r->fetch_assoc())) $uids[] = (int)$row['user_id'];
        }
        if (!is_array($uids) || !$uids) lms_error('Select at least one learner (or an internship to pull buyers from)');

        $n = 0;
        foreach ($uids as $uid) { if (lms_enroll($conn, $cid, (int)$uid, $in)) $n++; }
        lms_ok(['enrolled' => $n], "$n learner" . ($n === 1 ? '' : 's') . ' enrolled');
    }

    if ($action === 'update') {
        $id = lms_int($in['id'] ?? 0);
        if (!$id) lms_error('Enrollment id is required');
        $sets = [];
        if (in_array($in['status'] ?? '', ['active', 'expired', 'revoked'], true)) {
            $sets[] = "status = '" . $in['status'] . "'";
        }
        if (in_array($in['access_type'] ?? '', ['paid', 'free', 'trial'], true)) {
            $sets[] = "access_type = '" . $in['access_type'] . "'";
        }
        if (isset($in['amount']))      $sets[] = 'amount = ' . (float)$in['amount'];
        if (isset($in['expiry_date'])) {
            $d = trim((string)$in['expiry_date']);
            $sets[] = 'expiry_date = ' . ($d === '' ? 'NULL' : "'" . lms_esc($conn, $d) . "'");
        }
        if (!$sets) lms_error('Nothing to update');
        $conn->query('UPDATE lms_enrollments SET ' . implode(', ', $sets) . " WHERE id = $id");
        lms_ok(null, 'Enrollment updated');
    }

    if ($action === 'delete') {
        $id = lms_int($in['id'] ?? 0);
        if (!$id) lms_error('Enrollment id is required');
        $conn->query("DELETE FROM lms_enrollments WHERE id = $id");
        lms_ok(null, 'Enrollment removed');
    }

    lms_error('Unknown enrollments action: ' . $action);
}

/* ───────────────────────── REPORTS ───────────────────────── */
if ($resource === 'reports') {

    if ($action === 'progress') {
        $cid = lms_int($_GET['course_id'] ?? 0);
        if (!$cid) lms_error('course_id is required');

        $tr = $conn->query("SELECT COUNT(*) c FROM lms_lessons WHERE course_id = $cid");
        $totalLessons = $tr ? (int)$tr->fetch_assoc()['c'] : 0;

        $rows = [];
        $res = $conn->query("SELECT u.user_id, u.name, u.email,
                                    COUNT(CASE WHEN p.status='completed' THEN 1 END) done,
                                    COALESCE(SUM(p.watched_secs),0) watched,
                                    MAX(p.updated_at) last_active
                             FROM lms_enrollments e
                             LEFT JOIN users u       ON u.user_id = e.user_id
                             LEFT JOIN lms_progress p ON p.user_id = e.user_id AND p.course_id = e.course_id
                             WHERE e.course_id = $cid
                             GROUP BY u.user_id ORDER BY done DESC, u.user_id DESC");
        while ($res && ($r = $res->fetch_assoc())) {
            $r['done']     = (int)$r['done'];
            $r['watched']  = (int)$r['watched'];
            $r['progress'] = $totalLessons ? round($r['done'] * 100 / $totalLessons) : 0;
            $rows[] = $r;
        }
        lms_ok(['total_lessons' => $totalLessons, 'rows' => $rows]);
    }

    if ($action === 'quiz') {
        $qid = lms_int($_GET['quiz_id'] ?? 0);
        if (!$qid) lms_error('quiz_id is required');
        $sum = $conn->query("SELECT COUNT(*) attempts, COALESCE(AVG(percentage),0) avg_pct,
                                    COALESCE(MAX(percentage),0) max_pct, COALESCE(MIN(percentage),0) min_pct,
                                    SUM(passed) passed
                             FROM lms_quiz_attempts WHERE quiz_id = $qid");
        $s = $sum ? $sum->fetch_assoc() : [];

        /* per-question accuracy, computed from the stored answer maps */
        $questions = [];
        $qr = $conn->query("SELECT id, question, correct, marks FROM lms_quiz_questions
                            WHERE quiz_id = $qid AND status='active' ORDER BY sort_order");
        while ($qr && ($q = $qr->fetch_assoc())) {
            $questions[(int)$q['id']] = [
                'id' => (int)$q['id'], 'question' => $q['question'],
                'correct' => lms_json_decode($q['correct']), 'right' => 0, 'wrong' => 0,
            ];
        }
        $ar = $conn->query("SELECT answers FROM lms_quiz_attempts WHERE quiz_id = $qid");
        while ($ar && ($a = $ar->fetch_assoc())) {
            foreach (lms_json_decode($a['answers']) as $qidKey => $given) {
                $k = (int)$qidKey;
                if (!isset($questions[$k])) continue;
                $exp  = $questions[$k]['correct'];
                $got  = is_array($given) ? $given : [$given];
                sort($exp); sort($got);
                if ($exp == $got) $questions[$k]['right']++; else $questions[$k]['wrong']++;
            }
        }
        lms_ok(['summary' => $s, 'questions' => array_values($questions)]);
    }

    if ($action === 'course_funnel') {
        $rows = [];
        $res = $conn->query("SELECT c.id, c.title,
                                (SELECT COUNT(*) FROM lms_enrollments e WHERE e.course_id = c.id) enrolled,
                                (SELECT COUNT(DISTINCT p.user_id) FROM lms_progress p WHERE p.course_id = c.id) started,
                                (SELECT COUNT(*) FROM lms_lessons l WHERE l.course_id = c.id) lessons,
                                (SELECT COUNT(*) FROM lms_progress p WHERE p.course_id = c.id AND p.status='completed') completions,
                                (SELECT COALESCE(SUM(e.amount),0) FROM lms_enrollments e WHERE e.course_id = c.id) revenue
                             FROM lms_courses c WHERE c.status <> 'trashed'
                             ORDER BY enrolled DESC");
        while ($res && ($r = $res->fetch_assoc())) {
            foreach (['enrolled', 'started', 'lessons', 'completions'] as $k) $r[$k] = (int)$r[$k];
            $r['revenue'] = (float)$r['revenue'];
            $r['completion_rate'] = ($r['enrolled'] && $r['lessons'])
                ? round($r['completions'] * 100 / ($r['enrolled'] * $r['lessons'])) : 0;
            $rows[] = $r;
        }
        lms_ok(['rows' => $rows]);
    }

    lms_error('Unknown reports action: ' . $action);
}

/* ───────────────────────── SETTINGS ───────────────────────── */
if ($resource === 'settings') {

    if ($action === 'get') {
        $out = [];
        $res = $conn->query("SELECT setting_key, setting_value FROM lms_settings");
        while ($res && ($r = $res->fetch_assoc())) $out[$r['setting_key']] = $r['setting_value'];
        lms_ok(['settings' => $out]);
    }

    if ($action === 'save') {
        $settings = is_array($in['settings'] ?? null) ? $in['settings'] : lms_json_decode($in['settings'] ?? '');
        foreach ($settings as $k => $v) {
            $ke = lms_esc($conn, substr((string)$k, 0, 80));
            $ve = lms_esc($conn, is_array($v) ? json_encode($v) : (string)$v);
            $conn->query("INSERT INTO lms_settings (setting_key, setting_value) VALUES ('$ke', '$ve')
                          ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)");
        }
        lms_ok(null, 'Settings saved');
    }

    lms_error('Unknown settings action: ' . $action);
}

/* ───────────────────────── EDITOR IMAGE UPLOAD ───────────────────────── */
if ($resource === 'editor' && $action === 'upload_image') {
    if (empty($_FILES['image'])) lms_error('No image uploaded');
    $up = lms_s3_put($_FILES['image'], 'lms/editor');
    if (!$up) lms_error('Upload to S3 failed', 500);
    lms_ok(['url' => $up['url']]);
}

lms_error('Unknown resource: ' . $resource, 404);

/* ═══════════════════════════════════════════════════════════════════════════
   SHARED PROCEDURES
   ═══════════════════════════════════════════════════════════════════════════ */

/**
 * Creates a `users` row plus the satellite rows the rest of the platform
 * expects (additional_details / user_steps), mirroring register.php.
 * Returns ['ok'=>bool, 'user_id'=>int, 'password'=>string, 'message'=>string].
 */
function lms_register_user($conn, $email, $name, $phone = '', $password = '') {
    $name  = trim($name);
    $parts = preg_split('/\s+/', $name, 2);
    $fname = $parts[0] ?? $name;
    $lname = $parts[1] ?? '';
    $phone = preg_replace('/[^0-9+]/', '', (string)$phone);

    if ($password === '') {
        $password = substr(str_shuffle('0123456789abcdefghijkmnopqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ'), 0, 10);
    }
    $hash = password_hash($password, PASSWORD_BCRYPT);

    /* username must be unique — suffix a counter until it is */
    $base = preg_replace('/[^a-z0-9]/', '', strtolower($fname)) ?: 'learner';
    $username = $base;
    for ($i = 1; $i <= 50; $i++) {
        $ue = $conn->real_escape_string($username);
        $r  = $conn->query("SELECT user_id FROM users WHERE username = '$ue' LIMIT 1");
        if (!$r || !$r->num_rows) break;
        $username = $base . $i;
    }

    $stmt = $conn->prepare("INSERT INTO users
        (username, fname, lname, name, email, password, temp_password, phone, role, active)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, 4, 1)");
    if (!$stmt) return ['ok' => false, 'message' => 'Prepare failed: ' . $conn->error];
    $stmt->bind_param('ssssssss', $username, $fname, $lname, $name, $email, $hash, $password, $phone);
    if (!$stmt->execute()) {
        $err = $stmt->error;
        $stmt->close();
        return ['ok' => false, 'message' => 'Insert failed: ' . $err];
    }
    $uid = $stmt->insert_id;
    $stmt->close();

    /* satellite rows — non-fatal if the table shape differs on this box */
    @$conn->query("INSERT IGNORE INTO additional_details (user_id) VALUES ($uid)");
    @$conn->query("INSERT IGNORE INTO user_steps (user_id) VALUES ($uid)");

    return ['ok' => true, 'user_id' => $uid, 'password' => $password, 'message' => ''];
}

/** Idempotent enrol (the unique key makes a repeat call a no-op update). */
function lms_enroll($conn, $courseId, $userId, $opts = []) {
    $courseId = (int)$courseId;
    $userId   = (int)$userId;
    if (!$courseId || !$userId) return false;

    $type   = in_array($opts['access_type'] ?? '', ['paid', 'free', 'trial'], true) ? $opts['access_type'] : 'paid';
    $amount = (float)($opts['amount'] ?? 0);
    $source = $conn->real_escape_string((string)($opts['source'] ?? 'admin'));
    $expiry = trim((string)($opts['expiry_date'] ?? ''));

    /* fall back to the course's own validity window when no date was given */
    if ($expiry === '') {
        $r = $conn->query("SELECT validity_days FROM lms_courses WHERE id = $courseId");
        $days = $r ? (int)($r->fetch_assoc()['validity_days'] ?? 0) : 0;
        if ($days > 0) $expiry = date('Y-m-d', strtotime("+$days days"));
    }
    $expSql = $expiry === '' ? 'NULL' : "'" . $conn->real_escape_string($expiry) . "'";

    return (bool)$conn->query("INSERT INTO lms_enrollments
        (course_id, user_id, access_type, amount, source, expiry_date, status)
        VALUES ($courseId, $userId, '$type', $amount, '$source', $expSql, 'active')
        ON DUPLICATE KEY UPDATE
            access_type = VALUES(access_type),
            amount      = VALUES(amount),
            expiry_date = VALUES(expiry_date),
            status      = 'active'");
}

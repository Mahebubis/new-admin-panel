<?php
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../middleware/auth.php';
require_method('POST');
$jwt = require_jwt();
require_permission('manage_withdrawal', $jwt);

$input = get_json_input();
$id = intval($input['id'] ?? 0);
$rawStatus = strtolower(trim((string)($input['payment_status'] ?? $input['status'] ?? '')));

if (!$id || !$rawStatus) {
    api_error('ID and status are required');
}

// Admin panel's "Completed" button sends "success" — normalize to the
// panel's internal status word before validating.
if ($rawStatus === 'success') {
    $rawStatus = 'completed';
}

$allowedStatuses = ['completed', 'pending', 'under_review'];
if (!in_array($rawStatus, $allowedStatuses, true)) {
    api_error('Invalid status. Expecting completed | pending | under_review', 400);
}

/* withdrawal_request.payment_status stores "success" for a completed withdrawal;
 * transactions.status stores the raw status word. */
$wrStatusMap = [
    'completed'    => 'success',
    'pending'      => 'pending',
    'under_review' => 'under_review',
];
$wrStatus = $wrStatusMap[$rawStatus];

$conn->begin_transaction();

try {
    /* The proof screenshot is uploaded separately via upload-withdrawal-proof.php
     * before this call — just check it's already on file when completing. */
    $checkStmt = $conn->prepare("SELECT transaction_screenshot FROM withdrawal_request WHERE id = ?");
    $checkStmt->bind_param('i', $id);
    $checkStmt->execute();
    $checkStmt->bind_result($currentProof);
    $found = $checkStmt->fetch();
    $checkStmt->close();

    if (!$found) {
        throw new Exception('Withdrawal request not found');
    }
    if ($rawStatus === 'completed' && empty($currentProof)) {
        throw new Exception('Screenshot is required to mark as completed');
    }

    $stmt1 = $conn->prepare("UPDATE withdrawal_request SET payment_status = ? WHERE id = ?");
    if ($stmt1 === false) {
        throw new Exception('Failed to prepare withdrawal_request update');
    }
    $stmt1->bind_param('si', $wrStatus, $id);
    if (!$stmt1->execute()) {
        throw new Exception('Failed to update withdrawal_request');
    }
    $stmt1->close();

    $stmt2 = $conn->prepare("UPDATE transactions SET status = ? WHERE withdrawal_id = ?");
    if ($stmt2 === false) {
        throw new Exception('Failed to prepare transactions update');
    }
    $stmt2->bind_param('si', $rawStatus, $id);
    if (!$stmt2->execute()) {
        throw new Exception('Failed to update transactions');
    }
    $stmt2->close();

    $conn->commit();

    api_success([
        'withdrawal_request' => ['id' => $id, 'payment_status' => $wrStatus],
        'transactions'       => ['withdrawal_id' => $id, 'status' => $rawStatus],
    ], "Withdrawal status updated to $rawStatus");
} catch (Exception $e) {
    $conn->rollback();
    api_error($e->getMessage(), 400);
}

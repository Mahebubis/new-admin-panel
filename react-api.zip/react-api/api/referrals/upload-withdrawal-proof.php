<?php
/*
 * /api/referrals/upload-withdrawal-proof.php
 *
 * Uploads a payment proof (transaction screenshot) for a withdrawal request and
 * persists it on the shared `withdrawal_request` table — the same table the
 * dashboard's get_withdrawal_request.php reads — so the proof shows on the next
 * fetch as well. Multipart POST: { id, proof (file) }.
 */
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../middleware/auth.php';
require_method('POST');
$jwt = require_jwt();
require_permission('manage_withdrawal', $jwt);

$id = intval($_POST['id'] ?? 0);
if (!$id) api_error('Withdrawal id is required', 400);

if (!isset($_FILES['proof']) || $_FILES['proof']['error'] !== UPLOAD_ERR_OK) {
    api_error('No file uploaded or upload error', 400);
}

$file = $_FILES['proof'];

if ($file['size'] > 5 * 1024 * 1024) {
    api_error('File too large (max 5MB)', 400);
}

$allowed = ['jpg', 'jpeg', 'png', 'gif', 'webp', 'pdf'];
$ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
if (!in_array($ext, $allowed, true)) {
    api_error('Invalid file type. Allowed: ' . implode(', ', $allowed), 400);
}

$uploadDir = __DIR__ . '/../../uploads/withdrawal_proofs/';
if (!is_dir($uploadDir) && !mkdir($uploadDir, 0755, true) && !is_dir($uploadDir)) {
    api_error('Failed to create upload directory', 500);
}

$filename = 'wd_' . $id . '_' . uniqid() . '.' . $ext;
if (!move_uploaded_file($file['tmp_name'], $uploadDir . $filename)) {
    api_error('Failed to save uploaded file', 500);
}

$url = 'https://cit3.internshipstudio.com/admin/react-api/uploads/withdrawal_proofs/' . $filename;

/* Persist on the shared withdrawal_request table so the proof survives a reload. */
if ($stmt = $conn->prepare("UPDATE withdrawal_request SET transaction_screenshot = ? WHERE id = ?")) {
    $stmt->bind_param('si', $url, $id);
    $stmt->execute();
    $stmt->close();
}

api_success(['url' => $url, 'transaction_screenshot' => $url], 'Proof uploaded successfully');

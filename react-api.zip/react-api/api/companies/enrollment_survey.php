<?php
/*
 * /api/companies/enrollment_survey.php
 *
 * POST action=get_stats    → total, today, this_week, this_month
 * POST action=get_filters  → distinct values for q1 / q2 / q3 / q4 (for filter dropdowns)
 * POST action=fetch_data   → paginated + filtered list
 *      params: page, limit, search, q1, q2, q3, q4, date_from, date_to
 * POST action=export       → ALL filtered rows (no pagination, capped at 100000)
 *      params: search, q1, q2, q3, q4, date_from, date_to
 *
 * Table: enrollment_survey es  LEFT JOIN  users u ON u.user_id = es.user_id
 *   es: id, user_id, q1_current_status, q2_enroll_reason,
 *       q3_hear_about, q3_hear_about_other, q4_worth_outcome,
 *       q5_expectations, created_at, updated_at
 *   u:  username, email, name, phone
 */
ini_set('display_errors', 0);
ob_start();
chdir('/home/istudio/public_html/cit/common');
include '/home/istudio/public_html/cit/common/helper.php';
ob_clean();
header('Content-Type: application/json');

global $conn;
if (!$conn) { echo json_encode(['success' => false, 'message' => 'DB failed']); exit; }

$action = $_POST['action'] ?? '';

/* ══════════════════════════════════════
   SHARED — WHERE builder (filters)
══════════════════════════════════════ */
function survey_build_where($conn) {
    $search = $conn->real_escape_string(trim($_POST['search']    ?? ''));
    $q1     = $conn->real_escape_string(trim($_POST['q1']        ?? ''));
    $q2     = $conn->real_escape_string(trim($_POST['q2']        ?? ''));
    $q3     = $conn->real_escape_string(trim($_POST['q3']        ?? ''));
    $q4     = $conn->real_escape_string(trim($_POST['q4']        ?? ''));
    $df     = $conn->real_escape_string(trim($_POST['date_from'] ?? ''));
    $dt     = $conn->real_escape_string(trim($_POST['date_to']   ?? ''));

    $where = "WHERE 1=1";
    if ($search !== '') {
        $where .= "
            AND (
                u.username  LIKE '%{$search}%' OR
                u.email     LIKE '%{$search}%' OR
                u.name      LIKE '%{$search}%' OR
                u.phone     LIKE '%{$search}%' OR
                es.user_id  LIKE '%{$search}%'
            )";
    }
    if ($q1 !== '') $where .= " AND es.q1_current_status = '{$q1}'";
    if ($q2 !== '') $where .= " AND es.q2_enroll_reason  = '{$q2}'";
    if ($q3 !== '') $where .= " AND es.q3_hear_about     = '{$q3}'";
    if ($q4 !== '') $where .= " AND es.q4_worth_outcome  = '{$q4}'";
    if ($df !== '') $where .= " AND es.created_at >= '{$df} 00:00:00'";
    if ($dt !== '') $where .= " AND es.created_at <= '{$dt} 23:59:59'";
    return $where;
}

/* shared SELECT body */
$SELECT_BODY = "
    SELECT
        es.id, es.user_id,
        es.q1_current_status, es.q2_enroll_reason,
        es.q3_hear_about, es.q3_hear_about_other,
        es.q4_worth_outcome, es.q5_expectations,
        es.created_at, es.updated_at,
        u.username, u.email, u.name, u.phone
    FROM enrollment_survey es
    LEFT JOIN users u ON u.user_id = es.user_id
";

/* ══════════════════════════════════════
   GET STATS
══════════════════════════════════════ */
if ($action === 'get_stats') {
    $sql = "
        SELECT
            COUNT(*)                                                       AS total,
            SUM(DATE(created_at) = CURDATE())                              AS today,
            SUM(created_at >= DATE_SUB(CURDATE(), INTERVAL 7 DAY))         AS this_week,
            SUM(YEAR(created_at)  = YEAR(CURDATE())
                AND MONTH(created_at) = MONTH(CURDATE()))                   AS this_month
        FROM enrollment_survey
    ";
    $res = $conn->query($sql);
    if (!$res) { echo json_encode(['success' => false, 'message' => $conn->error]); exit; }
    $row = $res->fetch_assoc();
    echo json_encode([
        'success'    => true,
        'total'      => (int)$row['total'],
        'today'      => (int)$row['today'],
        'this_week'  => (int)$row['this_week'],
        'this_month' => (int)$row['this_month'],
    ]);
    exit;
}

/* ══════════════════════════════════════
   GET FILTERS — distinct option values
══════════════════════════════════════ */
if ($action === 'get_filters') {
    $out = ['q1' => [], 'q2' => [], 'q3' => [], 'q4' => []];
    $map = [
        'q1' => 'q1_current_status',
        'q2' => 'q2_enroll_reason',
        'q3' => 'q3_hear_about',
        'q4' => 'q4_worth_outcome',
    ];
    foreach ($map as $key => $col) {
        $r = $conn->query("
            SELECT DISTINCT {$col} AS v
            FROM enrollment_survey
            WHERE {$col} IS NOT NULL AND {$col} != ''
            ORDER BY {$col}
        ");
        if ($r) while ($row = $r->fetch_assoc()) $out[$key][] = $row['v'];
    }
    echo json_encode(['success' => true] + $out);
    exit;
}

/* ══════════════════════════════════════
   FETCH DATA (paginated + filtered)
══════════════════════════════════════ */
if ($action === 'fetch_data') {
    $page   = max(1, (int)($_POST['page']  ?? 1));
    $limit  = min(200, max(1, (int)($_POST['limit'] ?? 25)));
    $offset = ($page - 1) * $limit;

    $where = survey_build_where($conn);

    $cnt = $conn->query("
        SELECT COUNT(*) AS total
        FROM enrollment_survey es
        LEFT JOIN users u ON u.user_id = es.user_id
        {$where}
    ");
    if (!$cnt) { echo json_encode(['success' => false, 'message' => $conn->error]); exit; }
    $total = (int)$cnt->fetch_assoc()['total'];

    $data_res = $conn->query("
        {$SELECT_BODY}
        {$where}
        ORDER BY es.id DESC
        LIMIT {$limit} OFFSET {$offset}
    ");
    if (!$data_res) { echo json_encode(['success' => false, 'message' => $conn->error]); exit; }

    $rows = [];
    while ($row = $data_res->fetch_assoc()) $rows[] = $row;

    echo json_encode([
        'success'     => true,
        'data'        => $rows,
        'total'       => $total,
        'page'        => $page,
        'limit'       => $limit,
        'total_pages' => (int)ceil($total / max(1, $limit)),
    ]);
    exit;
}

/* ══════════════════════════════════════
   EXPORT — ALL filtered rows (no pagination)
══════════════════════════════════════ */
if ($action === 'export') {
    $where = survey_build_where($conn);

    $data_res = $conn->query("
        {$SELECT_BODY}
        {$where}
        ORDER BY es.id DESC
        LIMIT 100000
    ");
    if (!$data_res) { echo json_encode(['success' => false, 'message' => $conn->error]); exit; }

    $rows = [];
    while ($row = $data_res->fetch_assoc()) $rows[] = $row;

    echo json_encode([
        'success' => true,
        'data'    => $rows,
        'total'   => count($rows),
    ]);
    exit;
}

echo json_encode(['success' => false, 'message' => 'Invalid action']);
exit;
?>

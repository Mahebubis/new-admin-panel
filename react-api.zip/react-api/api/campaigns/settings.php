<?php
/*
 * /api/campaigns/settings.php — SendGrid / Elastic Email / Amazon SES credentials.
 * Seeded with dummy placeholder values by lib/schema.php; pasting real
 * credentials here is a pure data change, no code/deploy needed.
 *
 * action=get                                     → every provider row (secrets masked)
 * action=save   &provider &is_active &api_key &api_secret &auth_mode &aws_region
 *               &configuration_set &api_base_url &list_uid
 *               &webhook_secret &default_sender_name &default_sender_email &default_sending_domain
 * action=ses_status                              → SES sandbox state + send quota (API mode only)
 */
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../middleware/auth.php';
require_once __DIR__ . '/lib/config.php';
require_once __DIR__ . '/lib/schema.php';
require_once __DIR__ . '/lib/TransportFactory.php';
require_once __DIR__ . '/lib/SesSuppressionClient.php';

campaigns_ensure_schema();

$jwt = require_jwt();
require_permission('netcore_behaviour', $jwt);

function jin($k, $d = null) { $v = $_REQUEST[$k] ?? null; return ($v === null || $v === '') ? $d : $v; }
function mask_key($k) {
    $k = (string)$k;
    if (strlen($k) <= 8) return str_repeat('•', max(0, strlen($k) - 2)) . substr($k, -2);
    return substr($k, 0, 4) . str_repeat('•', 8) . substr($k, -4);
}

$action = jin('action', '');

if ($action === 'get') {
    // Filtered to the currently-supported providers rather than SELECT *: a retired
    // provider whose row somehow survives (e.g. an old mailwizz row on a DB that hasn't
    // run this release's migration yet) must not show up as an editable card.
    $inList = "'" . implode("','", array_map([$conn, 'real_escape_string'], TransportFactory::PROVIDERS)) . "'";
    $r = $conn->query("SELECT * FROM email_esp_settings WHERE provider IN ($inList) ORDER BY FIELD(provider, $inList)");
    $rows = [];
    while ($r && $row = $r->fetch_assoc()) {
        $row['api_key_masked'] = mask_key($row['api_key']);
        unset($row['api_key']); // never return the raw key to the client
        // Second credential half — only SES populates it, but it is masked and stripped
        // unconditionally so a provider added later cannot leak one by forgetting to.
        $row['api_secret_masked'] = mask_key($row['api_secret'] ?? '');
        unset($row['api_secret']);
        // MUST be cast. mysqli hands TINYINT back as the STRING "0"/"1", which JSON-encodes as
        // "0" — and in JavaScript `!!"0"` is TRUE, because it's a non-empty string. That made
        // the Settings page draw EVERY provider as the active sender, whichever one actually
        // was. Returning a real int is the fix; the frontend also compares numerically now.
        $row['is_active'] = (int)$row['is_active'];
        $rows[] = $row;
    }
    api_success(['settings' => $rows]);
}

if ($action === 'save') {
    $provider = jin('provider', '');
    if (!in_array($provider, TransportFactory::PROVIDERS, true)) api_error('Invalid provider');

    $set = [];
    $fields = ['api_key' => 's', 'api_secret' => 's', 'auth_mode' => 's', 'aws_region' => 's',
               'configuration_set' => 's', 'api_base_url' => 's', 'list_uid' => 's', 'webhook_secret' => 's',
               'default_sender_name' => 's', 'default_sender_email' => 's', 'default_sending_domain' => 's'];
    /*
     * Fields an empty box is allowed to CLEAR.
     *
     * jin() maps '' to its default, so the loop below used to read "submitted but blank" as
     * "not submitted at all" for every field alike — which meant emptying one of these and
     * pressing Save silently kept the old value. That is right for credentials (the secret is
     * never sent to the browser, so a blank box has to mean "keep what is stored") and wrong
     * for everything else. It cost a real afternoon: a configuration set name typed with
     * spaces could not be removed, and every send came back
     * "Invalid configuration set name <...>" from SES with the UI showing an empty box.
     *
     * auth_mode and aws_region stay out of this list deliberately — both have a validator
     * below that a blank value would trip, and neither has a meaningful empty state.
     */
    $clearable = ['configuration_set', 'api_base_url', 'list_uid', 'webhook_secret',
                  'default_sender_name', 'default_sender_email', 'default_sending_domain'];

    foreach ($fields as $f => $type) {
        if (in_array($f, $clearable, true)) {
            // Present in the request at all — including as '' — means the user set it.
            if (!array_key_exists($f, $_REQUEST)) continue;
            $v = (string)$_REQUEST[$f];
        } else {
            $v = jin($f, null);
            if ($v === null) continue;
        }
        // Credentials: leave untouched if the client sent back the masked placeholder (i.e. the
        // field was rendered from api_key_masked/api_secret_masked and never actually edited).
        if (($f === 'api_key' || $f === 'api_secret') && strpos((string)$v, '•') !== false) continue;
        /*
         * SES rejects a configuration set name containing anything but [A-Za-z0-9_-], and it
         * does so per recipient at send time — so a name with a space in it does not fail
         * here, it fails as an entire campaign of "permanent rejections" minutes later. Catch
         * it at the keyboard instead, exactly as the region below is caught.
         */
        if ($f === 'configuration_set') {
            $v = trim((string)$v);
            if ($v !== '' && !preg_match('/^[A-Za-z0-9_-]+$/', $v)) {
                api_error('A configuration set name can only contain letters, digits, "_" and "-" — SES rejects every send otherwise. Leave it empty if you have not created one.');
            }
        }
        // Only two auth modes exist; anything else would leave SesTransport silently defaulting
        // to API mode with an SMTP password in api_secret, which fails with a 403 per recipient.
        if ($f === 'auth_mode') {
            $v = strtolower(trim((string)$v));
            if (!in_array($v, ['api', 'smtp'], true)) api_error('Auth mode must be "api" or "smtp"');
        }
        // A typo'd region is worth catching here rather than as a signature failure on every
        // send: the region is part of the SigV4 credential scope AND of the SMTP hostname.
        if ($f === 'aws_region') {
            $v = strtolower(trim((string)$v));
            if (!preg_match('/^[a-z]{2}(-[a-z]+)+-\d$/', $v)) api_error('That does not look like an AWS region (e.g. ap-south-1)');
        }
        $set[] = "$f='" . $conn->real_escape_string((string)$v) . "'";
    }

    $isActive = jin('is_active', null);
    if ($isActive !== null) {
        if ((int)$isActive === 1) {
            // only one provider can be "active" (the one new campaigns default to)
            $conn->query("UPDATE email_esp_settings SET is_active=0");
        }
        $set[] = "is_active=" . ((int)$isActive === 1 ? 1 : 0);
    }

    if ($set) {
        $provE = $conn->real_escape_string($provider);
        $conn->query("UPDATE email_esp_settings SET " . implode(', ', $set) . " WHERE provider='$provE'");
    }

    /*
     * Making a provider the active sender while its credentials are still placeholders is
     * allowed — it may well be the intended order of operations — but it is worth saying out
     * loud, because the symptom otherwise arrives much later as a whole campaign whose every
     * recipient failed. Checked AFTER the write so it reflects what was just saved.
     */
    $warning = null;
    if ($isActive !== null && (int)$isActive === 1) {
        $t = TransportFactory::forProvider($provider);
        if (!$t || !$t->isConfigured()) {
            $warning = 'Saved, but this provider has no real credentials yet — campaigns sent now will fail. '
                     . 'Paste the credentials above and save again.';
        }
    }
    api_success($warning === null ? [] : ['warning' => $warning]);
}

/*
 * SES-only connection check. Answers the two questions that decide whether a send will work
 * and that nothing else in the UI can reveal: is the account still in the SANDBOX (where every
 * unverified recipient is rejected and the cap is 200/day), and what is the real sending rate?
 * See ses_account_status() for why guessing at this from failed sends is so unpleasant.
 */
if ($action === 'ses_status') {
    api_success(['ses' => ses_account_status()]);
}

api_error('Invalid action');

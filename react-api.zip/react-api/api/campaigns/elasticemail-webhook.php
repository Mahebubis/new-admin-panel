<?php
/*
 * Public receiver for Elastic Email's HTTP web notifications — the Elastic Email
 * counterpart of sendgrid-webhook.php. Configure at:
 *   Elastic Email dashboard → Settings → Notifications → Manage webhooks
 *   → URL = this file's public URL, with Sent / Error / Unsubscribed / AbuseReport
 *     events enabled (Opened / Clicked are NOT needed — see below).
 *
 * !! PLAN NOTE: webhooks are a PRO-plan feature at Elastic Email. On the Free
 * plan the "Manage webhooks" link in their dashboard is locked, nothing will ever
 * POST here, and campaigns sent via this transport will show sent_count but
 * delivered_count = 0 and bounce_count = 0. Open and click counts are unaffected —
 * those are first-party (track-open.php / track-click.php), not provider-reported.
 *
 * Two differences from SendGrid's webhook that shape this file:
 *   1. Elastic Email delivers ONE event per request as ordinary request parameters
 *      (query string / form fields), not a JSON array of many events. A JSON body
 *      is still accepted below as a fallback in case a future/PRO variant posts one.
 *   2. Correlation comes from `postback` — the arbitrary passthrough string we set to
 *      our rid in lib/ElasticEmailTransport.php. If it's missing we fall back to
 *      matching `messageid` against email_campaign_recipients.esp_message_id (indexed),
 *      which the transport stored from the send response.
 */
ini_set('display_errors', 0);
error_reporting(0);
header('Content-Type: application/json');

require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../lists/lib/schema.php';
require_once __DIR__ . '/../lists/lib/ContactImportWorker.php';

// Accept params in whichever shape arrives: query string, form POST, or a JSON body.
$params = $_REQUEST;
$raw = file_get_contents('php://input');
if ($raw !== '' && $raw !== false) {
    $json = json_decode($raw, true);
    if (is_array($json)) {
        // A JSON body may itself be a single event object or a list of them; normalize
        // to a list so the loop below handles both without branching.
        $events = isset($json[0]) && is_array($json[0]) ? $json : [$json];
    } else {
        $events = [$params];
    }
} else {
    $events = [$params];
}

/*
 * Elastic Email's `category` on an Error event, split by "is the RECIPIENT address
 * permanently bad?" — because a hard bounce auto-blocklists the address forever
 * (same policy as sendgrid-webhook.php) and that must never happen for a problem
 * on OUR side or a transient one on theirs.
 *
 * Soft (retryable, never blocklisted): transient remote failures AND our own
 * misconfiguration — SPFProblem/AccountProblem/CodeError/ManualCancel are all
 * sender-side, so blocklisting an innocent recipient for them would be a bug.
 */
$SOFT_BOUNCE_CATEGORIES = [
    'greylisted', 'throttled', 'timeout', 'connectionproblem', 'connectionterminated',
    'dnsproblem', 'whitelistingproblem', 'spfproblem', 'accountproblem', 'contentfilter',
    'codeerror', 'manualcancel', 'ignore',
];

$processed = 0;
foreach ($events as $evt) {
    if (!is_array($evt)) continue;

    // Elastic Email's own field casing has varied across versions/transports; read
    // case-insensitively so a `Status`/`MessageID` variant doesn't silently no-op.
    $get = function (string $key) use ($evt) {
        foreach ($evt as $k => $v) {
            if (strcasecmp((string)$k, $key) === 0) return $v;
        }
        return null;
    };

    $status   = strtolower(trim((string)$get('status')));
    $category = strtolower(trim((string)$get('category')));
    $rid      = (string)($get('postback') ?? '');
    $msgId    = (string)($get('messageid') ?? '');

    // Opens and clicks are already tracked first-party via track-open.php / track-click.php
    // (and the transport explicitly disables Elastic Email's own tracking), so ignore them
    // here rather than double-counting.
    if ($status === 'opened' || $status === 'clicked') continue;

    $recipient = null;
    if (preg_match('/^[a-f0-9]{32}$/', $rid)) {
        $stmt = $conn->prepare("SELECT id, campaign_id, email FROM email_campaign_recipients WHERE rid = ? LIMIT 1");
        $stmt->bind_param('s', $rid);
        $stmt->execute();
        $recipient = $stmt->get_result()->fetch_assoc();
        $stmt->close();
    }
    if (!$recipient && $msgId !== '') {
        $stmt = $conn->prepare("SELECT id, campaign_id, email FROM email_campaign_recipients WHERE esp_message_id = ? LIMIT 1");
        $stmt->bind_param('s', $msgId);
        $stmt->execute();
        $recipient = $stmt->get_result()->fetch_assoc();
        $stmt->close();
    }
    if (!$recipient) {
        /*
         * Not a campaign rid — offer it to the Journey engine, which keeps its own rids
         * in journey_messages. Elastic Email posts every event for the account here, so
         * without this hand-off journey emails never received a delivery confirmation.
         *
         * 'Sent' is Elastic's provider-confirmed hand-off, i.e. what SendGrid calls
         * 'delivered' — translated so the sink has one vocabulary to handle.
         *
         * Guarded with file_exists because this tree deploys folder by folder: requiring
         * a file that has not been uploaded yet is a fatal, and it would take the campaign
         * receipts handled below down with it.
         */
        $sink = __DIR__ . '/../journeys/lib/JourneyWebhookSink.php';
        if (file_exists($sink)) {
            require_once $sink;
            $jType = $status === 'sent' ? 'delivered' : ($status === 'error' ? 'bounce'
                   : ($status === 'unsubscribed' ? 'unsubscribe' : ($status === 'abusereport' ? 'spamreport' : $status)));
            if (journey_webhook_email_event($rid, $jType, $evt)) $processed++;
        }
        continue;
    }

    // 'Sent' is Elastic Email's provider-confirmed hand-off to the receiving mailbox —
    // the equivalent of SendGrid's 'delivered', and the ONLY place delivered_count grows
    // (the worker's own "sent" only means the API accepted our call).
    if ($status === 'sent') {
        $conn->query("UPDATE email_campaigns SET delivered_count = delivered_count + 1 WHERE id={$recipient['campaign_id']}");
        $processed++;
        continue;
    }

    $statusMap = [
        'error'        => 'bounce',
        'unsubscribed' => 'unsubscribe',
        'abusereport'  => 'spamreport',
    ];
    $mapped = $statusMap[$status] ?? null;
    if ($mapped === null) continue;

    $metaE = $conn->real_escape_string(json_encode($evt));
    $conn->query("INSERT INTO email_campaign_events (campaign_id, recipient_id, event_type, meta)
                  VALUES ({$recipient['campaign_id']}, {$recipient['id']}, '$mapped', '$metaE')");

    if ($mapped === 'bounce') {
        // Anything not explicitly listed as soft (NoMailbox, BlackListed, Spam,
        // NotDelivered, Unknown, or a missing category) is treated as hard — the safer
        // assumption for suppression, matching sendgrid-webhook.php.
        $bounceType = in_array($category, $SOFT_BOUNCE_CATEGORIES, true) ? 'soft' : 'hard';
        $conn->query("UPDATE email_campaign_recipients SET status='bounced', bounced_at=NOW(), bounce_type='$bounceType' WHERE id={$recipient['id']}");
        $countCol = $bounceType === 'soft' ? 'soft_bounce_count' : 'hard_bounce_count';
        $conn->query("UPDATE email_campaigns SET bounce_count = bounce_count + 1, $countCol = $countCol + 1 WHERE id={$recipient['campaign_id']}");

        // Hard bounce = the address is permanently invalid, so blocklist it exactly as an
        // unsubscribe would. Soft bounces are left alone — the address may work later.
        if ($bounceType === 'hard' && !empty($recipient['email'])) {
            $blocklistId = lists_get_or_create_blocklist_id();
            contact_upsert(['email' => $recipient['email']], $blocklistId);
        }
    } elseif ($mapped === 'unsubscribe') {
        $conn->query("UPDATE email_campaigns SET unsubscribe_count = unsubscribe_count + 1 WHERE id={$recipient['campaign_id']}");
        if (!empty($recipient['email'])) {
            $blocklistId = lists_get_or_create_blocklist_id();
            contact_upsert(['email' => $recipient['email']], $blocklistId);
        }
    } elseif ($mapped === 'spamreport') {
        $conn->query("UPDATE email_campaigns SET spam_count = spam_count + 1 WHERE id={$recipient['campaign_id']}");
        if (!empty($recipient['email'])) {
            $blocklistId = lists_get_or_create_blocklist_id();
            contact_upsert(['email' => $recipient['email']], $blocklistId, 'Marked as spam via Elastic Email');
        }
    }
    $processed++;
}

http_response_code(200);
echo json_encode(['ok' => true, 'processed' => $processed]);

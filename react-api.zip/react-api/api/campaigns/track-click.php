<?php
/*
 * Public, unauthenticated click-tracking redirect.
 * Every <a href> in a sent campaign email is rewritten by
 * lib/TrackingRewriter.php to point here, with the original URL in `u`.
 */
ini_set('display_errors', 0);
error_reporting(0);

$rid = $_GET['rid'] ?? '';
$url = $_GET['u'] ?? '';
// Fallback destination if rid/url are missing or malformed — never leave the user on a dead page.
$fallback = 'https://internshipstudio.com';

if (!preg_match('/^[a-f0-9]{32}$/', $rid) || $url === '') {
    header('Location: ' . $fallback, true, 302);
    exit;
}
$destination = filter_var($url, FILTER_VALIDATE_URL) ? $url : $fallback;

require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/lib/TrackingRewriter.php';
require_once __DIR__ . '/lib/BotDetector.php';

// goal_window_days is joined in because the landing page needs it to size the attribution
// cookie's expiry (see the redirect below) — it is the campaign's own setting, so it has to
// travel with the click rather than being guessed at the other end. is_test and sent_at come
// along for the same reasons as in track-open.php: a test send must not move the real
// campaign's numbers, and sent_at feeds the "too soon to be a human" bot rule.
$stmt = $conn->prepare("SELECT ecr.id, ecr.campaign_id, ecr.first_clicked_at, ecr.is_test, ecr.sent_at,
                               c.goal_window_days
                          FROM email_campaign_recipients ecr
                          LEFT JOIN email_campaigns c ON c.id = ecr.campaign_id
                         WHERE ecr.rid = ? LIMIT 1");
$stmt->bind_param('s', $rid);
$stmt->execute();
$recipient = $stmt->get_result()->fetch_assoc();
$stmt->close();

if ($recipient) {
    $ip = $conn->real_escape_string($_SERVER['REMOTE_ADDR'] ?? '');
    $rawUa = $_SERVER['HTTP_USER_AGENT'] ?? '';
    $ua = $conn->real_escape_string(substr($rawUa, 0, 490));
    $device = classify_device_type($rawUa);
    $urlE = $conn->real_escape_string(substr($destination, 0, 60000));

    // Security gateways follow every link in a message exactly as they fetch the open
    // pixel, so clicks need the same filter — see lib/BotDetector.php. A filtered click is
    // still redirected normally below; only the counting changes, never the user's journey.
    $secondsSinceSent = !empty($recipient['sent_at']) ? (time() - strtotime($recipient['sent_at'])) : null;
    $reason = tracking_machine_reason($rawUa, $secondsSinceSent, $_SERVER['REQUEST_METHOD'] ?? 'GET');

    if ($reason !== null) {
        $metaE = $conn->real_escape_string(json_encode(['filtered' => $reason]));
        $conn->query("INSERT INTO email_campaign_events (campaign_id, recipient_id, event_type, url, ip_address, user_agent, device_type, meta)
                      VALUES ({$recipient['campaign_id']}, {$recipient['id']}, 'click_bot', '$urlE', '$ip', '$ua', '$device', '$metaE')");
        if ((int)$recipient['is_test'] === 0) {
            $conn->query("UPDATE email_campaigns SET bot_click_count = bot_click_count + 1 WHERE id = " . (int)$recipient['campaign_id']);
        }
    } else {
        $isFirstClick = empty($recipient['first_clicked_at']);
        $conn->query("UPDATE email_campaign_recipients SET click_count = click_count + 1, first_clicked_at = IFNULL(first_clicked_at, NOW()) WHERE id = " . (int)$recipient['id']);
        if ((int)$recipient['is_test'] === 0) {
            $conn->query("UPDATE email_campaigns SET click_count = click_count + 1" . ($isFirstClick ? ", unique_click_count = unique_click_count + 1" : '') . " WHERE id = " . (int)$recipient['campaign_id']);
        }
        $conn->query("INSERT INTO email_campaign_events (campaign_id, recipient_id, event_type, url, ip_address, user_agent, device_type)
                      VALUES ({$recipient['campaign_id']}, {$recipient['id']}, 'click', '$urlE', '$ip', '$ua', '$device')");
    }

    // Carries the campaign forward onto the landing page so it can save/refresh
    // attribution (cookie for guests, DB row for logged-in users) — see
    // user_dashboard's src/utils/attribution.js, which reads these params.
    //
    // attr_window is the campaign's own goal_window_days, and it sizes the attribution
    // cookie's expiry at the other end. Before this was sent, attribution.js hardcoded a
    // 2-day cookie for every campaign: a campaign configured with a 7-day goal window
    // silently lost every conversion after day 2 (cookie already deleted by the browser),
    // and a 1-day campaign over-counted anything on day 2. Clamped to 1..90 so a nonsense
    // stored value can't produce a never-expiring cookie.
    $windowDays = (int)($recipient['goal_window_days'] ?: 2);
    $windowDays = max(1, min(90, $windowDays));
    $sep = (strpos($destination, '?') === false) ? '?' : '&';
    $destination .= $sep . 'campaign_id=' . (int)$recipient['campaign_id'] . '&medium=email&attr_window=' . $windowDays;
}

header('Location: ' . $destination, true, 302);
exit;

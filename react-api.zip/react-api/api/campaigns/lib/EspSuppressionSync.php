<?php
/*
 * One front door for "our Blocklist changed — tell the email providers about it".
 *
 * There is exactly ONE Blocklist on our side, but more than one ESP can be
 * configured at a time (SendGrid, Elastic Email and Amazon SES each keep their own
 * private suppression lists). Syncing only whichever provider happens to be the Active
 * sender today would leave stale suppressions behind the moment the admin flips
 * the Active sender radio in Settings — an address blocklisted while SendGrid was
 * active would still be deliverable through Elastic Email, and an address
 * un-blocklisted would stay permanently suppressed on the provider that wasn't
 * active at the time.
 *
 * So both calls below fan out to EVERY provider that has a real (non-placeholder)
 * API key. Each provider client already no-ops silently when its key is still the
 * seeded dummy, so an install using only one provider costs one cheap DB lookup.
 */
require_once __DIR__ . '/SendGridSuppressionClient.php';
require_once __DIR__ . '/ElasticEmailSuppressionClient.php';
require_once __DIR__ . '/SesSuppressionClient.php';

/** Suppress $email at every configured ESP (called when it's added to our Blocklist). */
function esp_add_global_suppression(string $email): void {
    sendgrid_add_global_suppression($email);
    elasticemail_add_global_suppression($email);
    ses_add_global_suppression($email);
}

/** Un-suppress $email at every configured ESP (called when it's removed from our Blocklist).
 *  The SES call is the one that carries the most weight: SES suppresses hard bounces and
 *  complaints on its own, so an address it has blacklisted stays undeliverable until this
 *  explicit delete runs, however clean our own tables look. */
function esp_remove_all_suppressions(string $email): void {
    sendgrid_remove_all_suppressions($email);
    elasticemail_remove_all_suppressions($email);
    ses_remove_all_suppressions($email);
}

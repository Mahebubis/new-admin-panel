<?php
require_once __DIR__ . '/SendGridTransport.php';
require_once __DIR__ . '/ElasticEmailTransport.php';
require_once __DIR__ . '/SesTransport.php';

class TransportFactory {
    /** Providers that can actually be selected/configured today. MailWizz is intentionally
     *  absent: its row is gone from email_esp_settings and its transport class was removed,
     *  but the value survives in the esp_transport ENUM so historical campaign rows stay
     *  readable (see the migration note in lib/schema.php). */
    public const PROVIDERS = ['sendgrid', 'elasticemail', 'ses'];

    /** Reads $campaign['esp_transport'], loads the matching email_esp_settings row, instantiates. */
    public static function forCampaign(array $campaign): ?EspTransport {
        return self::forProvider($campaign['esp_transport'] ?? 'sendgrid');
    }

    public static function forProvider(string $provider): ?EspTransport {
        global $conn;
        // Anything unrecognized — including the retired 'mailwizz' on an old campaign being
        // requeued — falls back to SendGrid rather than returning null, so a legacy campaign
        // still sends instead of failing every recipient with "No ESP transport configured".
        if (!in_array($provider, self::PROVIDERS, true)) $provider = 'sendgrid';

        $stmt = $conn->prepare("SELECT * FROM email_esp_settings WHERE provider = ? LIMIT 1");
        $stmt->bind_param('s', $provider);
        $stmt->execute();
        $row = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        if (!$row) return null;

        if ($provider === 'elasticemail') return new ElasticEmailTransport($row);
        if ($provider === 'ses')          return new SesTransport($row);
        return new SendGridTransport($row);
    }

    /** Which provider is flagged active in Settings (used as the default for new campaigns). */
    public static function activeProvider(): string {
        global $conn;
        $r = $conn->query("SELECT provider FROM email_esp_settings WHERE is_active = 1 LIMIT 1");
        $row = $r ? $r->fetch_assoc() : null;
        $provider = $row['provider'] ?? 'sendgrid';
        return in_array($provider, self::PROVIDERS, true) ? $provider : 'sendgrid';
    }

    /**
     * How many sends this provider tolerates in flight at once.
     *
     * CAMPAIGN_SEND_CONCURRENCY is tuned for SendGrid and Elastic Email, which absorb a burst
     * and answer 429 only under sustained load. Amazon SES is different in kind: it enforces a
     * hard requests-PER-SECOND ceiling (14/s by default in production, 1/s while the account is
     * still in the sandbox) and rejects everything above it immediately. Firing 32 concurrent
     * sends at it means most of a batch comes back throttled — those retry rather than being
     * lost (see SesTransport::parseResponse), but the run is spent achieving nothing.
     *
     * So SES is capped at its default rate. Raise SES_MAX_CONCURRENCY in lib/config.php after
     * AWS grants a higher sending rate — the value is a per-second rate and each send takes
     * well under a second, so concurrency ≈ rate is the right approximation.
     */
    public static function concurrencyFor(string $provider): int {
        $base = defined('CAMPAIGN_SEND_CONCURRENCY') ? (int)CAMPAIGN_SEND_CONCURRENCY : 32;
        if ($provider === 'ses') {
            $cap = defined('SES_MAX_CONCURRENCY') ? (int)SES_MAX_CONCURRENCY : 14;
            return max(1, min($base, $cap));
        }
        return max(1, $base);
    }
}

<?php
/*
 * Elastic Email suppression-list sync — the Elastic Email counterpart of
 * SendGridSuppressionClient.php, keeping Elastic Email's own suppression lists
 * (unsubscribes / bounces / complaints) in sync with OUR Blocklist in both directions:
 *   - elasticemail_add_global_suppression(): called whenever an email lands on our
 *     blocklist (manual add, CSV import, auto-added hard bounce/unsubscribe/spam) —
 *     so Elastic Email itself also refuses the address, not just our AudienceResolver.
 *   - elasticemail_remove_all_suppressions(): called whenever an email is removed from
 *     our blocklist, so it can actually receive mail again.
 * Uses the same API key stored in email_esp_settings (provider='elasticemail') that
 * ElasticEmailTransport.php sends real campaigns through.
 */

function elasticemail_api_key(): ?string {
    global $conn;
    $r = $conn->query("SELECT api_key FROM email_esp_settings WHERE provider='elasticemail' LIMIT 1");
    $row = $r ? $r->fetch_assoc() : null;
    $key = $row['api_key'] ?? null;
    // The dummy placeholder seeded for brand-new installs (see campaigns_ensure_schema())
    // isn't a real key — treat it the same as "not configured".
    return ($key && $key !== 'DUMMY_ELASTICEMAIL_API_KEY') ? $key : null;
}

function elasticemail_api_request(string $method, string $path, $body = null): array {
    $apiKey = elasticemail_api_key();
    if (!$apiKey) return ['ok' => false, 'error' => 'Elastic Email API key not configured'];

    $ch = curl_init('https://api.elasticemail.com/v4' . $path);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_CUSTOMREQUEST => $method,
        CURLOPT_HTTPHEADER => ['X-ElasticEmail-ApiKey: ' . $apiKey, 'Content-Type: application/json'],
        CURLOPT_TIMEOUT => 15,
    ]);
    if ($body !== null) curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($body));
    $respBody = curl_exec($ch);
    $status = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $curlErr = curl_error($ch);
    curl_close($ch);

    if ($curlErr) return ['ok' => false, 'error' => "Network error: $curlErr"];
    // A 404 on the DELETE just means the address wasn't suppressed in the first place —
    // a harmless no-op for every caller here, same as the SendGrid client.
    if ($status >= 200 && $status < 300) return ['ok' => true, 'status' => $status, 'body' => $respBody];
    return ['ok' => false, 'status' => $status, 'error' => $respBody];
}

function elasticemail_suppression_log(string $msg): void {
    if (function_exists('campaign_log')) { campaign_log('[elasticemail-suppression] ' . $msg); return; }
    error_log('[elasticemail-suppression] ' . $msg);
}

/** Adds $email to Elastic Email's unsubscribes suppression list — their broadest
 *  suppression type, stops Elastic Email sending to the address under any campaign.
 *  Silently no-ops when no real API key is configured yet (local/dev). */
function elasticemail_add_global_suppression(string $email): void {
    if (!elasticemail_api_key()) return;
    // POST /v4/suppressions/unsubscribes takes a bare JSON array of email strings.
    $res = elasticemail_api_request('POST', '/suppressions/unsubscribes', [$email]);
    elasticemail_suppression_log("add unsubscribe suppression for $email -> " . ($res['ok'] ? 'ok' : 'FAILED: ' . ($res['error'] ?? '')));
}

/** Removes $email from Elastic Email's suppressions. Unlike SendGrid (which needs one
 *  DELETE per list type) Elastic Email exposes a single DELETE /v4/suppressions/{email}
 *  that clears the address from unsubscribes, bounces and complaints at once. */
function elasticemail_remove_all_suppressions(string $email): void {
    if (!elasticemail_api_key()) return;
    $res = elasticemail_api_request('DELETE', '/suppressions/' . rawurlencode($email));
    elasticemail_suppression_log("remove all suppressions for $email -> " . ($res['ok'] ? 'ok' : ($res['status'] ?? '?') . ' ' . ($res['error'] ?? '')));
}

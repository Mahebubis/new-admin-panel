<?php
require_once __DIR__ . '/EspTransport.php';
require_once __DIR__ . '/ParallelSender.php';

/*
 * SendGrid Web API v3 transport (https://api.sendgrid.com/v3/mail/send).
 * With a dummy/invalid API key, SendGrid returns HTTP 401 with a JSON error
 * body — parseResponse() surfaces that cleanly as ok=false/error=<message> rather
 * than throwing, so "Send Test Email" can show a legible failure until a real
 * key is pasted into Settings.
 */
class SendGridTransport implements EspTransport {
    private string $apiKey;

    public function __construct(array $settingsRow) {
        $this->apiKey = (string)($settingsRow['api_key'] ?? '');
    }

    public function isConfigured(): bool {
        return $this->apiKey !== '';
    }

    public function buildRequest(string $to, string $subject, string $html, string $fromName, string $fromEmail, ?string $replyTo, ?string $rid, array $attachments = []): array {
        $payload = [
            'personalizations' => [[
                'to' => [['email' => $to]],
                'subject' => $subject,
            ]],
            'from' => ['email' => $fromEmail, 'name' => $fromName],
            'content' => [['type' => 'text/html', 'value' => $html]],
        ];
        if ($replyTo) $payload['reply_to'] = ['email' => $replyTo];
        // Echoed back verbatim on every Event Webhook payload for this send — lets
        // sendgrid-webhook.php correlate bounce/unsubscribe events to our recipient row.
        if ($rid) $payload['custom_args'] = ['rid' => $rid];
        if ($attachments) {
            $payload['attachments'] = array_map(fn($a) => [
                'content' => $a['content'], 'filename' => $a['filename'],
                'type' => $a['type'] ?? 'application/octet-stream', 'disposition' => 'attachment',
            ], $attachments);
        }

        return [
            'url' => 'https://api.sendgrid.com/v3/mail/send',
            'headers' => [
                'Authorization: Bearer ' . $this->apiKey,
                'Content-Type: application/json',
            ],
            'body' => json_encode($payload),
        ];
    }

    public function parseResponse(int $status, ?string $body, string $curlError, ?string $rid): array {
        if ($curlError !== '') {
            // Never permanent: a timeout or dropped connection says nothing about whether the
            // address is deliverable, so this must not consume one of the 3 attempts.
            return ['ok' => false, 'message_id' => null, 'error' => "Network error: $curlError", 'retryable' => true];
        }
        if ($status >= 200 && $status < 300) {
            // SendGrid returns the message id in the X-Message-Id response header, not
            // in the body — fall back to our own rid, which already uniquely identifies
            // the send and is what the Event Webhook echoes back anyway.
            return ['ok' => true, 'message_id' => $rid, 'error' => null, 'retryable' => false];
        }

        $decoded = json_decode((string)$body, true);
        $msg = $decoded['errors'][0]['message'] ?? ($body ?: "HTTP $status");
        // 429 = over the account's rate limit, 5xx = SendGrid having a moment. Both mean
        // "try this recipient again", not "this recipient is undeliverable" — which matters
        // enormously at high concurrency, where a rate-limit burst would otherwise
        // permanently fail thousands of good addresses in one batch.
        $retryable = ($status === 429 || $status >= 500);
        return ['ok' => false, 'message_id' => null, 'error' => "SendGrid $status: $msg", 'retryable' => $retryable];
    }

    public function sendEmail(string $to, string $subject, string $html, string $fromName, string $fromEmail, ?string $replyTo, ?string $rid, array $attachments = []): array {
        if (!$this->isConfigured()) {
            return ['ok' => false, 'message_id' => null, 'error' => 'SendGrid API key not configured', 'retryable' => false];
        }
        $req = $this->buildRequest($to, $subject, $html, $fromName, $fromEmail, $replyTo, $rid, $attachments);
        [$status, $body, $curlErr] = esp_http_exec($req);
        return $this->parseResponse($status, $body, $curlErr, $rid);
    }
}

<?php
require_once __DIR__ . '/EspTransport.php';
require_once __DIR__ . '/ParallelSender.php';

/*
 * Elastic Email REST API v4 transport
 * (POST https://api.elasticemail.com/v4/emails/transactional).
 *
 * Same role as SendGridTransport: a pure one-email-at-a-time delivery engine.
 * Recipient lists, personalization, templates and ALL open/click tracking stay
 * first-party (our own pixel + redirect, see lib/TrackingRewriter.php), so a
 * campaign looks identical in the UI whichever transport sent it.
 *
 * Auth is the X-ElasticEmail-ApiKey header (NOT a Bearer token) — the same key
 * shown under Settings → API in the Elastic Email dashboard, stored in
 * email_esp_settings (provider='elasticemail').
 *
 * With an invalid key the API answers 401 with a JSON {"Error": "..."} body,
 * which parseResponse() surfaces as ok=false/error=<message> rather than throwing,
 * so "Send Test Email" shows a legible failure instead of a blank 500.
 */
class ElasticEmailTransport implements EspTransport {
    private string $apiKey;

    public function __construct(array $settingsRow) {
        $this->apiKey = (string)($settingsRow['api_key'] ?? '');
    }

    public function isConfigured(): bool {
        return $this->apiKey !== '';
    }

    public function buildRequest(string $to, string $subject, string $html, string $fromName, string $fromEmail, ?string $replyTo, ?string $rid, array $attachments = []): array {
        // Elastic Email takes From/ReplyTo as a single RFC-style string, not a
        // {name, email} object the way SendGrid's payload does.
        $from = $fromName !== '' ? sprintf('%s <%s>', $fromName, $fromEmail) : $fromEmail;

        $payload = [
            'Recipients' => ['To' => [$to]],
            'Content' => [
                'Body'    => [['ContentType' => 'HTML', 'Content' => $html, 'Charset' => 'utf-8']],
                'Subject' => $subject,
                'From'    => $from,
            ],
            'Options' => [
                // BOTH deliberately off. inject_tracking() has already rewritten every link
                // to our own track-click.php and appended our open pixel before this method is
                // called; letting Elastic Email ALSO rewrite the same links would double-wrap
                // them (their redirector pointing at our redirector), which mangles the final
                // destination URL and makes their click counts and ours disagree. Tracking is
                // first-party by design here — see lib/TrackingRewriter.php.
                'TrackOpens'  => false,
                'TrackClicks' => false,
            ],
        ];
        if ($replyTo) $payload['Content']['ReplyTo'] = $replyTo;
        // Postback is Elastic Email's arbitrary passthrough string: it is echoed back
        // verbatim on every webhook notification for this send, which is exactly how
        // elasticemail-webhook.php correlates an async bounce/unsubscribe event back to
        // our recipient row (the equivalent of SendGrid's custom_args.rid).
        if ($rid) $payload['Content']['Postback'] = $rid;
        if ($attachments) {
            $payload['Content']['Attachments'] = array_map(fn($a) => [
                'BinaryContent' => $a['content'],          // already base64 (see load_campaign_attachments())
                'Name'          => $a['filename'],
                'ContentType'   => $a['type'] ?? 'application/octet-stream',
            ], $attachments);
        }

        return [
            'url' => 'https://api.elasticemail.com/v4/emails/transactional',
            'headers' => [
                'X-ElasticEmail-ApiKey: ' . $this->apiKey,
                'Content-Type: application/json',
            ],
            'body' => json_encode($payload),
        ];
    }

    public function parseResponse(int $status, ?string $body, string $curlError, ?string $rid): array {
        if ($curlError !== '') {
            return ['ok' => false, 'message_id' => null, 'error' => "Network error: $curlError", 'retryable' => true];
        }

        $decoded = json_decode((string)$body, true);
        if ($status >= 200 && $status < 300) {
            // Unlike SendGrid (message id only in a response header), Elastic Email returns
            // {"TransactionID": "...", "MessageID": "..."} in the body. MessageID is what its
            // webhook notifications carry as `messageid`, so store that as esp_message_id —
            // it's the fallback correlation key when `postback` is missing from an event.
            $msgId = $decoded['MessageID'] ?? $decoded['TransactionID'] ?? $rid;
            return ['ok' => true, 'message_id' => $msgId, 'error' => null, 'retryable' => false];
        }

        $msg = $decoded['Error'] ?? $decoded['error'] ?? $decoded['message'] ?? ($body ?: "HTTP $status");
        // Elastic Email throttles hard on the lower plans, so 429 is a genuinely expected
        // outcome when running at high concurrency — see the note in SendGridTransport.
        $retryable = ($status === 429 || $status >= 500);
        return [
            'ok' => false, 'message_id' => null,
            'error' => "Elastic Email $status: " . (is_string($msg) ? $msg : json_encode($msg)),
            'retryable' => $retryable,
        ];
    }

    public function sendEmail(string $to, string $subject, string $html, string $fromName, string $fromEmail, ?string $replyTo, ?string $rid, array $attachments = []): array {
        if (!$this->isConfigured()) {
            return ['ok' => false, 'message_id' => null, 'error' => 'Elastic Email API key not configured', 'retryable' => false];
        }
        $req = $this->buildRequest($to, $subject, $html, $fromName, $fromEmail, $replyTo, $rid, $attachments);
        [$status, $body, $curlErr] = esp_http_exec($req);
        return $this->parseResponse($status, $body, $curlErr, $rid);
    }
}

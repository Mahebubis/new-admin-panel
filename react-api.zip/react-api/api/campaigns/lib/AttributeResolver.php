<?php
/*
 * Resolves Customer Attribute values (public/react-api/api/attributes/) for a
 * batch of recipients at send time — either a live lookup against the
 * attribute's mapped table.column (category='system'), or a lookup against
 * campaign_attribute_data's own column for that attribute (category='custom',
 * usually populated by a CSV import — see lists/lib/ContactImportWorker.php).
 * Batched per tick (one query per attribute for the WHOLE tick's recipients),
 * not per-recipient, since SendWorker.php already processes recipients in
 * small chunks (50/tick).
 */
require_once __DIR__ . '/../../attributes/lib/schema.php';

/** Logs to worker.log when available (real sends, via SendWorker.php's campaign_log()),
 *  else falls back to the PHP error log (test sends from campaigns.php/templates.php,
 *  which don't load SendWorker.php) — so this is traceable either way. */
function attr_resolve_log(string $msg): void {
    if (function_exists('campaign_log')) { campaign_log('[attributes] ' . $msg); return; }
    error_log('[attributes] ' . $msg);
}

function load_all_attributes(): array {
    global $conn;
    $r = $conn->query("SELECT * FROM campaign_attributes");
    $rows = [];
    while ($r && $row = $r->fetch_assoc()) $rows[] = $row;
    return $rows;
}

/**
 * @param array $attributes    rows from load_all_attributes()
 * @param array $recipientRows rows from email_campaign_recipients (must have 'email', 'user_id')
 * @return array email(lowercase) => ['[NAME]' => value, ...] — ready to merge straight
 *               into substitute_merge_tags()'s $extraTokens argument.
 */
function resolve_attribute_values_batch(array $attributes, array $recipientRows): array {
    global $conn;
    if (!$attributes || !$recipientRows) return [];

    $emails = array_values(array_unique(array_map(fn($r) => strtolower($r['email']), $recipientRows)));
    $userIds = array_values(array_unique(array_filter(array_map(fn($r) => (int)($r['user_id'] ?? 0), $recipientRows))));
    // email(lowercase) -> user_id, so a 'user_id'-joined attribute can still be resolved
    // per-email even though the lookup itself runs against user_id.
    $userIdByEmail = [];
    foreach ($recipientRows as $r) {
        if (!empty($r['user_id'])) $userIdByEmail[strtolower($r['email'])] = (int)$r['user_id'];
    }

    $out = []; // email -> [token => value]
    attr_resolve_log('batch start — recipients=' . json_encode(array_map(fn($r) => ['email' => $r['email'] ?? null, 'user_id' => $r['user_id'] ?? null], $recipientRows))
        . ', resolved emails=' . json_encode($emails) . ', resolved user_ids=' . json_encode($userIds));

    foreach ($attributes as $attr) {
        // Attributes use [NAME] bracket tokens — deliberately different from the fixed
        // identity/exam XX_..._XX tags (MergeTags.php), per explicit request.
        $token = '[' . $attr['name'] . ']';

        if ($attr['category'] === 'custom') {
            if (!$emails) continue;
            // No LOWER()/COLLATE wrapping on the `email` column here — these VARCHAR columns
            // already use a case-insensitive (_ci) collation, so a plain `email IN (...)`
            // already matches regardless of case AND keeps the index usable (wrapping the
            // column in a function defeats it — the exact mistake that caused a 9s page load
            // earlier this session).
            $col = attribute_column_name($attr['name']);
            $emailList = implode(',', array_map(fn($e) => "'" . $conn->real_escape_string($e) . "'", $emails));
            $sql = "SELECT email, `$col` AS val FROM campaign_attribute_data WHERE email IN ($emailList)";
            $r = $conn->query($sql);
            if (!$r) { attr_resolve_log("attribute {$attr['name']} (custom): QUERY FAILED — $sql — " . $conn->error); continue; }
            $byEmail = [];
            while ($row = $r->fetch_assoc()) $byEmail[strtolower($row['email'])] = $row['val'];
            attr_resolve_log("attribute {$attr['name']} (custom): sql=[$sql] rows found=" . count($byEmail));
            foreach ($emails as $e) {
                $out[$e][$token] = (array_key_exists($e, $byEmail) && $byEmail[$e] !== null) ? $byEmail[$e] : ($attr['default_value'] ?? '');
            }
            continue;
        }

        // Mapped ('system') attribute — live lookup against its source table.
        $db = $attr['mapped_db']; $table = $attr['mapped_table']; $col = $attr['mapped_column']; $joinCol = $attr['mapped_join_col'];
        if (!$db || !$table || !$col || !$joinCol) {
            attr_resolve_log("attribute {$attr['name']} (id={$attr['id']}): SKIPPED — missing mapped_db/table/column/join_col (db=" . var_export($db, true) . ", table=" . var_export($table, true) . ", col=" . var_export($col, true) . ", joinCol=" . var_export($joinCol, true) . ")");
            continue;
        }
        $qualified = "`$db`.`$table`";

        if ($joinCol === 'user_id') {
            if (!$userIds) {
                attr_resolve_log("attribute {$attr['name']}: no user_id available on any recipient in this batch — falling back to default_value for all");
                foreach ($emails as $e) $out[$e][$token] = $attr['default_value'] ?? '';
                continue;
            }
            $idList = implode(',', array_map('intval', $userIds));
            $sql = "SELECT user_id, `$col` AS val FROM $qualified WHERE user_id IN ($idList)";
            $r = $conn->query($sql);
            if (!$r) { attr_resolve_log("attribute {$attr['name']}: QUERY FAILED — $sql — " . $conn->error); continue; }
            $byUserId = [];
            while ($row = $r->fetch_assoc()) $byUserId[(int)$row['user_id']] = $row['val'];
            attr_resolve_log("attribute {$attr['name']}: sql=[$sql] rows found=" . count($byUserId) . ' -> ' . json_encode($byUserId));
            foreach ($emails as $e) {
                $uid = $userIdByEmail[$e] ?? null;
                $out[$e][$token] = ($uid !== null && array_key_exists($uid, $byUserId) && $byUserId[$uid] !== null)
                    ? $byUserId[$uid] : ($attr['default_value'] ?? '');
            }
        } else { // joinCol === 'email'
            $emailList = implode(',', array_map(fn($e) => "'" . $conn->real_escape_string($e) . "'", $emails));
            $sql = "SELECT email, `$col` AS val FROM $qualified WHERE email IN ($emailList)";
            $r = $conn->query($sql);
            if (!$r) { attr_resolve_log("attribute {$attr['name']}: QUERY FAILED — $sql — " . $conn->error); continue; }
            $byEmail = [];
            while ($row = $r->fetch_assoc()) $byEmail[strtolower($row['email'])] = $row['val'];
            attr_resolve_log("attribute {$attr['name']}: sql=[$sql] rows found=" . count($byEmail) . ' -> ' . json_encode($byEmail));
            foreach ($emails as $e) {
                $out[$e][$token] = (array_key_exists($e, $byEmail) && $byEmail[$e] !== null) ? $byEmail[$e] : ($attr['default_value'] ?? '');
            }
        }
    }

    attr_resolve_log('batch result -> ' . json_encode($out));
    return $out;
}

<?php
/*
 * Recomputes email_campaigns.conversion_count for every sent campaign that has
 * a goal event configured (draft.goal_event_name, picked in CampaignStepSetup.jsx's
 * EventDropdown — same ALL_EVENTS list Segments' event-based rules use). Reuses
 * $EVENT_SOURCE (table/user_col/date_col/where/join per event key), already
 * defined in netcore/lib/segment_sql.php, instead of inventing new event
 * plumbing. Hooked into campaign-send-worker.php's existing cron tick — no
 * separate cron job needed.
 *
 * Click-attributed: a recipient only counts as a conversion if they actually
 * clicked a tracked link from THIS campaign (first_clicked_at, set by
 * track-click.php) and the goal event then happened within goal_window_days
 * of that click — not just "received the campaign and happened to do the
 * event eventually". This is what proves the campaign actually drove the
 * action rather than coincidence.
 *
 * EXCEPTION — events listed in $LIVE_ATTRIBUTED_EVENTS below: for these,
 * attribution is decided live, at the moment the event happens, and logged
 * into ONE shared table, campaign_attributions (user_id, campaign_id, medium,
 * event_key, clicked_at, attributed_at) — see the record_conversion() helper
 * in the user-dashboard backend's functions.php, called from login.php
 * (signin), update_score_viewed.php (result_view), etc. That row only gets
 * written if the user's attribution cookie was still live (i.e. not cleared
 * by an intervening untracked visit) when the event fired — see
 * user_dashboard's src/utils/attribution.js. Counting is then a plain WHERE
 * match against campaign_attributions — one query works for every event
 * listed here, no per-event table/column plumbing needed.
 *
 * Live attribution is the STRICTER of the two, and that is the point. The
 * click-window method credits a campaign whenever an order merely happens to
 * fall inside the window — including when the visitor clicked the email, left,
 * and came back later on their own. The cookie is deleted the moment someone
 * arrives without a campaign_id, so requiring it means the campaign really did
 * carry the user into that action. course_purchase / payment_success were moved
 * here for exactly that reason; the Go payment service writes their rows (see
 * payment_api internal/service/order.go and internal/service/payment.go).
 */

/**
 * Event keys whose write path has been wired up to call record_conversion()
 * and log into campaign_attributions. Add an event here only once that write
 * path actually exists — until then leave it out so it keeps using the
 * click-window fallback below (which is not wrong, just less precise).
 */
$LIVE_ATTRIBUTED_EVENTS = ['signin', 'result_view', 'exam_success', 'course_purchase', 'payment_success',
                           'register', 'came_on_dashboard', 'visited_iap'];

/**
 * The same list, reachable as a function.
 *
 * $LIVE_ATTRIBUTED_EVENTS is a top-level variable, so it is only global when this file is
 * required from file scope. A require_once that happens to run inside a function body instead
 * lands it in that function's locals, and every later `global $LIVE_ATTRIBUTED_EVENTS` sees
 * nothing — silently, because an empty list just means "no event is live-attributed" and every
 * caller carries on with its fallback. That has cost real debugging time more than once.
 *
 * Functions have no such problem: once the file is included at all, this is callable from
 * anywhere. New callers should use it; the variable stays for the ones that already read it.
 */
function campaigns_live_attributed_events(): array {
    static $list = null;
    if ($list !== null) return $list;
    // Read through $GLOBALS rather than `global`, so this works even when the variable
    // landed somewhere unexpected and $GLOBALS is the only place left holding it.
    $v = $GLOBALS['LIVE_ATTRIBUTED_EVENTS'] ?? null;
    return $list = (is_array($v) && $v)
        ? $v
        : ['signin', 'result_view', 'exam_success', 'course_purchase', 'payment_success',
           'register', 'came_on_dashboard', 'visited_iap'];
}

/**
 * The goal-window clause for live-attributed events, shared by the counter and the
 * list so they can never disagree.
 *
 * A campaign_attributions row is only written when the visitor still had a live
 * attribution cookie, and that cookie's expiry is sized from the campaign's own
 * goal_window_days (track-click.php sends it as `attr_window`, user_dashboard's
 * src/utils/attribution.js sets the cookie with it). But a cookie expiry is a
 * CLIENT-side promise: the browser clock can be wrong, the cookie can be hand-edited,
 * and — the case that actually bites — a row written before that plumbing existed was
 * stamped under a flat 2-day cookie regardless of what the campaign asked for. So the
 * window is re-checked here against the timestamps we stored ourselves.
 *
 * Only the upper bound is enforced. attributed_at and clicked_at are written by
 * different machines (the Go payment API for course_purchase/payment_success, PHP for
 * the rest), so a second or two of skew can put attributed_at marginally BEFORE
 * clicked_at on a legitimate conversion — bounding the lower end would silently drop it.
 */
function conversion_live_window_sql(array $campaign, string $alias): string {
    $windowDays = (int)($campaign['goal_window_days'] ?: 2);
    $windowDays = max(1, min(90, $windowDays));
    // A NULL clicked_at means record_conversion() had no cookie timestamp to work from and
    // defaulted it to the write time; there is no window to check, so let the row stand
    // rather than dropping a conversion for missing metadata.
    return " AND ($alias.clicked_at IS NULL
                  OR $alias.attributed_at <= DATE_ADD($alias.clicked_at, INTERVAL $windowDays DAY))";
}

/**
 * Builds the SQL pieces that enumerate WHICH users converted for a campaign —
 * the same two mechanisms campaigns_recompute_conversions() counts, but
 * returning rows instead of a bare COUNT so the report page can list, search,
 * and export them. Returns null when the campaign has no goal (or an unknown
 * event key), so callers can render "no goal set" rather than an error.
 *
 * Deliberately avoids joining `users` into the click-attributed branch: several
 * $EVENT_SOURCE entries carry a `where` that references a bare `user_id`
 * (e.g. exam_reminder's "user_id IS NOT NULL"), which would become ambiguous
 * the moment a second table with that column joins in. Name/phone come from
 * correlated subqueries instead, and search uses an aliased EXISTS.
 */
function conversion_list_sql(array $campaign, string $search = ''): ?array {
    global $conn, $EVENT_SOURCE, $LIVE_ATTRIBUTED_EVENTS;

    $campaignId = (int)$campaign['id'];
    $eventKey   = (string)($campaign['goal_event_name'] ?? '');
    if ($eventKey === '') return null;

    $s        = $conn->real_escape_string($search);
    $hasQuery = $search !== '';

    if (in_array($eventKey, $LIVE_ATTRIBUTED_EVENTS, true)) {
        $ekE = $conn->real_escape_string($eventKey);
        $searchSql = $hasQuery
            ? " AND (u.email LIKE '%$s%' OR u.phone LIKE '%$s%'
                     OR CONCAT(COALESCE(u.fname,''),' ',COALESCE(u.lname,'')) LIKE '%$s%')"
            : '';
        // MUST stay identical to the window clause in campaigns_recompute_one() — if these two
        // ever drift, the Conversions tile and the list it links to report different numbers
        // for the same campaign, and there is nothing in the UI to say which one is lying.
        $windowSql = conversion_live_window_sql($campaign, 'ca');
        /*
         * medium='email' is REQUIRED, not decorative. campaign_attributions is shared with the
         * WhatsApp channel, whose campaign ids come from a different table and therefore overlap:
         * without this filter, WhatsApp campaign #11's conversions are counted as email campaign
         * #11's. Rows written before the WhatsApp channel existed are all email, and are
         * backfilled to 'email' by campaigns_ensure_schema().
         */
        $from = "FROM campaign_attributions ca
                 LEFT JOIN users u ON u.user_id = ca.user_id
                 WHERE ca.campaign_id=$campaignId AND ca.medium='email'
                   AND ca.event_key='$ekE'$windowSql$searchSql";
        return [
            'mode'   => 'live',
            'select' => "SELECT ca.user_id, u.email,
                                TRIM(CONCAT(COALESCE(u.fname,''),' ',COALESCE(u.lname,''))) AS name,
                                u.phone, ca.medium, ca.clicked_at, ca.attributed_at AS converted_at",
            'from'   => $from,
            'group'  => '',
            'order'  => ' ORDER BY ca.attributed_at DESC',
            'count'  => "SELECT COUNT(*) AS c $from",
        ];
    }

    $src = $EVENT_SOURCE[$eventKey] ?? null;
    if (!$src) return null;

    $windowDays = (int)($campaign['goal_window_days'] ?: 2);
    $join       = $src['join'] ?? '';
    $whereExtra = ($src['where'] ?? '') !== '' ? " AND ({$src['where']})" : '';
    $searchSql  = $hasQuery
        ? " AND (ecr.email LIKE '%$s%'
                 OR EXISTS (SELECT 1 FROM users us WHERE us.user_id = ecr.user_id
                            AND (us.phone LIKE '%$s%'
                                 OR CONCAT(COALESCE(us.fname,''),' ',COALESCE(us.lname,'')) LIKE '%$s%')))"
        : '';

    $from = "FROM email_campaign_recipients ecr
             INNER JOIN {$src['table']} $join
                     ON {$src['user_col']} = ecr.user_id
                    AND {$src['date_col']} BETWEEN ecr.first_clicked_at AND DATE_ADD(ecr.first_clicked_at, INTERVAL $windowDays DAY)
             WHERE ecr.campaign_id=$campaignId AND ecr.is_test=0
               AND ecr.user_id IS NOT NULL AND ecr.first_clicked_at IS NOT NULL
               $whereExtra$searchSql";

    return [
        'mode'   => 'click',
        'select' => "SELECT ecr.user_id, ecr.email,
                            (SELECT TRIM(CONCAT(COALESCE(un.fname,''),' ',COALESCE(un.lname,'')))
                               FROM users un WHERE un.user_id = ecr.user_id) AS name,
                            (SELECT up.phone FROM users up WHERE up.user_id = ecr.user_id) AS phone,
                            'email' AS medium, ecr.first_clicked_at AS clicked_at,
                            MIN({$src['date_col']}) AS converted_at",
        'from'   => $from,
        'group'  => ' GROUP BY ecr.user_id, ecr.email, ecr.first_clicked_at',
        'order'  => ' ORDER BY converted_at DESC',
        'count'  => "SELECT COUNT(DISTINCT ecr.user_id) AS c $from",
    ];
}

/**
 * The raw source rows behind one user's conversion — whatever columns that
 * event's table actually has, so "view detail" works for every event without
 * per-event column plumbing. Strips password-ish columns because `register`
 * and `signin` resolve to the `users` table itself.
 *
 * $from/$to bound the rows to the window THIS campaign actually earned. They
 * are not optional in practice: a user who buys twice, months apart, off two
 * different campaigns has two rows in payment_status, and without the bound
 * this listed both under whichever campaign you happened to be viewing —
 * making it look like one campaign drove a purchase that another one did.
 * Callers derive the window from the attribution row (live-attributed events)
 * or from first_clicked_at + goal_window_days (click-attributed ones), which
 * are the same windows the conversion was counted under in the first place.
 *
 * Passing null for either bound leaves that side open, which is what a caller
 * with no attribution row and no recorded click can honestly do.
 */
function conversion_user_events(string $eventKey, int $userId, ?string $from = null, ?string $to = null, int $limit = 25): array {
    global $conn, $EVENT_SOURCE;

    $src = $EVENT_SOURCE[$eventKey] ?? null;
    if (!$src || $userId <= 0) return [];

    $userCol = $src['user_col'];
    $userColQ = (strpos($userCol, '.') === false) ? "{$src['table']}.$userCol" : $userCol;
    $join       = $src['join'] ?? '';
    $whereExtra = ($src['where'] ?? '') !== '' ? " AND ({$src['where']})" : '';

    $dateBound = '';
    if ($from !== null && $from !== '') {
        $dateBound .= " AND {$src['date_col']} >= '" . $conn->real_escape_string($from) . "'";
    }
    if ($to !== null && $to !== '') {
        $dateBound .= " AND {$src['date_col']} <= '" . $conn->real_escape_string($to) . "'";
    }

    $r = $conn->query("SELECT * FROM {$src['table']} $join
                        WHERE $userColQ = $userId $whereExtra$dateBound
                        ORDER BY {$src['date_col']} DESC LIMIT $limit");
    $rows = [];
    while ($r && $row = $r->fetch_assoc()) $rows[] = conversion_strip_secrets($row);
    return $rows;
}

/**
 * The [from, to] window whose event rows belong to this campaign, as
 * conversion_user_events() expects them.
 *
 * Live-attributed: the sticker's own clicked_at → attributed_at. A tolerance is
 * added to the upper end because the two timestamps are written by different
 * machines — attributed_at by whichever service recorded the conversion (the Go
 * payment API for course_purchase/payment_success, PHP for the rest), the event
 * row by MySQL — so a few seconds of clock skew between them is normal and
 * would otherwise hide the very row the panel exists to show.
 *
 * Click-attributed: the same first_clicked_at + goal_window_days window that
 * conversion_list_sql() counts under, so the detail can never disagree with
 * the list that linked to it.
 */
function conversion_event_window(array $campaign, ?array $attribution, ?array $recipient): array {
    global $LIVE_ATTRIBUTED_EVENTS;

    $eventKey = (string)($campaign['goal_event_name'] ?? '');

    if (in_array($eventKey, $LIVE_ATTRIBUTED_EVENTS, true)) {
        if (!$attribution) return [null, null];
        $from = $attribution['clicked_at'] ?? null;
        $to   = !empty($attribution['attributed_at'])
              ? date('Y-m-d H:i:s', strtotime($attribution['attributed_at']) + 300)
              : null;
        return [$from, $to];
    }

    $clicked = $recipient['first_clicked_at'] ?? null;
    if (!$clicked) return [null, null];
    $windowDays = (int)($campaign['goal_window_days'] ?: 2);
    return [$clicked, date('Y-m-d H:i:s', strtotime($clicked) + $windowDays * 86400)];
}

/** Never let a password hash reach the report UI. */
function conversion_strip_secrets(array $row): array {
    foreach (array_keys($row) as $k) {
        if (stripos($k, 'password') !== false || stripos($k, 'token') !== false) unset($row[$k]);
    }
    return $row;
}

/**
 * Recomputes conversion_count for every 'sent', not-yet-finalized campaign
 * with a goal_event_name set. Bounded on purpose: a campaign is marked
 * conversion_finalized=1 (and skipped by the WHERE clause forever after) the
 * moment BOTH: (a) every recipient who has ever clicked has had their window
 * expire, AND (b) the campaign was sent long enough ago (30+ days) that a
 * genuinely new first-time click is no longer realistically expected. (b)
 * alone matters because a campaign with zero clicks so far would otherwise
 * look "no open windows" on day one and get finalized immediately, freezing
 * it at 0 even though someone could still open and click it tomorrow.
 * Without this finalization step at all, every goal-campaign ever sent would
 * get re-queried on every single cron tick forever, growing without bound as
 * campaign history piles up.
 */
function campaigns_recompute_conversions(): void {
    global $conn, $EVENT_SOURCE, $LIVE_ATTRIBUTED_EVENTS;
    if (!$conn || empty($EVENT_SOURCE)) return;

    $r = $conn->query("SELECT id, goal_event_name, goal_window_days, completed_at
                        FROM email_campaigns
                        WHERE status='sent' AND goal_event_name IS NOT NULL AND goal_event_name <> ''
                          AND conversion_finalized=0");
    $campaigns = [];
    while ($r && $row = $r->fetch_assoc()) $campaigns[] = $row;

    foreach ($campaigns as $campaign) {
        // mysqli runs in exception mode here, so a bad query THROWS rather than
        // returning false — which means the `if (!$res)` guards below never fire
        // and, without this catch, one malformed campaign query aborts the whole
        // sweep: every campaign after it silently stops being recomputed, with
        // nothing in the log to say why. Contain the failure to its own campaign
        // and write down what broke.
        try {
            campaigns_recompute_one($campaign);
        } catch (\Throwable $e) {
            if (function_exists('campaign_log')) {
                campaign_log("conversions FAILED for campaign #{$campaign['id']} (goal={$campaign['goal_event_name']}) — " . $e->getMessage());
            }
        }
    }
}

/** One campaign's recompute — see campaigns_recompute_conversions() for the why. */
function campaigns_recompute_one(array $campaign): void {
    global $conn, $EVENT_SOURCE, $LIVE_ATTRIBUTED_EVENTS;

    $campaignId = (int)$campaign['id'];
    $eventKey   = $campaign['goal_event_name'];

    // Fast path: attribution was already decided live (click + event write
    // into campaign_attributions), so counting is a direct match — no
    // window arithmetic, nothing to guess.
    if (in_array($eventKey, $LIVE_ATTRIBUTED_EVENTS, true)) {
        $eventKeyE = $conn->real_escape_string($eventKey);
        $windowSql = conversion_live_window_sql($campaign, 'ca');
        // medium='email' — see the note in conversion_list_sql(): this table is shared with the
        // WhatsApp channel and campaign ids collide across the two.
        $cRes = $conn->query("SELECT COUNT(*) AS c FROM campaign_attributions ca
                               WHERE ca.campaign_id=$campaignId AND ca.medium='email'
                                 AND ca.event_key='$eventKeyE'$windowSql");
        $count = (int)$cRes->fetch_assoc()['c'];

        // No click-window to wait out — attribution is finalized at write time,
        // so once the campaign itself is old enough that no new send activity
        // is expected, stop rechecking it.
        $sentLongEnoughAgo = $campaign['completed_at'] && strtotime($campaign['completed_at']) < strtotime('-30 days');
        $conn->query("UPDATE email_campaigns SET conversion_count=$count"
            . ($sentLongEnoughAgo ? ', conversion_finalized=1' : '') . " WHERE id=$campaignId");
        if (function_exists('campaign_log')) {
            campaign_log("conversions recomputed for campaign #$campaignId (goal=$eventKey, directly-attributed) -> $count"
                . ($sentLongEnoughAgo ? ' (finalized)' : ''));
        }
        return;
    }

    $src = $EVENT_SOURCE[$eventKey] ?? null;
    if (!$src) {
        if (function_exists('campaign_log')) {
            campaign_log("conversions SKIPPED for campaign #$campaignId — goal '$eventKey' has no \$EVENT_SOURCE entry");
        }
        return;
    }

    $windowDays = (int)($campaign['goal_window_days'] ?: 2);
    $join = $src['join'] ?? '';
    $whereExtra = $src['where'] !== '' ? " AND ({$src['where']})" : '';

    $sql = "SELECT COUNT(DISTINCT ecr.user_id) AS c
            FROM email_campaign_recipients ecr
            INNER JOIN {$src['table']} $join
                    ON {$src['user_col']} = ecr.user_id
                   AND {$src['date_col']} BETWEEN ecr.first_clicked_at AND DATE_ADD(ecr.first_clicked_at, INTERVAL $windowDays DAY)
            WHERE ecr.campaign_id=$campaignId AND ecr.is_test=0
              AND ecr.user_id IS NOT NULL AND ecr.first_clicked_at IS NOT NULL
              $whereExtra";
    $cRes = $conn->query($sql);
    $count = (int)$cRes->fetch_assoc()['c'];

    // Still-open window check: any recipient whose click hasn't aged past the window yet?
    $openRes = $conn->query("SELECT 1 FROM email_campaign_recipients
                              WHERE campaign_id=$campaignId AND is_test=0 AND first_clicked_at IS NOT NULL
                                AND DATE_ADD(first_clicked_at, INTERVAL $windowDays DAY) >= NOW()
                              LIMIT 1");
    $anyOpenClickWindow = $openRes && $openRes->num_rows > 0;
    // Give up expecting a genuinely NEW first click after 30 days since send — before that,
    // always keep rechecking even with zero clicks so far, since someone could still open it.
    $sentLongEnoughAgo = $campaign['completed_at'] && strtotime($campaign['completed_at']) < strtotime('-30 days');
    $stillOpen = $anyOpenClickWindow || !$sentLongEnoughAgo;

    $conn->query("UPDATE email_campaigns SET conversion_count=$count"
        . ($stillOpen ? '' : ', conversion_finalized=1') . " WHERE id=$campaignId");
    if (function_exists('campaign_log')) {
        campaign_log("conversions recomputed for campaign #$campaignId (goal={$campaign['goal_event_name']}, click-attributed) -> $count"
            . ($stillOpen ? '' : ' (finalized — no more open click-windows)'));
    }
}

<?php
require_once __DIR__ . '/AwsSigV4.php';
require_once __DIR__ . '/SesTransport.php';

/*
 * Amazon SES account-level API calls — the SES counterpart of SendGridSuppressionClient.php
 * and ElasticEmailSuppressionClient.php.
 *
 * Two jobs, same as the other two clients:
 *   - ses_add_global_suppression()    — an address landed on OUR Blocklist, so put it on SES's
 *     account suppression list too. Without this, SES itself would still happily accept and
 *     deliver to an address we have decided never to mail again, and only our own
 *     AudienceResolver filtering would be standing in the way.
 *   - ses_remove_all_suppressions()   — the reverse, so removing an address from our Blocklist
 *     actually makes it deliverable again. This matters more on SES than on the other two
 *     providers: SES adds hard bounces and complaints to its suppression list AUTOMATICALLY and
 *     permanently, so without an explicit delete a recovered address stays undeliverable
 *     forever no matter what our own tables say.
 *
 * It also hosts ses_api_request(), which domains.php uses for domain identities and
 * settings.php uses for the sandbox/quota readout — the same arrangement as
 * sendgrid_api_request() living in SendGridSuppressionClient.php.
 *
 * !! MODE NOTE: every function here needs an IAM ACCESS KEY + SECRET ACCESS KEY (auth_mode
 * 'api'). With SMTP-only credentials there is no way to sign an AWS API request at all — the
 * SMTP password cannot be converted back into a secret key — so these calls no-op with a log
 * line instead of failing. Sending itself is unaffected; what is lost is suppression sync,
 * domain automation and the quota check.
 */

function ses_settings_row(): ?array {
    global $conn;
    $r = $conn->query("SELECT * FROM email_esp_settings WHERE provider='ses' LIMIT 1");
    $row = $r ? $r->fetch_assoc() : null;
    return $row ?: null;
}

/**
 * The signing credentials, or null when SES cannot be called via its API.
 * @return array{key: string, secret: string, region: string}|null
 */
function ses_api_creds(): ?array {
    $row = ses_settings_row();
    if (!$row) return null;

    $mode = strtolower(trim((string)($row['auth_mode'] ?? 'api')));
    if ($mode === 'smtp') return null;   // see the MODE NOTE above

    $key    = trim((string)($row['api_key'] ?? ''));
    $secret = trim((string)($row['api_secret'] ?? ''));
    // The placeholders seeded by campaigns_ensure_schema() are present but are not credentials.
    if ($key === '' || $secret === '') return null;
    if ($key === SesTransport::DUMMY_KEY || $secret === SesTransport::DUMMY_SECRET) return null;

    return [
        'key'    => $key,
        'secret' => $secret,
        'region' => trim((string)($row['aws_region'] ?? '')) ?: 'ap-south-1',
    ];
}

/**
 * One signed SES v2 API call.
 *
 * @param string $rawPath UNENCODED path — pass the bare email address in suppression paths and
 *                        let the signer encode it. Encoding it here would double-encode.
 * @param mixed  $body    JSON-encodable payload, or null for GET/DELETE
 * @return array{ok: bool, status?: int, body?: string, error?: string}
 */
function ses_api_request(string $method, string $rawPath, $body = null, array $query = []): array {
    $creds = ses_api_creds();
    if (!$creds) {
        return ['ok' => false, 'error' => 'Amazon SES API credentials not configured '
                                        . '(this call needs auth mode "API" with an access key id and secret access key)'];
    }

    // Signed over the EXACT bytes that go on the wire — re-encoding after signing is the
    // classic way to earn a 403 SignatureDoesNotMatch.
    $payload = $body === null ? '' : json_encode($body);
    $req = aws_sigv4_request($method, $creds['region'], 'ses', $rawPath, $query, $payload,
                             $creds['key'], $creds['secret'],
                             'email.' . $creds['region'] . '.amazonaws.com');

    $ch = curl_init($req['url']);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_CUSTOMREQUEST  => strtoupper($method),
        CURLOPT_HTTPHEADER     => $req['headers'],
        CURLOPT_TIMEOUT        => 15,
    ]);
    if ($payload !== '') curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
    $respBody = curl_exec($ch);
    $status   = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $curlErr  = curl_error($ch);
    curl_close($ch);

    if ($curlErr !== '') return ['ok' => false, 'error' => "Network error: $curlErr"];
    if ($status >= 200 && $status < 300) return ['ok' => true, 'status' => $status, 'body' => (string)$respBody];

    // SES puts the human-readable reason in {"message": "..."}; fall back to the raw body so a
    // throttling or permissions response is never reduced to a bare status code.
    $decoded = json_decode((string)$respBody, true);
    $msg = is_array($decoded) ? (string)($decoded['message'] ?? ($decoded['Message'] ?? '')) : '';
    return ['ok' => false, 'status' => $status, 'error' => $msg !== '' ? $msg : (string)$respBody];
}

function ses_suppression_log(string $msg): void {
    if (function_exists('campaign_log')) { campaign_log('[ses-suppression] ' . $msg); return; }
    error_log('[ses-suppression] ' . $msg);
}

/** Adds $email to SES's account-level suppression list. Reason COMPLAINT is the stronger of
 *  the two values SES accepts and is the honest one for a Blocklist entry — the address is
 *  suppressed because we were told to stop, not because a mail server rejected it. */
function ses_add_global_suppression(string $email): void {
    if (!ses_api_creds()) return;
    $res = ses_api_request('PUT', '/v2/email/suppression/addresses/' . $email, ['Reason' => 'COMPLAINT']);
    ses_suppression_log("add suppression for $email -> " . ($res['ok'] ? 'ok' : 'FAILED: ' . ($res['error'] ?? '')));
}

/** Removes $email from SES's suppression list. One call clears it regardless of whether it was
 *  suppressed for a bounce, a complaint, or by us — SES keeps a single list, unlike SendGrid's
 *  four. A 404 means it was not suppressed in the first place: a harmless no-op. */
function ses_remove_all_suppressions(string $email): void {
    if (!ses_api_creds()) return;
    $res = ses_api_request('DELETE', '/v2/email/suppression/addresses/' . $email);
    ses_suppression_log("remove suppression for $email -> " . ($res['ok'] ? 'ok' : ($res['status'] ?? '?') . ' ' . ($res['error'] ?? '')));
}

/**
 * Account health, for the "Check SES account" button in Settings.
 *
 * This exists because the SES sandbox is the single most common reason a correctly configured
 * SES integration appears broken: in the sandbox every send to an unverified address is
 * rejected with "Email address is not verified", the daily cap is 200 and the rate is 1/s. That
 * is indistinguishable, from the campaign UI, from a bad key — so it is worth being able to
 * read the account's real state in one click instead of inferring it from failures.
 *
 * @return array{ok: bool, error?: string, sandbox?: bool, ...}
 */
function ses_account_status(): array {
    $creds = ses_api_creds();
    if (!$creds) {
        $row = ses_settings_row();
        $mode = strtolower(trim((string)($row['auth_mode'] ?? 'api')));
        return ['ok' => false, 'error' => $mode === 'smtp'
            ? 'Auth mode is SMTP, which cannot call the SES API. Switch to API mode (with an '
            . 'access key id + secret access key) to read quota and sandbox status.'
            : 'Paste a real access key id and secret access key first.'];
    }

    $res = ses_api_request('GET', '/v2/email/account');
    if (!$res['ok']) return ['ok' => false, 'error' => (string)($res['error'] ?? 'SES rejected the request')];

    $body  = json_decode((string)$res['body'], true) ?: [];
    $quota = (array)($body['SendQuota'] ?? []);
    $production = !empty($body['ProductionAccessEnabled']);

    return [
        'ok'                => true,
        'region'            => $creds['region'],
        'sandbox'           => !$production,
        'sending_enabled'   => !empty($body['SendingEnabled']),
        'enforcement'       => (string)($body['EnforcementStatus'] ?? ''),
        'max_24_hour_send'  => (float)($quota['Max24HourSend'] ?? 0),
        'max_send_rate'     => (float)($quota['MaxSendRate'] ?? 0),
        'sent_last_24_hours' => (float)($quota['SentLast24Hours'] ?? 0),
    ];
}

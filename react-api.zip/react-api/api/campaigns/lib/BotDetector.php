<?php
/*
 * Tells a genuine human open/click apart from a machine fetch of the same URL.
 *
 * The problem this exists to solve: an open "event" is just somebody requesting a
 * 1x1 GIF, and plenty of things request that GIF without a human ever having looked
 * at the email —
 *
 *   - Apple Mail Privacy Protection (iOS 15+ / macOS Monterey+) pre-fetches EVERY
 *     remote image the moment a message is DELIVERED, whether or not it is ever
 *     opened. This is by far the largest source of phantom opens today.
 *   - Corporate mail gateways (Proofpoint, Mimecast, Barracuda, Defender…) fetch
 *     every URL in a message, including the pixel, as part of scanning it.
 *   - Link unfurlers and generic HTTP clients hit anything they are handed.
 *
 * The one thing that must NOT be filtered is Gmail's image proxy. Gmail routes every
 * image through ggpht.com/GoogleImageProxy — including on a completely genuine human
 * open — so treating it as a bot would delete most real opens for a Gmail-heavy
 * audience. It is allowlisted first, before every other rule, for exactly that reason.
 *
 * Nothing here silently disappears: callers log a filtered hit as an 'open_bot' /
 * 'click_bot' event with the reason in `meta`, so the filtering is auditable and a
 * bad rule can be spotted rather than quietly eating real engagement.
 */

// A fetch landing within this many seconds of the ESP accepting the send is a machine,
// not a person: the mail still has to be delivered, and nobody receives, notices and
// opens a marketing email in single-digit seconds. This is the catch-all that gets
// scanners which don't identify themselves in the User-Agent.
if (!defined('TRACKING_MIN_SECONDS_AFTER_SEND')) define('TRACKING_MIN_SECONDS_AFTER_SEND', 10);

// Repeat hits for the same recipient inside this window collapse into one. The pixel is
// served no-store (so mail clients don't cache away a genuine second open), which means a
// client re-rendering the message — scrolling it in and out of a preview pane — re-requests
// it each time. Those are the same single open, not several.
if (!defined('TRACKING_DEDUPE_SECONDS')) define('TRACKING_DEDUPE_SECONDS', 10);

/**
 * Lower-cased substrings that identify an automated fetcher.
 *
 * Deliberately NOT in this list:
 *   - 'googleimageproxy' — allowlisted above; it is Gmail's real open path.
 *   - 'whatsapp' — WhatsApp's IN-APP BROWSER puts "WhatsApp" in its User-Agent, so
 *     matching it would throw away real clicks from anyone who opened the link from a
 *     WhatsApp share. The link-preview fetcher is not worth that trade.
 */
function tracking_bot_user_agent_patterns(): array {
    return [
        // Security / mail-scanning gateways that fetch every URL in a message on arrival.
        'barracuda', 'proofpoint', 'mimecast', 'messagelabs', 'symantec', 'forcepoint',
        'sophos', 'trendmicro', 'fireeye', 'mcafee', 'ironport', 'spamtitan', 'mailscanner',
        'zscaler', 'netskope', 'cloudmark', 'safelinks', 'bitdefender', 'kaspersky',
        // Generic HTTP clients and crawlers — never a mail client rendering a message.
        'bot', 'crawler', 'spider', 'curl/', 'wget', 'python-requests', 'python-urllib',
        'go-http-client', 'java/', 'okhttp', 'libwww', 'httpclient', 'headlesschrome',
        'phantomjs', 'axios/', 'node-fetch', 'guzzle', 'apache-httpclient',
        // Link unfurlers.
        'slackbot', 'telegrambot', 'discordbot', 'linkedinbot', 'skypeuripreview',
        'bingpreview', 'facebookexternalhit',
    ];
}

/**
 * Returns a short reason string when this request should NOT count as human
 * engagement, or null when it should.
 *
 * @param string   $userAgent        raw HTTP_USER_AGENT
 * @param int|null $secondsSinceSent seconds between the recipient's sent_at and now;
 *                                   null when sent_at is unknown, which skips that rule
 * @param string   $method           HTTP request method
 */
function tracking_machine_reason(string $userAgent, ?int $secondsSinceSent, string $method = 'GET'): ?string {
    $ua = strtolower(trim($userAgent));

    // FIRST, before anything else — see the file header.
    if (strpos($ua, 'googleimageproxy') !== false) return null;

    // Scanners commonly probe with HEAD; a mail client rendering an <img> always GETs.
    if (strtoupper($method) !== 'GET') return 'non_get_request';

    if ($ua === '') return 'empty_user_agent';

    // Apple Mail Privacy Protection's proxy sends a bare WebKit string — no Version/ and
    // no Safari/ token after "(KHTML, like Gecko)", which no real Safari ever omits.
    if (preg_match('#^mozilla/5\.0 \(macintosh; intel mac os x[^)]*\) applewebkit/[\d.]+ \(khtml, like gecko\)$#', $ua)) {
        return 'apple_mail_privacy_protection';
    }

    foreach (tracking_bot_user_agent_patterns() as $needle) {
        if (strpos($ua, $needle) !== false) return 'bot_ua:' . $needle;
    }

    /*
     * A User-Agent with no platform token at all — no parenthesised "(Windows NT…)",
     * "(Macintosh…)", "(iPhone…)", "(X11…)" — is not a client that renders HTML mail.
     *
     * Every real browser and mail client states its platform in brackets; it is the oldest and
     * most universal convention in the header. Scripted fetchers, privacy proxies and scanners
     * that want to look "browser-ish" without impersonating one routinely send the bare prefix
     * `Mozilla/5.0` and nothing else, and that string matched none of the named patterns above:
     * it contains no vendor name, is not empty, and is not Apple's MPP signature. So it sailed
     * through as a genuine human open and fired an engagement trigger for somebody who never
     * touched the message.
     *
     * Checked AFTER the named patterns so a recognised fetcher still reports its own name in the
     * reason, and after the Gmail allowlist at the top, which returns before any of this.
     */
    if (strpos($ua, '(') === false) return 'degenerate_user_agent';

    // Guard against a negative value from clock skew between PHP and MySQL — that is not
    // evidence of a bot, so only a genuinely-too-soon positive gap counts.
    if ($secondsSinceSent !== null && $secondsSinceSent >= 0 && $secondsSinceSent < TRACKING_MIN_SECONDS_AFTER_SEND) {
        return 'too_soon_after_send';
    }

    return null;
}

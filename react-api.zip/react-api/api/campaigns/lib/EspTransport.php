<?php
/*
 * Pluggable email-sending transport interface. Both the SendGrid and Elastic Email
 * implementations are used purely as a "delivery engine" — recipient lists,
 * personalization, templates and ALL tracking (open/click) are owned by our
 * own tables regardless of which transport is active, so switching providers
 * never changes what the user sees in the Campaigns UI.
 *
 * The interface is deliberately split into buildRequest() / parseResponse() rather than
 * only sendEmail(). Sending one email at a time was the throughput ceiling (one blocking
 * HTTP round-trip per recipient — ~50 emails/minute), and the fix is to keep many requests
 * in flight at once. That requires the HTTP call to be separable from the provider-specific
 * payload and error handling: lib/ParallelSender.php owns the concurrency and knows nothing
 * about providers, while each transport keeps owning its own payload shape and error
 * vocabulary. sendEmail() remains as the single-shot path (used by "Send Test Email") and is
 * just build → execute → parse.
 */
interface EspTransport {
    /**
     * @param string $to          recipient email
     * @param string $subject     fully merge-tag-resolved subject
     * @param string $html        fully merge-tag-resolved + tracking-injected HTML body
     * @param string $fromName
     * @param string $fromEmail
     * @param string|null $replyTo
     * @param string|null $rid    our internal recipient tracking id — passed through as a
     *                            custom arg/header where the provider supports it, so async
     *                            webhook events (bounce/unsubscribe) can be correlated back.
     * @param array $attachments  array of ['filename'=>string, 'content'=>base64 string, 'type'=>mime string],
     *                            pre-loaded ONCE per worker tick by lib/SendWorker.php (not re-read from
     *                            disk per recipient) — see load_campaign_attachments().
     * @return array{ok: bool, message_id: ?string, error: ?string, retryable: bool}
     */
    public function sendEmail(string $to, string $subject, string $html, string $fromName, string $fromEmail, ?string $replyTo, ?string $rid, array $attachments = []): array;

    /**
     * The HTTP request for one send, WITHOUT performing it — so a caller can hand many of
     * these to curl_multi at once.
     *
     * @return array{url: string, headers: string[], body: string}
     */
    public function buildRequest(string $to, string $subject, string $html, string $fromName, string $fromEmail, ?string $replyTo, ?string $rid, array $attachments = []): array;

    /**
     * Turns one raw HTTP outcome into the same result shape sendEmail() returns.
     *
     * `retryable` is the important field: it separates "this address is bad, stop trying"
     * (400/401/permanent) from "the provider is busy or briefly unreachable" (429, 5xx,
     * connection errors). Only the former should consume one of a recipient's 3 attempts —
     * without that distinction, a burst of 429s while running at high concurrency would
     * permanently fail thousands of perfectly deliverable addresses.
     *
     * @param int         $status     HTTP status (0 when the request never completed)
     * @param string|null $body       raw response body
     * @param string      $curlError  transport-level error, '' when none
     * @param string|null $rid        the send's tracking id, for providers that echo nothing better
     * @return array{ok: bool, message_id: ?string, error: ?string, retryable: bool}
     */
    public function parseResponse(int $status, ?string $body, string $curlError, ?string $rid): array;

    /** False when no real API key is configured yet — checked once per batch instead of per send. */
    public function isConfigured(): bool;
}

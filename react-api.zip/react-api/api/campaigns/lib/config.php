<?php
/*
 * Shared secret guarding the HTTP fallback path of campaign-send-worker.php
 * (the CLI-cron path doesn't need it — see that file). Change this if it
 * ever leaks; it's not a per-user credential, just a "this request is really
 * from our own cron/instant-kick" check.
 */
if (!defined('CRON_SECRET')) {
    define('CRON_SECRET', 'cw_9f2a7c4e1b8d6f3a0e5c2b9d7f4a1c8e6b3d0f9a2c7e4b1d8f5a2c9e6b3d0f7a');
}

/*
 * Send throughput. The old numbers were 50 recipients per cron tick, sent one at a time —
 * roughly 50 emails/minute, which is ~13 HOURS for a 40k audience. Almost all of that was
 * the CPU sitting idle waiting on one HTTP round-trip at a time.
 *
 * CAMPAIGN_SEND_CONCURRENCY is the real lever: that many sends are in flight at once via
 * curl_multi (see lib/ParallelSender.php). At ~300ms per request, 32 in flight is ~100
 * emails/second — 40k in about seven minutes; 64 roughly halves that again.
 *
 * Raising it is NOT free, and the ceiling is your ESP, not this code. Too high and the
 * provider starts answering 429; that no longer loses mail (retryable failures go back to
 * 'pending' without burning an attempt — see mark_recipients_failed_batch()), but it wastes
 * the run. Raise in steps and watch worker.log for 'rate-limited/retryable' lines.
 */
if (!defined('CAMPAIGN_SEND_CONCURRENCY')) define('CAMPAIGN_SEND_CONCURRENCY', 32);

/*
 * Amazon SES ceiling, applied on top of the value above (see TransportFactory::concurrencyFor).
 * SES is unlike the other two providers: it enforces a documented sends-PER-SECOND rate and
 * rejects everything over it instead of queueing, so the number here should track the account's
 * actual "Sending rate" from the SES console — 14/s is the AWS default once production access is
 * granted, and 1/s while the account is still in the sandbox.
 *
 * Raise this only after AWS raises the account's rate; going higher just converts throughput
 * into throttling errors (which are requeued, not lost, but the run achieves nothing). Settings
 * → Amazon SES → "Check SES account" reports the current rate.
 */
if (!defined('SES_MAX_CONCURRENCY')) define('SES_MAX_CONCURRENCY', 14);

// Recipients claimed from the queue per batch. Wants to be comfortably larger than the
// concurrency so the in-flight window stays saturated, but not so large that one crashed
// run leaves a huge block stuck in 'processing'.
if (!defined('CAMPAIGN_SEND_BATCH_SIZE')) define('CAMPAIGN_SEND_BATCH_SIZE', 500);

// How long one worker invocation keeps pulling batches before exiting. The flock() in
// campaign-send-worker.php means overlapping cron ticks simply no-op while this runs, so a
// long run is safe — it just makes the next few ticks idle. This is what removes the old
// one-batch-per-minute cron granularity.
if (!defined('WORKER_MAX_RUNTIME_SECONDS')) define('WORKER_MAX_RUNTIME_SECONDS', 240);

// Pause after a batch that hit provider rate-limiting, to let the ESP's window reset
// instead of immediately hammering it again with the same concurrency.
if (!defined('CAMPAIGN_RATE_LIMIT_BACKOFF_SECONDS')) define('CAMPAIGN_RATE_LIMIT_BACKOFF_SECONDS', 2);

// Where uploaded campaign attachments are stored on disk, one subfolder per campaign id.
if (!defined('CAMPAIGN_ATTACHMENTS_DIR')) {
    define('CAMPAIGN_ATTACHMENTS_DIR', __DIR__ . '/../uploads/campaign_attachments');
}
define('CAMPAIGN_ATTACHMENT_MAX_FILE_BYTES', 5 * 1024 * 1024);   // 5MB per file
define('CAMPAIGN_ATTACHMENT_MAX_TOTAL_BYTES', 15 * 1024 * 1024); // 15MB per campaign
define('CAMPAIGN_ATTACHMENT_ALLOWED_EXT', ['pdf', 'doc', 'docx', 'xls', 'xlsx', 'jpg', 'jpeg', 'png', 'gif', 'txt', 'csv', 'zip']);

// Every campaign-send-worker.php run (cron tick or instant "Send Now" kick) appends
// one line per event here — lets the admin verify "did cron actually run" and "how
// many recipients did it find" without SSH/DB access.
if (!defined('WORKER_LOG_PATH')) {
    define('WORKER_LOG_PATH', __DIR__ . '/../worker.log');
}

// Images dropped/pasted into the template rich-text editor — MUST be publicly reachable
// (unlike attachments above) since recipients' mail clients fetch these URLs directly.
if (!defined('TEMPLATE_IMAGES_DIR')) {
    define('TEMPLATE_IMAGES_DIR', __DIR__ . '/../uploads/template_images');
}
if (!defined('TEMPLATE_IMAGES_PUBLIC_URL')) {
    define('TEMPLATE_IMAGES_PUBLIC_URL', 'https://cit3.internshipstudio.com/admin/react-api/api/campaigns/uploads/template_images');
}
define('TEMPLATE_IMAGE_MAX_BYTES', 3 * 1024 * 1024); // 3MB per image
define('TEMPLATE_IMAGE_ALLOWED_EXT', ['jpg', 'jpeg', 'png', 'gif', 'webp']);

<?php
/*
 * Personalization token substitution for the campaign builder.
 *
 * Reuses the site-wide `XX_..._XX` token convention already used by
 * src/pages/communication/EmailTemplates.jsx's TinyMCE mergetags plugin, but
 * scoped to the 5 person-identity tags — the only ones resolvable in a
 * generic campaign context (the other ~14 tags in that list are contextual
 * to tickets/exams/internship batches and don't apply here).
 *
 * This is a NEW implementation, not a call into the legacy external
 * sendTemplateEmail()/helper.php — that black-box helper has no hook for
 * injecting tracking pixels/links before send, which this pipeline needs.
 */

const CAMPAIGN_MERGE_TAGS = [
    'XX_USER_FNAME_XX' => 'first_name',
    'XX_USER_LNAME_XX' => 'last_name',
    'XX_USER_NAME_XX'  => 'full_name',   // derived: "first_name last_name"
    'XX_USER_EMAIL_XX' => 'email',
    'XX_USER_PHONE_XX' => 'phone',
    // Exam-result tags — only populated when the campaign has an exam_cit_version set (see
    // resolve_exam_data() below) AND the recipient actually attempted that specific exam.
    // Left blank otherwise (e.g. test sends, or a recipient who never took that exam).
    'XX_EXAM_NAME_XX'       => 'exam_name',
    'XX_EXAM_SCORE_XX'      => 'exam_score',
    'XX_EXAM_PERCENTAGE_XX' => 'exam_percentage',
    'XX_EXAM_RANK_XX'       => 'exam_rank',
    'XX_EXAM_STATUS_XX'     => 'exam_status',
    'XX_EXAM_DATE_XX'       => 'exam_date',
];

/**
 * @param string $text          subject / preheader / sender_name / html body — may contain XX_..._XX tokens
 * @param array  $recipient     a row from email_campaign_recipients, optionally merged with
 *                               resolve_exam_data()'s output (or an equivalent array for test sends)
 * @param array  $extraTokens   already-built '[NAME]' => value pairs for this recipient's
 *                               Customer Attributes (see AttributeResolver.php's
 *                               resolve_attribute_values_batch()) — purely additive, never
 *                               overrides the 5 identity + 6 exam tags above. Deliberately a
 *                               different bracket syntax from XX_..._XX (per explicit
 *                               request), so this function's own short-circuit below must
 *                               check for BOTH — a template using only attribute tokens has
 *                               no "XX_" substring in it at all.
 */
function substitute_merge_tags(string $text, array $recipient, array $extraTokens = []): string {
    if ($text === '' || (strpos($text, 'XX_') === false && strpos($text, '[') === false)) return $text;

    $firstName = trim((string)($recipient['first_name'] ?? ''));
    $lastName  = trim((string)($recipient['last_name'] ?? ''));
    $values = [
        'XX_USER_FNAME_XX' => $firstName,
        'XX_USER_LNAME_XX' => $lastName,
        'XX_USER_NAME_XX'  => trim("$firstName $lastName"),
        'XX_USER_EMAIL_XX' => (string)($recipient['email'] ?? ''),
        'XX_USER_PHONE_XX' => (string)($recipient['phone'] ?? ''),
        'XX_EXAM_NAME_XX'       => (string)($recipient['exam_name'] ?? ''),
        'XX_EXAM_SCORE_XX'      => (string)($recipient['exam_score'] ?? ''),
        'XX_EXAM_PERCENTAGE_XX' => (string)($recipient['exam_percentage'] ?? ''),
        'XX_EXAM_RANK_XX'       => (string)($recipient['exam_rank'] ?? ''),
        'XX_EXAM_STATUS_XX'     => (string)($recipient['exam_status'] ?? ''),
        'XX_EXAM_DATE_XX'       => (string)($recipient['exam_date'] ?? ''),
    ];
    $values = array_merge($values, $extraTokens);

    return strtr($text, $values);
}

/**
 * Splices the (already merge-tag-substituted) preheader text into the outgoing HTML as
 * the standard hidden-preheader snippet — most inbox providers show whatever plain text
 * comes right after <body> next to the subject line in the inbox list, so this has to
 * physically be part of the HTML, not just a value stored on the campaign. Padded with
 * non-breaking spaces + zero-width joiners so an inbox provider doesn't fall through to
 * showing real body text after a short preheader ends.
 */
function inject_preheader(string $html, string $preheader): string {
    $preheader = trim($preheader);
    if ($preheader === '') return $html;

    $hidden = '<div style="display:none;font-size:1px;line-height:1px;max-height:0;max-width:0;opacity:0;overflow:hidden;mso-hide:all;">'
        . htmlspecialchars($preheader, ENT_QUOTES, 'UTF-8')
        . str_repeat('&nbsp;&zwnj;', 20)
        . '</div>';

    if (preg_match('/<body[^>]*>/i', $html, $m, PREG_OFFSET_CAPTURE)) {
        $pos = $m[0][1] + strlen($m[0][0]);
        return substr($html, 0, $pos) . $hidden . substr($html, $pos);
    }
    return $hidden . $html;
}

/**
 * Looks up one recipient's result for a specific exam (a cit_version string, e.g. "CIT 168")
 * and returns the exam_* fields substitute_merge_tags() reads, or null if that recipient
 * never attempted this particular exam. Rank has to be computed across every OTHER user who
 * took the SAME exam — filtering cit_results down to one user first would make everyone rank
 * #1 — so the ranking is done in a subquery over the whole exam before picking this user's row
 * out of it, mirroring api/exam/results.php's existing RANK() OVER (...) pattern.
 */
function resolve_exam_data(?int $userId, ?string $citVersion): ?array {
    global $conn;
    if (!$userId || !$citVersion) return null;

    $citE = $conn->real_escape_string($citVersion);
    $sql = "SELECT sub.score, sub.timestamp, sub.rnk
            FROM (
                SELECT cr.user_id, cr.score, cr.timestamp,
                       RANK() OVER (ORDER BY cr.score DESC) AS rnk
                FROM cit_results cr
                WHERE cr.cit_version = '$citE'
            ) AS sub
            WHERE sub.user_id = " . (int)$userId . "
            ORDER BY sub.timestamp DESC
            LIMIT 1";
    $r = $conn->query($sql);
    $row = $r ? $r->fetch_assoc() : null;
    if (!$row) return null;

    // score is already the 0-100 value used app-wide for the pass/fail threshold (see
    // api/exam/results.php and netcore/lib/segment_sql.php's "payment_success"/"exam_success"
    // event, both comparing cr.score >= 60) — so it doubles as the percentage directly.
    $score = (float)($row['score'] ?? 0);
    return [
        'exam_name'       => $citVersion,
        'exam_score'      => (string)$row['score'],
        'exam_percentage' => (string)$row['score'],
        'exam_rank'       => (string)$row['rnk'],
        'exam_status'     => $score >= 60 ? 'Pass' : 'Fail',
        'exam_date'       => $row['timestamp'] ? date('d M Y', strtotime($row['timestamp'])) : '',
    ];
}

<?php
require_once __DIR__ . '/EspTransport.php';
require_once __DIR__ . '/ParallelSender.php';
require_once __DIR__ . '/AwsSigV4.php';

/*
 * Amazon SES transport — the third delivery engine alongside SendGridTransport and
 * ElasticEmailTransport, and identical to them in role: recipient lists, personalisation,
 * templates and ALL open/click tracking stay first-party (our own pixel + redirect, see
 * lib/TrackingRewriter.php), so a campaign looks the same in the UI whichever one sent it.
 *
 * ── TWO AUTH MODES, because SES hands out two different kinds of credential ──────────────
 *
 * 'api'  — SES v2 REST API, POST https://email.<region>.amazonaws.com/v2/email/outbound-emails
 *          signed with AWS SigV4 (see lib/AwsSigV4.php). Needs an IAM ACCESS KEY ID plus its
 *          SECRET ACCESS KEY. This is the better mode and the one to prefer:
 *            · plain HTTPS, so it rides the existing curl_multi path in ParallelSender.php
 *              with zero special-casing — same throughput as SendGrid
 *            · returns a real MessageId per send, which is the correlation key SES puts on
 *              every bounce/complaint notification
 *            · the same credential unlocks the suppression list (SesSuppressionClient.php),
 *              domain identities (domains.php) and the sandbox/quota check in settings.php
 *
 * 'smtp' — email-smtp.<region>.amazonaws.com:465, using the SMTP USER NAME and SMTP PASSWORD
 *          that the SES console shows once when you click "Create SMTP credentials".
 *          Supported because those are the credentials most people have in hand, and because
 *          they are NOT interchangeable with the API pair: the SMTP user name IS the access
 *          key id, but the SMTP password is an irreversible HMAC of the secret access key, so
 *          it can never be turned back into one. Having only SMTP credentials therefore means
 *          API mode is impossible until an access key is created for that IAM user.
 *          Everything that matters for campaigns still works — message tags and the
 *          configuration set are passed as X-SES-* headers, so bounce/complaint webhooks
 *          correlate exactly as they do in API mode. What is unavailable is anything that is
 *          an API call rather than a send: suppression-list sync, domain identity creation,
 *          and the quota/sandbox readout.
 *
 * ── SENDING RATE ─────────────────────────────────────────────────────────────────────────
 * Unlike SendGrid, SES enforces a hard per-second rate (default 14/s in production, 1/s while
 * the account is in the sandbox) and answers over it with a throttling error rather than
 * queueing. Those are classified retryable below, and TransportFactory::concurrencyFor()
 * caps in-flight sends for this provider so a batch doesn't spend itself on 454s.
 */
class SesTransport implements EspTransport {
    /** Placeholders seeded by campaigns_ensure_schema() — present, but not credentials. */
    public const DUMMY_KEY    = 'AKIA_DUMMY_REPLACE_ME';
    public const DUMMY_SECRET = 'DUMMY_SES_SECRET_REPLACE_ME';

    private string $mode;        // 'api' | 'smtp'
    private string $region;
    private string $keyId;       // API: access key id.  SMTP: SMTP user name (same value).
    private string $secret;      // API: secret access key.  SMTP: SMTP password (NOT the same).
    private string $configSet;   // optional SES configuration set — required for event webhooks

    public function __construct(array $settingsRow) {
        $mode = strtolower(trim((string)($settingsRow['auth_mode'] ?? 'api')));
        $this->mode      = $mode === 'smtp' ? 'smtp' : 'api';
        $this->region    = trim((string)($settingsRow['aws_region'] ?? '')) ?: 'ap-south-1';
        $this->keyId     = trim((string)($settingsRow['api_key'] ?? ''));
        $this->secret    = trim((string)($settingsRow['api_secret'] ?? ''));
        $this->configSet = trim((string)($settingsRow['configuration_set'] ?? ''));
    }

    public function isConfigured(): bool {
        if ($this->keyId === '' || $this->secret === '') return false;
        // Both halves are needed, and neither may still be the seeded placeholder — otherwise
        // SendWorker would fire a whole batch at a guaranteed 403.
        if ($this->keyId === self::DUMMY_KEY || $this->secret === self::DUMMY_SECRET) return false;
        return true;
    }

    public function mode(): string { return $this->mode; }
    public function region(): string { return $this->region; }

    /** libcurl is not always compiled with the SMTP protocols; without this the failure reads
     *  as an unhelpful "Protocol smtps not supported" on every single recipient. */
    private function smtpAvailable(): bool {
        $v = function_exists('curl_version') ? curl_version() : null;
        $protocols = is_array($v) ? (array)($v['protocols'] ?? []) : [];
        return in_array('smtps', $protocols, true) || in_array('smtp', $protocols, true);
    }

    /* ── request building ───────────────────────────────────────────────────────────────── */

    public function buildRequest(string $to, string $subject, string $html, string $fromName, string $fromEmail, ?string $replyTo, ?string $rid, array $attachments = []): array {
        return $this->mode === 'smtp'
            ? $this->buildSmtpRequest($to, $subject, $html, $fromName, $fromEmail, $replyTo, $rid, $attachments)
            : $this->buildApiRequest($to, $subject, $html, $fromName, $fromEmail, $replyTo, $rid, $attachments);
    }

    private function buildApiRequest(string $to, string $subject, string $html, string $fromName, string $fromEmail, ?string $replyTo, ?string $rid, array $attachments): array {
        $payload = [
            'FromEmailAddress' => ses_format_address($fromName, $fromEmail),
            'Destination'      => ['ToAddresses' => [$to]],
        ];
        if ($replyTo) $payload['ReplyToAddresses'] = [$replyTo];

        if ($attachments) {
            /*
             * Attachments are only expressible through Raw content on the v2 API, so a campaign
             * WITH files is sent as a base64 MIME blob and one without goes as Simple content.
             * Simple is preferred where possible: SES builds the MIME itself, which keeps our
             * own header/boundary handling out of the deliverability equation for the common case.
             */
            $mime = ses_build_mime($to, $subject, $html, $fromName, $fromEmail, $replyTo, $rid,
                                   $attachments, $this->configSet);
            $payload['Content'] = ['Raw' => ['Data' => base64_encode($mime)]];
        } else {
            $payload['Content'] = ['Simple' => [
                'Subject' => ['Data' => $subject, 'Charset' => 'UTF-8'],
                'Body'    => [
                    'Html' => ['Data' => $html, 'Charset' => 'UTF-8'],
                    // A text/plain alternative measurably helps inbox placement and costs
                    // nothing to derive — SES does not generate one for you.
                    'Text' => ['Data' => ses_html_to_text($html), 'Charset' => 'UTF-8'],
                ],
            ]];
        }

        // Echoed back on every SES event notification as mail.tags.rid — the correlation key
        // ses-webhook.php uses to find our recipient row (SendGrid's custom_args.rid, Elastic
        // Email's Postback). Tag values may only hold letters/digits/dashes/underscores, which
        // a 32-char hex rid satisfies.
        if ($rid) $payload['EmailTags'] = [['Name' => 'rid', 'Value' => $rid]];
        // Without a configuration set SES publishes NO events at all — no bounces, no
        // complaints, no deliveries. It is what wires a send to the SNS topic.
        if ($this->configSet !== '') $payload['ConfigurationSetName'] = $this->configSet;

        return aws_sigv4_request(
            'POST', $this->region, 'ses', '/v2/email/outbound-emails', [],
            json_encode($payload), $this->keyId, $this->secret,
            'email.' . $this->region . '.amazonaws.com'
        );
    }

    private function buildSmtpRequest(string $to, string $subject, string $html, string $fromName, string $fromEmail, ?string $replyTo, ?string $rid, array $attachments): array {
        $mime = ses_build_mime($to, $subject, $html, $fromName, $fromEmail, $replyTo, $rid,
                               $attachments, $this->configSet);

        /*
         * The message is fed to libcurl through a read callback over the in-memory string rather
         * than a temp stream: esp_send_parallel() keeps every job of a 500-recipient batch alive
         * for the whole run, and 500 open php://temp handles (each spilling to disk once an
         * attachment pushes it past 2MB) is a resource leak the HTTP transports never have.
         */
        $offset = 0;
        $read = function ($ch, $fd, $length) use ($mime, &$offset) {
            $chunk = substr($mime, $offset, $length);
            $offset += strlen($chunk);
            return $chunk;
        };

        $curlopts = [
            CURLOPT_USERNAME       => $this->keyId,
            CURLOPT_PASSWORD       => $this->secret,
            // Envelope sender. Angle brackets are what libcurl documents; SES rewrites the
            // return path to its own bounce domain (or your custom MAIL FROM) regardless.
            CURLOPT_MAIL_FROM      => '<' . $fromEmail . '>',
            CURLOPT_MAIL_RCPT      => [$to],
            CURLOPT_UPLOAD         => true,
            CURLOPT_INFILESIZE     => strlen($mime),
            CURLOPT_READFUNCTION   => $read,
            CURLOPT_USE_SSL        => CURLUSESSL_ALL,
            CURLOPT_CONNECTTIMEOUT => 15,
        ];
        /*
         * A rewind handler, IF this PHP build exposes one. Not every version of the curl
         * extension defines CURLOPT_SEEKFUNCTION, and referencing an undefined constant is a
         * fatal error in PHP 8 — which would take down every SES SMTP send rather than the one
         * edge case this guards. libcurl only rewinds when it has to re-issue DATA (an auth
         * retry mid-upload); without the handler that one message fails and is retried on the
         * next worker tick, which is a perfectly acceptable fallback.
         */
        if (defined('CURLOPT_SEEKFUNCTION')) {
            $curlopts[constant('CURLOPT_SEEKFUNCTION')] = function ($ch, $pos, $origin) use (&$offset) {
                $offset = (int)$pos;
                return 0; // CURL_SEEKFUNC_OK
            };
        }

        return [
            // Port 465 (implicit TLS) rather than 587 (STARTTLS): one fewer negotiation step and
            // no chance of a downgrade if a host's libcurl mishandles the upgrade.
            'url'     => 'smtps://email-smtp.' . $this->region . '.amazonaws.com:465',
            'headers' => [],
            'body'    => $mime,
            // Consumed by esp_curl_options() in ParallelSender.php. Present ONLY for SMTP —
            // an HTTP transport never sets this key, so nothing else changes behaviour.
            'curlopts' => $curlopts,
        ];
    }

    /* ── response handling ──────────────────────────────────────────────────────────────── */

    public function parseResponse(int $status, ?string $body, string $curlError, ?string $rid): array {
        return $this->mode === 'smtp'
            ? $this->parseSmtpResponse($status, $curlError, $rid)
            : $this->parseApiResponse($status, $body, $curlError, $rid);
    }

    private function parseApiResponse(int $status, ?string $body, string $curlError, ?string $rid): array {
        if ($curlError !== '') {
            return ['ok' => false, 'message_id' => null, 'error' => "Network error: $curlError", 'retryable' => true];
        }
        $decoded = json_decode((string)$body, true);
        if ($status >= 200 && $status < 300) {
            // SES's own id ("0100018f…"), which every bounce/complaint notification carries as
            // mail.messageId — stored as esp_message_id so an event with no rid tag can still
            // be matched.
            $msgId = is_array($decoded) ? ($decoded['MessageId'] ?? $rid) : $rid;
            return ['ok' => true, 'message_id' => $msgId, 'error' => null, 'retryable' => false];
        }

        $msg = '';
        if (is_array($decoded)) $msg = (string)($decoded['message'] ?? ($decoded['Message'] ?? ''));
        if ($msg === '') $msg = (string)($body ?: "HTTP $status");

        /*
         * The one classification that matters. SES answers a burst above the account's
         * per-second rate with 429 TooManyRequestsException / "Maximum sending rate exceeded",
         * and treating that as a permanent failure would burn an attempt for thousands of
         * perfectly deliverable addresses in a single fast batch. Everything genuinely about
         * the recipient (MessageRejected, unverified address, 400s) stays permanent.
         */
        $retryable = ($status === 429 || $status >= 500
            || stripos($msg, 'Throttl') !== false
            || stripos($msg, 'Maximum sending rate') !== false
            || stripos($msg, 'Too many requests') !== false);

        return ['ok' => false, 'message_id' => null, 'error' => "SES $status: $msg", 'retryable' => $retryable];
    }

    private function parseSmtpResponse(int $status, string $curlError, ?string $rid): array {
        /*
         * For SMTP, CURLINFO_RESPONSE_CODE is the last SMTP reply code, not an HTTP status —
         * 250 accepted, 4xx transient, 5xx permanent. curl also reports its own error text,
         * which is where SES's message ("Throttling failure: Maximum sending rate exceeded",
         * "Authentication credentials invalid") actually reads.
         */
        if ($status === 250 || $status === 251) {
            // No message id: SES returns it in the 250 reply text, which libcurl does not hand
            // back through the multi interface. The rid message tag is what ses-webhook.php
            // correlates on anyway, so nothing is lost — see the header set in ses_build_mime().
            return ['ok' => true, 'message_id' => $rid, 'error' => null, 'retryable' => false];
        }

        $detail = $curlError !== '' ? $curlError : ($status ? "SMTP $status" : 'no response');

        /*
         * Some failures produce NO SMTP reply code at all (status 0) and yet will never succeed
         * however often they are retried: cURL built without SMTP support, and rejected
         * credentials. Those must be permanent, because a retryable failure goes back to
         * 'pending' WITHOUT consuming an attempt (see mark_recipients_failed_batch) — so
         * misclassifying them means the campaign requeues the same doomed batch on every cron
         * tick forever and never reaches 'sent'. Everything else at status 0 (DNS, TLS, connect
         * timeout) genuinely is transient and says nothing about the address.
         */
        $permanentSignals = ['not supported', 'unsupported protocol', 'login denied',
                             'authentication', 'access denied', 'credentials'];
        $looksPermanent = false;
        foreach ($permanentSignals as $signal) {
            if (stripos($detail, $signal) !== false) { $looksPermanent = true; break; }
        }

        $retryable = !$looksPermanent && (
            $status === 0
            || ($status >= 400 && $status < 500)
            || stripos($detail, 'Throttl') !== false
            || stripos($detail, 'Maximum sending rate') !== false
        );

        return ['ok' => false, 'message_id' => null, 'error' => "SES SMTP: $detail", 'retryable' => $retryable];
    }

    public function sendEmail(string $to, string $subject, string $html, string $fromName, string $fromEmail, ?string $replyTo, ?string $rid, array $attachments = []): array {
        if (!$this->isConfigured()) {
            return ['ok' => false, 'message_id' => null, 'retryable' => false,
                    'error' => $this->mode === 'smtp'
                        ? 'Amazon SES SMTP user name / password not configured'
                        : 'Amazon SES access key id / secret access key not configured'];
        }
        if ($this->mode === 'smtp' && !$this->smtpAvailable()) {
            return ['ok' => false, 'message_id' => null, 'retryable' => false,
                    'error' => 'This server\'s cURL was built without SMTP support, so SES SMTP mode '
                             . 'cannot be used here. Switch the SES auth mode to "API" in Settings '
                             . '(create an access key for the SES IAM user) — that path is plain HTTPS.'];
        }
        $req = $this->buildRequest($to, $subject, $html, $fromName, $fromEmail, $replyTo, $rid, $attachments);
        [$status, $body, $curlErr] = esp_http_exec($req);
        return $this->parseResponse($status, $body, $curlErr, $rid);
    }
}

/* ══════════════════════════════════════════════════════════════════════════════════════════
   MIME construction
   Needed by BOTH modes — SMTP always sends raw MIME, and API mode falls back to it whenever a
   campaign has attachments. Written as free functions so ses-webhook.php and any future
   raw-send path can use them without instantiating a transport.
   ═════════════════════════════════════════════════════════════════════════════════════════ */

/** RFC 2047 encodes a header value only when it actually needs it — an ASCII subject stays
 *  human-readable in the raw message, which matters when debugging a deliverability problem. */
function ses_encode_header(string $value): string {
    $value = str_replace(["\r", "\n"], ' ', $value);
    if (preg_match('/[^\x20-\x7E]/', $value)) {
        return '=?UTF-8?B?' . base64_encode($value) . '?=';
    }
    return $value;
}

/** "Display Name <addr@example.com>", with the display name encoded and any quote/bracket
 *  that would break the header stripped out. */
function ses_format_address(string $name, string $email): string {
    $name = trim($name);
    if ($name === '') return $email;
    $name = str_replace(['"', '<', '>', "\r", "\n"], '', $name);
    return ses_encode_header($name) . ' <' . $email . '>';
}

/**
 * A readable text/plain alternative derived from the HTML body.
 *
 * Not cosmetic: a multipart message whose text part is missing is a well-known spam signal, and
 * SES (unlike some ESPs) never synthesises one. Block-level tags become line breaks first,
 * otherwise strip_tags() would run every paragraph into a single wall of text.
 */
function ses_html_to_text(string $html): string {
    $t = preg_replace('~<(script|style)\b[^>]*>.*?</\1>~is', '', $html);
    $t = preg_replace('~<br\s*/?>~i', "\n", (string)$t);
    $t = preg_replace('~</(p|div|tr|li|h[1-6]|table|blockquote)>~i', "\n", (string)$t);
    $t = strip_tags((string)$t);
    $t = html_entity_decode($t, ENT_QUOTES | ENT_HTML5, 'UTF-8');
    $t = preg_replace('/[ \t\x{00A0}]+/u', ' ', $t);
    $t = preg_replace('/\n{3,}/', "\n\n", (string)$t);
    $t = trim((string)$t);
    return $t !== '' ? $t : 'This message is best viewed in an HTML-capable email client.';
}

/**
 * One complete RFC 5322 message, CRLF-terminated throughout.
 *
 * Structure depends on what is actually present, because an unnecessary multipart wrapper is
 * one more thing for a picky mail client to render badly:
 *   no attachments  →  multipart/alternative { text/plain, text/html }
 *   attachments     →  multipart/mixed { multipart/alternative {…}, application/… × n }
 *
 * Both body parts are base64-encoded rather than quoted-printable: it is the encoding that
 * cannot corrupt UTF-8 or trip the 998-octet line limit, and the ~33% size cost is irrelevant
 * next to the images these templates already carry.
 *
 * @param array $attachments [['filename'=>…, 'content'=>base64 string, 'type'=>mime], …] —
 *              the same already-base64 shape load_campaign_attachments() produces.
 */
function ses_build_mime(string $to, string $subject, string $html, string $fromName, string $fromEmail,
                        ?string $replyTo, ?string $rid, array $attachments = [], string $configSet = ''): string {
    $eol = "\r\n";
    $altBoundary = 'alt_' . bin2hex(random_bytes(12));
    $mixBoundary = 'mix_' . bin2hex(random_bytes(12));

    $headers = [
        'From: ' . ses_format_address($fromName, $fromEmail),
        'To: ' . $to,
        'Subject: ' . ses_encode_header($subject),
        'Date: ' . gmdate('D, d M Y H:i:s') . ' +0000',
        'MIME-Version: 1.0',
    ];
    if ($replyTo) $headers[] = 'Reply-To: ' . $replyTo;
    /*
     * The SMTP-mode equivalents of the API's EmailTags / ConfigurationSetName. SES strips both
     * headers before delivery and acts on them itself, so they never reach the recipient.
     * Without X-SES-CONFIGURATION-SET nothing is published to SNS and delivered/bounce counts
     * stay at zero forever; without the rid tag the events that do arrive cannot be matched to
     * a recipient row.
     */
    if ($configSet !== '') $headers[] = 'X-SES-CONFIGURATION-SET: ' . $configSet;
    if ($rid) $headers[] = 'X-SES-MESSAGE-TAGS: rid=' . $rid;

    $textPart = 'Content-Type: text/plain; charset="UTF-8"' . $eol
              . 'Content-Transfer-Encoding: base64' . $eol . $eol
              . chunk_split(base64_encode(ses_html_to_text($html)), 76, $eol);

    $htmlPart = 'Content-Type: text/html; charset="UTF-8"' . $eol
              . 'Content-Transfer-Encoding: base64' . $eol . $eol
              . chunk_split(base64_encode($html), 76, $eol);

    $alternative = '--' . $altBoundary . $eol . $textPart
                 . '--' . $altBoundary . $eol . $htmlPart
                 . '--' . $altBoundary . '--' . $eol;

    if (!$attachments) {
        $headers[] = 'Content-Type: multipart/alternative; boundary="' . $altBoundary . '"';
        return implode($eol, $headers) . $eol . $eol . $alternative;
    }

    $headers[] = 'Content-Type: multipart/mixed; boundary="' . $mixBoundary . '"';
    $body = '--' . $mixBoundary . $eol
          . 'Content-Type: multipart/alternative; boundary="' . $altBoundary . '"' . $eol . $eol
          . $alternative;

    foreach ($attachments as $att) {
        $name = (string)($att['filename'] ?? 'attachment');
        // Anything that could break out of the header — quotes, CR/LF, path separators.
        $name = preg_replace('~[\r\n"\\\\/]~', '', $name);
        $type = (string)($att['type'] ?? 'application/octet-stream');
        // Already base64 from load_campaign_attachments(); re-wrap the lines because a single
        // multi-megabyte line violates the SMTP line-length limit and some MTAs will refuse it.
        $content = preg_replace('/\s+/', '', (string)($att['content'] ?? ''));

        $body .= '--' . $mixBoundary . $eol
               . 'Content-Type: ' . $type . '; name="' . $name . '"' . $eol
               . 'Content-Transfer-Encoding: base64' . $eol
               . 'Content-Disposition: attachment; filename="' . $name . '"' . $eol . $eol
               . chunk_split((string)$content, 76, $eol);
    }
    $body .= '--' . $mixBoundary . '--' . $eol;

    return implode($eol, $headers) . $eol . $eol . $body;
}

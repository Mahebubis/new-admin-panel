<?php
/*
 * SendGrid suppression-list sync — keeps SendGrid's own suppression lists (global
 * unsubscribes, bounces, blocks, spam reports, and any unsubscribe groups) in sync with
 * our own Blocklist, in both directions:
 *   - sendgrid_add_global_suppression(): called whenever an email is added to OUR
 *     blocklist (manual add, CSV import, or an auto-added hard bounce/unsubscribe) — makes
 *     SendGrid itself refuse to send to this address too, not just our own
 *     AudienceResolver.php filtering.
 *   - sendgrid_remove_all_suppressions(): called whenever an email is removed from OUR
 *     blocklist — clears it from every SendGrid suppression list so it can actually
 *     receive mail again, not just get removed from our own local list.
 * Uses the same SendGrid API key already stored in email_esp_settings (provider='sendgrid'),
 * the same one SendGridTransport.php sends real campaigns through.
 */

function sendgrid_api_key(): ?string {
    global $conn;
    $r = $conn->query("SELECT api_key FROM email_esp_settings WHERE provider='sendgrid' LIMIT 1");
    $row = $r ? $r->fetch_assoc() : null;
    $key = $row['api_key'] ?? null;
    // The dummy placeholder seeded for brand-new installs (see campaigns_ensure_schema())
    // isn't a real key — treat it the same as "not configured".
    return ($key && $key !== 'SG.DUMMY_KEY_REPLACE_ME') ? $key : null;
}

function sendgrid_api_request(string $method, string $path, $body = null): array {
    $apiKey = sendgrid_api_key();
    if (!$apiKey) return ['ok' => false, 'error' => 'SendGrid API key not configured'];

    $ch = curl_init('https://api.sendgrid.com/v3' . $path);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_CUSTOMREQUEST => $method,
        CURLOPT_HTTPHEADER => ['Authorization: Bearer ' . $apiKey, 'Content-Type: application/json'],
        CURLOPT_TIMEOUT => 15,
    ]);
    if ($body !== null) curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($body));
    $respBody = curl_exec($ch);
    $status = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $curlErr = curl_error($ch);
    curl_close($ch);

    if ($curlErr) return ['ok' => false, 'error' => "Network error: $curlErr"];
    // A 404 on a DELETE just means the email wasn't on that particular suppression list —
    // not a real error, every caller here treats it as a harmless no-op.
    if ($status >= 200 && $status < 300) return ['ok' => true, 'status' => $status, 'body' => $respBody];
    return ['ok' => false, 'status' => $status, 'error' => $respBody];
}

function sendgrid_suppression_log(string $msg): void {
    if (function_exists('campaign_log')) { campaign_log('[sendgrid-suppression] ' . $msg); return; }
    error_log('[sendgrid-suppression] ' . $msg);
}

/** Adds $email to SendGrid's global unsubscribe suppression list — the broadest
 *  suppression type, stops SendGrid from sending to this address under any campaign,
 *  independent of anything on our own side. Silently no-ops if no real API key is
 *  configured yet (e.g. local/dev environments). */
function sendgrid_add_global_suppression(string $email): void {
    if (!sendgrid_api_key()) return;
    $res = sendgrid_api_request('POST', '/asm/suppressions/global', ['recipient_emails' => [$email]]);
    sendgrid_suppression_log("add global suppression for $email -> " . ($res['ok'] ? 'ok' : 'FAILED: ' . ($res['error'] ?? '')));
}

/** Removes $email from every SendGrid suppression list — global unsubscribes, bounces,
 *  blocks, spam reports, and any configured unsubscribe group — so it can actually
 *  receive mail again after being removed from our Blocklist, not just locally. Each
 *  removal is independent and best-effort. */
function sendgrid_remove_all_suppressions(string $email): void {
    if (!sendgrid_api_key()) return;
    $encoded = rawurlencode($email);

    $res = sendgrid_api_request('DELETE', "/asm/suppressions/global/$encoded");
    sendgrid_suppression_log("remove global suppression for $email -> " . ($res['ok'] ? 'ok' : ($res['status'] ?? '?') . ' ' . ($res['error'] ?? '')));

    $res = sendgrid_api_request('DELETE', "/suppression/bounces/$encoded");
    sendgrid_suppression_log("remove bounce suppression for $email -> " . ($res['ok'] ? 'ok' : ($res['status'] ?? '?') . ' ' . ($res['error'] ?? '')));

    $res = sendgrid_api_request('DELETE', "/suppression/blocks/$encoded");
    sendgrid_suppression_log("remove block suppression for $email -> " . ($res['ok'] ? 'ok' : ($res['status'] ?? '?') . ' ' . ($res['error'] ?? '')));

    $res = sendgrid_api_request('DELETE', "/suppression/spam_reports/$encoded");
    sendgrid_suppression_log("remove spam report suppression for $email -> " . ($res['ok'] ? 'ok' : ($res['status'] ?? '?') . ' ' . ($res['error'] ?? '')));

    // Unsubscribe groups (SendGrid's ASM/"unsubscribe group" feature) — only relevant if
    // any groups are actually configured on the account; a harmless no-op otherwise.
    $groupsRes = sendgrid_api_request('GET', '/asm/groups');
    if ($groupsRes['ok']) {
        $groups = json_decode($groupsRes['body'], true) ?: [];
        foreach ($groups as $g) {
            $gid = $g['id'] ?? null;
            if (!$gid) continue;
            $gr = sendgrid_api_request('DELETE', "/asm/groups/$gid/suppressions/$encoded");
            sendgrid_suppression_log("remove group #$gid suppression for $email -> " . ($gr['ok'] ? 'ok' : ($gr['status'] ?? '?')));
        }
    }
}

<?php
/*
 * Resolves a campaign's Audience-step config into actual recipient rows /
 * counts. Reuses netcore/segments.php's buildSegmentSql() (shared via
 * netcore/lib/segment_sql.php) rather than re-implementing segment
 * membership resolution — campaigns select whole *segments* by id, so this
 * just UNIONs each selected segment's subquery.
 *
 * $config shape: { audience_type: 'all_contacts'|'segments', segment_ids: [..],
 *                   exclude_segment_ids: [..], domain_filter: 'gmail.com' }
 */
require_once __DIR__ . '/../../netcore/lib/segment_sql.php';
require_once __DIR__ . '/../../lists/lib/schema.php';

/**
 * Emails on the single global Blocklist — excluded from every campaign send
 * regardless of whether the recipient was matched via a Segment or a List.
 * Returns a lowercase-email => true map for O(1) lookups against the merged
 * recipient set built in resolve_audience_users(); resolve_audience_count()
 * instead folds this straight into its SQL as a subquery (see below).
 */
function blocklisted_emails(): array {
    global $conn;
    $blocklistId = lists_get_or_create_blocklist_id();
    $r = $conn->query("SELECT c.email FROM campaign_contacts c
                        INNER JOIN campaign_list_members m ON m.contact_id = c.id
                        WHERE m.list_id = " . (int)$blocklistId);
    $out = [];
    while ($r && $row = $r->fetch_assoc()) $out[strtolower($row['email'])] = true;
    return $out;
}

function audience_base_sql(array $config): ?string {
    global $conn;
    $type = $config['audience_type'] ?? 'segments';

    if ($type === 'all_contacts') {
        $inc = "SELECT user_id FROM users WHERE COALESCE(active,1) <> 0";
    } else {
        $segIds = array_values(array_filter(array_map('intval', $config['segment_ids'] ?? [])));
        if (!$segIds) return null;
        $subs = [];
        foreach ($segIds as $id) {
            $r = $conn->query("SELECT config FROM netcore_segments WHERE id=" . (int)$id . " LIMIT 1");
            $row = $r ? $r->fetch_assoc() : null;
            if (!$row) continue;
            $sql = buildSegmentSql(json_decode($row['config'], true));
            if ($sql) $subs[] = $sql;
        }
        if (!$subs) return null;
        $inc = "SELECT DISTINCT user_id FROM (" . implode(' UNION ', $subs) . ") AS inc_u";
    }

    $excIds = array_values(array_filter(array_map('intval', $config['exclude_segment_ids'] ?? [])));
    if ($excIds) {
        $excSubs = [];
        foreach ($excIds as $id) {
            $r = $conn->query("SELECT config FROM netcore_segments WHERE id=" . (int)$id . " LIMIT 1");
            $row = $r ? $r->fetch_assoc() : null;
            if (!$row) continue;
            $sql = buildSegmentSql(json_decode($row['config'], true));
            if ($sql) $excSubs[] = $sql;
        }
        if ($excSubs) {
            $excAll = implode(' UNION ', $excSubs);
            $inc = "SELECT user_id FROM ($inc) AS a WHERE user_id NOT IN (SELECT user_id FROM ($excAll) AS e)";
        }
    }
    return $inc;
}

function domain_where_clause(array $config): string {
    $domain = trim((string)($config['domain_filter'] ?? ''));
    return $domain !== '' ? " AND u.email LIKE '%@" . esc($domain) . "'" : '';
}

/** Same domain filter, applied to the campaign_contacts-sourced (Lists) half of the audience. */
function domain_where_clause_contacts(array $config): string {
    $domain = trim((string)($config['domain_filter'] ?? ''));
    return $domain !== '' ? " AND c.email LIKE '%@" . esc($domain) . "'" : '';
}

/**
 * Live "reachable contacts" count for the Audience step — a campaign's real
 * audience is the UNION of Segments (dynamic rules over `users`) and Lists
 * (static imported contacts in `campaign_contacts`), de-duped by email. Plain
 * SQL UNION is enough here since only a COUNT is needed.
 */
function resolve_audience_count(array $config): int {
    global $conn;
    $parts = [];

    $base = audience_base_sql($config);
    if ($base) {
        $parts[] = "SELECT u.email AS email FROM ($base) AS s
                    INNER JOIN users u ON u.user_id = s.user_id
                    WHERE u.email IS NOT NULL AND u.email <> ''" . domain_where_clause($config);
    }

    $listIds = array_values(array_filter(array_map('intval', $config['list_ids'] ?? [])));
    if ($listIds) {
        $ids = implode(',', $listIds);
        $parts[] = "SELECT c.email AS email FROM campaign_contacts c
                    INNER JOIN campaign_list_members m ON m.contact_id = c.id
                    WHERE m.list_id IN ($ids) AND c.email IS NOT NULL AND c.email <> ''" . domain_where_clause_contacts($config);
    }

    if (!$parts) return 0;
    $blocklistId = lists_get_or_create_blocklist_id();
    $sql = "SELECT COUNT(*) AS c FROM (" . implode(' UNION ', $parts) . ") AS combined
            WHERE combined.email NOT IN (
                SELECT c.email FROM campaign_contacts c
                INNER JOIN campaign_list_members m ON m.contact_id = c.id
                WHERE m.list_id = $blocklistId
            )";
    $r = $conn->query($sql);
    if (!$r) {
        if (function_exists('campaign_log')) campaign_log('resolve_audience_count: query FAILED — ' . $conn->error);
        return 0;
    }
    return (int)$r->fetch_assoc()['c'];
}

/**
 * Materializes recipient rows (email + merge-tag fields) for queueing into
 * email_campaign_recipients — merged in PHP, not SQL, because a plain UNION
 * only de-dupes rows that are byte-identical across every column, and a
 * contact matched by both a segment and a list could have differing name
 * data between the two sources. Segment-sourced rows win on an email
 * collision (checked first) since they carry a real user_id, which is what
 * unlocks exam-merge-tag data downstream (see MergeTags.php's resolve_exam_data()) —
 * list-only contacts get their user_id looked up too (a List/Blocklist contact can
 * still be an already-registered student), and only fall back to user_id => null
 * when their email genuinely isn't a registered account.
 */
function resolve_audience_users(array $config, int $limit = 0, int $offset = 0): array {
    global $conn;
    $byEmail = [];

    $base = audience_base_sql($config);
    if ($base) {
        $sql = "SELECT u.user_id, u.email, u.fname AS first_name, u.lname AS last_name, u.phone
                FROM ($base) AS s
                INNER JOIN users u ON u.user_id = s.user_id
                WHERE u.email IS NOT NULL AND u.email <> ''" . domain_where_clause($config);
        $r = $conn->query($sql);
        if (!$r && function_exists('campaign_log')) campaign_log('resolve_audience_users: segment-side query FAILED — ' . $conn->error);
        while ($r && $row = $r->fetch_assoc()) $byEmail[strtolower($row['email'])] = $row;
    }

    $listIds = array_values(array_filter(array_map('intval', $config['list_ids'] ?? [])));
    if ($listIds) {
        $ids = implode(',', $listIds);
        // LEFT JOIN users — a list/contact-only recipient with no name of its own (e.g. a
        // CSV that only had an EMAIL column) may still be an already-registered student;
        // fall back to their real users.fname/lname/phone AND their real user_id so
        // XX_USER_FNAME_XX, exam merge tags, and mapped Customer Attributes (all keyed by
        // user_id) aren't left blank/defaulted when we could've had the real value all
        // along — a List/Blocklist contact is only "no user_id" when their email genuinely
        // isn't a registered account.
        $sql = "SELECT DISTINCT c.email, u.user_id AS matched_user_id,
                       COALESCE(c.first_name, u.fname) AS first_name,
                       COALESCE(c.last_name, u.lname) AS last_name,
                       COALESCE(c.phone, u.phone) AS phone
                FROM campaign_contacts c
                INNER JOIN campaign_list_members m ON m.contact_id = c.id
                LEFT JOIN users u ON u.email = c.email COLLATE utf8mb4_general_ci
                WHERE m.list_id IN ($ids) AND c.email IS NOT NULL AND c.email <> ''" . domain_where_clause_contacts($config);
        $r = $conn->query($sql);
        if (!$r && function_exists('campaign_log')) campaign_log('resolve_audience_users: list-side query FAILED — ' . $conn->error);
        while ($r && $row = $r->fetch_assoc()) {
            $key = strtolower($row['email']);
            if (!isset($byEmail[$key])) {
                $uid = $row['matched_user_id'] !== null ? (int)$row['matched_user_id'] : null;
                unset($row['matched_user_id']);
                $byEmail[$key] = ['user_id' => $uid] + $row;
            }
        }
    }

    // Blocklist exclusion applied last, after the segment+list merge — this is what actually
    // stops a send (the Blocklist UI page alone is just a table; this is the enforcement point).
    $blocked = blocklisted_emails();
    if ($blocked) {
        foreach (array_keys($byEmail) as $email) {
            if (isset($blocked[$email])) unset($byEmail[$email]);
        }
    }

    $rows = array_values($byEmail);
    return $limit > 0 ? array_slice($rows, $offset, $limit) : $rows;
}

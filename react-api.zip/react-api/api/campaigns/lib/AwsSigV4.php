<?php
/*
 * Minimal AWS Signature Version 4 signer — the one piece of AWS plumbing the SES
 * transport cannot do without.
 *
 * WHY THIS EXISTS AT ALL
 * SendGrid and Elastic Email authenticate with a single header ("Authorization: Bearer …" /
 * "X-ElasticEmail-ApiKey: …"), so their transports needed no signing code. Amazon's HTTPS
 * APIs instead require every request to be signed with a key derived from the secret access
 * key, the date, the region and the service — the secret itself is never transmitted. That is
 * ~60 lines of very fussy string building, so it lives here on its own rather than being
 * buried inside SesTransport.php, and is shared by the transport, the suppression client and
 * the domain-identity calls in domains.php.
 *
 * NO SDK ON PURPOSE
 * The official aws/aws-sdk-php would pull ~15MB of Composer dependencies into a tree that has
 * none (this backend is deployed by uploading folders over FTP — see the deploy notes in
 * campaign-send-worker.php). Everything needed for SES is hash_hmac + a canonical string, and
 * PHP ships both.
 *
 * THE TWO ENCODING TRAPS, both of which produce a valid-looking 403 SignatureDoesNotMatch:
 *   1. Every path segment is URI-encoded ONCE for the URL that goes on the wire and TWICE for
 *      the canonical request used in the signature (S3 is the only service that skips the
 *      second pass). This only bites on paths containing an email address — the '@' in the
 *      suppression-list endpoints — which is exactly where SES bounce handling lives, so it
 *      would have failed in the least obvious place. aws_sigv4_request() returns the finished
 *      URL alongside the headers so no caller has to know this.
 *   2. The signed payload hash must be of the EXACT bytes sent. A caller that re-encodes its
 *      JSON after signing silently invalidates the signature, so this function takes the final
 *      body string and hands it straight back in the result.
 */

/** RFC 3986 encoding as AWS defines it. rawurlencode() already matches it (unreserved set is
 *  A-Za-z0-9-_.~, space becomes %20 not '+'), so this only handles the per-segment split. */
function aws_sigv4_encode_path(string $rawPath, bool $twice = false): string {
    $segments = explode('/', ltrim($rawPath, '/'));
    $out = [];
    foreach ($segments as $seg) {
        $enc = rawurlencode($seg);
        if ($twice) $enc = rawurlencode($enc);
        $out[] = $enc;
    }
    return '/' . implode('/', $out);
}

/** Canonical query string: parameters sorted by encoded name, values encoded, joined with '&'. */
function aws_sigv4_canonical_query(array $query): string {
    $pairs = [];
    foreach ($query as $k => $v) {
        // A list value repeats the key (SES uses this for nothing today, but a malformed
        // canonical string here is unreadable to debug, so handle it rather than ignore it).
        foreach ((array)$v as $one) {
            $pairs[] = rawurlencode((string)$k) . '=' . rawurlencode((string)$one);
        }
    }
    sort($pairs, SORT_STRING);
    return implode('&', $pairs);
}

/**
 * Signs one request and returns everything needed to perform it.
 *
 * @param string      $method    GET/POST/PUT/DELETE
 * @param string      $region    e.g. 'ap-south-1' — part of the signing scope, so a key signed
 *                               for the wrong region is rejected even though it is valid
 * @param string      $service   AWS signing name ('ses' for both SES v1 and the v2 REST API)
 * @param string      $rawPath   UNENCODED path, e.g. '/v2/email/suppression/addresses/a@b.com'
 * @param array       $query     query parameters, unencoded
 * @param string|null $payload   the exact request body bytes ('' or null for GET/DELETE)
 * @param string      $host      override the default '<service>.<region>.amazonaws.com'
 *                               (SES v2's endpoint is email.<region>.amazonaws.com, not ses.…)
 * @return array{url: string, headers: string[], body: string}
 *         Same shape EspTransport::buildRequest() returns, so a signed request can be handed
 *         straight to esp_http_exec()/esp_send_parallel() with no adapter in between.
 */
function aws_sigv4_request(string $method, string $region, string $service, string $rawPath,
                           array $query, ?string $payload, string $accessKey, string $secretKey,
                           string $host = '', string $contentType = 'application/json'): array {
    $method  = strtoupper($method);
    $payload = (string)$payload;
    if ($host === '') $host = $service . '.' . $region . '.amazonaws.com';

    // ONE timestamp for both forms. Calling gmdate() twice can straddle midnight, which puts
    // the date in the credential scope one day away from the date in X-Amz-Date — a signature
    // mismatch that only ever reproduces for a few microseconds a day.
    $now       = time();
    $amzDate   = gmdate('Ymd\THis\Z', $now);
    $dateStamp = gmdate('Ymd', $now);

    $canonicalUri   = aws_sigv4_encode_path($rawPath, true);
    $requestUri     = aws_sigv4_encode_path($rawPath, false);
    $canonicalQuery = aws_sigv4_canonical_query($query);
    $payloadHash    = hash('sha256', $payload);

    // Header names must be lowercase and sorted; a body-carrying request also signs
    // content-type, since that is a header we actually send.
    $headers = ['host' => $host, 'x-amz-date' => $amzDate];
    if ($payload !== '') $headers['content-type'] = $contentType;
    ksort($headers, SORT_STRING);

    $canonicalHeaders = '';
    foreach ($headers as $k => $v) $canonicalHeaders .= $k . ':' . trim($v) . "\n";
    $signedHeaders = implode(';', array_keys($headers));

    $canonicalRequest = implode("\n", [
        $method, $canonicalUri, $canonicalQuery, $canonicalHeaders, $signedHeaders, $payloadHash,
    ]);

    $scope     = $dateStamp . '/' . $region . '/' . $service . '/aws4_request';
    $stringToSign = implode("\n", [
        'AWS4-HMAC-SHA256', $amzDate, $scope, hash('sha256', $canonicalRequest),
    ]);

    // The derived signing key: secret → date → region → service → 'aws4_request'. Each step
    // takes the previous step's RAW binary output, which is why every hash_hmac below passes
    // true for $binary except the final signature.
    $kDate    = hash_hmac('sha256', $dateStamp, 'AWS4' . $secretKey, true);
    $kRegion  = hash_hmac('sha256', $region, $kDate, true);
    $kService = hash_hmac('sha256', $service, $kRegion, true);
    $kSigning = hash_hmac('sha256', 'aws4_request', $kService, true);
    $signature = hash_hmac('sha256', $stringToSign, $kSigning);

    $authorization = 'AWS4-HMAC-SHA256 '
        . 'Credential=' . $accessKey . '/' . $scope . ', '
        . 'SignedHeaders=' . $signedHeaders . ', '
        . 'Signature=' . $signature;

    $wireHeaders = [
        'Host: ' . $host,
        'X-Amz-Date: ' . $amzDate,
        'Authorization: ' . $authorization,
    ];
    if ($payload !== '') $wireHeaders[] = 'Content-Type: ' . $contentType;

    $url = 'https://' . $host . $requestUri . ($canonicalQuery !== '' ? '?' . $canonicalQuery : '');

    return ['url' => $url, 'headers' => $wireHeaders, 'body' => $payload];
}

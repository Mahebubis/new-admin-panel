<?php
/*
 * Injects our own first-party open-pixel + click-redirect tracking into an
 * email's HTML at send time, per recipient (each gets a unique `rid`).
 * This is why open/click stats are identical regardless of which ESP
 * (SendGrid or Elastic Email) actually delivered the mail — tracking never
 * depends on the transport.
 */

define('CAMPAIGNS_PUBLIC_BASE_URL', 'https://cit3.internshipstudio.com/admin/react-api/api/campaigns');

function inject_tracking(string $html, string $rid, string $baseUrl = CAMPAIGNS_PUBLIC_BASE_URL): string {
    $html = rewrite_links_for_click_tracking($html, $rid, $baseUrl);
    $html = append_open_pixel($html, $rid, $baseUrl);
    return $html;
}

/*
 * The pixel goes at the TOP of the body, not the bottom.
 *
 * Gmail truncates a message over ~102KB and hides the remainder behind "View entire
 * message" — and it never renders the hidden part, so a pixel sitting just before
 * </body> is simply never requested. Every link ABOVE the cut still redirects
 * normally, which produces the confusing signature this was found by: a campaign
 * reporting real clicks and zero opens, from recipients who obviously opened it.
 *
 * There is nothing to be gained from the bottom of the document — the pixel is
 * invisible either way, and mail clients load images as they render, not in document
 * order. So it is placed immediately after the opening <body> tag, where no amount of
 * clipping can reach it.
 */
function append_open_pixel(string $html, string $rid, string $baseUrl): string {
    $pixel = '<img src="' . htmlspecialchars($baseUrl . '/track-open.php?rid=' . urlencode($rid), ENT_QUOTES)
           . '" width="1" height="1" style="display:none;width:1px;height:1px;border:0;" alt="" />';

    // After the opening tag, attributes and all: <body>, <body style="…">, <BODY …>.
    $injected = preg_replace('/(<body\b[^>]*>)/i', '$1' . $pixel, $html, 1, $count);
    if ($count > 0) return $injected;

    // A fragment with no <body> at all (some templates are stored as bare markup) —
    // the top of the fragment is then the top of the rendered mail.
    return $pixel . $html;
}

/** Coarse device classification from a raw User-Agent string, stored alongside open/click events. */
function classify_device_type(string $userAgent): string {
    if ($userAgent === '') return 'unknown';
    if (preg_match('/iPad|Android(?!.*Mobile)|Tablet/i', $userAgent)) return 'tablet';
    if (preg_match('/Mobile|iPhone|Android|BlackBerry|IEMobile|Opera Mini/i', $userAgent)) return 'mobile';
    return 'desktop';
}

/** Rewrites every <a href="URL"> to point at our click-tracking redirect, skipping mailto/tel/#/already-wrapped links. */
function rewrite_links_for_click_tracking(string $html, string $rid, string $baseUrl): string {
    return preg_replace_callback(
        '/<a\b([^>]*?)\shref\s*=\s*(["\'])(.*?)\2([^>]*)>/is',
        function ($m) use ($rid, $baseUrl) {
            [$full, $pre, $quote, $url, $post] = $m;
            $trimmed = trim($url);
            if ($trimmed === '' || $trimmed[0] === '#'
                || stripos($trimmed, 'mailto:') === 0
                || stripos($trimmed, 'tel:') === 0
                || stripos($trimmed, '/track-click.php') !== false) {
                return $full;
            }
            $tracked = $baseUrl . '/track-click.php?rid=' . urlencode($rid) . '&u=' . urlencode($trimmed);
            return '<a' . $pre . ' href=' . $quote . $tracked . $quote . $post . '>';
        },
        $html
    );
}

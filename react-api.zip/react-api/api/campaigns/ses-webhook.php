<?php
/*
 * Public receiver for Amazon SES event notifications, delivered by Amazon SNS — the SES
 * counterpart of sendgrid-webhook.php and elasticemail-webhook.php.
 *
 * ── SETUP (three pieces, and SES publishes NOTHING until all three exist) ─────────────────
 *   1. SNS  → Topics → Create topic (Standard), any name, same region as SES.
 *   2. SNS  → that topic → Create subscription → Protocol HTTPS,
 *             Endpoint = this file's public URL. Leave "raw message delivery" OFF.
 *             AWS immediately POSTs a SubscriptionConfirmation here and this file confirms it
 *             automatically — the subscription should flip to "Confirmed" within seconds.
 *   3. SES  → Configuration sets → create one → Event destinations → Add destination →
 *             Amazon SNS → the topic above, with these event types selected:
 *               Sends, Deliveries, Bounces, Complaints, Rejects, Delivery delays
 *             (Opens and Clicks are deliberately NOT needed — see below.)
 *             Then put that configuration set's NAME into Settings → Email provider settings →
 *             Amazon SES → Configuration set.
 *
 * That last step is the one people miss. SES only emits events for messages tagged with a
 * configuration set that has an event destination; a campaign sent without one is delivered
 * perfectly and reports delivered_count = 0 and bounce_count = 0 forever, with nothing
 * anywhere saying why.
 *
 * ── WHY OPENS/CLICKS ARE IGNORED ──────────────────────────────────────────────────────────
 * Tracking is first-party: inject_tracking() has already rewritten every link to
 * track-click.php and appended our own open pixel (see lib/TrackingRewriter.php). Counting
 * SES's open/click events on top would double every number.
 *
 * ── CORRELATION ───────────────────────────────────────────────────────────────────────────
 * SesTransport tags every send with rid — as an EmailTag in API mode, as the
 * X-SES-MESSAGE-TAGS header in SMTP mode — and SES echoes it back on every event under
 * mail.tags.rid. That is the primary key. mail.messageId is the fallback, matched against
 * email_campaign_recipients.esp_message_id (indexed), which API mode stores from the send
 * response. Anything matching neither is offered to the Journey engine, whose messages keep
 * their own rids in journey_messages.
 */
ini_set('display_errors', 0);
error_reporting(0);
header('Content-Type: application/json');

require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../lists/lib/schema.php';
require_once __DIR__ . '/../lists/lib/ContactImportWorker.php';

/* Low-volume diagnostic log — only setup events, verification problems and unmatched events are
 * written, never one line per delivery, so it cannot run away. This is the file to read when
 * "the subscription says Confirmed but nothing is being counted". */
function ses_webhook_log(string $msg): void {
    $line = '[' . gmdate('Y-m-d H:i:s') . 'Z] ' . $msg . "\n";
    if (!@file_put_contents(__DIR__ . '/ses-webhook.log', $line, FILE_APPEND | LOCK_EX)) {
        error_log('[ses-webhook] ' . $msg);
    }
}

/* ══════════════════════════════════════════════════════════════════════════════════════════
   SNS message authenticity

   This endpoint is public and unauthenticated (SNS cannot send a bearer token or a custom
   header), so the signature is the only thing separating a real AWS notification from anyone
   who found the URL — and the events here blocklist email addresses, which is not something a
   stranger should be able to trigger.
   ═════════════════════════════════════════════════════════════════════════════════════════ */

/** Guards the two URLs this endpoint is handed by an unauthenticated request and then FETCHES:
 *  SigningCertURL (without this check an attacker points it at a certificate they control and
 *  every signature verifies) and SubscribeURL (which must call back into SNS, not anywhere else).
 *  Both live on sns.<region>.amazonaws.com. */
function sns_is_amazon_sns_url(string $url): bool {
    $parts = parse_url($url);
    if (!$parts || ($parts['scheme'] ?? '') !== 'https') return false;
    $host = strtolower((string)($parts['host'] ?? ''));
    return (bool)preg_match('/^sns\.[a-z0-9\-]+\.amazonaws\.com(\.cn)?$/', $host);
}

/** Certs rotate rarely, and re-fetching one per notification would add a round-trip to every
 *  single delivery receipt on a 40k campaign. Cached by URL in the system temp dir. */
function sns_fetch_certificate(string $url): ?string {
    $cacheFile = rtrim(sys_get_temp_dir(), '/\\') . DIRECTORY_SEPARATOR . 'sns-cert-' . sha1($url) . '.pem';
    if (is_readable($cacheFile) && (time() - (int)@filemtime($cacheFile)) < 86400) {
        $cached = @file_get_contents($cacheFile);
        if ($cached) return $cached;
    }
    $ch = curl_init($url);
    curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 10, CURLOPT_SSL_VERIFYPEER => true]);
    $pem = curl_exec($ch);
    $ok  = curl_error($ch) === '' && (int)curl_getinfo($ch, CURLINFO_HTTP_CODE) === 200;
    curl_close($ch);
    if (!$ok || !$pem) return null;
    @file_put_contents($cacheFile, $pem);
    return (string)$pem;
}

/**
 * @return true when the signature is valid, false when it is definitively wrong, and null when
 *         verification could not be performed at all (no openssl extension, cert unreachable).
 *
 * The three-way answer matters. A WRONG signature is rejected — that is a forgery or a
 * misconfigured sender. Verification being IMPOSSIBLE is treated as a pass with a log line
 * instead: on a host without openssl, failing closed would silently discard every delivery and
 * bounce receipt for every campaign, which is a far more damaging failure than accepting a
 * payload whose only lever is a counter keyed by a 128-bit random rid an attacker cannot guess.
 */
function sns_verify_signature(array $env): ?bool {
    if (!function_exists('openssl_verify')) return null;

    $certUrl = (string)($env['SigningCertURL'] ?? '');
    if (!sns_is_amazon_sns_url($certUrl)) return false;

    $type = (string)($env['Type'] ?? '');
    // Field order is part of the signature and differs by message type.
    $fields = ($type === 'SubscriptionConfirmation' || $type === 'UnsubscribeConfirmation')
        ? ['Message', 'MessageId', 'SubscribeURL', 'Timestamp', 'Token', 'TopicArn', 'Type']
        : ['Message', 'MessageId', 'Subject', 'Timestamp', 'TopicArn', 'Type'];

    $stringToSign = '';
    foreach ($fields as $f) {
        // 'Subject' is genuinely optional and is omitted from the string entirely when absent —
        // including it as empty produces a mismatch on every SES notification.
        if (!isset($env[$f])) continue;
        $stringToSign .= $f . "\n" . $env[$f] . "\n";
    }

    $pem = sns_fetch_certificate($certUrl);
    if ($pem === null) return null;
    $pubKey = @openssl_pkey_get_public($pem);
    if (!$pubKey) return null;

    $signature = base64_decode((string)($env['Signature'] ?? ''), true);
    if ($signature === false) return false;

    // SignatureVersion 1 is SHA1, version 2 is SHA256. AWS is migrating topics to 2, so both
    // have to be supported — assuming either one breaks on a topic configured the other way.
    $algo = ((string)($env['SignatureVersion'] ?? '1')) === '2' ? OPENSSL_ALGO_SHA256 : OPENSSL_ALGO_SHA1;
    $result = openssl_verify($stringToSign, $signature, $pubKey, $algo);
    return $result === 1 ? true : ($result === 0 ? false : null);
}

/* ══════════════════════════════════════════════════════════════════════════════════════════
   Envelope handling
   ═════════════════════════════════════════════════════════════════════════════════════════ */

$raw = (string)file_get_contents('php://input');
$env = json_decode($raw, true);
if (!is_array($env)) {
    http_response_code(200);   // never make SNS retry a payload we will never understand
    echo json_encode(['ok' => true, 'processed' => 0, 'note' => 'unparseable body']);
    exit;
}

$verified = sns_verify_signature($env);
if ($verified === false) {
    ses_webhook_log('REJECTED: SNS signature did not verify (type=' . (string)($env['Type'] ?? '?') . ')');
    http_response_code(403);
    echo json_encode(['ok' => false, 'error' => 'signature verification failed']);
    exit;
}
if ($verified === null) {
    ses_webhook_log('WARNING: could not verify SNS signature (openssl or cert fetch unavailable) — processing anyway');
}

$snsType = (string)($env['Type'] ?? ($_SERVER['HTTP_X_AMZ_SNS_MESSAGE_TYPE'] ?? ''));

/*
 * Confirming the subscription ourselves is what makes step 2 of the setup a single click. AWS
 * requires a GET on SubscribeURL before it will deliver anything; done manually that means
 * copying a URL out of the SNS console into a browser, and until it happens the subscription
 * sits in "Pending confirmation" while everything else looks correctly configured.
 */
if ($snsType === 'SubscriptionConfirmation') {
    $subUrl = (string)($env['SubscribeURL'] ?? '');
    if (!sns_is_amazon_sns_url($subUrl)) {
        // Same host rule as the cert: only ever call back into SNS itself, never an arbitrary
        // URL handed to us by an unauthenticated request.
        ses_webhook_log('REJECTED SubscriptionConfirmation: SubscribeURL is not an SNS host');
        http_response_code(400);
        echo json_encode(['ok' => false, 'error' => 'bad SubscribeURL']);
        exit;
    }
    $ch = curl_init($subUrl);
    curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 15]);
    curl_exec($ch);
    $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $err  = curl_error($ch);
    curl_close($ch);
    ses_webhook_log("SubscriptionConfirmation for topic " . (string)($env['TopicArn'] ?? '?')
                  . " -> HTTP $code" . ($err !== '' ? " ($err)" : '') . ($code === 200 ? ' — subscription confirmed' : ' — CONFIRMATION FAILED'));
    http_response_code(200);
    echo json_encode(['ok' => $code === 200, 'confirmed' => $code === 200]);
    exit;
}

if ($snsType === 'UnsubscribeConfirmation') {
    ses_webhook_log('UnsubscribeConfirmation received — this endpoint was removed from topic '
                  . (string)($env['TopicArn'] ?? '?') . '. Delivery and bounce counts will stop updating.');
    http_response_code(200);
    echo json_encode(['ok' => true]);
    exit;
}

/*
 * The SES event itself lives in the Message field as a JSON *string*. With "raw message
 * delivery" enabled on the subscription there is no envelope at all and the body IS the event —
 * accepted too, so a subscription configured either way works.
 */
$msg = null;
if (isset($env['Message']) && is_string($env['Message'])) {
    $msg = json_decode($env['Message'], true);
} elseif (isset($env['eventType']) || isset($env['notificationType'])) {
    $msg = $env;
}
if (!is_array($msg)) {
    http_response_code(200);
    echo json_encode(['ok' => true, 'processed' => 0, 'note' => 'no SES event in message']);
    exit;
}

/*
 * Two vocabularies for the same thing, because SES has two notification systems: configuration
 * set event destinations use `eventType` ("Delivery", "Bounce", "DeliveryDelay"), while the
 * older per-identity feedback notifications use `notificationType` ("Delivery", "Bounce",
 * "Complaint"). Reading both means a setup done either way is handled.
 */
$eventType = strtolower(trim((string)($msg['eventType'] ?? ($msg['notificationType'] ?? ''))));
$mail      = (array)($msg['mail'] ?? []);
$msgId     = (string)($mail['messageId'] ?? '');

// mail.tags is {name: [values]} — always a list, even for a single value.
$tags = (array)($mail['tags'] ?? []);
$rid  = '';
if (isset($tags['rid'])) {
    $ridTag = $tags['rid'];
    $rid = is_array($ridTag) ? (string)($ridTag[0] ?? '') : (string)$ridTag;
}

// First-party already (see the header comment) — claimed and dropped before any lookup work.
if ($eventType === 'open' || $eventType === 'click') {
    http_response_code(200);
    echo json_encode(['ok' => true, 'processed' => 0, 'note' => 'open/click tracked first-party']);
    exit;
}

/*
 * 'send' is SES acknowledging it accepted the API call — the worker already recorded that when
 * the request returned, so counting it would be redundant. 'delivery' is the receiving mail
 * server actually accepting the message, which is the real delivery signal.
 */
$typeMap = [
    'delivery'         => 'delivered',
    'bounce'           => 'bounce',
    'complaint'        => 'spamreport',
    'reject'           => 'dropped',
    'deliverydelay'    => 'deferred',
    'delivery delay'   => 'deferred',
    'subscription'     => 'unsubscribe',   // SES list-management unsubscribe link
    'send'             => null,
    'renderingfailure' => null,
];
$mapped = $typeMap[$eventType] ?? null;
if ($mapped === null) {
    http_response_code(200);
    echo json_encode(['ok' => true, 'processed' => 0, 'note' => "event '$eventType' not counted"]);
    exit;
}

/* ── find the recipient row ─────────────────────────────────────────────────────────────── */
$recipient = null;
if (preg_match('/^[a-f0-9]{32}$/', $rid)) {
    $stmt = $conn->prepare("SELECT id, campaign_id, email FROM email_campaign_recipients WHERE rid = ? LIMIT 1");
    $stmt->bind_param('s', $rid);
    $stmt->execute();
    $recipient = $stmt->get_result()->fetch_assoc();
    $stmt->close();
}
if (!$recipient && $msgId !== '') {
    $stmt = $conn->prepare("SELECT id, campaign_id, email FROM email_campaign_recipients WHERE esp_message_id = ? LIMIT 1");
    $stmt->bind_param('s', $msgId);
    $stmt->execute();
    $recipient = $stmt->get_result()->fetch_assoc();
    $stmt->close();
}

if (!$recipient) {
    /*
     * Not a campaign rid — hand it to the Journey engine, which keeps its own rids in
     * journey_messages. SES posts every event for the account to this one URL, so without this
     * hand-off journey emails would never receive a delivery confirmation.
     *
     * file_exists rather than a bare require_once: this tree deploys folder by folder and
     * requiring a file that has not been uploaded yet is fatal, which would take the campaign
     * receipts above down with it.
     */
    $sink = __DIR__ . '/../journeys/lib/JourneyWebhookSink.php';
    $claimed = false;
    if (file_exists($sink)) {
        require_once $sink;
        $claimed = journey_webhook_email_event($rid, $mapped, $msg);
    }
    if (!$claimed) {
        ses_webhook_log("unmatched $eventType event (rid='" . substr($rid, 0, 8) . "…', messageId='$msgId')");
    }
    http_response_code(200);
    echo json_encode(['ok' => true, 'processed' => $claimed ? 1 : 0]);
    exit;
}

$cid = (int)$recipient['campaign_id'];
$rowId = (int)$recipient['id'];

// The only place delivered_count grows. The worker's own "sent" means nothing more than
// "SES accepted the request", which is not the same claim.
if ($mapped === 'delivered') {
    $conn->query("UPDATE email_campaigns SET delivered_count = delivered_count + 1 WHERE id=$cid");
    http_response_code(200);
    echo json_encode(['ok' => true, 'processed' => 1]);
    exit;
}

$metaE = $conn->real_escape_string(json_encode($msg));
$conn->query("INSERT INTO email_campaign_events (campaign_id, recipient_id, event_type, meta)
              VALUES ($cid, $rowId, '$mapped', '$metaE')");

if ($mapped === 'bounce') {
    /*
     * SES classifies bounces itself and its vocabulary maps cleanly onto ours:
     *   Permanent    → hard  (the address does not exist / is suppressed)
     *   Transient    → soft  (mailbox full, message too large, temporarily refused)
     *   Undetermined → soft  (treated as soft ON PURPOSE — see below)
     *
     * Note this is the OPPOSITE default to the SendGrid and Elastic Email webhooks, which treat
     * an unrecognised classification as hard. That is right for them because their unknown case
     * usually IS a bad address, whereas SES reserves a distinct "Undetermined" for genuinely
     * ambiguous replies — and a hard bounce here permanently blocklists a real student.
     */
    $bounceType = (string)(($msg['bounce']['bounceType'] ?? '')) === 'Permanent' ? 'hard' : 'soft';
    $conn->query("UPDATE email_campaign_recipients SET status='bounced', bounced_at=NOW(), bounce_type='$bounceType' WHERE id=$rowId");
    $countCol = $bounceType === 'soft' ? 'soft_bounce_count' : 'hard_bounce_count';
    $conn->query("UPDATE email_campaigns SET bounce_count = bounce_count + 1, $countCol = $countCol + 1 WHERE id=$cid");

    // Hard bounce = permanently invalid, so blocklist it exactly as an unsubscribe would. Soft
    // bounces are left alone; the address may well work next week.
    if ($bounceType === 'hard' && !empty($recipient['email'])) {
        contact_upsert(['email' => $recipient['email']], lists_get_or_create_blocklist_id());
    }
} elseif ($mapped === 'spamreport') {
    $conn->query("UPDATE email_campaigns SET spam_count = spam_count + 1 WHERE id=$cid");
    // The strongest negative signal there is — a complaint filed with the mailbox provider,
    // which damages sending reputation for every future campaign. Never mail this address again.
    if (!empty($recipient['email'])) {
        contact_upsert(['email' => $recipient['email']], lists_get_or_create_blocklist_id(), 'Marked as spam via Amazon SES');
    }
} elseif ($mapped === 'unsubscribe') {
    $conn->query("UPDATE email_campaigns SET unsubscribe_count = unsubscribe_count + 1 WHERE id=$cid");
    if (!empty($recipient['email'])) {
        contact_upsert(['email' => $recipient['email']], lists_get_or_create_blocklist_id());
    }
} elseif ($mapped === 'dropped') {
    /*
     * A Reject means SES took the message and then refused to send it — almost always a virus
     * detected in an attachment. The recipient row is corrected from 'sent' to 'failed' because
     * nothing was ever transmitted; the address itself is fine, so nothing is blocklisted.
     */
    $reason = (string)($msg['reject']['reason'] ?? 'Rejected by Amazon SES');
    $reasonE = $conn->real_escape_string(mb_substr($reason, 0, 480));
    $conn->query("UPDATE email_campaign_recipients SET status='failed', error_message='$reasonE' WHERE id=$rowId");
}

http_response_code(200);
echo json_encode(['ok' => true, 'processed' => 1]);

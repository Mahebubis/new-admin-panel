<?php
/*
 * Public, unauthenticated 1x1 open-tracking pixel.
 * Embedded by lib/TrackingRewriter.php's inject_tracking() into every sent
 * campaign email.
 *
 * NOT every hit on this pixel is a human opening the mail — Apple Mail Privacy
 * Protection pre-fetches images on delivery, security gateways scan every URL, and
 * mail clients re-render the same message repeatedly. Those hits are recognized by
 * lib/BotDetector.php and recorded as 'open_bot' events instead: they still show up
 * in the database (so the filtering is auditable and reversible) but they never touch
 * open_count / unique_open_count. See BotDetector.php for the full reasoning, in
 * particular why Gmail's image proxy is explicitly NOT filtered.
 */
ini_set('display_errors', 0);
error_reporting(0);

// Serve the pixel FIRST — don't make the recipient's mail client wait on DB writes.
$gif = base64_decode('R0lGODlhAQABAIAAAAAAAP///ywAAAAAAQABAAACAUwAOw==');
header('Content-Type: image/gif');
header('Content-Length: ' . strlen($gif));
header('Cache-Control: no-store, no-cache, must-revalidate');
header('Pragma: no-cache');
echo $gif;

if (function_exists('fastcgi_finish_request')) {
    fastcgi_finish_request();
}

$rid = $_GET['rid'] ?? '';
if (!preg_match('/^[a-f0-9]{32}$/', $rid)) exit;

require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/lib/TrackingRewriter.php';
require_once __DIR__ . '/lib/BotDetector.php';

// is_test and sent_at are selected because both decide whether this hit counts:
// sent_at feeds the "too soon to be a human" rule, and a test-send recipient must never
// move the real campaign's numbers.
$stmt = $conn->prepare("SELECT id, campaign_id, opened_at, is_test, sent_at
                          FROM email_campaign_recipients WHERE rid = ? LIMIT 1");
$stmt->bind_param('s', $rid);
$stmt->execute();
$recipient = $stmt->get_result()->fetch_assoc();
$stmt->close();
if (!$recipient) exit;

$ip     = $conn->real_escape_string($_SERVER['REMOTE_ADDR'] ?? '');
$rawUa  = $_SERVER['HTTP_USER_AGENT'] ?? '';
$ua     = $conn->real_escape_string(substr($rawUa, 0, 490));
$device = classify_device_type($rawUa);

$secondsSinceSent = !empty($recipient['sent_at']) ? (time() - strtotime($recipient['sent_at'])) : null;
$reason = tracking_machine_reason($rawUa, $secondsSinceSent, $_SERVER['REQUEST_METHOD'] ?? 'GET');

// Collapse a burst of hits for the same recipient into the single open it really is.
// Only checked for otherwise-human-looking hits: a bot hit is already being discarded.
if ($reason === null) {
    $dupR = $conn->query("SELECT 1 FROM email_campaign_events
                           WHERE recipient_id = " . (int)$recipient['id'] . " AND event_type = 'open'
                             AND created_at >= DATE_SUB(NOW(), INTERVAL " . TRACKING_DEDUPE_SECONDS . " SECOND)
                           LIMIT 1");
    if ($dupR && $dupR->num_rows > 0) $reason = 'duplicate_within_' . TRACKING_DEDUPE_SECONDS . 's';
}

if ($reason !== null) {
    // Logged, never counted. bot_open_count exists so the report can show how much is
    // being filtered — a number that silently drops to zero is how a bad rule hides.
    $metaE = $conn->real_escape_string(json_encode(['filtered' => $reason]));
    $conn->query("INSERT INTO email_campaign_events (campaign_id, recipient_id, event_type, ip_address, user_agent, device_type, meta)
                  VALUES ({$recipient['campaign_id']}, {$recipient['id']}, 'open_bot', '$ip', '$ua', '$device', '$metaE')");
    if ((int)$recipient['is_test'] === 0) {
        $conn->query("UPDATE email_campaigns SET bot_open_count = bot_open_count + 1 WHERE id = " . (int)$recipient['campaign_id']);
    }
    exit;
}

$isFirstOpen = empty($recipient['opened_at']);
$conn->query("UPDATE email_campaign_recipients SET open_count = open_count + 1, opened_at = IFNULL(opened_at, NOW()) WHERE id = " . (int)$recipient['id']);

// A test send inserts a recipient row against the SAME campaign_id, so without this guard
// the admin previewing their own test email inflated the real campaign's open rate.
if ((int)$recipient['is_test'] === 0) {
    $conn->query("UPDATE email_campaigns SET open_count = open_count + 1" . ($isFirstOpen ? ", unique_open_count = unique_open_count + 1" : '') . " WHERE id = " . (int)$recipient['campaign_id']);
}

$conn->query("INSERT INTO email_campaign_events (campaign_id, recipient_id, event_type, ip_address, user_agent, device_type)
              VALUES ({$recipient['campaign_id']}, {$recipient['id']}, 'open', '$ip', '$ua', '$device')");

-- ===========================================================================
--  attachment_reupload_backup.sql          *** READ-ONLY — SELECTs ONLY ***
--
--  Backup queries for the "Re-upload attachment" feature
--  (Internships > Assignment Panel  and  Internships > Problem Statement).
--
--  A re-upload puts the SAME file on S3 again under a fresh key, then updates
--  only these columns on the EXISTING row:
--        file_url, file_key, file_name, file_type, file_size, mime_type
--  The primary key `id` is never touched, so every student submission that
--  points at that id keeps pointing at it.
--
--  NOTHING IN THIS FILE MODIFIES DATA. Every statement is a SELECT, so it is
--  safe to run as often as you like. The rollback/UPDATE statements live in a
--  separate file on purpose: attachment_reupload_revert.sql
--
--  HOW TO USE (phpMyAdmin):
--    Run QUERY 1 on its own -> Export the result grid to CSV -> keep the file.
--    That is the whole backup. Run QUERY 2 as well if you also want a
--    ready-made rollback script.
--
--  NOTE: phpMyAdmin only shows the result of the LAST statement when several
--  are run together, so run QUERY 1 and QUERY 2 SEPARATELY.
-- ===========================================================================


-- ===========================================================================
-- QUERY 1 — THE BACKUP.  One query, every attachment URL in the system
--    (assignments + problem statements + problem-statement items).
--    Export the result to CSV/Excel and keep it. `source_table` + `id` is all
--    you need to put any row back.
-- ===========================================================================
SELECT
    'internship_assignment_attachments' AS source_table,
    a.id                                AS id,
    a.assignment_id                     AS parent_id,
    asg.internship_id                   AS internship_id,
    asg.title                           AS parent_title,
    a.title                             AS title,
    a.kind                              AS kind,
    a.file_url                          AS file_url,
    a.file_key                          AS file_key,
    a.file_name                         AS file_name,
    a.file_type                         AS file_type,
    a.file_size                         AS file_size,
    a.mime_type                         AS mime_type,
    a.status                            AS status,
    a.created_at                        AS created_at
FROM internship_assignment_attachments a
LEFT JOIN internship_assignments asg ON asg.id = a.assignment_id

UNION ALL

SELECT
    'internship_problem_statements',
    p.id,
    p.internship_id,
    p.internship_id,
    NULL,
    p.title,
    'file',
    p.file_url,
    p.file_key,
    p.file_name,
    p.file_type,
    p.file_size,
    p.mime_type,
    p.status,
    p.created_at
FROM internship_problem_statements p

UNION ALL

SELECT
    'internship_problem_statement_items',
    i.id,
    i.statement_id,
    p2.internship_id,
    p2.title,
    i.label,
    i.kind,
    i.file_url,
    i.file_key,
    i.file_name,
    i.file_type,
    i.file_size,
    i.mime_type,
    i.status,
    i.created_at
FROM internship_problem_statement_items i
LEFT JOIN internship_problem_statements p2 ON p2.id = i.statement_id

ORDER BY source_table, id;


-- ---------------------------------------------------------------------------
-- 1b. Want a shorter sheet? Add this WHERE to each of the three SELECTs above
--     to skip external links and rows with no uploaded file:
--         WHERE file_key <> '' AND file_key IS NOT NULL
-- ---------------------------------------------------------------------------


-- ===========================================================================
-- QUERY 2 — BACKUP AS READY-TO-RUN SQL.  Generates the exact UPDATE
--    statements that restore today's values. Copy the `restore_sql` column
--    into a .sql file and you have a complete rollback script that does not
--    depend on the audit log at all.
--
--    This query only READS — it produces text, it does not execute anything.
-- ===========================================================================
SELECT CONCAT(
    'UPDATE internship_assignment_attachments SET ',
    'file_url=',  QUOTE(file_url),  ', ',
    'file_key=',  QUOTE(file_key),  ', ',
    'file_name=', QUOTE(COALESCE(file_name, '')), ', ',
    'file_type=', QUOTE(COALESCE(file_type, '')), ', ',
    'file_size=', file_size, ', ',
    'mime_type=', QUOTE(COALESCE(mime_type, '')),
    ' WHERE id=', id, ';'
) AS restore_sql
FROM internship_assignment_attachments
UNION ALL
SELECT CONCAT(
    'UPDATE internship_problem_statements SET ',
    'file_url=',  QUOTE(file_url),  ', ',
    'file_key=',  QUOTE(file_key),  ', ',
    'file_name=', QUOTE(COALESCE(file_name, '')), ', ',
    'file_type=', QUOTE(COALESCE(file_type, '')), ', ',
    'file_size=', file_size, ', ',
    'mime_type=', QUOTE(COALESCE(mime_type, '')),
    ' WHERE id=', id, ';'
) FROM internship_problem_statements
UNION ALL
SELECT CONCAT(
    'UPDATE internship_problem_statement_items SET ',
    'file_url=',  QUOTE(COALESCE(file_url, '')), ', ',
    'file_key=',  QUOTE(COALESCE(file_key, '')), ', ',
    'file_name=', QUOTE(COALESCE(file_name, '')), ', ',
    'file_type=', QUOTE(COALESCE(file_type, '')), ', ',
    'file_size=', file_size, ', ',
    'mime_type=', QUOTE(COALESCE(mime_type, '')),
    ' WHERE id=', id, ';'
) FROM internship_problem_statement_items;


-- ===========================================================================
-- QUERY 3 — the audit log, newest first.
--
--    Every re-upload done from the admin panel writes one row here holding the
--    old AND the new URL. The table is created automatically the first time
--    assignments_api.php / problem_statements_api.php runs, so until the
--    backend is deployed this query returns:
--        #1146 - Table '…internship_attachment_reupload_log' doesn't exist
--    That error is harmless — it just means no re-upload has happened yet.
-- ===========================================================================
SELECT id AS log_id, source_table, record_id,
       old_file_url, new_file_url, reverted, created_by, created_at
FROM internship_attachment_reupload_log
ORDER BY id DESC;


-- ===========================================================================
-- OPTIONAL — physical snapshot tables (the cheapest possible rollback).
--    These DO create tables, so they are left commented out. Uncomment and run
--    once before you start re-uploading; drop them when you're happy.
-- ===========================================================================
-- CREATE TABLE bkp_assignment_attachments_20260803  AS SELECT * FROM internship_assignment_attachments;
-- CREATE TABLE bkp_problem_statements_20260803      AS SELECT * FROM internship_problem_statements;
-- CREATE TABLE bkp_problem_statement_items_20260803 AS SELECT * FROM internship_problem_statement_items;

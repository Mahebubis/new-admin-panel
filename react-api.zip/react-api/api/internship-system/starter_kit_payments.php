<?php
/**
 * starter_kit_payments.php
 * ---------------------------------------------------------------------------
 * Admin API for "Purchased Starter Kit" (the 99 Store checkout).
 *
 * Reads the `ninety_nine_store_orders` table. The table is self-contained —
 * the buyer's details are captured at checkout (guest flow), so there is no
 * join to `users` any more. One order can carry SEVERAL courses: `courses`
 * is a JSON array of {name, slug, price} and `course_count` is its length,
 * while `course_slug` / `course_name` hold the first (primary) course.
 *
 * Columns in ninety_nine_store_orders:
 *   id, first_name, last_name, email, phone_number, state, course_slug,
 *   course_name, courses (json), course_count, batch, order_id,
 *   razorpay_order_id, payment_id, provider, amount, status,
 *   created_at, updated_at
 *
 * Routes (POST or GET ?action=):
 *   action=fetch_stats  &range=&start=&end=&provider=
 *                                 -> success/initiated/failed counts + sums
 *   action=fetch_list   &status=&range=&start=&end=&provider=&page=&per_page=
 *                                 -> paginated records + total
 *   action=export       &status=&range=&start=&end=&provider=
 *                                 -> every matching record (no pagination)
 *   action=fetch_courses          -> the store catalogue ({slug,name,price})
 *   action=lookup_email &email=   -> name / phone for the add-order popup
 *   action=create_order &email=&first_name=&last_name=&phone=&courses=&amount=
 *                       &status=&provider=&order_id=&payment_id=&created_at=
 *                                 -> inserts one admin-entered order
 *
 * Responses: { "status":"success", "data":{...} } | { "status":"error", ... }
 *
 * Mirrors the bootstrap / error-handling style of problem_statements_api.php.
 * ---------------------------------------------------------------------------
 */

@ini_set('display_errors', '0');
error_reporting(E_ALL);

define('SK_LOG_FILE', __DIR__ . '/starter_kit_payments_errors.log');
/* every course in the store is a flat ₹99 — the add-order form prices a cart
   off this, and the admin can still override the total by hand */
define('SK_UNIT_PRICE', 99);
@ini_set('log_errors', '1');
@ini_set('error_log', SK_LOG_FILE);

function sk_log($label, $msg) {
    $line = '[' . date('Y-m-d H:i:s') . '] ' . $label . ': ' . $msg
          . '  {' . ($_SERVER['REQUEST_METHOD'] ?? 'CLI') . ' '
          . ($_SERVER['REQUEST_URI'] ?? '') . '}' . PHP_EOL;
    @file_put_contents(SK_LOG_FILE, $line, FILE_APPEND | LOCK_EX);
}

set_error_handler(function ($no, $str, $file, $line) {
    if (strpos($file, 'starter_kit_payments.php') !== false) {
        sk_log('PHP-ERROR(' . $no . ')', $str . ' in ' . $file . ':' . $line);
    }
    return true;
});

/* shared bootstrap — provides global $conn (same as the other endpoints here) */
ob_start();
chdir('/home/istudio/public_html/cit/common');
include '/home/istudio/public_html/cit/common/helper.php';
ob_clean();

header('Content-Type: application/json');

register_shutdown_function(function () {
    $e = error_get_last();
    if ($e && in_array($e['type'], [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR], true)) {
        sk_log('FATAL', $e['message'] . ' in ' . $e['file'] . ':' . $e['line']);
        if (!headers_sent()) header('Content-Type: application/json');
        echo json_encode(['status' => 'error', 'message' => 'Server error: ' . $e['message']]);
    }
});

set_exception_handler(function ($e) {
    sk_log('EXCEPTION', get_class($e) . ': ' . $e->getMessage()
        . ' in ' . $e->getFile() . ':' . $e->getLine());
    if (!headers_sent()) {
        http_response_code(500);
        header('Content-Type: application/json');
    }
    echo json_encode(['status' => 'error', 'message' => 'Server error: ' . $e->getMessage()]);
    exit;
});

/* ====== helpers ====== */
function sk_out($p) { echo json_encode($p); exit; }
function sk_error($m, $c = 400) {
    sk_log('API-ERROR(' . $c . ')', $m);
    http_response_code($c);
    sk_out(['status' => 'error', 'message' => $m]);
}
function sk_ok($d = null, $m = '') {
    $r = ['status' => 'success'];
    if ($d !== null) $r['data'] = $d;
    if ($m !== '')   $r['message'] = $m;
    sk_out($r);
}

/* Build a safe SQL date-range condition on `created_at`.
   Returns a string that is always a valid boolean expression. */
function sk_date_condition($range, $start, $end) {
    switch ($range) {
        case 'today':
            return "DATE(o.created_at) = CURDATE()";
        case 'yesterday':
            return "DATE(o.created_at) = (CURDATE() - INTERVAL 1 DAY)";
        case 'last7':
            // last 7 days including today
            return "DATE(o.created_at) >= (CURDATE() - INTERVAL 6 DAY)";
        case 'custom':
            $re = '/^\d{4}-\d{2}-\d{2}$/';
            if (!preg_match($re, $start) || !preg_match($re, $end)) {
                sk_error('Invalid custom date range — expected YYYY-MM-DD for both start and end');
            }
            if ($start > $end) { $t = $start; $start = $end; $end = $t; }
            return "DATE(o.created_at) BETWEEN '$start' AND '$end'";
        case 'all':
        default:
            return "1";
    }
}

/* Build a safe provider condition. Empty / "all" => no filter. */
function sk_provider_condition($conn, $provider) {
    if ($provider === '' || $provider === 'all') return "1";
    if (!in_array($provider, ['cashfree', 'razorpay'], true)) {
        sk_error('Invalid provider — must be cashfree, razorpay or all');
    }
    $p = $conn->real_escape_string($provider);
    return "o.provider = '$p'";
}

/* Normalise one DB row for the panel:
   - name        = first_name + last_name
   - phone       = phone_number (legacy key kept for the UI)
   - courses     = [{name, slug, price}, …] — always an array, even for the
                   older single-course rows where `courses` is NULL
   - course_count= trusted from the column, falling back to the array length
   - paid_at     = updated_at once paid, else created_at */
function sk_shape_row($r) {
    $r['name']  = trim(($r['first_name'] ?? '') . ' ' . ($r['last_name'] ?? ''));
    $r['phone'] = $r['phone_number'] ?? '';

    $list = [];
    if (!empty($r['courses'])) {
        $decoded = json_decode($r['courses'], true);
        if (is_array($decoded)) {
            foreach ($decoded as $c) {
                if (is_string($c)) {
                    $list[] = ['name' => $c, 'slug' => '', 'price' => null];
                } elseif (is_array($c)) {
                    $list[] = [
                        'name'  => $c['name']  ?? $c['course_name'] ?? $c['title'] ?? ($c['slug'] ?? ''),
                        'slug'  => $c['slug']  ?? $c['course_slug'] ?? '',
                        'price' => isset($c['price']) ? (float)$c['price'] : null,
                    ];
                }
            }
        }
    }
    /* pre-multi-course rows (and any row with an unparseable JSON blob) */
    if (!$list && (($r['course_name'] ?? '') !== '' || ($r['course_slug'] ?? '') !== '')) {
        $list[] = [
            'name'  => $r['course_name'] ?? '',
            'slug'  => $r['course_slug'] ?? '',
            'price' => null,
        ];
    }

    $r['courses']      = $list;
    $r['course_count'] = (int)($r['course_count'] ?? 0) ?: count($list);
    $r['paid_at']      = ($r['status'] === 'success') ? $r['updated_at'] : $r['created_at'];
    return $r;
}

/* every column the panel renders / exports */
function sk_select_columns() {
    return "o.id,
            o.first_name,
            o.last_name,
            o.email,
            o.phone_number,
            o.state,
            o.course_slug,
            o.course_name,
            o.courses,
            o.course_count,
            o.batch,
            o.order_id,
            o.razorpay_order_id,
            o.payment_id,
            o.provider,
            o.amount,
            o.status,
            o.created_at,
            o.updated_at";
}

global $conn;
if (!$conn) sk_error('Database connection failed', 500);

$action   = $_REQUEST['action']   ?? '';
$range    = $_REQUEST['range']    ?? 'today';
$start    = trim($_REQUEST['start'] ?? '');
$end      = trim($_REQUEST['end']   ?? '');
$provider = strtolower(trim($_REQUEST['provider'] ?? 'all'));

$dateCond     = sk_date_condition($range, $start, $end);
$providerCond = sk_provider_condition($conn, $provider);

/* ════════════════════════════════════════
   FETCH STATS — success / initiated / failed totals for the range.
   *_courses sums the number of courses sold, which is what the 99 Store
   actually moves — an order of 3 courses is 1 order but 3 courses.
════════════════════════════════════════ */
if ($action === 'fetch_stats') {
    $sql = "SELECT
                SUM(o.status = 'success')                              AS success_count,
                SUM(o.status = 'initiated')                            AS initiated_count,
                SUM(o.status = 'failed')                               AS failed_count,
                COALESCE(SUM(CASE WHEN o.status = 'success'   THEN o.amount ELSE 0 END), 0) AS success_amount,
                COALESCE(SUM(CASE WHEN o.status = 'initiated' THEN o.amount ELSE 0 END), 0) AS initiated_amount,
                COALESCE(SUM(CASE WHEN o.status = 'failed'    THEN o.amount ELSE 0 END), 0) AS failed_amount,
                COALESCE(SUM(CASE WHEN o.status = 'success'   THEN GREATEST(o.course_count, 1) ELSE 0 END), 0) AS success_courses,
                COALESCE(SUM(CASE WHEN o.status = 'initiated' THEN GREATEST(o.course_count, 1) ELSE 0 END), 0) AS initiated_courses,
                COALESCE(SUM(CASE WHEN o.status = 'failed'    THEN GREATEST(o.course_count, 1) ELSE 0 END), 0) AS failed_courses
            FROM ninety_nine_store_orders o
            WHERE $dateCond AND $providerCond";

    $res = $conn->query($sql);
    if ($res === false) sk_error('Stats query failed: ' . $conn->error, 500);
    $row = $res->fetch_assoc() ?: [];
    $conn->close();

    sk_ok([
        'success_count'     => (int)($row['success_count']     ?? 0),
        'initiated_count'   => (int)($row['initiated_count']   ?? 0),
        'failed_count'      => (int)($row['failed_count']      ?? 0),
        'success_amount'    => (float)($row['success_amount']   ?? 0),
        'initiated_amount'  => (float)($row['initiated_amount'] ?? 0),
        'failed_amount'     => (float)($row['failed_amount']    ?? 0),
        'success_courses'   => (int)($row['success_courses']   ?? 0),
        'initiated_courses' => (int)($row['initiated_courses'] ?? 0),
        'failed_courses'    => (int)($row['failed_courses']    ?? 0),
    ]);
}

/* ════════════════════════════════════════
   FETCH LIST — paginated records for one status
════════════════════════════════════════ */
if ($action === 'fetch_list') {
    $status = $_REQUEST['status'] ?? 'success';
    if (!in_array($status, ['success', 'initiated', 'failed'], true)) {
        sk_error('Invalid status — must be success, initiated or failed');
    }

    $page     = max(1,  (int)($_REQUEST['page']     ?? 1));
    $perPage  = (int)($_REQUEST['per_page'] ?? 20);
    if (!in_array($perPage, [20, 50, 100, 200], true)) $perPage = 20;
    $offset   = ($page - 1) * $perPage;

    $where = "$dateCond AND $providerCond AND o.status = '$status'";

    /* total count */
    $cRes = $conn->query("SELECT COUNT(*) AS c FROM ninety_nine_store_orders o WHERE $where");
    if ($cRes === false) sk_error('Count query failed: ' . $conn->error, 500);
    $total = (int)($cRes->fetch_assoc()['c'] ?? 0);

    /* main data */
    $sql = "SELECT " . sk_select_columns() . "
            FROM ninety_nine_store_orders o
            WHERE $where
            ORDER BY o.id DESC
            LIMIT $perPage OFFSET $offset";

    $res = $conn->query($sql);
    if ($res === false) sk_error('List query failed: ' . $conn->error, 500);

    $rows = [];
    while ($r = $res->fetch_assoc()) $rows[] = sk_shape_row($r);
    $conn->close();

    sk_ok([
        'rows'     => $rows,
        'total'    => $total,
        'page'     => $page,
        'per_page' => $perPage,
    ]);
}

/* ════════════════════════════════════════
   EXPORT — every matching record (no pagination) for the date range.
   status = success | initiated | failed | all (default all)
════════════════════════════════════════ */
if ($action === 'export') {
    $status = $_REQUEST['status'] ?? 'all';
    if (!in_array($status, ['success', 'initiated', 'failed', 'all'], true)) {
        sk_error('Invalid status — must be success, initiated, failed or all');
    }
    $statusCond = ($status === 'all') ? "1" : "o.status = '$status'";

    $sql = "SELECT " . sk_select_columns() . "
            FROM ninety_nine_store_orders o
            WHERE $dateCond AND $providerCond AND $statusCond
            ORDER BY o.id DESC";

    $res = $conn->query($sql);
    if ($res === false) sk_error('Export query failed: ' . $conn->error, 500);

    $rows = [];
    while ($r = $res->fetch_assoc()) $rows[] = sk_shape_row($r);
    $conn->close();

    sk_ok(['rows' => $rows, 'total' => count($rows)]);
}

/* ════════════════════════════════════════
   FETCH COURSES — the ₹99 store catalogue, derived from what has actually
   been sold. Slugs are the contract between the store and the LMS, so the
   list is grouped by slug and the most-sold name wins; the hard-coded
   fallback only ever fires on an empty table.
════════════════════════════════════════ */
if ($action === 'fetch_courses') {
    $courses = [];

    /* the JSON cart carries the authoritative {name, slug, price} triples,
       so every row is unpacked rather than trusting course_slug alone */
    $res = $conn->query("SELECT o.course_slug, o.course_name, o.courses, o.amount, o.course_count
                         FROM ninety_nine_store_orders o
                         ORDER BY o.id DESC
                         LIMIT 2000");
    if ($res === false) sk_error('Course query failed: ' . $conn->error, 500);

    while ($r = $res->fetch_assoc()) {
        $shaped = sk_shape_row($r);
        $list   = $shaped['courses'];
        /* a single-course order's amount IS that course's price */
        $unit = (count($list) === 1 && (float)$r['amount'] > 0) ? (float)$r['amount'] : null;
        foreach ($list as $c) {
            $slug = trim((string)$c['slug']);
            $name = trim((string)$c['name']);
            if ($slug === '' && $name === '') continue;
            $key = strtolower($slug !== '' ? $slug : $name);
            if (!isset($courses[$key])) {
                $courses[$key] = [
                    'slug'  => $slug !== '' ? $slug : $key,
                    'name'  => $name !== '' ? $name : $slug,
                    'price' => $c['price'] !== null ? (float)$c['price'] : $unit,
                    'count' => 0,
                ];
            }
            if ($courses[$key]['price'] === null && $c['price'] !== null) {
                $courses[$key]['price'] = (float)$c['price'];
            }
            $courses[$key]['count']++;
        }
    }
    $conn->close();

    $courses = array_values($courses);
    usort($courses, function ($a, $b) { return $b['count'] - $a['count']; });
    foreach ($courses as &$c) { if ($c['price'] === null) $c['price'] = SK_UNIT_PRICE; }
    unset($c);

    if (!$courses) {
        $courses = [
            ['slug' => 'resume',   'name' => 'ATS Resume Course (2026)',               'price' => SK_UNIT_PRICE, 'count' => 0],
            ['slug' => 'linkedin', 'name' => 'LinkedIn Personal Branding Course (2026)','price' => SK_UNIT_PRICE, 'count' => 0],
            ['slug' => 'cloud-ai', 'name' => 'Prompt Engineering Course (2026)',        'price' => SK_UNIT_PRICE, 'count' => 0],
        ];
    }

    sk_ok(['courses' => $courses, 'unit_price' => SK_UNIT_PRICE]);
}

/* ════════════════════════════════════════
   LOOKUP EMAIL — pre-fill the "Add Order" popup.
   `users` is the primary source (a real account); the buyer's own last store
   order is the fallback, because the checkout is a guest flow that often
   captures a name the account never had.
════════════════════════════════════════ */
if ($action === 'lookup_email') {
    $email = strtolower(trim($_REQUEST['email'] ?? ''));
    if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        sk_error('Enter a valid email address');
    }
    $ee = $conn->real_escape_string($email);

    $out = [
        'found'      => false,
        'from'       => '',
        'user_id'    => 0,
        'first_name' => '',
        'last_name'  => '',
        'phone'      => '',
        'state'      => '',
        'batch'      => '',
        'orders'     => 0,
    ];

    $uRes = $conn->query("SELECT user_id, fname, lname, name, phone
                          FROM users WHERE LOWER(email) = '$ee' LIMIT 1");
    if ($uRes && $uRes->num_rows) {
        $u     = $uRes->fetch_assoc();
        $first = trim((string)($u['fname'] ?? ''));
        $last  = trim((string)($u['lname'] ?? ''));
        /* older accounts only ever filled `name` */
        if ($first === '' && trim((string)($u['name'] ?? '')) !== '') {
            $parts = preg_split('/\s+/', trim((string)$u['name']), 2);
            $first = $parts[0] ?? '';
            $last  = $parts[1] ?? '';
        }
        $out['found']      = true;
        $out['from']       = 'account';
        $out['user_id']    = (int)$u['user_id'];
        $out['first_name'] = $first;
        $out['last_name']  = $last;
        $out['phone']      = preg_replace('/[^0-9+]/', '', (string)($u['phone'] ?? ''));
    }

    /* the buyer's own last order fills whatever the account did not */
    $oRes = $conn->query("SELECT first_name, last_name, phone_number, state, batch
                          FROM ninety_nine_store_orders
                          WHERE LOWER(email) = '$ee'
                          ORDER BY id DESC LIMIT 1");
    if ($oRes && $oRes->num_rows) {
        $o = $oRes->fetch_assoc();
        if (!$out['found']) { $out['found'] = true; $out['from'] = 'order'; }
        if ($out['first_name'] === '') $out['first_name'] = (string)$o['first_name'];
        if ($out['last_name']  === '') $out['last_name']  = (string)$o['last_name'];
        if ($out['phone']      === '') $out['phone']      = (string)$o['phone_number'];
        $out['state'] = (string)($o['state'] ?? '');
        $out['batch'] = (string)($o['batch'] ?? '');
    }

    $cRes = $conn->query("SELECT COUNT(*) AS c FROM ninety_nine_store_orders WHERE LOWER(email) = '$ee'");
    if ($cRes) $out['orders'] = (int)($cRes->fetch_assoc()['c'] ?? 0);

    $conn->close();
    sk_ok($out);
}

/* ════════════════════════════════════════
   CREATE ORDER — an admin-entered starter-kit purchase.
   created_at AND updated_at are both written from the picked date-time (not
   NOW()) — that is the point of the form: a back-dated purchase has to land
   in the range the admin is reconciling, and the list reads `paid_at` off
   updated_at for a successful order. from_main stays 'no' and source stays
   'store' so the row reads as an ordinary ₹99 store order.
════════════════════════════════════════ */
if ($action === 'create_order') {
    $email = strtolower(trim($_REQUEST['email'] ?? ''));
    $first = trim($_REQUEST['first_name'] ?? '');
    $last  = trim($_REQUEST['last_name']  ?? '');
    $phone = preg_replace('/[^0-9+]/', '', trim($_REQUEST['phone'] ?? ''));
    $st    = trim($_REQUEST['status'] ?? 'success');
    $prov  = strtolower(trim($_REQUEST['provider'] ?? ''));
    $oid   = trim($_REQUEST['order_id']   ?? '');
    $pid   = trim($_REQUEST['payment_id'] ?? '');
    $when  = trim($_REQUEST['created_at'] ?? '');
    $amtIn = trim($_REQUEST['amount'] ?? '');

    if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) sk_error('Enter a valid email address');
    if ($first === '') sk_error('First name is required');
    if ($last  === '') sk_error('Last name is required');
    if (strlen(preg_replace('/[^0-9]/', '', $phone)) < 10) sk_error('Enter a valid phone number (at least 10 digits)');
    if (!in_array($st, ['success', 'initiated', 'failed'], true)) sk_error('Invalid status');
    if (!in_array($prov, ['cashfree', 'razorpay'], true)) sk_error('Select a payment provider');
    if ($oid === '') sk_error('Order ID is required');
    if ($pid === '') sk_error('Payment ID is required');
    if ($amtIn === '' || !is_numeric($amtIn) || (float)$amtIn <= 0) sk_error('Enter a valid amount');

    /* datetime-local sends YYYY-MM-DDTHH:MM — seconds are optional */
    if (!preg_match('/^(\d{4}-\d{2}-\d{2})[T ](\d{2}:\d{2})(:\d{2})?$/', $when, $m)) {
        sk_error('Pick a valid date and time for the order');
    }
    $when = $m[1] . ' ' . $m[2] . (isset($m[3]) ? $m[3] : ':00');
    if (strtotime($when) === false) sk_error('Pick a valid date and time for the order');

    /* courses — JSON array of {name, slug, price} straight from the picker */
    $list = json_decode($_REQUEST['courses'] ?? '', true);
    if (!is_array($list) || !$list) sk_error('Select at least one course');

    $courses = [];
    foreach ($list as $c) {
        if (!is_array($c)) continue;
        $cn = trim((string)($c['name'] ?? ''));
        $cs = trim((string)($c['slug'] ?? ''));
        if ($cn === '' && $cs === '') continue;
        $courses[] = [
            'name'  => $cn !== '' ? $cn : $cs,
            'slug'  => $cs !== '' ? $cs : $cn,
            'price' => isset($c['price']) && is_numeric($c['price']) ? (float)$c['price'] : SK_UNIT_PRICE,
        ];
    }
    if (!$courses) sk_error('Select at least one course');

    $amount = (float)$amtIn;
    $json   = json_encode($courses, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

    /* an admin can retype an id that already exists — nudge rather than
       silently minting a duplicate reference */
    $oidE = $conn->real_escape_string($oid);
    $dup  = $conn->query("SELECT id FROM ninety_nine_store_orders WHERE order_id = '$oidE' LIMIT 1");
    if ($dup && $dup->num_rows) sk_error('Order ID ' . $oid . ' already exists — regenerate it');

    /* attach the account when the email has one; the guest flow leaves it NULL */
    $ee  = $conn->real_escape_string($email);
    $uid = 0;
    $uR  = $conn->query("SELECT user_id FROM users WHERE LOWER(email) = '$ee' LIMIT 1");
    if ($uR && $uR->num_rows) $uid = (int)$uR->fetch_assoc()['user_id'];

    $e = function ($v) use ($conn) { return $conn->real_escape_string((string)$v); };

    $sql = "INSERT INTO ninety_nine_store_orders
                (user_id, first_name, last_name, email, phone_number, state,
                 course_slug, course_name, courses, course_count, batch,
                 order_id, razorpay_order_id, payment_id, provider, source,
                 from_main, amount, status, created_at, updated_at)
            VALUES ("
        . ($uid > 0 ? $uid : 'NULL') . ",
                 '" . $e($first) . "',
                 '" . $e($last)  . "',
                 '" . $e($email) . "',
                 '" . $e($phone) . "',
                 NULL,
                 '" . $e($courses[0]['slug']) . "',
                 '" . $e($courses[0]['name']) . "',
                 '" . $e($json) . "',
                 " . count($courses) . ",
                 NULL,
                 '" . $e($oid) . "',
                 NULL,
                 '" . $e($pid) . "',
                 '" . $e($prov) . "',
                 'store',
                 'no',
                 $amount,
                 '" . $e($st) . "',
                 '" . $e($when) . "',
                 '" . $e($when) . "')";

    if (!$conn->query($sql)) sk_error('Insert failed: ' . $conn->error, 500);
    $newId = (int)$conn->insert_id;

    $res = $conn->query("SELECT " . sk_select_columns() . "
                         FROM ninety_nine_store_orders o WHERE o.id = $newId LIMIT 1");
    $row = ($res && $res->num_rows) ? sk_shape_row($res->fetch_assoc()) : null;
    $conn->close();

    sk_ok(['id' => $newId, 'row' => $row, 'user_id' => $uid], 'Order added for ' . $email);
}

sk_error('Unknown action: ' . $action, 404);

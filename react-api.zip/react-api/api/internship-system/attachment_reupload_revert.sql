-- ===========================================================================
--  attachment_reupload_revert.sql        *** THIS FILE MODIFIES DATA ***
--
--  Rollback for the "Re-upload attachment" feature. Every statement here is an
--  UPDATE. Do NOT run this file top-to-bottom "just to see" — run only the
--  section you actually want, and take the backup first (see
--  attachment_reupload_backup.sql, QUERY 1).
--
--  What a revert does: writes the OLD file_url / file_key / file_name /
--  file_type / file_size / mime_type back onto the SAME record id. Ids are
--  never changed, so student submissions linked to them are unaffected.
--
--  Two independent ways to roll back:
--    A) from the audit log  (sections 1–2 below) — automatic, no typing
--    B) from your CSV backup (section 3)         — manual, per record
-- ===========================================================================


-- ===========================================================================
-- 0. LOOK FIRST — what would be reverted? (read-only, safe)
-- ===========================================================================
SELECT id AS log_id, source_table, record_id,
       old_file_url, new_file_url, reverted, created_by, created_at
FROM internship_attachment_reupload_log
WHERE reverted = 0
ORDER BY id DESC;


-- ===========================================================================
-- 1. REVERT EVERYTHING from the audit log.
--    Run 1a, 1b, 1c — then 1d to close the log rows.
--
--    If the SAME record was re-uploaded more than once, several log rows match
--    and you want the FIRST (original) one. Uncomment the `AND l.id = (…)`
--    line in each statement to guarantee that.
-- ===========================================================================

-- 1a. assignment attachments
UPDATE internship_assignment_attachments t
JOIN internship_attachment_reupload_log l
  ON l.record_id = t.id
 AND l.source_table = 'internship_assignment_attachments'
 AND l.reverted = 0
-- AND l.id = (SELECT MIN(l2.id) FROM internship_attachment_reupload_log l2
--             WHERE l2.source_table = l.source_table AND l2.record_id = l.record_id)
SET t.file_url  = l.old_file_url,
    t.file_key  = l.old_file_key,
    t.file_name = l.old_file_name,
    t.file_type = l.old_file_type,
    t.file_size = l.old_file_size,
    t.mime_type = l.old_mime_type;

-- 1b. problem statements (the statement's own file)
UPDATE internship_problem_statements t
JOIN internship_attachment_reupload_log l
  ON l.record_id = t.id
 AND l.source_table = 'internship_problem_statements'
 AND l.reverted = 0
-- AND l.id = (SELECT MIN(l2.id) FROM internship_attachment_reupload_log l2
--             WHERE l2.source_table = l.source_table AND l2.record_id = l.record_id)
SET t.file_url  = l.old_file_url,
    t.file_key  = l.old_file_key,
    t.file_name = l.old_file_name,
    t.file_type = l.old_file_type,
    t.file_size = l.old_file_size,
    t.mime_type = l.old_mime_type;

-- 1c. problem statement resources / datasets
UPDATE internship_problem_statement_items t
JOIN internship_attachment_reupload_log l
  ON l.record_id = t.id
 AND l.source_table = 'internship_problem_statement_items'
 AND l.reverted = 0
-- AND l.id = (SELECT MIN(l2.id) FROM internship_attachment_reupload_log l2
--             WHERE l2.source_table = l.source_table AND l2.record_id = l.record_id)
SET t.file_url  = l.old_file_url,
    t.file_key  = l.old_file_key,
    t.file_name = l.old_file_name,
    t.file_type = l.old_file_type,
    t.file_size = l.old_file_size,
    t.mime_type = l.old_mime_type;

-- 1d. close the log rows (run only after 1a–1c succeeded)
UPDATE internship_attachment_reupload_log
SET reverted = 1, reverted_at = NOW()
WHERE reverted = 0;


-- ===========================================================================
-- 2. REVERT ONE RECORD from the audit log — put the log_id from section 0 in.
-- ===========================================================================
-- UPDATE internship_assignment_attachments t
-- JOIN internship_attachment_reupload_log l ON l.record_id = t.id
-- SET t.file_url  = l.old_file_url,
--     t.file_key  = l.old_file_key,
--     t.file_name = l.old_file_name,
--     t.file_type = l.old_file_type,
--     t.file_size = l.old_file_size,
--     t.mime_type = l.old_mime_type
-- WHERE l.id = <LOG_ID> AND l.source_table = 'internship_assignment_attachments';
--
-- UPDATE internship_attachment_reupload_log
-- SET reverted = 1, reverted_at = NOW() WHERE id = <LOG_ID>;


-- ===========================================================================
-- 3. REVERT ONE RECORD BY HAND, from the CSV backup sheet.
--    Paste the old values from your export; the id stays exactly the same.
--    Swap the table name for internship_problem_statements or
--    internship_problem_statement_items as needed.
-- ===========================================================================
-- UPDATE internship_assignment_attachments
-- SET file_url  = 'https://…OLD-URL…',
--     file_key  = 'assignments/39/2025/11/asg_xxx.pdf',
--     file_name = 'DA Assignment 1 Excel SQL.pdf',
--     file_type = 'pdf',
--     file_size = 11264,
--     mime_type = 'application/pdf'
-- WHERE id = 123;


-- ===========================================================================
-- 4. RESTORE FROM A SNAPSHOT TABLE (if you created one before starting).
-- ===========================================================================
-- UPDATE internship_assignment_attachments t
-- JOIN bkp_assignment_attachments_20260803 b ON b.id = t.id
-- SET t.file_url = b.file_url, t.file_key = b.file_key, t.file_name = b.file_name,
--     t.file_type = b.file_type, t.file_size = b.file_size, t.mime_type = b.mime_type;

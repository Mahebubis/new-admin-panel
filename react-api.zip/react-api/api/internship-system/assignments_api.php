<?php
/**
 * assignments_api.php
 * ---------------------------------------------------------------------------
 * SINGLE-FILE admin API for the Internship "Assignment Panel".
 *
 * Hierarchy:
 *   internship_list  (is_full = 0 AND show_internship = 1)
 *     -> internship_assignments      (title + rich HTML description)
 *          -> internship_assignment_attachments  (admin reference files on S3,
 *               each with its own label / description — ppt, pdf, excel, csv,
 *               video, image, zip, ...)
 *          -> internship_assignment_fields       (the dynamic submission form
 *               builder — label, placeholder, help, required, options, file
 *               rules — exactly like the Internship Simulation 2.2 builder)
 *
 * Routes:
 *   GET  ?resource=domains
 *   GET  ?resource=assignments&action=list&internship_id=ID
 *   POST ?resource=assignments&action=create|update|delete|toggle|reorder
 *   GET  ?resource=attachments&action=list&assignment_id=ID
 *   POST ?resource=attachments&action=create   (multipart: file + meta)
 *   POST ?resource=attachments&action=update|delete|reorder
 *   GET  ?resource=fields&action=list&assignment_id=ID
 *   POST ?resource=fields&action=create|update|delete|toggle|reorder
 *   POST ?resource=editor&action=upload_image  (multipart: image) -> S3 URL
 *
 * Responses: { "status":"success", "data":{...} } | { "status":"error", ... }
 *
 * Bootstrap / error-handling mirrors sim_admin_api.php; the S3 upload approach
 * mirrors problem_statements_api.php (same bucket + credentials). Access is
 * gated by the React admin panel's permission system, not here.
 * ---------------------------------------------------------------------------
 */

@ini_set('display_errors', '0');
error_reporting(E_ALL);

define('ASG_LOG_FILE', __DIR__ . '/assignments_errors.log');
@ini_set('log_errors', '1');
@ini_set('error_log', ASG_LOG_FILE);

function asg_log($label, $msg) {
    $line = '[' . date('Y-m-d H:i:s') . '] ' . $label . ': ' . $msg
          . '  {' . ($_SERVER['REQUEST_METHOD'] ?? 'CLI') . ' '
          . ($_SERVER['REQUEST_URI'] ?? '') . '}' . PHP_EOL;
    @file_put_contents(ASG_LOG_FILE, $line, FILE_APPEND | LOCK_EX);
}

set_error_handler(function ($no, $str, $file, $line) {
    if (strpos($file, 'assignments_api.php') !== false) {
        asg_log('PHP-ERROR(' . $no . ')', $str . ' in ' . $file . ':' . $line);
    }
    return true;
});

/* shared bootstrap — provides global $conn (same as the other endpoints here) */
ob_start();
chdir('/home/istudio/public_html/cit/common');
include '/home/istudio/public_html/cit/common/helper.php';
ob_clean();

/* AWS SDK — same vendor autoload + bucket/creds as problem_statements_api.php */
require_once '/home/istudio/public_html/istudio_dashboard/api/vendor/autoload.php';
use Aws\S3\S3Client;
use Aws\Exception\AwsException;

header('Content-Type: application/json');

register_shutdown_function(function () {
    $e = error_get_last();
    if ($e && in_array($e['type'], [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR], true)) {
        asg_log('FATAL', $e['message'] . ' in ' . $e['file'] . ':' . $e['line']);
        if (!headers_sent()) header('Content-Type: application/json');
        echo json_encode(['status' => 'error', 'message' => 'Server error: ' . $e['message']]);
    }
});

set_exception_handler(function ($e) {
    asg_log('EXCEPTION', get_class($e) . ': ' . $e->getMessage()
        . ' in ' . $e->getFile() . ':' . $e->getLine());
    if (!headers_sent()) {
        http_response_code(500);
        header('Content-Type: application/json');
    }
    echo json_encode(['status' => 'error', 'message' => 'Server error: ' . $e->getMessage()]);
    exit;
});

/* ====== helpers ====== */
function asg_out($p) { echo json_encode($p); exit; }
function asg_error($m, $c = 400) {
    asg_log('API-ERROR(' . $c . ')', $m);
    http_response_code($c);
    asg_out(['status' => 'error', 'message' => $m]);
}
function asg_ok($d = null, $m = '') {
    $r = ['status' => 'success'];
    if ($m !== '') $r['message'] = $m;
    if ($d !== null) $r['data'] = $d;
    asg_out($r);
}
function asg_input() {
    $i = $_POST;
    if (empty($i)) {
        $j = json_decode(file_get_contents('php://input'), true);
        if (is_array($j)) $i = $j;
    }
    return $i;
}
function asg_json_decode($s) {
    if ($s === null || $s === '') return [];
    $d = json_decode($s, true);
    return is_array($d) ? $d : [];
}
function asg_json_col($v) {
    if ($v === null || $v === '') return null;
    if (is_array($v)) return json_encode(array_values($v));
    $d = json_decode($v, true);
    return is_array($d) ? json_encode($d) : json_encode([$v]);
}

/* ====== db ====== */
global $conn;
if (!$conn) asg_error('Database connection failed', 500);

/* ----- schema (safe to run every request) -------------------------------- */
$conn->query("CREATE TABLE IF NOT EXISTS internship_assignments (
    id            INT AUTO_INCREMENT PRIMARY KEY,
    internship_id INT          NOT NULL,
    title         VARCHAR(255) NOT NULL,
    description   LONGTEXT          DEFAULT NULL,
    step_order    INT               DEFAULT 0,
    status        ENUM('active','inactive') DEFAULT 'active',
    created_by    INT               DEFAULT 0,
    created_at    TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,
    updated_at    TIMESTAMP    DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_internship_status (internship_id, status, step_order),
    INDEX idx_status_internship (status, internship_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

$conn->query("CREATE TABLE IF NOT EXISTS internship_assignment_attachments (
    id            INT AUTO_INCREMENT PRIMARY KEY,
    assignment_id INT          NOT NULL,
    title         VARCHAR(255)      DEFAULT NULL,
    description   LONGTEXT          DEFAULT NULL,
    placeholder   VARCHAR(255)      DEFAULT NULL,
    is_required   TINYINT(1)        DEFAULT 0,
    kind          VARCHAR(10)       DEFAULT 'file',
    file_url      TEXT         NOT NULL,
    file_key      VARCHAR(512) NOT NULL,
    file_name     VARCHAR(255)      DEFAULT NULL,
    file_type     VARCHAR(40)       DEFAULT NULL,
    file_size     BIGINT            DEFAULT 0,
    mime_type     VARCHAR(150)      DEFAULT NULL,
    sort_order    INT               DEFAULT 0,
    status        ENUM('active','inactive') DEFAULT 'active',
    created_by    INT               DEFAULT 0,
    created_at    TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_assignment_status (assignment_id, status, sort_order)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

$conn->query("CREATE TABLE IF NOT EXISTS internship_assignment_fields (
    id                  INT AUTO_INCREMENT PRIMARY KEY,
    assignment_id       INT          NOT NULL,
    field_order         INT               DEFAULT 0,
    field_type          VARCHAR(30)  NOT NULL,
    label               VARCHAR(500) NOT NULL,
    placeholder         VARCHAR(500)      DEFAULT NULL,
    help_text           VARCHAR(1000)     DEFAULT NULL,
    is_required         TINYINT(1)        DEFAULT 1,
    options             TEXT              DEFAULT NULL,
    accepted_extensions VARCHAR(255)      DEFAULT NULL,
    max_file_size_mb    INT               DEFAULT 25,
    status              ENUM('active','inactive') DEFAULT 'active',
    created_at          TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,
    updated_at          TIMESTAMP    DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_assignment_order (assignment_id, field_order)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

/* add the kind column to a pre-existing attachments table (links vs files) */
function asg_ensure_column($conn, $table, $col, $ddl) {
    $r = $conn->query("SELECT COUNT(*) AS c FROM information_schema.columns
                       WHERE table_schema = DATABASE() AND table_name = '$table' AND column_name = '$col'");
    $exists = $r ? ((int)$r->fetch_assoc()['c'] > 0) : true;
    if (!$exists) @$conn->query("ALTER TABLE $table ADD COLUMN $ddl");
}
asg_ensure_column($conn, 'internship_assignment_attachments', 'kind', "kind VARCHAR(10) DEFAULT 'file'");

/* shared re-upload audit trail (old URL -> new URL, same record id).
   Makes every file swap revertible — see attachment_reupload_backup.sql. */
require_once __DIR__ . '/attachment_reupload_log.php';
arl_ensure_table($conn);

$user_id  = (int)($_SESSION['user_id'] ?? 0);
$resource = $_GET['resource'] ?? '';
$action   = $_GET['action'] ?? ($_POST['action'] ?? '');
$in       = asg_input();

$ALLOWED_TYPES = ['text','textarea','number','date','url','image','video',
    'file_pdf','file_xlsx','file_doc','file_any','presentation',
    'dropdown_single','dropdown_multi','radio','checkbox'];

/* ====== S3 config (same as problem_statements_api.php / notes.php) ====== */
$awsRegion  = 'ap-south-1';
$bucketName = 'internshipstudio-prod-data-bucket-new';
$awsCreds   = [
    'key'    => 'AKIAYVYU7O43T344J2MD',
    'secret' => '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',
];
$buildS3 = function() use ($awsRegion, $awsCreds) {
    return new S3Client([
        'version'     => 'latest',
        'region'      => $awsRegion,
        'credentials' => $awsCreds,
    ]);
};

/* upload a $_FILES entry to S3, return [url, key, name, size, mime_type] or asg_error */
function asg_put_to_s3($file, $keyPrefix, $buildS3, $bucketName, $awsRegion, $maxMb = 100) {
    if (empty($file) || !isset($file['error']) || $file['error'] !== UPLOAD_ERR_OK) {
        asg_error('File upload failed (code ' . ($file['error'] ?? 'n/a') . ')');
    }
    if ($file['size'] > $maxMb * 1024 * 1024) asg_error("File must be under {$maxMb}MB");

    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION) ?: 'bin');
    $ext = preg_replace('/[^a-z0-9]+/', '', $ext) ?: 'bin';
    $key = rtrim($keyPrefix, '/') . '/' . date('Y/m') . '/' . uniqid('asg_', true) . '.' . $ext;
    $mime = $file['type'] ?: 'application/octet-stream';

    $s3 = $buildS3();
    try {
        $s3->putObject([
            'Bucket'      => $bucketName,
            'Key'         => $key,
            'SourceFile'  => $file['tmp_name'],
            'ContentType' => $mime,
        ]);
    } catch (AwsException $e) {
        asg_error('S3 upload error: ' . $e->getMessage(), 500);
    }
    return [
        'url'       => "https://{$bucketName}.s3.{$awsRegion}.amazonaws.com/{$key}",
        'key'       => $key,
        'name'      => $file['name'],
        'size'      => (int)$file['size'],
        'mime_type' => $mime,
    ];
}

/* infer a coarse file_type bucket from extension / mime for nicer icons */
function asg_file_type($name, $mime) {
    $ext = strtolower(pathinfo($name, PATHINFO_EXTENSION));
    if (in_array($ext, ['pdf'])) return 'pdf';
    if (in_array($ext, ['doc','docx','rtf','txt','odt'])) return 'doc';
    if (in_array($ext, ['xls','xlsx','csv','ods'])) return 'excel';
    if (in_array($ext, ['ppt','pptx','odp','key'])) return 'ppt';
    if (in_array($ext, ['mp4','mov','avi','mkv','webm'])) return 'video';
    if (in_array($ext, ['zip','rar','7z','tar','gz'])) return 'zip';
    if (in_array($ext, ['jpg','jpeg','png','gif','webp','svg','bmp'])) return 'image';
    if (strpos((string)$mime, 'image/') === 0) return 'image';
    if (strpos((string)$mime, 'video/') === 0) return 'video';
    return 'other';
}

/* =========================================================================
   DOMAINS — internship_list rows with is_full = 0 AND show_internship = 1,
   plus active-assignment counts
   ========================================================================= */
if ($resource === 'domains') {
    $sql = "SELECT il.id, il.internship_name, il.short_name
            FROM internship_list il
            WHERE il.is_full = 0 AND il.show_internship = 1
            ORDER BY il.priority ASC, il.internship_name ASC";
    $res = $conn->query($sql);
    if ($res === false) asg_error('Could not read internship_list: ' . $conn->error, 500);

    $domains = [];
    while ($row = $res->fetch_assoc()) {
        $id = (int)$row['id'];
        $domains[$id] = [
            'internship_id' => $id,
            'name'          => $row['internship_name'],
            'short_name'    => $row['short_name'],
            'count'         => 0,
        ];
    }

    $cc = $conn->query("SELECT internship_id, COUNT(*) AS c
                        FROM internship_assignments
                        WHERE status = 'active'
                        GROUP BY internship_id");
    if ($cc) {
        while ($row = $cc->fetch_assoc()) {
            $id = (int)$row['internship_id'];
            if (isset($domains[$id])) $domains[$id]['count'] = (int)$row['c'];
        }
    }
    $conn->close();
    asg_ok(['domains' => array_values($domains)]);
}

/* =========================================================================
   ASSIGNMENTS
   ========================================================================= */
if ($resource === 'assignments') {

    if ($action === 'list') {
        $internship_id = isset($_GET['internship_id']) ? (int)$_GET['internship_id'] : 0;
        if ($internship_id <= 0) asg_error('internship_id is required');
        $stmt = $conn->prepare(
            "SELECT a.*,
                    (SELECT COUNT(*) FROM internship_assignment_attachments x
                       WHERE x.assignment_id = a.id AND x.status='active') AS attachment_count,
                    (SELECT COUNT(*) FROM internship_assignment_fields f
                       WHERE f.assignment_id = a.id) AS field_count
             FROM internship_assignments a
             WHERE a.internship_id = ?
             ORDER BY a.step_order ASC, a.id ASC"
        );
        $stmt->bind_param('i', $internship_id);
        $stmt->execute();
        $r = $stmt->get_result();
        $rows = [];
        while ($row = $r->fetch_assoc()) {
            $row['id']               = (int)$row['id'];
            $row['internship_id']    = (int)$row['internship_id'];
            $row['step_order']       = (int)$row['step_order'];
            $row['attachment_count'] = (int)$row['attachment_count'];
            $row['field_count']      = (int)$row['field_count'];
            $rows[] = $row;
        }
        $stmt->close();
        $conn->close();
        asg_ok(['assignments' => $rows]);
    }

    if ($action === 'create') {
        $internship_id = (int)($in['internship_id'] ?? 0);
        $title         = trim($in['title'] ?? '');
        if ($internship_id <= 0 || $title === '') asg_error('internship_id and title are required');
        $description = trim($in['description'] ?? '');
        $step_order  = (int)($in['step_order'] ?? 0);
        if ($step_order <= 0) {
            $mx = $conn->query("SELECT COALESCE(MAX(step_order),0)+1 AS n FROM internship_assignments WHERE internship_id=$internship_id")->fetch_assoc();
            $step_order = (int)$mx['n'];
        }
        $stmt = $conn->prepare(
            "INSERT INTO internship_assignments (internship_id, title, description, step_order, status, created_by)
             VALUES (?, ?, ?, ?, 'active', ?)"
        );
        $stmt->bind_param('issii', $internship_id, $title, $description, $step_order, $user_id);
        $stmt->execute();
        $id = $stmt->insert_id;
        $stmt->close();
        $conn->close();
        asg_ok(['id' => $id], 'Assignment created');
    }

    if ($action === 'update') {
        $id    = (int)($in['id'] ?? 0);
        $title = trim($in['title'] ?? '');
        if ($id <= 0 || $title === '') asg_error('id and title are required');
        $description = trim($in['description'] ?? '');
        $step_order  = (int)($in['step_order'] ?? 1);
        $stmt = $conn->prepare(
            "UPDATE internship_assignments SET title=?, description=?, step_order=? WHERE id=?"
        );
        $stmt->bind_param('ssii', $title, $description, $step_order, $id);
        $stmt->execute();
        $stmt->close();
        $conn->close();
        asg_ok(['id' => $id], 'Assignment updated');
    }

    if ($action === 'toggle') {
        $id = (int)($in['id'] ?? 0);
        if ($id <= 0) asg_error('id is required');
        $stmt = $conn->prepare("UPDATE internship_assignments SET status = IF(status='active','inactive','active') WHERE id=?");
        $stmt->bind_param('i', $id);
        $stmt->execute();
        $stmt->close();
        $conn->close();
        asg_ok(['id' => $id], 'Assignment status toggled');
    }

    if ($action === 'delete') {
        $id = (int)($in['id'] ?? 0);
        if ($id <= 0) asg_error('id is required');
        /* hard delete the assignment + its builder fields & attachment rows
           (S3 objects are kept for audit, like notes.php) */
        $conn->query("DELETE FROM internship_assignment_fields      WHERE assignment_id=$id");
        $conn->query("DELETE FROM internship_assignment_attachments WHERE assignment_id=$id");
        $conn->query("DELETE FROM internship_assignments            WHERE id=$id");
        $conn->close();
        asg_ok(['id' => $id], 'Assignment deleted');
    }

    if ($action === 'reorder') {
        $order = $in['order'] ?? [];
        if (is_string($order)) $order = json_decode($order, true);
        if (!is_array($order) || !$order) asg_error('order array is required');
        $stmt = $conn->prepare("UPDATE internship_assignments SET step_order=? WHERE id=?");
        foreach (array_values($order) as $i => $aid) {
            $pos = $i + 1; $aid = (int)$aid;
            $stmt->bind_param('ii', $pos, $aid);
            $stmt->execute();
        }
        $stmt->close();
        $conn->close();
        asg_ok(null, 'Assignments reordered');
    }

    asg_error('Unknown assignment action');
}

/* =========================================================================
   ATTACHMENTS — admin reference files (S3), each with label/description
   ========================================================================= */
if ($resource === 'attachments') {

    if ($action === 'list') {
        $assignment_id = isset($_GET['assignment_id']) ? (int)$_GET['assignment_id'] : 0;
        if ($assignment_id <= 0) asg_error('assignment_id is required');
        $stmt = $conn->prepare(
            "SELECT * FROM internship_assignment_attachments
             WHERE assignment_id = ? AND status='active'
             ORDER BY sort_order ASC, id ASC"
        );
        $stmt->bind_param('i', $assignment_id);
        $stmt->execute();
        $r = $stmt->get_result();
        $rows = [];
        while ($row = $r->fetch_assoc()) {
            $row['id']            = (int)$row['id'];
            $row['assignment_id'] = (int)$row['assignment_id'];
            $row['is_required']   = (int)$row['is_required'];
            $row['file_size']     = (int)$row['file_size'];
            $row['sort_order']    = (int)$row['sort_order'];
            $rows[] = $row;
        }
        $stmt->close();
        $conn->close();
        asg_ok(['attachments' => $rows]);
    }

    if ($action === 'create') {
        $assignment_id = (int)($_POST['assignment_id'] ?? $in['assignment_id'] ?? 0);
        if ($assignment_id <= 0) asg_error('assignment_id is required');

        $kind        = (($_POST['kind'] ?? $in['kind'] ?? 'file') === 'link') ? 'link' : 'file';
        $title       = trim($_POST['title'] ?? $in['title'] ?? '');
        $description = trim($_POST['description'] ?? $in['description'] ?? '');
        $placeholder = trim($_POST['placeholder'] ?? $in['placeholder'] ?? '');
        $is_required = !empty($_POST['is_required'] ?? $in['is_required'] ?? 0) ? 1 : 0;

        if ($kind === 'link') {
            $url = trim($_POST['url'] ?? $in['url'] ?? '');
            if ($url === '') asg_error('A link URL is required');
            $file_url = $url; $file_key = ''; $file_name = ($title !== '' ? $title : $url);
            $file_type = 'link'; $file_size = 0; $mime_type = 'text/uri-list';
        } else {
            if (empty($_FILES['file'])) asg_error('A file upload is required');
            $up = asg_put_to_s3($_FILES['file'], "assignments/$assignment_id", $buildS3, $bucketName, $awsRegion);
            $file_url = $up['url']; $file_key = $up['key']; $file_name = $up['name'];
            $file_type = asg_file_type($up['name'], $up['mime_type']);
            $file_size = $up['size']; $mime_type = $up['mime_type'];
        }

        $mx = $conn->query("SELECT COALESCE(MAX(sort_order),0)+1 AS n FROM internship_assignment_attachments WHERE assignment_id=$assignment_id")->fetch_assoc();
        $sort_order = (int)$mx['n'];

        $titleN = $title === '' ? null : $title;
        $descN  = $description === '' ? null : $description;
        $phN    = $placeholder === '' ? null : $placeholder;
        $stmt = $conn->prepare(
            "INSERT INTO internship_assignment_attachments
                (assignment_id, title, description, placeholder, is_required, kind,
                 file_url, file_key, file_name, file_type, file_size, mime_type, sort_order, created_by)
             VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)"
        );
        /* 14 params: i s s s i s s s s s i s i i */
        $stmt->bind_param(
            'isssisssssisii',
            $assignment_id, $titleN, $descN, $phN, $is_required, $kind,
            $file_url, $file_key, $file_name, $file_type, $file_size, $mime_type, $sort_order, $user_id
        );
        $stmt->execute();
        $id = $stmt->insert_id;
        $stmt->close();
        $conn->close();
        asg_ok(['id' => $id, 'file_url' => $file_url, 'file_type' => $file_type], $kind === 'link' ? 'Link added' : 'Attachment uploaded');
    }

    if ($action === 'update') {
        $id = (int)($in['id'] ?? 0);
        if ($id <= 0) asg_error('id is required');
        $title       = trim($in['title'] ?? '');
        $description = trim($in['description'] ?? '');
        $placeholder = trim($in['placeholder'] ?? '');
        $is_required = !empty($in['is_required']) ? 1 : 0;
        $titleN = $title === '' ? null : $title;
        $descN  = $description === '' ? null : $description;
        $phN    = $placeholder === '' ? null : $placeholder;
        $stmt = $conn->prepare(
            "UPDATE internship_assignment_attachments SET title=?, description=?, placeholder=?, is_required=? WHERE id=?"
        );
        $stmt->bind_param('sssii', $titleN, $descN, $phN, $is_required, $id);
        $stmt->execute();
        $stmt->close();
        $conn->close();
        asg_ok(['id' => $id], 'Attachment updated');
    }

    /* ---------------------------------------------------------------------
       REUPLOAD — swap the S3 file behind an existing attachment.
       The row id, title, description, placeholder, required flag and sort
       order are all left untouched (student submissions reference this id);
       only file_url / file_key / file_name / file_type / file_size /
       mime_type move to the freshly uploaded object. The previous values are
       written to internship_attachment_reupload_log first, so the swap can be
       undone at any time.
       --------------------------------------------------------------------- */
    if ($action === 'reupload') {
        $id = (int)($_POST['id'] ?? $in['id'] ?? 0);
        if ($id <= 0) asg_error('id is required');
        if (empty($_FILES['file'])) asg_error('A replacement file is required');

        $q = $conn->prepare("SELECT * FROM internship_assignment_attachments WHERE id=?");
        $q->bind_param('i', $id);
        $q->execute();
        $old = $q->get_result()->fetch_assoc();
        $q->close();
        if (!$old) asg_error('Attachment not found', 404);
        if (($old['kind'] ?? 'file') === 'link') {
            asg_error('This item is an external link, not an uploaded file — edit the link instead');
        }

        $up = asg_put_to_s3($_FILES['file'], 'assignments/' . (int)$old['assignment_id'],
                            $buildS3, $bucketName, $awsRegion);
        $new_type = asg_file_type($up['name'], $up['mime_type']);
        $new = [
            'file_url'  => $up['url'],  'file_key'  => $up['key'],  'file_name' => $up['name'],
            'file_type' => $new_type,   'file_size' => $up['size'], 'mime_type' => $up['mime_type'],
        ];

        $log_id = arl_log($conn, 'internship_assignment_attachments', $id, $old, $new, $user_id);

        $stmt = $conn->prepare(
            "UPDATE internship_assignment_attachments
                SET file_url=?, file_key=?, file_name=?, file_type=?, file_size=?, mime_type=?
             WHERE id=?"
        );
        $stmt->bind_param('ssssisi',
            $new['file_url'], $new['file_key'], $new['file_name'],
            $new['file_type'], $new['file_size'], $new['mime_type'], $id);
        $stmt->execute();
        $stmt->close();
        $conn->close();
        asg_ok([
            'id'       => $id,
            'log_id'   => $log_id,
            'file_url' => $new['file_url'],
            'file_key' => $new['file_key'],
            'old_file_url' => $old['file_url'],
        ], 'File replaced — the record id is unchanged');
    }

    /* history of re-uploads for one attachment (newest first) */
    if ($action === 'reupload_history') {
        $id = (int)($_GET['id'] ?? $in['id'] ?? 0);
        if ($id <= 0) asg_error('id is required');
        $rows = arl_history($conn, 'internship_assignment_attachments', $id);
        $conn->close();
        asg_ok(['history' => $rows]);
    }

    /* undo one logged re-upload (restores the old S3 URL on the same id) */
    if ($action === 'reupload_revert') {
        $log_id = (int)($in['log_id'] ?? $_POST['log_id'] ?? 0);
        list($ok, $msg) = arl_revert($conn, $log_id);
        $conn->close();
        if (!$ok) asg_error($msg);
        asg_ok(['log_id' => $log_id], $msg);
    }

    if ($action === 'delete') {
        $id = (int)($in['id'] ?? 0);
        if ($id <= 0) asg_error('id is required');
        $stmt = $conn->prepare("UPDATE internship_assignment_attachments SET status='inactive' WHERE id=?");
        $stmt->bind_param('i', $id);
        $stmt->execute();
        $stmt->close();
        $conn->close();
        asg_ok(['id' => $id], 'Attachment deleted');
    }

    if ($action === 'reorder') {
        $order = $in['order'] ?? [];
        if (is_string($order)) $order = json_decode($order, true);
        if (!is_array($order) || !$order) asg_error('order array is required');
        $stmt = $conn->prepare("UPDATE internship_assignment_attachments SET sort_order=? WHERE id=?");
        foreach (array_values($order) as $i => $xid) {
            $pos = $i + 1; $xid = (int)$xid;
            $stmt->bind_param('ii', $pos, $xid);
            $stmt->execute();
        }
        $stmt->close();
        $conn->close();
        asg_ok(null, 'Attachments reordered');
    }

    asg_error('Unknown attachment action');
}

/* =========================================================================
   FIELDS — the dynamic submission form builder (mirrors sim_task_fields)
   ========================================================================= */
if ($resource === 'fields') {

    if ($action === 'list') {
        $assignment_id = isset($_GET['assignment_id']) ? (int)$_GET['assignment_id'] : 0;
        if ($assignment_id <= 0) asg_error('assignment_id is required');
        $stmt = $conn->prepare("SELECT * FROM internship_assignment_fields WHERE assignment_id=? ORDER BY field_order ASC, id ASC");
        $stmt->bind_param('i', $assignment_id);
        $stmt->execute();
        $r = $stmt->get_result();
        $fields = [];
        while ($row = $r->fetch_assoc()) {
            $row['id']               = (int)$row['id'];
            $row['assignment_id']    = (int)$row['assignment_id'];
            $row['field_order']      = (int)$row['field_order'];
            $row['is_required']      = (int)$row['is_required'];
            $row['max_file_size_mb'] = (int)$row['max_file_size_mb'];
            $row['options']          = asg_json_decode($row['options']);
            $fields[] = $row;
        }
        $stmt->close();
        $conn->close();
        asg_ok(['fields' => $fields]);
    }

    if ($action === 'create' || $action === 'update') {
        $assignment_id = (int)($in['assignment_id'] ?? 0);
        $field_type    = $in['field_type'] ?? 'text';
        $label         = trim($in['label'] ?? '');
        if ($action === 'create' && $assignment_id <= 0) asg_error('assignment_id is required');
        if ($label === '') asg_error('label is required');
        if (!in_array($field_type, $ALLOWED_TYPES, true)) asg_error('Invalid field_type');

        $placeholder  = trim($in['placeholder'] ?? '');
        $help_text    = trim($in['help_text'] ?? '');
        $is_required  = !empty($in['is_required']) ? 1 : 0;
        $options      = asg_json_col($in['options'] ?? null);
        $accepted_ext = trim($in['accepted_extensions'] ?? '');
        $max_size     = max(1, (int)($in['max_file_size_mb'] ?? 25));
        $status       = ($in['status'] ?? 'active') === 'inactive' ? 'inactive' : 'active';

        if ($action === 'create') {
            $field_order = (int)($in['field_order'] ?? 0);
            if ($field_order <= 0) {
                $mx = $conn->query("SELECT COALESCE(MAX(field_order),0)+1 AS n FROM internship_assignment_fields WHERE assignment_id=$assignment_id")->fetch_assoc();
                $field_order = (int)$mx['n'];
            }
            $stmt = $conn->prepare(
                "INSERT INTO internship_assignment_fields
                 (assignment_id, field_order, field_type, label, placeholder, help_text,
                  is_required, options, accepted_extensions, max_file_size_mb, status)
                 VALUES (?,?,?,?,?,?,?,?,?,?,?)"
            );
            /* types: i i s s s s i s s i s  (max_file_size_mb=i, status=s) */
            $stmt->bind_param(
                'iissssissis',
                $assignment_id, $field_order, $field_type, $label, $placeholder, $help_text,
                $is_required, $options, $accepted_ext, $max_size, $status
            );
            $stmt->execute();
            $id = $stmt->insert_id;
            $stmt->close();
            $conn->close();
            asg_ok(['id' => $id], 'Field created');
        } else {
            $id = (int)($in['id'] ?? 0);
            if ($id <= 0) asg_error('id is required');
            $stmt = $conn->prepare(
                "UPDATE internship_assignment_fields SET
                   field_type=?, label=?, placeholder=?, help_text=?, is_required=?,
                   options=?, accepted_extensions=?, max_file_size_mb=?, status=?
                 WHERE id=?"
            );
            /* types: s s s s i s s i s i  (max_file_size_mb=i, status=s, id=i) */
            $stmt->bind_param(
                'ssssissisi',
                $field_type, $label, $placeholder, $help_text, $is_required,
                $options, $accepted_ext, $max_size, $status, $id
            );
            $stmt->execute();
            $stmt->close();
            $conn->close();
            asg_ok(['id' => $id], 'Field updated');
        }
    }

    if ($action === 'toggle') {
        $id = (int)($in['id'] ?? 0);
        if ($id <= 0) asg_error('id is required');
        $stmt = $conn->prepare("UPDATE internship_assignment_fields SET status=IF(status='active','inactive','active') WHERE id=?");
        $stmt->bind_param('i', $id);
        $stmt->execute();
        $stmt->close();
        $conn->close();
        asg_ok(['id' => $id], 'Field status toggled');
    }

    if ($action === 'delete') {
        $id = (int)($in['id'] ?? 0);
        if ($id <= 0) asg_error('id is required');
        $stmt = $conn->prepare("DELETE FROM internship_assignment_fields WHERE id=?");
        $stmt->bind_param('i', $id);
        $stmt->execute();
        $stmt->close();
        $conn->close();
        asg_ok(['id' => $id], 'Field deleted');
    }

    if ($action === 'reorder') {
        $order = $in['order'] ?? [];
        if (is_string($order)) $order = json_decode($order, true);
        if (!is_array($order) || !$order) asg_error('order array is required');
        $stmt = $conn->prepare("UPDATE internship_assignment_fields SET field_order=? WHERE id=?");
        foreach (array_values($order) as $i => $fid) {
            $pos = $i + 1; $fid = (int)$fid;
            $stmt->bind_param('ii', $pos, $fid);
            $stmt->execute();
        }
        $stmt->close();
        $conn->close();
        asg_ok(null, 'Fields reordered');
    }

    asg_error('Unknown field action');
}

/* =========================================================================
   EDITOR — inline image for the rich description editor -> S3
   ========================================================================= */
if ($resource === 'editor') {
    if ($action === 'upload_image') {
        if (empty($_FILES['image']) || $_FILES['image']['error'] !== UPLOAD_ERR_OK) {
            asg_error('Image file is required');
        }
        $file = $_FILES['image'];
        $allowed = ['image/jpeg','image/png','image/gif','image/webp'];
        if (!in_array($file['type'], $allowed, true)) asg_error('Only JPEG, PNG, GIF, WEBP images are allowed');
        if ($file['size'] > 5 * 1024 * 1024)          asg_error('Image must be under 5MB');

        $up = asg_put_to_s3($file, 'assignments/editor', $buildS3, $bucketName, $awsRegion, 5);
        $conn->close();
        asg_ok([
            'url'           => $up['url'],
            'key'           => $up['key'],
            'original_name' => $up['name'],
        ], 'Image uploaded');
    }
    asg_error('Unknown editor action');
}

asg_error('Unknown resource');

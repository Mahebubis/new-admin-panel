<?php
/**
 * attachment_reupload_log.php
 * ---------------------------------------------------------------------------
 * Shared audit trail for "re-upload" (swap the S3 file behind an existing row
 * WITHOUT touching its primary key).
 *
 * Used by:
 *   - assignments_api.php          -> internship_assignment_attachments
 *   - problem_statements_api.php   -> internship_problem_statements
 *                                  -> internship_problem_statement_items
 *
 * Every re-upload writes one row here holding the OLD file_url/file_key/…
 * and the NEW ones. That makes every swap fully revertible: either call
 * arl_revert() or run the plain-SQL revert query documented in
 * attachment_reupload_backup.sql — both restore the old values on the SAME id.
 *
 * Nothing here ever deletes an S3 object, so the old key stays retrievable.
 * ---------------------------------------------------------------------------
 */

/* the six columns a re-upload can change, in a fixed order */
function arl_cols() {
    return ['file_url', 'file_key', 'file_name', 'file_type', 'file_size', 'mime_type'];
}

/* create the log table (safe to run on every request) */
function arl_ensure_table($conn) {
    $conn->query("CREATE TABLE IF NOT EXISTS internship_attachment_reupload_log (
        id            BIGINT AUTO_INCREMENT PRIMARY KEY,
        source_table  VARCHAR(64)  NOT NULL,   -- which table the record lives in
        record_id     INT          NOT NULL,   -- the untouched primary key
        old_file_url  TEXT              DEFAULT NULL,
        old_file_key  VARCHAR(512)      DEFAULT NULL,
        old_file_name VARCHAR(255)      DEFAULT NULL,
        old_file_type VARCHAR(40)       DEFAULT NULL,
        old_file_size BIGINT            DEFAULT 0,
        old_mime_type VARCHAR(150)      DEFAULT NULL,
        new_file_url  TEXT              DEFAULT NULL,
        new_file_key  VARCHAR(512)      DEFAULT NULL,
        new_file_name VARCHAR(255)      DEFAULT NULL,
        new_file_type VARCHAR(40)       DEFAULT NULL,
        new_file_size BIGINT            DEFAULT 0,
        new_mime_type VARCHAR(150)      DEFAULT NULL,
        reverted      TINYINT(1)        DEFAULT 0,
        reverted_at   TIMESTAMP    NULL DEFAULT NULL,
        created_by    INT               DEFAULT 0,
        created_at    TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_source_record (source_table, record_id),
        INDEX idx_created (created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
}

/**
 * Record a swap. $old / $new are assoc arrays holding the arl_cols() keys.
 * Called BEFORE the UPDATE, so a failed UPDATE still leaves the old values
 * recorded rather than losing them.
 */
function arl_log($conn, $table, $record_id, $old, $new, $user_id = 0) {
    arl_ensure_table($conn);

    $ou = (string)($old['file_url']  ?? '');
    $ok = (string)($old['file_key']  ?? '');
    $on = (string)($old['file_name'] ?? '');
    $ot = (string)($old['file_type'] ?? '');
    $os = (int)   ($old['file_size'] ?? 0);
    $om = (string)($old['mime_type'] ?? '');
    $nu = (string)($new['file_url']  ?? '');
    $nk = (string)($new['file_key']  ?? '');
    $nn = (string)($new['file_name'] ?? '');
    $nt = (string)($new['file_type'] ?? '');
    $ns = (int)   ($new['file_size'] ?? 0);
    $nm = (string)($new['mime_type'] ?? '');
    $rid = (int)$record_id;
    $uid = (int)$user_id;

    $stmt = $conn->prepare(
        "INSERT INTO internship_attachment_reupload_log
            (source_table, record_id,
             old_file_url, old_file_key, old_file_name, old_file_type, old_file_size, old_mime_type,
             new_file_url, new_file_key, new_file_name, new_file_type, new_file_size, new_mime_type,
             created_by)
         VALUES (?,?, ?,?,?,?,?,?, ?,?,?,?,?,?, ?)"
    );
    if (!$stmt) return 0;
    /* 15 params: s i  s s s s i s  s s s s i s  i */
    $stmt->bind_param(
        'sissssisssssisi',
        $table, $rid,
        $ou, $ok, $on, $ot, $os, $om,
        $nu, $nk, $nn, $nt, $ns, $nm,
        $uid
    );
    $stmt->execute();
    $id = $stmt->insert_id;
    $stmt->close();
    return (int)$id;
}

/* the tables a log row is allowed to write back to (guards the table name,
   which is interpolated into the UPDATE) */
function arl_allowed_tables() {
    return [
        'internship_assignment_attachments',
        'internship_problem_statements',
        'internship_problem_statement_items',
    ];
}

/**
 * Undo one logged re-upload: write the old_* values back onto the SAME record
 * id and mark the log row reverted. Returns [ok(bool), message(string)].
 */
function arl_revert($conn, $log_id) {
    arl_ensure_table($conn);
    $log_id = (int)$log_id;
    if ($log_id <= 0) return [false, 'log_id is required'];

    $q = $conn->prepare("SELECT * FROM internship_attachment_reupload_log WHERE id=?");
    $q->bind_param('i', $log_id);
    $q->execute();
    $row = $q->get_result()->fetch_assoc();
    $q->close();
    if (!$row)                return [false, 'Log entry not found'];
    if ((int)$row['reverted']) return [false, 'This re-upload was already reverted'];

    $table = $row['source_table'];
    if (!in_array($table, arl_allowed_tables(), true)) return [false, 'Unknown source table'];

    $url  = (string)$row['old_file_url'];
    $key  = (string)$row['old_file_key'];
    $name = (string)$row['old_file_name'];
    $type = (string)$row['old_file_type'];
    $size = (int)   $row['old_file_size'];
    $mime = (string)$row['old_mime_type'];
    $rid  = (int)   $row['record_id'];

    $stmt = $conn->prepare(
        "UPDATE `$table` SET file_url=?, file_key=?, file_name=?, file_type=?, file_size=?, mime_type=?
         WHERE id=?"
    );
    if (!$stmt) return [false, 'Revert failed: ' . $conn->error];
    $stmt->bind_param('ssssisi', $url, $key, $name, $type, $size, $mime, $rid);
    $stmt->execute();
    $stmt->close();

    $conn->query("UPDATE internship_attachment_reupload_log
                  SET reverted=1, reverted_at=NOW() WHERE id=$log_id");
    return [true, 'Reverted to the previous file'];
}

/* history for one record (newest first) */
function arl_history($conn, $table, $record_id) {
    arl_ensure_table($conn);
    $stmt = $conn->prepare(
        "SELECT * FROM internship_attachment_reupload_log
         WHERE source_table=? AND record_id=? ORDER BY id DESC"
    );
    $rid = (int)$record_id;
    $stmt->bind_param('si', $table, $rid);
    $stmt->execute();
    $r = $stmt->get_result();
    $rows = [];
    while ($x = $r->fetch_assoc()) {
        $x['id']            = (int)$x['id'];
        $x['record_id']     = (int)$x['record_id'];
        $x['old_file_size'] = (int)$x['old_file_size'];
        $x['new_file_size'] = (int)$x['new_file_size'];
        $x['reverted']      = (int)$x['reverted'];
        $rows[] = $x;
    }
    $stmt->close();
    return $rows;
}

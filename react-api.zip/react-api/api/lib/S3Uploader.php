<?php
/*
 * Shared AWS S3 helper — same bucket/region/credentials already used by
 * internship-system/notes.php and problem_statements_api.php, reused here so
 * contact-import CSVs and campaign attachments stop accumulating permanently
 * on local cPanel disk. Nothing else in this feature talks to S3 directly —
 * always go through s3_upload_file()/s3_delete_key() below.
 */
require_once '/home/istudio/public_html/istudio_dashboard/api/vendor/autoload.php';

use Aws\S3\S3Client;
use Aws\Exception\AwsException;

function s3_client(): S3Client {
    return new S3Client([
        'version'     => 'latest',
        'region'      => 'ap-south-1',
        'credentials' => [
            'key'    => 'AKIAYVYU7O43T344J2MD',
            'secret' => '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',
        ],
    ]);
}

const S3_BUCKET = 'internshipstudio-prod-data-bucket-new';
const S3_REGION = 'ap-south-1';

/** Uploads a local file to S3 under $key, returns the permanent public URL, or null on failure. */
function s3_upload_file(string $localPath, string $key, string $contentType): ?string {
    if (!is_file($localPath)) return null;
    try {
        s3_client()->putObject([
            'Bucket'      => S3_BUCKET,
            'Key'         => $key,
            'SourceFile'  => $localPath,
            'ContentType' => $contentType,
        ]);
        return "https://" . S3_BUCKET . ".s3." . S3_REGION . ".amazonaws.com/{$key}";
    } catch (AwsException $e) {
        error_log('s3_upload_file failed for key ' . $key . ': ' . $e->getMessage());
        return null;
    }
}

function s3_delete_key(string $key): void {
    try {
        s3_client()->deleteObject(['Bucket' => S3_BUCKET, 'Key' => $key]);
    } catch (AwsException $e) {
        error_log('s3_delete_key failed for key ' . $key . ': ' . $e->getMessage());
    }
}

/** Downloads S3 bytes over HTTPS (used where we only have the public URL, e.g. SendWorker attachments). */
function s3_fetch_bytes(string $url): ?string {
    $ch = curl_init($url);
    curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 20]);
    $body = curl_exec($ch);
    $status = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    return ($status >= 200 && $status < 300) ? $body : null;
}

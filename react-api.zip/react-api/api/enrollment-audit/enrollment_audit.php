<?php
/**
 * /api/enrollment-audit/enrollment_audit.php  —  Enrollment Audit
 * ---------------------------------------------------------------------------
 * Cross-checks a Learnyst enrollment export (uploaded and parsed in the
 * browser) against this database. The browser sends the sheet's emails in
 * packets of 10,000; this endpoint answers one packet per request.
 *
 * For every email in a packet:
 *   1. Is it in `users`?  -> the ones that are NOT come back in `not_in_users`
 *      and become the first downloadable sheet.
 *   2. Only for rows the browser flagged `r:1` (their Product title matched the
 *      resume-building term): take the matched `users.user_id` and look for a
 *      `ninety_nine_store_orders` row on that user_id. The ones with NO order
 *      come back in `resume_no_order` and become the second sheet.
 *
 * Why the email->user_id map can hold several ids: `users` is not unique on
 * email (a learner who signed up twice has two rows). An email counts as
 * "has an order" when ANY of its user_ids has one - otherwise a duplicate
 * account would put a paying learner on the missing list.
 *
 * Two options the client may switch on (both default OFF, i.e. the literal
 * reading of the request):
 *   match_email_orders  also accept an order matched on ninety_nine_store_orders.email.
 *                       Store checkout is a guest flow, so older paid rows carry an
 *                       email and a NULL user_id - with this off they read as "no order".
 *   only_success        restrict orders to status = 'success' (initiated/failed
 *                       rows are carts, not purchases).
 *
 * POST (JSON):
 *   { action:"audit_batch",
 *     rows:[{e:"a@b.com", r:1}, ...],        // r=1 -> resume-building row
 *     match_email_orders:0|1, only_success:0|1 }
 *
 * Response: api_success({ checked, skipped, in_users, not_in_users:[],
 *                         resume_total, resume_in_users,
 *                         resume_not_registered:[], resume_no_order:[{email,user_id}] })
 * ---------------------------------------------------------------------------
 */
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../middleware/auth.php';

$jwt = require_jwt();
require_permission('enrollment_audit', $jwt);
require_method('POST');

/* One packet is 10k emails resolved with chunked IN() lookups - comfortably
   under a minute, but the default 30s can be tight on a cold buffer pool. */
@set_time_limit(180);

/* A packet larger than this is a client bug, not a bigger upload - the sheet is
   always split before it is sent. Capped rather than trusted so one request can
   never build a multi-megabyte IN() list. */
define('EA_MAX_PACKET', 20000);
/* IN() list size per query. Keeps each statement well inside max_allowed_packet
   while still letting the index do the work. */
define('EA_IN_CHUNK', 1000);

function ea_in_list($conn, array $vals) {
    return implode(',', array_map(
        fn($v) => "'" . $conn->real_escape_string((string)$v) . "'", $vals));
}

$in     = get_json_input();
$action = $in['action'] ?? '';

if ($action !== 'audit_batch') api_error('Unknown action');

$rows = $in['rows'] ?? [];
if (!is_array($rows) || !count($rows)) api_error('Packet contained no rows');
if (count($rows) > EA_MAX_PACKET) {
    api_error('Packet too large - send at most ' . EA_MAX_PACKET . ' rows per request');
}

$matchEmailOrders = !empty($in['match_email_orders']);
$onlySuccess      = !empty($in['only_success']);

/* The 99-store table is the second half of the audit; without it only the users
   check could run, and silently returning "nobody has an order" would be worse
   than saying so. */
$tbl = $conn->query("SELECT 1 FROM information_schema.TABLES
                      WHERE TABLE_SCHEMA = DATABASE()
                        AND TABLE_NAME = 'ninety_nine_store_orders' LIMIT 1");
if (!$tbl || !$tbl->num_rows) {
    api_error('Table ninety_nine_store_orders was not found in this database', 500);
}

/* -- normalise the packet ------------------------------------------------- */
$flags   = [];   // lowercased email => true when any of its rows is resume-building
$skipped = 0;
foreach ($rows as $r) {
    $e = strtolower(trim((string)(is_array($r) ? ($r['e'] ?? '') : $r)));
    if ($e === '' || !filter_var($e, FILTER_VALIDATE_EMAIL)) { $skipped++; continue; }
    if (!array_key_exists($e, $flags)) $flags[$e] = false;
    if (is_array($r) && !empty($r['r'])) $flags[$e] = true;
}
$emails = array_keys($flags);
if (!count($emails)) {
    api_success([
        'checked' => 0, 'skipped' => $skipped, 'in_users' => 0, 'not_in_users' => [],
        'resume_total' => 0, 'resume_in_users' => 0,
        'resume_not_registered' => [], 'resume_no_order' => [],
    ], 'Packet held no usable email addresses');
}

/* -- step 1: which emails exist in `users` -------------------------------- */
/* Compared with a plain IN() on the raw column so the email index is used.
   users.email collates case-insensitively, which is what lets the lowercased
   list still match a row stored as "Name@Gmail.com". */
$emailToUsers = [];
foreach (array_chunk($emails, EA_IN_CHUNK) as $chunk) {
    $list = ea_in_list($conn, $chunk);
    $res  = $conn->query("SELECT user_id, email FROM users WHERE email IN ($list)");
    while ($res && ($row = $res->fetch_assoc())) {
        $k = strtolower(trim((string)$row['email']));
        if (!isset($emailToUsers[$k])) $emailToUsers[$k] = [];
        $emailToUsers[$k][] = (int)$row['user_id'];
    }
}

$notInUsers = [];
foreach ($emails as $e) {
    if (!isset($emailToUsers[$e])) $notInUsers[] = $e;
}

/* -- step 2: resume-building rows -> ninety_nine_store_orders -------------- */
$resumeAll           = array_keys(array_filter($flags));
$resumeRegistered    = [];   // email => [user_id, ...]
$resumeNotRegistered = [];
foreach ($resumeAll as $e) {
    if (isset($emailToUsers[$e])) $resumeRegistered[$e] = $emailToUsers[$e];
    else                          $resumeNotRegistered[] = $e;
}

$statusCond = $onlySuccess ? " AND status = 'success'" : '';

$userIdsWithOrder = [];
if ($resumeRegistered) {
    $ids = [];
    foreach ($resumeRegistered as $list) foreach ($list as $uid) $ids[$uid] = true;
    foreach (array_chunk(array_keys($ids), EA_IN_CHUNK) as $chunk) {
        $list = implode(',', array_map('intval', $chunk));
        $res  = $conn->query("SELECT DISTINCT user_id FROM ninety_nine_store_orders
                               WHERE user_id IN ($list)$statusCond");
        while ($res && ($row = $res->fetch_assoc())) $userIdsWithOrder[(int)$row['user_id']] = true;
    }
}

$emailsWithOrder = [];
if ($matchEmailOrders && $resumeRegistered) {
    foreach (array_chunk(array_keys($resumeRegistered), EA_IN_CHUNK) as $chunk) {
        $list = ea_in_list($conn, $chunk);
        $res  = $conn->query("SELECT DISTINCT email FROM ninety_nine_store_orders
                               WHERE email IN ($list)$statusCond");
        while ($res && ($row = $res->fetch_assoc())) {
            $emailsWithOrder[strtolower(trim((string)$row['email']))] = true;
        }
    }
}

$resumeNoOrder = [];
foreach ($resumeRegistered as $email => $uids) {
    $has = false;
    foreach ($uids as $uid) {
        if (isset($userIdsWithOrder[$uid])) { $has = true; break; }
    }
    if (!$has && $matchEmailOrders && isset($emailsWithOrder[$email])) $has = true;
    if (!$has) $resumeNoOrder[] = ['email' => $email, 'user_id' => $uids[0]];
}

api_success([
    'checked'               => count($emails),
    'skipped'               => $skipped,
    'in_users'              => count($emailToUsers),
    'not_in_users'          => $notInUsers,
    'resume_total'          => count($resumeAll),
    'resume_in_users'       => count($resumeRegistered),
    'resume_not_registered' => $resumeNotRegistered,
    'resume_no_order'       => $resumeNoOrder,
], 'OK');

<?php
/*
 * Reuses the campaigns feature's CRON_SECRET (already guarded by
 * if(!defined())) instead of minting a second shared secret to manage.
 */
require_once __DIR__ . '/../../campaigns/lib/config.php';

define('CONTACT_UPLOAD_MAX_FILE_BYTES', 10 * 1024 * 1024); // 10MB
define('CONTACT_UPLOAD_MAX_ROWS', 50000);
define('CONTACT_IMPORT_CHUNK_SIZE', 1000); // rows processed per worker tick

if (!defined('CONTACT_UPLOADS_DIR')) {
    define('CONTACT_UPLOADS_DIR', __DIR__ . '/../uploads/contact_imports');
}
if (!defined('CONTACT_UPLOADS_TMP_DIR')) {
    define('CONTACT_UPLOADS_TMP_DIR', __DIR__ . '/../uploads/contact_imports_tmp');
}

// Every contact-import-worker.php run appends one line per event here — same
// verify-by-reading-a-log-file approach as campaigns/lib/config.php's WORKER_LOG_PATH.
if (!defined('CONTACT_IMPORT_LOG_PATH')) {
    define('CONTACT_IMPORT_LOG_PATH', __DIR__ . '/../worker.log');
}

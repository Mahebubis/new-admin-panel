<?php
/*
 * Canonical contact fields + CSV header auto-matching, shared by
 * contact_uploads.php's preview_upload/start_import (Step 1/2 of the import
 * wizard) and ContactImportWorker.php (the actual row-by-row upsert).
 *
 * Single source of truth for "what column name should I put in my CSV" —
 * mirrored as static option labels in ImportContactsWizard.jsx's Step 2
 * dropdown so the two can't silently drift apart.
 */

const CONTACT_CANONICAL_FIELDS = [
    'email'      => ['label' => 'Email',      'column' => 'email',      'required' => true],
    'first_name' => ['label' => 'First Name', 'column' => 'first_name', 'required' => false],
    'last_name'  => ['label' => 'Last Name',  'column' => 'last_name',  'required' => false],
    'phone'      => ['label' => 'Phone',      'column' => 'phone',      'required' => false],
    'state'      => ['label' => 'State',      'column' => 'state',     'required' => false],
    'country'    => ['label' => 'Country',    'column' => 'country',   'required' => false],
    'city'       => ['label' => 'City',       'column' => 'city',      'required' => false],
];

// header alias -> canonical key, matched after csv_normalize_header() strips
// case/space/underscore/hyphen differences (so "First Name", "FIRST_NAME",
// "first-name" and "FNAME" all resolve identically).
const CONTACT_HEADER_ALIASES = [
    'EMAIL'         => 'email', 'EMAILADDRESS' => 'email', 'EMAIL ADDRESS' => 'email',
    'FIRSTNAME'     => 'first_name', 'FNAME' => 'first_name',
    'LASTNAME'      => 'last_name', 'LNAME' => 'last_name', 'SURNAME' => 'last_name',
    'PHONE'         => 'phone', 'PHONENUMBER' => 'phone', 'MOBILE' => 'phone', 'MOBILENUMBER' => 'phone',
    'STATE'         => 'state',
    'COUNTRY'       => 'country',
    'CITY'          => 'city',
];

/** "First Name" / "FIRST_NAME" / "first-name" all normalize to "FIRSTNAME". */
function csv_normalize_header(string $h): string {
    return strtoupper(preg_replace('/[^A-Za-z0-9]/', '', $h));
}

/** @return array<string,string|null> CSV header => canonical field key, or null for an unmatched ("custom") column. */
function csv_suggest_mapping(array $headers): array {
    $mapping = [];
    foreach ($headers as $h) {
        $norm = csv_normalize_header($h);
        $mapping[$h] = CONTACT_HEADER_ALIASES[$norm] ?? null;
    }
    return $mapping;
}

/**
 * Applies a confirmed header->canonical mapping to one CSV data row, returning
 * the shape contact_upsert() (in ContactImportWorker.php) expects: the 7 core
 * columns plus an `extra_attributes` array of every unmapped/custom column.
 *
 * @param array $row       one fgetcsv() row, same order as $headers
 * @param array $headers   the CSV's header row (Step 1's detected column order)
 * @param array $mapping   header => canonical key ('email','first_name',...) or null/'extra' for custom fields
 * @param array $defaults  header => default value, used when a mapped cell is blank
 */
function csv_apply_mapping(array $row, array $headers, array $mapping, array $defaults = []): array {
    $out = ['email' => null, 'first_name' => null, 'last_name' => null, 'phone' => null,
            'state' => null, 'country' => null, 'city' => null, 'extra_attributes' => []];

    foreach ($headers as $i => $header) {
        $value = trim((string)($row[$i] ?? ''));
        if ($value === '' && isset($defaults[$header]) && $defaults[$header] !== '') $value = $defaults[$header];

        $target = $mapping[$header] ?? null;
        // array_key_exists (NOT isset) — isset() returns false for a null value, and every
        // canonical field in $out starts out as null, which would silently misroute every
        // mapped column into extra_attributes instead.
        if ($target && $target !== 'extra' && $target !== 'extra_attributes' && array_key_exists($target, $out)) {
            $out[$target] = $value !== '' ? $value : null;
        } elseif ($value !== '') {
            // Unmapped/custom column — preserved, never silently dropped.
            $out['extra_attributes'][$header] = $value;
        }
    }
    return $out;
}

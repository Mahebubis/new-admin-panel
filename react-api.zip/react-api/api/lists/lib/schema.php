<?php
/*
 * lists_ensure_schema() — idempotent CREATE TABLE IF NOT EXISTS for the 5
 * tables backing the Contact Lists (CSV import) feature. Called at the top
 * of every entrypoint in this feature, mirrors campaigns/lib/schema.php's
 * campaigns_ensure_schema(). SQL is documented in ../lists_schema.sql.
 *
 * `campaign_contacts` is intentionally NOT the same table as `users` —
 * `users` is the legacy table of actual registered students (password,
 * payment_status, exam data, etc.); a marketing contact imported from a CSV
 * (a lead who may never have registered) doesn't belong mixed into that
 * table. Lists/contacts are a separate, self-contained store, unioned in
 * alongside Segments (which read from `users`) at campaign-send time — see
 * campaigns/lib/AudienceResolver.php.
 */
function lists_ensure_schema() {
    global $conn;
    if (!$conn) return;

    try {
        $conn->query("CREATE TABLE IF NOT EXISTS campaign_contacts (
            id                BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            email             VARCHAR(255) NOT NULL,
            first_name        VARCHAR(255) DEFAULT NULL,
            last_name         VARCHAR(255) DEFAULT NULL,
            phone             VARCHAR(50)  DEFAULT NULL,
            state             VARCHAR(100) DEFAULT NULL,
            country           VARCHAR(100) DEFAULT NULL,
            city              VARCHAR(100) DEFAULT NULL,
            extra_attributes  JSON DEFAULT NULL,
            created_at        TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at        TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            UNIQUE INDEX uq_email (email),
            INDEX idx_created_at (created_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

        $conn->query("CREATE TABLE IF NOT EXISTS campaign_lists (
            id             INT AUTO_INCREMENT PRIMARY KEY,
            name           VARCHAR(255) NOT NULL,
            description    VARCHAR(500) DEFAULT NULL,
            kind           ENUM('list','blocklist') NOT NULL DEFAULT 'list',
            contact_count  INT NOT NULL DEFAULT 0,
            created_by     BIGINT UNSIGNED DEFAULT NULL,
            created_at     TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at     TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            INDEX idx_name (name),
            INDEX idx_created_at (created_at),
            INDEX idx_kind (kind)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

        $conn->query("CREATE TABLE IF NOT EXISTS campaign_list_members (
            list_id     INT NOT NULL,
            contact_id  BIGINT UNSIGNED NOT NULL,
            added_at    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (list_id, contact_id),
            INDEX idx_contact (contact_id),
            CONSTRAINT fk_clm_list    FOREIGN KEY (list_id)    REFERENCES campaign_lists(id)    ON DELETE CASCADE,
            CONSTRAINT fk_clm_contact FOREIGN KEY (contact_id) REFERENCES campaign_contacts(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

        $conn->query("CREATE TABLE IF NOT EXISTS campaign_contact_uploads (
            id                  INT AUTO_INCREMENT PRIMARY KEY,
            list_id             INT NOT NULL,
            original_filename   VARCHAR(255) NOT NULL,
            stored_path         VARCHAR(500) NOT NULL,
            column_mapping      JSON DEFAULT NULL,
            status              ENUM('pending','processing','processed','failed') NOT NULL DEFAULT 'pending',
            total_rows          INT NOT NULL DEFAULT 0,
            processed_rows      INT NOT NULL DEFAULT 0,
            success_count       INT NOT NULL DEFAULT 0,
            failed_count        INT NOT NULL DEFAULT 0,
            cursor_byte_offset  BIGINT UNSIGNED NOT NULL DEFAULT 0,
            uploaded_by         BIGINT UNSIGNED DEFAULT NULL,
            created_at          TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            started_at          DATETIME DEFAULT NULL,
            completed_at        DATETIME DEFAULT NULL,
            INDEX idx_status (status),
            INDEX idx_list (list_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

        $conn->query("CREATE TABLE IF NOT EXISTS campaign_contact_upload_errors (
            id             BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            upload_id      INT NOT NULL,
            row_number     INT NOT NULL,
            email          VARCHAR(255) DEFAULT NULL,
            error_message  VARCHAR(500) DEFAULT NULL,
            raw_row        JSON DEFAULT NULL,
            created_at     TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_upload (upload_id),
            CONSTRAINT fk_ccue_upload FOREIGN KEY (upload_id) REFERENCES campaign_contact_uploads(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    } catch (\Throwable $e) {
        // Another concurrent request is doing this exact same idempotent setup right now —
        // every statement above is CREATE-IF-NOT-EXISTS, so whichever request finishes first
        // still leaves the schema correct; this request just continues instead of fatal-erroring.
        error_log('lists_ensure_schema: CREATE TABLE block failed — ' . $e->getMessage());
    }

    // Each additive ALTER gets its own try/catch — so one failing statement (e.g. a stale
    // partial index from an earlier interrupted deploy) can't silently prevent the others
    // from running, and any failure is individually visible in the PHP error log instead of
    // one broad catch swallowing everything.
    try {
        $chk = $conn->query("SHOW COLUMNS FROM campaign_lists LIKE 'kind'");
        if ($chk && $chk->num_rows === 0) {
            $conn->query("ALTER TABLE campaign_lists ADD COLUMN kind ENUM('list','blocklist') NOT NULL DEFAULT 'list' AFTER description");
        }
    } catch (\Throwable $e) {
        error_log('lists_ensure_schema: ADD COLUMN kind failed — ' . $e->getMessage());
    }
    try {
        $chkIdx = $conn->query("SHOW INDEX FROM campaign_lists WHERE Key_name='idx_kind'");
        if ($chkIdx && $chkIdx->num_rows === 0) {
            $conn->query("ALTER TABLE campaign_lists ADD INDEX idx_kind (kind)");
        }
    } catch (\Throwable $e) {
        error_log('lists_ensure_schema: ADD INDEX idx_kind failed — ' . $e->getMessage());
    }
    try {
        $chk2 = $conn->query("SHOW COLUMNS FROM campaign_contact_uploads LIKE 's3_url'");
        if ($chk2 && $chk2->num_rows === 0) {
            $conn->query("ALTER TABLE campaign_contact_uploads ADD COLUMN s3_url VARCHAR(500) DEFAULT NULL AFTER stored_path");
        }
    } catch (\Throwable $e) {
        error_log('lists_ensure_schema: ADD COLUMN s3_url failed — ' . $e->getMessage());
    }
    try {
        // Why this lives on the membership row (campaign_list_members) rather than on
        // campaign_contacts itself: the reason a contact was blocklisted is a property of
        // THAT membership, not of the contact as a whole — the same email could in theory
        // also belong to an ordinary list, where "reason" has no meaning.
        $chk3 = $conn->query("SHOW COLUMNS FROM campaign_list_members LIKE 'reason'");
        if ($chk3 && $chk3->num_rows === 0) {
            $conn->query("ALTER TABLE campaign_list_members ADD COLUMN reason VARCHAR(500) DEFAULT NULL AFTER added_at");
        }
    } catch (\Throwable $e) {
        error_log('lists_ensure_schema: ADD COLUMN reason failed — ' . $e->getMessage());
    }
}

/*
 * Returns the id of the single global Blocklist row (kind='blocklist'),
 * creating it on first use — mirrors the seeded-singleton pattern already
 * used for email_esp_settings in campaigns/lib/schema.php. There is only
 * ever exactly one blocklist (unlike Lists, which supports many), matching
 * the reference product's single "Blocklisted contacts" table.
 */
function lists_get_or_create_blocklist_id(): int {
    global $conn;
    try {
        $r = $conn->query("SELECT id FROM campaign_lists WHERE kind='blocklist' LIMIT 1");
    } catch (\Throwable $e) {
        // Defensive fallback — if `kind` somehow isn't there yet (e.g. this ever gets called
        // from a path that skipped lists_ensure_schema(), or a prior deploy only partially
        // applied it), force the additive ALTER to run right now instead of fatal-erroring.
        error_log('lists_get_or_create_blocklist_id: kind column missing, re-running lists_ensure_schema() — ' . $e->getMessage());
        lists_ensure_schema();
        $r = $conn->query("SELECT id FROM campaign_lists WHERE kind='blocklist' LIMIT 1");
    }
    $row = $r ? $r->fetch_assoc() : null;
    if ($row) return (int)$row['id'];

    $conn->query("INSERT INTO campaign_lists (name, description, kind) VALUES ('Blocklist', 'Contacts who must never receive a campaign', 'blocklist')");
    return (int)$conn->insert_id;
}

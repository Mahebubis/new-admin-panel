<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/CsvMapper.php';
require_once __DIR__ . '/../../lib/S3Uploader.php';
require_once __DIR__ . '/../../attributes/lib/schema.php';
require_once __DIR__ . '/schema.php';
require_once __DIR__ . '/../../campaigns/lib/EspSuppressionSync.php';
/*
 * The Contact-activity trigger's "an attribute was updated" ledger. Required here because
 * this worker is one of only two places on the platform that CHANGES a contact attribute's
 * value, and a change nobody recorded is a change no journey can ever react to. Everything
 * in that file is guarded, so an import can never fail because of it.
 */
require_once __DIR__ . '/../../journeys/lib/ContactActivity.php';

/** Same log-to-a-file-so-it's-debuggable-without-DB-access pattern as campaigns/lib/SendWorker.php's campaign_log(). */
function contact_import_log(string $msg): void {
    $line = '[' . date('Y-m-d H:i:s') . '] ' . $msg . "\n";
    @file_put_contents(CONTACT_IMPORT_LOG_PATH, $line, FILE_APPEND | LOCK_EX);
}

/**
 * Non-blocking "fire and forget" kick so Confirm & Import doesn't wait for the
 * next cron minute — mirrors campaigns/lib/SendWorker.php's trigger_worker_async()
 * exactly, just pointed at this feature's own worker entrypoint/secret-less path
 * (same CRON_SECRET, reused rather than minting a second one).
 */
function contact_import_trigger_worker_async(int $uploadId) {
    $host = 'cit3.internshipstudio.com';
    $path = '/admin/react-api/api/lists/contact-import-worker.php?cron_secret=' . urlencode(CRON_SECRET) . '&upload_id=' . $uploadId;
    $fp = @fsockopen('ssl://' . $host, 443, $errno, $errstr, 1);
    if (!$fp) return;
    stream_set_timeout($fp, 1);
    fwrite($fp, "GET $path HTTP/1.1\r\nHost: $host\r\nConnection: Close\r\n\r\n");
    fclose($fp);
}

/**
 * Upserts one contact by email (INSERT...ON DUPLICATE KEY UPDATE against the
 * uq_email unique index), links it into the target list, and returns the
 * contact's id. JSON_MERGE_PATCH on extra_attributes means a later import
 * that only supplies some custom columns won't wipe out custom fields an
 * earlier import wrote — keys merge instead of the whole blob being replaced.
 */
function contact_upsert(array $data, int $listId, ?string $reason = null): int {
    global $conn;
    $email = $conn->real_escape_string($data['email']);
    $fname = $conn->real_escape_string((string)($data['first_name'] ?? ''));
    $lname = $conn->real_escape_string((string)($data['last_name'] ?? ''));
    $phone = $conn->real_escape_string((string)($data['phone'] ?? ''));
    $state = $conn->real_escape_string((string)($data['state'] ?? ''));
    $country = $conn->real_escape_string((string)($data['country'] ?? ''));
    $city  = $conn->real_escape_string((string)($data['city'] ?? ''));
    $extra = $conn->real_escape_string(json_encode($data['extra_attributes'] ?? new stdClass()));

    $conn->query("INSERT INTO campaign_contacts (email, first_name, last_name, phone, state, country, city, extra_attributes)
                  VALUES ('$email', " . ($fname !== '' ? "'$fname'" : 'NULL') . ", " . ($lname !== '' ? "'$lname'" : 'NULL') . ",
                          " . ($phone !== '' ? "'$phone'" : 'NULL') . ", " . ($state !== '' ? "'$state'" : 'NULL') . ",
                          " . ($country !== '' ? "'$country'" : 'NULL') . ", " . ($city !== '' ? "'$city'" : 'NULL') . ", '$extra')
                  ON DUPLICATE KEY UPDATE
                      id = LAST_INSERT_ID(id),
                      first_name = COALESCE(VALUES(first_name), first_name),
                      last_name  = COALESCE(VALUES(last_name), last_name),
                      phone      = COALESCE(VALUES(phone), phone),
                      state      = COALESCE(VALUES(state), state),
                      country    = COALESCE(VALUES(country), country),
                      city       = COALESCE(VALUES(city), city),
                      extra_attributes = JSON_MERGE_PATCH(COALESCE(extra_attributes, '{}'), VALUES(extra_attributes))");
    $contactId = $conn->insert_id;
    $wasAlreadyInThisList = false;
    $chk = $conn->query("SELECT 1 FROM campaign_list_members WHERE list_id=$listId AND contact_id=$contactId");
    if ($chk && $chk->num_rows > 0) $wasAlreadyInThisList = true;
    if ($reason !== null && $reason !== '') {
        $reasonE = $conn->real_escape_string($reason);
        $conn->query("INSERT INTO campaign_list_members (list_id, contact_id, reason) VALUES ($listId, $contactId, '$reasonE')
                      ON DUPLICATE KEY UPDATE reason = VALUES(reason)");
    } else {
        $conn->query("INSERT IGNORE INTO campaign_list_members (list_id, contact_id) VALUES ($listId, $contactId)");
    }

    // Every path that adds someone to the Blocklist specifically (CSV import, the single-
    // contact "Add" action, or an auto-added hard bounce/unsubscribe — see
    // sendgrid-webhook.php / elasticemail-webhook.php) funnels through here, so this is the
    // one place that needs to also tell the ESPs themselves to suppress the address —
    // otherwise our own AudienceResolver exclusion would be the only thing stopping a send,
    // and the provider would still be willing to accept it. Fans out to every configured
    // provider, not just the active one (see EspSuppressionSync.php for why).
    // Skipped if they were already in the blocklist (no new suppression needed).
    if (!$wasAlreadyInThisList && $listId === lists_get_or_create_blocklist_id()) {
        esp_add_global_suppression($data['email']);
    }

    if (!empty($data['extra_attributes'])) {
        fan_out_extra_attributes($data['email'], $data['extra_attributes']);
    }

    return $contactId;
}

/**
 * Every CSV column that isn't a canonical contact field (email/first_name/.../city)
 * ends up here, keyed by its original header text (e.g. "COLLEGE" => "MIT"). For each,
 * normalize the header into an attribute name (same rule attributes.php's manual create
 * uses, so "College" and "COLLEGE" resolve to the same attribute), then one of three things:
 *   1. An attribute with that name already exists and is MAPPED ('system') to a real
 *      table — write straight into that live table/column, matched back to this email
 *      (see write_mapped_attribute_value()). Confirmed, deliberate behavior: this CAN
 *      overwrite real system-of-record data (e.g. users.fname), not just campaign
 *      personalization data — a stale/wrong CSV column can silently change live records.
 *   2. An attribute with that name already exists and is unmapped ('custom') — store the
 *      value in its own column in campaign_attribute_data, keyed by email.
 *   3. No attribute with that name exists yet — auto-create one ('custom'), add its
 *      column to campaign_attribute_data, then store the value there.
 * This is what makes an uploaded CSV column immediately usable as XX_COLLEGE_XX in a
 * campaign template with zero manual setup — see AttributeResolver.php for the read side.
 */
function fan_out_extra_attributes(string $email, array $extraAttributes): void {
    global $conn;
    $emailE = $conn->real_escape_string($email);

    foreach ($extraAttributes as $header => $value) {
        $value = trim((string)$value);
        if ($value === '') continue;

        $name = normalize_attribute_name((string)$header);
        if ($name === '') continue;
        $nameE = $conn->real_escape_string($name);

        $r = $conn->query("SELECT id, category, mapped_db, mapped_table, mapped_column, mapped_join_col
                            FROM campaign_attributes WHERE name='$nameE' LIMIT 1");
        $attr = $r ? $r->fetch_assoc() : null;

        if ($attr && $attr['category'] === 'system') {
            write_mapped_attribute_value($attr, $email, $value);
            journey_contact_log_update($email, $name, $value, 'import');
            continue;
        }

        if (!$attr) {
            $conn->query("INSERT INTO campaign_attributes (name, category) VALUES ('$nameE', 'custom')");
            $attributeId = $conn->insert_id;
            attribute_log($attributeId, $name, 'Auto-created from CSV import', null);
        }

        attribute_data_ensure_column($name);
        $col = attribute_column_name($name);
        $valueE = $conn->real_escape_string($value);
        $conn->query("INSERT INTO campaign_attribute_data (email, `$col`) VALUES ('$emailE', '$valueE')
                      ON DUPLICATE KEY UPDATE `$col`=VALUES(`$col`)");
        /*
         * One ledger row per attribute actually written, so a journey triggered on
         * "COLLEGE was updated" fires for exactly the contacts whose COLLEGE this import
         * touched — not for everyone whose row happened to move. See
         * journeys/lib/ContactActivity.php for why the ledger is needed at all.
         */
        journey_contact_log_update($email, $name, $value, 'import');
    }
}

/**
 * Writes one value directly into a mapped ('system') attribute's real source table,
 * matched back to $email via the attribute's own join column — resolving a user_id from
 * the email first when the mapped table is keyed by user_id (a CSV contact only ever
 * carries an email, never a user_id directly). Silently skipped when the email isn't a
 * registered user and the mapped table needs a user_id to match on — there's nothing to
 * attach the value to in that case.
 */
function write_mapped_attribute_value(array $attr, string $email, string $value): void {
    global $conn;
    $db = $attr['mapped_db']; $table = $attr['mapped_table']; $col = $attr['mapped_column']; $joinCol = $attr['mapped_join_col'];
    if (!$db || !$table || !$col || !$joinCol) return;
    $qualified = "`$db`.`$table`";
    $valueE = $conn->real_escape_string($value);
    $emailE = $conn->real_escape_string($email);

    if ($joinCol === 'user_id') {
        $uRes = $conn->query("SELECT user_id FROM users WHERE email='$emailE' LIMIT 1");
        $uRow = $uRes ? $uRes->fetch_assoc() : null;
        if (!$uRow) {
            contact_import_log("write_mapped_attribute_value: $email is not a registered user — skipping write to $qualified.$col (needs user_id to match on)");
            return;
        }
        $conn->query("UPDATE $qualified SET `$col`='$valueE' WHERE user_id=" . (int)$uRow['user_id']);
    } else {
        $conn->query("UPDATE $qualified SET `$col`='$valueE' WHERE email='$emailE'");
    }
}

/**
 * Processes one chunk of a single import job (or every due job, if $uploadId
 * is null — the recurring cron sweep). Resumes via a BYTE offset persisted in
 * cursor_byte_offset, not a row-skip count, so every tick costs O(chunk size)
 * regardless of how far into a large file it's resuming (re-reading from the
 * start and skipping N rows every tick would be quadratic overall).
 */
function contact_import_process_batch(int $chunkSize = 1000, ?int $uploadId = null): array {
    global $conn;

    $filter = $uploadId ? "id=" . (int)$uploadId : "status IN ('pending','processing')";
    $res = $conn->query("SELECT id FROM campaign_contact_uploads WHERE $filter");
    $ids = [];
    while ($res && $row = $res->fetch_assoc()) $ids[] = (int)$row['id'];

    contact_import_log('tick: ' . count($ids) . ' upload(s) to check' . ($uploadId ? " (instant kick for upload #$uploadId)" : ' (cron sweep)'));

    $processedTotal = 0;
    foreach ($ids as $id) {
        $r = $conn->query("SELECT * FROM campaign_contact_uploads WHERE id=$id LIMIT 1");
        $upload = $r ? $r->fetch_assoc() : null;
        if (!$upload || !in_array($upload['status'], ['pending', 'processing'], true)) continue;

        if ($upload['status'] === 'pending') {
            $conn->query("UPDATE campaign_contact_uploads SET status='processing', started_at=NOW() WHERE id=$id");
        }

        $mappingCfg = json_decode($upload['column_mapping'] ?? '{}', true) ?: [];
        $mapping  = $mappingCfg['mapping'] ?? [];
        $defaults = $mappingCfg['defaults'] ?? [];
        $headers  = array_keys($mapping); // preserves the original CSV column order (see ContactImportWorker.php header comment)

        if (!is_file($upload['stored_path'])) {
            contact_import_log("upload #$id: stored file missing at {$upload['stored_path']} -> marking FAILED");
            $conn->query("UPDATE campaign_contact_uploads SET status='failed', completed_at=NOW() WHERE id=$id");
            continue;
        }

        $fh = fopen($upload['stored_path'], 'r');
        if (!$fh) { contact_import_log("upload #$id: could not open file -> marking FAILED"); $conn->query("UPDATE campaign_contact_uploads SET status='failed', completed_at=NOW() WHERE id=$id"); continue; }

        if ((int)$upload['cursor_byte_offset'] === 0) {
            fgetcsv($fh); // skip the header line on the very first tick
        } else {
            fseek($fh, (int)$upload['cursor_byte_offset']);
        }

        $rowNumber = (int)$upload['processed_rows'];
        $successDelta = 0; $failedDelta = 0; $rowsThisTick = 0;
        while ($rowsThisTick < $chunkSize && ($row = fgetcsv($fh)) !== false) {
            $rowsThisTick++; $rowNumber++;
            if (count($row) === 1 && $row[0] === null) continue; // trailing blank line

            $data = csv_apply_mapping($row, $headers, $mapping, $defaults);
            $email = $data['email'];
            if (!$email || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
                $failedDelta++;
                $emailE = $conn->real_escape_string((string)$email);
                $errMsg = $conn->real_escape_string($email ? 'Invalid email address' : 'Missing email address');
                $rawE = $conn->real_escape_string(json_encode(array_combine(array_slice($headers, 0, count($row)), $row)));
                $conn->query("INSERT INTO campaign_contact_upload_errors (upload_id, row_number, email, error_message, raw_row)
                              VALUES ($id, $rowNumber, '$emailE', '$errMsg', '$rawE')");
                continue;
            }

            try {
                contact_upsert($data, (int)$upload['list_id']);
                $successDelta++;
            } catch (\Throwable $e) {
                $failedDelta++;
                $emailE = $conn->real_escape_string($email);
                $errMsg = $conn->real_escape_string(substr($e->getMessage(), 0, 480));
                $conn->query("INSERT INTO campaign_contact_upload_errors (upload_id, row_number, email, error_message)
                              VALUES ($id, $rowNumber, '$emailE', '$errMsg')");
            }
        }

        $atEof = feof($fh) || $rowsThisTick < $chunkSize;
        $newOffset = ftell($fh);
        fclose($fh);

        $conn->query("UPDATE campaign_contact_uploads SET
            processed_rows = processed_rows + $rowsThisTick,
            success_count = success_count + $successDelta,
            failed_count = failed_count + $failedDelta,
            cursor_byte_offset = $newOffset
            WHERE id=$id");
        $processedTotal += $rowsThisTick;

        if ($atEof) {
            $r2 = $conn->query("SELECT success_count, failed_count FROM campaign_contact_uploads WHERE id=$id LIMIT 1");
            $final = $r2 ? $r2->fetch_assoc() : ['success_count' => 0, 'failed_count' => 0];
            $finalStatus = ((int)$final['success_count'] > 0 || (int)$final['failed_count'] === 0) ? 'processed' : 'failed';
            $conn->query("UPDATE campaign_contact_uploads SET status='$finalStatus', completed_at=NOW() WHERE id=$id");
            $conn->query("UPDATE campaign_lists SET contact_count = (
                              SELECT COUNT(*) FROM campaign_list_members WHERE list_id={$upload['list_id']}
                          ) WHERE id={$upload['list_id']}");
            contact_import_log("upload #$id: COMPLETED -> status=$finalStatus (success={$final['success_count']}, failed={$final['failed_count']})");

            // Archive to S3 and remove the local copy — cPanel disk only ever holds files
            // actively being processed above, never a permanently-growing history. The
            // chunked fseek/fgetcsv/ftell processing above is untouched local-disk logic;
            // this only runs once, after the import has fully finished.
            $s3Url = s3_upload_file($upload['stored_path'], 'campaign_contact_uploads/' . $id . '/' . basename($upload['original_filename']), 'text/csv');
            if ($s3Url) {
                $s3UrlE = $conn->real_escape_string($s3Url);
                $conn->query("UPDATE campaign_contact_uploads SET s3_url='$s3UrlE' WHERE id=$id");
                @unlink($upload['stored_path']);
                contact_import_log("upload #$id: archived to S3 ($s3Url) and removed local copy");
            } else {
                contact_import_log("upload #$id: S3 archival FAILED — local copy kept at {$upload['stored_path']}");
            }
        } else {
            contact_import_log("upload #$id: this tick processed=$rowsThisTick (success=$successDelta, failed=$failedDelta), still in progress");
        }
    }

    return ['uploads' => count($ids), 'processed' => $processedTotal];
}

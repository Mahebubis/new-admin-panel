<?php
/*
 * Cron / instant-kick entrypoint for the contact-list CSV import batch
 * processor. Mirrors campaigns/campaign-send-worker.php exactly (CLI/HTTP
 * dual-mode, shared CRON_SECRET, flock() guard) but against its OWN lock
 * file, so this job and the campaign-send worker never block each other.
 *
 * Cron (reliable safety-net — runs every minute once set up):
 *   * * * * * /usr/local/bin/ea-php83 /home/istudio/public_html/cit3/admin/react-api/api/lists/contact-import-worker.php >> /home/istudio/public_html/cit3/admin/react-api/api/lists/worker.log 2>&1
 *
 * HTTP fallback (used internally by contact_import_trigger_worker_async() for
 * the instant "Confirm & Import" kick — requires the shared cron_secret, NOT
 * a public endpoint):
 *   GET .../contact-import-worker.php?cron_secret=...&upload_id=123
 */
ini_set('display_errors', 0);
error_reporting(E_ALL & ~E_WARNING & ~E_NOTICE & ~E_DEPRECATED);
$_SERVER['REQUEST_METHOD'] = $_SERVER['REQUEST_METHOD'] ?? 'CLI';

require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/lib/config.php';
require_once __DIR__ . '/lib/schema.php';
require_once __DIR__ . '/lib/ContactImportWorker.php';
require_once __DIR__ . '/../attributes/lib/schema.php';
lists_ensure_schema();
attributes_ensure_schema();

$isCli = (php_sapi_name() === 'cli');
$isAuthorizedHttp = !$isCli && ($_GET['cron_secret'] ?? '') === CRON_SECRET;
if (!$isCli && !$isAuthorizedHttp) {
    http_response_code(403);
    echo "forbidden\n";
    exit;
}

$uploadId = isset($_GET['upload_id']) ? (int)$_GET['upload_id'] : null;
if ($isCli && isset($argv[1])) $uploadId = (int)$argv[1];

contact_import_log('worker invoked via ' . ($isCli ? 'CLI (cron)' : 'HTTP (instant kick)')
    . ($uploadId ? ", upload_id=$uploadId" : ', no specific upload_id (cron sweep)'));

// Separate lock file from campaign_worker.lock — a slow email-send tick must
// never block contact imports from progressing, and vice versa.
$lockPath = sys_get_temp_dir() . '/contact_import_worker.lock';
$lockFp = fopen($lockPath, 'c');
if (!$lockFp || !flock($lockFp, LOCK_EX | LOCK_NB)) {
    contact_import_log('skip — another worker run is already in progress');
    exit;
}

$result = contact_import_process_batch(CONTACT_IMPORT_CHUNK_SIZE, $uploadId);
contact_import_log('tick finished: ' . json_encode($result));

flock($lockFp, LOCK_UN);
fclose($lockFp);

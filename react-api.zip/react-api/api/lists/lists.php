<?php
/*
 * /api/lists/lists.php
 *
 * action=list            &page &per_page &search        → paginated lists (kind='list' only — also
 *                                                            feeds the campaign wizard's unified
 *                                                            Segments/Lists picker; the Blocklist is
 *                                                            a separate kind and never shows up here)
 * action=get_or_create_blocklist                        → id of the single global Blocklist row
 *                                                            (kind='blocklist'), created on first use
 * action=get              &id                            → single list row
 * action=create           &name &description             → create a new (empty) list
 * action=rename            &id &name &description         → rename/edit description
 * action=delete           &id                             → delete list (cascades membership)
 * action=members          &id &page &per_page &search     → paginated contacts belonging to a list
 * action=remove_member     &list_id &contact_id           → remove one contact from a list
 * action=add_contact       &list_id &email [&first_name &last_name &phone &state &country &city &reason]
 *                                                          → add a single contact without a CSV import
 *                                                            (reason is only meaningful for the Blocklist —
 *                                                            stored on the membership row, not the contact)
 * action=update_contact    &contact_id [&first_name &last_name &phone &state &country &city]
 *                                                          → edit a contact's details in place
 * action=download          &id                            → CSV export of a list's contacts
 */
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../middleware/auth.php';
require_once __DIR__ . '/lib/schema.php';
require_once __DIR__ . '/lib/ContactImportWorker.php';
require_once __DIR__ . '/../campaigns/lib/EspSuppressionSync.php';

lists_ensure_schema();

$jwt = require_jwt();
require_permission('netcore_behaviour', $jwt);

function jin($k, $d = null) { $v = $_REQUEST[$k] ?? null; return ($v === null || $v === '') ? $d : $v; }

$action = jin('action', '');

if ($action === 'list') {
    $page    = max(1, (int)jin('page', 1));
    $perPage = max(1, min(100, (int)jin('per_page', 10)));
    $search  = trim((string)jin('search', ''));
    $offset  = ($page - 1) * $perPage;

    $where = "WHERE kind='list'";
    if ($search !== '') $where .= " AND name LIKE '%" . $conn->real_escape_string($search) . "%'";

    $tr = $conn->query("SELECT COUNT(*) AS c FROM campaign_lists $where");
    $total = $tr ? (int)$tr->fetch_assoc()['c'] : 0;

    $r = $conn->query("SELECT id, name, description, contact_count, created_at, updated_at
                        FROM campaign_lists $where
                        ORDER BY id DESC LIMIT $perPage OFFSET $offset");
    $rows = [];
    while ($r && $row = $r->fetch_assoc()) $rows[] = $row;

    api_success([
        'lists' => $rows, 'total' => $total, 'page' => $page, 'per_page' => $perPage,
        'pages' => $total > 0 ? (int)ceil($total / $perPage) : 1,
    ]);
}

if ($action === 'get_or_create_blocklist') {
    api_success(['id' => lists_get_or_create_blocklist_id()]);
}

if ($action === 'get') {
    $id = (int)jin('id', 0);
    $r = $conn->query("SELECT * FROM campaign_lists WHERE id=$id LIMIT 1");
    $row = $r ? $r->fetch_assoc() : null;
    if (!$row) api_error('Not found', 404);
    api_success(['list' => $row]);
}

if ($action === 'create') {
    $name = trim((string)jin('name', ''));
    $desc = trim((string)jin('description', ''));
    if ($name === '') api_error('List name required');

    $nameE = $conn->real_escape_string($name);
    $descE = $conn->real_escape_string($desc);
    $conn->query("INSERT INTO campaign_lists (name, description, created_by) VALUES ('$nameE', '$descE', " . (int)($jwt['user_id'] ?? 0) . ")");
    api_success(['id' => $conn->insert_id]);
}

if ($action === 'rename') {
    $id   = (int)jin('id', 0);
    $name = trim((string)jin('name', ''));
    $desc = jin('description', null);
    if (!$id) api_error('id required');
    if ($name === '') api_error('List name required');

    $nameE = $conn->real_escape_string($name);
    $set = ["name='$nameE'"];
    if ($desc !== null) $set[] = "description='" . $conn->real_escape_string($desc) . "'";
    $conn->query("UPDATE campaign_lists SET " . implode(', ', $set) . " WHERE id=$id");
    api_success([]);
}

if ($action === 'delete') {
    $id = (int)jin('id', 0);
    if (!$id) api_error('id required');
    $conn->query("DELETE FROM campaign_lists WHERE id=$id"); // FK cascade clears campaign_list_members
    api_success([]);
}

if ($action === 'members') {
    $id      = (int)jin('id', 0);
    $page    = max(1, (int)jin('page', 1));
    $perPage = max(1, min(200, (int)jin('per_page', 25)));
    $search  = trim((string)jin('search', ''));
    $offset  = ($page - 1) * $perPage;

    $whereExtra = '';
    if ($search !== '') {
        $s = $conn->real_escape_string($search);
        $whereExtra = " AND (c.email LIKE '%$s%' OR c.first_name LIKE '%$s%' OR c.last_name LIKE '%$s%')";
    }

    $tr = $conn->query("SELECT COUNT(*) AS cnt FROM campaign_contacts c
                         INNER JOIN campaign_list_members m ON m.contact_id = c.id
                         WHERE m.list_id=$id $whereExtra");
    $total = $tr ? (int)$tr->fetch_assoc()['cnt'] : 0;

    // LEFT JOIN users on email — many contacts (e.g. anyone added via an unsubscribe event,
    // or a CSV that only had an EMAIL column) are actually already-registered students. Rather
    // than duplicating their name/phone into campaign_contacts and letting it go stale, we
    // just fall back to the live users row (same fname/lname/phone/state/country fields the
    // "register" event already exposes) whenever campaign_contacts itself doesn't have them.
    //
    // COLLATE goes on c.email (the small table) only, NOT u.email — wrapping the users side
    // in COLLATE defeats its index and forces a full table scan on every request (this is
    // what made the page take ~9s). Converting the small side to match users.email's native
    // collation instead lets MySQL still use the index on users.email normally.
    $r = $conn->query("SELECT c.id, c.email,
                               COALESCE(c.first_name, u.fname) AS first_name,
                               COALESCE(c.last_name, u.lname) AS last_name,
                               COALESCE(c.phone, u.phone) AS phone,
                               COALESCE(c.state, u.state) AS state,
                               COALESCE(c.country, u.country) AS country,
                               c.city, m.added_at, m.reason
                        FROM campaign_contacts c
                        INNER JOIN campaign_list_members m ON m.contact_id = c.id
                        LEFT JOIN users u ON u.email = c.email COLLATE utf8mb4_general_ci
                        WHERE m.list_id=$id $whereExtra
                        ORDER BY m.added_at DESC LIMIT $perPage OFFSET $offset");
    $rows = [];
    while ($r && $row = $r->fetch_assoc()) $rows[] = $row;

    api_success([
        'members' => $rows, 'total' => $total, 'page' => $page, 'per_page' => $perPage,
        'pages' => $total > 0 ? (int)ceil($total / $perPage) : 1,
    ]);
}

if ($action === 'remove_member') {
    $listId    = (int)jin('list_id', 0);
    $contactId = (int)jin('contact_id', 0);
    if (!$listId || !$contactId) api_error('list_id and contact_id required');

    // Removing from the Blocklist specifically means "this person is allowed to receive
    // email again" — so it isn't enough to just delete our own local membership row, the
    // ESPs' own suppression lists (SendGrid's global unsubscribe/bounces/blocks/spam
    // reports, Elastic Email's unsubscribes/bounces/complaints) would otherwise keep
    // refusing to deliver to them regardless of what our side thinks. Fetch the email
    // BEFORE deleting the membership row, since we need it either way. Ordinary Lists
    // never touch the ESPs on removal — only the Blocklist.
    if ($listId === lists_get_or_create_blocklist_id()) {
        $eR = $conn->query("SELECT email FROM campaign_contacts WHERE id=$contactId LIMIT 1");
        $eRow = $eR ? $eR->fetch_assoc() : null;
        if ($eRow) esp_remove_all_suppressions($eRow['email']);
    }

    $conn->query("DELETE FROM campaign_list_members WHERE list_id=$listId AND contact_id=$contactId");
    $conn->query("UPDATE campaign_lists SET contact_count = (
                      SELECT COUNT(*) FROM campaign_list_members WHERE list_id=$listId
                  ) WHERE id=$listId");
    api_success([]);
}

if ($action === 'add_contact') {
    $listId = (int)jin('list_id', 0);
    $email  = trim((string)jin('email', ''));
    if (!$listId) api_error('list_id required');
    if (!$email || !filter_var($email, FILTER_VALIDATE_EMAIL)) api_error('A valid email is required');

    $contactId = contact_upsert([
        'email' => $email,
        'first_name' => jin('first_name', null),
        'last_name'  => jin('last_name', null),
        'phone'      => jin('phone', null),
        'state'      => jin('state', null),
        'country'    => jin('country', null),
        'city'       => jin('city', null),
    ], $listId, jin('reason', null));

    $conn->query("UPDATE campaign_lists SET contact_count = (
                      SELECT COUNT(*) FROM campaign_list_members WHERE list_id=$listId
                  ) WHERE id=$listId");
    api_success(['contact_id' => $contactId]);
}

if ($action === 'update_contact') {
    $contactId = (int)jin('contact_id', 0);
    if (!$contactId) api_error('contact_id required');
    $r = $conn->query("SELECT id, email FROM campaign_contacts WHERE id=$contactId LIMIT 1");
    $row = $r ? $r->fetch_assoc() : null;
    if (!$row) api_error('Not found', 404);

    $set = [];

    // Email is always editable here and always only touches OUR campaign_contacts copy —
    // deliberately never the real `users.email` (that's the account's actual login
    // identity; changing it from a marketing contact-list editor is out of scope and too
    // risky to do implicitly). The real-table sync below always matches against the
    // ORIGINAL email, not whatever it's being changed to in this same request.
    $newEmail = trim((string)jin('email', ''));
    if ($newEmail !== '' && $newEmail !== $row['email']) {
        if (!filter_var($newEmail, FILTER_VALIDATE_EMAIL)) api_error('Enter a valid email address');
        $dup = $conn->query("SELECT id FROM campaign_contacts WHERE email='" . $conn->real_escape_string($newEmail) . "' AND id<>$contactId LIMIT 1");
        if ($dup && $dup->num_rows > 0) api_error('That email is already used by another contact');
        $set[] = "email='" . $conn->real_escape_string($newEmail) . "'";
    }

    $fields = ['first_name', 'last_name', 'phone', 'state', 'country', 'city'];
    $provided = [];
    foreach ($fields as $f) {
        $v = jin($f, null);
        if ($v !== null) { $set[] = "$f='" . $conn->real_escape_string($v) . "'"; $provided[$f] = $v; }
    }
    if ($set) $conn->query("UPDATE campaign_contacts SET " . implode(', ', $set) . " WHERE id=$contactId");

    // "Edit real database value also" — an explicit, opt-in write into the real `users`
    // table too (matched by email), not just our own marketing-only campaign_contacts
    // copy. Off by default: a plain edit here only ever touches campaign_contacts, never
    // a real student record, unless this flag is deliberately turned on for this save.
    $updateRealTable = jin('update_real_table', '0') === '1';
    if ($updateRealTable && $provided) {
        // Maps our canonical contact fields to `users`'s own column names — only fields
        // that actually exist there (users has no `city` column) are ever written.
        $realFieldMap = ['first_name' => 'fname', 'last_name' => 'lname', 'phone' => 'phone', 'state' => 'state', 'country' => 'country'];
        $realSet = [];
        foreach ($realFieldMap as $ourField => $realCol) {
            if (array_key_exists($ourField, $provided)) {
                $realSet[] = "`$realCol`='" . $conn->real_escape_string($provided[$ourField]) . "'";
            }
        }
        if ($realSet) {
            $emailE = $conn->real_escape_string($row['email']);
            $conn->query("UPDATE users SET " . implode(', ', $realSet) . " WHERE email='$emailE'");
        }
    }
    api_success([]);
}

if ($action === 'download') {
    $id = (int)jin('id', 0);
    $r = $conn->query("SELECT name FROM campaign_lists WHERE id=$id LIMIT 1");
    $row = $r ? $r->fetch_assoc() : null;
    if (!$row) api_error('Not found', 404);

    $filename = preg_replace('/[^a-zA-Z0-9_]+/', '_', $row['name']) . '.csv';
    header('Content-Type: text/csv; charset=utf-8');
    header("Content-Disposition: attachment; filename=\"$filename\"");
    $out = fopen('php://output', 'w');
    fputcsv($out, ['email', 'first_name', 'last_name', 'phone', 'state', 'country', 'city']);
    $q = $conn->query("SELECT c.email,
                               COALESCE(c.first_name, u.fname) AS first_name,
                               COALESCE(c.last_name, u.lname) AS last_name,
                               COALESCE(c.phone, u.phone) AS phone,
                               COALESCE(c.state, u.state) AS state,
                               COALESCE(c.country, u.country) AS country,
                               c.city
                        FROM campaign_contacts c
                        INNER JOIN campaign_list_members m ON m.contact_id = c.id
                        LEFT JOIN users u ON u.email = c.email COLLATE utf8mb4_general_ci
                        WHERE m.list_id=$id
                        ORDER BY c.id");
    while ($q && $row = $q->fetch_assoc()) fputcsv($out, $row);
    fclose($out);
    exit;
}

api_error('Invalid action');

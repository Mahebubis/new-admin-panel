<?php
/*
 * /api/netcore/segments.php
 *
 * Body actions (form-urlencoded or JSON):
 *   action=list            → list segments (id, name, counts, refreshed)
 *   action=get      &id    → fetch one segment + its config JSON
 *   action=save     [&id]  &name &contact_type &config(json) → create/update
 *   action=delete   &id
 *   action=duplicate&id
 *   action=refresh  &id    → recompute user_count
 *   action=count           &config(json) → preview count without saving
 *   action=download &id    → CSV of resulting users (email, fname, lname, phone, registered_at)
 */
header('Cache-Control: no-cache, no-store, must-revalidate');
ini_set('display_errors', 0);
ob_start();

chdir('/home/istudio/public_html/cit/common');
include '/home/istudio/public_html/cit/common/helper.php';
ob_clean();

global $conn;
if (!$conn) { header('Content-Type: application/json'); echo json_encode(['status'=>'error','message'=>'DB connection missing']); exit; }

/* helpers */
function jin($k, $d = null) { $v = $_REQUEST[$k] ?? null; return $v === null ? $d : $v; }
function ok($a)   { header('Content-Type: application/json'); echo json_encode(['status'=>'success'] + $a); exit; }
function fail($m, $code = 400) { http_response_code($code); header('Content-Type: application/json'); echo json_encode(['status'=>'error','message'=>$m]); exit; }

/* Segment-resolution SQL builder (event map, condition/block combinators, buildSegmentSql,
   countSegment, channelCounts) lives in lib/segment_sql.php — shared with the campaigns
   feature's AudienceResolver so segment-membership logic exists in exactly one place. */
require_once __DIR__ . '/lib/segment_sql.php';

/* idempotent: add columns to netcore_segments if not present */
function ensureSchema() {
    global $conn;
    $r = mysqli_query($conn, "SHOW COLUMNS FROM netcore_segments LIKE 'email_count'");
    if (!$r || mysqli_num_rows($r) === 0) {
        mysqli_query($conn, "ALTER TABLE netcore_segments
                             ADD COLUMN email_count INT NOT NULL DEFAULT 0,
                             ADD COLUMN phone_count INT NOT NULL DEFAULT 0");
    }
}
ensureSchema();

/* ════════════════════════════════════════
   ROUTING
═══════════════════════════════════════ */
$action = jin('action', '');

if ($action === 'list') {
    $page    = max(1, (int)jin('page', 1));
    $perPage = max(1, min(100, (int)jin('per_page', 10)));
    $search  = trim((string)jin('search', ''));
    $sort    = jin('sort', '');     /* '' | 'created_at' | 'refreshed' */
    $order   = strtolower(jin('order', 'desc')) === 'asc' ? 'ASC' : 'DESC';
    $offset  = ($page - 1) * $perPage;

    $where = '';
    if ($search !== '') {
        $s = esc($search);
        $where = "WHERE name LIKE '%$s%'";
    }

    $orderBy = "ORDER BY id DESC";
    if ($sort === 'created_at') $orderBy = "ORDER BY created_at $order";
    if ($sort === 'refreshed')  $orderBy = "ORDER BY user_count_refreshed_at $order";

    $tr = mysqli_query($conn, "SELECT COUNT(*) AS c FROM netcore_segments $where");
    $total = $tr ? (int)mysqli_fetch_assoc($tr)['c'] : 0;

    $r = mysqli_query($conn, "SELECT id, name, contact_type, user_count, email_count, phone_count,
                                     user_count_refreshed_at, created_at, updated_at
                              FROM netcore_segments
                              $where
                              $orderBy LIMIT $perPage OFFSET $offset");
    $rows = [];
    while ($r && $row = mysqli_fetch_assoc($r)) $rows[] = $row;
    ok([
        'segments' => $rows,
        'total'    => $total,
        'page'     => $page,
        'per_page' => $perPage,
        'pages'    => $total > 0 ? (int)ceil($total / $perPage) : 1,
    ]);
}

if ($action === 'get') {
    $id = (int)jin('id', 0);
    $r = mysqli_query($conn, "SELECT * FROM netcore_segments WHERE id=$id LIMIT 1");
    $row = $r ? mysqli_fetch_assoc($r) : null;
    if (!$row) fail('Not found', 404);
    $row['config'] = json_decode($row['config'], true);
    ok(['segment' => $row]);
}

if ($action === 'count') {
    $config = json_decode(jin('config', ''), true);
    if (!is_array($config)) fail('Invalid config');
    $count = countSegment($config);
    ok(['count' => $count]);
}

if ($action === 'save') {
    $id          = (int)jin('id', 0);
    $name        = trim((string)jin('name', ''));
    $contactType = trim((string)jin('contact_type', 'all_identified'));
    $config      = jin('config', '');
    if ($name === '')       fail('Name required');
    $cfgArr = json_decode($config, true);
    if (!$cfgArr) fail('Invalid config JSON');

    $ch = channelCounts($cfgArr);
    $nameE = esc($name); $ctE = esc($contactType); $cfgE = esc($config);
    $now   = date('Y-m-d H:i:s');

    if ($id > 0) {
        mysqli_query($conn, "UPDATE netcore_segments
                             SET name='$nameE', contact_type='$ctE', config='$cfgE',
                                 user_count={$ch['total']}, email_count={$ch['email']}, phone_count={$ch['phone']},
                                 user_count_refreshed_at='$now'
                             WHERE id=$id");
    } else {
        mysqli_query($conn, "INSERT INTO netcore_segments (name, contact_type, config, user_count, email_count, phone_count, user_count_refreshed_at)
                             VALUES ('$nameE', '$ctE', '$cfgE', {$ch['total']}, {$ch['email']}, {$ch['phone']}, '$now')");
        $id = mysqli_insert_id($conn);
    }
    ok(['id' => $id, 'count' => $ch['total'], 'email_count' => $ch['email'], 'phone_count' => $ch['phone'], 'refreshed_at' => $now]);
}

if ($action === 'delete') {
    $id = (int)jin('id', 0);
    if (!$id) fail('id required');
    mysqli_query($conn, "DELETE FROM netcore_segments WHERE id=$id");
    ok([]);
}

if ($action === 'duplicate') {
    $id = (int)jin('id', 0);
    $r = mysqli_query($conn, "SELECT name, contact_type, config FROM netcore_segments WHERE id=$id LIMIT 1");
    $row = $r ? mysqli_fetch_assoc($r) : null;
    if (!$row) fail('Not found', 404);
    $name = esc($row['name'] . ' (Copy)');
    $ct   = esc($row['contact_type']);
    $cfg  = esc($row['config']);
    mysqli_query($conn, "INSERT INTO netcore_segments (name, contact_type, config) VALUES ('$name','$ct','$cfg')");
    ok(['id' => mysqli_insert_id($conn)]);
}

if ($action === 'refresh') {
    $id = (int)jin('id', 0);
    $r = mysqli_query($conn, "SELECT config FROM netcore_segments WHERE id=$id LIMIT 1");
    $row = $r ? mysqli_fetch_assoc($r) : null;
    if (!$row) fail('Not found', 404);
    $ch = channelCounts(json_decode($row['config'], true));
    $now = date('Y-m-d H:i:s');
    mysqli_query($conn, "UPDATE netcore_segments
                         SET user_count={$ch['total']}, email_count={$ch['email']}, phone_count={$ch['phone']},
                             user_count_refreshed_at='$now'
                         WHERE id=$id");
    ok(['count' => $ch['total'], 'email_count' => $ch['email'], 'phone_count' => $ch['phone'], 'refreshed_at' => $now]);
}

if ($action === 'users') {
    /* paginated users for a segment, optionally filtered to a channel (email/sms/whatsapp) */
    $id      = (int)jin('id', 0);
    $page    = max(1, (int)jin('page', 1));
    $perPage = max(1, min(200, (int)jin('per_page', 25)));
    $channel = jin('channel', '');   /* '', 'email', 'sms', 'whatsapp' */
    $search  = trim((string)jin('search', ''));
    $offset  = ($page - 1) * $perPage;

    $r = mysqli_query($conn, "SELECT name, config FROM netcore_segments WHERE id=$id LIMIT 1");
    $seg = $r ? mysqli_fetch_assoc($r) : null;
    if (!$seg) fail('Not found', 404);
    $sql = buildSegmentSql(json_decode($seg['config'], true));
    if (!$sql) ok(['total' => 0, 'page' => 1, 'pages' => 1, 'users' => [], 'name' => $seg['name']]);

    $whereExtra = '';
    if ($channel === 'email') {
        $whereExtra = "AND u.email IS NOT NULL AND u.email <> ''";
    } elseif ($channel === 'sms' || $channel === 'whatsapp') {
        $whereExtra = "AND u.phone IS NOT NULL AND u.phone <> ''";
    }
    if ($search !== '') {
        $s = esc($search);
        if (strpos($search, '@') !== false)        $whereExtra .= " AND u.email = '$s'";
        elseif (preg_match('/^\d+$/', $search))    $whereExtra .= strlen($search) >= 10 ? " AND u.phone = '$s'" : " AND u.user_id = '$s'";
        else                                       $whereExtra .= " AND (u.fname LIKE '$s%' OR u.lname LIKE '$s%')";
    }

    $base = "FROM ($sql) AS s INNER JOIN users u ON u.user_id = s.user_id WHERE 1=1 $whereExtra";

    $tr = mysqli_query($conn, "SELECT COUNT(*) AS c $base");
    $total = $tr ? (int)mysqli_fetch_assoc($tr)['c'] : 0;

    $listSql = "SELECT u.user_id, u.email, u.phone AS mobile, u.fname AS first_name, u.lname AS last_name,
                       u.state, u.country, u.registered_at AS register_date
                $base
                ORDER BY u.registered_at DESC
                LIMIT $perPage OFFSET $offset";
    $lr = mysqli_query($conn, $listSql);
    $users = [];
    while ($lr && $row = mysqli_fetch_assoc($lr)) {
        if (!empty($row['register_date'])) $row['register_date'] = substr($row['register_date'], 0, 10);
        $users[] = $row;
    }

    ok([
        'name'  => $seg['name'],
        'total' => $total,
        'page'  => $page,
        'per_page' => $perPage,
        'pages' => $total > 0 ? (int)ceil($total / $perPage) : 1,
        'users' => $users,
    ]);
}

if ($action === 'users_csv') {
    /* full CSV export of a segment's users (optionally per channel) */
    $id      = (int)jin('id', 0);
    $channel = jin('channel', '');
    $r = mysqli_query($conn, "SELECT name, config FROM netcore_segments WHERE id=$id LIMIT 1");
    $seg = $r ? mysqli_fetch_assoc($r) : null;
    if (!$seg) fail('Not found', 404);
    $sql = buildSegmentSql(json_decode($seg['config'], true));
    if (!$sql) fail('Empty segment');
    $whereExtra = '';
    if ($channel === 'email')                       $whereExtra = "AND u.email IS NOT NULL AND u.email <> ''";
    elseif ($channel === 'sms' || $channel === 'whatsapp') $whereExtra = "AND u.phone IS NOT NULL AND u.phone <> ''";

    $filename = preg_replace('/[^a-zA-Z0-9_]+/', '_', $seg['name']) . ($channel ? "_$channel" : '') . '.csv';
    header('Content-Type: text/csv; charset=utf-8');
    header("Content-Disposition: attachment; filename=\"$filename\"");
    $out = fopen('php://output', 'w');
    fputcsv($out, ['user_id','email','mobile','first_name','last_name','state','country','register_date']);
    $q = "SELECT u.user_id, u.email, u.phone, u.fname, u.lname, u.state, u.country, u.registered_at
          FROM ($sql) AS s INNER JOIN users u ON u.user_id = s.user_id WHERE 1=1 $whereExtra";
    $res = mysqli_query($conn, $q);
    while ($res && $row = mysqli_fetch_assoc($res)) fputcsv($out, $row);
    fclose($out);
    exit;
}

if ($action === 'download') {
    $id = (int)jin('id', 0);
    $r = mysqli_query($conn, "SELECT name, config FROM netcore_segments WHERE id=$id LIMIT 1");
    $row = $r ? mysqli_fetch_assoc($r) : null;
    if (!$row) fail('Not found', 404);
    $sql = buildSegmentSql(json_decode($row['config'], true));
    if (!$sql) fail('Empty segment');

    /* stream as CSV */
    $filename = preg_replace('/[^a-zA-Z0-9_]+/', '_', $row['name']) . '.csv';
    header('Content-Type: text/csv; charset=utf-8');
    header("Content-Disposition: attachment; filename=\"$filename\"");
    $out = fopen('php://output', 'w');
    fputcsv($out, ['user_id', 'email', 'fname', 'lname', 'phone', 'registered_at']);

    $q = "SELECT u.user_id, u.email, u.fname, u.lname, u.phone, u.registered_at
          FROM users u INNER JOIN ($sql) AS s ON s.user_id = u.user_id";
    $res = mysqli_query($conn, $q);
    if ($res) while ($r = mysqli_fetch_assoc($res)) fputcsv($out, $r);
    fclose($out);
    exit;
}

fail('Invalid action');
?>

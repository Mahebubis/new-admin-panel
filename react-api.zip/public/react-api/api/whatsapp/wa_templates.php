<?php
/*
 * /api/whatsapp/wa_templates.php — WhatsApp message templates.
 *
 * A row here is OUR record of a template that exists (or is being submitted) on the WhatsApp
 * Business Account. WhatsApp itself will only deliver a template Meta has approved, so `name`
 * + `language` must match the approved template exactly; everything else on the row (body
 * copy, buttons, variable labels, samples) is what lets the campaign wizard render a true
 * preview and offer variable mapping without calling the provider on every keystroke.
 *
 * action=list     &page &per_page &search &status(active|archived) &category
 * action=get       &id
 * action=save     [&id] &name &display_name &category &language &header_* &body_text
 *                  &footer_text &buttons(json) &variable_labels(json) &sample_values(json) &approval_status
 * action=archive | restore | delete   &id
 * action=sync                                → pull the approved-template list from the provider
 */
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../middleware/auth.php';
require_once __DIR__ . '/lib/config.php';
require_once __DIR__ . '/lib/schema.php';
require_once __DIR__ . '/lib/WaHelpers.php';
require_once __DIR__ . '/lib/WaLinks.php';

whatsapp_ensure_schema();

$jwt = require_jwt();
require_permission('netcore_behaviour', $jwt);

function jin($k, $d = null) { $v = $_REQUEST[$k] ?? null; return ($v === null || $v === '') ? $d : $v; }

/** Decodes a JSON parameter into an array, tolerating an empty/garbage value. */
function jarr($k): array {
    $v = $_REQUEST[$k] ?? null;
    if ($v === null || $v === '') return [];
    $d = json_decode((string)$v, true);
    return is_array($d) ? $d : [];
}

$action = jin('action', '');

if ($action === 'list') {
    $page     = max(1, (int)jin('page', 1));
    $perPage  = max(1, min(200, (int)jin('per_page', 24)));
    $search   = trim((string)jin('search', ''));
    $status   = jin('status', 'active');
    $category = jin('category', '');
    $offset   = ($page - 1) * $perPage;

    $where = ["status='" . $conn->real_escape_string($status) . "'"];
    if ($search !== '') {
        $s = $conn->real_escape_string($search);
        $where[] = "(name LIKE '%$s%' OR display_name LIKE '%$s%' OR body_text LIKE '%$s%')";
    }
    if ($category !== '') $where[] = "category='" . $conn->real_escape_string($category) . "'";
    // With 130+ templates on an account, "show me only the ones I can actually send" is the
    // filter that matters most — an unapproved template is accepted by the API and then dropped.
    $approval = jin('approval', '');
    if ($approval !== '') $where[] = "approval_status='" . $conn->real_escape_string($approval) . "'";
    $whereSql = 'WHERE ' . implode(' AND ', $where);

    $tr = $conn->query("SELECT COUNT(*) AS c FROM wa_templates $whereSql");
    $total = $tr ? (int)$tr->fetch_assoc()['c'] : 0;

    $r = $conn->query("SELECT * FROM wa_templates $whereSql ORDER BY id DESC LIMIT $perPage OFFSET $offset");
    $rows = [];
    while ($r && $row = $r->fetch_assoc()) {
        $row['buttons']         = json_decode($row['buttons'] ?? '[]', true) ?: [];
        $row['variable_labels'] = json_decode($row['variable_labels'] ?? '{}', true) ?: [];
        $row['sample_values']   = json_decode($row['sample_values'] ?? '{}', true) ?: [];
        // Placeholder counts are derived, never stored — a body edit can't leave them stale.
        $row['body_variable_count']   = wa_placeholder_count((string)$row['body_text']);
        $row['header_variable_count'] = $row['header_type'] === 'text' ? wa_placeholder_count((string)$row['header_text']) : 0;
        $rows[] = $row;
    }

    $counts = [];
    $cr = $conn->query("SELECT status, COUNT(*) AS c FROM wa_templates GROUP BY status");
    while ($cr && $row = $cr->fetch_assoc()) $counts[$row['status']] = (int)$row['c'];

    // Approval tallies for the filter chips — scoped to the active/archived tab in view, and to
    // the category filter, so the numbers always match what the chips would actually show.
    $aWhere = ["status='" . $conn->real_escape_string($status) . "'"];
    if ($category !== '') $aWhere[] = "category='" . $conn->real_escape_string($category) . "'";
    $approvalCounts = ['approved' => 0, 'pending' => 0, 'rejected' => 0, 'unknown' => 0, 'all' => 0];
    $ar = $conn->query("SELECT approval_status, COUNT(*) AS c FROM wa_templates WHERE "
        . implode(' AND ', $aWhere) . ' GROUP BY approval_status');
    while ($ar && $row = $ar->fetch_assoc()) {
        $approvalCounts[$row['approval_status']] = (int)$row['c'];
        $approvalCounts['all'] += (int)$row['c'];
    }

    api_success(['templates' => $rows, 'total' => $total, 'page' => $page, 'per_page' => $perPage,
                 'pages' => $total > 0 ? (int)ceil($total / $perPage) : 1, 'counts' => $counts,
                 'approval_counts' => $approvalCounts]);
}

if ($action === 'get') {
    $id = (int)jin('id', 0);
    $r = $conn->query("SELECT * FROM wa_templates WHERE id=$id LIMIT 1");
    $row = $r ? $r->fetch_assoc() : null;
    if (!$row) api_error('Not found', 404);
    $row['buttons']         = json_decode($row['buttons'] ?? '[]', true) ?: [];
    $row['variable_labels'] = json_decode($row['variable_labels'] ?? '{}', true) ?: [];
    $row['sample_values']   = json_decode($row['sample_values'] ?? '{}', true) ?: [];
    $row['body_variable_count']   = wa_placeholder_count((string)$row['body_text']);
    $row['header_variable_count'] = $row['header_type'] === 'text' ? wa_placeholder_count((string)$row['header_text']) : 0;
    api_success(['template' => $row]);
}

if ($action === 'save') {
    $id   = (int)jin('id', 0);
    $name = trim((string)jin('name', ''));
    $body = (string)jin('body_text', '');

    if ($name === '') api_error('Template name is required');
    // Meta's own rule for template names — enforced here rather than discovered at submission,
    // since a name with spaces or capitals can never be approved.
    if (!preg_match('/^[a-z0-9_]+$/', $name)) {
        api_error('Template name may only contain lowercase letters, numbers and underscores (e.g. exam_reminder_1)');
    }
    if (trim($body) === '') api_error('Message body is required');
    if (mb_strlen($body) > 1024) api_error('Message body is limited to 1024 characters by WhatsApp');

    $footer = (string)jin('footer_text', '');
    if (mb_strlen($footer) > 60) api_error('Footer is limited to 60 characters by WhatsApp');

    $language   = trim((string)jin('language', 'en')) ?: 'en';
    $category   = jin('category', 'utility');
    if (!in_array($category, ['marketing', 'utility', 'authentication'], true)) $category = 'utility';
    $headerType = jin('header_type', 'none');
    if (!in_array($headerType, ['none', 'text', 'image', 'video', 'document'], true)) $headerType = 'none';
    $approval   = jin('approval_status', 'pending');
    if (!in_array($approval, ['approved', 'pending', 'rejected', 'unknown'], true)) $approval = 'pending';

    // Placeholders must be a complete 1..N run — WhatsApp rejects a body that uses {{1}} and
    // {{3}} but never {{2}}, and catching it here beats a rejection days later.
    foreach ([['body', $body], ['header', $headerType === 'text' ? (string)jin('header_text', '') : '']] as [$part, $text]) {
        if ($text === '') continue;
        preg_match_all('/\{\{\s*(\d+)\s*\}\}/', $text, $m);
        $used = array_values(array_unique(array_map('intval', $m[1] ?? [])));
        sort($used);
        $expected = range(1, count($used));
        if ($used && $used !== $expected) {
            api_error(ucfirst($part) . ' placeholders must be numbered consecutively from {{1}} — found {{' . implode('}}, {{', $used) . '}}');
        }
    }

    $buttons = jarr('buttons');
    // Normalized so the send path can trust the shape without re-validating per recipient.
    $buttons = array_values(array_map(function ($b) {
        $type = in_array(($b['type'] ?? ''), ['url', 'phone', 'quick_reply'], true) ? $b['type'] : 'quick_reply';
        return [
            'type'    => $type,
            'text'    => mb_substr(trim((string)($b['text'] ?? '')), 0, 25),
            'url'     => $type === 'url' ? trim((string)($b['url'] ?? '')) : '',
            'phone'   => $type === 'phone' ? trim((string)($b['phone'] ?? '')) : '',
            // A dynamic url button takes a per-recipient suffix appended to the base url.
            'dynamic' => $type === 'url' && !empty($b['dynamic']),
        ];
    }, $buttons));
    if (count($buttons) > 3) api_error('WhatsApp allows at most 3 buttons on a template');

    $cols = [
        'name'             => $name,
        'display_name'     => (string)jin('display_name', $name),
        'category'         => $category,
        'language'         => $language,
        'header_type'      => $headerType,
        'header_text'      => $headerType === 'text' ? (string)jin('header_text', '') : '',
        'header_media_url' => in_array($headerType, ['image', 'video', 'document'], true) ? (string)jin('header_media_url', '') : '',
        'body_text'        => $body,
        'footer_text'      => $footer,
        'buttons'          => json_encode($buttons),
        // Where a tracked button actually sends people. Set once here rather than per campaign:
        // the button URL is part of what Meta approved, so its real destination belongs to the
        // template and is the same for every campaign that uses it.
        'click_target_url' => trim((string)jin('click_target_url', '')),
        'variable_labels'  => json_encode(jarr('variable_labels')),
        'sample_values'    => json_encode(jarr('sample_values')),
        'approval_status'  => $approval,
    ];
    $set = [];
    foreach ($cols as $c => $v) $set[] = "`$c`='" . $conn->real_escape_string((string)$v) . "'";

    if ($id > 0) {
        $conn->query("UPDATE wa_templates SET " . implode(', ', $set) . " WHERE id=$id");
    } else {
        // uq_name_lang: the same approved template can't be registered twice for one language.
        $dup = $conn->query("SELECT id FROM wa_templates WHERE name='" . $conn->real_escape_string($name) . "'
                              AND language='" . $conn->real_escape_string($language) . "' LIMIT 1");
        if ($dup && $dup->num_rows > 0) api_error("A template named \"$name\" already exists for language \"$language\"");
        $set[] = 'created_by=' . (int)($jwt['user_id'] ?? 0);
        $conn->query("INSERT INTO wa_templates SET " . implode(', ', $set));
        $id = $conn->insert_id;
    }

    /*
     * Bake the tracked link in, AFTER the row exists — a brand-new template has no id until the
     * INSERT above returns one, and the link id is derived from it.
     *
     * The editor sends the destination plain, the way a non-technical person would type it:
     *
     *     https://dashboard.internshipstudio.com/login
     *
     * and what is stored — and therefore what Meta is asked to approve — is
     *
     *     https://dashboard.internshipstudio.com/login/23
     *
     * Rewritten in the body, the header and every URL button, so it does not matter which of
     * those the link was typed into. wa_link_rewrite() is idempotent, so saving repeatedly does
     * not stack ids, and it also recognises the "?{{1}}" and "?XX_WA_ATTR_XX" endings the earlier
     * variable-based scheme produced — which means an old template migrates by being re-saved.
     */
    $target = trim((string)$cols['click_target_url']);
    $linkId = 0;
    $tracked = '';
    if ($target !== '') {
        $linkId = wa_link_ensure($id, $target);
        if ($linkId > 0) {
            $tracked = wa_tracked_link($target, $linkId);

            $newBody   = wa_link_rewrite($body, $target, $linkId);
            $newHeader = wa_link_rewrite((string)$cols['header_text'], $target, $linkId);
            $newButtons = array_map(function ($b) use ($target, $linkId) {
                if (($b['type'] ?? '') === 'url') {
                    /*
                     * A URL button left blank means "send them to the destination above".
                     *
                     * That is by far the commonest template shape — a plain message and one
                     * button — and asking for the same URL twice on one screen is asking for one
                     * of the two to be mistyped. Only the blank case is filled; a button pointing
                     * somewhere else is left exactly as written.
                     */
                    if (trim((string)($b['url'] ?? '')) === '') $b['url'] = $target;

                    $b['url'] = wa_link_rewrite((string)$b['url'], $target, $linkId);
                    // The id carries the campaign now, so the button no longer needs a
                    // per-recipient variable — and it is precisely that variable Meta kept
                    // refusing. Clearing the flag stops the send path appending a {{1}} value to
                    // a URL that has no {{1}} left in it.
                    $b['dynamic'] = false;
                }
                return $b;
            }, $buttons);

            $conn->query("UPDATE wa_templates
                             SET body_text   = '" . $conn->real_escape_string($newBody) . "',
                                 header_text = '" . $conn->real_escape_string($newHeader) . "',
                                 buttons     = '" . $conn->real_escape_string(json_encode(array_values($newButtons))) . "'
                           WHERE id = $id");
        }
    }

    api_success(['id' => $id, 'link_id' => $linkId, 'tracked_url' => $tracked]);
}

if ($action === 'archive' || $action === 'restore') {
    $id = (int)jin('id', 0);
    $status = $action === 'archive' ? 'archived' : 'active';
    $conn->query("UPDATE wa_templates SET status='$status' WHERE id=$id");
    api_success([]);
}

if ($action === 'delete') {
    $id = (int)jin('id', 0);
    if (!$id) api_error('id required');

    $r = $conn->query("SELECT name, language, meta_template_id FROM wa_templates WHERE id=$id LIMIT 1");
    $tpl = $r ? $r->fetch_assoc() : null;

    /*
     * Delete on META first, then locally.
     *
     * A template that exists on the WABA but not here is invisible and un-fixable from this
     * panel: its name is taken, so re-creating it fails, and there is no row left to press
     * anything on. Deleting locally first would strand exactly that, which is the state a
     * mis-submitted template (wrong button URL, say) leaves you in.
     *
     * Meta deletes BY NAME and removes every language variant, which is why the name is used
     * rather than the template id.
     */
    $metaResult = null;
    if ($tpl && trim((string)$tpl['meta_template_id']) !== '' && (int)jin('delete_on_meta', 1) === 1) {
        // Same resolution as submit_to_meta and sync: the WABA comes from the sending number,
        // which is the only place it is stored.
        $token  = trim((string)((wa_settings_row() ?: [])['meta_access_token'] ?? ''));
        $sender = wa_sender_by_id((int)jin('sender_id', 0)) ?: wa_default_sender();
        $wabaId = trim((string)($sender['waba_id'] ?? ''));
        if ($token !== '' && $wabaId !== '') {
            $res = wa_graph_call('DELETE', WA_GRAPH_BASE . WA_GRAPH_VERSION . '/' . rawurlencode($wabaId)
                . '/message_templates?name=' . rawurlencode((string)$tpl['name']), $token);
            $metaResult = $res['ok'] ? 'deleted on Meta' : ('Meta said: ' . $res['error']);
            /*
             * A Meta failure does NOT stop the local delete. The usual causes are "already gone"
             * and "still in use", and in both cases leaving an unusable row here helps nobody —
             * the outcome is reported instead so it isn't silently swallowed.
             */
        }
    }

    // Campaigns snapshot a template's content at save time (see wa_campaigns.php's save), so
    // deleting one never changes what an already-scheduled campaign will send.
    $conn->query("DELETE FROM wa_templates WHERE id=$id");
    api_success(['meta' => $metaResult], $metaResult ?: 'Deleted');
}

/*
 * Pulls the template list straight from Meta.
 *
 * Netcore's messaging API has NO template endpoint — its entire documented surface is consent,
 * send-message, template-MESSAGE (sending one), media, webhooks and reports, and every
 * /api/v2/template* path answers 404. Templates aren't Netcore's data anyway: they live on the
 * WhatsApp Business Account and Meta is what approves them, so the authoritative list is
 *
 *     GET https://graph.facebook.com/{version}/{waba_id}/message_templates
 *
 * which returns name, language, category, status and the full components array — exactly what
 * wa_upsert_templates() already knows how to read. Netcore's own "Integrate with third-party
 * BSPs" guide documents the same Meta System User token for this, with the
 * whatsapp_business_management scope.
 */
if ($action === 'sync') {
    $settings = wa_settings_row() ?: [];
    $token = trim((string)($settings['meta_access_token'] ?? ''));
    if ($token === '') {
        api_error('Add a Meta access token in Settings → Template sync. Netcore has no template API, so the list is read directly from your WhatsApp Business Account.');
    }

    // The WABA whose templates to read — from the chosen sender, since that's where waba_id is
    // recorded. Every number under one business normally shares it.
    $sender = wa_sender_by_id((int)jin('sender_id', 0)) ?: wa_default_sender();
    $wabaId = trim((string)($sender['waba_id'] ?? ''));
    if ($wabaId === '') api_error('No WABA ID on the sending number — add it in Settings → Sending numbers.');

    $version = trim((string)jin('graph_version', '')) ?: WA_GRAPH_VERSION;
    $url = WA_GRAPH_BASE . rawurlencode($version) . '/' . rawurlencode($wabaId) . '/message_templates'
         . '?limit=200&fields=' . rawurlencode('name,status,category,language,components');

    $found = [];
    $pages = 0;
    $lastError = null;

    // Meta paginates with a cursor; `paging.next` is a fully-formed URL (token included). The
    // page cap is a guard against a malformed next-link looping forever — 20 × 200 is far more
    // than the 250-templates-per-WABA ceiling Meta enforces.
    while ($url !== null && $pages < 20) {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HTTPHEADER     => ['Authorization: Bearer ' . $token],
            CURLOPT_TIMEOUT        => 25,
        ]);
        $body   = curl_exec($ch);
        $status = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $err    = curl_error($ch);
        curl_close($ch);
        $pages++;

        if ($err !== '') api_error('Could not reach Meta: ' . $err);
        $decoded = json_decode((string)$body, true);

        if ($status < 200 || $status >= 300 || !is_array($decoded)) {
            // Meta's errors are genuinely descriptive (expired token, missing scope, wrong WABA),
            // so they're surfaced verbatim instead of being flattened into "sync failed".
            $msg = $decoded['error']['message'] ?? (is_string($body) ? mb_substr($body, 0, 300) : "HTTP $status");
            $type = $decoded['error']['type'] ?? '';
            $code = $decoded['error']['code'] ?? $status;
            $lastError = "Meta refused the request (code $code" . ($type ? ", $type" : '') . "): $msg";
            break;
        }

        foreach ((array)($decoded['data'] ?? []) as $tpl) {
            if (is_array($tpl) && isset($tpl['name'])) $found[] = $tpl;
        }

        $next = $decoded['paging']['next'] ?? null;
        $url = (is_string($next) && strpos($next, 'https://graph.facebook.com/') === 0) ? $next : null;
    }

    if (!$found) {
        api_error($lastError ?: "Meta returned no templates for WABA $wabaId. Check that the token belongs to the business that owns this WABA.");
    }

    $res = wa_upsert_templates($found, (int)($jwt['user_id'] ?? 0));
    api_success($res + ['found' => count($found), 'waba_id' => $wabaId, 'pages' => $pages]);
}

/*
 * Import templates from whatever the Netcore panel can hand you, because its messaging API
 * (waapi.pepipost.com) has no template endpoint at all — every path under /api/v2/template*
 * answers 404, since template management lives on the cpaas.netcorecloud.com side.
 *
 * Accepts either:
 *   - JSON  — the response body of the panel's own template-list XHR, copied from DevTools.
 *             This also reveals the real endpoint, so automatic sync can be wired up later.
 *   - CSV / TSV — the file behind the download icon on Template management.
 *
 * Columns/keys are matched loosely by name, since neither export format is documented here.
 */
if ($action === 'import') {
    $payload = (string)jin('payload', '');
    if ($payload === '' && !empty($_FILES['file']) && $_FILES['file']['error'] === UPLOAD_ERR_OK) {
        if ($_FILES['file']['size'] > 5 * 1024 * 1024) api_error('File too large (max 5MB)');
        $payload = (string)file_get_contents($_FILES['file']['tmp_name']);
    }
    $payload = trim($payload);
    if ($payload === '') api_error('Paste the exported template list, or choose a file');

    // Excel and some panel exports write a UTF-8 BOM, which would otherwise become part of the
    // first column's header name and break every match against it.
    $payload = preg_replace('/^\xEF\xBB\xBF/', '', $payload);

    $found = [];

    $decoded = json_decode($payload, true);
    if (is_array($decoded)) {
        $walk = function ($node) use (&$walk, &$found) {
            if (!is_array($node)) return;
            $nameVal = $node['name'] ?? ($node['template_name'] ?? null);
            if (is_string($nameVal) && preg_match('/^[a-z0-9_]+$/', $nameVal)
                && (isset($node['components']) || isset($node['body']) || isset($node['template_body'])
                    || isset($node['language']) || isset($node['category']))) {
                $found[] = $node;
                return;
            }
            foreach ($node as $child) if (is_array($child)) $walk($child);
        };
        $walk($decoded);
        if (!$found) api_error('That JSON parsed, but nothing template-shaped was found in it. Make sure you copied the full response body.');
    } else {
        // ── CSV / TSV ──────────────────────────────────────────────────────────────────
        // Read through a stream rather than splitting on newlines: a template body legitimately
        // contains line breaks inside a quoted field, which a naive split would tear apart.
        $firstLine = strtok($payload, "\n");
        $delimiter = substr_count($firstLine, "\t") > substr_count($firstLine, ',') ? "\t" : ',';

        $fh = fopen('php://memory', 'r+');
        fwrite($fh, $payload);
        rewind($fh);
        $rows = [];
        while (($r = fgetcsv($fh, 0, $delimiter)) !== false) {
            if ($r === [null] || $r === false) continue; // blank line
            $rows[] = $r;
        }
        fclose($fh);
        if (count($rows) < 2) api_error('That does not look like a template export — no header row plus data rows were found.');

        $header = array_shift($rows);
        /** Exact header match first, then a contains-match, so "Template Name" and "name" both work. */
        $col = function (array $needles) use ($header) {
            foreach ([true, false] as $exact) {
                foreach ($header as $i => $h) {
                    $h = strtolower(trim((string)$h));
                    foreach ($needles as $n) {
                        if ($exact ? $h === $n : strpos($h, $n) !== false) return $i;
                    }
                }
            }
            return null;
        };
        $iName   = $col(['template name', 'name', 'template']);
        $iLang   = $col(['language', 'lang']);
        $iCat    = $col(['category', 'type']);
        $iStatus = $col(['status']);
        $iBody   = $col(['body', 'message', 'content']);
        $iHeader = $col(['header']);
        $iFooter = $col(['footer']);
        if ($iName === null) api_error('No "Template name" column found in that file. Header row was: ' . implode(' | ', array_map('strval', $header)));

        $get = fn(array $r, $i) => ($i === null || !isset($r[$i])) ? '' : trim((string)$r[$i]);
        foreach ($rows as $r) {
            $name = $get($r, $iName);
            if ($name === '') continue;
            $found[] = [
                'name'     => $name,
                'language' => $get($r, $iLang) ?: 'en',
                'category' => $get($r, $iCat),
                'status'   => $get($r, $iStatus),
                'body'     => $get($r, $iBody),
                'header'   => $get($r, $iHeader),
                'footer'   => $get($r, $iFooter),
            ];
        }
        if (!$found) api_error('No template rows were found in that file.');
    }

    $res = wa_upsert_templates($found, (int)($jwt['user_id'] ?? 0));
    api_success($res + ['found' => count($found)]);
}

/**
 * Writes a batch of loosely-shaped template records into wa_templates, keyed on (name,
 * language). Shared by the API sync and the manual import so both land identical rows.
 *
 * Rows without message text are counted as skipped rather than written: body_text is what the
 * placeholder count is derived from, and a template imported with an empty body would look like
 * it has no variables — which would then send a real template with its parameters missing.
 *
 * @return array{imported:int, updated:int, skipped:int, skipped_names:string[]}
 */
function wa_upsert_templates(array $found, int $userId): array {
    global $conn;
    $imported = 0; $updated = 0; $skipped = 0; $skippedNames = [];

    foreach ($found as $t) {
        // Field names differ between Meta's shape, Netcore's own, and a CSV export, so each is
        // read through a short list of spellings rather than one hard-coded key.
        $name = (string)($t['name'] ?? ($t['template_name'] ?? ''));
        if ($name === '' || !preg_match('/^[a-z0-9_]+$/', $name)) { $skipped++; continue; }

        $lang = (string)($t['language']['code'] ?? ($t['language'] ?? ($t['language_code'] ?? ($t['lang'] ?? 'en'))));
        // A CSV often writes "English" rather than the code Meta expects.
        $langMap = ['english' => 'en', 'hindi' => 'hi', 'marathi' => 'mr', 'gujarati' => 'gu',
                    'tamil' => 'ta', 'telugu' => 'te', 'bengali' => 'bn', 'kannada' => 'kn',
                    'malayalam' => 'ml', 'punjabi' => 'pa'];
        $lang = $langMap[strtolower(trim($lang))] ?? $lang;
        if ($lang === '') $lang = 'en';

        $cat = strtolower(trim((string)($t['category'] ?? ($t['template_category'] ?? 'utility'))));
        if (!in_array($cat, ['marketing', 'utility', 'authentication'], true)) $cat = 'utility';

        $approval = strtolower(trim((string)($t['status'] ?? ($t['template_status'] ?? ($t['approval_status'] ?? 'unknown')))));
        $approval = in_array($approval, ['approved', 'pending', 'rejected'], true) ? $approval : 'unknown';

        // Meta's components array when present; the flat spellings otherwise.
        $bodyText = ''; $headerText = ''; $footerText = ''; $headerType = 'none'; $buttons = [];
        foreach ((array)($t['components'] ?? []) as $comp) {
            if (!is_array($comp)) continue;
            $ctype = strtolower((string)($comp['type'] ?? ''));
            if ($ctype === 'body')   $bodyText = (string)($comp['text'] ?? '');
            if ($ctype === 'footer') $footerText = (string)($comp['text'] ?? '');
            if ($ctype === 'header') {
                $fmt = strtolower((string)($comp['format'] ?? 'text'));
                $headerType = in_array($fmt, ['text', 'image', 'video', 'document'], true) ? $fmt : 'text';
                $headerText = (string)($comp['text'] ?? '');
            }
            if ($ctype === 'buttons') {
                foreach ((array)($comp['buttons'] ?? []) as $b) {
                    $bt = strtolower((string)($b['type'] ?? ''));
                    $buttons[] = [
                        'type'    => $bt === 'url' ? 'url' : ($bt === 'phone_number' ? 'phone' : 'quick_reply'),
                        'text'    => (string)($b['text'] ?? ''),
                        'url'     => (string)($b['url'] ?? ''),
                        'phone'   => (string)($b['phone_number'] ?? ''),
                        'dynamic' => isset($b['url']) && strpos((string)$b['url'], '{{') !== false,
                    ];
                }
            }
        }
        if ($bodyText === '')   $bodyText = (string)($t['body'] ?? ($t['template_body'] ?? ($t['content'] ?? '')));
        if ($headerText === '') $headerText = (string)($t['header'] ?? '');
        if ($footerText === '') $footerText = (string)($t['footer'] ?? '');
        if ($headerType === 'none' && trim($headerText) !== '') $headerType = 'text';

        if (trim($bodyText) === '') { $skipped++; $skippedNames[] = $name; continue; }

        $nameE = $conn->real_escape_string($name);
        $langE = $conn->real_escape_string($lang);
        $vals = [
            "name='$nameE'", "display_name='$nameE'",
            "category='" . $conn->real_escape_string($cat) . "'", "language='$langE'",
            "header_type='" . $conn->real_escape_string($headerType) . "'",
            "header_text='" . $conn->real_escape_string($headerText) . "'",
            "body_text='"   . $conn->real_escape_string($bodyText) . "'",
            "footer_text='" . $conn->real_escape_string($footerText) . "'",
            "approval_status='" . $conn->real_escape_string($approval) . "'",
            "status='active'",
        ];
        // Meta's own template id, when the record came from Meta — it's what lets a single
        // template's status be re-checked later without re-reading the whole account.
        if (!empty($t['id']) && is_string($t['id'])) {
            $vals[] = "meta_template_id='" . $conn->real_escape_string($t['id']) . "'";
        }
        // Buttons are only overwritten when the source actually carried some — a CSV export
        // usually has no button column, and blanking existing buttons would quietly break the
        // dynamic-URL mapping on a template that was imported properly earlier.
        if ($buttons) $vals[] = "buttons='" . $conn->real_escape_string(json_encode($buttons)) . "'";

        $exists = $conn->query("SELECT id FROM wa_templates WHERE name='$nameE' AND language='$langE' LIMIT 1");
        $row = $exists ? $exists->fetch_assoc() : null;
        if ($row) {
            $conn->query("UPDATE wa_templates SET " . implode(', ', $vals) . ' WHERE id=' . (int)$row['id']);
            $updated++;
        } else {
            $conn->query("INSERT INTO wa_templates SET " . implode(', ', $vals) . ', created_by=' . $userId);
            $imported++;
        }
    }

    return ['imported' => $imported, 'updated' => $updated, 'skipped' => $skipped,
            'skipped_names' => array_slice($skippedNames, 0, 20)];
}

/* ── Meta template management ───────────────────────────────────────────────────────────── */

/** One Graph API call. Meta's error bodies are genuinely descriptive, so they're returned intact
 *  rather than being reduced to a status code. */
function wa_graph(string $method, string $url, string $token, ?array $payload = null): array {
    $ch = curl_init($url);
    $opts = [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HTTPHEADER     => ['Content-Type: application/json', 'Authorization: Bearer ' . $token],
        CURLOPT_TIMEOUT        => 25,
    ];
    if ($method !== 'GET') {
        $opts[CURLOPT_CUSTOMREQUEST] = $method;
        if ($payload !== null) $opts[CURLOPT_POSTFIELDS] = json_encode($payload);
    }
    curl_setopt_array($ch, $opts);
    $body   = curl_exec($ch);
    $status = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $err    = curl_error($ch);
    curl_close($ch);

    if ($err !== '') return ['ok' => false, 'error' => "Could not reach Meta: $err", 'data' => null];
    $decoded = json_decode((string)$body, true);
    if ($status < 200 || $status >= 300 || !is_array($decoded)) {
        $e = $decoded['error'] ?? [];
        $msg = $e['error_user_msg'] ?? ($e['message'] ?? (is_string($body) ? mb_substr($body, 0, 300) : "HTTP $status"));
        $code = $e['code'] ?? $status;
        return ['ok' => false, 'error' => "Meta rejected this (code $code): $msg", 'data' => $decoded];
    }
    return ['ok' => true, 'error' => null, 'data' => $decoded];
}

/**
 * Turns one of our wa_templates rows into Meta's `components` array.
 *
 * Meta requires an `example` for every placeholder — a template with {{1}} and no sample is
 * rejected outright — which is exactly what the editor's "Sample values" section is for.
 */
function wa_build_meta_components(array $t): array {
    $components = [];
    $samples = json_decode($t['sample_values'] ?? '{}', true) ?: [];

    $headerVars = $t['header_type'] === 'text' ? wa_placeholder_count((string)$t['header_text']) : 0;
    if ($t['header_type'] === 'text' && trim((string)$t['header_text']) !== '') {
        $header = ['type' => 'HEADER', 'format' => 'TEXT', 'text' => (string)$t['header_text']];
        if ($headerVars > 0) {
            $header['example'] = ['header_text' => array_map(
                fn($i) => (string)($samples['header'][$i] ?? 'Sample'),
                range(0, $headerVars - 1)
            )];
        }
        $components[] = $header;
    } elseif (in_array($t['header_type'], ['image', 'video', 'document'], true) && trim((string)$t['header_media_url']) !== '') {
        $components[] = [
            'type' => 'HEADER', 'format' => strtoupper($t['header_type']),
            'example' => ['header_handle' => [(string)$t['header_media_url']]],
        ];
    }

    $bodyVars = wa_placeholder_count((string)$t['body_text']);
    $body = ['type' => 'BODY', 'text' => (string)$t['body_text']];
    if ($bodyVars > 0) {
        // body_text example is an array OF arrays — one inner array per variable set.
        $body['example'] = ['body_text' => [array_map(
            fn($i) => (string)($samples['body'][$i] ?? 'Sample'),
            range(0, $bodyVars - 1)
        )]];
    }
    $components[] = $body;

    if (trim((string)$t['footer_text']) !== '') {
        $components[] = ['type' => 'FOOTER', 'text' => (string)$t['footer_text']];
    }

    $buttons = json_decode($t['buttons'] ?? '[]', true) ?: [];
    $metaButtons = [];
    foreach ($buttons as $b) {
        $text = (string)($b['text'] ?? '');
        if ($text === '') continue;
        if (($b['type'] ?? '') === 'url') {
            $url = trim((string)($b['url'] ?? ''));
            $btn = ['type' => 'URL', 'text' => $text, 'url' => $url];

            /*
             * A TRACKED LINK IS STATIC, and that is the entire point of it.
             *
             * When the template has a link_id, its URL already ends in that id ("…/login/23") and
             * carries the campaign by itself. Appending a variable on top would recreate exactly
             * the URL shape Meta refused to approve — every submission of the {{1}} form came back
             * INCORRECT_CATEGORY, under UTILITY and MARKETING alike — so the dynamic branch below
             * is skipped entirely and Meta sees a plain link with no placeholder and no example.
             *
             * Templates set up before wa_links existed have no link_id and still take the old
             * path, so nothing about them changes until they are re-saved.
             */
            $hasTrackedLink = (int)($t['link_id'] ?? 0) > 0;

            if (!empty($b['dynamic']) && !$hasTrackedLink) {
                /*
                 * WHERE {{1}} GOES, and why it is not simply appended.
                 *
                 * This used to do  rtrim($url,'/') . '/{{1}}'  unconditionally, which produced a
                 * PATH segment:  https://dashboard…/login/{{1}}. Filled with attribution
                 * parameters that becomes  …/login/campaign_id=14&medium=whatsapp…  — a nonsense
                 * path, and window.location.search is empty, so the landing page reads no
                 * campaign at all. It also double-appended on any template whose url already
                 * carried {{1}} (everything imported from Meta does), giving  …/{{1}}/{{1}}.
                 *
                 * So: a placeholder the admin already typed is respected exactly as written —
                 * that is the only way to choose between the query form (…/login?{{1}}, one page
                 * per template) and the path form (…/{{1}}, one template serving many pages).
                 * Only when there is no placeholder at all is one added, in QUERY form, because
                 * that is what the attribution parameters need to be readable.
                 */
                if (strpos($btn['url'], '{{') === false) {
                    $btn['url'] .= (strpos($btn['url'], '?') === false ? '?{{1}}' : '&{{1}}');
                }
                // Meta requires a fully-formed example. A realistic one also shows the reviewer
                // what the variable is for, which makes a URL button far less likely to be
                // rejected than the literal word "sample".
                $btn['example'] = [str_replace('{{1}}', 'campaign_id=1&medium=whatsapp&attr_window=2', $btn['url'])];
            }
            $metaButtons[] = $btn;
        } elseif (($b['type'] ?? '') === 'phone') {
            $metaButtons[] = ['type' => 'PHONE_NUMBER', 'text' => $text, 'phone_number' => (string)($b['phone'] ?? '')];
        } else {
            $metaButtons[] = ['type' => 'QUICK_REPLY', 'text' => $text];
        }
    }
    if ($metaButtons) $components[] = ['type' => 'BUTTONS', 'buttons' => $metaButtons];

    return $components;
}

/*
 * Submits one of our templates to Meta for approval — the step that used to be "go do it in the
 * Netcore panel instead". Meta answers with an id and a status (normally PENDING); the webhook's
 * Template tab, or Refresh status below, moves it to APPROVED/REJECTED later.
 */
if ($action === 'submit_to_meta') {
    $id = (int)jin('id', 0);
    $r = $conn->query("SELECT * FROM wa_templates WHERE id=$id LIMIT 1");
    $t = $r ? $r->fetch_assoc() : null;
    if (!$t) api_error('Not found', 404);

    $settings = wa_settings_row() ?: [];
    $token = trim((string)($settings['meta_access_token'] ?? ''));
    if ($token === '') api_error('Add a Meta access token in Settings → Template sync first.');

    $sender = wa_sender_by_id((int)jin('sender_id', 0)) ?: wa_default_sender();
    $wabaId = trim((string)($sender['waba_id'] ?? ''));
    if ($wabaId === '') api_error('No WABA ID on the sending number — add it in Settings → Sending numbers.');

    // Caught here rather than as a Meta rejection, because Meta's message for this is far less
    // clear than naming the specific missing sample.
    $bodyVars = wa_placeholder_count((string)$t['body_text']);
    $samples = json_decode($t['sample_values'] ?? '{}', true) ?: [];
    for ($i = 0; $i < $bodyVars; $i++) {
        if (trim((string)($samples['body'][$i] ?? '')) === '') {
            api_error('Meta needs a sample value for every variable. Fill in "Sample values" for body {{' . ($i + 1) . '}} before submitting.');
        }
    }

    $components = wa_build_meta_components($t);
    $existingId = trim((string)$t['meta_template_id']);

    /*
     * CREATE a new template, or EDIT the one we already have on Meta.
     *
     * Creating twice with the same name+language is refused outright:
     *   (#100) There is already English content for this template. You can create a new template
     *          and try again.
     * which is what every resubmit of a REJECTED template hits — exactly when someone is fixing
     * the thing Meta objected to. Editing is the operation that was wanted, and Meta allows it on
     * a rejected or approved template (POST to the template id, components only — name, language
     * and category are fixed once created).
     *
     * Falls back to creating when the edit is refused, because a template id can go stale: deleted
     * on Meta, or recreated under a new id after a 30-day name cooldown.
     */
    if ($existingId !== '') {
        /*
         * category is sent on the edit as well as the components.
         *
         * Meta FIXES a template's category when it is created, and an edit that omits it silently
         * keeps the old one — so a template rejected as INCORRECT_CATEGORY stays rejected no
         * matter how many times it is resubmitted, because the one thing that needed to change
         * never left this server. Recent API versions accept a category change here; where they
         * don't, Meta refuses the edit and the create-fallback below runs, which surfaces the
         * name collision as a real error instead of a silent no-op.
         */
        $res = wa_graph('POST', WA_GRAPH_BASE . WA_GRAPH_VERSION . '/' . rawurlencode($existingId),
            $token, ['components' => $components, 'category' => strtoupper($t['category'])]);
        if (!$res['ok']) {
            $res = wa_graph('POST', WA_GRAPH_BASE . WA_GRAPH_VERSION . '/' . rawurlencode($wabaId) . '/message_templates',
                $token, [
                    'name'       => $t['name'],
                    'language'   => $t['language'],
                    'category'   => strtoupper($t['category']),
                    'components' => $components,
                ]);
            if (!$res['ok']) api_error($res['error']);
            $existingId = '';   // a create returns a fresh id below
        }
    } else {
        $res = wa_graph('POST', WA_GRAPH_BASE . WA_GRAPH_VERSION . '/' . rawurlencode($wabaId) . '/message_templates',
            $token, [
                'name'       => $t['name'],
                'language'   => $t['language'],
                'category'   => strtoupper($t['category']),
                'components' => $components,
            ]);
        if (!$res['ok']) api_error($res['error']);
    }

    // An edit answers {"success": true} with no id, so the one we already hold is kept.
    $metaId = (string)($res['data']['id'] ?? $existingId);
    $status = strtolower((string)($res['data']['status'] ?? 'pending'));
    $status = in_array($status, ['approved', 'pending', 'rejected'], true) ? $status : 'pending';
    $conn->query("UPDATE wa_templates
                     SET meta_template_id='" . $conn->real_escape_string($metaId) . "',
                         approval_status='" . $conn->real_escape_string($status) . "'
                   WHERE id=$id");

    api_success(['meta_template_id' => $metaId, 'approval_status' => $status]);
}

/* Re-checks one template's approval status without re-syncing the whole account. */
if ($action === 'refresh_status') {
    $id = (int)jin('id', 0);
    $r = $conn->query("SELECT * FROM wa_templates WHERE id=$id LIMIT 1");
    $t = $r ? $r->fetch_assoc() : null;
    if (!$t) api_error('Not found', 404);

    $settings = wa_settings_row() ?: [];
    $token = trim((string)($settings['meta_access_token'] ?? ''));
    if ($token === '') api_error('Add a Meta access token in Settings → Template sync first.');
    if (trim((string)$t['meta_template_id']) === '') {
        api_error('This template has no Meta id yet — use "Sync from WhatsApp" to match it up, or submit it to Meta.');
    }

    /*
     * rejected_reason is asked for alongside the status, because "rejected" on its own is the
     * least actionable word Meta can send: the template has to be changed, and nothing here says
     * what to change. Meta returns a short slug (INVALID_FORMAT, ABUSIVE_CONTENT,
     * SCAM, TAG_CONTENT_MISMATCH…) which is at least a direction.
     */
    $url = WA_GRAPH_BASE . WA_GRAPH_VERSION . '/' . rawurlencode($t['meta_template_id'])
         . '?fields=status,category,rejected_reason';
    $res = wa_graph('GET', $url, $token);
    if (!$res['ok']) api_error($res['error']);

    $status = strtolower((string)($res['data']['status'] ?? 'unknown'));
    $status = in_array($status, ['approved', 'pending', 'rejected'], true) ? $status : 'unknown';
    $conn->query("UPDATE wa_templates SET approval_status='" . $conn->real_escape_string($status) . "' WHERE id=$id");

    $reason = (string)($res['data']['rejected_reason'] ?? '');
    // NONE is what Meta returns for a template it hasn't rejected — not a reason worth showing.
    if (strtoupper($reason) === 'NONE') $reason = '';

    api_success([
        'approval_status'  => $status,
        'rejected_reason'  => $reason,
        // Turned into a sentence here rather than in the UI: the mapping is Meta's vocabulary, and
        // it belongs next to the call that produced it.
        'rejected_message' => $reason === '' ? '' : (
            [
                'INVALID_FORMAT'           => 'Formatting problem — usually a variable at the start or end of the body, non-consecutive {{n}}, or a missing sample value.',
                'ABUSIVE_CONTENT'          => 'Meta considered the wording abusive or misleading.',
                'SCAM'                     => 'Flagged as a possible scam. A whole URL inside a variable is a common trigger — put the domain in the fixed text and leave only the query string dynamic.',
                'PROMOTIONAL'              => 'Marketing wording in a Utility template. Either soften the copy or submit it as Marketing.',
                'TAG_CONTENT_MISMATCH'     => 'The content does not match the category chosen.',
                'INCORRECT_CATEGORY'       => 'Wrong category for this content — change the category and resubmit.',
                'INVALID_BUTTON_URL'       => 'A button URL was rejected. A fully dynamic link is the usual cause.',
                'INVALID_BUTTON_PHONE_NUMBER' => 'The button phone number was rejected.',
            ][strtoupper($reason)] ?? ('Meta reported: ' . $reason)
        ),
    ]);
}

api_error('Invalid action');

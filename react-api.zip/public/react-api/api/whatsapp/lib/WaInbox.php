<?php
/*
 * Live Chat — the two-way half of the WhatsApp channel.
 *
 * Campaigns are one-way: we send a template and count what comes back as a number. This file
 * backs the other direction — when someone REPLIES to one of those campaign messages, that reply
 * has to land somewhere a human can answer it. That "somewhere" is a conversation.
 *
 * Two concepts do all the work:
 *
 *   wa_conversations   one row per (sending number, contact number). Carries the denormalized
 *                      last-message preview so the inbox list is a single indexed SELECT with no
 *                      joins — with thousands of threads that is the difference between an inbox
 *                      that opens instantly and one that doesn't.
 *
 *   wa_messages        the free-form traffic: every inbound message, and every manual reply an
 *                      admin types here. Campaign sends are deliberately NOT copied in — the
 *                      thread view merges them straight out of wa_campaign_recipients, so there
 *                      is exactly one copy of a campaign message in the database and its
 *                      delivered/read state stays the campaign's own.
 *
 * THE 24-HOUR RULE, because it explains most of this UI:
 * WhatsApp only allows free-form messages inside 24 hours of the contact's last message
 * ("customer service window"). Outside it, Meta rejects anything but an approved template. So
 * every conversation tracks window_expires_at, the composer disables itself when it lapses, and
 * the template picker takes over. Getting this wrong doesn't produce an error an admin would
 * understand — it produces a message that simply never arrives.
 */
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/schema.php';
require_once __DIR__ . '/WaHelpers.php';
require_once __DIR__ . '/WaAudienceResolver.php';
// wa_log() and wa_record_event() live here. webhook.php already pulls it in before this file,
// but the dependency is stated explicitly so including WaInbox.php on its own (a future cron,
// a one-off script) can't fatal on an undefined function.
require_once __DIR__ . '/WaSendWorker.php';

/** Where inbound media is cached after its first fetch. Outside the web root's reach on purpose:
 *  everything is served back through wa_inbox.php so the JWT gate still applies to an image. */
if (!defined('WA_MEDIA_DIR')) define('WA_MEDIA_DIR', __DIR__ . '/../media');

/** Meta keeps inbound media for 30 days; after that the media id 404s and only our cache has it. */
if (!defined('WA_MEDIA_RETENTION_DAYS')) define('WA_MEDIA_RETENTION_DAYS', 30);

function wa_inbox_ensure_schema(): void {
    global $conn;
    if (!$conn) return;

    try {
        $conn->query("CREATE TABLE IF NOT EXISTS wa_conversations (
            id               BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            phone            VARCHAR(24) NOT NULL,
            phone_number_id  VARCHAR(32) NOT NULL DEFAULT '',
            sender_id        INT DEFAULT NULL,
            waba_id          VARCHAR(64) DEFAULT NULL,

            -- Identity. profile_name is what WhatsApp reports the contact calls themselves;
            -- the rest is matched out of our own records so the panel can show a real person
            -- rather than a bare number.
            profile_name     VARCHAR(255) DEFAULT NULL,
            user_id          BIGINT UNSIGNED DEFAULT NULL,
            first_name       VARCHAR(255) DEFAULT NULL,
            last_name        VARCHAR(255) DEFAULT NULL,
            email            VARCHAR(255) DEFAULT NULL,

            -- Denormalized preview for the list pane.
            last_message_at        DATETIME DEFAULT NULL,
            last_message_text      VARCHAR(500) DEFAULT NULL,
            last_message_direction ENUM('in','out') DEFAULT NULL,
            last_message_type      VARCHAR(24) DEFAULT NULL,
            unread_count           INT NOT NULL DEFAULT 0,

            -- End of the free-form window: last inbound + 24h. NULL means never messaged us.
            window_expires_at DATETIME DEFAULT NULL,
            last_inbound_at   DATETIME DEFAULT NULL,

            -- Which campaign brought this person in — the first one whose message they answered.
            origin_campaign_id INT DEFAULT NULL,

            status      ENUM('open','resolved') NOT NULL DEFAULT 'open',
            is_archived TINYINT(1) NOT NULL DEFAULT 0,
            assigned_to BIGINT UNSIGNED DEFAULT NULL,
            note        VARCHAR(1000) DEFAULT NULL,

            created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

            UNIQUE INDEX uq_number_phone (phone_number_id, phone),
            -- The inbox list's only ORDER BY. Archived rows are filtered first so the index
            -- stays useful for the default view.
            INDEX idx_recent (is_archived, last_message_at),
            INDEX idx_unread (unread_count),
            INDEX idx_phone (phone)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

        $conn->query("CREATE TABLE IF NOT EXISTS wa_messages (
            id              BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            conversation_id BIGINT UNSIGNED NOT NULL,
            direction       ENUM('in','out') NOT NULL,
            wa_message_id   VARCHAR(120) DEFAULT NULL,
            -- Echoed to Meta as nothing; kept so a send can be correlated before the id arrives.
            rid             CHAR(32) DEFAULT NULL,

            msg_type   VARCHAR(24) NOT NULL DEFAULT 'text',
            body       TEXT DEFAULT NULL,
            caption    VARCHAR(1000) DEFAULT NULL,

            -- Media. media_id is Meta's handle (valid ~30 days); local_path is our cache, filled
            -- on first view and the only copy that survives Meta's retention window.
            media_id       VARCHAR(190) DEFAULT NULL,
            media_mime     VARCHAR(120) DEFAULT NULL,
            media_filename VARCHAR(255) DEFAULT NULL,
            media_size     INT DEFAULT NULL,
            local_path     VARCHAR(255) DEFAULT NULL,

            template_name VARCHAR(255) DEFAULT NULL,
            -- The message being replied to, when the contact used WhatsApp's reply-quote.
            context_wamid VARCHAR(120) DEFAULT NULL,

            status        ENUM('received','pending','sent','delivered','read','failed') NOT NULL DEFAULT 'received',
            error_code    VARCHAR(64) DEFAULT NULL,
            error_message VARCHAR(500) DEFAULT NULL,

            sent_by    BIGINT UNSIGNED DEFAULT NULL,
            created_at DATETIME NOT NULL,
            delivered_at DATETIME DEFAULT NULL,
            read_at      DATETIME DEFAULT NULL,

            -- Meta re-delivers a webhook it didn't get a 200 for, so the same inbound message
            -- can legitimately arrive several times. This key is what makes ingestion idempotent.
            UNIQUE INDEX uq_wamid (wa_message_id),
            INDEX idx_thread (conversation_id, id),
            INDEX idx_created (created_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    } catch (\Throwable $e) {
        error_log('wa_inbox_ensure_schema: ' . $e->getMessage());
    }
}

/* ── identity ─────────────────────────────────────────────────────────────────────────── */

/**
 * Everything we already know about this number, pulled from campaign history.
 *
 * A person who replies to a campaign is by definition someone we messaged, so their name and
 * email are already sitting on the recipient row — no extra lookup against `users` needed, and
 * it works for list-sourced contacts that have no user record at all.
 */
function wa_identity_for_phone(string $phone): array {
    global $conn;
    $p = $conn->real_escape_string($phone);
    $r = $conn->query("SELECT user_id, email, first_name, last_name, campaign_id
                         FROM wa_campaign_recipients
                        WHERE phone='$p'
                        ORDER BY (user_id IS NULL) ASC, id DESC
                        LIMIT 1");
    $row = $r ? $r->fetch_assoc() : null;
    return $row ?: [];
}

/**
 * The conversation for a (sending number, contact) pair, created on first contact.
 *
 * INSERT … ON DUPLICATE KEY is deliberate over SELECT-then-INSERT: webhook deliveries for the
 * same person can arrive concurrently, and the race would otherwise produce two threads for one
 * contact — which looks to an admin like messages randomly going missing.
 */
function wa_conversation_upsert(string $phone, string $phoneNumberId, ?string $profileName = null): ?array {
    global $conn;

    $p   = $conn->real_escape_string($phone);
    $pni = $conn->real_escape_string($phoneNumberId);

    $r = $conn->query("SELECT * FROM wa_conversations WHERE phone_number_id='$pni' AND phone='$p' LIMIT 1");
    $existing = $r ? $r->fetch_assoc() : null;

    if ($existing) {
        // A profile name can change (people rename themselves); keep the latest.
        if ($profileName !== null && $profileName !== '' && $profileName !== $existing['profile_name']) {
            $conn->query("UPDATE wa_conversations SET profile_name='" . $conn->real_escape_string($profileName) . "'
                           WHERE id=" . (int)$existing['id']);
            $existing['profile_name'] = $profileName;
        }
        return $existing;
    }

    $ident = wa_identity_for_phone($phone);
    $sender = null;
    if ($phoneNumberId !== '') {
        $sr = $conn->query("SELECT id, waba_id FROM wa_senders WHERE phone_number_id='$pni' LIMIT 1");
        $sender = $sr ? $sr->fetch_assoc() : null;
    }

    $esc = fn($v) => "'" . $conn->real_escape_string((string)$v) . "'";
    $conn->query("INSERT INTO wa_conversations
        (phone, phone_number_id, sender_id, waba_id, profile_name, user_id, first_name, last_name, email, origin_campaign_id)
        VALUES (" . $esc($phone) . ", " . $esc($phoneNumberId) . ", "
        . (isset($sender['id']) ? (int)$sender['id'] : 'NULL') . ", "
        . $esc($sender['waba_id'] ?? '') . ", " . $esc((string)$profileName) . ", "
        . (!empty($ident['user_id']) ? (int)$ident['user_id'] : 'NULL') . ", "
        . $esc($ident['first_name'] ?? '') . ", " . $esc($ident['last_name'] ?? '') . ", "
        . $esc($ident['email'] ?? '') . ", "
        . (!empty($ident['campaign_id']) ? (int)$ident['campaign_id'] : 'NULL') . ")
        ON DUPLICATE KEY UPDATE updated_at = NOW()");

    $r2 = $conn->query("SELECT * FROM wa_conversations WHERE phone_number_id='$pni' AND phone='$p' LIMIT 1");
    $row = $r2 ? $r2->fetch_assoc() : null;
    return $row ?: null;
}

/** Refreshes the list-pane preview after a message lands. One UPDATE, never a recount. */
function wa_conversation_touch(int $conversationId, array $msg, bool $inbound): void {
    global $conn;

    $preview = wa_message_preview($msg);
    $at      = $msg['created_at'] ?? date('Y-m-d H:i:s');

    $sets = [
        "last_message_at='"        . $conn->real_escape_string($at) . "'",
        "last_message_text='"      . $conn->real_escape_string(mb_substr($preview, 0, 480)) . "'",
        "last_message_direction='" . ($inbound ? 'in' : 'out') . "'",
        "last_message_type='"      . $conn->real_escape_string((string)($msg['msg_type'] ?? 'text')) . "'",
    ];
    if ($inbound) {
        // Every inbound message restarts the 24-hour free-form window, and un-resolves a thread
        // someone had closed — a new question on an old thread is still a new question.
        $sets[] = "unread_count = unread_count + 1";
        $sets[] = "last_inbound_at='" . $conn->real_escape_string($at) . "'";
        $sets[] = "window_expires_at = DATE_ADD('" . $conn->real_escape_string($at) . "', INTERVAL 24 HOUR)";
        $sets[] = "status='open'";
        $sets[] = "is_archived=0";
    }
    $conn->query("UPDATE wa_conversations SET " . implode(', ', $sets) . ' WHERE id=' . (int)$conversationId);
}

/** One line of text for the list pane, whatever the message actually was. */
function wa_message_preview(array $msg): string {
    $type = (string)($msg['msg_type'] ?? 'text');
    $body = trim((string)($msg['body'] ?? ''));
    $cap  = trim((string)($msg['caption'] ?? ''));
    switch ($type) {
        case 'image':    return $cap !== '' ? "📷 $cap" : '📷 Photo';
        case 'video':    return $cap !== '' ? "🎥 $cap" : '🎥 Video';
        case 'audio':    return '🎤 Voice message';
        case 'document': return '📄 ' . ($msg['media_filename'] ?: 'Document');
        case 'sticker':  return 'Sticker';
        case 'location': return '📍 Location';
        case 'contacts': return '👤 Contact card';
        case 'template': return $body !== '' ? $body : 'Template message';
        default:         return $body !== '' ? $body : ucfirst($type);
    }
}

/* ── webhook ingestion ────────────────────────────────────────────────────────────────── */

/**
 * Pulls inbound messages, and status updates for OUR replies, out of a Meta webhook payload.
 *
 * Only Meta's documented Cloud API shape is walked here — entry[].changes[].value — rather than
 * the tolerant recursive search webhook.php uses for campaign statuses. Inbound messages carry
 * real content that has to be stored exactly, and a fuzzy walker that guessed wrong would write
 * a garbled conversation rather than simply miss a counter.
 *
 * @return array{messages:int, statuses:int, clicks:int}
 */
function wa_ingest_webhook(array $payload): array {
    global $conn;
    $messages = 0; $statuses = 0; $clicks = 0; $clickEvents = 0;

    foreach (($payload['entry'] ?? []) as $entry) {
        foreach (($entry['changes'] ?? []) as $change) {
            if (($change['field'] ?? '') !== 'messages') continue;
            $value = $change['value'] ?? [];
            if (!is_array($value)) continue;

            $phoneNumberId = (string)($value['metadata']['phone_number_id'] ?? '');

            // contacts[] runs parallel to messages[]: wa_id → the name the contact set on their
            // own WhatsApp profile.
            $names = [];
            foreach (($value['contacts'] ?? []) as $c) {
                $wid = (string)($c['wa_id'] ?? '');
                if ($wid !== '') $names[$wid] = (string)($c['profile']['name'] ?? '');
            }

            foreach (($value['messages'] ?? []) as $m) {
                if (wa_store_inbound_message($m, $phoneNumberId, $names)) $messages++;
            }

            foreach (($value['statuses'] ?? []) as $st) {
                if (wa_apply_message_status($st)) $statuses++;
            }

            // `seen` is tracked separately from `applied` so the caller can tell "recognized but
            // not ours" from "unparseable" — otherwise a click we deliberately declined to credit
            // still counts as an unknown payload and gets dumped into the log in full.
            $ua = wa_apply_user_actions($value);
            $clicks     += $ua['applied'];
            $clickEvents += $ua['seen'];
        }
    }
    return ['messages' => $messages, 'statuses' => $statuses, 'clicks' => $clicks, 'click_events' => $clickEvents];
}

/**
 * Link taps inside a marketing message, which Meta reports as `user_actions` on the change
 * rather than as a status:
 *
 *   value.user_actions[] = { timestamp, action_type: "marketing_messages_link_click",
 *                            marketing_messages_link_click_data: { tracking_token } }
 *
 * Worth handling for two reasons. It is the ONLY signal Meta gives for a URL button being
 * clicked — quick-reply taps arrive as inbound messages, URL taps arrive only here. And left
 * unparsed it was falling through to the "no recognizable events" branch, which dumps 400
 * characters of raw JSON into the log on every single click.
 *
 * Attribution is best-effort: the payload identifies the tap by a tracking_token, not by a
 * message id or a phone number, so a click can only be credited when the payload happens to
 * carry a recipient. Uncreditable clicks are counted and logged rather than guessed at — a
 * click column that silently invents numbers is worse than one that undercounts.
 */
function wa_apply_user_actions(array $value): array {
    global $conn;
    $actions = $value['user_actions'] ?? [];
    if (!is_array($actions) || !$actions) return ['applied' => 0, 'seen' => 0];

    $applied = 0;
    $seen = 0;

    foreach ($actions as $a) {
        if (!is_array($a)) continue;
        if (($a['action_type'] ?? '') !== 'marketing_messages_link_click') continue;
        $seen++;

        // Whichever identifier this payload version happens to carry.
        $who = null;
        foreach (['recipient_id', 'wa_id', 'from', 'phone_number', 'recipient'] as $k) {
            if (!empty($a[$k]) && (is_string($a[$k]) || is_numeric($a[$k]))) { $who = (string)$a[$k]; break; }
        }
        if ($who === null) continue;

        $phone = wa_normalize_phone($who, wa_default_cc());
        if ($phone === null) continue;

        // Only OUR campaigns, and only recently — a tap on a message some other app on this WABA
        // sent must never inflate one of our campaigns.
        $r = $conn->query("SELECT id, campaign_id FROM wa_campaign_recipients
                            WHERE phone='" . $conn->real_escape_string($phone) . "'
                              AND is_test=0 AND sent_at IS NOT NULL
                              AND sent_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)
                            ORDER BY sent_at DESC LIMIT 1");
        $rec = $r ? $r->fetch_assoc() : null;
        if (!$rec) continue;

        $rid = (int)$rec['id']; $cid = (int)$rec['campaign_id'];
        $conn->query("UPDATE wa_campaign_recipients SET click_count = click_count + 1 WHERE id=$rid");
        $conn->query("UPDATE wa_campaigns SET click_count = click_count + 1 WHERE id=$cid");
        wa_record_event($cid, $rid, 'button_click', null, 'marketing message link click');
        $applied++;
    }

    if ($seen > 0 && $applied === 0) {
        // One short line instead of a 400-character JSON dump. Almost always another app's
        // traffic on a shared WABA, which is expected and uninteresting.
        $num = (string)($value['metadata']['display_phone_number'] ?? 'unknown number');
        wa_log("webhook: $seen marketing link click(s) on $num — not matched to any of our campaigns");
    }
    return ['applied' => $applied, 'seen' => $seen];
}

/** One inbound message → one wa_messages row. Returns false when it was a duplicate re-delivery. */
function wa_store_inbound_message(array $m, string $phoneNumberId, array $names): bool {
    global $conn;

    $wamid = (string)($m['id'] ?? '');
    $from  = (string)($m['from'] ?? '');
    if ($from === '') return false;

    $phone = wa_normalize_phone($from, wa_default_cc()) ?: preg_replace('/\D+/', '', $from);
    $conv  = wa_conversation_upsert($phone, $phoneNumberId, $names[$from] ?? null);
    if (!$conv) return false;

    $type = (string)($m['type'] ?? 'text');
    $ts   = isset($m['timestamp']) ? date('Y-m-d H:i:s', (int)$m['timestamp']) : date('Y-m-d H:i:s');

    $row = [
        'msg_type'   => $type,
        'body'       => null,
        'caption'    => null,
        'media_id'   => null,
        'media_mime' => null,
        'media_filename' => null,
        'media_size' => null,
        'created_at' => $ts,
    ];

    switch ($type) {
        case 'text':
            $row['body'] = (string)($m['text']['body'] ?? '');
            break;
        case 'image': case 'video': case 'audio': case 'document': case 'sticker':
            $node = $m[$type] ?? [];
            $row['media_id']       = (string)($node['id'] ?? '');
            $row['media_mime']     = (string)($node['mime_type'] ?? '');
            $row['media_filename'] = (string)($node['filename'] ?? '');
            $row['caption']        = (string)($node['caption'] ?? '');
            break;
        case 'button':
            // Tapping a quick-reply button on a template arrives as its own message.
            $row['body'] = (string)($m['button']['text'] ?? '');
            break;
        case 'interactive':
            $i = $m['interactive'] ?? [];
            $row['body'] = (string)($i['button_reply']['title'] ?? ($i['list_reply']['title'] ?? ''));
            break;
        case 'location':
            $l = $m['location'] ?? [];
            $row['body'] = trim(($l['name'] ?? '') . ' ' . ($l['address'] ?? '')) ?: (($l['latitude'] ?? '') . ',' . ($l['longitude'] ?? ''));
            break;
        case 'contacts':
            $row['body'] = (string)($m['contacts'][0]['name']['formatted_name'] ?? 'Contact');
            break;
        default:
            // Reactions, orders, system messages, anything Meta adds later. Stored as a
            // placeholder rather than dropped, so the thread doesn't develop silent gaps.
            $row['body'] = (string)($m[$type]['body'] ?? ucfirst($type) . ' message');
    }

    $esc = fn($v) => $v === null || $v === '' ? 'NULL' : "'" . $GLOBALS['conn']->real_escape_string((string)$v) . "'";
    $ctx = (string)($m['context']['id'] ?? '');

    $conn->query("INSERT INTO wa_messages
        (conversation_id, direction, wa_message_id, msg_type, body, caption, media_id, media_mime,
         media_filename, context_wamid, status, created_at)
        VALUES (" . (int)$conv['id'] . ", 'in', " . $esc($wamid) . ", " . $esc($row['msg_type']) . ", "
        . $esc($row['body']) . ", " . $esc($row['caption']) . ", " . $esc($row['media_id']) . ", "
        . $esc($row['media_mime']) . ", " . $esc($row['media_filename']) . ", " . $esc($ctx) . ", "
        . "'received', '" . $conn->real_escape_string($row['created_at']) . "')
        ON DUPLICATE KEY UPDATE wa_message_id = wa_message_id");

    // affected_rows is 0 when the ON DUPLICATE branch fired — i.e. Meta re-delivered a webhook
    // we already stored. Nothing further should happen, or the unread badge would climb on
    // every retry.
    if ($conn->affected_rows === 0) return false;

    wa_conversation_touch((int)$conv['id'], $row, true);

    /*
     * A reply is also a campaign signal.
     *
     * Tapping a QUICK-REPLY button on a template arrives here as an ordinary inbound message of
     * type 'button' (or 'interactive' for a list/button reply) — there is no separate click
     * webhook. So this is the only place a click can be counted, and without it the campaign
     * report's click column stays at zero forever.
     *
     * URL buttons are a different story: Meta does not report taps on them at all, through any
     * webhook field. If click-through on a link matters, the link has to carry its own tracking
     * (a redirect through the panel), not rely on WhatsApp.
     */
    $isTap = in_array($type, ['button', 'interactive'], true);
    wa_credit_reply_to_campaign($phone, (string)($m['context']['id'] ?? ''), $isTap);

    // "STOP" still means stop, whether it arrives here or through the campaign path.
    if (!empty($row['body']) && preg_match('/^\s*(stop|unsubscribe|opt\s*out)\b/i', (string)$row['body'])) {
        wa_record_optin($phone, 'optout', 'REPLY');
        wa_log("inbox: $phone opted out via reply");
    }
    return true;
}

/**
 * Counts an inbound message as a reply against the campaign that prompted it.
 *
 * When WhatsApp gives us a context id (the contact used the reply-quote), that identifies the
 * exact campaign message. Otherwise the most recent campaign message to that number inside the
 * last 24 hours is the only reasonable attribution — beyond that window the connection is a
 * guess, so nothing is credited rather than inflating a campaign's reply count.
 */
function wa_credit_reply_to_campaign(string $phone, string $contextWamid, bool $isButtonTap = false): void {
    global $conn;
    $p = $conn->real_escape_string($phone);

    $rec = null;
    if ($contextWamid !== '') {
        $r = $conn->query("SELECT id, campaign_id FROM wa_campaign_recipients
                            WHERE wa_message_id='" . $conn->real_escape_string($contextWamid) . "' LIMIT 1");
        $rec = $r ? $r->fetch_assoc() : null;
    }
    if (!$rec) {
        $r = $conn->query("SELECT id, campaign_id FROM wa_campaign_recipients
                            WHERE phone='$p' AND is_test=0 AND sent_at IS NOT NULL
                              AND sent_at >= DATE_SUB(NOW(), INTERVAL 24 HOUR)
                            ORDER BY sent_at DESC LIMIT 1");
        $rec = $r ? $r->fetch_assoc() : null;
    }
    if (!$rec) return;

    $cid = (int)$rec['campaign_id'];
    $rid = (int)$rec['id'];

    $conn->query("UPDATE wa_campaigns SET reply_count = reply_count + 1 WHERE id=$cid");
    wa_record_event($cid, $rid, 'replied');

    if ($isButtonTap) {
        $conn->query("UPDATE wa_campaign_recipients SET click_count = click_count + 1 WHERE id=$rid");
        $conn->query("UPDATE wa_campaigns SET click_count = click_count + 1 WHERE id=$cid");
        wa_record_event($cid, $rid, 'button_click');
    }
}

/**
 * Applies a Meta status webhook to a manual reply we sent from this inbox.
 *
 * Campaign messages are handled by webhook.php's own correlation pass; this one only ever
 * touches wa_messages, and returns false for an id it doesn't own so the two never fight over
 * the same row.
 */
function wa_apply_message_status(array $st): bool {
    global $conn;
    $id     = (string)($st['id'] ?? '');
    $status = strtolower((string)($st['status'] ?? ''));
    if ($id === '' || $status === '') return false;

    $r = $conn->query("SELECT id, status FROM wa_messages
                        WHERE wa_message_id='" . $conn->real_escape_string($id) . "' AND direction='out' LIMIT 1");
    $row = $r ? $r->fetch_assoc() : null;
    if (!$row) return false;

    // Same forward-only rule as the campaign path: WhatsApp does not order its webhooks, and a
    // late "delivered" must never demote a "read" that already landed.
    $rank = ['pending' => 0, 'sent' => 1, 'delivered' => 2, 'read' => 3];
    $mid  = (int)$row['id'];

    if ($status === 'failed') {
        $e = $st['errors'][0] ?? [];
        $msg = $e['error_data']['details'] ?? ($e['title'] ?? 'Failed');
        $conn->query("UPDATE wa_messages SET status='failed',
                             error_code='" . $conn->real_escape_string((string)($e['code'] ?? '')) . "',
                             error_message='" . $conn->real_escape_string(mb_substr((string)$msg, 0, 480)) . "'
                       WHERE id=$mid");
        return true;
    }
    if (!isset($rank[$status])) return false;
    if (($rank[$status] ?? 0) <= ($rank[$row['status']] ?? 0)) return false;

    $col = $status === 'read' ? ", read_at=NOW()" : ($status === 'delivered' ? ", delivered_at=NOW()" : '');
    $conn->query("UPDATE wa_messages SET status='$status'$col WHERE id=$mid");
    return true;
}

/* ── outbound ─────────────────────────────────────────────────────────────────────────── */

/** The sending number a conversation replies through: the one it arrived on, else the default. */
function wa_conversation_sender(array $conv): ?array {
    global $conn;
    if (!empty($conv['phone_number_id'])) {
        $r = $conn->query("SELECT * FROM wa_senders
                            WHERE phone_number_id='" . $conn->real_escape_string($conv['phone_number_id']) . "' LIMIT 1");
        $row = $r ? $r->fetch_assoc() : null;
        if ($row) return $row;
    }
    return wa_sender_by_id(isset($conv['sender_id']) ? (int)$conv['sender_id'] : null) ?: wa_default_sender();
}

/** Is the free-form window still open? Everything outside it must be a template. */
function wa_window_open(array $conv): bool {
    $exp = $conv['window_expires_at'] ?? null;
    return $exp !== null && strtotime((string)$exp) > time();
}

/**
 * Sends one free-form message and records it.
 *
 * @param array $content Meta's message object minus the envelope, e.g.
 *                       ['type'=>'text','text'=>['body'=>'hi']]
 * @return array{ok:bool, error:?string, message:?array}
 */
function wa_inbox_send(array $conv, array $content, array $local, ?int $sentBy): array {
    global $conn;

    $sender = wa_conversation_sender($conv);
    $token  = wa_meta_token();
    $pni    = trim((string)($sender['phone_number_id'] ?? ''));

    if ($token === '')  return ['ok' => false, 'error' => 'No Meta access token configured — add one in Settings.', 'message' => null];
    if ($pni === '')    return ['ok' => false, 'error' => 'This conversation has no sending number with a phone number ID.', 'message' => null];

    $payload = array_merge([
        'messaging_product' => 'whatsapp',
        'recipient_type'    => 'individual',
        'to'                => $conv['phone'],
    ], $content);

    $res = wa_graph_call('POST', WA_GRAPH_BASE . WA_GRAPH_VERSION . "/$pni/messages", $token, $payload);

    $now = date('Y-m-d H:i:s');
    $esc = fn($v) => $v === null || $v === '' ? 'NULL' : "'" . $GLOBALS['conn']->real_escape_string((string)$v) . "'";

    if (!$res['ok']) {
        $conn->query("INSERT INTO wa_messages
            (conversation_id, direction, msg_type, body, caption, media_id, media_mime, media_filename,
             template_name, status, error_code, error_message, sent_by, created_at)
            VALUES (" . (int)$conv['id'] . ", 'out', " . $esc($local['msg_type'] ?? 'text') . ", "
            . $esc($local['body'] ?? null) . ", " . $esc($local['caption'] ?? null) . ", "
            . $esc($local['media_id'] ?? null) . ", " . $esc($local['media_mime'] ?? null) . ", "
            . $esc($local['media_filename'] ?? null) . ", " . $esc($local['template_name'] ?? null) . ", "
            . "'failed', " . $esc($res['code']) . ", " . $esc(mb_substr((string)$res['error'], 0, 480)) . ", "
            . ($sentBy ? (int)$sentBy : 'NULL') . ", '$now')");
        return ['ok' => false, 'error' => $res['error'], 'message' => null];
    }

    $wamid = (string)($res['data']['messages'][0]['id'] ?? '');
    $conn->query("INSERT INTO wa_messages
        (conversation_id, direction, wa_message_id, msg_type, body, caption, media_id, media_mime,
         media_filename, local_path, template_name, status, sent_by, created_at)
        VALUES (" . (int)$conv['id'] . ", 'out', " . $esc($wamid) . ", " . $esc($local['msg_type'] ?? 'text') . ", "
        . $esc($local['body'] ?? null) . ", " . $esc($local['caption'] ?? null) . ", "
        . $esc($local['media_id'] ?? null) . ", " . $esc($local['media_mime'] ?? null) . ", "
        . $esc($local['media_filename'] ?? null) . ", " . $esc($local['local_path'] ?? null) . ", "
        . $esc($local['template_name'] ?? null) . ", 'sent', " . ($sentBy ? (int)$sentBy : 'NULL') . ", '$now')");

    $newId = (int)$conn->insert_id;
    wa_conversation_touch((int)$conv['id'], array_merge($local, ['created_at' => $now]), false);

    $r = $conn->query("SELECT * FROM wa_messages WHERE id=$newId LIMIT 1");
    return ['ok' => true, 'error' => null, 'message' => $r ? $r->fetch_assoc() : null];
}

/**
 * Tells WhatsApp the contact's messages have been seen, so THEY see the blue ticks.
 *
 * Best-effort by design: an admin opening a thread must not be blocked, or shown an error, over
 * a read receipt. A stale wamid (older than 30 days) is the normal failure and is uninteresting.
 */
function wa_mark_read_upstream(array $conv): void {
    global $conn;
    $sender = wa_conversation_sender($conv);
    $pni    = trim((string)($sender['phone_number_id'] ?? ''));
    $token  = wa_meta_token();
    if ($pni === '' || $token === '') return;

    $r = $conn->query("SELECT wa_message_id FROM wa_messages
                        WHERE conversation_id=" . (int)$conv['id'] . " AND direction='in' AND wa_message_id IS NOT NULL
                        ORDER BY id DESC LIMIT 1");
    $row = $r ? $r->fetch_assoc() : null;
    if (!$row) return;

    wa_graph_call('POST', WA_GRAPH_BASE . WA_GRAPH_VERSION . "/$pni/messages", $token, [
        'messaging_product' => 'whatsapp',
        'status'            => 'read',
        'message_id'        => $row['wa_message_id'],
    ], 8);
}

/* ── media ────────────────────────────────────────────────────────────────────────────── */

/** Ensures the cache directory exists and cannot be listed or executed over HTTP. */
function wa_media_dir(): string {
    if (!is_dir(WA_MEDIA_DIR)) @mkdir(WA_MEDIA_DIR, 0775, true);
    $ht = WA_MEDIA_DIR . '/.htaccess';
    if (!file_exists($ht)) @file_put_contents($ht, "Deny from all\n");
    return WA_MEDIA_DIR;
}

/**
 * Returns [absolute path, mime] for a message's media, downloading from Meta on first use.
 *
 * Two round trips are required and both need the token: GET /{media_id} returns a short-lived
 * (~5 min) signed URL, and that URL still refuses an unauthenticated fetch. The result is cached
 * because the download is the slow part and because Meta drops the media after 30 days — after
 * which our copy is the only one.
 *
 * @return array{0:?string,1:string,2:?string} path, mime, error
 */
function wa_media_fetch(array $msg): array {
    global $conn;

    $cached = trim((string)($msg['local_path'] ?? ''));
    if ($cached !== '') {
        $abs = wa_media_dir() . '/' . basename($cached);
        if (is_file($abs)) return [$abs, (string)($msg['media_mime'] ?: 'application/octet-stream'), null];
    }

    $mediaId = trim((string)($msg['media_id'] ?? ''));
    if ($mediaId === '') return [null, '', 'This message has no media'];

    $token = wa_meta_token();
    if ($token === '') return [null, '', 'No Meta access token configured'];

    $meta = wa_graph_call('GET', WA_GRAPH_BASE . WA_GRAPH_VERSION . '/' . rawurlencode($mediaId), $token, null, 15);
    if (!$meta['ok']) {
        return [null, '', 'Meta would not return this media: ' . $meta['error']
            . ' (media is deleted after ' . WA_MEDIA_RETENTION_DAYS . ' days)'];
    }

    $url  = (string)($meta['data']['url'] ?? '');
    $mime = (string)($meta['data']['mime_type'] ?? ($msg['media_mime'] ?: 'application/octet-stream'));
    if ($url === '') return [null, '', 'Meta returned no download URL'];

    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HTTPHEADER     => ['Authorization: Bearer ' . $token],
        CURLOPT_TIMEOUT        => 45,
        CURLOPT_FOLLOWLOCATION => true,
    ]);
    $bin    = curl_exec($ch);
    $status = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    if ($bin === false || $status < 200 || $status >= 300) return [null, '', "Download failed (HTTP $status)"];

    $ext  = wa_ext_for_mime($mime, (string)($msg['media_filename'] ?? ''));
    $name = 'wa_' . (int)$msg['id'] . '_' . substr(sha1($mediaId), 0, 10) . $ext;
    $abs  = wa_media_dir() . '/' . $name;
    if (@file_put_contents($abs, $bin) === false) {
        // Serving still works without a cache — only the next view pays for the download again.
        return [null, $mime, 'Could not write the media cache directory'];
    }

    $conn->query("UPDATE wa_messages SET local_path='" . $conn->real_escape_string($name) . "',
                         media_mime='" . $conn->real_escape_string($mime) . "',
                         media_size=" . strlen($bin) . "
                   WHERE id=" . (int)$msg['id']);
    return [$abs, $mime, null];
}

function wa_ext_for_mime(string $mime, string $filename = ''): string {
    $known = [
        'image/jpeg' => '.jpg', 'image/png' => '.png', 'image/webp' => '.webp', 'image/gif' => '.gif',
        'video/mp4' => '.mp4', 'video/3gpp' => '.3gp',
        'audio/ogg' => '.ogg', 'audio/mpeg' => '.mp3', 'audio/mp4' => '.m4a', 'audio/amr' => '.amr',
        'application/pdf' => '.pdf',
    ];
    $base = strtok($mime, ';');
    if (isset($known[$base])) return $known[$base];
    if ($filename !== '' && preg_match('/(\.[A-Za-z0-9]{1,6})$/', $filename, $m)) return strtolower($m[1]);
    return '.bin';
}

/**
 * Uploads a local file to Meta and returns its media id.
 *
 * Multipart, so it can't go through wa_graph_call() (JSON only). CURLFile is used rather than a
 * hand-built body because Meta rejects a mismatched boundary with an unhelpful generic error.
 *
 * @return array{ok:bool, id:?string, error:?string}
 */
function wa_graph_upload_media(string $phoneNumberId, string $path, string $mime, string $filename): array {
    $token = wa_meta_token();
    if ($token === '') return ['ok' => false, 'id' => null, 'error' => 'No Meta access token configured'];

    $ch = curl_init(WA_GRAPH_BASE . WA_GRAPH_VERSION . "/$phoneNumberId/media");
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST           => true,
        CURLOPT_HTTPHEADER     => ['Authorization: Bearer ' . $token],
        CURLOPT_TIMEOUT        => 120,
        CURLOPT_POSTFIELDS     => [
            'messaging_product' => 'whatsapp',
            'type'              => $mime,
            'file'              => new CURLFile($path, $mime, $filename),
        ],
    ]);
    $body   = curl_exec($ch);
    $status = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $err    = curl_error($ch);
    curl_close($ch);

    if ($err !== '') return ['ok' => false, 'id' => null, 'error' => "Upload failed: $err"];
    $decoded = json_decode((string)$body, true);
    if ($status < 200 || $status >= 300 || empty($decoded['id'])) {
        $e = $decoded['error'] ?? [];
        return ['ok' => false, 'id' => null, 'error' => $e['error_user_msg'] ?? ($e['message'] ?? "Upload failed (HTTP $status)")];
    }
    return ['ok' => true, 'id' => (string)$decoded['id'], 'error' => null];
}

/**
 * What WhatsApp accepts, per message type.
 *
 * The caps are Meta's own and are enforced here rather than left to the API: a rejected upload
 * costs a 120-second round trip and returns a generic error, while a local check is instant and
 * can say exactly which limit was hit.
 */
function wa_media_kind(string $mime): array {
    $mime = strtolower(strtok($mime, ';') ?: '');
    $sets = [
        'image'    => ['mimes' => ['image/jpeg', 'image/png'],                          'max' => 5  * 1024 * 1024],
        'video'    => ['mimes' => ['video/mp4', 'video/3gpp'],                          'max' => 16 * 1024 * 1024],
        'audio'    => ['mimes' => ['audio/aac', 'audio/mp4', 'audio/mpeg', 'audio/amr', 'audio/ogg'], 'max' => 16 * 1024 * 1024],
    ];
    foreach ($sets as $kind => $spec) {
        if (in_array($mime, $spec['mimes'], true)) return ['kind' => $kind, 'max' => $spec['max'], 'mime' => $mime];
    }
    // Everything else rides as a document, which is the broadest type WhatsApp accepts.
    return ['kind' => 'document', 'max' => 100 * 1024 * 1024, 'mime' => $mime ?: 'application/octet-stream'];
}

<?php
/*
 * /api/whatsapp/wa_inbox.php — the Live Chat inbox.
 *
 * Campaign endpoints are batch-shaped: build an audience, queue it, read a report. This one is
 * interactive, so every action is sized to be called repeatedly by a page that is open all day:
 *
 *   action=threads   &search &filter &page &per_page   list pane — one indexed SELECT, no joins
 *   action=thread    &id [&before] [&limit]            message history, newest-first, paginated
 *   action=poll      &conversation_id &after           the every-few-seconds delta (list + new msgs)
 *   action=profile   &id                               right pane: identity, campaigns, stats
 *   action=send      &id &text                         free-form text reply
 *   action=send_media &id [&caption]  + $_FILES[file]  upload to Meta, then send by media id
 *   action=send_template &id &template_id [&vars]      the only thing allowed outside 24 hours
 *   action=mark_read &id                               clears the badge, blue-ticks upstream
 *   action=set_status &id &status                      open / resolved
 *   action=archive   &id &archived
 *   action=media     &message_id                       streams (and caches) inbound media
 *
 * `media` is the one action that does not answer JSON — it streams bytes. It still runs behind
 * the same JWT check, which is why media is proxied through PHP at all instead of being written
 * somewhere the web server would serve directly: a customer's photo should not be a public URL
 * that happens to be hard to guess.
 */
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../middleware/auth.php';
require_once __DIR__ . '/lib/config.php';
require_once __DIR__ . '/lib/schema.php';
require_once __DIR__ . '/lib/WaHelpers.php';
require_once __DIR__ . '/lib/WaAudienceResolver.php';
require_once __DIR__ . '/lib/WaInbox.php';

whatsapp_ensure_schema();
wa_inbox_ensure_schema();

$jwt = require_jwt();
require_permission('netcore_behaviour', $jwt);

$ADMIN_ID = (int)($jwt['user_id'] ?? 0);

function jin($k, $d = null) { $v = $_REQUEST[$k] ?? null; return ($v === null || $v === '') ? $d : $v; }
function esc($v) { global $conn; return "'" . $conn->real_escape_string((string)$v) . "'"; }

/** The conversation named by ?id, or a 404 — every action below needs one. */
function require_conversation(): array {
    global $conn;
    $id = (int)jin('id', jin('conversation_id', 0));
    if ($id <= 0) api_error('Conversation id is required', 400);
    $r = $conn->query("SELECT * FROM wa_conversations WHERE id=$id LIMIT 1");
    $row = $r ? $r->fetch_assoc() : null;
    if (!$row) api_error('Conversation not found', 404);
    return $row;
}

/** Shapes one conversation row for the list pane. */
function thread_out(array $c): array {
    $name = trim(trim((string)$c['first_name'] . ' ' . (string)$c['last_name']));
    if ($name === '') $name = trim((string)$c['profile_name']);
    if ($name === '') $name = '+' . $c['phone'];
    $expires = $c['window_expires_at'] ?? null;
    return [
        'id'             => (int)$c['id'],
        'phone'          => $c['phone'],
        'name'           => $name,
        'profile_name'   => $c['profile_name'],
        'first_name'     => $c['first_name'],
        'last_name'      => $c['last_name'],
        'email'          => $c['email'],
        'user_id'        => $c['user_id'] !== null ? (int)$c['user_id'] : null,
        'last_message_at'        => $c['last_message_at'],
        'last_message_text'      => $c['last_message_text'],
        'last_message_direction' => $c['last_message_direction'],
        'last_message_type'      => $c['last_message_type'],
        'unread_count'   => (int)$c['unread_count'],
        'status'         => $c['status'],
        'is_archived'    => (int)$c['is_archived'],
        'window_expires_at' => $expires,
        // Computed here rather than in the browser: the server clock is the one the 24-hour
        // rule is actually enforced against, and a device with a skewed clock would otherwise
        // show an open composer for a window Meta has already closed.
        'window_open'    => $expires !== null && strtotime((string)$expires) > time(),
        'window_seconds_left' => $expires !== null ? max(0, strtotime((string)$expires) - time()) : 0,
        'origin_campaign_id'  => $c['origin_campaign_id'] !== null ? (int)$c['origin_campaign_id'] : null,
    ];
}

$action = jin('action', 'threads');

/* ── list pane ────────────────────────────────────────────────────────────────────────── */

if ($action === 'threads' || $action === 'poll') {
    $search  = trim((string)jin('search', ''));
    $filter  = (string)jin('filter', 'all');
    $perPage = min(100, max(10, (int)jin('per_page', 40)));
    $page    = max(1, (int)jin('page', 1));

    $where = ["is_archived = " . ($filter === 'archived' ? '1' : '0')];
    if ($filter === 'unread')   $where[] = 'unread_count > 0';
    if ($filter === 'open')     $where[] = "status = 'open'";
    if ($filter === 'resolved') $where[] = "status = 'resolved'";
    if ($search !== '') {
        $s = $conn->real_escape_string($search);
        $where[] = "(phone LIKE '%$s%' OR profile_name LIKE '%$s%' OR email LIKE '%$s%'
                     OR CONCAT_WS(' ', first_name, last_name) LIKE '%$s%')";
    }
    $w = implode(' AND ', $where);

    $offset = ($page - 1) * $perPage;
    $r = $conn->query("SELECT * FROM wa_conversations WHERE $w
                        ORDER BY last_message_at IS NULL, last_message_at DESC, id DESC
                        LIMIT $perPage OFFSET $offset");
    $threads = [];
    while ($r && $row = $r->fetch_assoc()) $threads[] = thread_out($row);

    $tot = $conn->query("SELECT COUNT(*) c, COALESCE(SUM(unread_count > 0), 0) u FROM wa_conversations WHERE is_archived = 0");
    $totRow = $tot ? $tot->fetch_assoc() : ['c' => 0, 'u' => 0];

    $payload = [
        'threads'        => $threads,
        'total'          => (int)$totRow['c'],
        'unread_threads' => (int)$totRow['u'],
        'page'           => $page,
        'per_page'       => $perPage,
        'server_time'    => date('Y-m-d H:i:s'),
    ];

    /*
     * Poll folds the open thread's new messages into the same response. Two requests every few
     * seconds, per open tab, is how a page like this quietly becomes the busiest endpoint on the
     * server; one is half that and keeps list and thread consistent with each other.
     */
    if ($action === 'poll') {
        $cid   = (int)jin('conversation_id', 0);
        $after = (string)jin('after', '');
        $payload['messages'] = ($cid > 0 && $after !== '')
            ? wa_thread_messages($cid, null, 60, $after)
            : [];
    }

    api_success($payload);
}

/* ── message history ──────────────────────────────────────────────────────────────────── */

/**
 * One conversation's messages, newest last.
 *
 * Campaign sends are NOT copied into wa_messages — they are read straight out of
 * wa_campaign_recipients and merged here. That keeps a single copy of every campaign message
 * (its delivered/read state stays the campaign's own, so the thread and the campaign report can
 * never disagree) and means an admin sees the exact template that prompted the reply they're
 * looking at.
 *
 * @param ?string $before  fetch messages older than this timestamp (paging backwards)
 * @param ?string $after   fetch messages newer than this timestamp (polling forwards)
 */
function wa_thread_messages(int $conversationId, ?string $before, int $limit, ?string $after = null): array {
    global $conn;

    $cr = $conn->query("SELECT phone FROM wa_conversations WHERE id=$conversationId LIMIT 1");
    $conv = $cr ? $cr->fetch_assoc() : null;
    if (!$conv) return [];
    $phone = $conn->real_escape_string($conv['phone']);

    $mWhere = ["conversation_id = $conversationId"];
    $cWhere = ["r.phone = '$phone'", '(r.sent_at IS NOT NULL OR r.failed_at IS NOT NULL)'];
    if ($before !== null && $before !== '') {
        $b = $conn->real_escape_string($before);
        $mWhere[] = "created_at < '$b'";
        $cWhere[] = "COALESCE(r.sent_at, r.failed_at) < '$b'";
    }
    if ($after !== null && $after !== '') {
        /*
         * >= not >, deliberately. MySQL DATETIME has one-second resolution, so two messages in
         * the same second share a timestamp — a strict > would silently drop the second one
         * forever, since the cursor has already moved past it. The overlap re-sends at most the
         * message the client already has, and the view de-duplicates by key.
         */
        $a = $conn->real_escape_string($after);
        $mWhere[] = "created_at >= '$a'";
        $cWhere[] = "COALESCE(r.sent_at, r.failed_at) >= '$a'";
    }
    $mw = implode(' AND ', $mWhere);
    $cw = implode(' AND ', $cWhere);

    $sql = "SELECT * FROM (
        SELECT 'm' AS src, m.id AS row_id, m.direction, m.wa_message_id, m.msg_type, m.body, m.caption,
               m.media_id, m.media_mime, m.media_filename, m.media_size, m.local_path,
               m.template_name, m.context_wamid, m.status, m.error_code, m.error_message,
               m.created_at, NULL AS campaign_id, NULL AS campaign_name, 0 AS click_count
          FROM wa_messages m WHERE $mw
        UNION ALL
        SELECT 'c' AS src, r.id AS row_id, 'out' AS direction, r.wa_message_id, 'template' AS msg_type,
               r.rendered_body AS body, NULL AS caption,
               NULL AS media_id, NULL AS media_mime, NULL AS media_filename, NULL AS media_size, NULL AS local_path,
               c.template_name, NULL AS context_wamid, r.status, r.error_code, r.error_message,
               COALESCE(r.sent_at, r.failed_at) AS created_at, r.campaign_id, c.name AS campaign_name, r.click_count
          FROM wa_campaign_recipients r
          JOIN wa_campaigns c ON c.id = r.campaign_id
         WHERE $cw
    ) t ORDER BY t.created_at DESC, t.row_id DESC LIMIT " . (int)$limit;

    $r = $conn->query($sql);
    $rows = [];
    while ($r && $row = $r->fetch_assoc()) {
        $rows[] = [
            'key'        => $row['src'] . '-' . $row['row_id'],
            'src'        => $row['src'],
            'id'         => (int)$row['row_id'],
            'direction'  => $row['direction'],
            'type'       => $row['msg_type'],
            'body'       => $row['body'],
            'caption'    => $row['caption'],
            'has_media'  => !empty($row['media_id']) || !empty($row['local_path']),
            'media_mime' => $row['media_mime'],
            'media_filename' => $row['media_filename'],
            'media_size' => $row['media_size'] !== null ? (int)$row['media_size'] : null,
            'template_name' => $row['template_name'],
            'status'     => $row['status'],
            'error_code' => $row['error_code'],
            'error'      => $row['error_message'],
            'created_at' => $row['created_at'],
            'campaign_id'   => $row['campaign_id'] !== null ? (int)$row['campaign_id'] : null,
            'campaign_name' => $row['campaign_name'],
            'click_count'   => (int)$row['click_count'],
        ];
    }
    // Fetched newest-first so LIMIT takes the RECENT end; the view wants oldest-first.
    return array_reverse($rows);
}

if ($action === 'thread') {
    $conv   = require_conversation();
    $limit  = min(200, max(10, (int)jin('limit', 60)));
    $before = jin('before', null);
    $msgs   = wa_thread_messages((int)$conv['id'], $before, $limit);

    api_success([
        'conversation' => thread_out($conv),
        'messages'     => $msgs,
        // A short page means we hit the start of the conversation, so the view can stop asking.
        'has_more'     => count($msgs) >= $limit,
        'server_time'  => date('Y-m-d H:i:s'),
    ]);
}

/* ── right pane ───────────────────────────────────────────────────────────────────────── */

if ($action === 'profile') {
    $conv  = require_conversation();
    $phone = $conn->real_escape_string($conv['phone']);

    // Every campaign this number has been part of, with the per-recipient outcome — this is the
    // "which campaign is this person replying about" answer the right pane exists to give.
    $r = $conn->query("SELECT r.id, r.campaign_id, r.status, r.click_count, r.sent_at, r.delivered_at,
                              r.read_at, r.failed_at, r.error_message, r.is_test,
                              c.name AS campaign_name, c.template_name, c.template_category, c.status AS campaign_status
                         FROM wa_campaign_recipients r
                         JOIN wa_campaigns c ON c.id = r.campaign_id
                        WHERE r.phone='$phone'
                        ORDER BY COALESCE(r.sent_at, r.queued_at) DESC
                        LIMIT 50");
    $campaigns = [];
    while ($r && $row = $r->fetch_assoc()) {
        $campaigns[] = [
            'recipient_id'  => (int)$row['id'],
            'campaign_id'   => (int)$row['campaign_id'],
            'campaign_name' => $row['campaign_name'],
            'campaign_status' => $row['campaign_status'],
            'template_name' => $row['template_name'],
            'category'      => $row['template_category'],
            'status'        => $row['status'],
            'clicks'        => (int)$row['click_count'],
            'is_test'       => (int)$row['is_test'],
            'sent_at'       => $row['sent_at'],
            'delivered_at'  => $row['delivered_at'],
            'read_at'       => $row['read_at'],
            'failed_at'     => $row['failed_at'],
            'error'         => $row['error_message'],
        ];
    }

    $s = $conn->query("SELECT COUNT(*) total,
                              SUM(status IN ('sent','delivered','read')) sent,
                              SUM(status IN ('delivered','read')) delivered,
                              SUM(status = 'read') `read`,
                              SUM(status = 'failed') failed,
                              COALESCE(SUM(click_count),0) clicks
                         FROM wa_campaign_recipients WHERE phone='$phone'");
    $stats = $s ? $s->fetch_assoc() : [];

    $m = $conn->query("SELECT SUM(direction='in') inbound, SUM(direction='out') outbound
                         FROM wa_messages WHERE conversation_id=" . (int)$conv['id']);
    $mstats = $m ? $m->fetch_assoc() : [];

    $o = $conn->query("SELECT status, updated_at FROM wa_optins WHERE phone='$phone' LIMIT 1");
    $optin = $o ? $o->fetch_assoc() : null;

    $sender = wa_conversation_sender($conv);

    api_success([
        'conversation' => thread_out($conv),
        'campaigns'    => $campaigns,
        'stats'        => [
            'campaigns_received' => (int)($stats['total'] ?? 0),
            'sent'      => (int)($stats['sent'] ?? 0),
            'delivered' => (int)($stats['delivered'] ?? 0),
            'read'      => (int)($stats['read'] ?? 0),
            'failed'    => (int)($stats['failed'] ?? 0),
            'clicks'    => (int)($stats['clicks'] ?? 0),
            'inbound_messages'  => (int)($mstats['inbound'] ?? 0),
            'outbound_messages' => (int)($mstats['outbound'] ?? 0),
        ],
        'optin' => $optin ? ['status' => $optin['status'], 'updated_at' => $optin['updated_at']] : null,
        'sender' => $sender ? [
            'id' => (int)$sender['id'],
            'business_number' => $sender['business_number'],
            'display_name'    => $sender['display_name'],
            'phone_number_id' => $sender['phone_number_id'],
        ] : null,
        'note' => $conv['note'],
    ]);
}

/* ── sending ──────────────────────────────────────────────────────────────────────────── */

if ($action === 'send') {
    $conv = require_conversation();
    $text = trim((string)jin('text', ''));
    if ($text === '') api_error('Message is empty', 400);
    if (mb_strlen($text) > 4096) api_error('WhatsApp text messages are limited to 4096 characters', 400);

    // Checked here as well as in the UI: the composer can be stale by the time Send is pressed,
    // and Meta's own rejection for this ("#131047 Re-engagement message") reads like a bug
    // rather than an explanation.
    if (!wa_window_open($conv)) {
        api_error('The 24-hour reply window has closed for this contact. Send an approved template instead.', 409);
    }

    $res = wa_inbox_send(
        $conv,
        ['type' => 'text', 'text' => ['preview_url' => (bool)preg_match('~https?://~i', $text), 'body' => $text]],
        ['msg_type' => 'text', 'body' => $text],
        $GLOBALS['ADMIN_ID']
    );
    if (!$res['ok']) api_error($res['error'] ?: 'Could not send', 502);
    api_success(['message' => $res['message']], 'Sent');
}

if ($action === 'send_media') {
    $conv = require_conversation();
    if (!wa_window_open($conv)) {
        api_error('The 24-hour reply window has closed for this contact. Send an approved template instead.', 409);
    }

    $f = $_FILES['file'] ?? null;
    if (!$f || ($f['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
        $codes = [
            UPLOAD_ERR_INI_SIZE   => 'The file is larger than this server accepts (upload_max_filesize)',
            UPLOAD_ERR_FORM_SIZE  => 'The file is too large',
            UPLOAD_ERR_PARTIAL    => 'The upload was interrupted',
            UPLOAD_ERR_NO_FILE    => 'No file was attached',
            UPLOAD_ERR_NO_TMP_DIR => 'The server has no temp directory configured',
            UPLOAD_ERR_CANT_WRITE => 'The server could not write the upload',
        ];
        api_error($codes[$f['error'] ?? UPLOAD_ERR_NO_FILE] ?? 'Upload failed', 400);
    }

    $tmp      = $f['tmp_name'];
    $filename = preg_replace('/[^\w. \-()]+/u', '_', (string)$f['name']);
    $size     = (int)$f['size'];

    // finfo over the browser-supplied type: the client's Content-Type is a hint, and Meta
    // rejects a mismatch between the declared type and the actual bytes.
    $mime = (string)($f['type'] ?? '');
    if (function_exists('finfo_open')) {
        $fi = finfo_open(FILEINFO_MIME_TYPE);
        if ($fi) { $detected = finfo_file($fi, $tmp); finfo_close($fi); if ($detected) $mime = $detected; }
    }

    $spec = wa_media_kind($mime);
    if ($size > $spec['max']) {
        api_error('WhatsApp limits ' . $spec['kind'] . ' to ' . round($spec['max'] / 1048576) . ' MB — this file is '
            . round($size / 1048576, 1) . ' MB', 400);
    }

    $sender = wa_conversation_sender($conv);
    $pni    = trim((string)($sender['phone_number_id'] ?? ''));
    if ($pni === '') api_error('This conversation has no sending number with a phone number ID', 400);

    $up = wa_graph_upload_media($pni, $tmp, $spec['mime'], $filename);
    if (!$up['ok']) api_error($up['error'] ?: 'Could not upload the file to Meta', 502);

    $caption = trim((string)jin('caption', ''));
    $kind    = $spec['kind'];

    $node = ['id' => $up['id']];
    // Only image, video and document carry a caption; audio does not, and sending one is an error.
    if ($caption !== '' && in_array($kind, ['image', 'video', 'document'], true)) $node['caption'] = $caption;
    if ($kind === 'document') $node['filename'] = $filename;

    // Keep our own copy: Meta drops uploaded media after 30 days, and a thread that loses its
    // attachments is a thread you can no longer audit.
    $localName = null;
    $ext = wa_ext_for_mime($spec['mime'], $filename);
    $cand = 'out_' . time() . '_' . substr(sha1($filename . $up['id']), 0, 10) . $ext;
    if (@copy($tmp, wa_media_dir() . '/' . $cand)) $localName = $cand;

    $res = wa_inbox_send($conv, [ 'type' => $kind, $kind => $node ], [
        'msg_type'       => $kind,
        'caption'        => $caption,
        'media_id'       => $up['id'],
        'media_mime'     => $spec['mime'],
        'media_filename' => $filename,
        'local_path'     => $localName,
    ], $GLOBALS['ADMIN_ID']);

    if (!$res['ok']) api_error($res['error'] ?: 'Could not send', 502);
    api_success(['message' => $res['message']], 'Sent');
}

if ($action === 'send_template') {
    $conv = require_conversation();
    $tid  = (int)jin('template_id', 0);
    if ($tid <= 0) api_error('Pick a template', 400);

    $r = $conn->query("SELECT * FROM wa_templates WHERE id=$tid LIMIT 1");
    $tpl = $r ? $r->fetch_assoc() : null;
    if (!$tpl) api_error('Template not found', 404);
    if ($tpl['approval_status'] !== 'approved') {
        api_error('WhatsApp only delivers templates Meta has approved — this one is ' . $tpl['approval_status'], 400);
    }

    // Positional variable values, in template order: vars[]=Rahul&vars[]=iCAT 174
    $vars = $_REQUEST['vars'] ?? [];
    if (is_string($vars)) $vars = json_decode($vars, true) ?: [$vars];
    $vars = array_values(array_map('strval', (array)$vars));

    require_once __DIR__ . '/lib/MetaCloudTransport.php';
    $headerVars = wa_placeholder_count((string)($tpl['header_text'] ?? ''));
    $components = meta_build_components($tpl, [
        'header' => array_slice($vars, 0, $headerVars),
        'body'   => array_slice($vars, $headerVars),
        'button_url_suffix' => (string)jin('button_url_suffix', ''),
    ]);

    $template = ['name' => $tpl['name'], 'language' => ['code' => $tpl['language']]];
    if ($components) $template['components'] = $components;

    // The preview stored on the message is the filled-in body, not the raw {{1}} form — the
    // thread has to show what the contact actually received.
    $rendered = wa_fill_placeholders((string)$tpl['body_text'], array_slice($vars, $headerVars));

    $res = wa_inbox_send($conv, ['type' => 'template', 'template' => $template], [
        'msg_type'      => 'template',
        'body'          => $rendered,
        'template_name' => $tpl['name'],
    ], $GLOBALS['ADMIN_ID']);

    if (!$res['ok']) api_error($res['error'] ?: 'Could not send', 502);
    api_success(['message' => $res['message']], 'Template sent');
}

/* ── thread state ─────────────────────────────────────────────────────────────────────── */

if ($action === 'mark_read') {
    $conv = require_conversation();
    $conn->query("UPDATE wa_conversations SET unread_count = 0 WHERE id=" . (int)$conv['id']);
    wa_mark_read_upstream($conv);
    api_success([], 'Marked read');
}

if ($action === 'set_status') {
    $conv   = require_conversation();
    $status = jin('status', 'open') === 'resolved' ? 'resolved' : 'open';
    $conn->query("UPDATE wa_conversations SET status='$status' WHERE id=" . (int)$conv['id']);
    api_success(['status' => $status], $status === 'resolved' ? 'Marked resolved' : 'Reopened');
}

if ($action === 'archive') {
    $conv = require_conversation();
    $on   = (int)jin('archived', 1) ? 1 : 0;
    $conn->query("UPDATE wa_conversations SET is_archived=$on WHERE id=" . (int)$conv['id']);
    api_success(['is_archived' => $on], $on ? 'Archived' : 'Restored');
}

if ($action === 'save_note') {
    $conv = require_conversation();
    $note = mb_substr(trim((string)jin('note', '')), 0, 1000);
    $conn->query("UPDATE wa_conversations SET note=" . esc($note) . ' WHERE id=' . (int)$conv['id']);
    api_success(['note' => $note], 'Note saved');
}

/* ── media streaming ──────────────────────────────────────────────────────────────────── */

if ($action === 'media') {
    $mid = (int)jin('message_id', 0);
    if ($mid <= 0) api_error('message_id is required', 400);

    $r = $conn->query("SELECT * FROM wa_messages WHERE id=$mid LIMIT 1");
    $msg = $r ? $r->fetch_assoc() : null;
    if (!$msg) api_error('Message not found', 404);

    [$path, $mime, $err] = wa_media_fetch($msg);
    if ($path === null) api_error($err ?: 'Media unavailable', 404);

    // Streamed rather than echoed: a 16 MB video read into a PHP string would blow past
    // memory_limit on a shared host.
    $disposition = str_starts_with((string)$mime, 'image/') || str_starts_with((string)$mime, 'video/')
        || str_starts_with((string)$mime, 'audio/') ? 'inline' : 'attachment';
    $name = $msg['media_filename'] ?: basename($path);

    header('Content-Type: ' . $mime);
    header('Content-Length: ' . filesize($path));
    header('Content-Disposition: ' . $disposition . '; filename="' . addslashes($name) . '"');
    header('Cache-Control: private, max-age=86400');
    readfile($path);
    exit;
}

/* ── manual thread creation ───────────────────────────────────────────────────────────── */

/*
 * Starting a conversation with a number that has never written to us. Only useful with a
 * template (the window is closed by definition), which is why the thread opens empty and the
 * composer shows the template picker.
 */
if ($action === 'open_thread') {
    $raw   = trim((string)jin('phone', ''));
    $phone = wa_normalize_phone($raw, wa_default_cc());
    if ($phone === null) api_error('That does not look like a valid phone number', 400);

    $sender = wa_sender_by_id((int)jin('sender_id', 0)) ?: wa_default_sender();
    if (!$sender || trim((string)$sender['phone_number_id']) === '') {
        api_error('No sending number is configured — add one in Settings first', 400);
    }

    $conv = wa_conversation_upsert($phone, (string)$sender['phone_number_id'], null);
    if (!$conv) api_error('Could not open a conversation', 500);
    api_success(['conversation' => thread_out($conv)]);
}

if ($action === 'templates') {
    // The approved templates the composer offers once the window has closed.
    $r = $conn->query("SELECT id, name, display_name, language, category, header_type, header_text,
                              body_text, footer_text, buttons
                         FROM wa_templates
                        WHERE status='active' AND approval_status='approved'
                        ORDER BY name ASC");
    $out = [];
    while ($r && $row = $r->fetch_assoc()) {
        $row['id'] = (int)$row['id'];
        $row['buttons'] = json_decode((string)$row['buttons'], true) ?: [];
        $row['header_vars'] = wa_placeholder_count((string)$row['header_text']);
        $row['body_vars']   = wa_placeholder_count((string)$row['body_text']);
        $out[] = $row;
    }
    api_success(['templates' => $out]);
}

api_error('Invalid action', 400);

<?php
/*
 * /api/whatsapp/click.php — "this person tapped the WhatsApp button", reported by the platform
 * they landed on.
 *
 * The companion to the XX_WA_ATTR_XX token. When a template button is approved as
 *
 *     https://dashboard.internshipstudio.com/login?{{1}}
 *
 * the tap goes STRAIGHT to your platform — nothing passes through this panel, so the Clicked
 * column would stay at zero even though the click plainly happened. This endpoint is how the
 * landing page hands that fact back.
 *
 *     POST /api/whatsapp/click.php
 *     wa_rid=<the wa_rid on the landing URL>          ← preferred: exact, unambiguous
 *   or campaign_id=<id>&phone=<the phone on the URL>  ← fallback when rid wasn't captured
 *
 * Call it once, server-side, when the landing page sees campaign_id + medium=whatsapp on the
 * query string. It is safe to call more than once — click_count counts every tap, while
 * first_clicked_at (which anchors the attribution window) is written only the first time.
 *
 * WHY IT ISN'T BEHIND THE ADMIN JWT
 * The caller is your dashboard, not an admin session, and it has no admin token to present. The
 * shared secret below is what authenticates it. Note also what the worst case actually is: the
 * rid is a 128-bit random value tied to one recipient row, so a forged call can add a click to a
 * campaign and nothing else — it writes no other field, returns no data, and cannot enumerate.
 */
ini_set('display_errors', 0);
error_reporting(E_ALL & ~E_WARNING & ~E_NOTICE & ~E_DEPRECATED);
header('Content-Type: application/json');

/*
 * CORS, because the natural caller is the landing page's own JavaScript on a DIFFERENT host
 * (dashboard.internshipstudio.com calling cit3.internshipstudio.com). Restricted to this
 * business's own origins rather than '*' — there is no reason for any other site to reach this.
 */
$origin = $_SERVER['HTTP_ORIGIN'] ?? '';
if ($origin !== '' && preg_match('~^https?://([a-z0-9-]+\.)*internshipstudio\.com$~i', $origin)) {
    header('Access-Control-Allow-Origin: ' . $origin);
    header('Vary: Origin');
    header('Access-Control-Allow-Headers: Content-Type, X-WA-Secret');
    header('Access-Control-Allow-Methods: POST, OPTIONS');
}
// Preflight: answer and stop, before touching the database.
if (($_SERVER['REQUEST_METHOD'] ?? '') === 'OPTIONS') { http_response_code(204); exit; }

require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/lib/config.php';
require_once __DIR__ . '/lib/schema.php';
require_once __DIR__ . '/lib/WaAudienceResolver.php';

whatsapp_ensure_schema();

function click_out(bool $ok, string $message, array $extra = []): void {
    echo json_encode(array_merge(['success' => $ok, 'message' => $message], $extra));
    exit;
}

$rid        = trim((string)($_REQUEST['wa_rid'] ?? ''));
$hasRid     = (bool)preg_match('/^[a-f0-9]{32}$/i', $rid);
$secret     = $_SERVER['HTTP_X_WA_SECRET'] ?? ($_REQUEST['secret'] ?? '');
$hasSecret  = hash_equals(WA_CRON_SECRET, (string)$secret);

/*
 * EITHER credential is enough, and that is deliberate.
 *
 * Requiring the shared secret alone would force this to be called server-side, because putting it
 * in browser JavaScript publishes it — and the caller here IS a browser: the visitor lands on the
 * page and the page reports the click. Demanding a server-to-server hop for a click counter would
 * mean most integrations simply never do it.
 *
 * So a valid wa_rid is accepted on its own. It is a 128-bit random value that identifies exactly
 * one recipient row and appears only in that person's own message, which makes it a per-click
 * capability token. The worst a holder can do is re-report their own click: click_count on their
 * row rises, first_clicked_at does not move, and nothing else is written or readable. That is a
 * fair trade for an integration that is one fetch() call.
 *
 * The shared secret still works, for a server-side caller that would rather not pass the rid.
 */
if (!$hasRid && !$hasSecret) {
    http_response_code(403);
    click_out(false, 'Send wa_rid (from the landing URL), or the X-WA-Secret header');
}

$campaignId = (int)($_REQUEST['campaign_id'] ?? 0);
$phoneRaw   = trim((string)($_REQUEST['phone'] ?? ''));

$rec = null;

// Preferred path: the rid identifies exactly one recipient row, so there is nothing to resolve.
if ($hasRid) {
    $r = $conn->query("SELECT id, campaign_id, first_clicked_at FROM wa_campaign_recipients
                        WHERE rid = '" . $conn->real_escape_string($rid) . "' LIMIT 1");
    $rec = $r ? $r->fetch_assoc() : null;
}

/*
 * Fallback: campaign + phone. Scoped to the campaign on purpose — a bare phone number would
 * otherwise credit whichever campaign happened to be most recent, and the landing URL always
 * carries campaign_id anyway.
 */
if (!$rec && $campaignId > 0 && $phoneRaw !== '') {
    $phone = wa_normalize_phone($phoneRaw, wa_default_cc());
    if ($phone !== null) {
        $r = $conn->query("SELECT id, campaign_id, first_clicked_at FROM wa_campaign_recipients
                            WHERE campaign_id = $campaignId
                              AND phone = '" . $conn->real_escape_string($phone) . "'
                              AND is_test = 0 LIMIT 1");
        $rec = $r ? $r->fetch_assoc() : null;
    }
}

/*
 * Not a campaign recipient — the tap may belong to a Journey step. Journey WhatsApp sends
 * carry their own rid in journey_messages and go out through this same template/attribution
 * plumbing, so the landing page reports them here with no way of knowing which feature sent
 * the message. Without this the tap was answered "no matching recipient" and the journey's
 * Clicked column stayed at zero — and, because first_clicked_at anchors last-click
 * attribution, its conversions could never be credited either.
 *
 * file_exists-guarded: this backend deploys folder by folder and a require of a file that is
 * not uploaded yet is fatal.
 */
if (!$rec && ($hasRid || ($campaignId > 0 && $phoneRaw !== ''))) {
    $sink = __DIR__ . '/../journeys/lib/JourneyWebhookSink.php';
    if (file_exists($sink)) {
        require_once $sink;
        // The rid first, always — it names one message and cannot be wrong. The phone is only
        // consulted when the rid resolved to nothing, and only in the journey's offset id range.
        if ($hasRid && journey_webhook_wa_click(strtolower($rid))) {
            click_out(true, 'Click recorded against a journey message', ['journey' => true]);
        }
        if ($campaignId > 0 && $phoneRaw !== '' && journey_wa_click_by_phone($campaignId, $phoneRaw)) {
            click_out(true, 'Click recorded against a journey message', ['journey' => true, 'by' => 'phone']);
        }
    }
}

if (!$rec) click_out(false, 'No matching recipient — send wa_rid, or campaign_id plus phone');

$recipientId = (int)$rec['id'];
$cid         = (int)$rec['campaign_id'];
$isFirst     = empty($rec['first_clicked_at']);

/*
 * Every tap counts toward click_count — five taps is five taps, and that is a real engagement
 * signal. first_clicked_at is written ONCE because it anchors the attribution window: letting a
 * later tap move it would silently extend that window on every revisit.
 */
$conn->query("UPDATE wa_campaign_recipients
                 SET click_count = click_count + 1,
                     first_clicked_at = COALESCE(first_clicked_at, NOW())
               WHERE id = $recipientId");
$conn->query("UPDATE wa_campaigns SET click_count = click_count + 1 WHERE id = $cid");

// Only the first tap becomes a timeline event; the rest are in the counter already and would
// otherwise bury every other event in the report.
if ($isFirst) {
    $conn->query("INSERT INTO wa_campaign_events (campaign_id, recipient_id, event_type, detail)
                  VALUES ($cid, $recipientId, 'button_click', 'WhatsApp button tap (reported by the landing page)')");
}

click_out(true, 'Click recorded', [
    'campaign_id'  => $cid,
    'recipient_id' => $recipientId,
    'first_click'  => $isFirst,
]);

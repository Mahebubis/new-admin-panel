<?php
/**
 * sim_admin_api.php
 * ---------------------------------------------------------------------------
 * SINGLE-FILE admin API for the Internship Simulation.
 * Lives in react-api/api/internship-system/ and bootstraps via the shared
 * helper.php (provides global $conn), like the other endpoints in this folder.
 * Access is gated by the React admin panel's permission system, not here.
 *
 * Routes:
 *   GET  ?resource=domains
 *   GET  ?resource=tasks&action=list&internship_id=ID
 *   POST ?resource=tasks&action=create|update|delete|toggle
 *   GET  ?resource=fields&action=list&task_id=ID
 *   POST ?resource=fields&action=create|update|delete|toggle|reorder
 *
 * Responses: { "status":"success", "data":{...} } or { "status":"error", ... }
 *
 * Requires the sim_tasks / sim_task_fields tables (see sim_schema.sql).
 * ---------------------------------------------------------------------------
 */

/* keep the body clean JSON even if the shared bootstrap emits warnings */
@ini_set('display_errors', '0');
error_reporting(E_ALL);

/* ---------------------------------------------------------------------------
   ERROR LOGGING — every error/warning/notice/exception is written to
   sim_admin_api_errors.log in THIS same directory.
   --------------------------------------------------------------------------- */
define('SIM_LOG_FILE', __DIR__ . '/sim_admin_api_errors.log');
@ini_set('log_errors', '1');
@ini_set('error_log', SIM_LOG_FILE);

function sim_log($label, $msg) {
    $line = '[' . date('Y-m-d H:i:s') . '] ' . $label . ': ' . $msg
          . '  {' . ($_SERVER['REQUEST_METHOD'] ?? 'CLI') . ' '
          . ($_SERVER['REQUEST_URI'] ?? '') . '}' . PHP_EOL;
    @file_put_contents(SIM_LOG_FILE, $line, FILE_APPEND | LOCK_EX);
}

/* warnings / notices — logged only when they originate from THIS file.
   The shared helper.php bootstrap emits its own notices we can't fix here. */
set_error_handler(function ($no, $str, $file, $line) {
    if (strpos($file, 'sim_admin_api.php') !== false) {
        sim_log('PHP-ERROR(' . $no . ')', $str . ' in ' . $file . ':' . $line);
    }
    return true; /* handled — suppress PHP's default output/logging */
});

/* shared bootstrap — same as the other internship-system endpoints.
   helper.php provides the mysqli connection as global $conn. */
ob_start();
chdir('/home/istudio/public_html/cit/common');
include '/home/istudio/public_html/cit/common/helper.php';
ob_clean();

header('Content-Type: application/json');

register_shutdown_function(function () {
    $e = error_get_last();
    if ($e && in_array($e['type'], [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR], true)) {
        sim_log('FATAL', $e['message'] . ' in ' . $e['file'] . ':' . $e['line']);
        if (!headers_sent()) header('Content-Type: application/json');
        echo json_encode(['status' => 'error', 'message' => 'Server error: ' . $e['message']]);
    }
});

/* any uncaught exception (e.g. a mysqli error) -> clean JSON, never a blank page */
set_exception_handler(function ($e) {
    sim_log('EXCEPTION', get_class($e) . ': ' . $e->getMessage()
        . ' in ' . $e->getFile() . ':' . $e->getLine()
        . PHP_EOL . $e->getTraceAsString());
    if (!headers_sent()) {
        http_response_code(500);
        header('Content-Type: application/json');
    }
    echo json_encode(['status' => 'error', 'message' => 'Server error: ' . $e->getMessage()]);
    exit;
});

/* ====== helpers ====== */
function sim_out($p) { echo json_encode($p); exit; }
function sim_error($m, $c = 400) {
    sim_log('API-ERROR(' . $c . ')', $m);
    http_response_code($c);
    sim_out(['status' => 'error', 'message' => $m]);
}
function sim_ok($d = null, $m = '') {
    $r = ['status' => 'success'];
    if ($m !== '') $r['message'] = $m;
    if ($d !== null) $r['data'] = $d;
    sim_out($r);
}
function sim_input() {
    $i = $_POST;
    if (empty($i)) {
        $j = json_decode(file_get_contents('php://input'), true);
        if (is_array($j)) $i = $j;
    }
    return $i;
}
function sim_json_decode($s) {
    if ($s === null || $s === '') return [];
    $d = json_decode($s, true);
    return is_array($d) ? $d : [];
}
function sim_json_col($v) {
    if ($v === null || $v === '') return null;
    if (is_array($v)) return json_encode(array_values($v));
    $d = json_decode($v, true);
    return is_array($d) ? json_encode($d) : json_encode([$v]);
}
function sim_num($v) {
    if ($v === null || $v === '' || !is_numeric($v)) return null;
    return (float)$v;
}

/* ====== db ====== */
/* $conn is provided by helper.php (included above). */
global $conn;
if (!$conn) sim_error('Database connection failed', 500);

/* No per-request auth gate here — access is controlled by the React admin
   panel's permission system (route is permission-gated), consistent with the
   other endpoints in this internship-system folder. $user_id is recorded as
   created_by when available. */
$user_id = (int)($_SESSION['user_id'] ?? 0);

$resource = $_GET['resource'] ?? '';
$action   = $_GET['action'] ?? '';
$in       = sim_input();

$ALLOWED_TYPES = ['text','textarea','number','date','url','image','video',
    'file_pdf','file_xlsx','file_doc','file_any','presentation',
    'dropdown_single','dropdown_multi','radio','checkbox'];

/* =========================================================================
   DOMAINS  — list every internship_list domain + simulation task count
   ========================================================================= */
if ($resource === 'domains') {
    /* LEFT JOIN so a domain shows even if it has no category mapping */
    $sql = "SELECT il.id, il.internship_name, il.short_name,
                   MIN(ic.cat_name) AS category_name
            FROM internship_list il
            LEFT JOIN category_internship ci ON il.id = ci.internship_id
            LEFT JOIN internship_categories ic ON ic.cat_id = ci.cat_id
            WHERE il.show_internship = 1
            GROUP BY il.id, il.internship_name, il.short_name
            ORDER BY il.priority ASC";
    $res = $conn->query($sql);
    if ($res === false) sim_error('Could not read internship_list: ' . $conn->error, 500);

    $domains = [];
    while ($row = $res->fetch_assoc()) {
        $id = (int)$row['id'];
        $domains[$id] = [
            'internship_id' => $id,
            'name'          => $row['internship_name'],
            'short_name'    => $row['short_name'],
            'category'      => $row['category_name'] ?: 'Uncategorized',
            'task_count'    => 0,
        ];
    }

    /* task counts — tolerate the sim_tasks table not existing yet */
    $tc = $conn->query("SELECT internship_id, COUNT(*) AS c FROM sim_tasks GROUP BY internship_id");
    if ($tc) {
        while ($row = $tc->fetch_assoc()) {
            $id = (int)$row['internship_id'];
            if (isset($domains[$id])) $domains[$id]['task_count'] = (int)$row['c'];
        }
    }
    $conn->close();
    sim_ok(['all' => array_values($domains)]);
}

/* =========================================================================
   TASKS
   ========================================================================= */
if ($resource === 'tasks') {

    if ($action === 'list') {
        $internship_id = isset($_GET['internship_id']) ? (int)$_GET['internship_id'] : 0;
        if ($internship_id <= 0) sim_error('internship_id is required');
        $stmt = $conn->prepare(
            "SELECT t.*, (SELECT COUNT(*) FROM sim_task_fields f WHERE f.task_id = t.id) AS field_count
             FROM sim_tasks t WHERE t.internship_id = ?
             ORDER BY t.step_order ASC, t.id ASC"
        );
        $stmt->bind_param('i', $internship_id);
        $stmt->execute();
        $r = $stmt->get_result();
        $tasks = [];
        while ($row = $r->fetch_assoc()) {
            $row['id']            = (int)$row['id'];
            $row['internship_id'] = (int)$row['internship_id'];
            $row['step_order']    = (int)$row['step_order'];
            $row['points']        = (int)$row['points'];
            $row['field_count']   = (int)$row['field_count'];
            $tasks[] = $row;
        }
        $stmt->close();
        $conn->close();
        sim_ok(['tasks' => $tasks]);
    }

    if ($action === 'create') {
        $internship_id  = (int)($in['internship_id'] ?? 0);
        $title          = trim($in['title'] ?? '');
        if ($internship_id <= 0 || $title === '') sim_error('internship_id and title are required');
        $description    = trim($in['description'] ?? '');
        $estimated_time = trim($in['estimated_time'] ?? '');
        $points         = (int)($in['points'] ?? 50);
        $step_order     = (int)($in['step_order'] ?? 0);
        if ($step_order <= 0) {
            $mx = $conn->query("SELECT COALESCE(MAX(step_order),0)+1 AS n FROM sim_tasks WHERE internship_id=$internship_id")->fetch_assoc();
            $step_order = (int)$mx['n'];
        }
        $stmt = $conn->prepare(
            "INSERT INTO sim_tasks (internship_id, title, description, step_order, estimated_time, points, status, created_by)
             VALUES (?, ?, ?, ?, ?, ?, 'active', ?)"
        );
        $stmt->bind_param('issisii', $internship_id, $title, $description, $step_order, $estimated_time, $points, $user_id);
        $stmt->execute();
        $id = $stmt->insert_id;
        $stmt->close();
        $conn->close();
        sim_ok(['id' => $id], 'Task created');
    }

    if ($action === 'update') {
        $id    = (int)($in['id'] ?? 0);
        $title = trim($in['title'] ?? '');
        if ($id <= 0 || $title === '') sim_error('id and title are required');
        $description    = trim($in['description'] ?? '');
        $estimated_time = trim($in['estimated_time'] ?? '');
        $points         = (int)($in['points'] ?? 50);
        $step_order     = (int)($in['step_order'] ?? 1);
        $stmt = $conn->prepare(
            "UPDATE sim_tasks SET title=?, description=?, estimated_time=?, points=?, step_order=? WHERE id=?"
        );
        $stmt->bind_param('sssiii', $title, $description, $estimated_time, $points, $step_order, $id);
        $stmt->execute();
        $stmt->close();
        $conn->close();
        sim_ok(['id' => $id], 'Task updated');
    }

    if ($action === 'toggle') {
        $id = (int)($in['id'] ?? 0);
        if ($id <= 0) sim_error('id is required');
        $stmt = $conn->prepare("UPDATE sim_tasks SET status = IF(status='active','inactive','active') WHERE id=?");
        $stmt->bind_param('i', $id);
        $stmt->execute();
        $stmt->close();
        $conn->close();
        sim_ok(['id' => $id], 'Task status toggled');
    }

    if ($action === 'delete') {
        $id = (int)($in['id'] ?? 0);
        if ($id <= 0) sim_error('id is required');
        $subIds = [];
        $sr = $conn->query("SELECT id FROM sim_submissions WHERE task_id=$id");
        while ($x = $sr->fetch_assoc()) $subIds[] = (int)$x['id'];
        if ($subIds) {
            $list = implode(',', $subIds);
            $conn->query("DELETE FROM sim_submission_answers WHERE submission_id IN ($list)");
        }
        $conn->query("DELETE FROM sim_submissions   WHERE task_id=$id");
        $conn->query("DELETE FROM sim_user_progress WHERE task_id=$id");
        $conn->query("DELETE FROM sim_task_fields   WHERE task_id=$id");
        $conn->query("DELETE FROM sim_tasks         WHERE id=$id");
        $conn->close();
        sim_ok(['id' => $id], 'Task deleted');
    }

    if ($action === 'reorder') {
        $order = $in['order'] ?? [];
        if (is_string($order)) $order = json_decode($order, true);
        if (!is_array($order) || !$order) sim_error('order array is required');
        $stmt = $conn->prepare("UPDATE sim_tasks SET step_order=? WHERE id=?");
        foreach (array_values($order) as $i => $tid) {
            $pos = $i + 1;
            $tid = (int)$tid;
            $stmt->bind_param('ii', $pos, $tid);
            $stmt->execute();
        }
        $stmt->close();
        $conn->close();
        sim_ok(null, 'Tasks reordered');
    }

    sim_error('Unknown task action');
}

/* =========================================================================
   FIELDS  (the dynamic submission form)
   ========================================================================= */
if ($resource === 'fields') {

    if ($action === 'list') {
        $task_id = isset($_GET['task_id']) ? (int)$_GET['task_id'] : 0;
        if ($task_id <= 0) sim_error('task_id is required');
        $stmt = $conn->prepare("SELECT * FROM sim_task_fields WHERE task_id=? ORDER BY field_order ASC, id ASC");
        $stmt->bind_param('i', $task_id);
        $stmt->execute();
        $r = $stmt->get_result();
        $fields = [];
        while ($row = $r->fetch_assoc()) {
            $row['id']               = (int)$row['id'];
            $row['task_id']          = (int)$row['task_id'];
            $row['field_order']      = (int)$row['field_order'];
            $row['is_required']      = (int)$row['is_required'];
            $row['min_keywords']     = (int)$row['min_keywords'];
            $row['max_file_size_mb'] = (int)$row['max_file_size_mb'];
            $row['weight']           = (int)$row['weight'];
            $row['options']          = sim_json_decode($row['options']);
            $row['correct_answers']  = sim_json_decode($row['correct_answers']);
            $row['keywords']         = sim_json_decode($row['keywords']);
            $fields[] = $row;
        }
        $stmt->close();
        $conn->close();
        sim_ok(['fields' => $fields]);
    }

    if ($action === 'create' || $action === 'update') {
        $task_id    = (int)($in['task_id'] ?? 0);
        $field_type = $in['field_type'] ?? 'text';
        $label      = trim($in['label'] ?? '');
        if ($action === 'create' && $task_id <= 0) sim_error('task_id is required');
        if ($label === '') sim_error('label is required');
        if (!in_array($field_type, $ALLOWED_TYPES, true)) sim_error('Invalid field_type');

        $placeholder    = trim($in['placeholder'] ?? '');
        $help_text      = trim($in['help_text'] ?? '');
        $is_required    = !empty($in['is_required']) ? 1 : 0;
        $options        = sim_json_col($in['options'] ?? null);
        $correct        = sim_json_col($in['correct_answers'] ?? null);
        $keywords       = sim_json_col($in['keywords'] ?? null);
        $match_mode     = ($in['keyword_match_mode'] ?? 'any') === 'all' ? 'all' : 'any';
        $min_keywords   = max(1, (int)($in['min_keywords'] ?? 1));
        $number_min     = sim_num($in['number_min'] ?? null);
        $number_max     = sim_num($in['number_max'] ?? null);
        $number_correct = sim_num($in['number_correct'] ?? null);
        $accepted_ext   = trim($in['accepted_extensions'] ?? '');
        $max_size       = max(1, (int)($in['max_file_size_mb'] ?? 25));
        $weight         = max(1, (int)($in['weight'] ?? 1));
        $status         = ($in['status'] ?? 'active') === 'inactive' ? 'inactive' : 'active';

        if ($action === 'create') {
            $field_order = (int)($in['field_order'] ?? 0);
            if ($field_order <= 0) {
                $mx = $conn->query("SELECT COALESCE(MAX(field_order),0)+1 AS n FROM sim_task_fields WHERE task_id=$task_id")->fetch_assoc();
                $field_order = (int)$mx['n'];
            }
            $stmt = $conn->prepare(
                "INSERT INTO sim_task_fields
                 (task_id, field_order, field_type, label, placeholder, help_text, is_required,
                  options, correct_answers, keywords, keyword_match_mode, min_keywords,
                  number_min, number_max, number_correct, accepted_extensions, max_file_size_mb, weight, status)
                 VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)"
            );
            $stmt->bind_param(
                'iissssisssisdddsiis',
                $task_id, $field_order, $field_type, $label, $placeholder, $help_text, $is_required,
                $options, $correct, $keywords, $match_mode, $min_keywords,
                $number_min, $number_max, $number_correct, $accepted_ext, $max_size, $weight, $status
            );
            $stmt->execute();
            $id = $stmt->insert_id;
            $stmt->close();
            $conn->close();
            sim_ok(['id' => $id], 'Field created');
        } else {
            $id = (int)($in['id'] ?? 0);
            if ($id <= 0) sim_error('id is required');
            $stmt = $conn->prepare(
                "UPDATE sim_task_fields SET
                   field_type=?, label=?, placeholder=?, help_text=?, is_required=?,
                   options=?, correct_answers=?, keywords=?, keyword_match_mode=?, min_keywords=?,
                   number_min=?, number_max=?, number_correct=?, accepted_extensions=?,
                   max_file_size_mb=?, weight=?, status=?
                 WHERE id=?"
            );
            $stmt->bind_param(
                'ssssisssisdddsiisi',
                $field_type, $label, $placeholder, $help_text, $is_required,
                $options, $correct, $keywords, $match_mode, $min_keywords,
                $number_min, $number_max, $number_correct, $accepted_ext,
                $max_size, $weight, $status, $id
            );
            $stmt->execute();
            $stmt->close();
            $conn->close();
            sim_ok(['id' => $id], 'Field updated');
        }
    }

    if ($action === 'toggle') {
        $id = (int)($in['id'] ?? 0);
        if ($id <= 0) sim_error('id is required');
        $stmt = $conn->prepare("UPDATE sim_task_fields SET status=IF(status='active','inactive','active') WHERE id=?");
        $stmt->bind_param('i', $id);
        $stmt->execute();
        $stmt->close();
        $conn->close();
        sim_ok(['id' => $id], 'Field status toggled');
    }

    if ($action === 'delete') {
        $id = (int)($in['id'] ?? 0);
        if ($id <= 0) sim_error('id is required');
        $conn->query("DELETE FROM sim_submission_answers WHERE field_id=$id");
        $stmt = $conn->prepare("DELETE FROM sim_task_fields WHERE id=?");
        $stmt->bind_param('i', $id);
        $stmt->execute();
        $stmt->close();
        $conn->close();
        sim_ok(['id' => $id], 'Field deleted');
    }

    if ($action === 'reorder') {
        $order = $in['order'] ?? [];
        if (is_string($order)) $order = json_decode($order, true);
        if (!is_array($order) || !$order) sim_error('order array is required');
        $stmt = $conn->prepare("UPDATE sim_task_fields SET field_order=? WHERE id=?");
        foreach (array_values($order) as $i => $fid) {
            $pos = $i + 1;
            $fid = (int)$fid;
            $stmt->bind_param('ii', $pos, $fid);
            $stmt->execute();
        }
        $stmt->close();
        $conn->close();
        sim_ok(null, 'Fields reordered');
    }

    sim_error('Unknown field action');
}

sim_error('Unknown resource');

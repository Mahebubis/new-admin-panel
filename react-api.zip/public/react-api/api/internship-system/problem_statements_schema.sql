-- ---------------------------------------------------------------------------
-- problem_statements_schema.sql
-- Table that stores uploaded "Problem Statement" files for each internship
-- domain (internship_list row). A domain can hold many problem statements.
--
-- The API (problem_statements_api.php) also runs this CREATE TABLE IF NOT
-- EXISTS on every request, so applying this file manually is optional — it is
-- kept here for documentation / reference.
-- ---------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS internship_problem_statements (
    id            INT AUTO_INCREMENT PRIMARY KEY,
    internship_id INT          NOT NULL,                       -- internship_list.id
    title         VARCHAR(255)      DEFAULT NULL,              -- optional
    description   LONGTEXT          DEFAULT NULL,              -- optional, rich HTML
    file_url      TEXT         NOT NULL,                       -- public S3 URL (mandatory)
    file_key      VARCHAR(512) NOT NULL,                       -- S3 object key
    file_name     VARCHAR(255)      DEFAULT NULL,              -- original file name
    file_type     VARCHAR(40)       DEFAULT NULL,              -- pdf|image|doc|excel|ppt|video|zip|other
    file_size     BIGINT            DEFAULT 0,                 -- bytes
    mime_type     VARCHAR(150)      DEFAULT NULL,
    status        ENUM('active','inactive') DEFAULT 'active',
    created_by    INT               DEFAULT 0,                 -- admin users.user_id
    created_at    TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,
    updated_at    TIMESTAMP    DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    -- composite indexes: list query (internship_id+status) and count query (status+internship_id)
    INDEX idx_internship_status (internship_id, status),
    INDEX idx_status_internship (status, internship_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

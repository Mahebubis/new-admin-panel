-- ===========================================================================
--  assignments_schema.sql
--  Tables for the Internship "Assignment Panel".
--  assignments_api.php creates these automatically (CREATE TABLE IF NOT EXISTS)
--  on every request, so running this by hand is optional — it's kept here as
--  living documentation of the schema.
-- ===========================================================================

-- One assignment belongs to one internship (internship_list.id).
-- Only internships with is_full = 0 AND show_internship = 1 are surfaced.
CREATE TABLE IF NOT EXISTS internship_assignments (
    id            INT AUTO_INCREMENT PRIMARY KEY,
    internship_id INT          NOT NULL,
    title         VARCHAR(255) NOT NULL,
    description   LONGTEXT          DEFAULT NULL,   -- rich HTML (editor output)
    step_order    INT               DEFAULT 0,
    status        ENUM('active','inactive') DEFAULT 'active',
    created_by    INT               DEFAULT 0,
    created_at    TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,
    updated_at    TIMESTAMP    DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_internship_status (internship_id, status, step_order),
    INDEX idx_status_internship (status, internship_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Admin reference files attached to an assignment (ppt/pdf/excel/csv/video/...).
-- Each carries its own label (title), description, placeholder and required flag.
-- Files live on S3; the row stores the public URL + key.
CREATE TABLE IF NOT EXISTS internship_assignment_attachments (
    id            INT AUTO_INCREMENT PRIMARY KEY,
    assignment_id INT          NOT NULL,
    title         VARCHAR(255)      DEFAULT NULL,
    description   LONGTEXT          DEFAULT NULL,
    placeholder   VARCHAR(255)      DEFAULT NULL,
    is_required   TINYINT(1)        DEFAULT 0,
    file_url      TEXT         NOT NULL,
    file_key      VARCHAR(512) NOT NULL,
    file_name     VARCHAR(255)      DEFAULT NULL,
    file_type     VARCHAR(40)       DEFAULT NULL,   -- pdf|doc|excel|ppt|video|zip|image|other
    file_size     BIGINT            DEFAULT 0,
    mime_type     VARCHAR(150)      DEFAULT NULL,
    sort_order    INT               DEFAULT 0,
    status        ENUM('active','inactive') DEFAULT 'active',
    created_by    INT               DEFAULT 0,
    created_at    TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_assignment_status (assignment_id, status, sort_order)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- The dynamic submission-form builder (mirrors sim_task_fields).
-- field_type one of: text, textarea, number, date, url, image, video,
-- file_pdf, file_xlsx, file_doc, file_any, presentation,
-- dropdown_single, dropdown_multi, radio, checkbox.
CREATE TABLE IF NOT EXISTS internship_assignment_fields (
    id                  INT AUTO_INCREMENT PRIMARY KEY,
    assignment_id       INT          NOT NULL,
    field_order         INT               DEFAULT 0,
    field_type          VARCHAR(30)  NOT NULL,
    label               VARCHAR(500) NOT NULL,
    placeholder         VARCHAR(500)      DEFAULT NULL,
    help_text           VARCHAR(1000)     DEFAULT NULL,
    is_required         TINYINT(1)        DEFAULT 1,
    options             TEXT              DEFAULT NULL,   -- JSON [{value,label}]
    accepted_extensions VARCHAR(255)      DEFAULT NULL,   -- csv of extensions for file types
    max_file_size_mb    INT               DEFAULT 25,
    status              ENUM('active','inactive') DEFAULT 'active',
    created_at          TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,
    updated_at          TIMESTAMP    DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_assignment_order (assignment_id, field_order)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

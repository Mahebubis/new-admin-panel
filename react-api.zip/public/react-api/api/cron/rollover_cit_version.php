<?php
/**
 * CIT VERSION ROLLOVER CRON  (run daily at 00:00 Asia/Kolkata)
 * ------------------------------------------------------------------
 * Flow (exactly in this order):
 *   1. Read settings.future_result_dates (pipe-delimited Y-m-d list).
 *      Take the FIRST (0th) date. If today != that date -> exit (skip).
 *   2. Read settings.refund_program (on/off) -> choose the WhatsApp table:
 *        on  -> whatsapp_placement_club_link_for_refund
 *        off -> whatsapp_placement_club_link
 *   3. Find the status='active' row in that table, then the NEXT row (id >).
 *        - If no next row -> DO NOT create the batch. Email a reminder to
 *          add the next WhatsApp link, then exit.
 *   4. If a next row exists (single DB transaction):
 *        - close the current active link, activate the next one
 *        - set previous exam_batch_for_reports.to_date = now
 *        - insert the new exam_batch_for_reports row (new CIT version)
 *            result_date      = 0th future date (== today)
 *            certificate_date = result_date + 1 day
 *            exam_end_date    = result_date - 1 day
 *            exam_start_date  = prev.exam_end_date + 1 day
 *            from_date        = now,  to_date = exam_end_date (column is NOT NULL)
 *        - update settings.current_cit_version -> new version
 *        - update settings.result_date        -> 0th future date
 *        - remove the 0th date from settings.future_result_dates
 *        - write a row into cit_version_rollover_log
 * ------------------------------------------------------------------
 */

error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);
ini_set('error_log', __DIR__ . '/error_log.txt');

file_put_contents(
    __DIR__ . '/cron_execution_log.txt',
    "[" . date('Y-m-d H:i:s') . "] CIT ROLLOVER CRON EXECUTED. FILE: " . __FILE__ . "\n",
    FILE_APPEND
);

require_once '/home/istudio/public_html/istudio_dashboard/api/vendor/autoload.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

date_default_timezone_set('Asia/Kolkata');

$db_host = '127.0.0.1';
$db_user = 'istudio_admin';
$db_pass = 'h;V[ts@#;u{B';
$db_name = 'istudio_cit';

$conn = mysqli_connect($db_host, $db_user, $db_pass, $db_name);
if (!$conn) {
    error_log("[" . date("Y-m-d H:i:s") . "] DB CONNECTION ERROR: " . mysqli_connect_error());
    exit("DB connection failed.\n");
}

/* ── recipients for reminder / status emails ── */
$RECIPIENTS = [
    "contact@internshipstudio.com",
    "aniketbihani97@gmail.com",
    "rashibhandari775@gmail.com",
    "khansaifurrhaman@gmail.com",
];

/* ── email helper (same SMTP as existing crons) ── */
function sendEmail($email, $subject, $body)
{
    $mail = new PHPMailer(true);
    try {
        $mail->isSMTP();
        $mail->Host       = 'mailhost.internshipstudio.com';
        $mail->SMTPAuth   = true;
        $mail->Username   = 'contact@internshipstudio.com';
        $mail->Password   = '5Hbe!j9rhbal~po1';
        $mail->SMTPSecure = 'tls';
        $mail->Port       = 587;
        $mail->CharSet    = 'UTF-8';
        $mail->Encoding   = 'base64';
        $mail->setFrom('contact@internshipstudio.com', 'Internship Studio');
        $mail->addAddress($email);
        $mail->addReplyTo('contact@internshipstudio.com', 'Internship Studio');
        $mail->isHTML(true);
        $mail->Subject = $subject;
        $mail->Body    = $body;
        $mail->send();
        return true;
    } catch (Exception $e) {
        error_log("[" . date('Y-m-d H:i:s') . "] EMAIL ERROR to $email: " . $mail->ErrorInfo);
        return false;
    }
}

function mailAll($recipients, $subject, $body)
{
    foreach ($recipients as $e) sendEmail($e, $subject, $body);
}

/* ── settings helpers ── */
function getSetting($conn, $key, $default = '')
{
    $key = mysqli_real_escape_string($conn, $key);
    $r = mysqli_query($conn, "SELECT settings_value FROM settings WHERE settings_key='$key' LIMIT 1");
    if ($r && mysqli_num_rows($r) > 0) return mysqli_fetch_assoc($r)['settings_value'];
    return $default;
}

function setSetting($conn, $key, $value)
{
    $k = mysqli_real_escape_string($conn, $key);
    $v = mysqli_real_escape_string($conn, $value);
    $r = mysqli_query($conn, "SELECT id FROM settings WHERE settings_key='$k' LIMIT 1");
    if ($r && mysqli_num_rows($r) > 0) {
        return mysqli_query($conn, "UPDATE settings SET settings_value='$v' WHERE settings_key='$k'");
    }
    return mysqli_query($conn, "INSERT INTO settings (settings_key, settings_value) VALUES ('$k','$v')");
}

/* ── "CIT 170" -> 170 ── */
function citNum($name)
{
    if (preg_match('/(\d+)/', (string)$name, $m)) return (int)$m[1];
    return 0;
}

/* ── next WA initials: ER -> ES -> ... -> EZ -> FA -> ... -> ZZ -> AA (mirrors the React helper) ── */
function nextInitials($code)
{
    $s = strtoupper(preg_replace('/[^A-Za-z]/', '', (string)$code));
    if (strlen($s) < 2) return 'AA';
    $a = ord($s[0]) - 65;
    $b = ord($s[1]) - 65;
    $b += 1;
    if ($b > 25) { $b = 0; $a += 1; }
    if ($a > 25) { $a = 0; }
    return chr(65 + $a) . chr(65 + $b);
}

/* ── ensure the log table exists ── */
mysqli_query($conn, "CREATE TABLE IF NOT EXISTS cit_version_rollover_log (
    id INT AUTO_INCREMENT PRIMARY KEY,
    exam_name VARCHAR(64) NOT NULL,
    current_cit_version VARCHAR(64) NULL,
    result_date DATE NULL,
    settings_result_date DATE NULL,
    wa_table VARCHAR(64) NULL,
    wa_community_name VARCHAR(255) NULL,
    refund_program VARCHAR(8) NULL,
    note VARCHAR(255) NULL,
    created_at DATETIME NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
/* add columns if an older table already exists without them */
foreach ([
    'current_cit_version'  => "current_cit_version VARCHAR(64) NULL AFTER exam_name",
    'settings_result_date' => "settings_result_date DATE NULL AFTER result_date",
] as $col => $ddl) {
    $colChk = mysqli_query($conn, "SHOW COLUMNS FROM cit_version_rollover_log LIKE '$col'");
    if ($colChk && mysqli_num_rows($colChk) === 0) {
        mysqli_query($conn, "ALTER TABLE cit_version_rollover_log ADD COLUMN $ddl");
    }
}

/* ============================================================
   STEP 1 — future_result_dates -> first date must equal today
   ============================================================ */
$raw = trim((string)getSetting($conn, 'future_result_dates', ''));
$dates = array();
if ($raw !== '') {
    foreach (explode('|', $raw) as $p) {
        $p = trim($p);
        if ($p !== '') $dates[] = $p;
    }
}

if (empty($dates)) {
    exit("No future_result_dates configured. Nothing to do.\n");
}

$firstDate = date('Y-m-d', strtotime($dates[0]));
$today     = date('Y-m-d');

if ($today !== $firstDate) {
    exit("Today ($today) does not match first result date ($firstDate). Skipping.\n");
}

/* ============================================================
   Derive the new CIT version from the latest existing batch
   ============================================================ */
$prevRes = mysqli_query($conn, "SELECT id, exam_name, exam_end_date, wa_community_initials
                                FROM exam_batch_for_reports ORDER BY id DESC LIMIT 1");
if (!$prevRes || mysqli_num_rows($prevRes) === 0) {
    mailAll($RECIPIENTS, "CIT rollover skipped — no existing batch",
        "The cron tried to roll over on $today but exam_batch_for_reports has no rows to derive the next version from.");
    exit("No previous exam_batch_for_reports row.\n");
}
$prev      = mysqli_fetch_assoc($prevRes);
$prevId    = (int)$prev['id'];
$newNum    = citNum($prev['exam_name']) + 1;
$newName   = 'CIT ' . $newNum;
$newInit   = nextInitials($prev['wa_community_initials']);

$result_date      = $firstDate;
$certificate_date = date('Y-m-d', strtotime($result_date . ' +1 day'));
$exam_end_date    = date('Y-m-d', strtotime($result_date . ' -1 day'));
$exam_start_date  = date('Y-m-d', strtotime($prev['exam_end_date'] . ' +1 day'));
$now              = date('Y-m-d H:i:s');

/* ============================================================
   STEP 2 — refund_program decides which WhatsApp table
   ============================================================ */
$refund   = strtolower(trim((string)getSetting($conn, 'refund_program', 'off')));
$isRefund = ($refund === 'on');
$waTable  = $isRefund ? 'whatsapp_placement_club_link_for_refund' : 'whatsapp_placement_club_link';

/* ============================================================
   STEP 3 — find active + next WhatsApp link
   ============================================================ */
$actRes = mysqli_query($conn, "SELECT id, community_name FROM $waTable WHERE status='active' ORDER BY id ASC LIMIT 1");
if (!$actRes || mysqli_num_rows($actRes) === 0) {
    mailAll($RECIPIENTS,
        "Add WhatsApp link for $newName — no active link",
        "Rollover for <b>$newName</b> (result date $result_date) could not proceed because <b>$waTable</b> has no active link.<br>"
        . "Please add/activate the next link for either whatsapp_placement_club_link or whatsapp_placement_club_link_for_refund.");
    exit("No active link in $waTable.\n");
}
$active   = mysqli_fetch_assoc($actRes);
$activeId = (int)$active['id'];

$nextRes = mysqli_query($conn, "SELECT id, community_name FROM $waTable WHERE id > $activeId ORDER BY id ASC LIMIT 1");
if (!$nextRes || mysqli_num_rows($nextRes) === 0) {
    // No next link -> do NOT create the batch, just remind.
    mailAll($RECIPIENTS,
        "Add next WhatsApp link for $newName",
        "Please add the next link for whatsapp placement club link for either "
        . "<b>whatsapp_placement_club_link</b> or <b>whatsapp_placement_club_link_for_refund</b>.<br><br>"
        . "Active table: <b>$waTable</b><br>"
        . "Current active link: <b>" . htmlspecialchars($active['community_name']) . "</b> (id $activeId)<br>"
        . "Pending new CIT version: <b>$newName</b><br>"
        . "Result date: <b>$result_date</b><br><br>"
        . "The new CIT version was NOT created. It will be created on the next run once a next link exists.");
    exit("No next link in $waTable — reminder sent, rollover deferred.\n");
}
$next     = mysqli_fetch_assoc($nextRes);
$nextId   = (int)$next['id'];
$nextName = $next['community_name'];

/* ============================================================
   STEP 4 — do the rollover atomically
   ============================================================ */
mysqli_begin_transaction($conn);
try {
    // switch WhatsApp link
    if (!mysqli_query($conn, "UPDATE $waTable SET status='closed', closed_at='$now' WHERE id=$activeId"))
        throw new Exception('close active link failed: ' . mysqli_error($conn));
    if (!mysqli_query($conn, "UPDATE $waTable SET status='active', activated_at='$now' WHERE id=$nextId"))
        throw new Exception('activate next link failed: ' . mysqli_error($conn));

    // previous batch ends now
    if (!mysqli_query($conn, "UPDATE exam_batch_for_reports SET to_date='$now' WHERE id=$prevId"))
        throw new Exception('update prev to_date failed: ' . mysqli_error($conn));

    // guard against a duplicate version being inserted
    $dupChk = mysqli_query($conn, "SELECT id FROM exam_batch_for_reports WHERE exam_name='" . mysqli_real_escape_string($conn, $newName) . "' LIMIT 1");
    if ($dupChk && mysqli_num_rows($dupChk) > 0)
        throw new Exception("version $newName already exists");

    $eName = mysqli_real_escape_string($conn, $newName);
    $eInit = mysqli_real_escape_string($conn, $newInit);
    // to_date is NOT NULL: seed it with exam_end_date (same convention as the
    // previous latest row). It gets overwritten with the switch timestamp when
    // the NEXT version rolls over.
    $ins = "INSERT INTO exam_batch_for_reports
            (exam_name, from_date, to_date, result_date, certificate_date, exam_start_date, exam_end_date, wa_community_initials, special, normal)
            VALUES ('$eName','$now','$exam_end_date','$result_date','$certificate_date','$exam_start_date','$exam_end_date','$eInit',0,1)";
    if (!mysqli_query($conn, $ins))
        throw new Exception('insert new batch failed: ' . mysqli_error($conn));

    // current version pointer
    if (!setSetting($conn, 'current_cit_version', $newName))
        throw new Exception('update current_cit_version failed: ' . mysqli_error($conn));

    // settings.result_date tracks the new batch's result date (the 0th future date)
    if (!setSetting($conn, 'result_date', $result_date))
        throw new Exception('update result_date failed: ' . mysqli_error($conn));

    // consume the 0th future date
    array_shift($dates);
    if (!setSetting($conn, 'future_result_dates', implode('|', $dates)))
        throw new Exception('update future_result_dates failed: ' . mysqli_error($conn));

    // log
    $wt    = mysqli_real_escape_string($conn, $waTable);
    $nName = mysqli_real_escape_string($conn, $nextName);
    $rp    = mysqli_real_escape_string($conn, $refund);
    // settings_result_date = the value just written to settings.result_date
    if (!mysqli_query($conn, "INSERT INTO cit_version_rollover_log
            (exam_name, current_cit_version, result_date, settings_result_date, wa_table, wa_community_name, refund_program, note, created_at)
            VALUES ('$eName','$eName','$result_date','$result_date','$wt','$nName','$rp','rollover','$now')"))
        throw new Exception('insert rollover log failed: ' . mysqli_error($conn));

    mysqli_commit($conn);
} catch (Exception $e) {
    mysqli_rollback($conn);
    error_log("[" . date('Y-m-d H:i:s') . "] ROLLOVER FAILED: " . $e->getMessage());
    mailAll($RECIPIENTS, "CIT rollover FAILED for $newName",
        "The rollover to <b>$newName</b> failed and was rolled back.<br>Error: " . htmlspecialchars($e->getMessage()));
    exit("Rollover failed: " . $e->getMessage() . "\n");
}

/* ── success notification ── */
mailAll($RECIPIENTS,
    "CIT rollover done → $newName",
    "<h3>New CIT version created</h3>"
    . "Version: <b>$newName</b><br>"
    . "Result date: <b>$result_date</b> (also written to settings.result_date)<br>"
    . "Exam window: <b>$exam_start_date → $exam_end_date</b><br>"
    . "Certificate date: <b>$certificate_date</b><br>"
    . "WA table: <b>$waTable</b><br>"
    . "WhatsApp activated: <b>" . htmlspecialchars($nextName) . "</b> (id $nextId), closed id $activeId<br>"
    . "Time: <b>$now</b>");

echo "Rollover complete: $newName (result $result_date).\n";

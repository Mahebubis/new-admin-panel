<?php
/* ════════════════════════════════════════════════════════════
   ATTENDANCE API
   Endpoint: /admin/react-api/api/attendance/attendance.php

   Actions (GET):
     ?action=list                    -> recent 15 users from attendance_log
     ?action=search&q=<email|phone>  -> matching users (exact match — fast)
     ?action=calendar&payment_id=<id>-> day-by-day calendar for one payment

   One user can have several internship_payment rows with refund='yes' —
   each such payment becomes its own row (its own batch + duration).

   Present-day rule:
     - dates < 2026-05-13 : present if a user_login_activity record exists
     - dates >= 2026-05-13: present ONLY if BOTH a user_login_activity record
                            AND an attendance_log record exist for that date
════════════════════════════════════════════════════════════ */
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../middleware/auth.php';

/* Match the database's calendar so "today" lines up with DATE() in MySQL —
   otherwise a UTC server treats the IST current date as future and skips it. */
date_default_timezone_set('Asia/Kolkata');

$jwt = require_jwt();
require_permission('attendance', $jwt);

define('ATT_CUTOFF', '2026-05-13');   // dual-table rule applies on/after this date

/* total_duration column value -> number of months */
function att_months($days) {
    $days = (int)$days;
    if ($days <= 0)   return 0;
    if ($days <= 35)  return 1;
    if ($days <= 65)  return 2;
    if ($days <= 95)  return 3;
    if ($days <= 125) return 4;
    if ($days <= 155) return 5;
    return 6;
}

/* "19th March, 2026" -> DateTime | null */
function att_parse_batch($batch) {
    if (!$batch) return null;
    $clean = preg_replace('/(\d+)(st|nd|rd|th)/i', '$1', trim($batch));
    try { return new DateTime($clean); } catch (Exception $e) { return null; }
}

/* project submission date — 1mo=day25, 2mo=day55, 3mo=day85 ... (25 + (m-1)*30),
   counting the batch day itself as day 1 */
function att_submission_date($start, $months) {
    if (!$start || $months < 1) return null;
    $dayNo = 25 + ($months - 1) * 30;
    $d = clone $start;
    $d->modify('+' . ($dayNo - 1) . ' days');
    return $d->format('Y-m-d');
}

/* core: day-by-day attendance for one user over [start, start + durationDays) */
function att_compute($conn, $user_id, DateTime $start, $durationDays) {
    $end = clone $start;
    $end->modify('+' . ($durationDays - 1) . ' days');
    $startStr = $start->format('Y-m-d');
    $endStr   = $end->format('Y-m-d');
    /* Force the MySQL session to IST so CURDATE() and DATE(login_date) /
       DATE(marked_at) all interpret "today" in the same timezone the user
       experiences — otherwise a UTC-defaulted server pushes today into
       "future" and silently drops today's marking from the count. Belt and
       braces: also derive today from PHP with an explicit IST timezone so
       the cutoff stays correct even if SET time_zone fails silently. */
    $conn->query("SET time_zone = '+05:30'");
    $todayStr = (new DateTime('now', new DateTimeZone('Asia/Kolkata')))->format('Y-m-d');

    /* bulk: login dates in the window */
    $loginSet = [];
    $st = $conn->prepare("SELECT DISTINCT DATE(login_date) d FROM user_login_activity
                          WHERE user_id = ? AND DATE(login_date) BETWEEN ? AND ? AND activity_level >= 1");
    $st->bind_param('iss', $user_id, $startStr, $endStr);
    $st->execute();
    $r = $st->get_result();
    while ($row = $r->fetch_assoc()) $loginSet[$row['d']] = true;
    $st->close();

    /* bulk: attendance_log dates in the window (matched on marked_at) */
    $attSet = [];
    $st = $conn->prepare("SELECT DISTINCT DATE(marked_at) d FROM attendance_log
                          WHERE user_id = ? AND DATE(marked_at) BETWEEN ? AND ?");
    $st->bind_param('iss', $user_id, $startStr, $endStr);
    $st->execute();
    $r = $st->get_result();
    while ($row = $r->fetch_assoc()) $attSet[$row['d']] = true;
    $st->close();

    $days = []; $present = 0; $absent = 0; $future = 0;
    $cur = clone $start;
    for ($i = 0; $i < $durationDays; $i++) {
        $ds = $cur->format('Y-m-d');
        /* String compare on YYYY-MM-DD avoids any DateTime timezone-offset
           subtleties — today is past (evaluable), strictly later dates are
           future. */
        if ($ds > $todayStr) {
            $status = 'future'; $future++;
        } else {
            $inLogin = isset($loginSet[$ds]);
            if ($ds < ATT_CUTOFF) {
                $isPresent = $inLogin;                          // old rule
            } else {
                $isPresent = $inLogin && isset($attSet[$ds]);   // dual-table rule
            }
            if ($isPresent) { $status = 'present'; $present++; }
            else            { $status = 'absent';  $absent++;  }
        }
        $days[] = ['date' => $ds, 'status' => $status];
        $cur->modify('+1 day');
    }
    /* percentage is against the FULL duration (e.g. 30 days = 100%), not elapsed days */
    $pct = $durationDays > 0 ? round($present / $durationDays * 100, 1) : 0;
    return compact('days', 'present', 'absent', 'future', 'pct');
}

/* build a row from one internship_payment record + user info */
function att_build_row($conn, $user, $p, $withDays = false) {
    $months = att_months($p['total_duration'] ?? 0);
    $start  = att_parse_batch($p['batch'] ?? '');

    $row = [
        'payment_id'              => (int)$p['id'],
        'user_id'                 => (int)$user['user_id'],
        'name'                    => $user['name'],
        'email'                   => $user['email'],
        'phone'                   => $user['phone'],
        'internship_name'         => $p['internship'],
        'batch'                   => $p['batch'],
        'batch_start'             => $start ? $start->format('Y-m-d') : null,
        'paid_at'                 => $p['paid_at'],
        'duration_months'         => $months,
        'duration_days'           => $months * 30,
        'attendance_pct'          => 0,
        'present'                 => 0,
        'absent'                  => 0,
        'future'                  => 0,
        'project_submission_date' => null,
    ];
    if ($start && $months > 0) {
        $c = att_compute($conn, (int)$user['user_id'], $start, $months * 30);
        $row['attendance_pct']          = $c['pct'];
        $row['present']                 = $c['present'];
        $row['absent']                  = $c['absent'];
        $row['future']                  = $c['future'];
        $row['project_submission_date'] = att_submission_date($start, $months);
        if ($withDays) $row['days'] = $c['days'];
    }
    return $row;
}

/* one row per refund='yes' internship_payment for a user */
function att_rows_for_user($conn, $user_id) {
    $st = $conn->prepare("SELECT user_id, name, email, phone FROM users WHERE user_id = ? LIMIT 1");
    $st->bind_param('i', $user_id);
    $st->execute();
    $user = $st->get_result()->fetch_assoc();
    $st->close();
    if (!$user) return [];

    $pst = $conn->prepare("SELECT id, batch, paid_at, internship, total_duration
                           FROM internship_payment
                           WHERE user_id = ? AND refund = 'yes'
                           ORDER BY paid_at DESC");
    $pst->bind_param('i', $user_id);
    $pst->execute();
    $pres = $pst->get_result();
    $rows = [];
    while ($p = $pres->fetch_assoc()) $rows[] = att_build_row($conn, $user, $p, false);
    $pst->close();
    return $rows;
}

/* ════════ ROUTING ════════ */
$action = $_GET['action'] ?? 'list';

/* ── recent 15 users who have attendance_log entries ── */
if ($action === 'list') {
    $res = $conn->query("SELECT user_id, MAX(marked_at) lm
                         FROM attendance_log
                         GROUP BY user_id
                         ORDER BY lm DESC
                         LIMIT 15");
    $out = [];
    if ($res) while ($r = $res->fetch_assoc()) {
        foreach (att_rows_for_user($conn, (int)$r['user_id']) as $row) $out[] = $row;
    }
    api_success(['records' => $out]);
}

/* ── search by email / phone — EXACT match so the index is used (fast) ── */
if ($action === 'search') {
    $q = trim($_GET['q'] ?? '');
    if ($q === '') api_error('Search query required', 400);

    if (strpos($q, '@') !== false) {
        $st = $conn->prepare("SELECT DISTINCT user_id FROM users WHERE email = ? LIMIT 20");
    } else {
        $st = $conn->prepare("SELECT DISTINCT user_id FROM users WHERE phone = ? LIMIT 20");
    }
    $st->bind_param('s', $q);
    $st->execute();
    $ids = $st->get_result();
    $out = [];
    while ($r = $ids->fetch_assoc()) {
        foreach (att_rows_for_user($conn, (int)$r['user_id']) as $row) $out[] = $row;
    }
    $st->close();
    api_success(['records' => $out]);
}

/* ── full calendar for one internship payment ── */
if ($action === 'calendar') {
    $payment_id = (int)($_GET['payment_id'] ?? 0);
    if (!$payment_id) api_error('payment_id required', 400);

    $st = $conn->prepare("SELECT ip.id, ip.user_id, ip.batch, ip.paid_at, ip.internship, ip.total_duration,
                                 u.name, u.email, u.phone
                          FROM internship_payment ip
                          JOIN users u ON u.user_id = ip.user_id
                          WHERE ip.id = ? LIMIT 1");
    $st->bind_param('i', $payment_id);
    $st->execute();
    $p = $st->get_result()->fetch_assoc();
    $st->close();
    if (!$p) api_error('Payment not found', 404);

    $user = ['user_id' => $p['user_id'], 'name' => $p['name'], 'email' => $p['email'], 'phone' => $p['phone']];
    $cal  = att_build_row($conn, $user, $p, true);
    if (!isset($cal['days'])) $cal['days'] = [];
    api_success(['calendar' => $cal]);
}

api_error('Unknown action', 400);

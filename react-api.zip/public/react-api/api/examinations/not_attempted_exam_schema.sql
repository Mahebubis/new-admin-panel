-- Run against istudio_cit. Marks cit_results rows that were force-finalized
-- via the "Not Attempted Exam" CSV upload (bulk-closing stuck/unfinished
-- attempts) instead of being written by the normal exam-submit flow.
ALTER TABLE `cit_results`
  ADD COLUMN `not_attempted` VARCHAR(10) NULL DEFAULT NULL AFTER `cit_version`;

<?php
/* ════════════════════════════════════════════════════════════
   RESULT PUBLISH API — PER CIT VERSION (batched, resumable)
   Endpoint: /admin/react-api/api/examinations/result_publish_version.php

   Drives the per-row Publish / Revert on the CIT Versions (Old) page.

   HOW "PUBLISHED" IS TRACKED (works for historical + new publishes):
     result.phase  = exam_batches.batch_id
     exam_batches.cit_no = the CIT number (e.g. 168)
     => a version N is "published" when the result table has rows whose
        phase belongs to a batch with cit_no = N.
     This is the SAME mapping the rest of the app uses
     (see exam_results.php: "exam_batches WHERE cit_no = ...").

   Tables:
     cit_results          -> raw scores (input)
     exam_batches         -> one row per batch  (batch_id = result.phase, cit_no = version)
     result               -> final ranked rows (output)
     result_publish_logs  -> audit log (mode = 'real')

   Actions (POST, x-www-form-urlencoded):
     all_status                              -> publish state for every version
     version_status  { cit_version }         -> publish state for one version
     publish_batch   { cit_version, offset, limit, round, batch_id }
     publish_skipped { cit_version, batch_id, round }
     revert_check    { cit_version }         -> can this version be reverted?
     revert_batch    { cit_version, limit }
════════════════════════════════════════════════════════════ */
ini_set('display_errors', 0);
error_reporting(E_ALL);

define('RP_ERROR_LOG', __DIR__ . '/result_publish_version_error.log');
ini_set('log_errors', 1);
ini_set('error_log', RP_ERROR_LOG);

function logErr($ctx, $msg) {
    @file_put_contents(RP_ERROR_LOG,
        '[' . date('Y-m-d H:i:s') . '] [' . $ctx . '] ' . $msg . PHP_EOL,
        FILE_APPEND | LOCK_EX);
}

set_error_handler(function ($no, $str, $file, $line) {
    logErr('php_error', "[#$no] $str in $file:$line");
    return false;
});
set_exception_handler(function ($e) {
    logErr('exception', get_class($e) . ': ' . $e->getMessage()
        . ' in ' . $e->getFile() . ':' . $e->getLine());
    if (!headers_sent()) header('Content-Type: application/json');
    echo json_encode(['status'=>'error','message'=>'Server error — logged']);
});
register_shutdown_function(function () {
    $e = error_get_last();
    if ($e && in_array($e['type'], [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR], true)) {
        logErr('fatal', "[#{$e['type']}] {$e['message']} in {$e['file']}:{$e['line']}");
    }
});

ob_start();
chdir('/home/istudio/public_html/cit/common');
include '/home/istudio/public_html/cit/common/helper.php';   // $conn, fetch_setting(), update_student_step()
ob_clean();
header('Content-Type: application/json');
set_time_limit(0);
mysqli_report(MYSQLI_REPORT_OFF);

global $conn;
if (!$conn) { echo json_encode(['status'=>'error','message'=>'DB failed']); exit; }

$action = $_POST['action'] ?? $_GET['action'] ?? '';

/* ── helpers ─────────────────────────────────────────────── */

// numeric part of "CIT 168" -> 168
function citNum($cit_version) {
    if (preg_match('/(\d+)/', (string)$cit_version, $m)) return (int)$m[1];
    return 0;
}

// eligible student count for a version (raw scores)
function eligibleCount($conn, $cv) {
    $cvE = mysqli_real_escape_string($conn, $cv);
    $r = mysqli_query($conn, "SELECT COUNT(*) c FROM cit_results WHERE exam_id = 1 AND cit_version = '$cvE'");
    return $r ? (int)mysqli_fetch_assoc($r)['c'] : 0;
}

// all batch_ids that belong to a version (via exam_batches.cit_no)
function versionBatchIds($conn, $num) {
    $num = (int)$num;
    $ids = [];
    $r = mysqli_query($conn, "SELECT batch_id FROM exam_batches WHERE cit_no = $num");
    if ($r) while ($row = mysqli_fetch_assoc($r)) $ids[] = (int)$row['batch_id'];
    return $ids;
}

// published result rows for a version + which batch holds the most rows
// returns [count, [batchIds], mainBatchId]
function publishedForVersion($conn, $num) {
    $ids = versionBatchIds($conn, $num);
    if (!$ids) return [0, [], 0];
    $in = implode(',', array_map('intval', $ids));
    $count = 0; $main = 0; $best = -1;
    $r = mysqli_query($conn, "SELECT phase, COUNT(*) c FROM result WHERE phase IN ($in) GROUP BY phase");
    if ($r) while ($row = mysqli_fetch_assoc($r)) {
        $c = (int)$row['c']; $count += $c;
        if ($c > $best) { $best = $c; $main = (int)$row['phase']; }
    }
    return [$count, $ids, $main];
}

function batchIdExists($conn, $value) {
    $value = (int)$value;
    $r = mysqli_query($conn, "SELECT 1 FROM exam_batches WHERE batch_id = $value LIMIT 1");
    return $r && mysqli_num_rows($r) > 0;
}

// is any NEWER version (higher cit_no) still holding result rows?
function newerPublishedBlocker($conn, $num) {
    $num = (int)$num;
    // batches for higher versions
    $ids = [];
    $r = mysqli_query($conn, "SELECT batch_id, cit_no FROM exam_batches WHERE cit_no > $num");
    if ($r) while ($row = mysqli_fetch_assoc($r)) $ids[(int)$row['batch_id']] = (int)$row['cit_no'];
    if (!$ids) return null;
    $in = implode(',', array_map('intval', array_keys($ids)));
    $blockNum = 0;
    $q = mysqli_query($conn, "SELECT DISTINCT phase FROM result WHERE phase IN ($in)");
    if ($q) while ($row = mysqli_fetch_assoc($q)) {
        $cn = $ids[(int)$row['phase']] ?? 0;
        if ($cn > $blockNum) $blockNum = $cn;   // report the newest blocker
    }
    return $blockNum > 0 ? ('CIT ' . $blockNum) : null;
}

/* ════════ ALL STATUS (one call for the whole table) ════════ */
if ($action === 'all_status') {
    // eligible totals per version string ("CIT 169" => n)
    $eligible = [];
    $r = mysqli_query($conn, "SELECT cit_version, COUNT(*) c FROM cit_results
                              WHERE exam_id = 1 GROUP BY cit_version");
    if ($r) while ($row = mysqli_fetch_assoc($r)) $eligible[$row['cit_version']] = (int)$row['c'];

    // batch map: cit_no => [batch_ids]
    $batchMap = [];
    $allBatchIds = [];
    $r = mysqli_query($conn, "SELECT batch_id, cit_no FROM exam_batches");
    if ($r) while ($row = mysqli_fetch_assoc($r)) {
        $bid = (int)$row['batch_id'];
        $batchMap[(int)$row['cit_no']][] = $bid;
        $allBatchIds[] = $bid;
    }

    // published rows per phase — only count phases that belong to a batch (index-friendly,
    // avoids a full GROUP BY scan of the whole result table)
    $phaseCount = [];
    if ($allBatchIds) {
        $inB = implode(',', $allBatchIds);
        $r = mysqli_query($conn, "SELECT phase, COUNT(*) c FROM result WHERE phase IN ($inB) GROUP BY phase");
        if ($r) while ($row = mysqli_fetch_assoc($r)) $phaseCount[(int)$row['phase']] = (int)$row['c'];
    }

    // union of every version number we know about (from scores or batches)
    $nums = [];
    foreach (array_keys($eligible) as $cv) $nums[citNum($cv)] = true;
    foreach (array_keys($batchMap) as $n)  $nums[(int)$n] = true;
    unset($nums[0]);

    $statuses = [];
    foreach (array_keys($nums) as $num) {
        $cvKey = 'CIT ' . $num;
        $published = 0; $main = 0; $best = -1;
        foreach (($batchMap[$num] ?? []) as $bid) {
            $c = $phaseCount[$bid] ?? 0;
            $published += $c;
            if ($c > $best) { $best = $c; $main = $bid; }
        }
        $total = $eligible[$cvKey] ?? 0;
        $statuses[$cvKey] = [
            'total'        => $total,
            'batch_id'     => $main,
            'published'    => $published,
            'skipped'      => ($total > 0 ? max(0, $total - $published) : 0),
            'is_published' => ($published > 0),
        ];
    }
    echo json_encode(['status'=>'success','data'=>$statuses]);
    exit;
}

/* ════════ VERSION STATUS (single) ════════ */
if ($action === 'version_status') {
    $cv = trim($_POST['cit_version'] ?? '');
    if ($cv === '') { echo json_encode(['status'=>'error','message'=>'cit_version required']); exit; }
    $num = citNum($cv);
    list($published, , $main) = publishedForVersion($conn, $num);
    $total = eligibleCount($conn, $cv);
    echo json_encode(['status'=>'success','data'=>[
        'total'        => $total,
        'batch_id'     => $main,
        'published'    => $published,
        'skipped'      => ($total > 0 ? max(0, $total - $published) : 0),
        'is_published' => ($published > 0),
    ]]);
    exit;
}

/* ════════ PUBLISH ONE PACKET ════════ */
if ($action === 'publish_batch') {
    $cv       = trim($_POST['cit_version'] ?? '');
    $offset   = max(0, (int)($_POST['offset'] ?? 0));
    $limit    = min(5000, max(1, (int)($_POST['limit'] ?? 2000)));
    $round    = (int)($_POST['round'] ?? 1);
    $batch_id = (int)($_POST['batch_id'] ?? 0);
    if ($cv === '') { echo json_encode(['status'=>'error','message'=>'cit_version required']); exit; }

    $cvE   = mysqli_real_escape_string($conn, $cv);
    $num   = citNum($cv);
    // reuse total across packets so we don't COUNT(*) cit_results on every request
    $total = (int)($_POST['total'] ?? 0);
    if ($total <= 0) $total = eligibleCount($conn, $cv);
    if ($total === 0) { echo json_encode(['status'=>'error','message'=>'No results found for '.$cv]); exit; }

    /* ── first packet: create the batch + log row ── */
    if ($offset === 0 && $batch_id === 0) {
        // block a second publish for a version that already has result rows
        list($alreadyPublished) = publishedForVersion($conn, $num);
        if ($alreadyPublished > 0) {
            echo json_encode(['status'=>'error',
                'message'=>$cv.' is already published. Revert it before publishing again.']);
            exit;
        }
        $phase = mt_rand(1, 65535);
        while (batchIdExists($conn, $phase)) $phase = mt_rand(1, 65535);

        $date = date('Y-m-d');
        $ins = $conn->prepare("INSERT INTO exam_batches (batch_id, batch_date, cit_no) VALUES (?, ?, ?)");
        $ins->bind_param('isi', $phase, $date, $num);
        if (!$ins->execute()) {
            echo json_encode(['status'=>'error','message'=>'Failed to create batch: '.$ins->error]);
            exit;
        }
        $ins->close();

        $now = date('Y-m-d H:i:s');
        $mode = 'real'; $st = 'in_progress';
        $log = $conn->prepare("INSERT INTO result_publish_logs
            (cit_version, batch_id, publish_date, total_users, added_count, skipped_count,
             publish_start_time, publish_end_time, first_user_id, last_user_id, status, mode)
            VALUES (?, ?, ?, ?, 0, 0, ?, ?, 0, 0, ?, ?)");
        $log->bind_param('sisissss', $cv, $phase, $date, $total, $now, $now, $st, $mode);
        $log->execute(); $log->close();

        $batch_id = $phase;
    }
    if (!$batch_id) { echo json_encode(['status'=>'error','message'=>'batch_id missing']); exit; }

    /* ── process this slice (global order + OFFSET keeps ranking correct) ── */
    $res = mysqli_query($conn, "SELECT user_id, correct_answers, wrong_answers, time_taken
                                FROM cit_results
                                WHERE exam_id = 1 AND cit_version = '$cvE'
                                ORDER BY correct_answers DESC, time_taken ASC, user_id ASC
                                LIMIT $limit OFFSET $offset");
    $added = 0; $skipped = 0; $processed = 0;
    $first_user_id = null; $last_user_id = null;

    /* build ONE multi-row INSERT for the whole slice (all values are ints/derived → injection-safe) */
    $vals = []; $uids = [];
    $i = 0;
    while ($res && ($row = mysqli_fetch_assoc($res))) {
        $rank = $offset + $i + 1;            // global rank
        $i++;
        $uid = (int)$row['user_id'];
        if ($first_user_id === null) $first_user_id = $uid;
        $last_user_id = $uid;
        $uids[] = $uid;

        $percentile  = ($total > 1) ? (($total - $rank) / $total * 100) : 100;
        $pctStr      = number_format($percentile, 6, '.', '');
        $right       = (int)$row['correct_answers'];
        $wrong       = (int)$row['wrong_answers'];
        $total_marks = $right * 3;

        $vals[] = "($uid,$right,$wrong,$total_marks,$round,$batch_id,$rank,$pctStr,NOW())";
    }
    $processed = count($vals);

    if ($processed > 0) {
        $sql = "INSERT INTO result (user_id, rightans, wrongans, total, round, phase, `rank`, percentile, created_at) VALUES "
             . implode(',', $vals);
        if (mysqli_query($conn, $sql)) {
            $added = $processed;
            // bulk step flip: one upsert instead of N per-user update_student_step() calls.
            // user_steps.user_id is the PK; missing rows are created, existing rows get the flag.
            $stepVals = [];
            foreach ($uids as $u) $stepVals[] = '(' . (int)$u . ',1)';
            mysqli_query($conn, "INSERT INTO user_steps (user_id, cit_exam_result) VALUES "
                . implode(',', $stepVals) . " ON DUPLICATE KEY UPDATE cit_exam_result = 1");
        } else {
            logErr('publish_batch', 'bulk insert fail: ' . mysqli_error($conn));
            echo json_encode(['status'=>'error','message'=>'Insert failed: '.mysqli_error($conn)]);
            exit;
        }
    }

    $done = ($offset + $limit) >= $total;

    /* ── roll the counters into the log row ── */
    $now = date('Y-m-d H:i:s');
    $st  = $done ? 'completed' : 'in_progress';
    $up = $conn->prepare("UPDATE result_publish_logs
        SET added_count = added_count + ?, skipped_count = skipped_count + ?,
            last_user_id = ?, publish_end_time = ?, status = ?
        WHERE batch_id = ? AND mode = 'real'");
    $up->bind_param('iiissi', $added, $skipped, $last_user_id, $now, $st, $batch_id);
    $up->execute(); $up->close();

    if ($offset === 0 && $first_user_id !== null) {
        $uf = $conn->prepare("UPDATE result_publish_logs SET first_user_id = ?
                              WHERE batch_id = ? AND mode = 'real'");
        $uf->bind_param('ii', $first_user_id, $batch_id);
        $uf->execute(); $uf->close();
    }

    echo json_encode(['status'=>'success','data'=>[
        'cit_version' => $cv,
        'batch_id'    => $batch_id,
        'total'       => $total,
        'offset'      => $offset,
        'processed'   => $processed,
        'added'       => $added,
        'skipped'     => $skipped,
        'next_offset' => $offset + $limit,
        'done'        => $done,
    ]]);
    exit;
}

/* ════════ PUBLISH SKIPPED (fill the gaps for one version) ════════ */
if ($action === 'publish_skipped') {
    $cv       = trim($_POST['cit_version'] ?? '');
    $batch_id = (int)($_POST['batch_id'] ?? 0);
    $round    = (int)($_POST['round'] ?? 1);
    if ($cv === '' || !$batch_id) { echo json_encode(['status'=>'error','message'=>'cit_version & batch_id required']); exit; }

    $cvE   = mysqli_real_escape_string($conn, $cv);
    $num   = citNum($cv);
    $total = eligibleCount($conn, $cv);
    if ($total === 0) { echo json_encode(['status'=>'error','message'=>'No results found for '.$cv]); exit; }

    // user_ids already published for this version (across all its batches)
    $existing = [];
    list(, $allIds) = publishedForVersion($conn, $num);
    if ($allIds) {
        $in = implode(',', array_map('intval', $allIds));
        $r = mysqli_query($conn, "SELECT user_id FROM result WHERE phase IN ($in)");
        if ($r) while ($row = mysqli_fetch_assoc($r)) $existing[(int)$row['user_id']] = true;
    }

    // full ordered list -> rank is the true global position; insert only missing users
    $res = mysqli_query($conn, "SELECT user_id, correct_answers, wrong_answers, time_taken
                                FROM cit_results
                                WHERE exam_id = 1 AND cit_version = '$cvE'
                                ORDER BY correct_answers DESC, time_taken ASC, user_id ASC");
    $stmt = $conn->prepare("INSERT INTO result
        (user_id, rightans, wrongans, total, round, phase, `rank`, percentile, created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW())");
    if (!$stmt) { echo json_encode(['status'=>'error','message'=>'Prepare failed: '.$conn->error]); exit; }

    $rank = 0; $added = 0; $failed = 0; $already = 0; $doneUids = [];
    while ($res && ($row = mysqli_fetch_assoc($res))) {
        $rank++;
        $uid = (int)$row['user_id'];
        if (isset($existing[$uid])) { $already++; continue; }   // already published, keep its rank

        $percentile  = ($total > 1) ? (($total - $rank) / $total * 100) : 100;
        $right       = (int)$row['correct_answers'];
        $wrong       = (int)$row['wrong_answers'];
        $total_marks = $right * 3;

        $stmt->bind_param('iiiiiiid', $uid, $right, $wrong, $total_marks, $round, $batch_id, $rank, $percentile);
        if ($stmt->execute()) {
            $added++;
            $doneUids[] = $uid;
        } else {
            $failed++;
            logErr('publish_skipped', 'insert fail uid=' . $uid . ' : ' . $stmt->error);
        }
    }
    $stmt->close();

    // bulk step flip for the newly inserted users
    if ($doneUids) {
        $stepVals = [];
        foreach ($doneUids as $u) $stepVals[] = '(' . (int)$u . ',1)';
        mysqli_query($conn, "INSERT INTO user_steps (user_id, cit_exam_result) VALUES "
            . implode(',', $stepVals) . " ON DUPLICATE KEY UPDATE cit_exam_result = 1");
    }

    $now = date('Y-m-d H:i:s');
    $up = $conn->prepare("UPDATE result_publish_logs
        SET added_count = added_count + ?, publish_end_time = ?, status = 'completed'
        WHERE batch_id = ? AND mode = 'real'");
    $up->bind_param('isi', $added, $now, $batch_id);
    $up->execute(); $up->close();

    list($published) = publishedForVersion($conn, $num);
    echo json_encode(['status'=>'success','data'=>[
        'cit_version'      => $cv,
        'batch_id'         => $batch_id,
        'total'            => $total,
        'added'            => $added,
        'already_published'=> $already,                 // were already published, left untouched
        'skipped'          => max(0, $total - $published),   // still-missing after this run
        'published'        => $published,
    ]]);
    exit;
}

/* ════════ REVERT CHECK (guard: no newer published version) ════════ */
if ($action === 'revert_check') {
    $cv = trim($_POST['cit_version'] ?? '');
    if ($cv === '') { echo json_encode(['status'=>'error','message'=>'cit_version required']); exit; }
    $num = citNum($cv);

    $blocker = newerPublishedBlocker($conn, $num);
    list($published, , $main) = publishedForVersion($conn, $num);

    echo json_encode(['status'=>'success','data'=>[
        'can_revert' => ($blocker === null && $published > 0),
        'blocker'    => $blocker,
        'batch_id'   => $main,
        'published'  => $published,
    ]]);
    exit;
}

/* ════════ REVERT ONE PACKET ════════ */
if ($action === 'revert_batch') {
    $cv    = trim($_POST['cit_version'] ?? '');
    $limit = min(5000, max(1, (int)($_POST['limit'] ?? 500)));
    if ($cv === '') { echo json_encode(['status'=>'error','message'=>'cit_version required']); exit; }
    $num = citNum($cv);

    // re-check the guard on every packet — a newer version must not be published
    $blocker = newerPublishedBlocker($conn, $num);
    if ($blocker !== null) {
        echo json_encode(['status'=>'error',
            'message'=>'Revert '.$blocker.' first (a newer version is still published).']);
        exit;
    }

    $ids = versionBatchIds($conn, $num);
    if (!$ids) { echo json_encode(['status'=>'success','data'=>['reverted'=>0,'remaining'=>0,'done'=>true]]); exit; }
    $in = implode(',', array_map('intval', $ids));

    // delete a packet of result rows for any of this version's batches
    $del = $conn->prepare("DELETE FROM result WHERE phase IN ($in) LIMIT ?");
    $del->bind_param('i', $limit);
    $del->execute();
    $reverted = $del->affected_rows;
    $del->close();

    $rc = mysqli_query($conn, "SELECT COUNT(*) c FROM result WHERE phase IN ($in)");
    $remaining = $rc ? (int)mysqli_fetch_assoc($rc)['c'] : 0;
    $done = ($remaining === 0);

    // fully reverted -> remove the batch rows + logs so the version shows unpublished again
    if ($done) {
        mysqli_query($conn, "DELETE FROM exam_batches WHERE cit_no = $num");
        mysqli_query($conn, "DELETE FROM result_publish_logs WHERE batch_id IN ($in) AND mode = 'real'");
    }

    echo json_encode(['status'=>'success','data'=>[
        'cit_version' => $cv,
        'reverted'    => $reverted,
        'remaining'   => $remaining,
        'done'        => $done,
    ]]);
    exit;
}

logErr('fallback', "Unknown action='$action'");
echo json_encode(['status'=>'error','message'=>'Invalid action']);
exit;
?>

<?php
ini_set('display_errors', 0);
ob_start();
chdir('/home/istudio/public_html/cit/common');
include '/home/istudio/public_html/cit/common/helper.php';
ob_clean();
header('Content-Type: application/json');

global $conn;
if (!$conn) { echo json_encode(['status'=>'error','message'=>'DB failed']); exit; }

$action = $_POST['action'] ?? $_GET['action'] ?? '';

/* ── GET: fetch both tables ── */
if ($_SERVER['REQUEST_METHOD'] === 'GET' || $action === 'fetch') {
    $new = []; $old = [];
    $r = mysqli_query($conn, "SELECT id, cit_name, `start`, `end`, exam_start, exam_end, `result`, certificate, Initial FROM cit_version ORDER BY id DESC");
    if ($r) while ($row = mysqli_fetch_assoc($r)) $new[] = $row;
    $r = mysqli_query($conn, "SELECT * FROM exam_batch_for_reports ORDER BY id DESC");
    if ($r) while ($row = mysqli_fetch_assoc($r)) $old[] = $row;
    echo json_encode(['status'=>'success','new'=>$new,'old'=>$old]);
    exit;
}

/* ════ NEW TABLE (cit_version) ════ */

if ($action === 'add_cit_version2') {
    $cit_name    = mysqli_real_escape_string($conn, $_POST['cit_name']    ?? '');
    $start       = mysqli_real_escape_string($conn, $_POST['start']       ?? '');
    $end         = mysqli_real_escape_string($conn, $_POST['end']         ?? '');
    $exam_start  = mysqli_real_escape_string($conn, $_POST['exam_start']  ?? '');
    $exam_end    = mysqli_real_escape_string($conn, $_POST['exam_end']    ?? '');
    $result      = mysqli_real_escape_string($conn, $_POST['result']      ?? '');
    $certificate = mysqli_real_escape_string($conn, $_POST['certificate'] ?? '');
    $Initial     = mysqli_real_escape_string($conn, $_POST['Initial']     ?? '');

    $sql = "INSERT INTO cit_version (cit_name, `start`, `end`, exam_start, exam_end, `result`, certificate, Initial)
            VALUES ('$cit_name','$start','$end','$exam_start','$exam_end','$result','$certificate','$Initial')";
    echo json_encode(mysqli_query($conn, $sql) ? ['status'=>'success','message'=>'CIT version added successfully'] : ['status'=>'error','message'=>'Failed to add CIT version']);
    exit;
}

if ($action === 'update_cit_version2') {
    $id          = (int)($_POST['id'] ?? 0);
    $cit_name    = mysqli_real_escape_string($conn, $_POST['cit_name']    ?? '');
    $start       = mysqli_real_escape_string($conn, $_POST['start']       ?? '');
    $end         = mysqli_real_escape_string($conn, $_POST['end']         ?? '');
    $exam_start  = mysqli_real_escape_string($conn, $_POST['exam_start']  ?? '');
    $exam_end    = mysqli_real_escape_string($conn, $_POST['exam_end']    ?? '');
    $result      = mysqli_real_escape_string($conn, $_POST['result']      ?? '');
    $certificate = mysqli_real_escape_string($conn, $_POST['certificate'] ?? '');
    $Initial     = mysqli_real_escape_string($conn, $_POST['Initial']     ?? '');

    $sql = "UPDATE cit_version SET cit_name='$cit_name', `start`='$start', `end`='$end',
            exam_start='$exam_start', exam_end='$exam_end', `result`='$result',
            certificate='$certificate', Initial='$Initial' WHERE id=$id";
    echo json_encode(mysqli_query($conn, $sql) ? ['status'=>'success','message'=>'CIT version updated successfully'] : ['status'=>'error','message'=>'Failed to update CIT version']);
    exit;
}

if ($action === 'delete_cit_version2') {
    $id = (int)($_POST['id'] ?? 0);
    echo json_encode(mysqli_query($conn, "DELETE FROM cit_version WHERE id=$id") ? ['status'=>'success','message'=>'CIT version deleted successfully'] : ['status'=>'error','message'=>'Failed to delete CIT version']);
    exit;
}

/* ════ OLD TABLE (exam_batch_for_reports) ════ */

if ($action === 'add_cit_version') {
    $exam_name             = $_POST['exam_name']             ?? '';
    $from_date             = $_POST['from_date']             ?? '';
    $to_date               = $_POST['to_date']               ?? '';
    $result_date           = $_POST['result_date']           ?? '';
    $certificate_date      = $_POST['certificate_date']      ?? '';
    $exam_start_date       = $_POST['exam_start_date']       ?? '';
    $exam_end_date         = $_POST['exam_end_date']         ?? '';
    $wa_community_initials = $_POST['wa_community_initials'] ?? '';

    // Check duplicate — same as PHP
    $chk = mysqli_query($conn, "SELECT id FROM exam_batch_for_reports WHERE exam_name='$exam_name'");
    if ($chk && mysqli_num_rows($chk) > 0) {
        echo json_encode(['status'=>'error','message'=>'CIT Version already exists']);
        exit;
    }

    $now = date('Y-m-d H:i:s');

    // the previous latest row's exam period ENDS now -> to_date = now
    $prev = mysqli_query($conn, "SELECT id FROM exam_batch_for_reports ORDER BY id DESC LIMIT 1");
    if ($prev && mysqli_num_rows($prev) > 0) {
        $prevId = (int) mysqli_fetch_assoc($prev)['id'];
        mysqli_query($conn, "UPDATE exam_batch_for_reports SET to_date = '$now' WHERE id = $prevId");
    }

    // the new (latest) row's exam period STARTS now -> from_date = now.
    // to_date is NOT NULL, so seed it with exam_end_date; it is overwritten with
    // the switch timestamp when the next version is added.
    $sql = "INSERT INTO exam_batch_for_reports
            (exam_name,from_date,to_date,result_date,certificate_date,exam_start_date,exam_end_date,wa_community_initials,special,normal)
            VALUES ('$exam_name','$now','$exam_end_date','$result_date','$certificate_date','$exam_start_date','$exam_end_date','$wa_community_initials',0,1)";
    $ok = mysqli_query($conn, $sql);
    if ($ok) {
        // the new version becomes the current CIT version
        $cvE = mysqli_real_escape_string($conn, $exam_name);
        mysqli_query($conn, "UPDATE settings SET settings_value = '$cvE' WHERE settings_key = 'current_cit_version'");
    }
    echo json_encode($ok ? ['status'=>'success','message'=>'CIT Version Added Successfully'] : ['status'=>'error','message'=>'Something went wrong']);
    exit;
}

if ($action === 'update_cit_version') {
    $id                    = $_POST['id']                    ?? '';
    $exam_name             = $_POST['exam_name']             ?? '';
    $from_date             = $_POST['from_date']             ?? '';
    $to_date               = $_POST['to_date']               ?? '';
    $result_date           = $_POST['result_date']           ?? '';
    $certificate_date      = $_POST['certificate_date']      ?? '';
    $exam_start_date       = $_POST['exam_start_date']       ?? '';
    $exam_end_date         = $_POST['exam_end_date']         ?? '';
    $wa_community_initials = $_POST['wa_community_initials'] ?? '';

    // Check duplicate (excluding self) — same as PHP
    $chk = mysqli_query($conn, "SELECT id FROM exam_batch_for_reports WHERE exam_name='$exam_name' AND id!='$id'");
    if ($chk && mysqli_num_rows($chk) > 0) {
        echo json_encode(['status'=>'error','message'=>'CIT Version already exists']);
        exit;
    }

    $sql = "UPDATE exam_batch_for_reports SET
            exam_name='$exam_name', from_date='$from_date', to_date='$to_date',
            result_date='$result_date', certificate_date='$certificate_date',
            exam_start_date='$exam_start_date', exam_end_date='$exam_end_date',
            wa_community_initials='$wa_community_initials'
            WHERE id='$id'";
    echo json_encode(mysqli_query($conn, $sql) ? ['status'=>'success','message'=>'CIT Version Updated Successfully'] : ['status'=>'error','message'=>'Something went wrong']);
    exit;
}

if ($action === 'delete_cit_version') {
    $id = (int)($_POST['id'] ?? 0);

    // is the row being deleted the latest (highest id) one?
    $latRes   = mysqli_query($conn, "SELECT id FROM exam_batch_for_reports ORDER BY id DESC LIMIT 1");
    $latestId = ($latRes && mysqli_num_rows($latRes) > 0) ? (int) mysqli_fetch_assoc($latRes)['id'] : 0;
    $wasLatest = ($id === $latestId && $id > 0);

    $ok = mysqli_query($conn, "DELETE FROM exam_batch_for_reports WHERE id = $id");

    if ($ok && $wasLatest) {
        // the previous version becomes active again: clear its to_date + restore current version
        $prev = mysqli_query($conn, "SELECT id, exam_name, exam_end_date FROM exam_batch_for_reports ORDER BY id DESC LIMIT 1");
        if ($prev && mysqli_num_rows($prev) > 0) {
            $prevRow  = mysqli_fetch_assoc($prev);
            $prevId   = (int) $prevRow['id'];
            $prevName = mysqli_real_escape_string($conn, $prevRow['exam_name']);
            // to_date is NOT NULL -> restore the "latest row" convention (exam_end_date)
            $prevEnd  = mysqli_real_escape_string($conn, $prevRow['exam_end_date']);
            mysqli_query($conn, "UPDATE exam_batch_for_reports SET to_date = '$prevEnd' WHERE id = $prevId");
            mysqli_query($conn, "UPDATE settings SET settings_value = '$prevName' WHERE settings_key = 'current_cit_version'");
        }
    }
    echo json_encode($ok ? ['status'=>'success','message'=>'CIT Version Deleted Successfully'] : ['status'=>'error','message'=>'Something went wrong']);
    exit;
}

/* ════ FUTURE RESULT DATES (settings key: future_result_dates, pipe-delimited) ════ */

function frd_valid_date($d) {
    $d = trim((string)$d);
    if ($d === '') return null;
    $t = strtotime($d);
    if ($t === false) return null;
    return date('Y-m-d', $t);
}

function frd_read($conn) {
    $r = mysqli_query($conn, "SELECT settings_value FROM settings WHERE settings_key='future_result_dates' LIMIT 1");
    if (!$r || mysqli_num_rows($r) === 0) return array();
    $val = trim((string)(mysqli_fetch_assoc($r)['settings_value'] ?? ''));
    if ($val === '') return array();
    $out = array();
    foreach (explode('|', $val) as $p) {
        $p = trim($p);
        if ($p !== '') $out[] = $p;
    }
    return $out;
}

function frd_write($conn, $dates) {
    $dates = array_values(array_unique($dates));
    usort($dates, function ($a, $b) { return strtotime($a) - strtotime($b); });
    $joined = mysqli_real_escape_string($conn, implode('|', $dates));
    $chk = mysqli_query($conn, "SELECT id FROM settings WHERE settings_key='future_result_dates' LIMIT 1");
    if ($chk && mysqli_num_rows($chk) > 0) {
        mysqli_query($conn, "UPDATE settings SET settings_value='$joined' WHERE settings_key='future_result_dates'");
    } else {
        mysqli_query($conn, "INSERT INTO settings (settings_key, settings_value) VALUES ('future_result_dates','$joined')");
    }
    return $dates;
}

if ($action === 'get_future_dates') {
    echo json_encode(['status'=>'success','dates'=>frd_read($conn)]);
    exit;
}

if ($action === 'add_future_date') {
    $d = frd_valid_date($_POST['date'] ?? '');
    if (!$d) { echo json_encode(['status'=>'error','message'=>'Invalid date']); exit; }
    $dates = frd_read($conn);
    if (in_array($d, $dates, true)) { echo json_encode(['status'=>'error','message'=>'Date already exists']); exit; }
    $dates[] = $d;
    $dates = frd_write($conn, $dates);
    echo json_encode(['status'=>'success','message'=>'Result date added','dates'=>$dates]);
    exit;
}

if ($action === 'update_future_date') {
    $old = frd_valid_date($_POST['old_date'] ?? '');
    $new = frd_valid_date($_POST['new_date'] ?? '');
    if (!$old || !$new) { echo json_encode(['status'=>'error','message'=>'Invalid date']); exit; }
    $dates = frd_read($conn);
    $idx = array_search($old, $dates, true);
    if ($idx === false) { echo json_encode(['status'=>'error','message'=>'Date not found']); exit; }
    if ($new !== $old && in_array($new, $dates, true)) { echo json_encode(['status'=>'error','message'=>'Target date already exists']); exit; }
    $dates[$idx] = $new;
    $dates = frd_write($conn, $dates);
    echo json_encode(['status'=>'success','message'=>'Result date updated','dates'=>$dates]);
    exit;
}

if ($action === 'delete_future_date') {
    $d = frd_valid_date($_POST['date'] ?? '');
    if (!$d) { echo json_encode(['status'=>'error','message'=>'Invalid date']); exit; }
    $dates = frd_read($conn);
    $filtered = array();
    foreach ($dates as $x) { if ($x !== $d) $filtered[] = $x; }
    $dates = frd_write($conn, $filtered);
    echo json_encode(['status'=>'success','message'=>'Result date deleted','dates'=>$dates]);
    exit;
}

/* ════ ROLLOVER LOGS (auto-created table) ════ */

/* add a column to the log table if an older table exists without it */
function rl_add_col($conn, $col, $ddl) {
    $c = mysqli_query($conn, "SHOW COLUMNS FROM cit_version_rollover_log LIKE '$col'");
    if ($c && mysqli_num_rows($c) === 0) {
        mysqli_query($conn, "ALTER TABLE cit_version_rollover_log ADD COLUMN $ddl");
    }
}

function ensure_rollover_log($conn) {
    mysqli_query($conn, "CREATE TABLE IF NOT EXISTS cit_version_rollover_log (
        id INT AUTO_INCREMENT PRIMARY KEY,
        exam_name VARCHAR(64) NOT NULL,
        current_cit_version VARCHAR(64) NULL,
        result_date DATE NULL,
        settings_result_date DATE NULL,
        wa_table VARCHAR(64) NULL,
        wa_community_name VARCHAR(255) NULL,
        refund_program VARCHAR(8) NULL,
        note VARCHAR(255) NULL,
        created_at DATETIME NOT NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    rl_add_col($conn, 'current_cit_version',  "current_cit_version VARCHAR(64) NULL AFTER exam_name");
    rl_add_col($conn, 'settings_result_date', "settings_result_date DATE NULL AFTER result_date");
}

if ($action === 'get_rollover_logs') {
    ensure_rollover_log($conn);
    $rows = array();
    $r = mysqli_query($conn, "SELECT * FROM cit_version_rollover_log ORDER BY id DESC LIMIT 200");
    if ($r) while ($row = mysqli_fetch_assoc($r)) $rows[] = $row;

    // live settings for the dashboard strip on the CIT versions page
    $settings = ['current_cit_version'=>'', 'result_date'=>'', 'refund_program'=>''];
    $s = mysqli_query($conn, "SELECT settings_key, settings_value FROM settings
                              WHERE settings_key IN ('current_cit_version','result_date','refund_program')");
    if ($s) while ($row = mysqli_fetch_assoc($s)) $settings[$row['settings_key']] = $row['settings_value'];

    echo json_encode(['status'=>'success','logs'=>$rows,'settings'=>$settings]);
    exit;
}

echo json_encode(['status'=>'error','message'=>'Invalid action']);
exit;
?>
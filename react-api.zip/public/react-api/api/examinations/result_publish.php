<?php
/* ════════════════════════════════════════════════════════════
   RESULT PUBLISH API  (React admin panel) — REAL
   Endpoint: /admin/react-api/api/examinations/result_publish.php

   Log table = result_publish_logs, columns:
     id, cit_version, batch_id, publish_date, total_users,
     added_count, skipped_count, publish_start_time, publish_end_time,
     first_user_id, last_user_id, status, mode

   Actions (POST, x-www-form-urlencoded):
     get_stats     -> date, cit_version, user_count, batch_exists
     get_logs      -> last 50 rows of result_publish_logs
     delete_batch  -> { date }     delete an existing batch
     publish       -> { round }    REAL publish + one log row
════════════════════════════════════════════════════════════ */
ini_set('display_errors', 0);
error_reporting(E_ALL);

/* ── error logging: writes to result_publish_error.log in THIS directory ── */
define('RP_ERROR_LOG', __DIR__ . '/result_publish_error.log');
ini_set('log_errors', 1);
ini_set('error_log', RP_ERROR_LOG);

function logErr($ctx, $msg) {
    @file_put_contents(RP_ERROR_LOG,
        '[' . date('Y-m-d H:i:s') . '] [' . $ctx . '] ' . $msg . PHP_EOL,
        FILE_APPEND | LOCK_EX);
}

// catch PHP warnings / notices / recoverable errors
set_error_handler(function ($no, $str, $file, $line) {
    logErr('php_error', "[#$no] $str in $file:$line");
    return false;   // also let PHP's default handler run
});

// catch uncaught exceptions
set_exception_handler(function ($e) {
    logErr('exception', get_class($e) . ': ' . $e->getMessage()
        . ' in ' . $e->getFile() . ':' . $e->getLine());
    if (!headers_sent()) header('Content-Type: application/json');
    echo json_encode(['status'=>'error','message'=>'Server error — logged']);
});

// catch fatal errors on shutdown
register_shutdown_function(function () {
    $e = error_get_last();
    if ($e && in_array($e['type'], [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR], true)) {
        logErr('fatal', "[#{$e['type']}] {$e['message']} in {$e['file']}:{$e['line']}");
    }
});

ob_start();
chdir('/home/istudio/public_html/cit/common');
include '/home/istudio/public_html/cit/common/helper.php';   // gives $conn, fetch_setting(), update_student_step()
ob_clean();
header('Content-Type: application/json');
set_time_limit(0);                       // publish loop can be long
mysqli_report(MYSQLI_REPORT_OFF);        // PHP 8.1+: don't throw on SQL errors — we handle them

global $conn;
if (!$conn) { echo json_encode(['status'=>'error','message'=>'DB failed']); exit; }

$action = $_POST['action'] ?? $_GET['action'] ?? '';

/* ── helper: ensure a unique batch_id ── */
function citBatchExists($conn, $value) {
    $stmt = $conn->prepare("SELECT 1 FROM exam_batches WHERE batch_id = ? LIMIT 1");
    $stmt->bind_param('i', $value);
    $stmt->execute();
    $stmt->store_result();
    $exists = $stmt->num_rows > 0;
    $stmt->close();
    return $exists;
}

/* ════════ GET STATS ════════ */
if ($action === 'get_stats') {
    $date        = date('Y-m-d');
    $cit_version = fetch_setting('current_cit_version');
    $cv          = mysqli_real_escape_string($conn, (string)$cit_version);

    $user_count = 0;
    $r = mysqli_query($conn, "SELECT COUNT(*) c FROM cit_results WHERE exam_id = 1 AND cit_version = '$cv'");
    if ($r) $user_count = (int)mysqli_fetch_assoc($r)['c'];

    $batch_id = null;
    $stmt = $conn->prepare("SELECT batch_id FROM exam_batches WHERE batch_date = ? LIMIT 1");
    $stmt->bind_param('s', $date);
    $stmt->execute();
    $res = $stmt->get_result();
    if ($res && $res->num_rows > 0) $batch_id = (int)$res->fetch_assoc()['batch_id'];
    $stmt->close();

    echo json_encode(['status'=>'success','data'=>[
        'date'         => $date,
        'cit_version'  => $cit_version,
        'user_count'   => $user_count,
        'batch_exists' => $batch_id !== null,
        'batch_id'     => $batch_id,
    ]]);
    exit;
}

/* ════════ GET LOGS ════════ */
if ($action === 'get_logs') {
    $logs = [];
    $r = mysqli_query($conn, "SELECT id, cit_version, batch_id, publish_date, total_users,
                                     added_count, skipped_count, publish_start_time, publish_end_time,
                                     first_user_id, last_user_id, status, mode
                              FROM result_publish_logs ORDER BY id DESC LIMIT 50");
    if ($r) {
        while ($row = mysqli_fetch_assoc($r)) $logs[] = $row;
    } else {
        logErr('get_logs', mysqli_error($conn));
    }
    echo json_encode(['status'=>'success','data'=>$logs]);
    exit;
}

/* ════════ DELETE BATCH ════════ */
if ($action === 'delete_batch') {
    $date = $_POST['date'] ?? '';
    if (!$date) { echo json_encode(['status'=>'error','message'=>'date required']); exit; }

    $stmt = $conn->prepare("SELECT batch_id FROM exam_batches WHERE batch_date = ?");
    $stmt->bind_param('s', $date);
    $stmt->execute();
    $res = $stmt->get_result();
    if (!$res || $res->num_rows === 0) {
        echo json_encode(['status'=>'error','message'=>'No batch found for '.$date]);
        exit;
    }
    $batch_id = (int)$res->fetch_assoc()['batch_id'];
    $stmt->close();

    // delete result rows first, then the batch (same order as the PHP page)
    $d1 = $conn->prepare("DELETE FROM result WHERE phase = ?");
    $d1->bind_param('i', $batch_id); $d1->execute();
    $deleted = $d1->affected_rows; $d1->close();

    $d2 = $conn->prepare("DELETE FROM exam_batches WHERE batch_id = ?");
    $d2->bind_param('i', $batch_id); $d2->execute(); $d2->close();

    echo json_encode(['status'=>'success','message'=>"Batch #$batch_id deleted ($deleted result rows removed)"]);
    exit;
}

/* ════════ PUBLISH (REAL) ════════ */
if ($action === 'publish') {
    $round       = (int)($_POST['round'] ?? 1);
    $date        = date('Y-m-d');
    $cit_version = fetch_setting('current_cit_version');
    if (!$cit_version) { echo json_encode(['status'=>'error','message'=>'current_cit_version not set']); exit; }

    // block double-publish for the same date
    $chk = $conn->prepare("SELECT batch_id FROM exam_batches WHERE batch_date = ? LIMIT 1");
    $chk->bind_param('s', $date); $chk->execute();
    if ($chk->get_result()->num_rows > 0) {
        echo json_encode(['status'=>'error','message'=>'A batch already exists for '.$date.'. Delete it first.']);
        exit;
    }
    $chk->close();

    // unique batch_id (phase)
    $phase = mt_rand(1, 65535);
    while (citBatchExists($conn, $phase)) $phase = mt_rand(1, 65535);

    $cit_no     = explode(' ', $cit_version);
    $cit_no_val = isset($cit_no[1]) ? (int)$cit_no[1] : 0;

    $ins = $conn->prepare("INSERT INTO exam_batches (batch_id, batch_date, cit_no) VALUES (?, ?, ?)");
    $ins->bind_param('isi', $phase, $date, $cit_no_val);
    if (!$ins->execute()) {
        echo json_encode(['status'=>'error','message'=>'Failed to create batch: '.$ins->error]);
        exit;
    }
    $ins->close();

    $cv  = mysqli_real_escape_string($conn, $cit_version);
    $res = mysqli_query($conn, "SELECT user_id, correct_answers, wrong_answers, time_taken
                                FROM cit_results
                                WHERE exam_id = 1 AND cit_version = '$cv'
                                ORDER BY correct_answers DESC, time_taken ASC");
    $total_users = $res ? mysqli_num_rows($res) : 0;

    if ($total_users === 0) {
        mysqli_query($conn, "DELETE FROM exam_batches WHERE batch_id = $phase");   // rollback empty batch
        echo json_encode(['status'=>'error','message'=>'No results found for '.$cit_version]);
        exit;
    }

    $rank = 0; $added = 0; $skipped = 0;
    $publish_start_time = null;   // timestamp of FIRST student
    $publish_end_time   = null;   // timestamp after LAST student
    $first_user_id      = null;   // user_id of FIRST student
    $last_user_id       = null;   // user_id of LAST student

    // created_at supplied explicitly — matches the working test version
    $stmt = $conn->prepare("INSERT INTO result (user_id, rightans, wrongans, total, round, phase, `rank`, percentile, created_at)
                            VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW())");
    if (!$stmt) {
        mysqli_query($conn, "DELETE FROM exam_batches WHERE batch_id = $phase");   // rollback empty batch
        echo json_encode(['status'=>'error','message'=>'Prepare failed (result): ' . $conn->error]);
        exit;
    }

    while ($row = mysqli_fetch_assoc($res)) {
        $rank++;
        $uid = (int)$row['user_id'];
        if ($publish_start_time === null) { $publish_start_time = date('Y-m-d H:i:s'); $first_user_id = $uid; }
        $last_user_id = $uid;

        $percentile  = ($total_users > 1) ? (($total_users - $rank) / $total_users * 100) : 100;
        $right       = (int)$row['correct_answers'];
        $wrong       = (int)$row['wrong_answers'];
        $total_marks = $right * 3;

        // bind types fixed: rank = int, percentile = double  -> 'iiiiiiid'
        $stmt->bind_param('iiiiiiid', $uid, $right, $wrong, $total_marks, $round, $phase, $rank, $percentile);
        if ($stmt->execute()) {
            $added++;
            update_student_step($uid, 'cit_exam_result', 1);
        } else {
            $skipped++;
            logErr('publish', 'insert fail uid=' . $uid . ' : ' . $stmt->error);
        }
    }
    $stmt->close();
    $publish_end_time = date('Y-m-d H:i:s');

    // one log row per publish run (matches result_publish_logs schema)
    $publish_date = $date;
    $mode_val     = 'real';
    $status_val   = 'completed';
    $log = $conn->prepare("INSERT INTO result_publish_logs
        (cit_version, batch_id, publish_date, total_users, added_count, skipped_count,
         publish_start_time, publish_end_time, first_user_id, last_user_id, status, mode)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $log->bind_param('sisiiissiiss', $cit_version, $phase, $publish_date, $total_users,
                     $added, $skipped, $publish_start_time, $publish_end_time,
                     $first_user_id, $last_user_id, $status_val, $mode_val);
    $log_ok = $log->execute();
    $log_id = $log_ok ? $log->insert_id : 0;
    if (!$log_ok) logErr('publish_log', $log->error);
    $log->close();

    echo json_encode(['status'=>'success','message'=>'Results published successfully','data'=>[
        'log_id'             => $log_id,
        'batch_id'           => $phase,
        'cit_version'        => $cit_version,
        'round'              => $round,
        'total_users'        => $total_users,
        'added'              => $added,
        'skipped'            => $skipped,
        'first_user_id'      => $first_user_id,
        'last_user_id'       => $last_user_id,
        'publish_start_time' => $publish_start_time,
        'publish_end_time'   => $publish_end_time,
    ]]);
    exit;
}

logErr('fallback', "Unknown action='$action'");
echo json_encode(['status'=>'error','message'=>'Invalid action']);
exit;
?>

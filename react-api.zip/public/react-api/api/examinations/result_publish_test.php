<?php
/* ════════════════════════════════════════════════════════════
   RESULT PUBLISH API  —  TEST VERSION  (temporary)
   Endpoint: /admin/react-api/api/examinations/result_publish_test.php

   Only the API FILE is separate — it writes to the SAME real tables:
     - result rows  -> result
     - student step -> user_steps      (via helper.php update_student_step)
     - log rows     -> result_publish_logs   (mode = 'test')
   Difference vs result_publish.php: processes ONLY the 2-3 user IDs you pass.

   result_publish_logs columns:
     id, cit_version, batch_id, publish_date, total_users,
     added_count, skipped_count, publish_start_time, publish_end_time,
     first_user_id, last_user_id, status, mode

   Actions (POST, x-www-form-urlencoded):
     get_stats   -> date, cit_version, user_count
     get_logs    -> last 50 rows of result_publish_logs
     publish     -> { user_ids, round }   TEST publish for 2-3 users
     delete_test -> { batch_id }          remove a test batch's result rows
════════════════════════════════════════════════════════════ */
ini_set('display_errors', 0);
error_reporting(E_ALL);

/* ── error logging: writes to result_publish_test_error.log in THIS directory ── */
define('RP_ERROR_LOG', __DIR__ . '/result_publish_test_error.log');
ini_set('log_errors', 1);
ini_set('error_log', RP_ERROR_LOG);

function logErr($ctx, $msg) {
    @file_put_contents(RP_ERROR_LOG,
        '[' . date('Y-m-d H:i:s') . '] [' . $ctx . '] ' . $msg . PHP_EOL,
        FILE_APPEND | LOCK_EX);
}

// catch PHP warnings / notices / recoverable errors
set_error_handler(function ($no, $str, $file, $line) {
    logErr('php_error', "[#$no] $str in $file:$line");
    return false;   // also let PHP's default handler run
});

// catch uncaught exceptions / fatal Errors
set_exception_handler(function ($e) {
    logErr('exception', get_class($e) . ': ' . $e->getMessage()
        . ' in ' . $e->getFile() . ':' . $e->getLine());
    if (!headers_sent()) header('Content-Type: application/json');
    echo json_encode(['status'=>'error','message'=>'Server error: ' . $e->getMessage()]);
});

// catch fatal errors on shutdown
register_shutdown_function(function () {
    $e = error_get_last();
    if ($e && in_array($e['type'], [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR], true)) {
        logErr('fatal', "[#{$e['type']}] {$e['message']} in {$e['file']}:{$e['line']}");
    }
});

ob_start();
chdir('/home/istudio/public_html/cit/common');
include '/home/istudio/public_html/cit/common/helper.php';   // gives $conn, fetch_setting(), update_student_step()
ob_clean();
header('Content-Type: application/json');
set_time_limit(0);
mysqli_report(MYSQLI_REPORT_OFF);        // PHP 8.1+: don't throw on SQL errors — we handle them

global $conn;
if (!$conn) { echo json_encode(['status'=>'error','message'=>'DB failed']); exit; }

$action = $_POST['action'] ?? $_GET['action'] ?? '';

/* ── safe prepare: on failure return the REAL sql error instead of crashing ── */
function prep($conn, $sql, $label) {
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        logErr('prepare', "[$label] " . $conn->error);
        echo json_encode(['status'=>'error','message'=>"DB prepare failed [$label]: " . $conn->error]);
        exit;
    }
    return $stmt;
}

/* ════════ GET STATS ════════ */
if ($action === 'get_stats') {
    $date        = date('Y-m-d');
    $cit_version = fetch_setting('current_cit_version');
    $cv          = mysqli_real_escape_string($conn, (string)$cit_version);

    $user_count = 0;
    $r = mysqli_query($conn, "SELECT COUNT(*) c FROM cit_results WHERE exam_id = 1 AND cit_version = '$cv'");
    if ($r) $user_count = (int)mysqli_fetch_assoc($r)['c'];

    echo json_encode(['status'=>'success','data'=>[
        'date'        => $date,
        'cit_version' => $cit_version,
        'user_count'  => $user_count,
        'mode'        => 'TEST',
    ]]);
    exit;
}

/* ════════ GET LOGS ════════ */
if ($action === 'get_logs') {
    $logs = [];
    $r = mysqli_query($conn, "SELECT id, cit_version, batch_id, publish_date, total_users,
                                     added_count, skipped_count, publish_start_time, publish_end_time,
                                     first_user_id, last_user_id, status, mode
                              FROM result_publish_logs ORDER BY id DESC LIMIT 50");
    if ($r) {
        while ($row = mysqli_fetch_assoc($r)) $logs[] = $row;
    } else {
        logErr('get_logs', mysqli_error($conn));
    }
    echo json_encode(['status'=>'success','data'=>$logs]);
    exit;
}

/* ════════ DELETE TEST BATCH ════════ */
if ($action === 'delete_test') {
    $batch_id = (int)($_POST['batch_id'] ?? 0);
    if (!$batch_id) { echo json_encode(['status'=>'error','message'=>'batch_id required']); exit; }

    $d = prep($conn, "DELETE FROM result WHERE phase = ?", 'delete result');
    $d->bind_param('i', $batch_id); $d->execute();
    $deleted = $d->affected_rows; $d->close();

    // remove the batch row too (created during the test publish)
    $db = prep($conn, "DELETE FROM exam_batches WHERE batch_id = ?", 'delete exam_batches');
    $db->bind_param('i', $batch_id); $db->execute(); $db->close();

    // remove the log row for this test batch
    $dl = prep($conn, "DELETE FROM result_publish_logs WHERE batch_id = ? AND mode = 'test'", 'delete log');
    $dl->bind_param('i', $batch_id); $dl->execute();
    $logRemoved = $dl->affected_rows; $dl->close();

    echo json_encode(['status'=>'success','message'=>"Test batch #$batch_id cleared ($deleted result rows, $logRemoved log removed)"]);
    exit;
}

/* ════════ PUBLISH (TEST — 2-3 users) ════════ */
if ($action === 'publish') {
    $round = (int)($_POST['round'] ?? 1);
    $raw   = $_POST['user_ids'] ?? '';
    $ids   = is_array($raw) ? $raw : explode(',', $raw);
    $ids   = array_filter(array_map('intval', $ids));
    $ids   = array_slice(array_values(array_unique($ids)), 0, 3);   // max 3 for testing

    if (!$ids) { echo json_encode(['status'=>'error','message'=>'Enter 1-3 valid user IDs']); exit; }

    $cit_version = fetch_setting('current_cit_version');
    if (!$cit_version) { echo json_encode(['status'=>'error','message'=>'current_cit_version not set']); exit; }

    $cv      = mysqli_real_escape_string($conn, (string)$cit_version);
    $id_list = implode(',', $ids);

    $res = mysqli_query($conn, "SELECT user_id, correct_answers, wrong_answers, time_taken
                                FROM cit_results
                                WHERE exam_id = 1 AND cit_version = '$cv' AND user_id IN ($id_list)
                                ORDER BY correct_answers DESC, time_taken ASC");
    if (!$res) {
        echo json_encode(['status'=>'error','message'=>'cit_results query failed: ' . $conn->error]);
        exit;
    }
    $total_users = mysqli_num_rows($res);
    if ($total_users === 0) {
        echo json_encode(['status'=>'error','message'=>'No cit_results found for given user IDs']);
        exit;
    }

    /* unique batch id — created in exam_batches first so result.phase stays valid
       (the real publish does this too; result.phase may reference exam_batches.batch_id) */
    $phase = mt_rand(1, 65535);
    $chkB = prep($conn, "SELECT 1 FROM exam_batches WHERE batch_id = ? LIMIT 1", 'check exam_batches');
    while (true) {
        $chkB->bind_param('i', $phase);
        $chkB->execute(); $chkB->store_result();
        $dupe = $chkB->num_rows > 0;
        $chkB->free_result();
        if (!$dupe) break;
        $phase = mt_rand(1, 65535);
    }
    $chkB->close();

    $cit_no_parts = explode(' ', $cit_version);
    $cit_no_val   = isset($cit_no_parts[1]) ? (int)$cit_no_parts[1] : 0;
    $batch_date   = date('Y-m-d');
    $batchIns = prep($conn,
        "INSERT INTO exam_batches (batch_id, batch_date, cit_no) VALUES (?, ?, ?)",
        'insert exam_batches');
    $batchIns->bind_param('isi', $phase, $batch_date, $cit_no_val);
    if (!$batchIns->execute()) {
        echo json_encode(['status'=>'error','message'=>'Failed to create test batch: ' . $batchIns->error]);
        exit;
    }
    $batchIns->close();

    $rank = 0; $added = 0; $skipped = 0;
    $insert_errors = [];          // per-row INSERT errors, surfaced in the response
    $publish_start_time = null;   // timestamp of FIRST student
    $publish_end_time   = null;   // timestamp after LAST student
    $first_user_id      = null;   // user_id of FIRST student
    $last_user_id       = null;   // user_id of LAST student
    $rows = [];

    // writes to the SAME real `result` table (created_at supplied explicitly)
    $stmt = prep($conn,
        "INSERT INTO result (user_id, rightans, wrongans, total, round, phase, `rank`, percentile, created_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW())",
        'insert result');

    while ($row = mysqli_fetch_assoc($res)) {
        $rank++;
        $uid = (int)$row['user_id'];
        if ($publish_start_time === null) { $publish_start_time = date('Y-m-d H:i:s'); $first_user_id = $uid; }
        $last_user_id = $uid;

        $percentile  = ($total_users > 1) ? (($total_users - $rank) / $total_users * 100) : 100;
        $right       = (int)$row['correct_answers'];
        $wrong       = (int)$row['wrong_answers'];
        $total_marks = $right * 3;

        // bind types: rank = int, percentile = double -> 'iiiiiiid'
        $stmt->bind_param('iiiiiiid', $uid, $right, $wrong, $total_marks, $round, $phase, $rank, $percentile);
        if ($stmt->execute()) {
            $added++;
            update_student_step($uid, 'cit_exam_result', 1);   // real helper -> user_steps
        } else {
            $skipped++;
            $insert_errors[] = "uid $uid: " . $stmt->error;
            logErr('publish', 'insert fail uid=' . $uid . ' : ' . $stmt->error);
        }
        $rows[] = [
            'user_id'    => $uid, 'rightans' => $right, 'wrongans' => $wrong,
            'total'      => $total_marks, 'rank' => $rank, 'percentile' => round($percentile, 2),
        ];
    }
    $stmt->close();
    $publish_end_time = date('Y-m-d H:i:s');

    // one log row per test run -> result_publish_logs (mode = 'test')
    $publish_date = date('Y-m-d');
    $mode_val     = 'test';
    $status_val   = 'completed';
    $log = prep($conn,
        "INSERT INTO result_publish_logs
         (cit_version, batch_id, publish_date, total_users, added_count, skipped_count,
          publish_start_time, publish_end_time, first_user_id, last_user_id, status, mode)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
        'insert result_publish_logs');
    $log->bind_param('sisiiissiiss', $cit_version, $phase, $publish_date, $total_users,
                     $added, $skipped, $publish_start_time, $publish_end_time,
                     $first_user_id, $last_user_id, $status_val, $mode_val);
    $log_ok = $log->execute();
    $log_id = $log_ok ? $log->insert_id : 0;
    if (!$log_ok) logErr('publish_log', $log->error);
    $log->close();

    echo json_encode(['status'=>'success','message'=>'TEST publish complete','data'=>[
        'mode'               => 'TEST',
        'log_id'             => $log_id,
        'batch_id'           => $phase,
        'cit_version'        => $cit_version,
        'round'              => $round,
        'total_users'        => $total_users,
        'added'              => $added,
        'skipped'            => $skipped,
        'insert_errors'      => $insert_errors,
        'first_user_id'      => $first_user_id,
        'last_user_id'       => $last_user_id,
        'publish_start_time' => $publish_start_time,
        'publish_end_time'   => $publish_end_time,
        'users'              => $rows,
    ]]);
    exit;
}

logErr('fallback', "Unknown action='$action'");
echo json_encode(['status'=>'error','message'=>'Invalid action']);
exit;
?>

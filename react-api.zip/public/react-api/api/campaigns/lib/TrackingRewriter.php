<?php
/*
 * Injects our own first-party open-pixel + click-redirect tracking into an
 * email's HTML at send time, per recipient (each gets a unique `rid`).
 * This is why open/click stats are identical regardless of which ESP
 * (SendGrid or Elastic Email) actually delivered the mail — tracking never
 * depends on the transport.
 */

define('CAMPAIGNS_PUBLIC_BASE_URL', 'https://cit3.internshipstudio.com/admin/react-api/api/campaigns');

function inject_tracking(string $html, string $rid, string $baseUrl = CAMPAIGNS_PUBLIC_BASE_URL): string {
    $html = rewrite_links_for_click_tracking($html, $rid, $baseUrl);
    $html = append_open_pixel($html, $rid, $baseUrl);
    return $html;
}

function append_open_pixel(string $html, string $rid, string $baseUrl): string {
    $pixel = '<img src="' . htmlspecialchars($baseUrl . '/track-open.php?rid=' . urlencode($rid), ENT_QUOTES)
           . '" width="1" height="1" style="display:none;width:1px;height:1px;border:0;" alt="" />';
    if (stripos($html, '</body>') !== false) {
        return preg_replace('/<\/body>/i', $pixel . '</body>', $html, 1);
    }
    return $html . $pixel;
}

/** Coarse device classification from a raw User-Agent string, stored alongside open/click events. */
function classify_device_type(string $userAgent): string {
    if ($userAgent === '') return 'unknown';
    if (preg_match('/iPad|Android(?!.*Mobile)|Tablet/i', $userAgent)) return 'tablet';
    if (preg_match('/Mobile|iPhone|Android|BlackBerry|IEMobile|Opera Mini/i', $userAgent)) return 'mobile';
    return 'desktop';
}

/** Rewrites every <a href="URL"> to point at our click-tracking redirect, skipping mailto/tel/#/already-wrapped links. */
function rewrite_links_for_click_tracking(string $html, string $rid, string $baseUrl): string {
    return preg_replace_callback(
        '/<a\b([^>]*?)\shref\s*=\s*(["\'])(.*?)\2([^>]*)>/is',
        function ($m) use ($rid, $baseUrl) {
            [$full, $pre, $quote, $url, $post] = $m;
            $trimmed = trim($url);
            if ($trimmed === '' || $trimmed[0] === '#'
                || stripos($trimmed, 'mailto:') === 0
                || stripos($trimmed, 'tel:') === 0
                || stripos($trimmed, '/track-click.php') !== false) {
                return $full;
            }
            $tracked = $baseUrl . '/track-click.php?rid=' . urlencode($rid) . '&u=' . urlencode($trimmed);
            return '<a' . $pre . ' href=' . $quote . $tracked . $quote . $post . '>';
        },
        $html
    );
}

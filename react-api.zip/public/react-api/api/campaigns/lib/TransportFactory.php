<?php
require_once __DIR__ . '/SendGridTransport.php';
require_once __DIR__ . '/ElasticEmailTransport.php';

class TransportFactory {
    /** Providers that can actually be selected/configured today. MailWizz is intentionally
     *  absent: its row is gone from email_esp_settings and its transport class was removed,
     *  but the value survives in the esp_transport ENUM so historical campaign rows stay
     *  readable (see the migration note in lib/schema.php). */
    public const PROVIDERS = ['sendgrid', 'elasticemail'];

    /** Reads $campaign['esp_transport'], loads the matching email_esp_settings row, instantiates. */
    public static function forCampaign(array $campaign): ?EspTransport {
        return self::forProvider($campaign['esp_transport'] ?? 'sendgrid');
    }

    public static function forProvider(string $provider): ?EspTransport {
        global $conn;
        // Anything unrecognized — including the retired 'mailwizz' on an old campaign being
        // requeued — falls back to SendGrid rather than returning null, so a legacy campaign
        // still sends instead of failing every recipient with "No ESP transport configured".
        if (!in_array($provider, self::PROVIDERS, true)) $provider = 'sendgrid';

        $stmt = $conn->prepare("SELECT * FROM email_esp_settings WHERE provider = ? LIMIT 1");
        $stmt->bind_param('s', $provider);
        $stmt->execute();
        $row = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        if (!$row) return null;

        return $provider === 'elasticemail' ? new ElasticEmailTransport($row) : new SendGridTransport($row);
    }

    /** Which provider is flagged active in Settings (used as the default for new campaigns). */
    public static function activeProvider(): string {
        global $conn;
        $r = $conn->query("SELECT provider FROM email_esp_settings WHERE is_active = 1 LIMIT 1");
        $row = $r ? $r->fetch_assoc() : null;
        $provider = $row['provider'] ?? 'sendgrid';
        return in_array($provider, self::PROVIDERS, true) ? $provider : 'sendgrid';
    }
}

<?php
require_once __DIR__ . '/EspTransport.php';

/*
 * Runs many ESP sends concurrently.
 *
 * This is the whole reason a 40k campaign can finish in minutes rather than hours. An email
 * send is almost entirely WAITING — a few hundred milliseconds of network round-trip during
 * which the server does nothing. Sending sequentially, that dead time is the throughput
 * ceiling: ~3 emails/second no matter how fast the machine is. curl_multi keeps N of those
 * waits overlapping, so throughput becomes (concurrency / latency) instead of (1 / latency).
 *
 * Nothing here knows anything about SendGrid or Elastic Email — each transport builds its own
 * request and interprets its own response (see EspTransport::buildRequest/parseResponse).
 * That keeps provider quirks in the provider classes and concurrency in exactly one place.
 */

/** Performs one already-built request. The single-send path (Send Test Email) and the
 *  fallback when there is only one job, so both share identical cURL options. */
function esp_http_exec(array $req, int $timeout = 20): array {
    $ch = curl_init($req['url']);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST           => true,
        CURLOPT_POSTFIELDS     => $req['body'],
        CURLOPT_HTTPHEADER     => $req['headers'],
        CURLOPT_TIMEOUT        => $timeout,
    ]);
    $body    = curl_exec($ch);
    $status  = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $curlErr = curl_error($ch);
    curl_close($ch);
    return [$status, $body === false ? null : $body, $curlErr];
}

/**
 * Sends every job, at most $concurrency in flight at once.
 *
 * @param array $jobs each ['key' => mixed, 'rid' => ?string, 'req' => built request]
 *                    `key` is echoed back as the result key — SendWorker passes the
 *                    recipient row id so results map straight back to rows.
 * @return array<mixed, array{ok: bool, message_id: ?string, error: ?string, retryable: bool}>
 */
function esp_send_parallel(EspTransport $transport, array $jobs, int $concurrency = 32, int $timeout = 20): array {
    $results = [];
    if (!$jobs) return $results;

    $queue = array_values($jobs);
    $total = count($queue);
    $concurrency = max(1, min($concurrency, $total));

    // One handle in flight isn't worth curl_multi's bookkeeping.
    if ($concurrency === 1) {
        foreach ($queue as $job) {
            [$status, $body, $err] = esp_http_exec($job['req'], $timeout);
            $results[$job['key']] = $transport->parseResponse($status, $body, $err, $job['rid'] ?? null);
        }
        return $results;
    }

    $mh = curl_multi_init();
    $next = 0;
    $inFlight = [];  // handle id => job

    // PHP 8 hands back CurlHandle OBJECTS, not resources, so (int)$ch is a TypeError there;
    // spl_object_id is the object-safe equivalent. The is_object() check keeps this working
    // if it is ever run on an older PHP where curl_init() still returns a resource.
    $handleId = fn($ch) => is_object($ch) ? spl_object_id($ch) : (int)$ch;

    $launch = function () use (&$queue, &$next, &$inFlight, $mh, $timeout, $total, $handleId) {
        if ($next >= $total) return false;
        $job = $queue[$next++];
        $ch = curl_init($job['req']['url']);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST           => true,
            CURLOPT_POSTFIELDS     => $job['req']['body'],
            CURLOPT_HTTPHEADER     => $job['req']['headers'],
            CURLOPT_TIMEOUT        => $timeout,
        ]);
        curl_multi_add_handle($mh, $ch);
        $inFlight[$handleId($ch)] = $job;
        return true;
    };

    for ($i = 0; $i < $concurrency; $i++) {
        if (!$launch()) break;
    }

    do {
        $status = curl_multi_exec($mh, $running);
        if ($status !== CURLM_OK) break;

        // Block until a handle actually has activity rather than spinning the CPU at 100%.
        // Guarded on $running because select() returns immediately (and can return -1) when
        // nothing is in flight — which happens on the tick right after the last completion.
        if ($running > 0) curl_multi_select($mh, 1.0);

        while ($done = curl_multi_info_read($mh)) {
            $ch  = $done['handle'];
            $id  = $handleId($ch);
            $job = $inFlight[$id] ?? null;

            if ($job !== null) {
                $body = curl_multi_getcontent($ch);
                $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
                // $done['result'] is the cURL-level outcome (timeout, DNS, TLS). curl_error()
                // alone is unreliable once a handle has been removed from the multi stack.
                $err  = $done['result'] !== CURLE_OK ? (curl_error($ch) ?: 'cURL error ' . $done['result']) : '';
                $results[$job['key']] = $transport->parseResponse($code, $body, $err, $job['rid'] ?? null);
                unset($inFlight[$id]);
            }

            curl_multi_remove_handle($mh, $ch);
            curl_close($ch);
            // Immediately backfill the freed slot so the window stays saturated.
            $launch();
        }
    } while ($running > 0 || $inFlight);

    curl_multi_close($mh);
    return $results;
}

<?php
/*
 * campaigns_ensure_schema() — idempotent CREATE TABLE IF NOT EXISTS for the
 * 5 tables backing the Email Campaigns builder. Called at the top of every
 * entrypoint in this feature, mirrors netcore/segments.php's ensureSchema().
 * SQL is documented (kept in sync manually) in ../campaigns_schema.sql.
 */
function campaigns_ensure_schema() {
    global $conn;
    if (!$conn) return;

    // CREATE TABLE IF NOT EXISTS and SHOW COLUMNS are cheap metadata-only checks — safe to
    // run on every single request (every page load, every cron tick, every tracking-pixel
    // hit), and this is what lets a newly-added column (like `attachments` below) actually
    // get created on servers that already had these tables. Do NOT skip this block wholesale
    // — an earlier version of this function did that as a deadlock workaround and it also
    // silently disabled all future column migrations, which is the bug that broke attachments.
    //
    // The ONE statement that actually caused that deadlock — the INSERT IGNORE seeding
    // email_esp_settings' two default rows — is guarded separately below, since that's a
    // real row-level unique-key write that concurrent requests can collide on; everything
    // else here is metadata-only and doesn't have that problem.
    try {
        $conn->query("CREATE TABLE IF NOT EXISTS email_campaigns (
            id                  INT AUTO_INCREMENT PRIMARY KEY,
            name                VARCHAR(255) NOT NULL,
            tags                VARCHAR(500) DEFAULT NULL,
            status              ENUM('draft','scheduled','running','sent','suspended','failed') NOT NULL DEFAULT 'draft',
            channel             ENUM('email') NOT NULL DEFAULT 'email',
            campaign_type       ENUM('regular','amp','ab_test','split') NOT NULL DEFAULT 'regular',
            ga_source VARCHAR(255) DEFAULT NULL, ga_medium VARCHAR(255) DEFAULT NULL, ga_campaign VARCHAR(255) DEFAULT NULL,
            ga_content VARCHAR(255) DEFAULT NULL, ga_term VARCHAR(255) DEFAULT NULL,
            goal_event_name VARCHAR(255) DEFAULT NULL, goal_window_days INT DEFAULT NULL, goal_revenue_param VARCHAR(255) DEFAULT NULL,
            audience_type       ENUM('all_contacts','segments') NOT NULL DEFAULT 'segments',
            segment_ids         JSON DEFAULT NULL,
            exclude_segment_ids JSON DEFAULT NULL,
            list_ids            JSON DEFAULT NULL,
            domain_filter       VARCHAR(255) DEFAULT NULL,
            reachable_count     INT NOT NULL DEFAULT 0,
            sender_name    VARCHAR(255) DEFAULT NULL, sender_email VARCHAR(255) DEFAULT NULL, sending_domain VARCHAR(255) DEFAULT NULL,
            subject        VARCHAR(998) DEFAULT NULL, preheader VARCHAR(255) DEFAULT NULL, reply_to VARCHAR(255) DEFAULT NULL,
            template_id    INT DEFAULT NULL,
            content_html   LONGTEXT DEFAULT NULL,
            schedule_type  ENUM('now','later') NOT NULL DEFAULT 'now',
            scheduled_at   DATETIME DEFAULT NULL,
            esp_transport  ENUM('sendgrid','mailwizz','elasticemail') NOT NULL DEFAULT 'sendgrid',
            exam_cit_version VARCHAR(100) DEFAULT NULL,
            total_recipients INT NOT NULL DEFAULT 0, sent_count INT NOT NULL DEFAULT 0, delivered_count INT NOT NULL DEFAULT 0,
            open_count INT NOT NULL DEFAULT 0, unique_open_count INT NOT NULL DEFAULT 0,
            click_count INT NOT NULL DEFAULT 0, unique_click_count INT NOT NULL DEFAULT 0,
            -- Hits that were machine fetches, not humans (Apple Mail Privacy Protection
            -- prefetch, mail-security scanners, duplicate re-renders — see lib/BotDetector.php).
            -- Counted separately so the filtering is visible instead of silently vanishing.
            bot_open_count INT NOT NULL DEFAULT 0, bot_click_count INT NOT NULL DEFAULT 0,
            bounce_count INT NOT NULL DEFAULT 0, unsubscribe_count INT NOT NULL DEFAULT 0,
            hard_bounce_count INT NOT NULL DEFAULT 0, soft_bounce_count INT NOT NULL DEFAULT 0,
            spam_count INT NOT NULL DEFAULT 0,
            conversion_count INT NOT NULL DEFAULT 0, conversion_finalized TINYINT(1) NOT NULL DEFAULT 0,
            created_by  BIGINT UNSIGNED DEFAULT NULL,
            created_at  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            started_at DATETIME DEFAULT NULL, completed_at DATETIME DEFAULT NULL,
            materialized_at DATETIME DEFAULT NULL,
            attachments JSON DEFAULT NULL,
            INDEX idx_status_scheduled (status, scheduled_at),
            INDEX idx_created_at (created_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

        $conn->query("CREATE TABLE IF NOT EXISTS email_campaign_recipients (
            id            BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            campaign_id   INT NOT NULL,
            user_id       BIGINT UNSIGNED DEFAULT NULL,
            email         VARCHAR(255) NOT NULL,
            first_name    VARCHAR(255) DEFAULT NULL, last_name VARCHAR(255) DEFAULT NULL, phone VARCHAR(50) DEFAULT NULL,
            is_test       TINYINT(1) NOT NULL DEFAULT 0,
            status        ENUM('pending','processing','sent','failed','bounced') NOT NULL DEFAULT 'pending',
            rid           CHAR(32) NOT NULL,
            attempts      TINYINT UNSIGNED NOT NULL DEFAULT 0,
            error_message VARCHAR(500) DEFAULT NULL,
            esp_message_id VARCHAR(255) DEFAULT NULL,
            queued_at     TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            sent_at DATETIME DEFAULT NULL, opened_at DATETIME DEFAULT NULL, first_clicked_at DATETIME DEFAULT NULL, bounced_at DATETIME DEFAULT NULL,
            open_count INT NOT NULL DEFAULT 0, click_count INT NOT NULL DEFAULT 0,
            bounce_type ENUM('hard','soft') DEFAULT NULL,
            UNIQUE INDEX uq_rid (rid),
            INDEX idx_campaign_status (campaign_id, status),
            INDEX idx_campaign_email (campaign_id, email),
            INDEX idx_esp_message_id (esp_message_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

        $conn->query("CREATE TABLE IF NOT EXISTS email_campaign_events (
            id           BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            campaign_id  INT NOT NULL,
            recipient_id BIGINT UNSIGNED NOT NULL,
            event_type   ENUM('open','click','bounce','unsubscribe','spamreport','dropped','deferred','open_bot','click_bot') NOT NULL,
            url          TEXT DEFAULT NULL,
            ip_address   VARCHAR(45) DEFAULT NULL, user_agent VARCHAR(500) DEFAULT NULL, meta JSON DEFAULT NULL,
            device_type  ENUM('mobile','tablet','desktop','unknown') DEFAULT NULL,
            created_at   TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_campaign_type (campaign_id, event_type),
            INDEX idx_recipient (recipient_id),
            INDEX idx_created_at (created_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

        $conn->query("CREATE TABLE IF NOT EXISTS campaign_templates (
            id              INT AUTO_INCREMENT PRIMARY KEY,
            name            VARCHAR(255) NOT NULL,
            category        VARCHAR(100) DEFAULT NULL,
            source          ENUM('upload','editor') NOT NULL DEFAULT 'editor',
            subject_default VARCHAR(998) DEFAULT NULL,
            body_html       LONGTEXT NOT NULL,
            status          ENUM('active','archived') NOT NULL DEFAULT 'active',
            created_by      BIGINT UNSIGNED DEFAULT NULL,
            created_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            INDEX idx_status_created (status, created_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

        $conn->query("CREATE TABLE IF NOT EXISTS email_esp_settings (
            id                     INT AUTO_INCREMENT PRIMARY KEY,
            provider               ENUM('sendgrid','mailwizz','elasticemail') NOT NULL,
            is_active              TINYINT(1) NOT NULL DEFAULT 0,
            api_key                VARCHAR(500) DEFAULT NULL,
            api_base_url           VARCHAR(500) DEFAULT NULL,
            list_uid               VARCHAR(100) DEFAULT NULL,
            webhook_secret         VARCHAR(255) DEFAULT NULL,
            default_sender_name    VARCHAR(255) DEFAULT NULL, default_sender_email VARCHAR(255) DEFAULT NULL, default_sending_domain VARCHAR(255) DEFAULT NULL,
            extra_config           JSON DEFAULT NULL,
            updated_at             TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            UNIQUE INDEX uq_provider (provider)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

        // Guarded separately: this is the one real row-level write in this function (a
        // unique-key INSERT), so only attempt it if the seed rows genuinely aren't there yet —
        // this is what actually avoids the concurrent-request deadlock, without skipping the
        // (harmless) table/column checks above.
        $seedCheck = $conn->query("SELECT 1 FROM email_esp_settings LIMIT 1");
        if (!$seedCheck || $seedCheck->num_rows === 0) {
            $conn->query("INSERT IGNORE INTO email_esp_settings
                (provider, is_active, api_key, api_base_url, list_uid, default_sender_name, default_sender_email, default_sending_domain) VALUES
                ('sendgrid', 1, 'SG.DUMMY_KEY_REPLACE_ME', NULL, NULL, 'Internship Studio', 'alert@alert.internshipstudio.com', 'alert.internshipstudio.com'),
                ('elasticemail', 0, 'DUMMY_ELASTICEMAIL_API_KEY', NULL, NULL, 'Internship Studio', 'alert@alert.internshipstudio.com', 'alert.internshipstudio.com')");
        }

        /* ---- MailWizz → Elastic Email migration (idempotent, runs on already-live DBs) ----
         *
         * The ENUMs above gained 'elasticemail' but deliberately KEPT 'mailwizz': dropping a
         * value that existing rows still use makes MySQL either error or silently coerce those
         * rows to '', which would corrupt the esp_transport of every campaign that was ever
         * sent through MailWizz. The value stays legal in the column; it's simply no longer
         * offered anywhere (settings.php rejects it, TransportFactory maps it to SendGrid, and
         * the Settings UI doesn't render it).
         */
        $espCols = $conn->query("SHOW COLUMNS FROM email_esp_settings LIKE 'provider'");
        $espColRow = $espCols ? $espCols->fetch_assoc() : null;
        if ($espColRow && strpos((string)$espColRow['Type'], 'elasticemail') === false) {
            $conn->query("ALTER TABLE email_esp_settings MODIFY COLUMN provider ENUM('sendgrid','mailwizz','elasticemail') NOT NULL");
        }
        $campCols = $conn->query("SHOW COLUMNS FROM email_campaigns LIKE 'esp_transport'");
        $campColRow = $campCols ? $campCols->fetch_assoc() : null;
        if ($campColRow && strpos((string)$campColRow['Type'], 'elasticemail') === false) {
            $conn->query("ALTER TABLE email_campaigns MODIFY COLUMN esp_transport ENUM('sendgrid','mailwizz','elasticemail') NOT NULL DEFAULT 'sendgrid'");
        }

        // Seed the Elastic Email row on DBs that were created before this provider existed.
        // is_active=0 so adding it never silently steals sending away from SendGrid — the
        // admin flips the Active sender radio in Settings when they're ready.
        $eeCheck = $conn->query("SELECT 1 FROM email_esp_settings WHERE provider='elasticemail' LIMIT 1");
        if (!$eeCheck || $eeCheck->num_rows === 0) {
            $conn->query("INSERT IGNORE INTO email_esp_settings
                (provider, is_active, api_key, api_base_url, list_uid, default_sender_name, default_sender_email, default_sending_domain) VALUES
                ('elasticemail', 0, 'DUMMY_ELASTICEMAIL_API_KEY', NULL, NULL, 'Internship Studio', 'alert@alert.internshipstudio.com', 'alert.internshipstudio.com')");
        }

        // Drop the MailWizz credentials row. It only ever held dummy placeholders (never wired
        // to a real install), and leaving it behind would let it stay flagged is_active — which
        // TransportFactory::activeProvider() would then hand to every brand-new campaign.
        //
        // Guarded behind a SELECT for the same reason as the seeding block above: this function
        // runs on EVERY request, and these are the only row-level writes here. After the first
        // request that migrates the DB the check finds nothing and no write is attempted again.
        $mwCheck = $conn->query("SELECT is_active FROM email_esp_settings WHERE provider='mailwizz' LIMIT 1");
        $mwRow = $mwCheck ? $mwCheck->fetch_assoc() : null;
        if ($mwRow) {
            $conn->query("DELETE FROM email_esp_settings WHERE provider='mailwizz'");
            // If MailWizz was the active sender at that moment, nothing is active at all now:
            // activeProvider() would silently fall back to SendGrid while the Settings UI showed
            // no selected radio at all. Re-point the flag so UI and behaviour agree.
            if ((int)$mwRow['is_active'] === 1) {
                $conn->query("UPDATE email_esp_settings SET is_active=1 WHERE provider='sendgrid'");
            }
        }

        // Additive columns for servers that already had email_campaigns before these existed
        // (both are now also in the CREATE TABLE above for brand-new installs).
        $chk = $conn->query("SHOW COLUMNS FROM email_campaigns LIKE 'materialized_at'");
        if ($chk && $chk->num_rows === 0) {
            $conn->query("ALTER TABLE email_campaigns ADD COLUMN materialized_at DATETIME DEFAULT NULL AFTER completed_at");
        }
        $chk2 = $conn->query("SHOW COLUMNS FROM email_campaigns LIKE 'attachments'");
        if ($chk2 && $chk2->num_rows === 0) {
            $conn->query("ALTER TABLE email_campaigns ADD COLUMN attachments JSON DEFAULT NULL AFTER materialized_at");
        }
        $chk3 = $conn->query("SHOW COLUMNS FROM email_campaigns LIKE 'exam_cit_version'");
        if ($chk3 && $chk3->num_rows === 0) {
            $conn->query("ALTER TABLE email_campaigns ADD COLUMN exam_cit_version VARCHAR(100) DEFAULT NULL AFTER esp_transport");
        }
        $chk5 = $conn->query("SHOW COLUMNS FROM email_campaigns LIKE 'list_ids'");
        if ($chk5 && $chk5->num_rows === 0) {
            $conn->query("ALTER TABLE email_campaigns ADD COLUMN list_ids JSON DEFAULT NULL AFTER exclude_segment_ids");
        }
        $chk6 = $conn->query("SHOW COLUMNS FROM email_campaigns LIKE 'hard_bounce_count'");
        if ($chk6 && $chk6->num_rows === 0) {
            $conn->query("ALTER TABLE email_campaigns ADD COLUMN hard_bounce_count INT NOT NULL DEFAULT 0 AFTER bounce_count");
            $conn->query("ALTER TABLE email_campaigns ADD COLUMN soft_bounce_count INT NOT NULL DEFAULT 0 AFTER hard_bounce_count");
        }
        $chk7 = $conn->query("SHOW COLUMNS FROM email_campaigns LIKE 'conversion_count'");
        if ($chk7 && $chk7->num_rows === 0) {
            $conn->query("ALTER TABLE email_campaigns ADD COLUMN conversion_count INT NOT NULL DEFAULT 0 AFTER unsubscribe_count");
        }
        $chk8 = $conn->query("SHOW COLUMNS FROM email_campaign_recipients LIKE 'bounce_type'");
        if ($chk8 && $chk8->num_rows === 0) {
            $conn->query("ALTER TABLE email_campaign_recipients ADD COLUMN bounce_type ENUM('hard','soft') DEFAULT NULL AFTER click_count");
        }
        $chk9 = $conn->query("SHOW COLUMNS FROM email_campaign_events LIKE 'device_type'");
        if ($chk9 && $chk9->num_rows === 0) {
            $conn->query("ALTER TABLE email_campaign_events ADD COLUMN device_type ENUM('mobile','tablet','desktop','unknown') DEFAULT NULL AFTER meta");
        }
        $chk10 = $conn->query("SHOW COLUMNS FROM email_campaigns LIKE 'conversion_finalized'");
        if ($chk10 && $chk10->num_rows === 0) {
            $conn->query("ALTER TABLE email_campaigns ADD COLUMN conversion_finalized TINYINT(1) NOT NULL DEFAULT 0 AFTER conversion_count");
        }
        $chk11 = $conn->query("SHOW COLUMNS FROM email_campaigns LIKE 'spam_count'");
        if ($chk11 && $chk11->num_rows === 0) {
            $conn->query("ALTER TABLE email_campaigns ADD COLUMN spam_count INT NOT NULL DEFAULT 0 AFTER soft_bounce_count");
        }

        // Machine-fetch counters + the event types that feed them. Both additive: existing
        // open/click rows and counts are untouched, so nothing is retroactively reclassified —
        // only hits arriving AFTER this deploy get filtered. See lib/BotDetector.php.
        $chk12 = $conn->query("SHOW COLUMNS FROM email_campaigns LIKE 'bot_open_count'");
        if ($chk12 && $chk12->num_rows === 0) {
            $conn->query("ALTER TABLE email_campaigns ADD COLUMN bot_open_count INT NOT NULL DEFAULT 0 AFTER unique_click_count");
            $conn->query("ALTER TABLE email_campaigns ADD COLUMN bot_click_count INT NOT NULL DEFAULT 0 AFTER bot_open_count");
        }
        /*
         * Label pre-existing attribution rows as email.
         *
         * campaign_attributions is written by the user dashboard and is now SHARED with the
         * WhatsApp channel, whose campaign ids come from a different table and therefore collide
         * with email's. Both trackers filter on `medium` to stay separable — which means a row
         * with no medium counts for neither, and every row written before WhatsApp existed has
         * none. Without this, turning on that filter would drop historical email conversions to
         * zero overnight.
         *
         * Touches only unlabelled rows, so it is a no-op from the second run onward.
         */
        $hasAttr = $conn->query("SHOW TABLES LIKE 'campaign_attributions'");
        if ($hasAttr && $hasAttr->num_rows > 0) {
            $conn->query("UPDATE campaign_attributions SET medium='email'
                           WHERE medium IS NULL OR medium = ''");
        }

        $evCols = $conn->query("SHOW COLUMNS FROM email_campaign_events LIKE 'event_type'");
        $evColRow = $evCols ? $evCols->fetch_assoc() : null;
        if ($evColRow && strpos((string)$evColRow['Type'], 'open_bot') === false) {
            $conn->query("ALTER TABLE email_campaign_events MODIFY COLUMN event_type
                          ENUM('open','click','bounce','unsubscribe','spamreport','dropped','deferred','open_bot','click_bot') NOT NULL");
        }
    } catch (\Throwable $e) {
        // Another concurrent request is doing this exact same idempotent setup right now.
        // Safe to ignore — every statement above is CREATE-IF-NOT-EXISTS / INSERT-IGNORE,
        // so whichever request finishes first still leaves the schema correct, and this
        // request continues instead of fatal-erroring the page the user is looking at.
        error_log('campaigns_ensure_schema: ' . $e->getMessage());
    }
}

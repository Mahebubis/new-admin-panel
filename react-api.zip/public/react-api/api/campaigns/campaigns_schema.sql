-- Email Campaigns Builder — schema documentation.
-- These CREATE TABLE / INSERT statements are created idempotently at runtime by
-- lib/schema.php (campaigns_ensure_schema()) — this file exists as living
-- documentation, matching the convention used by internship-system/assignments_schema.sql.
--
-- Deliberately separate from the legacy `email_template` table (used by
-- communication/email_templates.php, campaign_emails.php, BulkEmail.jsx) so those
-- existing reminder-email flows are completely undisturbed by this feature.

CREATE TABLE IF NOT EXISTS email_campaigns (
    id                  INT AUTO_INCREMENT PRIMARY KEY,
    name                VARCHAR(255) NOT NULL,
    tags                VARCHAR(500) DEFAULT NULL,
    status              ENUM('draft','scheduled','running','sent','suspended','failed') NOT NULL DEFAULT 'draft',
    channel             ENUM('email') NOT NULL DEFAULT 'email',
    campaign_type       ENUM('regular','amp','ab_test','split') NOT NULL DEFAULT 'regular',

    -- Setup step "Advanced" blocks — stored only, NOT wired to any analytics pipeline
    ga_source VARCHAR(255) DEFAULT NULL, ga_medium VARCHAR(255) DEFAULT NULL, ga_campaign VARCHAR(255) DEFAULT NULL,
    ga_content VARCHAR(255) DEFAULT NULL, ga_term VARCHAR(255) DEFAULT NULL,
    goal_event_name VARCHAR(255) DEFAULT NULL, goal_window_days INT DEFAULT NULL, goal_revenue_param VARCHAR(255) DEFAULT NULL,

    -- Audience step
    audience_type       ENUM('all_contacts','segments') NOT NULL DEFAULT 'segments',
    segment_ids         JSON DEFAULT NULL,
    exclude_segment_ids JSON DEFAULT NULL,
    domain_filter       VARCHAR(255) DEFAULT NULL,
    reachable_count     INT NOT NULL DEFAULT 0,

    -- Content step
    sender_name    VARCHAR(255) DEFAULT NULL, sender_email VARCHAR(255) DEFAULT NULL, sending_domain VARCHAR(255) DEFAULT NULL,
    subject        VARCHAR(998) DEFAULT NULL, preheader VARCHAR(255) DEFAULT NULL, reply_to VARCHAR(255) DEFAULT NULL,
    template_id    INT DEFAULT NULL,
    content_html   LONGTEXT DEFAULT NULL,

    -- Schedule step
    schedule_type  ENUM('now','later') NOT NULL DEFAULT 'now',
    scheduled_at   DATETIME DEFAULT NULL,
    -- 'mailwizz' is retired (no transport class, no settings row) but stays a legal ENUM
    -- value so campaigns sent through it before its removal still read back correctly.
    esp_transport  ENUM('sendgrid','mailwizz','elasticemail') NOT NULL DEFAULT 'sendgrid',

    -- Denormalized rollup stats
    total_recipients INT NOT NULL DEFAULT 0, sent_count INT NOT NULL DEFAULT 0, delivered_count INT NOT NULL DEFAULT 0,
    open_count INT NOT NULL DEFAULT 0, unique_open_count INT NOT NULL DEFAULT 0,
    click_count INT NOT NULL DEFAULT 0, unique_click_count INT NOT NULL DEFAULT 0,
    bounce_count INT NOT NULL DEFAULT 0, unsubscribe_count INT NOT NULL DEFAULT 0,

    created_by  BIGINT UNSIGNED DEFAULT NULL,
    created_at  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    started_at DATETIME DEFAULT NULL, completed_at DATETIME DEFAULT NULL,

    INDEX idx_status_scheduled (status, scheduled_at),
    INDEX idx_created_at (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS email_campaign_recipients (
    id            BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    campaign_id   INT NOT NULL,
    user_id       BIGINT UNSIGNED DEFAULT NULL,
    email         VARCHAR(255) NOT NULL,
    first_name    VARCHAR(255) DEFAULT NULL, last_name VARCHAR(255) DEFAULT NULL, phone VARCHAR(50) DEFAULT NULL,
    is_test       TINYINT(1) NOT NULL DEFAULT 0,
    status        ENUM('pending','processing','sent','failed','bounced') NOT NULL DEFAULT 'pending',
    rid           CHAR(32) NOT NULL,
    attempts      TINYINT UNSIGNED NOT NULL DEFAULT 0,
    error_message VARCHAR(500) DEFAULT NULL,
    esp_message_id VARCHAR(255) DEFAULT NULL,
    queued_at     TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    sent_at DATETIME DEFAULT NULL, opened_at DATETIME DEFAULT NULL, first_clicked_at DATETIME DEFAULT NULL, bounced_at DATETIME DEFAULT NULL,
    open_count INT NOT NULL DEFAULT 0, click_count INT NOT NULL DEFAULT 0,

    UNIQUE INDEX uq_rid (rid),
    INDEX idx_campaign_status (campaign_id, status),
    INDEX idx_campaign_email (campaign_id, email),
    INDEX idx_esp_message_id (esp_message_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS email_campaign_events (
    id           BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    campaign_id  INT NOT NULL,
    recipient_id BIGINT UNSIGNED NOT NULL,
    event_type   ENUM('open','click','bounce','unsubscribe','spamreport','dropped','deferred') NOT NULL,
    url          TEXT DEFAULT NULL,
    ip_address   VARCHAR(45) DEFAULT NULL, user_agent VARCHAR(500) DEFAULT NULL, meta JSON DEFAULT NULL,
    created_at   TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,

    INDEX idx_campaign_type (campaign_id, event_type),
    INDEX idx_recipient (recipient_id),
    INDEX idx_created_at (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS campaign_templates (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    name            VARCHAR(255) NOT NULL,
    category        VARCHAR(100) DEFAULT NULL,
    source          ENUM('upload','editor') NOT NULL DEFAULT 'editor',
    subject_default VARCHAR(998) DEFAULT NULL,
    body_html       LONGTEXT NOT NULL,
    status          ENUM('active','archived') NOT NULL DEFAULT 'active',
    created_by      BIGINT UNSIGNED DEFAULT NULL,
    created_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_status_created (status, created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS email_esp_settings (
    id                     INT AUTO_INCREMENT PRIMARY KEY,
    provider               ENUM('sendgrid','mailwizz','elasticemail') NOT NULL,
    is_active              TINYINT(1) NOT NULL DEFAULT 0,
    api_key                VARCHAR(500) DEFAULT NULL,
    api_base_url           VARCHAR(500) DEFAULT NULL,
    list_uid               VARCHAR(100) DEFAULT NULL,
    webhook_secret         VARCHAR(255) DEFAULT NULL,
    default_sender_name    VARCHAR(255) DEFAULT NULL, default_sender_email VARCHAR(255) DEFAULT NULL, default_sending_domain VARCHAR(255) DEFAULT NULL,
    extra_config           JSON DEFAULT NULL,
    updated_at             TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE INDEX uq_provider (provider)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT IGNORE INTO email_esp_settings (provider, is_active, api_key, api_base_url, list_uid, default_sender_name, default_sender_email, default_sending_domain) VALUES
 ('sendgrid', 1, 'SG.DUMMY_KEY_REPLACE_ME', NULL, NULL, 'Internship Studio', 'alert@alert.internshipstudio.com', 'alert.internshipstudio.com'),
 ('elasticemail', 0, 'DUMMY_ELASTICEMAIL_API_KEY', NULL, NULL, 'Internship Studio', 'alert@alert.internshipstudio.com', 'alert.internshipstudio.com');

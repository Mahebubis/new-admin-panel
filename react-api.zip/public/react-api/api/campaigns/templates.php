<?php
/*
 * /api/campaigns/templates.php — Content > Template tab backend.
 *
 * action=list    &page &per_page &search &status(active|archived, default active)
 * action=get      &id
 * action=save    [&id] &name &category &subject_default &body_html
 * action=upload         &name &category  (multipart, file field: html_file)
 * action=upload_image                     (multipart, file field: image) → returns a public URL,
 *                                          used by TinyMCE's drag-and-drop / paste image handler
 * action=archive         &id
 * action=restore         &id
 * action=send_test       &id &emails (comma/newline separated)
 */
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../middleware/auth.php';
require_once __DIR__ . '/lib/config.php';
require_once __DIR__ . '/lib/schema.php';
require_once __DIR__ . '/lib/MergeTags.php';
require_once __DIR__ . '/lib/TrackingRewriter.php';
require_once __DIR__ . '/lib/AttributeResolver.php';
require_once __DIR__ . '/lib/TransportFactory.php';

campaigns_ensure_schema();
attributes_ensure_schema();

$jwt = require_jwt();
require_permission('netcore_behaviour', $jwt);

function jin($k, $d = null) { $v = $_REQUEST[$k] ?? null; return ($v === null || $v === '') ? $d : $v; }
function strip_preview($html, $len = 140) {
    $text = trim(preg_replace('/\s+/', ' ', strip_tags((string)$html)));
    return mb_strlen($text) > $len ? mb_substr($text, 0, $len) . '…' : $text;
}

$action = jin('action', '');

if ($action === 'list') {
    $page    = max(1, (int)jin('page', 1));
    $perPage = max(1, min(100, (int)jin('per_page', 12)));
    $search  = trim((string)jin('search', ''));
    $status  = jin('status', 'active');
    $offset  = ($page - 1) * $perPage;

    $where = ["status='" . $conn->real_escape_string($status) . "'"];
    if ($search !== '') $where[] = "name LIKE '%" . $conn->real_escape_string($search) . "%'";
    $whereSql = 'WHERE ' . implode(' AND ', $where);

    $tr = $conn->query("SELECT COUNT(*) AS c FROM campaign_templates $whereSql");
    $total = $tr ? (int)$tr->fetch_assoc()['c'] : 0;

    $r = $conn->query("SELECT id, name, category, source, subject_default, body_html, status, created_at, updated_at
                        FROM campaign_templates $whereSql
                        ORDER BY id DESC LIMIT $perPage OFFSET $offset");
    $rows = [];
    while ($r && $row = $r->fetch_assoc()) {
        // body_html IS included here (unlike an earlier version of this endpoint) so the
        // gallery can render a real scaled-down thumbnail instead of a plain text snippet —
        // per_page is capped at 100 and email HTML is typically a few KB to ~50KB, so this
        // stays a reasonable payload even at full page size.
        $row['preview'] = strip_preview($row['body_html']);
        $rows[] = $row;
    }
    api_success(['templates' => $rows, 'total' => $total, 'page' => $page, 'per_page' => $perPage,
                 'pages' => $total > 0 ? (int)ceil($total / $perPage) : 1]);
}

if ($action === 'get') {
    $id = (int)jin('id', 0);
    $r = $conn->query("SELECT * FROM campaign_templates WHERE id=$id LIMIT 1");
    $row = $r ? $r->fetch_assoc() : null;
    if (!$row) api_error('Not found', 404);
    api_success(['template' => $row]);
}

if ($action === 'save') {
    $id       = (int)jin('id', 0);
    $name     = trim((string)jin('name', ''));
    $category = trim((string)jin('category', ''));
    $subject  = trim((string)jin('subject_default', ''));
    $html     = (string)jin('body_html', '');
    if ($name === '') api_error('Template name required');
    if ($id === 0 && trim($html) === '') api_error('Template content is empty');

    $nameE = $conn->real_escape_string($name);
    $catE  = $conn->real_escape_string($category);
    $subE  = $conn->real_escape_string($subject);
    $htmlE = $conn->real_escape_string($html);

    if ($id > 0) {
        $conn->query("UPDATE campaign_templates SET name='$nameE', category='$catE', subject_default='$subE', body_html='$htmlE' WHERE id=$id");
    } else {
        $conn->query("INSERT INTO campaign_templates (name, category, source, subject_default, body_html, created_by)
                      VALUES ('$nameE', '$catE', 'editor', '$subE', '$htmlE', " . (int)($jwt['user_id'] ?? 0) . ")");
        $id = $conn->insert_id;
    }
    api_success(['id' => $id]);
}

if ($action === 'upload') {
    $name     = trim((string)jin('name', ''));
    $category = trim((string)jin('category', ''));
    if ($name === '') api_error('Template name required');
    if (empty($_FILES['html_file']) || $_FILES['html_file']['error'] !== UPLOAD_ERR_OK) api_error('Upload a .html file');

    $file = $_FILES['html_file'];
    if ($file['size'] > 2 * 1024 * 1024) api_error('File too large (max 2MB)');
    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    if (!in_array($ext, ['htm', 'html'], true)) api_error('Only .htm/.html files are supported');

    $html = file_get_contents($file['tmp_name']);
    if ($html === false || trim($html) === '') api_error('Could not read the uploaded file');

    $nameE = $conn->real_escape_string($name);
    $catE  = $conn->real_escape_string($category);
    $htmlE = $conn->real_escape_string($html);
    $conn->query("INSERT INTO campaign_templates (name, category, source, body_html, created_by)
                  VALUES ('$nameE', '$catE', 'upload', '$htmlE', " . (int)($jwt['user_id'] ?? 0) . ")");
    api_success(['id' => $conn->insert_id]);
}

if ($action === 'upload_image') {
    if (empty($_FILES['image']) || $_FILES['image']['error'] !== UPLOAD_ERR_OK) api_error('Choose an image to upload');
    $file = $_FILES['image'];

    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    if (!in_array($ext, TEMPLATE_IMAGE_ALLOWED_EXT, true)) {
        api_error('Only ' . implode(', ', TEMPLATE_IMAGE_ALLOWED_EXT) . ' images are supported');
    }
    if ($file['size'] > TEMPLATE_IMAGE_MAX_BYTES) {
        api_error('Image too large — max ' . (TEMPLATE_IMAGE_MAX_BYTES / 1024 / 1024) . 'MB');
    }

    if (!is_dir(TEMPLATE_IMAGES_DIR) && !mkdir(TEMPLATE_IMAGES_DIR, 0755, true) && !is_dir(TEMPLATE_IMAGES_DIR)) {
        api_error('Could not create the uploads folder');
    }
    $storedName = bin2hex(random_bytes(8)) . '.' . $ext;
    if (!move_uploaded_file($file['tmp_name'], TEMPLATE_IMAGES_DIR . '/' . $storedName)) {
        api_error('Could not save the uploaded image');
    }

    // Shape matches what the frontend's TinyMCE images_upload_handler reads back out
    // (data.location) — see AddBlog.jsx-style self-hosted TinyMCE setup in TemplateEditor.jsx.
    api_success(['location' => TEMPLATE_IMAGES_PUBLIC_URL . '/' . $storedName]);
}

if ($action === 'archive') {
    $id = (int)jin('id', 0);
    $conn->query("UPDATE campaign_templates SET status='archived' WHERE id=$id");
    api_success([]);
}

if ($action === 'restore') {
    $id = (int)jin('id', 0);
    $conn->query("UPDATE campaign_templates SET status='active' WHERE id=$id");
    api_success([]);
}

if ($action === 'send_test') {
    $id = (int)jin('id', 0);
    $r = $conn->query("SELECT * FROM campaign_templates WHERE id=$id LIMIT 1");
    $tpl = $r ? $r->fetch_assoc() : null;
    if (!$tpl) api_error('Not found', 404);

    $emailsRaw = (string)jin('emails', '');
    $emails = array_values(array_filter(array_map('trim', preg_split('/[,;\n]+/', $emailsRaw))));
    if (!$emails) api_error('Enter at least one test email address');

    $provider = TransportFactory::activeProvider();
    $transport = TransportFactory::forProvider($provider);
    $esR = $conn->query("SELECT default_sender_name, default_sender_email FROM email_esp_settings WHERE provider='" . $conn->real_escape_string($provider) . "' LIMIT 1");
    $es = $esR ? $esR->fetch_assoc() : [];
    $fromName  = $es['default_sender_name'] ?? 'Internship Studio';
    $fromEmail = $es['default_sender_email'] ?? 'alert@alert.internshipstudio.com';

    $results = [];
    foreach ($emails as $email) {
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $results[] = ['email' => $email, 'ok' => false, 'error' => 'Invalid email address'];
            continue;
        }
        if (!$transport) {
            $results[] = ['email' => $email, 'ok' => false, 'error' => 'ESP not configured — set an API key in Settings'];
            continue;
        }
        // If the test address happens to belong to a real registered student, use their
        // real user_id/name so mapped Attributes resolve correctly instead of always
        // looking like an anonymous 'Test User' with nothing to look up.
        $emailE = $conn->real_escape_string($email);
        $uRes = $conn->query("SELECT user_id, fname, lname FROM users WHERE email='$emailE' LIMIT 1");
        $uRow = $uRes ? $uRes->fetch_assoc() : null;
        $testUserId = $uRow['user_id'] ?? null;
        $testFname = $uRow['fname'] ?? 'Test';
        $testLname = $uRow['lname'] ?? 'User';

        $recipient = ['email' => $email, 'user_id' => $testUserId, 'first_name' => $testFname, 'last_name' => $testLname, 'phone' => ''];
        $attributes = load_all_attributes();
        $attrTokens = $attributes ? (resolve_attribute_values_batch($attributes, [$recipient])[strtolower($email)] ?? []) : [];

        $subject = substitute_merge_tags((string)($tpl['subject_default'] ?: $tpl['name']), $recipient, $attrTokens);
        $html = substitute_merge_tags((string)$tpl['body_html'], $recipient, $attrTokens);
        $banner = '<div style="background:#fef3c7;color:#92400e;padding:8px 14px;font:600 12px sans-serif;border-radius:6px;margin-bottom:12px;">TEST EMAIL — template preview, no tracking recorded</div>';
        $res = $transport->sendEmail($email, '[TEST] ' . $subject, $banner . $html, $fromName, $fromEmail, null, null);
        $results[] = ['email' => $email, 'ok' => $res['ok'], 'error' => $res['error'] ?? null];
    }
    api_success(['results' => $results]);
}

api_error('Invalid action');

<?php
/*
 * /api/campaigns/settings.php — SendGrid / Elastic Email credentials.
 * Seeded with dummy placeholder values by lib/schema.php; pasting real
 * credentials here is a pure data change, no code/deploy needed.
 *
 * action=get                                     → both provider rows (api_key masked)
 * action=save   &provider &is_active &api_key &api_base_url &list_uid
 *               &webhook_secret &default_sender_name &default_sender_email &default_sending_domain
 */
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../middleware/auth.php';
require_once __DIR__ . '/lib/config.php';
require_once __DIR__ . '/lib/schema.php';
require_once __DIR__ . '/lib/TransportFactory.php';

campaigns_ensure_schema();

$jwt = require_jwt();
require_permission('netcore_behaviour', $jwt);

function jin($k, $d = null) { $v = $_REQUEST[$k] ?? null; return ($v === null || $v === '') ? $d : $v; }
function mask_key($k) {
    $k = (string)$k;
    if (strlen($k) <= 8) return str_repeat('•', max(0, strlen($k) - 2)) . substr($k, -2);
    return substr($k, 0, 4) . str_repeat('•', 8) . substr($k, -4);
}

$action = jin('action', '');

if ($action === 'get') {
    // Filtered to the currently-supported providers rather than SELECT *: a retired
    // provider whose row somehow survives (e.g. an old mailwizz row on a DB that hasn't
    // run this release's migration yet) must not show up as an editable card.
    $inList = "'" . implode("','", array_map([$conn, 'real_escape_string'], TransportFactory::PROVIDERS)) . "'";
    $r = $conn->query("SELECT * FROM email_esp_settings WHERE provider IN ($inList) ORDER BY FIELD(provider, $inList)");
    $rows = [];
    while ($r && $row = $r->fetch_assoc()) {
        $row['api_key_masked'] = mask_key($row['api_key']);
        unset($row['api_key']); // never return the raw key to the client
        // MUST be cast. mysqli hands TINYINT back as the STRING "0"/"1", which JSON-encodes as
        // "0" — and in JavaScript `!!"0"` is TRUE, because it's a non-empty string. That made
        // the Settings page draw EVERY provider as the active sender, whichever one actually
        // was. Returning a real int is the fix; the frontend also compares numerically now.
        $row['is_active'] = (int)$row['is_active'];
        $rows[] = $row;
    }
    api_success(['settings' => $rows]);
}

if ($action === 'save') {
    $provider = jin('provider', '');
    if (!in_array($provider, TransportFactory::PROVIDERS, true)) api_error('Invalid provider');

    $set = [];
    $fields = ['api_key' => 's', 'api_base_url' => 's', 'list_uid' => 's', 'webhook_secret' => 's',
               'default_sender_name' => 's', 'default_sender_email' => 's', 'default_sending_domain' => 's'];
    foreach ($fields as $f => $type) {
        $v = jin($f, null);
        if ($v === null) continue;
        // api_key: leave untouched if the client sent back the masked placeholder (didn't actually change it)
        if ($f === 'api_key' && strpos((string)$v, '•') !== false) continue;
        $set[] = "$f='" . $conn->real_escape_string((string)$v) . "'";
    }

    $isActive = jin('is_active', null);
    if ($isActive !== null) {
        if ((int)$isActive === 1) {
            // only one provider can be "active" (the one new campaigns default to)
            $conn->query("UPDATE email_esp_settings SET is_active=0");
        }
        $set[] = "is_active=" . ((int)$isActive === 1 ? 1 : 0);
    }

    if ($set) {
        $provE = $conn->real_escape_string($provider);
        $conn->query("UPDATE email_esp_settings SET " . implode(', ', $set) . " WHERE provider='$provE'");
    }
    api_success([]);
}

api_error('Invalid action');

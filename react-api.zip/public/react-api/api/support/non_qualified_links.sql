-- ============================================================
-- WhatsApp for Non Qualified — community-link table.
-- Mirrors `whatsapp_placement_club_link_for_refund`.
-- Run once on the istudio_cit database.
-- ============================================================

CREATE TABLE IF NOT EXISTS `whatsapp_placement_club_link_for_non_qualified` (
  `id`             INT(11)      NOT NULL AUTO_INCREMENT,
  `community_name` VARCHAR(255) NOT NULL DEFAULT '',
  `community_link` VARCHAR(512) NOT NULL DEFAULT '',
  `status`         ENUM('active','pending','closed') NOT NULL DEFAULT 'pending',
  `activated_at`   DATETIME     DEFAULT NULL,
  `closed_at`      DATETIME     DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_status` (`status`),
  KEY `idx_community_name` (`community_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- Stores which non-qualified community link each student was
-- assigned. Mirrors `assigned_links_for_refund` (which itself
-- mirrors the generic `assigned_links`):
--   assigned_id -> whatsapp_placement_club_link_for_non_qualified.id
-- ============================================================
CREATE TABLE IF NOT EXISTS `assigned_links_for_non_qualified` (
  `id`          INT(11)     NOT NULL AUTO_INCREMENT,
  `user_id`     BIGINT(20)  NOT NULL,
  `assigned_id` INT(11)     NOT NULL,
  `assigned_at` DATETIME    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`  DATETIME    NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_assigned_id` (`assigned_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Dedicated settings key the backend writes the current active link to
-- (only updated when the active link's initials match the current CIT).
INSERT INTO `settings` (`settings_key`, `settings_value`)
SELECT 'wa_cit_non_qualified_club', ''
WHERE NOT EXISTS (
  SELECT 1 FROM `settings` WHERE `settings_key` = 'wa_cit_non_qualified_club'
);

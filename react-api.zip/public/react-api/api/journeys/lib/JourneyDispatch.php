<?php
/*
 * /api/journeys/lib/JourneyDispatch.php
 *
 * Everything between "the engine decided to send" and "the provider answered".
 *
 * Message nodes never call a transport directly. They call journey_dispatch(),
 * which runs the same five gates in the same order every time:
 *
 *   1. control group   — held-out students walk the graph but receive nothing
 *   2. address         — no email / no phone is a suppression, not a crash
 *   3. frequency cap   — SKIP the message, keep the student (see below)
 *   4. DND             — HOLD the message to the end of the quiet window
 *   5. idempotency     — one row per (entry, node, attempt), inserted before the send
 *
 * ── Two deliberate departures from Netcore ───────────────────────────────────
 *
 * Frequency cap: Netcore REMOVES a user from the journey when a message is
 * capped. A student who hits their daily cap at step 3 of a 7-step onboarding
 * silently loses the remaining four. We skip the message, log
 * suppress_reason='frequency_cap', and continue to the next node. Per-journey
 * ignore_fc / counts_toward_fc (MoEngage's model) let operational journeys —
 * exam-day, payment failure — bypass the cap while still counting toward it for
 * marketing ones.
 *
 * DND: messages are HELD, not dropped, exactly as Netcore does. A send that
 * lands inside a quiet window is rescheduled to the moment the window ends, so a
 * Saturday-night trigger goes out Monday morning rather than vanishing.
 * Evaluated in the journey's timezone (default Asia/Kolkata), not the student's —
 * a single-country student base does not justify per-user timezones.
 */

require_once __DIR__ . '/../../../config/database.php';
require_once __DIR__ . '/JourneyGraph.php';
require_once __DIR__ . '/JourneyConditions.php';
// Explicit, not left to load order: journey_attr_campaign_id() and JOURNEY_ATTR_MEDIUM are used
// in the WhatsApp send below, and today they happen to be loaded first only because JourneyEngine
// requires them a line later. That is a fatal waiting for the day something loads this file alone.
require_once __DIR__ . '/JourneyWebhookSink.php';

require_once __DIR__ . '/../../campaigns/lib/config.php';
require_once __DIR__ . '/../../campaigns/lib/MergeTags.php';
require_once __DIR__ . '/../../campaigns/lib/TrackingRewriter.php';
require_once __DIR__ . '/../../campaigns/lib/EspTransport.php';
require_once __DIR__ . '/../../campaigns/lib/TransportFactory.php';
require_once __DIR__ . '/../../campaigns/lib/AudienceResolver.php';

if (!defined('JOURNEYS_PUBLIC_BASE_URL')) {
    define('JOURNEYS_PUBLIC_BASE_URL', 'https://cit3.internshipstudio.com/admin/react-api/api/journeys');
}
/** Sends are attempted at most this many times before the message is marked failed. */
if (!defined('JOURNEY_MAX_SEND_ATTEMPTS')) define('JOURNEY_MAX_SEND_ATTEMPTS', 3);

/* ════════════════════════════════════════════════════════════════════════════
   Result shape
   Every function here returns one of these, and the engine branches on 'outcome':
     sent       → take the node's Sent / Called branch
     failed     → take the Failed branch
     suppressed → take the Sent branch anyway (the student continues; only the
                  message was withheld) and record why
     hold       → do not advance; re-queue the same node at 'retry_at' (DND)
   ═══════════════════════════════════════════════════════════════════════════ */
function journey_result(string $outcome, string $detail = '', array $extra = []): array {
    return array_merge(['outcome' => $outcome, 'detail' => $detail], $extra);
}

/* ════════════════════════════════════════════════════════════════════════════
   Gate 3 — frequency capping
   ═══════════════════════════════════════════════════════════════════════════ */

/**
 * How many journey messages this student has already been SENT today, counting
 * only journeys whose counts_toward_fc is on. Deliberately counts across all
 * journeys, not just this one: a cap that only looks at its own journey is not a
 * cap, it is a per-journey quota.
 */
function journey_messages_today(int $userId, string $channel, string $scope = 'channel'): int {
    global $conn;
    if ($userId <= 0) return 0;
    // 'channel' scope counts only sends on the same channel, so a WhatsApp step cannot
    // consume the allowance an email step was relying on.
    $chWhere = $scope === 'all' ? '' : " AND m.channel = '" . $conn->real_escape_string($channel) . "'";
    $r = @$conn->query("SELECT COUNT(*) c
                          FROM journey_messages m
                          INNER JOIN journeys j ON j.id = m.journey_id
                         WHERE m.user_id = " . (int)$userId . "
                           AND m.status = 'sent'
                           AND m.sent_at >= CURDATE()
                           AND j.counts_toward_fc = 1"
                         . $chWhere);
    $row = $r ? $r->fetch_assoc() : null;
    return (int)($row['c'] ?? 0);
}

/* ════════════════════════════════════════════════════════════════════════════
   Gate 4 — Do Not Disturb
   ═══════════════════════════════════════════════════════════════════════════ */

/**
 * If $whenTs falls inside a blocking window, returns the timestamp the window
 * ends (when the message may go out). Returns null when the send is allowed now.
 *
 * dnd_config is [{day:0..6 (Sun..Sat), enabled, from:'HH:MM', to:'HH:MM'}].
 * A window whose `to` is earlier than its `from` spans midnight and is checked as
 * two intervals — [from, 24:00) today and [00:00, to) tomorrow — which is the
 * case the naive implementation always gets wrong.
 */
function journey_dnd_hold_until(array $journey, int $whenTs): ?int {
    if (empty($journey['dnd_enabled']) || !empty($journey['ignore_dnd'])) return null;

    $cfg = json_decode((string)($journey['dnd_config'] ?? '[]'), true);
    if (!is_array($cfg) || !$cfg) return null;

    $tz = new DateTimeZone((string)($journey['timezone'] ?: 'Asia/Kolkata'));
    $now = (new DateTime('@' . $whenTs))->setTimezone($tz);

    $byDay = [];
    foreach ($cfg as $row) $byDay[(int)($row['day'] ?? -1)] = $row;

    $mins = fn(string $hm) => (int)substr($hm, 0, 2) * 60 + (int)substr($hm, 3, 2);

    // Check today's window, and yesterday's if it crossed midnight into today.
    for ($back = 0; $back <= 1; $back++) {
        $day  = (clone $now)->modify("-$back day");
        $dow  = (int)$day->format('w');
        $row  = $byDay[$dow] ?? null;
        if (!$row || empty($row['enabled'])) continue;

        $from = $mins((string)($row['from'] ?? '21:00'));
        $to   = $mins((string)($row['to']   ?? '09:30'));
        $cur  = (int)$now->format('G') * 60 + (int)$now->format('i');

        if ($from === $to) continue;                     // zero-length window blocks nothing

        if ($from < $to) {
            if ($back > 0) continue;                     // same-day window, yesterday is irrelevant
            if ($cur >= $from && $cur < $to) {
                $end = (clone $now)->setTime(intdiv($to, 60), $to % 60, 0);
                return $end->getTimestamp();
            }
        } else {
            // Spans midnight.
            if ($back === 0 && $cur >= $from) {          // evening portion → ends tomorrow morning
                $end = (clone $now)->modify('+1 day')->setTime(intdiv($to, 60), $to % 60, 0);
                return $end->getTimestamp();
            }
            if ($back === 1 && $cur < $to) {             // morning portion of yesterday's window
                $end = (clone $now)->setTime(intdiv($to, 60), $to % 60, 0);
                return $end->getTimestamp();
            }
        }
    }
    return null;
}

/* ════════════════════════════════════════════════════════════════════════════
   Message row bookkeeping
   ═══════════════════════════════════════════════════════════════════════════ */

/**
 * Claim the right to send. The UNIQUE index on idem_key is the actual guard: two
 * worker ticks racing on the same entry both try this INSERT and exactly one wins.
 * The loser gets null and skips the send entirely — which is what stops the
 * duplicate-message failure Netcore documents (A9.2) from ever being possible here.
 */
function journey_claim_message(array $ctx, string $channel, ?string $toAddr): ?array {
    global $conn;

    $idem = $ctx['entry_id'] . ':' . $ctx['node_id'] . ':' . (int)($ctx['attempt'] ?? 1);
    $rid  = bin2hex(random_bytes(16));

    $stmt = $conn->prepare(
        "INSERT INTO journey_messages (journey_id, entry_id, node_id, user_id, channel, to_addr, rid, idem_key, status, variant)
         VALUES (?,?,?,?,?,?,?,?, 'queued', ?)"
    );
    if (!$stmt) return null;

    $jid = (int)$ctx['journey_id']; $eid = (int)$ctx['entry_id'];
    $nid = (string)$ctx['node_id']; $uid = (int)($ctx['user_id'] ?? 0);
    $to  = (string)($toAddr ?? '');
    $var = (string)($ctx['variant'] ?? '');
    $stmt->bind_param('iisisssss', $jid, $eid, $nid, $uid, $channel, $to, $rid, $idem, $var);

    $ok = @$stmt->execute();
    $id = $ok ? (int)$conn->insert_id : 0;
    $stmt->close();

    if (!$ok || !$id) return null;                    // duplicate idem_key → someone else owns this send
    return ['id' => $id, 'rid' => $rid];
}

function journey_message_suppress(array $ctx, string $channel, ?string $toAddr, string $reason, string $detail = ''): array {
    global $conn;
    $claim = journey_claim_message($ctx, $channel, $toAddr);
    if ($claim) {
        $r = $conn->real_escape_string($reason);
        $d = $conn->real_escape_string(mb_substr($detail, 0, 480));
        @$conn->query("UPDATE journey_messages
                          SET status='suppressed', suppress_reason='$r', error_message='$d'
                        WHERE id=" . (int)$claim['id']);
        @$conn->query("UPDATE journeys SET suppressed_count = suppressed_count + 1 WHERE id=" . (int)$ctx['journey_id']);
    }
    return journey_result('suppressed', $detail !== '' ? $detail : $reason, ['reason' => $reason]);
}

function journey_message_mark(int $messageId, string $status, array $fields = []): void {
    global $conn;
    $sets = ["status='" . $conn->real_escape_string($status) . "'"];
    if ($status === 'sent') $sets[] = 'sent_at = NOW()';
    $sets[] = 'attempts = attempts + 1';
    foreach ($fields as $k => $v) {
        if ($v === null) { $sets[] = "`$k` = NULL"; continue; }
        $sets[] = "`$k` = '" . $conn->real_escape_string(mb_substr((string)$v, 0, 480)) . "'";
    }
    @$conn->query("UPDATE journey_messages SET " . implode(', ', $sets) . " WHERE id = " . (int)$messageId);
}

/* ════════════════════════════════════════════════════════════════════════════
   The gate runner
   ═══════════════════════════════════════════════════════════════════════════ */

/**
 * @param array $journey  the journeys row (typed columns, not the settings blob)
 * @param array $entry    the journey_entries row
 * @param array $node     the graph node
 * @param array $ctx      ['journey_id','entry_id','node_id','user_id','attempt','variant']
 */
function journey_dispatch(array $journey, array $entry, array $node, array $ctx): array {
    // The one-per-student gate below queries directly, so the connection has to be in
    // scope. Without this it is null and every dispatch dies with "Call to a member
    // function query() on null" — which stops the entry before any message is attempted.
    global $conn;

    $T = journey_node_types();
    $channel = $T[$node['key']]['channel'] ?? null;
    if (!$channel) return journey_result('failed', 'Node ' . $node['key'] . ' is not a message node.');

    $cfg = $node['cfg'] ?? [];

    /* ── 1. control group ── */
    if (!empty($entry['is_control'])) {
        return journey_message_suppress($ctx, $channel, null, 'control_group',
            'Held out for incrementality measurement.');
    }

    /* ── 2. address ── */
    $to = $channel === 'email' ? trim((string)($entry['email'] ?? ''))
        : ($channel === 'whatsapp' ? trim((string)($entry['phone'] ?? '')) : null);

    if ($channel !== 'webhook') {
        if ($to === '' || $to === null) {
            return journey_message_suppress($ctx, $channel, null, 'no_address',
                'Student has no ' . ($channel === 'email' ? 'email address' : 'phone number') . ' on file.');
        }
        if ($channel === 'email' && journey_is_blocklisted($to)) {
            return journey_message_suppress($ctx, $channel, $to, 'blocklisted', 'Address is on the blocklist.');
        }
    }

    /* ── 2b. one message per student, if this journey is set that way ──
       A journey normally messages someone at every message step it walks them
       through — that IS the follow-up. This switch collapses it to a single
       message per student for the whole journey, for the case where the graph
       exists to pick ONE channel per person rather than to run a sequence. */
    if ($channel !== 'webhook' && !empty($journey['one_per_student'])) {
        $uid = (int)($entry['user_id'] ?? 0);
        if ($uid > 0) {
            $r = $conn->query("SELECT id FROM journey_messages
                                WHERE journey_id = " . (int)$journey['id'] . "
                                  AND user_id = $uid AND status = 'sent' LIMIT 1");
            if ($r && $r->num_rows > 0) {
                return journey_message_suppress($ctx, $channel, $to, 'already_messaged',
                    'This journey is set to send at most one message per student, and this student '
                    . 'already received one. They continue to the next step.');
            }
        }
    }

    /* ── 3. frequency cap ── */
    if ($channel !== 'webhook' && !empty($journey['fc_enabled']) && empty($journey['ignore_fc'])) {
        $capN  = max(1, (int)$journey['fc_max_per_day']);
        $scope = ($journey['fc_scope'] ?? 'channel') === 'all' ? 'all' : 'channel';
        $used  = journey_messages_today((int)($entry['user_id'] ?? 0), $channel, $scope);
        if ($used >= $capN) {
            // NOT an exit. The student stays in the journey and continues.
            // The reason names the scope, because "capped" without saying WHAT was
            // counted is the single most confusing message this engine can produce —
            // the cap spans every journey, so the culprit is usually somewhere else.
            $what = $scope === 'all' ? 'messages on any channel' : ucfirst($channel) . ' messages';
            return journey_message_suppress($ctx, $channel, $to, 'frequency_cap',
                "Already had $used/$capN $what today across all journeys, so this one was skipped. "
                . 'The student continues to the next step.');
        }
    }

    /* ── 4. DND ── */
    if ($channel !== 'webhook') {
        $holdUntil = journey_dnd_hold_until($journey, time());
        if ($holdUntil !== null) {
            return journey_result('hold', 'Quiet hours — held until ' . date('Y-m-d H:i', $holdUntil) . '.',
                                  ['retry_at' => $holdUntil]);
        }
    }

    /* ── 5. claim + send ── */
    $claim = journey_claim_message($ctx, $channel, $to);
    if (!$claim) {
        // Another tick already owns this exact (entry, node, attempt).
        return journey_result('suppressed', 'Already dispatched by a concurrent run.', ['reason' => 'duplicate']);
    }

    try {
        switch ($channel) {
            case 'email':    return journey_send_email($journey, $entry, $cfg, $claim, $ctx);
            case 'whatsapp': return journey_send_whatsapp($journey, $entry, $cfg, $claim, $ctx);
            case 'webhook':  return journey_call_webhook($journey, $entry, $cfg, $claim, $ctx);
        }
        journey_message_mark($claim['id'], 'suppressed', ['suppress_reason' => 'not_configured']);
        return journey_result('suppressed', ucfirst($channel) . ' has no sending provider on this server.',
                              ['reason' => 'not_configured']);
    } catch (Throwable $e) {
        journey_message_mark($claim['id'], 'failed', ['error_message' => $e->getMessage()]);
        return journey_result('failed', $e->getMessage());
    }
}

/* ════════════════════════════════════════════════════════════════════════════
   Email
   ═══════════════════════════════════════════════════════════════════════════ */

function journey_send_email(array $journey, array $entry, array $cfg, array $claim, array $ctx): array {
    global $conn;

    $tplRef = (string)($cfg['template'] ?? '');
    $tpl = journey_lookup_email_template($tplRef);
    if (!$tpl) {
        journey_message_mark($claim['id'], 'failed', ['error_message' => "Email template '$tplRef' not found"]);
        return journey_result('failed', "Email template '$tplRef' no longer exists.");
    }

    $provider  = TransportFactory::activeProvider();
    $transport = TransportFactory::forProvider($provider);
    if (!$transport || !$transport->isConfigured()) {
        journey_message_mark($claim['id'], 'suppressed',
            ['suppress_reason' => 'not_configured', 'error_message' => "ESP '$provider' is not configured"]);
        return journey_result('suppressed', "Email provider '$provider' is not configured in Settings.",
                              ['reason' => 'not_configured']);
    }

    /*
     * Sender identity, in the same shape the campaign wizard's Content step uses:
     * a name, a local part, and a sending domain picked separately. Each piece falls
     * back to the ESP settings default when the node leaves it blank, so an existing
     * step configured before these fields existed keeps sending exactly as it did.
     */
    $sr = $conn->query("SELECT * FROM email_esp_settings WHERE provider = '" . $conn->real_escape_string($provider) . "' LIMIT 1");
    $esp = $sr ? $sr->fetch_assoc() : [];

    $defaultFrom = (string)($esp['default_sender_email'] ?? '');
    $defaultLocal = strpos($defaultFrom, '@') !== false ? substr($defaultFrom, 0, strpos($defaultFrom, '@')) : $defaultFrom;

    $fromName = trim((string)($cfg['senderName'] ?? '')) !== ''
        ? (string)$cfg['senderName'] : (string)($esp['default_sender_name'] ?? 'Internship Studio');

    $local  = trim((string)($cfg['senderLocal'] ?? '')) !== '' ? trim((string)$cfg['senderLocal']) : $defaultLocal;
    $domain = trim((string)($cfg['from'] ?? '')) !== ''
        ? trim((string)$cfg['from']) : (string)($esp['default_sending_domain'] ?? '');
    $fromEmail = ($local !== '' && $domain !== '') ? ($local . '@' . $domain) : $defaultFrom;

    $replyTo = trim((string)($cfg['replyTo'] ?? ''));
    if ($replyTo !== '' && !filter_var($replyTo, FILTER_VALIDATE_EMAIL)) $replyTo = '';

    if ($fromEmail === '') {
        journey_message_mark($claim['id'], 'suppressed',
            ['suppress_reason' => 'not_configured', 'error_message' => 'No sender address configured']);
        return journey_result('suppressed', 'No sender address is configured for email.', ['reason' => 'not_configured']);
    }

    $recipient = [
        'first_name' => $entry['first_name'] ?? '',
        'last_name'  => $entry['last_name'] ?? '',
        'email'      => $entry['email'] ?? '',
        'phone'      => $entry['phone'] ?? '',
    ];
    $subject = trim((string)($cfg['subject'] ?? '')) !== ''
        ? (string)$cfg['subject'] : (string)($tpl['subject_default'] ?? $tpl['name']);
    $subject = substitute_merge_tags($subject, $recipient);
    $html    = substitute_merge_tags((string)$tpl['body_html'], $recipient);

    // The hidden pre-header is the text most inboxes show next to the subject line, so
    // it has to be spliced into the HTML itself — storing it on the node is not enough.
    $preheader = trim((string)($cfg['preheader'] ?? ''));
    if ($preheader !== '') $html = inject_preheader($html, substitute_merge_tags($preheader, $recipient));

    // Same open-pixel + click-rewrite pipeline the campaigns use, pointed at this
    // feature's own endpoints so a rid resolves against journey_messages.
    $html = inject_tracking($html, $claim['rid'], JOURNEYS_PUBLIC_BASE_URL);

    $res = $transport->sendEmail((string)$entry['email'], $subject, $html, $fromName, $fromEmail,
                                 $replyTo !== '' ? $replyTo : null, $claim['rid'],
                                 journey_load_attachments($cfg));

    $conn->query("UPDATE journey_messages SET subject = '" . $conn->real_escape_string(mb_substr($subject, 0, 990)) . "',
                         provider = '" . $conn->real_escape_string($provider) . "'
                   WHERE id = " . (int)$claim['id']);

    // The transport contract is ['ok' => bool, ...] — see EspTransport's docblock and
    // SendWorker.php, which both read 'ok'. This checked 'success', which no transport
    // ever sets, so EVERY email was recorded as failed with a null error ("Unknown ESP
    // error") even when SendGrid had accepted it.
    if (!empty($res['ok'])) {
        journey_message_mark($claim['id'], 'sent', ['provider_message_id' => $res['message_id'] ?? null]);
        return journey_result('sent', 'Email sent to ' . $entry['email']);
    }

    $err = (string)($res['error'] ?? 'The email provider rejected the send without giving a reason.');
    journey_message_mark($claim['id'], 'failed', ['error_message' => $err]);
    return journey_result('failed', 'Email failed: ' . $err);
}

/**
 * Pulls a step's attachments from S3 and base64-encodes them for the transport.
 *
 * Cached per node for the life of the worker run: a journey step with a 2MB PDF
 * would otherwise re-download it from S3 once per student, which at a few hundred
 * entries a tick is minutes of pointless transfer. Campaigns solve the same problem
 * by loading once per batch (see load_campaign_attachments); this is the per-node
 * equivalent. A file that has gone missing is skipped rather than failing the send —
 * a deleted attachment must not stop a student's journey.
 */
function journey_load_attachments(array $cfg): array {
    static $cache = [];
    $list = $cfg['attachments'] ?? [];
    if (!is_array($list) || !$list) return [];

    $ck = md5(json_encode($list));
    if (isset($cache[$ck])) return $cache[$ck];

    require_once __DIR__ . '/../../lib/S3Uploader.php';
    $out = [];
    foreach ($list as $a) {
        $url = $a['s3_url'] ?? '';
        if ($url === '') continue;
        $bytes = s3_fetch_bytes($url);
        if ($bytes === null) { journey_cond_log('attachment unreachable, skipped: ' . $url); continue; }
        $out[] = [
            'filename' => $a['filename'] ?? basename($url),
            'content'  => base64_encode($bytes),
            'type'     => $a['mime'] ?? 'application/octet-stream',
        ];
    }
    if (count($cache) > 20) $cache = [];
    $cache[$ck] = $out;
    return $out;
}

/** Accepts a template id or a name — the builder stored names before it had real data. */
function journey_lookup_email_template(string $ref): ?array {
    global $conn;
    if ($ref === '') return null;
    if (is_numeric($ref)) {
        $r = $conn->query("SELECT * FROM campaign_templates WHERE id = " . (int)$ref . " LIMIT 1");
        $row = $r ? $r->fetch_assoc() : null;
        if ($row) return $row;
    }
    $esc = $conn->real_escape_string($ref);
    $r = $conn->query("SELECT * FROM campaign_templates WHERE name = '$esc' AND status = 'active' LIMIT 1");
    return $r ? ($r->fetch_assoc() ?: null) : null;
}

/* ════════════════════════════════════════════════════════════════════════════
   WhatsApp
   ═══════════════════════════════════════════════════════════════════════════ */

/**
 * Reuses the campaign renderer rather than reimplementing template rendering:
 * wa_render_for_recipient() takes an array shaped like a wa_campaigns row, so we
 * synthesise one from the wa_templates row plus the node's variable mapping. That
 * keeps journeys on exactly the same Meta/Netcore component-building code the
 * WhatsApp campaigns already send through — one renderer, one place for bugs.
 */
function journey_send_whatsapp(array $journey, array $entry, array $cfg, array $claim, array $ctx): array {
    global $conn;

    require_once __DIR__ . '/../../whatsapp/lib/schema.php';
    require_once __DIR__ . '/../../whatsapp/lib/WaHelpers.php';
    require_once __DIR__ . '/../../whatsapp/lib/WaSendWorker.php';

    $tplRef = (string)($cfg['template'] ?? '');
    $tpl = journey_lookup_wa_template($tplRef);
    if (!$tpl) {
        journey_message_mark($claim['id'], 'failed', ['error_message' => "WhatsApp template '$tplRef' not found"]);
        return journey_result('failed', "WhatsApp template '$tplRef' no longer exists.");
    }
    if (($tpl['approval_status'] ?? '') === 'rejected') {
        journey_message_mark($claim['id'], 'suppressed',
            ['suppress_reason' => 'not_configured', 'error_message' => 'Template is rejected by Meta']);
        return journey_result('suppressed', "WhatsApp template '{$tpl['name']}' is rejected by Meta.",
                              ['reason' => 'not_configured']);
    }

    // config.php is required explicitly: WaAudienceResolver uses WA_DEFAULT_COUNTRY_CODE
    // as a default parameter value but does not include its own config, so it only works
    // when something loaded it first. Relying on that ordering is a fatal waiting to happen.
    require_once __DIR__ . '/../../whatsapp/lib/config.php';
    require_once __DIR__ . '/../../whatsapp/lib/WaAudienceResolver.php';
    require_once __DIR__ . '/../../whatsapp/lib/WaLinks.php';

    /*
     * Claim the template's tracked link for THIS journey, exactly as the campaign worker claims
     * it for a campaign.
     *
     * The link id is frozen inside the Meta-approved template, so a template used by both a
     * campaign and this journey hands out the identical /login/<id> to both audiences. Whoever
     * writes this row last owns an anonymous tap. Until journeys could write it, every journey
     * tap was credited to the last campaign that used the template — which is why the journey's
     * Clicked column stayed at 0 while that campaign's kept rising long after it finished.
     *
     * Cheap and idempotent (one UPDATE), so it runs per send rather than needing a separate
     * "journey started" hook that a resumed or retried send could miss.
     */
    $linkId = (int)($tpl['link_id'] ?? 0);
    if ($linkId > 0) {
        $goalDaysForLink = max(1, (int)ceil(((int)($journey['goal_window_hours'] ?: 72)) / 24));
        wa_link_bind_journey($linkId, (int)$journey['id'],
                             (string)($journey['goal_event'] ?? ''), $goalDaysForLink);
    }

    /*
     * Numbers must carry the country code. `users.phone` holds bare 10-digit Indian
     * mobiles, and sending "9421898233" makes the BSP read it as international and
     * drop it — "Netcore 8006: Messages Dropped - Intl Messages Blocked", which is
     * exactly what the first live journey produced.
     *
     * wa_normalize_phone() is the same function the WhatsApp campaigns normalise with,
     * so journeys and campaigns treat a given contact identically: it prefixes the
     * configured country code, and returns null for anything that isn't a dialable
     * mobile — which is a suppression (no usable number), not a provider failure.
     */
    $phone = wa_normalize_phone((string)($entry['phone'] ?? ''), wa_default_cc());
    if ($phone === null) {
        journey_message_mark($claim['id'], 'suppressed',
            ['suppress_reason' => 'no_address', 'error_message' => 'Not a dialable mobile number: ' . $entry['phone']]);
        return journey_result('suppressed',
            "'{$entry['phone']}' is not a valid mobile number, so nothing was sent.", ['reason' => 'no_address']);
    }

    $settings = function_exists('wa_settings_row') ? (wa_settings_row() ?: []) : [];
    $sender   = journey_wa_sender((string)($cfg['sender'] ?? ''));
    if (!$sender) {
        journey_message_mark($claim['id'], 'suppressed',
            ['suppress_reason' => 'not_configured', 'error_message' => 'No WhatsApp sending number configured']);
        return journey_result('suppressed', 'No WhatsApp sending number is configured.', ['reason' => 'not_configured']);
    }

    /*
     * Template variables. The node stores rows of {a: '{{1}}', v: 'FIRST_NAME'} — the
     * NAME of an attribute, not its value. Passing that straight through sent students a
     * WhatsApp message reading "Hello FIRST_NAME", because substitute_merge_tags() only
     * understands XX_..._XX and [BRACKET] tokens, not a bare column name.
     *
     * journey_attribute_values() already resolves users columns plus the Customer
     * Attributes store into one flat upper-cased map, so the value is looked up there.
     * A row that matches no attribute is treated as literal text, which is what lets you
     * hard-code a word into a variable slot.
     *
     * Anything still empty falls back to the template's own sample value: Meta rejects a
     * template parameter that is blank (#132000), so an empty string would fail the send
     * outright rather than just looking odd.
     */
    /*
     * sample_values is stored as {header:[…], body:[…]}, which is how the editor writes it and
     * how wa_templates.php reads it back when submitting to Meta. Reading it as a FLAT list here
     * meant [0] never existed, so the fallback that exists to stop #132000 produced the
     * empty string it was written to prevent — and a step with no variable rows at all handed
     * the whole map to the transport, which stringified it to 'Array'. The legacy flat shape is
     * still accepted so a template saved before the editor gained the two lists keeps working.
     */
    $samplesRaw = json_decode((string)($tpl['sample_values'] ?? '[]'), true);
    $samples = is_array($samplesRaw['body'] ?? null)
        ? array_values($samplesRaw['body'])
        : array_values(array_filter((array)$samplesRaw, 'is_scalar'));
    $attrVals = journey_attribute_values((int)($entry['user_id'] ?? 0), $entry);

    /*
     * TRACKED_LINK — this student's OWN link, and the only way a WhatsApp tap can be
     * credited to a person who never signs in.
     *
     * The approved button URL is byte-identical in every copy of the message (Meta refused
     * every variable-bearing version, so it is frozen as …/login/<link id>), and Netcore
     * will not deliver a dynamic button parameter either — see the note below on
     * goal_event_name. So the button physically cannot carry who it was sent to.
     *
     * A BODY variable can. `attributes` is the one part of Netcore's payload that is proven
     * to work, WhatsApp auto-links whatever text arrives in it, and the URL is identical to
     * the one the button would have carried:
     *
     *     …/login?campaign_id=1000027&medium=journey&phone=919…&goal=…&attr_window=3&wa_rid=<32 hex>
     *
     * The dashboard already knows what to do with that: attribution.js reads medium+wa_rid
     * and posts the tap to whatsapp/click.php, which stamps this exact journey_messages row.
     * No session required — the rid IS the identity.
     *
     * Written as XX_WA_ATTR_XX here and expanded by wa_render_for_recipient(), because the
     * rid and the phone belong to the SEND, not to the student profile this loop resolves
     * against.
     */
    $trackedLink = journey_wa_tracked_link($linkId);

    $bodyVars = [];
    foreach (array_values((array)($cfg['params'] ?? [])) as $i => $p) {
        $ref  = trim((string)($p['v'] ?? $p['value'] ?? ''));
        $name = strtoupper($ref);
        if ($name === 'TRACKED_LINK' || $name === 'WA_TRACKED_LINK') {
            // No link on the template means nothing to track — fall back to the sample so the
            // send still goes out rather than failing on an empty parameter (#132000).
            $bodyVars[] = $trackedLink !== '' ? $trackedLink : (string)($samples[$i] ?? '');
            continue;
        }
        $val  = array_key_exists($name, $attrVals) ? (string)$attrVals[$name] : $ref;
        if ($val === '') $val = (string)($samples[$i] ?? '');
        $bodyVars[] = $val;
    }
    if (!$bodyVars) $bodyVars = $samples;

    /*
     * The pseudo-campaign is filled out COMPLETELY, not just with the template fields.
     *
     * wa_render_for_recipient() does more than merge text: when a template has a dynamic
     * URL button it defaults that button's value to the XX_WA_ATTR_XX attribution token,
     * because Meta rejects the whole send with "131008: Button at index 0 of type Url
     * requires a parameter" if the value is missing — which is exactly what every journey
     * WhatsApp was failing with. That defaulting only happens when the renderer can see
     * an id, a goal and the template's buttons, so leaving those blank turned the
     * behaviour off and produced the rejection.
     *
     * Filling them makes a journey send byte-identical to a campaign send: same renderer,
     * same attribution query string, same click.php landing, same conversion plumbing.
     */
    $goalDays = max(1, (int)ceil(((int)($journey['goal_window_hours'] ?: 72)) / 24));
    $pseudoCampaign = [
        'id'                => (int)$journey['id'],
        /*
         * What this send calls itself in the attribution query string, when the template carries
         * a per-recipient link (XX_WA_ATTR_XX in a button or a body variable).
         *
         * That link is the only way a WhatsApp tap can name the person WITHOUT a sign-in: it
         * arrives carrying their phone number and this message's own rid, so the landing page can
         * report the click immediately. The static /login/<id> form cannot — it is identical in
         * every message ever sent.
         *
         * The offset id and 'journey' medium have to travel here for the same reason they do
         * everywhere else: a bare 21 would be indistinguishable from campaign 21 in the shared
         * attribution ledger.
         */
        'attr_campaign_id'  => journey_attr_campaign_id((int)$journey['id']),
        'attr_medium'       => JOURNEY_ATTR_MEDIUM,
        'message_type'      => 'template',
        'template_name'     => $tpl['name'],
        'template_language' => $tpl['language'],
        'header_type'       => $tpl['header_type'],
        'header_text'       => $tpl['header_text'],
        'header_media_url'  => $tpl['header_media_url'],
        'body_text'         => $tpl['body_text'],
        'buttons'           => $tpl['buttons'],
        'variables'         => json_encode([
            'header' => [],
            'body'   => $bodyVars,
            // Explicit value from the step wins; blank lets the renderer default it to
            // the attribution token when the template needs one.
            'button_url_suffix' => (string)($cfg['buttonUrl'] ?? ''),
        ]),
        /*
         * goal_event_name is deliberately blank unless this step opted into button
         * tracking, and that is what makes a journey send match a working campaign.
         *
         * wa_render_for_recipient() reads it as "auto-fill a dynamic URL button with the
         * attribution token". netcore_build_buttons() then emits a `buttons` key — and
         * Netcore does not deliver that value, so WhatsApp rejects the whole message with
         * 131008. A campaign with no goal never sets a suffix, emits no `buttons` key at
         * all, and sends fine with this very template.
         *
         * Passing the goal unconditionally is what turned a working template into a
         * failing one for journeys only. Now the button block is emitted only when the
         * step's "Button link value" is filled in — an explicit choice, not a default.
         */
        'goal_event_name'   => (string)($journey['goal_event'] ?: 'journey'),
        /*
         * …but the goal must NOT switch the button auto-fill back on.
         *
         * The renderer treats "has a goal + dynamic url button + nothing typed" as consent to
         * fill that button with the attribution token. For a campaign that is right. For a
         * journey it is what produced 131008 on every send: Netcore accepts the buttons block
         * and does not pass the value on, so WhatsApp refuses the whole message for a missing
         * button parameter. The goal still has to travel — it is what puts `goal=` in the
         * TRACKED_LINK query string — so the two are separated instead of tangled together.
         *
         * An explicitly typed "Button link value" is untouched by this and still goes out, for
         * the day the Meta route is connected and can carry it.
         */
        'auto_button_attr'  => false,
        'goal_window_days'  => $goalDays,
        'text_content'      => '',
        'preview_url'       => 0,
    ];
    $recipient = [
        'first_name' => $entry['first_name'] ?? '', 'last_name' => $entry['last_name'] ?? '',
        'email'      => $entry['email'] ?? '',
        // The normalised number, so the attribution query string carries the same value
        // the message was actually sent to.
        'phone'      => $phone,
        'rid'        => $claim['rid'],
    ];

    $rendered = wa_render_for_recipient($pseudoCampaign, $recipient, []);

    /*
     * Which route this step sends through. Blank (the default) follows whatever the
     * sending number is configured for in WhatsApp Settings — which today is Netcore,
     * because the Meta app is not connected to the WABA and a direct Cloud API send
     * fails with "#200 permissions". The dropdown exists so a step can be pinned
     * explicitly rather than silently changing route the day someone edits Settings.
     */
    $providerOverride = strtolower(trim((string)($cfg['provider'] ?? '')));
    $providerOverride = in_array($providerOverride, ['netcore', 'meta'], true) ? $providerOverride : null;

    $transport = wa_transport_for_sender($settings, $sender, $providerOverride);
    if (!$transport || !$transport->isConfigured()) {
        journey_message_mark($claim['id'], 'suppressed',
            ['suppress_reason' => 'not_configured', 'error_message' => 'WhatsApp transport not configured']);
        return journey_result('suppressed', 'The WhatsApp transport is not configured.', ['reason' => 'not_configured']);
    }

    $res = $transport->sendMessage($phone, $rendered['content'], $claim['rid']);

    // Record the number actually dialled, not the raw profile value — otherwise the
    // message log shows a bare 10-digit number that was never what we sent to.
    $conn->query("UPDATE journey_messages
                     SET preview = '" . $conn->real_escape_string(mb_substr((string)($rendered['preview'] ?? ''), 0, 2000)) . "',
                         to_addr = '" . $conn->real_escape_string($phone) . "',
                         provider = 'whatsapp'
                   WHERE id = " . (int)$claim['id']);

    // Same contract as the email transports: 'ok', not 'success'.
    if (!empty($res['ok'])) {
        journey_message_mark($claim['id'], 'sent', ['provider_message_id' => $res['message_id'] ?? null]);
        $conn->query("UPDATE journey_messages SET provider = '"
            . $conn->real_escape_string(wa_resolve_provider($sender, $providerOverride))
            . "' WHERE id = " . (int)$claim['id']);
        return journey_result('sent', 'WhatsApp sent to ' . $phone);
    }
    $err = (string)($res['error'] ?? 'The WhatsApp provider rejected the send without giving a reason.');
    journey_message_mark($claim['id'], 'failed', ['error_message' => $err]);
    return journey_result('failed', 'WhatsApp failed: ' . $err);
}

/**
 * The template's destination with the attribution token appended, or '' when the template has
 * no link configured.
 *
 *     https://dashboard.internshipstudio.com/login?XX_WA_ATTR_XX
 *
 * NO /<link id> PATH SEGMENT, deliberately, even though wa_tracked_link() would add one and the
 * approved BUTTON carries it. The id exists to give a static link something to look up, and the
 * dashboard resolves it by calling whatsapp/link.php — which logs its own anonymous tap row. A
 * URL carrying both would therefore be counted twice for one tap: once anonymously by link.php
 * and once, by name, by click.php. This link needs no lookup: everything link.php would return
 * is already in the query string, and the rid names the person the id never could.
 *
 * A destination that already has a query string keeps it — the token is appended with '&'.
 */
function journey_wa_tracked_link(int $linkId): string {
    global $conn;
    if ($linkId <= 0) return '';

    $r   = $conn->query("SELECT target_url FROM wa_links WHERE id = " . (int)$linkId . " LIMIT 1");
    $row = $r ? $r->fetch_assoc() : null;
    $target = trim((string)($row['target_url'] ?? ''));
    if ($target === '') return '';

    return $target . (strpos($target, '?') === false ? '?' : '&') . 'XX_WA_ATTR_XX';
}

function journey_lookup_wa_template(string $ref): ?array {
    global $conn;
    if ($ref === '') return null;
    if (is_numeric($ref)) {
        $r = $conn->query("SELECT * FROM wa_templates WHERE id = " . (int)$ref . " LIMIT 1");
        $row = $r ? $r->fetch_assoc() : null;
        if ($row) return $row;
    }
    $esc = $conn->real_escape_string($ref);
    $r = $conn->query("SELECT * FROM wa_templates WHERE name = '$esc' AND status = 'active' ORDER BY id DESC LIMIT 1");
    return $r ? ($r->fetch_assoc() ?: null) : null;
}

/** The node stores a display label like "+91 90000 11111 (iStudio)" — match on digits. */
function journey_wa_sender(string $ref): ?array {
    global $conn;
    $digits = preg_replace('/\D+/', '', $ref);
    if ($digits !== '') {
        $esc = $conn->real_escape_string($digits);
        $r = $conn->query("SELECT * FROM wa_senders
                            WHERE REPLACE(REPLACE(business_number,'+',''),' ','') = '$esc'
                              AND is_active = 1 LIMIT 1");
        $row = $r ? $r->fetch_assoc() : null;
        if ($row) return $row;
    }
    $r = $conn->query("SELECT * FROM wa_senders WHERE is_active = 1 ORDER BY is_default DESC, id ASC LIMIT 1");
    return $r ? ($r->fetch_assoc() ?: null) : null;
}

/* ════════════════════════════════════════════════════════════════════════════
   Call a service (webhook)
   ═══════════════════════════════════════════════════════════════════════════ */

/**
 * The node Netcore does not have and your own research flags as a MUST for us:
 * unlock the hiring portal, issue a certificate, sync a CRM.
 *
 * Locked to https and to a host allowlist. A journey step that can POST anywhere
 * is an SSRF primitive handed to whoever can edit a journey, so the allowlist is
 * the feature, not a formality.
 */
function journey_call_webhook(array $journey, array $entry, array $cfg, array $claim, array $ctx): array {
    $url    = trim((string)($cfg['url'] ?? ''));
    $method = strtoupper((string)($cfg['method'] ?? 'POST'));
    if (!in_array($method, ['GET', 'POST', 'PUT'], true)) $method = 'POST';

    $host = parse_url($url, PHP_URL_HOST);
    $scheme = parse_url($url, PHP_URL_SCHEME);
    if ($scheme !== 'https' || !$host) {
        journey_message_mark($claim['id'], 'failed', ['error_message' => 'Endpoint must be an https URL']);
        return journey_result('failed', 'The endpoint must be an https:// URL.');
    }
    if (!journey_host_allowed($host)) {
        journey_message_mark($claim['id'], 'failed', ['error_message' => "Host '$host' is not allowlisted"]);
        return journey_result('failed', "Host '$host' is not on the webhook allowlist (see JOURNEY_WEBHOOK_HOSTS).");
    }

    $payload = ['user_id' => (int)($entry['user_id'] ?? 0), 'email' => $entry['email'] ?? '',
                'phone' => $entry['phone'] ?? '', 'journey_id' => (int)$ctx['journey_id'],
                'entry_id' => (int)$ctx['entry_id'], 'node_id' => (string)$ctx['node_id']];
    foreach (array_filter(array_map('trim', explode(',', (string)($cfg['body'] ?? '')))) as $k) {
        if (!isset($payload[$k])) $payload[$k] = $entry[$k] ?? null;
    }

    $ch = curl_init();
    $target = $url;
    if ($method === 'GET') $target .= (strpos($url, '?') === false ? '?' : '&') . http_build_query($payload);
    curl_setopt_array($ch, [
        CURLOPT_URL => $target,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => 15,
        CURLOPT_CONNECTTIMEOUT => 8,
        CURLOPT_FOLLOWLOCATION => false,     // a redirect could walk out of the allowlist
        CURLOPT_CUSTOMREQUEST => $method,
    ]);
    if ($method !== 'GET') {
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
        curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
    }
    $body = curl_exec($ch);
    $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $err  = curl_error($ch);
    curl_close($ch);

    if ($err !== '' || $code < 200 || $code >= 300) {
        $msg = $err !== '' ? $err : "HTTP $code";
        journey_message_mark($claim['id'], 'failed', ['error_message' => $msg]);
        return journey_result('failed', 'Service call failed: ' . $msg);
    }
    journey_message_mark($claim['id'], 'sent', ['provider_message_id' => "HTTP $code"]);
    return journey_result('sent', "Service call returned HTTP $code");
}

function journey_host_allowed(string $host): bool {
    $allow = defined('JOURNEY_WEBHOOK_HOSTS') ? JOURNEY_WEBHOOK_HOSTS
           : ['internshipstudio.com', 'offcampusly.com', 'skilluniverse.com'];
    $host = strtolower($host);
    foreach ($allow as $a) {
        $a = strtolower($a);
        if ($host === $a || substr($host, -strlen('.' . $a)) === '.' . $a) return true;
    }
    return false;
}

/*
 * Deliberately NOT incrementing journeys.sent_count here.
 *
 * journey_rollup_node_stats() recomputes every counter from journey_messages at the end
 * of each tick — it is the single source of truth. Incrementing as well meant the number
 * was inflated between the send and the rollup, and any future change to what counts as
 * "sent" would have had to be made in two places that could disagree. Counting rows once,
 * in one place, is what makes the report reconcile with the message log.
 */

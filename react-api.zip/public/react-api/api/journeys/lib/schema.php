<?php
/*
 * /api/journeys/lib/schema.php
 *
 * Idempotent schema creation for the Journey Orchestration engine, following the
 * same convention as campaigns/lib/schema.php and whatsapp/lib/schema.php:
 * journeys_ensure_schema() runs at the top of every entry point (journeys.php,
 * journey-worker.php) and is cheap after the first call — CREATE TABLE IF NOT
 * EXISTS is a no-op once the tables exist.
 *
 * journeys_schema.sql in the parent folder is the human-readable copy of exactly
 * these statements (living documentation, same as campaigns_schema.sql).
 *
 * ── Why two homes for the same settings ───────────────────────────────────────
 * journeys.settings holds the UI's own JSON shape verbatim (what the builder's
 * settings drawer reads and writes — see BACKEND_API.md §1.2). The engine does
 * NOT read that blob: journeys_denormalize_settings() copies the execution-
 * relevant values out into typed columns (goal_event, dnd_config, fc_max_per_day,
 * control_mode, …) on every save. The worker only ever touches the typed columns,
 * so a malformed settings blob can never crash a running journey, and the columns
 * can be indexed and queried.
 */

require_once __DIR__ . '/../../../config/database.php';

/*
 * ── mysqli error mode ────────────────────────────────────────────────────────
 * PHP 8.1 turned mysqli's default reporting to MYSQLI_REPORT_ERROR|STRICT, which
 * makes every failed query THROW mysqli_sql_exception instead of returning false.
 * Two things in this feature are written against the return-false contract and
 * are wrong under exceptions:
 *
 *   1. journey_claim_message() relies on a duplicate-key INSERT returning false.
 *      That failed insert IS the idempotency guard — it is how two concurrent
 *      worker ticks are stopped from sending the same message twice. Under
 *      exception mode it would throw instead, abort the step, and the guard
 *      would never do its job.
 *   2. The engine probes optional tables/columns with @$conn->query() and checks
 *      for false. The @ operator does not suppress exceptions, so a missing
 *      optional table would kill the whole tick rather than degrading.
 *
 * So this feature's entry points opt back into the classic behaviour. It is set
 * here because lib/schema.php is the one file both journeys.php and
 * journey-worker.php load, and it is scoped to this request only — nothing else
 * on the server is affected.
 */
mysqli_report(MYSQLI_REPORT_OFF);

function journeys_ensure_schema(): void {
    global $conn;
    static $done = false;
    if ($done) return;
    $done = true;

    foreach (journeys_schema_statements() as $sql) {
        // Deliberately not fatal: a single failed CREATE (e.g. a column added by a
        // newer deploy that this older file doesn't know about) must not take the
        // whole endpoint down. journeys_schema_health() surfaces anything missing.
        @$conn->query($sql);
    }
    journeys_apply_migrations();
}

function journeys_schema_statements(): array {
    return [

    /* ═══════════════ 1. The journey itself ═══════════════ */
    "CREATE TABLE IF NOT EXISTS journeys (
        id              BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        name            VARCHAR(255) NOT NULL,
        tags            JSON DEFAULT NULL,
        status          ENUM('draft','scheduled','ongoing','paused','stopped','completed','archived','failed')
                          NOT NULL DEFAULT 'draft',

        start_at        DATETIME DEFAULT NULL,
        end_type        ENUM('never','date') NOT NULL DEFAULT 'never',
        end_at          DATETIME DEFAULT NULL,
        timezone        VARCHAR(64) NOT NULL DEFAULT 'Asia/Kolkata',

        -- Canvas. { nodes: {id: {key,x,y,cfg}}, edges: {id: {from,branch,to,wait}} }
        graph           JSON NOT NULL,
        -- Verbatim UI settings blob (BACKEND_API.md 1.2). Engine reads the columns below, not this.
        settings        JSON DEFAULT NULL,

        -- ── Goal / attribution (spec 2.6). Locked on first deploy. ──
        goal_enabled      TINYINT(1) NOT NULL DEFAULT 0,
        goal_event        VARCHAR(64) DEFAULT NULL,
        goal_window_hours INT NOT NULL DEFAULT 72,
        goal_locked_at    DATETIME DEFAULT NULL,

        -- ── Governance (research Part D 1,2,3) ──
        -- Journey-level exit criteria: Braze has it, Netcore does not. Without it every
        -- conversion path must be hand-drawn at every node. Shape: {event, window_hours}.
        exit_criteria         JSON DEFAULT NULL,
        -- Adobe's per-profile re-entrance block. Cheap insurance against duplicate-event storms.
        entry_debounce_seconds INT NOT NULL DEFAULT 300,

        dnd_enabled     TINYINT(1) NOT NULL DEFAULT 0,
        dnd_config      JSON DEFAULT NULL,            -- [{day:0..6, enabled:1, from:'21:00', to:'09:30'}]
        fc_enabled      TINYINT(1) NOT NULL DEFAULT 0,
        fc_max_per_day  INT NOT NULL DEFAULT 2,
        -- MoEngage's per-flow overrides. Netcore REMOVES a capped user from the journey;
        -- we skip the message and continue (Part D 2), and these let operational journeys
        -- (exam-day, payment-failure) bypass the cap entirely while still counting toward it.
        ignore_fc        TINYINT(1) NOT NULL DEFAULT 0,
        ignore_dnd       TINYINT(1) NOT NULL DEFAULT 0,
        counts_toward_fc TINYINT(1) NOT NULL DEFAULT 1,

        control_mode    ENUM('none','percent','list') NOT NULL DEFAULT 'none',
        control_pct     INT NOT NULL DEFAULT 0,
        control_list    LONGTEXT DEFAULT NULL,        -- newline/comma separated emails

        -- ── Denormalised rollups the listing + report read ──
        entered_count   BIGINT UNSIGNED NOT NULL DEFAULT 0,
        active_count    BIGINT UNSIGNED NOT NULL DEFAULT 0,
        sent_count      BIGINT UNSIGNED NOT NULL DEFAULT 0,
        delivered_count BIGINT UNSIGNED NOT NULL DEFAULT 0,
        opened_count    BIGINT UNSIGNED NOT NULL DEFAULT 0,
        clicked_count   BIGINT UNSIGNED NOT NULL DEFAULT 0,
        conversion_count BIGINT UNSIGNED NOT NULL DEFAULT 0,
        revenue         DECIMAL(14,2) NOT NULL DEFAULT 0,
        suppressed_count BIGINT UNSIGNED NOT NULL DEFAULT 0,

        current_version_id BIGINT UNSIGNED DEFAULT NULL,
        last_error      VARCHAR(1000) DEFAULT NULL,

        created_by      BIGINT UNSIGNED DEFAULT NULL,
        created_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        deployed_at     DATETIME DEFAULT NULL,
        completed_at    DATETIME DEFAULT NULL,

        INDEX idx_status (status),
        INDEX idx_status_start (status, start_at),
        INDEX idx_updated (updated_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

    /* ═══════════════ 2. Version snapshots ═══════════════
       The single most important schema decision in the spec (5.2 note 2): an entry
       pins to the version it entered under, so editing a live journey can never
       reroute users who are already inside it. */
    "CREATE TABLE IF NOT EXISTS journey_versions (
        id          BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        journey_id  BIGINT UNSIGNED NOT NULL,
        version_no  INT UNSIGNED NOT NULL,
        name        VARCHAR(255) DEFAULT NULL,
        status      VARCHAR(32) DEFAULT NULL,
        graph       JSON NOT NULL,
        settings    JSON DEFAULT NULL,
        created_by  BIGINT UNSIGNED DEFAULT NULL,
        created_at  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY uq_journey_version (journey_id, version_no),
        INDEX idx_journey (journey_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

    /* ═══════════════ 3. One row per user per entry ═══════════════
       Contact fields are SNAPSHOTTED at entry, not joined at send time: a journey can
       hold someone for 30 days and the merge tags must render what the message was
       personalised for, not what the profile drifted to. */
    "CREATE TABLE IF NOT EXISTS journey_entries (
        id            BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        journey_id    BIGINT UNSIGNED NOT NULL,
        version_id    BIGINT UNSIGNED DEFAULT NULL,
        user_id       BIGINT UNSIGNED DEFAULT NULL,
        email         VARCHAR(255) DEFAULT NULL,
        phone         VARCHAR(50) DEFAULT NULL,
        first_name    VARCHAR(255) DEFAULT NULL,
        last_name     VARCHAR(255) DEFAULT NULL,

        status        ENUM('active','waiting','completed','exited','errored') NOT NULL DEFAULT 'active',
        current_node  VARCHAR(64) DEFAULT NULL,
        -- Control-group members walk the whole graph and are tracked for conversions,
        -- but every dispatch is suppressed. Without the row you cannot compute lift.
        is_control    TINYINT(1) NOT NULL DEFAULT 0,

        trigger_event VARCHAR(64) DEFAULT NULL,
        trigger_payload JSON DEFAULT NULL,
        steps_taken   INT UNSIGNED NOT NULL DEFAULT 0,

        entered_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        exited_at     DATETIME DEFAULT NULL,
        exit_reason   VARCHAR(255) DEFAULT NULL,
        last_error    VARCHAR(1000) DEFAULT NULL,
        updated_at    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

        INDEX idx_journey_status (journey_id, status),
        INDEX idx_journey_user (journey_id, user_id),
        INDEX idx_user (user_id),
        INDEX idx_entered (journey_id, entered_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

    /* ═══════════════ 4. Append-only audit trail ═══════════════
       This is what answers "I never got the WhatsApp" in thirty seconds (Iterable's
       per-user trace, research Part D 6). Never updated, only inserted. */
    "CREATE TABLE IF NOT EXISTS journey_steps (
        id          BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        entry_id    BIGINT UNSIGNED NOT NULL,
        journey_id  BIGINT UNSIGNED NOT NULL,
        node_id     VARCHAR(64) NOT NULL,
        node_key    VARCHAR(32) NOT NULL,
        branch      VARCHAR(64) DEFAULT NULL,
        outcome     VARCHAR(32) NOT NULL DEFAULT 'ok',   -- ok|suppressed|error|wait|exit
        detail      VARCHAR(500) DEFAULT NULL,
        result      JSON DEFAULT NULL,
        created_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_entry (entry_id, id),
        INDEX idx_journey_node (journey_id, node_id),
        INDEX idx_created (created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

    /* ═══════════════ 5. The scheduler's work queue ═══════════════
       Every delay and every wait-for-event becomes one row with a wake_at. The whole
       engine is driven by: WHERE status='pending' AND wake_at <= NOW(). */
    "CREATE TABLE IF NOT EXISTS journey_waits (
        id           BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        entry_id     BIGINT UNSIGNED NOT NULL,
        journey_id   BIGINT UNSIGNED NOT NULL,
        node_id      VARCHAR(64) NOT NULL,       -- node to execute when this fires
        from_node_id VARCHAR(64) DEFAULT NULL,
        edge_id      VARCHAR(64) DEFAULT NULL,
        mode         ENUM('delay','event') NOT NULL DEFAULT 'delay',

        wake_at      DATETIME NOT NULL,
        -- wait-for-event only
        event_key    VARCHAR(64) DEFAULT NULL,
        event_params JSON DEFAULT NULL,
        watch_from   DATETIME DEFAULT NULL,      -- only events after this count
        expires_at   DATETIME DEFAULT NULL,
        timeout_node_id VARCHAR(64) DEFAULT NULL,

        status       ENUM('pending','fired','expired','cancelled') NOT NULL DEFAULT 'pending',
        fired_at     DATETIME DEFAULT NULL,
        created_at   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,

        INDEX idx_due (status, wake_at),
        INDEX idx_entry (entry_id),
        INDEX idx_journey_status (journey_id, status),
        INDEX idx_event_watch (status, mode, event_key)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

    /* ═══════════════ 6. Sticky split variants ═══════════════
       Separate from journey_entries on purpose: the assignment must OUTLIVE any single
       entry, which is what makes a re-entering user land in the same variant (spec 3.2). */
    "CREATE TABLE IF NOT EXISTS journey_split_assignments (
        journey_id  BIGINT UNSIGNED NOT NULL,
        node_id     VARCHAR(64) NOT NULL,
        user_id     BIGINT UNSIGNED NOT NULL,
        variant     VARCHAR(32) NOT NULL,
        assigned_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (journey_id, node_id, user_id),
        INDEX idx_variant (journey_id, node_id, variant)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

    /* ═══════════════ 7. Dispatch log ═══════════════
       One row per attempted message, INCLUDING the ones that were never sent
       (suppressed by DND hold, frequency cap, control group, no address). Netcore's
       silent drop is precisely what makes journeys impossible to debug; every
       suppression here carries a reason. Also the counting table for the cap. */
    "CREATE TABLE IF NOT EXISTS journey_messages (
        id            BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        journey_id    BIGINT UNSIGNED NOT NULL,
        entry_id      BIGINT UNSIGNED NOT NULL,
        node_id       VARCHAR(64) NOT NULL,
        user_id       BIGINT UNSIGNED DEFAULT NULL,
        channel       ENUM('email','whatsapp','sms','push','webhook') NOT NULL,
        to_addr       VARCHAR(255) DEFAULT NULL,
        subject       VARCHAR(998) DEFAULT NULL,
        preview       TEXT DEFAULT NULL,

        rid           CHAR(32) NOT NULL,
        -- entry:node:attempt. UNIQUE, and inserted BEFORE the provider call — that
        -- insert failing is what makes a retried worker tick unable to double-send.
        idem_key      VARCHAR(128) NOT NULL,

        status        ENUM('queued','sent','failed','suppressed') NOT NULL DEFAULT 'queued',
        suppress_reason VARCHAR(64) DEFAULT NULL,  -- control_group|frequency_cap|dnd_hold|no_address|not_configured|blocklisted
        provider      VARCHAR(32) DEFAULT NULL,
        provider_message_id VARCHAR(255) DEFAULT NULL,
        error_message VARCHAR(500) DEFAULT NULL,
        attempts      TINYINT UNSIGNED NOT NULL DEFAULT 0,

        queued_at     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        sent_at       DATETIME DEFAULT NULL,
        delivered_at  DATETIME DEFAULT NULL,
        opened_at     DATETIME DEFAULT NULL,
        first_clicked_at DATETIME DEFAULT NULL,
        open_count    INT NOT NULL DEFAULT 0,
        click_count   INT NOT NULL DEFAULT 0,

        UNIQUE KEY uq_rid (rid),
        UNIQUE KEY uq_idem (idem_key),
        INDEX idx_journey_node (journey_id, node_id, status),
        INDEX idx_entry (entry_id),
        INDEX idx_user_sent (user_id, sent_at),
        INDEX idx_provider_msg (provider_message_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

    /* ═══════════════ 8. Trigger watermarks ═══════════════
       Your platform has no generic event stream — events are DERIVED from ~20 domain
       tables through $EVENT_SOURCE in netcore/lib/segment_sql.php. So an Activity
       trigger cannot be push-based; it is a poller that remembers how far it has read.
       last_seen_at is exclusive: rows are picked up with date_col > last_seen_at. */
    "CREATE TABLE IF NOT EXISTS journey_event_cursors (
        journey_id   BIGINT UNSIGNED NOT NULL,
        source_key   VARCHAR(64) NOT NULL,       -- event key, or 'segment'/'list'/'business'
        last_seen_at DATETIME DEFAULT NULL,
        last_run_at  DATETIME DEFAULT NULL,
        rows_seen    BIGINT UNSIGNED NOT NULL DEFAULT 0,
        updated_at   TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (journey_id, source_key)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

    /* ═══════════════ 9. Business events ═══════════════
       Backend-fired events (spec UC-3/4/10: batch_starts_tomorrow, exam_window_opens).
       POSTed to journeys.php?action=business_event by your cron/scheduler; the worker
       drains them. The event is about the CATALOGUE, the audience comes from behaviour —
       context_map on the trigger node joins the two. */
    "CREATE TABLE IF NOT EXISTS journey_business_events (
        id           BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        event_name   VARCHAR(100) NOT NULL,
        payload      JSON DEFAULT NULL,
        occurred_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        created_at   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_name_time (event_name, occurred_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

    /* ═══════════════ 10. Conversions ═══════════════
       Last-click attribution against the journey goal. Revenue is ALWAYS recorded when
       the goal event carries an amount, even if the marketer picked a non-revenue goal
       (Insider's default — research Part D 9). */
    "CREATE TABLE IF NOT EXISTS journey_conversions (
        id           BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        journey_id   BIGINT UNSIGNED NOT NULL,
        entry_id     BIGINT UNSIGNED NOT NULL,
        user_id      BIGINT UNSIGNED NOT NULL,
        node_id      VARCHAR(64) DEFAULT NULL,     -- message that got the last click
        message_id   BIGINT UNSIGNED DEFAULT NULL,
        event_key    VARCHAR(64) NOT NULL,
        is_control   TINYINT(1) NOT NULL DEFAULT 0,
        revenue      DECIMAL(14,2) NOT NULL DEFAULT 0,
        converted_at DATETIME NOT NULL,
        created_at   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY uq_entry_event (entry_id, event_key),
        INDEX idx_journey (journey_id, converted_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

    /* ═══════════════ 11. Node rollups ═══════════════
       Recomputed on a cadence rather than counted on read, so the report stays fast
       once journey_steps has millions of rows. */
    "CREATE TABLE IF NOT EXISTS journey_node_stats (
        journey_id  BIGINT UNSIGNED NOT NULL,
        node_id     VARCHAR(64) NOT NULL,
        stat_date   DATE NOT NULL,
        entered     BIGINT UNSIGNED NOT NULL DEFAULT 0,
        sent        BIGINT UNSIGNED NOT NULL DEFAULT 0,
        delivered   BIGINT UNSIGNED NOT NULL DEFAULT 0,
        opened      BIGINT UNSIGNED NOT NULL DEFAULT 0,
        clicked     BIGINT UNSIGNED NOT NULL DEFAULT 0,
        suppressed  BIGINT UNSIGNED NOT NULL DEFAULT 0,
        failed      BIGINT UNSIGNED NOT NULL DEFAULT 0,
        waiting     BIGINT UNSIGNED NOT NULL DEFAULT 0,
        updated_at  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (journey_id, node_id, stat_date)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

    ];
}

/*
 * Columns added after the first deploy. ADD COLUMN IF NOT EXISTS is MySQL 8.0.29+
 * only, and this server may be older, so each one is probed against
 * INFORMATION_SCHEMA first. Same approach campaigns/lib/schema.php uses.
 */
function journeys_apply_migrations(): void {
    global $conn;

    $add = function (string $table, string $column, string $ddl) use ($conn) {
        $t = $conn->real_escape_string($table);
        $c = $conn->real_escape_string($column);
        $r = $conn->query("SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS
                            WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = '$t' AND COLUMN_NAME = '$c' LIMIT 1");
        if ($r && $r->num_rows > 0) return;
        @$conn->query("ALTER TABLE `$t` ADD COLUMN $ddl");
    };

    // Placeholder for future additions — keeping the hook in place means the next
    // column can ship without anyone having to remember how this file works.
    $add('journeys', 'last_worker_at', 'last_worker_at DATETIME DEFAULT NULL');
    $add('journeys', 'fc_scope', "fc_scope ENUM('channel','all') NOT NULL DEFAULT 'channel'");
    $add('journeys', 'one_per_student', 'one_per_student TINYINT(1) NOT NULL DEFAULT 0');
    $add('journey_entries', 'debounce_key', 'debounce_key VARCHAR(80) DEFAULT NULL');
    $add('journey_entries', 'error_retries', 'error_retries TINYINT UNSIGNED NOT NULL DEFAULT 0');
    $add('journey_messages', 'variant', 'variant VARCHAR(32) DEFAULT NULL');
}

/**
 * Which of our tables actually exist. journeys.php?action=health returns this so a
 * deploy can be verified without SSH or a DB client.
 */
function journeys_schema_health(): array {
    global $conn;
    $tables = ['journeys','journey_versions','journey_entries','journey_steps','journey_waits',
               'journey_split_assignments','journey_messages','journey_event_cursors',
               'journey_business_events','journey_conversions','journey_node_stats'];
    $out = [];
    foreach ($tables as $t) {
        $r = $conn->query("SELECT COUNT(*) c FROM INFORMATION_SCHEMA.TABLES
                            WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = '" . $conn->real_escape_string($t) . "'");
        $row = $r ? $r->fetch_assoc() : null;
        $out[$t] = ((int)($row['c'] ?? 0)) === 1;
    }
    return $out;
}

/* ══════════════════════════════════════════════════════════════════════════════
   Settings blob  →  typed engine columns

   Called on every save. The builder owns the JSON shape; the engine owns the
   columns. Anything unparseable falls back to a safe default rather than
   throwing, because a settings drawer bug must not be able to stop a live
   journey mid-flight.
   ═════════════════════════════════════════════════════════════════════════════ */
function journeys_denormalize_settings(?array $settings): array {
    $s = $settings ?: [];

    $goalEnabled = !empty($s['goal']);
    $goalEvent   = trim((string)($s['goalEvent'] ?? ''));
    $goalWindow  = (int)($s['goalWindow'] ?? 72);
    if ($goalWindow <= 0) $goalWindow = 72;

    // Control group. The UI writes controlMode 'Percentage' | 'List'.
    $controlMode = 'none';
    if (!empty($s['control'])) {
        $controlMode = strtolower((string)($s['controlMode'] ?? 'percentage')) === 'list' ? 'list' : 'percent';
    }
    $controlPct = max(0, min(100, (int)($s['controlPct'] ?? 0)));

    /*
     * DND. The UI carries two parallel arrays indexed 0..6 (Sun..Sat): dndDays[i] is
     * 1 when day i has a blocking window, dndTimes[i] = {f: from, t: to}.
     * Netcore's semantics, kept exactly: a SELECTED day means messages are BLOCKED
     * inside that window; unselected days have no DND at all. A window whose end is
     * before its start spans midnight and is evaluated as two intervals.
     */
    $dndEnabled = !empty($s['dnd']);
    $dndConfig  = [];
    $days  = is_array($s['dndDays'] ?? null) ? $s['dndDays'] : [];
    $times = is_array($s['dndTimes'] ?? null) ? $s['dndTimes'] : [];
    for ($d = 0; $d < 7; $d++) {
        $dndConfig[] = [
            'day'     => $d,
            'enabled' => !empty($days[$d]) ? 1 : 0,
            'from'    => (string)($times[$d]['f'] ?? '21:00'),
            'to'      => (string)($times[$d]['t'] ?? '09:30'),
        ];
    }

    $exit = null;
    if (!empty($s['exitEnabled']) && !empty($s['exitEvent'])) {
        $exit = [
            'event'        => (string)$s['exitEvent'],
            'window_hours' => max(1, (int)($s['exitWindow'] ?? 720)),
        ];
    }

    return [
        'goal_enabled'      => $goalEnabled ? 1 : 0,
        'goal_event'        => $goalEvent !== '' ? $goalEvent : null,
        'goal_window_hours' => $goalWindow,
        'exit_criteria'     => $exit ? json_encode($exit) : null,
        'entry_debounce_seconds' => max(0, (int)($s['debounce'] ?? 300)),
        'dnd_enabled'       => $dndEnabled ? 1 : 0,
        'dnd_config'        => json_encode($dndConfig),
        'fc_enabled'        => !empty($s['cap']) ? 1 : 0,
        'fc_max_per_day'    => max(1, (int)($s['capN'] ?? 2)),
        // 'channel' counts WhatsApp and email separately; 'all' is one shared budget.
        // Netcore supports both; per-channel is the default because a WhatsApp step
        // using up an email step's allowance surprises everyone the first time.
        'fc_scope'          => strtolower((string)($s['capScope'] ?? '')) === 'all channels together' ? 'all' : 'channel',
        'one_per_student'   => !empty($s['onePerStudent']) ? 1 : 0,
        'ignore_fc'         => !empty($s['ignoreFc']) ? 1 : 0,
        'ignore_dnd'        => !empty($s['ignoreDnd']) ? 1 : 0,
        'counts_toward_fc'  => array_key_exists('countsTowardFc', $s) ? (!empty($s['countsTowardFc']) ? 1 : 0) : 1,
        'control_mode'      => $controlMode,
        'control_pct'       => $controlPct,
        'control_list'      => $controlMode === 'list' ? (string)($s['controlList'] ?? '') : null,
    ];
}

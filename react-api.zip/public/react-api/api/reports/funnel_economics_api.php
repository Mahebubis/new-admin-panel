<?php
/* ============================================================================
   FUNNEL ECONOMICS — STANDALONE API
   File: funnel_economics_api.php
   ----------------------------------------------------------------------------
   Self-contained, action-based JSON endpoint. Drop this file anywhere your
   web server can serve PHP, point the React component at its URL, done.

   Reads:
     - Meta Ads insights via Graph API v19 (uses the token from your
       `settings` table where settings_key = 'meta_access_token')
     - Registrations from the `users` table
     - Exams from the `cit_results` table
     - Payments / revenue from the `payment_status` table
     - CIT version date ranges from the `exam_batch_for_reports` table

   Writes: nothing. Read-only.

   Actions:
     POST action=get_cit_versions
       -> { success, versions: ["CIT_v17", "CIT_v18", ...] }

     POST action=fetch_funnel_economics
            mode=versions  versions=["CIT_v17"]
       OR   mode=daterange from_date=2026-05-01 to_date=2026-05-31
       -> { success, inputs, raw, source, fetched_at }
   ============================================================================ */

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if (session_status() === PHP_SESSION_NONE) {
    @session_start();
}

/* ---------- CORS (uncomment + set if React lives on a different origin) --- */
$ALLOW_ORIGIN = null; // e.g. 'http://localhost:3000' or 'https://app.example.com'
if ($ALLOW_ORIGIN) {
    header("Access-Control-Allow-Origin: $ALLOW_ORIGIN");
    header("Access-Control-Allow-Credentials: true");
    header("Access-Control-Allow-Methods: POST, OPTIONS");
    header("Access-Control-Allow-Headers: Content-Type, X-Requested-With");
    if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(204); exit; }
}
header('Content-Type: application/json; charset=utf-8');

/* ---------- Helpers ------------------------------------------------------- */
function jsonOut($payload, $code = 200) {
    http_response_code($code);
    echo json_encode($payload);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonOut(['success' => false, 'message' => 'POST required'], 405);
}

$action = $_POST['action'] ?? '';
if ($action === '') {
    jsonOut(['success' => false, 'message' => 'Missing action']);
}

/* ---------- DB CONNECTION -------------------------------------------------
   Update these to your DB creds. Matches your existing meta_ads_api.php.
   -------------------------------------------------------------------------- */
$host     = '127.0.0.1:3306';
$dbname   = 'istudio_cit';
$username = 'istudio_admin';
$password = 'h;V[ts@#;u{B';

try {
    $pdo = new PDO(
        "mysql:host=$host;dbname=$dbname;charset=utf8mb4",
        $username, $password,
        [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ]
    );
} catch (PDOException $e) {
    jsonOut(['success' => false, 'message' => 'DB connection failed: ' . $e->getMessage()], 500);
}

/* ---------- META API CONFIG ----------------------------------------------- */
define('AD_ACCOUNT_ID', 'act_440296640847969');

function getMetaToken($pdo) {
    $stmt = $pdo->prepare("SELECT settings_value FROM settings WHERE settings_key='meta_access_token' LIMIT 1");
    $stmt->execute();
    return $stmt->fetchColumn();
}

function isTokenExpiredError($errMsg) {
    return (
        stripos($errMsg, 'invalid oauth access token')           !== false ||
        stripos($errMsg, 'error validating access token')        !== false ||
        stripos($errMsg, 'session has expired')                  !== false ||
        stripos($errMsg, 'access token could not be decrypted')  !== false ||
        stripos($errMsg, 'invalid access token')                 !== false
    );
}

/* ---------- Looks up a CIT version's date range from exam_batch_for_reports.
              Matches the +1 day from-date convention used in your other tabs. */
function getVersionDateRange($pdo, $versionName) {
    static $cache = [];
    if (isset($cache[$versionName])) return $cache[$versionName];

    $stmt = $pdo->prepare("SELECT from_date, to_date FROM exam_batch_for_reports WHERE exam_name = ? LIMIT 1");
    $stmt->execute([$versionName]);
    $dates = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$dates) { $cache[$versionName] = null; return null; }

    $r = [
        'from' => date('Y-m-d', strtotime($dates['from_date'] . ' +1 day')),
        'to'   => $dates['to_date'],
    ];
    $cache[$versionName] = $r;
    return $r;
}

/* ---------- Single account-level Meta insights call.
              Returns aggregated totals including inline_link_clicks for honest
              CTR / LP CVR. Memoized per request. */
function fetchMetaAccountTotals($from, $to) {
    global $ACCESS_TOKEN;
    static $memo = [];
    $k = $from . '|' . $to;
    if (isset($memo[$k])) return $memo[$k];

    $fields = ['spend', 'impressions', 'clicks', 'inline_link_clicks', 'reach'];
    $url = 'https://graph.facebook.com/v19.0/' . AD_ACCOUNT_ID .
           '/insights?level=account' .
           '&fields=' . implode(',', $fields) .
           '&time_range={"since":"' . $from . '","until":"' . $to . '"}' .
           '&access_token=' . $ACCESS_TOKEN;

    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_TIMEOUT, 30);
    $resp = curl_exec($ch);
    curl_close($ch);

    $data = json_decode($resp, true);
    if (isset($data['error'])) {
        $memo[$k] = ['error' => $data['error']['message'] ?? 'Meta API error'];
        return $memo[$k];
    }

    $totals = [
        'spend'              => 0.0,
        'impressions'        => 0,
        'clicks'             => 0,
        'inline_link_clicks' => 0,
        'reach'              => 0,
    ];
    foreach ($data['data'] ?? [] as $row) {
        $totals['spend']              += (float)($row['spend']              ?? 0);
        $totals['impressions']        += (int)  ($row['impressions']        ?? 0);
        $totals['clicks']             += (int)  ($row['clicks']             ?? 0);
        $totals['inline_link_clicks'] += (int)  ($row['inline_link_clicks'] ?? 0);
        $totals['reach']              += (int)  ($row['reach']              ?? 0);
    }
    $memo[$k] = $totals;
    return $totals;
}

/* ---------- DB-side aggregation for one date range.
              Attribution = users whose registered_at falls inside the range. */
function fetchFunnelDBTotalsForRange($pdo, $from, $to) {
    $out = [
        'registrations'     => 0,
        'exam_count'        => 0,
        'internship_count'  => 0,
        'second_internship' => 0,
        'revenue'           => 0.0,
    ];

    $stmt = $pdo->prepare("SELECT user_id FROM users WHERE registered_at BETWEEN ? AND ?");
    $stmt->execute([$from . ' 00:00:00', $to . ' 23:59:59']);
    $userIds = $stmt->fetchAll(PDO::FETCH_COLUMN);
    if (empty($userIds)) return $out;

    $out['registrations'] = count($userIds);
    $ph = implode(',', array_fill(0, count($userIds), '?'));

    $stmt = $pdo->prepare("SELECT COUNT(DISTINCT user_id) FROM cit_results WHERE user_id IN ($ph)");
    $stmt->execute($userIds);
    $out['exam_count'] = (int)$stmt->fetchColumn();

    $stmt = $pdo->prepare("
        SELECT user_id, COUNT(*) AS cnt, COALESCE(SUM(amount), 0) AS amt
        FROM payment_status
        WHERE status = 'success' AND user_id IN ($ph)
        GROUP BY user_id
    ");
    $stmt->execute($userIds);
    foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $r) {
        $out['internship_count']++;
        if ((int)$r['cnt'] >= 2) $out['second_internship']++;
        $out['revenue'] += (float)$r['amt'];
    }
    return $out;
}

/* ==========================================================================
   ACTION: get_cit_versions
   ========================================================================== */
if ($action === 'get_cit_versions') {
    try {
        $stmt = $pdo->query("
            SELECT exam_name
            FROM exam_batch_for_reports
            GROUP BY exam_name
            ORDER BY MAX(id) DESC
        ");
        $versions = $stmt->fetchAll(PDO::FETCH_COLUMN);
        jsonOut(['success' => true, 'versions' => $versions]);
    } catch (Exception $e) {
        jsonOut(['success' => false, 'message' => $e->getMessage()]);
    }
}

/* ==========================================================================
   ACTION: fetch_funnel_economics
   ========================================================================== */
if ($action === 'fetch_funnel_economics') {

    $ACCESS_TOKEN = getMetaToken($pdo);
    $GLOBALS['ACCESS_TOKEN'] = $ACCESS_TOKEN;
    if (!$ACCESS_TOKEN) {
        jsonOut(['success' => false, 'token_expired' => true, 'message' => 'Meta Access Token Missing']);
    }

    $mode     = $_POST['mode'] ?? 'versions';
    $versions = json_decode($_POST['versions'] ?? '[]', true);
    if (!is_array($versions)) $versions = [];
    $fromDate = $_POST['from_date'] ?? '';
    $toDate   = $_POST['to_date']   ?? '';

    try {
        // -------- 1. Date ranges to aggregate --------
        $ranges      = [];
        $sourceLabel = '';

        if ($mode === 'versions') {
            if (empty($versions)) {
                jsonOut(['success' => false, 'message' => 'No CIT versions provided']);
            }
            foreach ($versions as $v) {
                $r = getVersionDateRange($pdo, $v);
                if ($r) $ranges[] = ['from' => $r['from'], 'to' => $r['to'], 'version' => $v];
            }
            $sourceLabel = implode(' + ', $versions);
        } else {
            if ($fromDate === '' || $toDate === '') {
                jsonOut(['success' => false, 'message' => 'No date range provided']);
            }
            $ranges[]    = ['from' => $fromDate, 'to' => $toDate];
            $sourceLabel = "$fromDate to $toDate";
        }

        if (empty($ranges)) {
            jsonOut(['success' => false, 'message' => 'No valid ranges to process']);
        }

        // -------- 2. Meta totals across all ranges --------
        $meta = [
            'spend'              => 0.0,
            'impressions'        => 0,
            'clicks'             => 0,
            'inline_link_clicks' => 0,
            'reach'              => 0,
        ];
        foreach ($ranges as $r) {
            $t = fetchMetaAccountTotals($r['from'], $r['to']);
            if (isset($t['error'])) {
                if (isTokenExpiredError($t['error'])) {
                    jsonOut(['success' => false, 'token_expired' => true,
                             'message' => 'Meta Access Token Expired']);
                }
                throw new Exception('Meta API Error: ' . $t['error']);
            }
            $meta['spend']              += $t['spend'];
            $meta['impressions']        += $t['impressions'];
            $meta['clicks']             += $t['clicks'];
            $meta['inline_link_clicks'] += $t['inline_link_clicks'];
            $meta['reach']              += $t['reach'];
        }

        // -------- 3. DB totals across all ranges --------
        $db = [
            'registrations'     => 0,
            'exam_count'        => 0,
            'internship_count'  => 0,
            'second_internship' => 0,
            'revenue'           => 0.0,
        ];
        foreach ($ranges as $r) {
            $t = fetchFunnelDBTotalsForRange($pdo, $r['from'], $r['to']);
            $db['registrations']     += $t['registrations'];
            $db['exam_count']        += $t['exam_count'];
            $db['internship_count']  += $t['internship_count'];
            $db['second_internship'] += $t['second_internship'];
            $db['revenue']           += $t['revenue'];
        }

        // -------- 4. The 8 funnel-economics inputs --------
        // Prefer inline_link_clicks; fall back to all clicks if Meta did not
        // return the link-clicks field for this account / range.
        $linkClicks = $meta['inline_link_clicks'] > 0
            ? $meta['inline_link_clicks']
            : $meta['clicks'];

        $inputs = [
            'spend'       => round($meta['spend'], 2),
            'cpm'         => $meta['impressions'] > 0
                ? round($meta['spend'] / $meta['impressions'] * 1000, 2)
                : 0,
            'ctr'         => $meta['impressions'] > 0
                ? round($linkClicks / $meta['impressions'] * 100, 4)
                : 0,
            'lpCvr'       => $linkClicks > 0
                ? round($db['registrations'] / $linkClicks * 100, 4)
                : 0,
            'examRate'    => $db['registrations'] > 0
                ? round($db['exam_count'] / $db['registrations'] * 100, 4)
                : 0,
            'checkoutCvr' => $db['exam_count'] > 0
                ? round($db['internship_count'] / $db['exam_count'] * 100, 4)
                : 0,
            'aov'         => $db['internship_count'] > 0
                ? round($db['revenue'] / $db['internship_count'], 2)
                : 0,
            'repeat'      => $db['internship_count'] > 0
                ? round($db['second_internship'] / $db['internship_count'] * 100, 4)
                : 0,
        ];

        jsonOut([
            'success' => true,
            'inputs'  => $inputs,
            'raw'     => [
                'spend'              => round($meta['spend'], 2),
                'impressions'        => $meta['impressions'],
                'clicks'             => $meta['clicks'],
                'inline_link_clicks' => $meta['inline_link_clicks'],
                'reach'              => $meta['reach'],
                'registrations'      => $db['registrations'],
                'exam_count'         => $db['exam_count'],
                'internship_count'   => $db['internship_count'],
                'second_internship'  => $db['second_internship'],
                'revenue'            => round($db['revenue'], 2),
                'link_clicks_used'   => $linkClicks,
            ],
            'source'  => [
                'mode'   => $mode,
                'label'  => $sourceLabel,
                'ranges' => $ranges,
            ],
            'fetched_at' => date('Y-m-d H:i:s'),
        ]);

    } catch (Exception $e) {
        jsonOut(['success' => false, 'message' => $e->getMessage()]);
    }
}

/* ==========================================================================
   Unknown action
   ========================================================================== */
jsonOut(['success' => false, 'message' => 'Unknown action: ' . $action]);
<?php
/*
 * GET /api/reports/cit_versions.php
 *
 * Returns the same CIT version list the Meta Ads Dashboard uses,
 * sourced from `exam_batch_for_reports`. Sorted newest first so
 * versions[0] is the latest. from_date is shifted +1 day to match
 * the Meta Ads Dashboard's get_date_range behavior.
 *
 * Response:
 *   { versions: [
 *       { name: "CIT 45", from_date: "2024-12-02", to_date: "2024-12-08" },
 *       ...
 *   ] }
 */

ini_set('display_errors', 0);
error_reporting(E_ALL);
header('Content-Type: application/json; charset=utf-8');

function out($p, $code = 200) {
    http_response_code($code);
    echo json_encode($p);
    exit;
}
register_shutdown_function(function () {
    $e = error_get_last();
    if ($e && in_array($e['type'], [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR], true)) {
        if (!headers_sent()) {
            http_response_code(500);
            header('Content-Type: application/json; charset=utf-8');
        }
        echo json_encode(['error' => 'PHP fatal: ' . $e['message']]);
    }
});

try {
    $host     = '127.0.0.1:3306';
    $dbname   = 'istudio_cit';
    $username = 'istudio_admin';
    $password = 'h;V[ts@#;u{B';

    $pdo = new PDO(
        "mysql:host=$host;dbname=$dbname",
        $username,
        $password,
        [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ]
    );
    $pdo->exec("SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci");
    $pdo->exec("SET collation_connection = 'utf8mb4_unicode_ci'");

    // Latest row per exam_name (largest id), newest first.
    $sql = "
        SELECT exam_name, from_date, to_date
        FROM exam_batch_for_reports e1
        WHERE id = (
            SELECT MAX(id) FROM exam_batch_for_reports e2
            WHERE e2.exam_name = e1.exam_name
        )
        ORDER BY id DESC
    ";
    $rows = $pdo->query($sql)->fetchAll();

    $versions = [];
    foreach ($rows as $r) {
        $from = $r['from_date'] ? date('Y-m-d', strtotime($r['from_date'] . ' +1 day')) : '';
        $to   = $r['to_date']   ? date('Y-m-d', strtotime($r['to_date']))                : '';
        $versions[] = [
            'name'      => $r['exam_name'],
            'from_date' => $from,
            'to_date'   => $to,
        ];
    }

    out(['versions' => $versions]);

} catch (Throwable $e) {
    out(['error' => 'Server exception: ' . $e->getMessage()], 500);
}

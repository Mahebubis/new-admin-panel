<?php
/*
 * GET /api/reports/datewise_data_realtime.php
 *   ?start_date=YYYY-MM-DD&end_date=YYYY-MM-DD
 *   [&campaign=X][&adset=Y][&ad=Z][&expand=ads]
 *
 * Real-time replacement for datewise_data.php:
 *   - COST per (date, campaign[, adset, ad]) from Meta Graph API (Insights, time_increment=1)
 *   - LEADS + REVENUE from local MySQL (users / user_campaign / internship_payment / payment_status)
 *
 * Output (same shape as datewise_data.php so the React component is drop-in):
 *   { data: [{date, campaign, adset, ad, cost, revenue, leads, cpl, roi}, ...],
 *     counts: { "<campaign>": {adset_count, ad_count}, ... } }
 */

ini_set('display_errors', 0);
ini_set('log_errors',     1);
error_reporting(E_ALL);
header('Content-Type: application/json; charset=utf-8');

function out($payload, $code = 200) {
    http_response_code($code);
    echo json_encode($payload);
    exit;
}
// Convert any fatal/parse error into JSON
register_shutdown_function(function () {
    $err = error_get_last();
    if ($err && in_array($err['type'], [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR], true)) {
        if (!headers_sent()) {
            http_response_code(500);
            header('Content-Type: application/json; charset=utf-8');
        }
        echo json_encode(['error' => 'PHP fatal: ' . $err['message'] . ' at ' . $err['file'] . ':' . $err['line']]);
    }
});

try {

    /* ─── Inputs ─── */
    $start    = $_GET['start_date'] ?? '';
    $end      = $_GET['end_date']   ?? '';
    $campaign = trim(urldecode($_GET['campaign'] ?? ''));
    $adset    = trim(urldecode($_GET['adset']    ?? ''));
    $ad       = trim(urldecode($_GET['ad']       ?? ''));
    $expand   = $_GET['expand'] ?? '';

    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $start) || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $end)) {
        out(['error' => 'start_date and end_date required as YYYY-MM-DD']);
    }

    /* ─── CACHE: 5-min file cache keyed by all query params ─── */
    // Pass ?nocache=1 to force a fresh fetch.
    $cache_ttl  = 300; // seconds
    $cache_dir  = sys_get_temp_dir() . '/datewise_realtime_cache';
    if (!is_dir($cache_dir)) @mkdir($cache_dir, 0777, true);
    $cache_key  = md5(implode('|', [$start, $end, $campaign, $adset, $ad, $expand]));
    $cache_file = $cache_dir . '/' . $cache_key . '.json';
    $nocache    = !empty($_GET['nocache']);

    if (!$nocache && is_file($cache_file) && (time() - filemtime($cache_file)) < $cache_ttl) {
        header('X-Cache: HIT');
        header('X-Cache-Age: ' . (time() - filemtime($cache_file)) . 's');
        readfile($cache_file);
        exit;
    }

    /* ─── DB (direct PDO — proven pattern from meta_ads.php) ─── */
    $host     = '127.0.0.1:3306';
    $dbname   = 'istudio_cit';
    $username = 'istudio_admin';
    $password = 'h;V[ts@#;u{B';

    try {
        // No `charset=` in DSN — on MySQL 8 it pins the connection to
        // utf8mb4_0900_ai_ci which collides with the tables' utf8mb4_unicode_ci.
        $pdo = new PDO(
            "mysql:host=$host;dbname=$dbname",
            $username,
            $password,
            [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            ]
        );
        // Force connection charset + collation to match the tables. INIT_COMMAND
        // wasn't sticking; explicit exec() does.
        $pdo->exec("SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci");
        $pdo->exec("SET collation_connection = 'utf8mb4_unicode_ci'");
    } catch (PDOException $e) {
        out(['error' => 'DB connect failed: ' . $e->getMessage()], 500);
    }

    /* ─── Meta token ─── */
    define('AD_ACCOUNT_ID', 'act_440296640847969');

    $token = '';
    try {
        $stmt = $pdo->prepare("SELECT settings_value FROM settings WHERE settings_key='meta_access_token' LIMIT 1");
        $stmt->execute();
        $token = (string)$stmt->fetchColumn();
    } catch (Exception $e) {
        out(['error' => 'Token lookup failed: ' . $e->getMessage()]);
    }
    if ($token === '') {
        out(['error' => 'Meta access token not configured in settings table']);
    }

    /* ─── 1. Fetch Meta insights, paginated ─── */
    $fields = [
        'campaign_id','campaign_name',
        'adset_id','adset_name',
        'ad_id','ad_name',
        'spend','impressions','date_start',
    ];

    $insights   = [];
    $meta_error = null;   // non-fatal: a Meta failure must NOT hide the DB data

    /* Meta Insights cannot span the future. The current/ongoing CIT version has a
       to_date in the future, which makes Meta reject the whole request — clamp the
       window to today so cost data still comes back for the elapsed part. The DB
       leads/revenue/exams queries below keep the full requested range. */
    $today      = date('Y-m-d');
    $meta_since = $start;
    $meta_until = ($end > $today) ? $today : $end;

    if ($meta_since > $today) {
        // Entire range is in the future — no ad spend can exist yet; skip Meta.
        $meta_error = 'requested range is in the future; no ad spend data yet';
    } else {
        $url = 'https://graph.facebook.com/v19.0/' . AD_ACCOUNT_ID . '/insights'
             . '?level=ad'
             . '&fields=' . implode(',', $fields)
             . '&time_range=' . urlencode(json_encode(['since' => $meta_since, 'until' => $meta_until]))
             . '&time_increment=1'
             . '&limit=5000'   // bumped from 500 — fewer pagination round-trips
             . '&access_token=' . urlencode($token);

        $guard = 0;
        while ($url && $guard < 50) {
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL,            $url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($ch, CURLOPT_TIMEOUT,        60);
            $resp = curl_exec($ch);
            $cerr = curl_error($ch);
            curl_close($ch);

            // On any Meta problem, stop fetching but STILL return DB-sourced rows.
            if ($resp === false) { $meta_error = 'Meta cURL failed: ' . $cerr; break; }
            $decoded = json_decode($resp, true);
            if (!is_array($decoded)) { $meta_error = 'Meta returned non-JSON: ' . substr($resp, 0, 300); break; }
            if (isset($decoded['error'])) { $meta_error = 'Meta API: ' . ($decoded['error']['message'] ?? 'unknown'); break; }

            if (!empty($decoded['data'])) {
                foreach ($decoded['data'] as $row) $insights[] = $row;
            }
            $url = $decoded['paging']['next'] ?? null;
            $guard++;
        }
    }

    /* ─── 2. Aggregate spend + impressions per (date, campaign[, adset, ad]) ─── */
    $spend_map = []; // key => ['cost' => float, 'impressions' => int]
    $camp_adset_set = [];
    $camp_ad_set    = [];

    foreach ($insights as $row) {
        $r_camp  = trim($row['campaign_name'] ?? '');
        $r_adset = trim($row['adset_name']    ?? '');
        $r_ad    = trim($row['ad_name']       ?? '');
        $r_date  = $row['date_start']         ?? '';
        $r_spend = (float)($row['spend']       ?? 0);
        $r_impr  = (int)  ($row['impressions'] ?? 0);
        if ($r_camp === '' || $r_date === '') continue;

        if ($campaign !== '' && $r_camp  !== $campaign) continue;
        if ($adset    !== '' && $r_adset !== $adset)    continue;
        if ($ad       !== '' && $r_ad    !== $ad)       continue;

        if ($r_adset !== '') $camp_adset_set[$r_camp][$r_adset] = true;
        if ($r_ad    !== '') $camp_ad_set[$r_camp][$r_ad]       = true;

        $key = ($expand === 'ads')
            ? "$r_date|$r_camp|$r_adset|$r_ad"
            : "$r_date|$r_camp||";
        if (!isset($spend_map[$key])) $spend_map[$key] = ['cost' => 0, 'impressions' => 0];
        $spend_map[$key]['cost']        += $r_spend;
        $spend_map[$key]['impressions'] += $r_impr;
    }

    /* ─── 3. Leads + Revenue from DB ─── */
    // Split the original triple-JOIN into 3 small queries with IN() lookups.
    // The previous JOIN used CONVERT() to bridge mismatched column collations,
    // which forces a full table scan. This version lets each query use its
    // primary/index lookup and gives a big speedup on wide date ranges.
    $leads_map = [];
    try {
        // 3a. Users registered in the date range.
        $stmt = $pdo->prepare("
            SELECT user_id, DATE(registered_at) AS reg_date
            FROM users
            WHERE DATE(registered_at) BETWEEN :s AND :e
        ");
        $stmt->execute([':s' => $start, ':e' => $end]);
        $user_dates = [];   // user_id => reg_date
        foreach ($stmt->fetchAll() as $r) {
            $user_dates[$r['user_id']] = $r['reg_date'];
        }
        $user_ids = array_keys($user_dates);

        // Helper: chunk huge IN() lists.
        $chunk = function ($arr, $size = 5000) {
            return array_chunk($arr, $size);
        };

        if (!empty($user_ids)) {
            // 3b. Campaign / adset / ad for those users.
            $user_camp = []; // user_id => [campaign, adset, ad]
            foreach ($chunk($user_ids) as $batch) {
                $ph = implode(',', array_fill(0, count($batch), '?'));
                $st = $pdo->prepare("
                    SELECT user_id, campaign, adset, ad
                    FROM user_campaign
                    WHERE user_id IN ($ph)
                ");
                $st->execute($batch);
                foreach ($st->fetchAll() as $r) {
                    // If a user has multiple campaign rows, keep the first.
                    if (!isset($user_camp[$r['user_id']])) $user_camp[$r['user_id']] = $r;
                }
            }

            // 3c. Total successful revenue per user.
            $user_revenue = []; // user_id => float
            foreach ($chunk($user_ids) as $batch) {
                $ph = implode(',', array_fill(0, count($batch), '?'));
                $st = $pdo->prepare("
                    SELECT ip.user_id, COALESCE(SUM(ps.amount), 0) AS revenue
                    FROM internship_payment ip
                    JOIN payment_status ps
                      ON CONVERT(ps.payment_id USING utf8mb4) COLLATE utf8mb4_unicode_ci
                       = CONVERT(ip.payment_id USING utf8mb4) COLLATE utf8mb4_unicode_ci
                    WHERE ip.user_id IN ($ph)
                    GROUP BY ip.user_id
                ");
                $st->execute($batch);
                foreach ($st->fetchAll() as $r) {
                    $user_revenue[$r['user_id']] = (float)$r['revenue'];
                }
            }

            // 3c-2. Which of those users gave the CIT exam (have a cit_results row).
            //        Same definition used by analytics_dashboard.php.
            $exam_users = []; // user_id => true
            foreach ($chunk($user_ids) as $batch) {
                $ph = implode(',', array_fill(0, count($batch), '?'));
                $st = $pdo->prepare("SELECT DISTINCT user_id FROM cit_results WHERE user_id IN ($ph)");
                $st->execute($batch);
                foreach ($st->fetchAll() as $r) {
                    $exam_users[$r['user_id']] = true;
                }
            }

            // 3d. Aggregate to leads_map[date|camp|adset|ad].
            foreach ($user_dates as $uid => $date) {
                $info = $user_camp[$uid] ?? ['campaign' => '', 'adset' => '', 'ad' => ''];

                // Apply optional filters (same as the old WHERE).
                if ($campaign !== '' && $info['campaign'] !== $campaign) continue;
                if ($adset    !== '' && $info['adset']    !== $adset)    continue;
                if ($ad       !== '' && $info['ad']       !== $ad)       continue;

                $key = ($expand === 'ads')
                    ? "$date|{$info['campaign']}|{$info['adset']}|{$info['ad']}"
                    : "$date|{$info['campaign']}||";

                if (!isset($leads_map[$key])) $leads_map[$key] = ['leads' => 0, 'revenue' => 0.0, 'exams' => 0];
                $leads_map[$key]['leads']   += 1;
                $leads_map[$key]['revenue'] += $user_revenue[$uid] ?? 0;
                if (isset($exam_users[$uid])) $leads_map[$key]['exams'] += 1;
            }
        }
    } catch (Exception $e) {
        out(['error' => 'Leads query failed: ' . $e->getMessage()]);
    }

    /* ─── 4. Merge ─── */
    $all_keys = array_unique(array_merge(array_keys($spend_map), array_keys($leads_map)));
    $rows = [];
    foreach ($all_keys as $key) {
        $parts = explode('|', $key, 4);
        $date  = $parts[0] ?? '';
        $camp  = $parts[1] ?? '';
        $ads_  = $parts[2] ?? '';
        $adv   = $parts[3] ?? '';
        $sm    = $spend_map[$key] ?? ['cost' => 0, 'impressions' => 0];
        $cost  = (float)$sm['cost'];
        $impr  = (int)  $sm['impressions'];
        $leads   = $leads_map[$key]['leads']   ?? 0;
        $revenue = $leads_map[$key]['revenue'] ?? 0;
        $exams   = $leads_map[$key]['exams']   ?? 0;
        $roi     = $cost  > 0 ? round($revenue / $cost,  4) : 0;
        $cpl     = $leads > 0 ? round($cost    / $leads, 2) : 0;
        $cpm     = $impr  > 0 ? round(($cost / $impr) * 1000, 2) : 0;
        $cpe     = $exams > 0 ? round($cost    / $exams, 2) : 0;
        $rows[] = [
            'date'        => $date,
            'campaign'    => $camp,
            'adset'       => $ads_,
            'ad'          => $adv,
            'cost'        => round($cost, 2),
            'impressions' => $impr,
            'revenue'     => round($revenue, 2),
            'leads'       => $leads,
            'exams'       => $exams,
            'cpl'         => $cpl,
            'cpm'         => $cpm,
            'cpe'         => $cpe,
            'roi'         => $roi,
        ];
    }
    usort($rows, function ($a, $b) {
        return $a['date'] <=> $b['date'] ?: strcmp($a['campaign'], $b['campaign']);
    });

    /* ─── 5. Counts ─── */
    $counts = [];
    foreach ($camp_adset_set as $c => $set) {
        $counts[$c] = ['adset_count' => count($set), 'ad_count' => 0];
    }
    foreach ($camp_ad_set as $c => $set) {
        if (!isset($counts[$c])) $counts[$c] = ['adset_count' => 0, 'ad_count' => 0];
        $counts[$c]['ad_count'] = count($set);
    }

    // Persist to cache then respond (X-Cache: MISS so client can see first-load timing).
    // `meta_error` is informational only — `data` still carries the DB-sourced
    // leads/revenue/exams so the report is never blank for a version.
    $json = json_encode(['data' => $rows, 'counts' => $counts, 'meta_error' => $meta_error]);
    // Don't cache a Meta-failed response — otherwise a transient outage would pin
    // cost=0 for 5 minutes. A clean fetch is cached as normal.
    if ($meta_error === null) {
        @file_put_contents($cache_file, $json);
    }
    header('X-Cache: MISS');
    echo $json;
    exit;

} catch (Throwable $e) {
    out(['error' => 'Server exception: ' . $e->getMessage() . ' at ' . $e->getFile() . ':' . $e->getLine()], 500);
}

// ===========================================================================
//  LmsCourses.jsx — the "Courses" tab (Learnyst Products → Courses).
//
//  Card grid + counter strip + a create drawer that matches Learnyst's
//  Create Course screen (title / price / free toggle / content-security radio
//  cards), plus a full settings drawer for an existing course.
// ===========================================================================
import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import toast from 'react-hot-toast';
import {
  Plus, Search, MoreVertical, BookOpen, Clock, Lock, Unlock, Trash2,
  Copy, Settings2, Eye, EyeOff, RotateCcw, ImagePlus, Layers, Users, Grid3x3,
} from 'lucide-react';
import { LMS, money, duration } from './lmsApi';
import { Loader, Empty, Pill, Drawer, Confirm } from './LmsStyles';
import { useOutsideClose } from './lmsTheme';

const STATUS_FILTERS = [
  { key: 'all', label: 'All' },
  { key: 'published', label: 'Published' },
  { key: 'draft', label: 'Draft' },
  { key: 'trashed', label: 'Trash' },
];

const emptyCourse = {
  title: '', subtitle: '', description: '', category: '', instructor: '',
  price: '', sale_price: '', is_free: false, validity_days: 365,
  encryption: 'unencrypted', status: 'draft', seo_title: '', seo_description: '',
};

/* ── per-card ⋯ menu ─────────────────────────────────────────── */
function CardMenu({ course, onPublish, onDuplicate, onTrash, onRestore, onDelete, onSettings }) {
  const [open, setOpen] = useState(false);
  const ref = useRef(null);
  useOutsideClose(ref, () => setOpen(false), open);

  const trashed = course.status === 'trashed';
  return (
    <div style={{ position: 'relative' }} ref={ref}>
      <button className="lms-icon-btn" onClick={(e) => { e.preventDefault(); setOpen(o => !o); }} aria-label="Course actions">
        <MoreVertical size={17} />
      </button>
      {open && (
        <div className="lms-menu" onClick={() => setOpen(false)}>
          {trashed ? (
            <>
              <button onClick={() => onRestore(course)}><RotateCcw size={15} /> Restore course</button>
              <div className="lms-menu-sep" />
              <button className="danger" onClick={() => onDelete(course)}><Trash2 size={15} /> Delete permanently</button>
            </>
          ) : (
            <>
              <button onClick={() => onSettings(course)}><Settings2 size={15} /> Course settings</button>
              <button onClick={() => onPublish(course)}>
                {course.status === 'published' ? <><EyeOff size={15} /> Unpublish</> : <><Eye size={15} /> Publish</>}
              </button>
              <button onClick={() => onDuplicate(course)}><Copy size={15} /> Duplicate</button>
              <div className="lms-menu-sep" />
              <button className="danger" onClick={() => onTrash(course)}><Trash2 size={15} /> Move to trash</button>
            </>
          )}
        </div>
      )}
    </div>
  );
}

export default function LmsCourses() {
  const navigate = useNavigate();
  const [params, setParams] = useSearchParams();

  const [loading, setLoading] = useState(true);
  const [courses, setCourses] = useState([]);
  const [counts, setCounts] = useState({});
  const [status, setStatus] = useState('all');
  const [q, setQ] = useState('');
  const [search, setSearch] = useState('');

  const [createOpen, setCreateOpen] = useState(params.get('new') === '1');
  const [draft, setDraft] = useState(emptyCourse);
  const [saving, setSaving] = useState(false);

  const [editing, setEditing] = useState(null);   // full course being edited
  const [confirm, setConfirm] = useState(null);   // { title, message, label, run }

  const thumbInput = useRef(null);
  const [thumbTarget, setThumbTarget] = useState(null);

  /* debounce the search box so we aren't querying on every keystroke */
  useEffect(() => {
    const t = setTimeout(() => setSearch(q.trim()), 300);
    return () => clearTimeout(t);
  }, [q]);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const d = await LMS.listCourses({ status, q: search });
      setCourses(d.courses || []);
      setCounts(d.counts || {});
    } catch (e) {
      toast.error(e.message);
    } finally {
      setLoading(false);
    }
  }, [status, search]);

  useEffect(() => { load(); }, [load]);

  /* Consume the deep-links other screens send us — ?new=1 opens the create
     drawer, ?settings=<id> opens that course's settings (the builder's
     Settings button) — then strip the param so a refresh doesn't re-open it. */
  useEffect(() => {
    const settingsId = params.get('settings');
    if (params.get('new') !== '1' && !settingsId) return;

    if (settingsId) {
      LMS.getCourse(settingsId)
        .then(d => setEditing({ ...d.course, is_free: !!Number(d.course.is_free) }))
        .catch(e => toast.error(e.message));
    }
    const next = new URLSearchParams(params);
    next.delete('new');
    next.delete('settings');
    setParams(next, { replace: true });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const createCourse = async () => {
    if (!draft.title.trim()) return toast.error('Course title is required');
    setSaving(true);
    try {
      const d = await LMS.createCourse({
        ...draft,
        price: draft.is_free ? 0 : Number(draft.price || 0),
        sale_price: Number(draft.sale_price || 0),
        is_free: draft.is_free ? 1 : 0,
      });
      toast.success('Course created');
      setCreateOpen(false);
      setDraft(emptyCourse);
      navigate(`/lms/courses/${d.id}`);
    } catch (e) {
      toast.error(e.message);
    } finally {
      setSaving(false);
    }
  };

  const saveSettings = async () => {
    if (!editing?.title?.trim()) return toast.error('Course title is required');
    setSaving(true);
    try {
      await LMS.updateCourse({
        ...editing,
        price: editing.is_free ? 0 : Number(editing.price || 0),
        sale_price: Number(editing.sale_price || 0),
        is_free: editing.is_free ? 1 : 0,
      });
      toast.success('Course updated');
      setEditing(null);
      load();
    } catch (e) {
      toast.error(e.message);
    } finally {
      setSaving(false);
    }
  };

  const act = (fn, msg) => async (course) => {
    try {
      await fn(course.id);
      toast.success(msg);
      load();
    } catch (e) {
      toast.error(e.message);
    }
  };

  const onPublish = async (course) => {
    const next = course.status === 'published' ? 'unpublished' : 'published';
    try {
      await LMS.publishCourse(course.id, next);
      toast.success(next === 'published' ? 'Course published' : 'Course unpublished');
      load();
    } catch (e) { toast.error(e.message); }
  };

  const pickThumb = (course) => {
    setThumbTarget(course);
    thumbInput.current?.click();
  };

  const uploadThumb = async (e) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file || !thumbTarget) return;
    if (!file.type.startsWith('image/')) return toast.error('Pick an image file');
    const t = toast.loading('Uploading thumbnail…');
    try {
      const fd = new FormData();
      fd.append('id', thumbTarget.id);
      fd.append('file', file);
      await LMS.uploadThumbnail(fd);
      toast.success('Thumbnail updated', { id: t });
      load();
    } catch (err) {
      toast.error(err.message, { id: t });
    } finally {
      setThumbTarget(null);
    }
  };

  const counters = useMemo(() => ([
    { label: 'Total Courses', value: counts.total ?? 0,     icon: <Grid3x3 size={18} /> },
    { label: 'Published',     value: counts.published ?? 0, icon: <Eye size={18} /> },
    { label: 'Draft',         value: counts.draft ?? 0,     icon: <Layers size={18} /> },
    { label: 'Trashed',       value: counts.trashed ?? 0,   icon: <Trash2 size={18} /> },
  ]), [counts]);

  return (
    <div className="lms-page">
      <input ref={thumbInput} type="file" accept="image/*" hidden onChange={uploadThumb} />

      <div className="lms-page-head">
        <div>
          <h1 className="lms-h1">Courses</h1>
          <p className="lms-sub">Welcome to your course dashboard</p>
        </div>
        <button className="lms-btn lms-btn-dark" onClick={() => { setDraft(emptyCourse); setCreateOpen(true); }}>
          <Plus size={17} /> Create
        </button>
      </div>

      <div className="lms-toolbar">
        <div className="lms-search">
          <Search size={16} />
          <input placeholder="Search by title" value={q} onChange={e => setQ(e.target.value)} />
        </div>
        <div className="lms-segment">
          {STATUS_FILTERS.map(f => (
            <button key={f.key} className={status === f.key ? 'active' : ''} onClick={() => setStatus(f.key)}>
              {f.label}
            </button>
          ))}
        </div>
      </div>

      <div className="lms-counters">
        {counters.map(c => (
          <div className="lms-counter" key={c.label}>
            <div>
              <div className="lms-counter-label">{c.label}</div>
              <div className="lms-counter-value">{c.value}</div>
            </div>
            <span style={{ color: 'var(--lms-text-3)' }}>{c.icon}</span>
          </div>
        ))}
      </div>

      {loading ? (
        <Loader />
      ) : courses.length === 0 ? (
        <Empty
          icon={<BookOpen size={24} />}
          title={search ? 'No courses match that search' : 'No courses yet'}
          message={
            search
              ? 'Try a different title or clear the search box.'
              : 'Create your first course, then add modules and video lessons inside it.'
          }
          action={!search && (
            <button className="lms-btn lms-btn-dark" onClick={() => setCreateOpen(true)}>
              <Plus size={16} /> Create course
            </button>
          )}
        />
      ) : (
        <div className="lms-course-grid">
          {courses.map(c => (
            <div className="lms-course-card" key={c.id}>
              <Link to={c.status === 'trashed' ? '#' : `/lms/courses/${c.id}`}
                onClick={e => c.status === 'trashed' && e.preventDefault()}>
                <div className="lms-course-thumb">
                  {c.thumbnail_url
                    ? <img src={c.thumbnail_url} alt={c.title} />
                    : <div className="lms-course-thumb-ph">{c.title}</div>}
                  <span className="lms-validity"><Clock size={11} /> {c.validity_days || 0} Days</span>
                </div>
              </Link>

              <div className="lms-course-body">
                <Link to={c.status === 'trashed' ? '#' : `/lms/courses/${c.id}`}
                  onClick={e => c.status === 'trashed' && e.preventDefault()}>
                  <div className="lms-course-title">{c.title}</div>
                </Link>
                <div className="lms-course-meta">
                  {c.lesson_count} Lesson{c.lesson_count === 1 ? '' : 's'} • {duration(c.total_secs)}
                </div>
                <div className="lms-course-price">
                  {c.is_free ? 'Free' : money(c.sale_price > 0 ? c.sale_price : c.price)}
                  {!c.is_free && c.sale_price > 0 && c.sale_price < c.price && (
                    <span style={{ fontSize: 12.5, color: 'var(--lms-text-3)', textDecoration: 'line-through', marginLeft: 8 }}>
                      {money(c.price)}
                    </span>
                  )}
                </div>

                <div className="lms-course-foot">
                  <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
                    <Pill tone={
                      c.status === 'published' ? 'green' : c.status === 'trashed' ? 'red' : 'grey'
                    }>
                      {c.status === 'published' ? 'Published' : c.status === 'trashed' ? 'Trashed' : 'Unpublished'}
                    </Pill>
                    <Pill tone="grey">
                      {c.encryption === 'encrypted' ? <><Lock size={11} /> Encrypted</> : <><Unlock size={11} /> Unencrypted</>}
                    </Pill>
                  </div>
                  <div style={{ display: 'flex', alignItems: 'center' }}>
                    {c.status !== 'trashed' && (
                      <button className="lms-icon-btn" title="Change thumbnail" onClick={() => pickThumb(c)}>
                        <ImagePlus size={16} />
                      </button>
                    )}
                    <CardMenu
                      course={c}
                      onSettings={async (co) => {
                        try {
                          const d = await LMS.getCourse(co.id);
                          setEditing({ ...d.course, is_free: !!Number(d.course.is_free) });
                        } catch (e) { toast.error(e.message); }
                      }}
                      onPublish={onPublish}
                      onDuplicate={act(LMS.duplicateCourse, 'Course duplicated')}
                      onRestore={act(LMS.restoreCourse, 'Course restored')}
                      onTrash={(co) => setConfirm({
                        title: 'Move course to trash?',
                        message: `"${co.title}" will be hidden from learners. You can restore it from the Trash filter at any time.`,
                        label: 'Move to trash',
                        run: async () => { await LMS.trashCourse(co.id); toast.success('Moved to trash'); setConfirm(null); load(); },
                      })}
                      onDelete={(co) => setConfirm({
                        title: 'Delete course permanently?',
                        message: `"${co.title}", all its modules, lessons, attachments, form responses and enrollments will be deleted. This cannot be undone.`,
                        label: 'Delete permanently',
                        run: async () => { await LMS.deleteCourse(co.id); toast.success('Course deleted'); setConfirm(null); load(); },
                      })}
                    />
                  </div>
                </div>

                <div style={{ display: 'flex', gap: 14, fontSize: 11.5, color: 'var(--lms-text-3)' }}>
                  <span style={{ display: 'inline-flex', gap: 4, alignItems: 'center' }}>
                    <Layers size={12} /> {c.section_count} sections
                  </span>
                  <span style={{ display: 'inline-flex', gap: 4, alignItems: 'center' }}>
                    <Users size={12} /> {c.enroll_count} enrolled
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* ── create drawer ─────────────────────────────────────── */}
      <Drawer
        open={createOpen}
        title="Create Course"
        subtitle="Start creating a new course"
        onClose={() => setCreateOpen(false)}
        footer={
          <>
            <button className="lms-btn lms-btn-ghost" onClick={() => setCreateOpen(false)}>Cancel</button>
            <button className="lms-btn lms-btn-dark" onClick={createCourse} disabled={saving}>
              {saving ? 'Creating…' : 'Create'}
            </button>
          </>
        }
      >
        <div className="lms-field">
          <label className="lms-label">
            Title<span className="req">*</span>
            <span className="lms-char-count">{draft.title.length}/60</span>
          </label>
          <input
            className="lms-input"
            maxLength={60}
            placeholder="Enter course title"
            value={draft.title}
            onChange={e => setDraft(d => ({ ...d, title: e.target.value }))}
          />
        </div>

        <div className="lms-field">
          <label className="lms-label">Price</label>
          <input
            className="lms-input"
            type="number"
            min="0"
            placeholder="₹ Price"
            disabled={draft.is_free}
            value={draft.price}
            onChange={e => setDraft(d => ({ ...d, price: e.target.value }))}
          />
          <label className="lms-check" style={{ marginTop: 12 }}>
            <input
              type="checkbox"
              checked={draft.is_free}
              onChange={e => setDraft(d => ({ ...d, is_free: e.target.checked }))}
            />
            Make this a free course
          </label>
        </div>

        <div className="lms-field">
          <label className="lms-label">Content Security</label>
          <label className={`lms-radio-card${draft.encryption === 'encrypted' ? ' on' : ''}`}>
            <input
              type="radio"
              checked={draft.encryption === 'encrypted'}
              onChange={() => setDraft(d => ({ ...d, encryption: 'encrypted' }))}
            />
            <div>
              <div style={{ fontWeight: 600, fontSize: 13.5, display: 'flex', alignItems: 'center', gap: 8 }}>
                Encryption <Pill tone="amber">Recommended</Pill>
              </div>
              <p className="lms-help">
                Secure content will be encrypted using the DRM system and will be protected against piracy.
              </p>
            </div>
          </label>
          <label className={`lms-radio-card${draft.encryption === 'unencrypted' ? ' on' : ''}`}>
            <input
              type="radio"
              checked={draft.encryption === 'unencrypted'}
              onChange={() => setDraft(d => ({ ...d, encryption: 'unencrypted' }))}
            />
            <div>
              <div style={{ fontWeight: 600, fontSize: 13.5 }}>No Encryption</div>
              <p className="lms-help">
                Content will not be encrypted. Unsecure content can be easily downloaded and pirated.
              </p>
            </div>
          </label>
        </div>

        <div className="lms-row-2">
          <div className="lms-field">
            <label className="lms-label">Validity (days)</label>
            <input
              className="lms-input" type="number" min="0"
              value={draft.validity_days}
              onChange={e => setDraft(d => ({ ...d, validity_days: e.target.value }))}
            />
          </div>
          <div className="lms-field">
            <label className="lms-label">Category</label>
            <input
              className="lms-input" placeholder="e.g. Software Testing"
              value={draft.category}
              onChange={e => setDraft(d => ({ ...d, category: e.target.value }))}
            />
          </div>
        </div>
      </Drawer>

      {/* ── settings drawer ───────────────────────────────────── */}
      <Drawer
        open={!!editing}
        title="Course Settings"
        subtitle={editing?.title}
        onClose={() => setEditing(null)}
        footer={
          <>
            <button className="lms-btn lms-btn-ghost" onClick={() => setEditing(null)}>Cancel</button>
            <button className="lms-btn lms-btn-dark" onClick={saveSettings} disabled={saving}>
              {saving ? 'Saving…' : 'Save changes'}
            </button>
          </>
        }
      >
        {editing && (
          <>
            <div className="lms-field">
              <label className="lms-label">Title<span className="req">*</span></label>
              <input className="lms-input" maxLength={60} value={editing.title}
                onChange={e => setEditing(s => ({ ...s, title: e.target.value }))} />
            </div>
            <div className="lms-field">
              <label className="lms-label">Subtitle</label>
              <input className="lms-input" value={editing.subtitle || ''}
                onChange={e => setEditing(s => ({ ...s, subtitle: e.target.value }))} />
            </div>
            <div className="lms-field">
              <label className="lms-label">Description</label>
              <textarea className="lms-textarea" value={editing.description || ''}
                onChange={e => setEditing(s => ({ ...s, description: e.target.value }))} />
            </div>
            <div className="lms-row-2">
              <div className="lms-field">
                <label className="lms-label">Category</label>
                <input className="lms-input" value={editing.category || ''}
                  onChange={e => setEditing(s => ({ ...s, category: e.target.value }))} />
              </div>
              <div className="lms-field">
                <label className="lms-label">Instructor</label>
                <input className="lms-input" value={editing.instructor || ''}
                  onChange={e => setEditing(s => ({ ...s, instructor: e.target.value }))} />
              </div>
            </div>
            <div className="lms-row-3">
              <div className="lms-field">
                <label className="lms-label">Price</label>
                <input className="lms-input" type="number" min="0" disabled={editing.is_free}
                  value={editing.price ?? ''}
                  onChange={e => setEditing(s => ({ ...s, price: e.target.value }))} />
              </div>
              <div className="lms-field">
                <label className="lms-label">Sale price</label>
                <input className="lms-input" type="number" min="0" disabled={editing.is_free}
                  value={editing.sale_price ?? ''}
                  onChange={e => setEditing(s => ({ ...s, sale_price: e.target.value }))} />
              </div>
              <div className="lms-field">
                <label className="lms-label">Validity (days)</label>
                <input className="lms-input" type="number" min="0" value={editing.validity_days ?? 365}
                  onChange={e => setEditing(s => ({ ...s, validity_days: e.target.value }))} />
              </div>
            </div>
            <label className="lms-check" style={{ marginBottom: 18 }}>
              <input type="checkbox" checked={!!editing.is_free}
                onChange={e => setEditing(s => ({ ...s, is_free: e.target.checked }))} />
              Make this a free course
            </label>

            <div className="lms-row-2">
              <div className="lms-field">
                <label className="lms-label">Content security</label>
                <select className="lms-select" value={editing.encryption}
                  onChange={e => setEditing(s => ({ ...s, encryption: e.target.value }))}>
                  <option value="unencrypted">No Encryption</option>
                  <option value="encrypted">Encryption (DRM)</option>
                </select>
              </div>
              <div className="lms-field">
                <label className="lms-label">Status</label>
                <select className="lms-select" value={editing.status}
                  onChange={e => setEditing(s => ({ ...s, status: e.target.value }))}>
                  <option value="draft">Draft</option>
                  <option value="published">Published</option>
                  <option value="unpublished">Unpublished</option>
                </select>
              </div>
            </div>

            <div className="lms-divider" />
            <h3 className="lms-h3" style={{ marginBottom: 14 }}>SEO</h3>
            <div className="lms-field">
              <label className="lms-label">SEO title</label>
              <input className="lms-input" value={editing.seo_title || ''}
                onChange={e => setEditing(s => ({ ...s, seo_title: e.target.value }))} />
            </div>
            <div className="lms-field">
              <label className="lms-label">SEO description</label>
              <textarea className="lms-textarea" style={{ minHeight: 70 }} value={editing.seo_description || ''}
                onChange={e => setEditing(s => ({ ...s, seo_description: e.target.value }))} />
            </div>
          </>
        )}
      </Drawer>

      <Confirm
        open={!!confirm}
        title={confirm?.title}
        message={confirm?.message}
        confirmLabel={confirm?.label}
        onCancel={() => setConfirm(null)}
        onConfirm={() => confirm?.run()}
      />
    </div>
  );
}

// ===========================================================================
//  LmsCourseBuilder.jsx — the course content builder.
//
//  This is the screen the whole LMS is built around: open a course card and you
//  get its modules (sections); expand a module and you get its lessons; add a
//  lesson and you land in the lesson editor where the video, attachments and
//  the per-lesson data-collection form live.
//
//  Layout follows Learnyst's /contents/content-builder page 1:1 — numbered
//  section rows, the stats strip (hidden / lessons / quizzes / duration), the
//  green "Add lesson" bar inside each expanded module and the "Add Section"
//  bar at the bottom.
// ===========================================================================
import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import toast from 'react-hot-toast';
import {
  ChevronLeft, ChevronDown, ChevronUp, Plus, MoreVertical, Settings2, Search,
  PlayCircle, FileText, HelpCircle, Radio, ClipboardList, EyeOff, Paperclip,
  Trash2, ArrowDownToLine, ArrowUpToLine, ArrowDown, ArrowUp, Pencil, Link2,
  BookOpen, Clock, Layers, ArrowRightLeft,
} from 'lucide-react';
import { LMS, duration } from './lmsApi';
import { Loader, Empty, Pill, Drawer, Modal, Confirm } from './LmsStyles';
import { useOutsideClose } from './lmsTheme';

const LESSON_TYPES = [
  { key: 'video',   label: 'Video',   icon: PlayCircle,    hint: 'Upload or link a lecture video' },
  { key: 'article', label: 'Article', icon: FileText,      hint: 'A rich-text note or reading' },
  { key: 'pdf',     label: 'PDF',     icon: Paperclip,     hint: 'A downloadable document' },
  { key: 'quiz',    label: 'Quiz',    icon: HelpCircle,    hint: 'Attach a quiz from the Quizzes tab' },
  { key: 'form',    label: 'Form',    icon: ClipboardList, hint: 'Collect data from the learner' },
  { key: 'live',    label: 'Live',    icon: Radio,         hint: 'A scheduled live class link' },
];

const typeIcon = (t) => (LESSON_TYPES.find(x => x.key === t)?.icon) || PlayCircle;

/* ── ⋯ menu on a lesson row ──────────────────────────────────── */
function LessonMenu({ lesson, sections, onMove, onAddNext, onBottom, onTrash, onCopyUrl }) {
  const [open, setOpen] = useState(false);
  const [moveOpen, setMoveOpen] = useState(false);
  const ref = useRef(null);
  useOutsideClose(ref, () => { setOpen(false); setMoveOpen(false); }, open);

  return (
    <div style={{ position: 'relative' }} ref={ref}>
      <button className="lms-icon-btn" onClick={() => setOpen(o => !o)} aria-label="Lesson actions">
        <MoreVertical size={16} />
      </button>
      {open && (
        <div className="lms-menu">
          <button onClick={() => setMoveOpen(m => !m)}>
            <ArrowRightLeft size={15} /> Move To Another Section
          </button>
          {moveOpen && (
            <div style={{ maxHeight: 200, overflowY: 'auto', margin: '2px 0 6px', paddingLeft: 8 }}>
              {sections.filter(s => s.id !== lesson.section_id).map(s => (
                <button key={s.id} style={{ fontSize: 12.5 }}
                  onClick={() => { setOpen(false); setMoveOpen(false); onMove(lesson, s.id); }}>
                  {s.title}
                </button>
              ))}
              {sections.length < 2 && (
                <div style={{ fontSize: 12, color: 'var(--lms-text-3)', padding: '6px 11px' }}>
                  Add another section first
                </div>
              )}
            </div>
          )}
          <button onClick={() => { setOpen(false); onCopyUrl(lesson); }}><Link2 size={15} /> Copy URL</button>
          <button onClick={() => { setOpen(false); onAddNext(lesson); }}><Plus size={15} /> Add Next Lesson</button>
          <button onClick={() => { setOpen(false); onBottom(lesson); }}><ArrowDownToLine size={15} /> Move To Bottom</button>
          <div className="lms-menu-sep" />
          <button className="danger" onClick={() => { setOpen(false); onTrash(lesson); }}>
            <Trash2 size={15} /> Move To Trash
          </button>
        </div>
      )}
    </div>
  );
}

/* ── ⋯ menu on a section row ─────────────────────────────────── */
function SectionMenu({ section, onEdit, onDelete }) {
  const [open, setOpen] = useState(false);
  const ref = useRef(null);
  useOutsideClose(ref, () => setOpen(false), open);
  return (
    <div style={{ position: 'relative' }} ref={ref}>
      <button className="lms-icon-btn" onClick={e => { e.stopPropagation(); setOpen(o => !o); }} aria-label="Section actions">
        <MoreVertical size={16} />
      </button>
      {open && (
        <div className="lms-menu" onClick={e => e.stopPropagation()}>
          <button onClick={() => { setOpen(false); onEdit(section); }}><Pencil size={15} /> Rename section</button>
          <div className="lms-menu-sep" />
          <button className="danger" onClick={() => { setOpen(false); onDelete(section); }}>
            <Trash2 size={15} /> Delete section
          </button>
        </div>
      )}
    </div>
  );
}

export default function LmsCourseBuilder() {
  const { courseId } = useParams();
  const navigate = useNavigate();

  const [loading, setLoading] = useState(true);
  const [course, setCourse] = useState(null);
  const [sections, setSections] = useState([]);
  const [openIds, setOpenIds] = useState([]);
  const [search, setSearch] = useState('');
  const [query, setQuery] = useState('');

  const [sectionDraft, setSectionDraft] = useState(null);   // { id?, title, description, drip_days }
  const [lessonDraft, setLessonDraft] = useState(null);     // { section_id, title, lesson_type, after? }
  const [confirm, setConfirm] = useState(null);
  const [saving, setSaving] = useState(false);
  const [moreOpen, setMoreOpen] = useState(false);
  const moreRef = useRef(null);
  useOutsideClose(moreRef, () => setMoreOpen(false), moreOpen);

  const load = useCallback(async () => {
    try {
      const d = await LMS.listSections(courseId);
      setCourse(d.course);
      setSections(d.sections || []);
      /* keep the first module open on a fresh load, like Learnyst does */
      setOpenIds(prev => (prev.length ? prev : (d.sections?.[0] ? [d.sections[0].id] : [])));
    } catch (e) {
      toast.error(e.message);
    } finally {
      setLoading(false);
    }
  }, [courseId]);

  useEffect(() => { setLoading(true); load(); }, [load]);

  const stats = useMemo(() => {
    let lessons = 0, quizzes = 0, hidden = 0, secs = 0;
    for (const s of sections) {
      for (const l of s.lessons || []) {
        if (l.lesson_type === 'quiz') quizzes++; else lessons++;
        if (l.is_hidden) hidden++;
        secs += l.duration_secs || 0;
      }
    }
    return { lessons, quizzes, hidden, secs };
  }, [sections]);

  const visibleSections = useMemo(() => {
    if (!search.trim()) return sections;
    const q = search.trim().toLowerCase();
    return sections
      .map(s => ({ ...s, lessons: (s.lessons || []).filter(l => l.title.toLowerCase().includes(q)) }))
      .filter(s => s.lessons.length > 0 || s.title.toLowerCase().includes(q));
  }, [sections, search]);

  const toggleSection = (id) =>
    setOpenIds(ids => (ids.includes(id) ? ids.filter(x => x !== id) : [...ids, id]));

  /* ── section CRUD ── */
  const saveSection = async () => {
    if (!sectionDraft?.title?.trim()) return toast.error('Section title is required');
    setSaving(true);
    try {
      if (sectionDraft.id) {
        await LMS.updateSection(sectionDraft);
        toast.success('Section updated');
      } else {
        const d = await LMS.createSection({ ...sectionDraft, course_id: Number(courseId) });
        toast.success('Section added');
        setOpenIds(ids => [...ids, d.id]);
      }
      setSectionDraft(null);
      load();
    } catch (e) {
      toast.error(e.message);
    } finally {
      setSaving(false);
    }
  };

  const moveSection = async (index, dir) => {
    const next = [...sections];
    const target = index + dir;
    if (target < 0 || target >= next.length) return;
    [next[index], next[target]] = [next[target], next[index]];
    setSections(next);
    try { await LMS.reorderSections(next.map(s => s.id)); }
    catch (e) { toast.error(e.message); load(); }
  };

  const moveSectionEdge = async (index, toTop) => {
    const next = [...sections];
    const [item] = next.splice(index, 1);
    if (toTop) next.unshift(item); else next.push(item);
    setSections(next);
    try { await LMS.reorderSections(next.map(s => s.id)); }
    catch (e) { toast.error(e.message); load(); }
  };

  /* ── lesson CRUD ── */
  const createLesson = async () => {
    if (!lessonDraft?.title?.trim()) return toast.error('Lesson title is required');
    setSaving(true);
    try {
      const d = await LMS.createLesson({
        course_id: Number(courseId),
        section_id: lessonDraft.section_id,
        title: lessonDraft.title,
        lesson_type: lessonDraft.lesson_type,
      });
      toast.success('Lesson added');
      setLessonDraft(null);
      navigate(`/lms/courses/${courseId}/lessons/${d.id}`);
    } catch (e) {
      toast.error(e.message);
    } finally {
      setSaving(false);
    }
  };

  const moveLessonToBottom = async (lesson) => {
    const sec = sections.find(s => s.id === lesson.section_id);
    if (!sec) return;
    const rest = sec.lessons.filter(l => l.id !== lesson.id);
    const order = [...rest.map(l => l.id), lesson.id];
    try {
      await LMS.reorderLessons(order);
      toast.success('Moved to bottom');
      load();
    } catch (e) { toast.error(e.message); }
  };

  const moveLessonToSection = async (lesson, sectionId) => {
    try {
      await LMS.moveLesson(lesson.id, sectionId);
      toast.success('Lesson moved');
      setOpenIds(ids => (ids.includes(sectionId) ? ids : [...ids, sectionId]));
      load();
    } catch (e) { toast.error(e.message); }
  };

  const copyLessonUrl = async (lesson) => {
    const url = `${window.location.origin}/lms/courses/${courseId}/lessons/${lesson.id}`;
    try {
      await navigator.clipboard.writeText(url);
      toast.success('Lesson URL copied');
    } catch {
      toast.error('Could not access the clipboard — copy it from the address bar instead');
    }
  };

  if (loading) return <Loader />;
  if (!course) {
    return (
      <div className="lms-page">
        <Empty
          icon={<BookOpen size={24} />}
          title="Course not found"
          message="It may have been deleted. Go back to the course list and pick another one."
          action={<Link to="/lms/courses" className="lms-btn lms-btn-dark">Back to courses</Link>}
        />
      </div>
    );
  }

  return (
    <div className="lms-page">
      <div className="lms-breadcrumb">
        <Link to="/lms/courses" style={{ display: 'inline-flex', alignItems: 'center', gap: 5 }}>
          <ChevronLeft size={15} /> Back
        </Link>
      </div>

      {/* ── course header ─────────────────────────────────────── */}
      <div className="lms-page-head" style={{ alignItems: 'center' }}>
        <div>
          <div className="lms-chip-row" style={{ marginBottom: 10 }}>
            <Pill tone={course.status === 'published' ? 'green' : 'grey'}>
              {course.status === 'published' ? 'Published' : 'Unpublished'}
            </Pill>
            <Pill tone="grey">{course.encryption === 'encrypted' ? 'Encrypted' : 'Unencrypted'}</Pill>
          </div>
          <h1 className="lms-h1">{course.title}</h1>
        </div>

        <div style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
          <div style={{ position: 'relative' }} ref={moreRef}>
            <button className="lms-btn lms-btn-ghost" onClick={() => setMoreOpen(o => !o)}>
              More <ChevronDown size={15} />
            </button>
            {moreOpen && (
              <div className="lms-menu" onClick={() => setMoreOpen(false)}>
                <button onClick={() => setOpenIds(sections.map(s => s.id))}>
                  <Layers size={15} /> Expand all sections
                </button>
                <button onClick={() => setOpenIds([])}>
                  <Layers size={15} /> Collapse all
                </button>
                <div className="lms-menu-sep" />
                <button onClick={() => navigate(`/lms/responses?course_id=${courseId}`)}>
                  <ClipboardList size={15} /> View form responses
                </button>
                <button onClick={() => navigate(`/lms/enrollments?course_id=${courseId}`)}>
                  <BookOpen size={15} /> Course enrollments
                </button>
              </div>
            )}
          </div>
          <Link to={`/lms/courses?settings=${courseId}`} className="lms-btn lms-btn-ghost">
            <Settings2 size={16} /> Settings
          </Link>
        </div>
      </div>

      {/* ── search + stats strip ──────────────────────────────── */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 18, flexWrap: 'wrap', marginBottom: 22 }}>
        <div style={{ display: 'flex', gap: 10 }}>
          <div className="lms-search" style={{ minWidth: 240 }}>
            <Search size={16} />
            <input
              placeholder="Search lessons"
              value={query}
              onChange={e => setQuery(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && setSearch(query)}
            />
          </div>
          <button className="lms-btn lms-btn-ghost" onClick={() => setSearch(query)}>Search</button>
          {search && (
            <button className="lms-btn lms-btn-quiet" onClick={() => { setQuery(''); setSearch(''); }}>Clear</button>
          )}
        </div>

        <div className="lms-builder-stats">
          <span><EyeOff size={15} /> {stats.hidden} Hidden Lesson{stats.hidden === 1 ? '' : 's'}</span>
          <span><BookOpen size={15} /> {stats.lessons} Lesson{stats.lessons === 1 ? '' : 's'}</span>
          <span><HelpCircle size={15} /> {stats.quizzes} Quiz{stats.quizzes === 1 ? '' : 'zes'}</span>
          <span><Clock size={15} /> {duration(stats.secs)}</span>
        </div>
      </div>

      {/* ── sections ──────────────────────────────────────────── */}
      {visibleSections.length === 0 ? (
        <Empty
          icon={<Layers size={24} />}
          title={search ? 'No lessons match that search' : 'This course has no sections yet'}
          message={
            search
              ? 'Try a different keyword, or clear the search to see the full outline.'
              : 'Add your first section — for example "Module 1" — then add video lessons inside it.'
          }
          action={!search && (
            <button className="lms-btn lms-btn-dark"
              onClick={() => setSectionDraft({ title: '', description: '', drip_days: 0 })}>
              <Plus size={16} /> Add Section
            </button>
          )}
        />
      ) : (
        visibleSections.map((s, idx) => {
          const isOpen = openIds.includes(s.id);
          const lessons = s.lessons || [];
          const quizCount = lessons.filter(l => l.lesson_type === 'quiz').length;
          const lessonCount = lessons.length - quizCount;

          return (
            <div className="lms-section-row" key={s.id}>
              <div className="lms-section-head" onClick={() => toggleSection(s.id)}>
                {isOpen ? <ChevronUp size={17} color="var(--lms-text-2)" /> : <ChevronDown size={17} color="var(--lms-text-2)" />}
                <span className="lms-section-num">{idx + 1}</span>
                <span className="lms-section-title">{s.title}</span>
                <span className="lms-section-meta">
                  {lessonCount} Lesson{lessonCount === 1 ? '' : 's'} • {quizCount} Quiz{quizCount === 1 ? '' : 'zes'}
                </span>
                <div className="lms-section-actions" onClick={e => e.stopPropagation()}>
                  {idx > 0 && (
                    <>
                      <button className="lms-icon-btn" title="Move up" onClick={() => moveSection(idx, -1)}><ArrowUp size={15} /></button>
                      <button className="lms-icon-btn" title="Move to top" onClick={() => moveSectionEdge(idx, true)}><ArrowUpToLine size={15} /></button>
                    </>
                  )}
                  {idx < visibleSections.length - 1 && (
                    <>
                      <button className="lms-icon-btn" title="Move down" onClick={() => moveSection(idx, 1)}><ArrowDown size={15} /></button>
                      <button className="lms-icon-btn" title="Move to bottom" onClick={() => moveSectionEdge(idx, false)}><ArrowDownToLine size={15} /></button>
                    </>
                  )}
                  <SectionMenu
                    section={s}
                    onEdit={(sec) => setSectionDraft({
                      id: sec.id, title: sec.title, description: sec.description || '', drip_days: sec.drip_days || 0,
                    })}
                    onDelete={(sec) => setConfirm({
                      title: 'Delete this section?',
                      message: `"${sec.title}" and its ${(sec.lessons || []).length} lesson(s), including their videos, attachments and form fields, will be deleted permanently.`,
                      label: 'Delete section',
                      run: async () => {
                        await LMS.deleteSection(sec.id);
                        toast.success('Section deleted');
                        setConfirm(null);
                        load();
                      },
                    })}
                  />
                </div>
              </div>

              {isOpen && (
                <div className="lms-lesson-list">
                  {lessons.map((l, li) => {
                    const Icon = typeIcon(l.lesson_type);
                    return (
                      <div className="lms-lesson-row" key={l.id}>
                        <span className="lms-lesson-num">{li + 1}</span>
                        <span className="lms-lesson-ico"><Icon size={17} /></span>
                        <span
                          className="lms-lesson-title"
                          onClick={() => navigate(`/lms/courses/${courseId}/lessons/${l.id}`)}
                        >
                          {l.title}
                        </span>
                        {!!l.is_hidden && <Pill tone="grey"><EyeOff size={11} /> Hidden</Pill>}
                        {l.status === 'published' && <Pill tone="green">Published</Pill>}
                        {l.field_count > 0 && (
                          <span className="lms-lesson-chip" title="Form fields on this lesson">
                            <ClipboardList size={12} /> {l.field_count}
                          </span>
                        )}
                        {l.attachment_count > 0 && (
                          <span className="lms-lesson-chip" title="Attachments">
                            <Paperclip size={12} /> {l.attachment_count}
                          </span>
                        )}
                        <LessonMenu
                          lesson={l}
                          sections={sections}
                          onMove={moveLessonToSection}
                          onAddNext={(ls) => setLessonDraft({ section_id: ls.section_id, title: '', lesson_type: 'video' })}
                          onBottom={moveLessonToBottom}
                          onCopyUrl={copyLessonUrl}
                          onTrash={(ls) => setConfirm({
                            title: 'Move lesson to trash?',
                            message: `"${ls.title}" will be deleted along with its video, attachments, form fields and any responses collected on it.`,
                            label: 'Delete lesson',
                            run: async () => {
                              await LMS.deleteLesson(ls.id);
                              toast.success('Lesson deleted');
                              setConfirm(null);
                              load();
                            },
                          })}
                        />
                      </div>
                    );
                  })}

                  <button
                    className="lms-add-lesson"
                    onClick={() => setLessonDraft({ section_id: s.id, title: '', lesson_type: 'video' })}
                  >
                    <Plus size={16} /> Add lesson
                  </button>
                </div>
              )}
            </div>
          );
        })
      )}

      {visibleSections.length > 0 && (
        <button className="lms-add-section" onClick={() => setSectionDraft({ title: '', description: '', drip_days: 0 })}>
          <Plus size={17} /> Add Section
        </button>
      )}

      {/* ── add / rename section ──────────────────────────────── */}
      <Drawer
        open={!!sectionDraft}
        title={sectionDraft?.id ? 'Edit Section' : 'Add Section'}
        subtitle={sectionDraft?.id ? 'Rename or re-describe this section' : 'Add a new section'}
        onClose={() => setSectionDraft(null)}
        footer={
          <>
            <button className="lms-btn lms-btn-ghost" onClick={() => setSectionDraft(null)}>Cancel</button>
            <button className="lms-btn lms-btn-dark" onClick={saveSection} disabled={saving}>
              {saving ? 'Saving…' : 'Save'}
            </button>
          </>
        }
      >
        {sectionDraft && (
          <>
            <div className="lms-field">
              <label className="lms-label">
                Section Title<span className="req">*</span>
                <span className="lms-char-count">{sectionDraft.title.length}/60</span>
              </label>
              <input
                className="lms-input"
                maxLength={60}
                autoFocus
                placeholder={`Section ${sections.length + 1}`}
                value={sectionDraft.title}
                onChange={e => setSectionDraft(d => ({ ...d, title: e.target.value }))}
                onKeyDown={e => e.key === 'Enter' && saveSection()}
              />
            </div>
            <div className="lms-field">
              <label className="lms-label">Description</label>
              <textarea
                className="lms-textarea" style={{ minHeight: 80 }}
                placeholder="What this module covers (optional)"
                value={sectionDraft.description}
                onChange={e => setSectionDraft(d => ({ ...d, description: e.target.value }))}
              />
            </div>
            <div className="lms-field">
              <label className="lms-label">Drip after (days)</label>
              <input
                className="lms-input" type="number" min="0"
                value={sectionDraft.drip_days}
                onChange={e => setSectionDraft(d => ({ ...d, drip_days: e.target.value }))}
              />
              <p className="lms-help">
                0 unlocks the section immediately. Any other value keeps it locked for that many days after enrollment.
              </p>
            </div>
          </>
        )}
      </Drawer>

      {/* ── add lesson ────────────────────────────────────────── */}
      <Modal
        open={!!lessonDraft}
        title="Add Lesson"
        onClose={() => setLessonDraft(null)}
        footer={
          <>
            <button className="lms-btn lms-btn-ghost" onClick={() => setLessonDraft(null)}>Cancel</button>
            <button className="lms-btn lms-btn-dark" onClick={createLesson} disabled={saving}>
              {saving ? 'Adding…' : 'Add lesson'}
            </button>
          </>
        }
      >
        {lessonDraft && (
          <>
            <div className="lms-field">
              <label className="lms-label">Lesson title<span className="req">*</span></label>
              <input
                className="lms-input"
                autoFocus
                placeholder="e.g. Lesson 1 : Introduction to DevOps"
                value={lessonDraft.title}
                onChange={e => setLessonDraft(d => ({ ...d, title: e.target.value }))}
                onKeyDown={e => e.key === 'Enter' && createLesson()}
              />
            </div>
            <div className="lms-field">
              <label className="lms-label">Lesson type</label>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(150px,1fr))', gap: 10 }}>
                {LESSON_TYPES.map(t => {
                  const Icon = t.icon;
                  const on = lessonDraft.lesson_type === t.key;
                  return (
                    <button
                      key={t.key}
                      onClick={() => setLessonDraft(d => ({ ...d, lesson_type: t.key }))}
                      style={{
                        display: 'flex', flexDirection: 'column', alignItems: 'flex-start', gap: 4,
                        padding: 13, borderRadius: 8, textAlign: 'left',
                        border: `1px solid ${on ? 'var(--lms-green)' : 'var(--lms-border-2)'}`,
                        background: on ? 'var(--lms-green-soft)' : '#fff',
                      }}
                    >
                      <Icon size={17} color={on ? 'var(--lms-green-dark)' : 'var(--lms-text-2)'} />
                      <span style={{ fontSize: 13, fontWeight: 600 }}>{t.label}</span>
                      <span style={{ fontSize: 11, color: 'var(--lms-text-3)', lineHeight: 1.4 }}>{t.hint}</span>
                    </button>
                  );
                })}
              </div>
            </div>
          </>
        )}
      </Modal>

      <Confirm
        open={!!confirm}
        title={confirm?.title}
        message={confirm?.message}
        confirmLabel={confirm?.label}
        onCancel={() => setConfirm(null)}
        onConfirm={() => confirm?.run()}
      />
    </div>
  );
}

import { NavLink, Outlet } from 'react-router-dom';

/* ── Netcore sub-layout: horizontal top tab navbar + outlet ── */
export default function NetcoreLayout() {
  const tabs = [
    {
      to: '/netcore/behaviour',
      label: 'Dashboard',
      icon: (
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
          <rect x="3" y="3" width="7" height="7" rx="1.5" />
          <rect x="14" y="3" width="7" height="7" rx="1.5" />
          <rect x="3" y="14" width="7" height="7" rx="1.5" />
          <rect x="14" y="14" width="7" height="7" rx="1.5" />
        </svg>
      ),
    },
    {
      to: '/netcore/contacts',
      label: 'Contacts',
      icon: (
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
          <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" />
          <circle cx="9" cy="7" r="4" />
          <path d="M22 21v-2a4 4 0 0 0-3-3.87" />
          <path d="M16 3.13a4 4 0 0 1 0 7.75" />
        </svg>
      ),
    },
  ];

  return (
    <>
      <style>{`
        .nc-sub-layout {
          display: flex; flex-direction: column; background: #f1f0ff;
          height: calc(100vh - 94px);
          margin: -16px -20px; /* counteract AdminLayout main padding so navbar reaches edges */
        }
        .nc-sub-nav {
          display: flex; align-items: center; gap: 4px;
          background: #1e3a8a; padding: 0 16px; flex-shrink: 0; height: 48px;
          box-shadow: 0 1px 3px rgba(0,0,0,.15);
        }
        .nc-sub-tab {
          display: inline-flex; align-items: center; gap: 8px;
          padding: 10px 18px; height: 48px;
          color: rgba(255,255,255,.75); font-size: 13px; font-weight: 600;
          text-decoration: none; cursor: pointer; transition: color .15s;
          border-bottom: 3px solid transparent; box-sizing: border-box;
        }
        .nc-sub-tab:hover { color: #fff; }
        .nc-sub-tab.active {
          color: #fff;
          border-bottom-color: #f59e0b;
          background: rgba(255,255,255,.06);
        }
        .nc-sub-main { flex: 1; min-height: 0; overflow: auto; }
      `}</style>
      <div className="nc-sub-layout">
        <nav className="nc-sub-nav">
          {tabs.map(t => (
            <NavLink key={t.to} to={t.to}
              className={({ isActive }) => `nc-sub-tab${isActive ? ' active' : ''}`}>
              {t.icon}
              <span>{t.label}</span>
            </NavLink>
          ))}
        </nav>
        <main className="nc-sub-main">
          <Outlet />
        </main>
      </div>
    </>
  );
}

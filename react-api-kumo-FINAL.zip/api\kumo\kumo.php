<?php
/*
 * KumoMTA module — the single authenticated API endpoint.
 *
 * Follows the house convention: ?action=… multiplexes every operation onto one
 * file, input comes from $_REQUEST (GET or form-POST both work), output is
 * api_success()/api_error().
 *
 * Permission key: kumo_mta  (Permissions → KumoMTA)
 *
 * DATABASE SAFETY: every write in this file targets a kumo_* table. The only
 * statements that touch pre-existing tables are SELECTs (netcore_segments,
 * users) used to let you build an audience from data you already have.
 */

require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../middleware/auth.php';
require_once __DIR__ . '/lib/config.php';
require_once __DIR__ . '/lib/schema.php';
require_once __DIR__ . '/lib/Stats.php';
require_once __DIR__ . '/lib/Health.php';
require_once __DIR__ . '/lib/Audience.php';
require_once __DIR__ . '/lib/Mailer.php';
require_once __DIR__ . '/lib/KumoClient.php';
require_once __DIR__ . '/lib/SendWorker.php';

kumo_ensure_schema();

$jwt = require_jwt();
require_permission('kumo_mta', $jwt);

$ME = (string)($jwt['name'] ?? $jwt['email'] ?? ('user#' . (int)($jwt['user_id'] ?? 0)));

function jin($k, $d = null) {
    $v = $_REQUEST[$k] ?? null;
    return ($v === null || $v === '') ? $d : $v;
}
function jint($k, $d = 0)  { return (int)jin($k, $d); }
function jarr($k)          { $v = jin($k, '[]'); $a = is_array($v) ? $v : json_decode((string)$v, true); return is_array($a) ? $a : []; }
function jbool($k, $d = 0) { $v = jin($k, $d); return (int)(($v === '1' || $v === 1 || $v === true || $v === 'true') ? 1 : 0); }
function esc($s)           { global $conn; return $conn->real_escape_string((string)$s); }
function jsonOrNull($a)    { return $a ? "'" . esc(json_encode(array_values($a))) . "'" : 'NULL'; }

$action = (string)jin('action', '');

/* ════════════════════════════════════════════════════════════════════════════
   DASHBOARD
   ════════════════════════════════════════════════════════════════════════════ */
if ($action === 'dashboard') {
    $from   = jin('from');
    $to     = jin('to');
    $bucket = jin('bucket', 'day') === 'hour' ? 'hour' : 'day';

    api_success([
        'overview'   => kumo_stats_overview($from, $to),
        'series'     => kumo_stats_series($from, $to, $bucket),
        'providers'  => kumo_stats_by_provider($from, $to),
        'ips'        => kumo_ip_rows($from, $to),
        'api_health' => kumo_api_health_summary(24),
        'queue'      => kumo_queue_snapshot(),
        'audience'   => kumo_audience_counts(),
        'responses'  => kumo_top_responses($from, $to, 8),
        'alerts'     => kumo_alerts_list(6),
        'campaigns'  => kumo_recent_campaigns(6),
        'warmup'     => kumo_warmup_overview(),
        'server_time'=> date('Y-m-d H:i:s'),
    ]);
}

function kumo_alerts_list(int $limit = 20, bool $openOnly = true): array {
    global $conn;
    $out = [];
    try {
        $w = $openOnly ? 'WHERE acknowledged_at IS NULL' : '';
        $r = $conn->query("SELECT a.*, i.ip FROM kumo_alerts a LEFT JOIN kumo_ips i ON i.id=a.ip_id $w ORDER BY a.id DESC LIMIT " . max(1, min(100, $limit)));
        while ($r && $x = $r->fetch_assoc()) {
            $out[] = [
                'id' => (int)$x['id'], 'level' => $x['level'], 'ip' => $x['ip'], 'ip_id' => $x['ip_id'] ? (int)$x['ip_id'] : null,
                'campaign_id' => $x['campaign_id'] ? (int)$x['campaign_id'] : null,
                'title' => $x['title'], 'body' => $x['body'],
                'acknowledged_at' => $x['acknowledged_at'], 'acknowledged_by' => $x['acknowledged_by'],
                'created_at' => $x['created_at'],
            ];
        }
    } catch (\Throwable $e) { error_log('kumo_alerts_list: ' . $e->getMessage()); }
    return $out;
}

function kumo_recent_campaigns(int $limit = 6): array {
    global $conn;
    $out = [];
    try {
        $r = $conn->query("SELECT id, name, status, total_recipients, sent_count, delivered_count, bounced_count,
                                  open_count, unique_open_count, click_count, unique_click_count, complaint_count,
                                  scheduled_at, started_at, completed_at, created_at
                           FROM kumo_campaigns ORDER BY id DESC LIMIT " . max(1, min(50, $limit)));
        while ($r && $x = $r->fetch_assoc()) $out[] = kumo_campaign_public($x);
    } catch (\Throwable $e) { error_log('kumo_recent_campaigns: ' . $e->getMessage()); }
    return $out;
}

function kumo_campaign_public(array $x): array {
    $sent = max(1, (int)($x['sent_count'] ?? 0));
    $del  = (int)($x['delivered_count'] ?? 0);
    $base = $del > 0 ? $del : $sent;
    $pct  = fn($n, $d) => $d > 0 ? round($n / $d * 100, 2) : 0;
    return [
        'id' => (int)$x['id'], 'name' => $x['name'], 'status' => $x['status'],
        'total_recipients' => (int)($x['total_recipients'] ?? 0),
        'sent' => (int)($x['sent_count'] ?? 0), 'delivered' => $del,
        'bounced' => (int)($x['bounced_count'] ?? 0), 'complaints' => (int)($x['complaint_count'] ?? 0),
        'opens' => (int)($x['open_count'] ?? 0), 'unique_opens' => (int)($x['unique_open_count'] ?? 0),
        'clicks' => (int)($x['click_count'] ?? 0), 'unique_clicks' => (int)($x['unique_click_count'] ?? 0),
        'unsubs' => (int)($x['unsub_count'] ?? 0),
        'delivery_rate' => $pct($del, (int)($x['sent_count'] ?? 0)),
        'open_rate'     => $pct((int)($x['unique_open_count'] ?? 0), $base),
        'click_rate'    => $pct((int)($x['unique_click_count'] ?? 0), $base),
        'bounce_rate'   => $pct((int)($x['bounced_count'] ?? 0), (int)($x['sent_count'] ?? 0)),
        'complaint_rate'=> $pct((int)($x['complaint_count'] ?? 0), $base),
        'scheduled_at' => $x['scheduled_at'] ?? null, 'started_at' => $x['started_at'] ?? null,
        'completed_at' => $x['completed_at'] ?? null, 'created_at' => $x['created_at'] ?? null,
    ];
}

function kumo_warmup_overview(): array {
    global $conn;
    $plan = [];
    try {
        $r = $conn->query("SELECT * FROM kumo_warmup_plan ORDER BY day_from");
        while ($r && $x = $r->fetch_assoc()) $plan[] = ['day_from' => (int)$x['day_from'], 'day_to' => (int)$x['day_to'], 'daily_cap' => (int)$x['daily_cap']];
    } catch (\Throwable $e) { /* ignore */ }
    return ['plan' => $plan, 'auto' => kumo_setting('warmup_auto', '1') === '1'];
}

/* ════════════════════════════════════════════════════════════════════════════
   SENDING IPs
   ════════════════════════════════════════════════════════════════════════════ */
if ($action === 'ips_list') {
    api_success(['ips' => kumo_ip_rows(jin('from'), jin('to'))]);
}

if ($action === 'ip_save') {
    $id       = jint('id');
    $ip       = trim((string)jin('ip', ''));
    $hostname = trim((string)jin('hostname', ''));
    $tenant   = trim((string)jin('tenant', ''));
    $label    = trim((string)jin('label', ''));
    $warmup   = jbool('warmup_enabled', 1);
    $manual   = jin('manual_cap', null);
    $sort     = jint('sort_order');

    if ($ip === '' || !filter_var($ip, FILTER_VALIDATE_IP)) api_error('Enter a valid IPv4 address', 422);
    if ($tenant === '') api_error('Tenant is required — it must match the pool name in KumoMTA (ip1 … ip5)', 422);

    /* Batch identity: which purchase this IP came from. The label is derived
       from it (1-5-3 = batch 1, 5 bought together, IP #3) unless the admin
       typed their own. */
    $batchNo   = max(1, jint('batch_no', 1));
    $batchSize = max(0, jint('batch_size'));
    $batchIdx  = max(0, jint('batch_index'));
    $purchased = jin('purchased_at');
    if ($label === '' && $batchSize > 0 && $batchIdx > 0) $label = kumo_batch_label($batchNo, $batchSize, $batchIdx);

    $purchasedSql = $purchased ? "'" . esc(date('Y-m-d', strtotime((string)$purchased))) . "'" : 'NULL';
    $capSql       = ($manual === null || $manual === '') ? 'NULL' : (int)$manual;

    if ($id) {
        $conn->query(sprintf("UPDATE kumo_ips SET ip='%s', hostname='%s', tenant='%s', label='%s',
                warmup_enabled=%d, manual_cap=%s, sort_order=%d,
                batch_no=%d, batch_size=%d, batch_index=%d, purchased_at=%s WHERE id=%d",
            esc($ip), esc($hostname), esc($tenant), esc($label), $warmup, $capSql, $sort,
            $batchNo, $batchSize, $batchIdx, $purchasedSql, $id));
    } else {
        $conn->query(sprintf("INSERT INTO kumo_ips (ip, hostname, tenant, label, warmup_enabled, manual_cap, sort_order,
                batch_no, batch_size, batch_index, purchased_at, warmup_started_at, warmup_day)
                VALUES ('%s','%s','%s','%s',%d,%s,%d,%d,%d,%d,%s,CURDATE(),1)",
            esc($ip), esc($hostname), esc($tenant), esc($label), $warmup, $capSql, $sort,
            $batchNo, $batchSize, $batchIdx, $purchasedSql));
        $id = (int)$conn->insert_id;
    }
    kumo_warmup_tick();
    api_success(['id' => $id], 'Saved');
}

if ($action === 'ip_pause' || $action === 'ip_resume') {
    $id = jint('id');
    if (!$id) api_error('Missing id', 422);
    if ($action === 'ip_pause') {
        $reason = (string)jin('reason', 'Paused from the dashboard');
        $conn->query(sprintf("UPDATE kumo_ips SET status='paused', paused_reason='%s', paused_by='%s', paused_at=NOW() WHERE id=%d",
            esc($reason), esc($ME), $id));
        $conn->query("UPDATE kumo_ip_daily SET cap=0 WHERE ip_id=$id AND day=CURDATE()");
        kumo_alert('warn', 'IP paused by ' . $ME, $reason, $id);
    } else {
        $conn->query(sprintf("UPDATE kumo_ips SET status='active', paused_reason=NULL, paused_by=NULL, paused_at=NULL,
                                health=CASE WHEN health='red' THEN 'yellow' ELSE health END, good_hours=0 WHERE id=%d", $id));
        kumo_warmup_tick();
        kumo_alert('info', 'IP resumed by ' . $ME, '', $id);
    }
    api_success([], 'Done');
}

if ($action === 'ip_retire') {
    $id = jint('id');
    if (!$id) api_error('Missing id', 422);
    $conn->query("UPDATE kumo_ips SET status='retired' WHERE id=$id");
    api_success([], 'IP retired (its history is kept)');
}

if ($action === 'ip_detail') {
    $id = jint('id');
    if (!$id) api_error('Missing id', 422);
    $from = jin('from'); $to = jin('to');

    $r = $conn->query("SELECT * FROM kumo_ips WHERE id=$id LIMIT 1");
    $ip = $r ? $r->fetch_assoc() : null;
    if (!$ip) api_error('IP not found', 404);

    $health = [];
    $r = $conn->query("SELECT * FROM kumo_ip_health WHERE ip_id=$id ORDER BY id DESC LIMIT 48");
    while ($r && $x = $r->fetch_assoc()) $health[] = [
        'checked_at' => $x['checked_at'], 'color' => $x['color'], 'sent_24h' => (int)$x['sent_24h'],
        'bounce_rate' => (float)$x['bounce_rate'], 'complaint_rate' => (float)$x['complaint_rate'],
        'deferral_rate' => (float)$x['deferral_rate'], 'delivery_rate' => (float)$x['delivery_rate'],
        'reasons' => $x['reasons'],
    ];

    $bl = [];
    $r = $conn->query("SELECT * FROM kumo_blocklist_checks WHERE target='" . esc($ip['ip']) . "' ORDER BY zone");
    while ($r && $x = $r->fetch_assoc()) $bl[] = ['zone' => $x['zone'], 'listed' => (int)$x['listed'], 'response' => $x['response'], 'checked_at' => $x['checked_at']];

    $daily = [];
    $r = $conn->query("SELECT day, cap, sent, warmup_day FROM kumo_ip_daily WHERE ip_id=$id ORDER BY day DESC LIMIT 30");
    while ($r && $x = $r->fetch_assoc()) $daily[] = ['day' => $x['day'], 'cap' => (int)$x['cap'], 'sent' => (int)$x['sent'], 'warmup_day' => (int)$x['warmup_day']];

    api_success([
        'ip'        => array_values(array_filter(kumo_ip_rows($from, $to), fn($r2) => (int)$r2['id'] === $id))[0] ?? null,
        'series'    => kumo_stats_series($from, $to, jin('bucket', 'day') === 'hour' ? 'hour' : 'day', $id),
        'providers' => kumo_stats_by_provider($from, $to, $id),
        'health'    => array_reverse($health),
        'blocklists'=> $bl,
        'daily'     => array_reverse($daily),
        'responses' => kumo_top_responses($from, $to, 10),
    ]);
}

if ($action === 'ip_check')      { api_success(kumo_blocklist_tick(), 'Blocklist + reverse DNS checked'); }
if ($action === 'health_run')    { api_success(kumo_health_tick(), 'Health recalculated'); }
if ($action === 'warmup_run')    { api_success(kumo_warmup_tick(), 'Warmup caps refreshed'); }
if ($action === 'api_probe')     { api_success(kumo_api_probe(), 'Bridge probed'); }

/* ════════════════════════════════════════════════════════════════════════════
   TEMPLATES
   ════════════════════════════════════════════════════════════════════════════ */
if ($action === 'templates_list') {
    $rows = [];
    $q = trim((string)jin('search', ''));
    $w = "status <> 'archived'";
    if ($q !== '') $w .= " AND name LIKE '%" . esc($q) . "%'";
    /* with_html=1 (the campaign picker) needs enough of the body to render a
       real thumbnail; the plain listing keeps its 400-char snippet so a gallery
       of 200 templates does not ship megabytes of HTML. */
    $withHtml = jbool('with_html', 0) === 1;
    $limit    = $withHtml ? 60 : 200;
    $htmlCol  = $withHtml ? ", LEFT(COALESCE(body_html,''), 60000) AS preview_html" : '';
    $r = $conn->query("SELECT id, name, category, subject, status, updated_at, created_at,
                              LEFT(COALESCE(body_html,''), 400) AS snippet$htmlCol
                       FROM kumo_templates WHERE $w ORDER BY updated_at DESC LIMIT $limit");
    while ($r && $x = $r->fetch_assoc()) {
        $row = ['id' => (int)$x['id'], 'name' => $x['name'], 'category' => $x['category'], 'subject' => $x['subject'],
                'status' => $x['status'], 'updated_at' => $x['updated_at'], 'created_at' => $x['created_at'], 'snippet' => $x['snippet']];
        if ($withHtml) $row['preview_html'] = $x['preview_html'];
        $rows[] = $row;
    }
    api_success(['templates' => $rows]);
}

if ($action === 'template_get') {
    $id = jint('id');
    $r = $conn->query("SELECT * FROM kumo_templates WHERE id=$id LIMIT 1");
    $x = $r ? $r->fetch_assoc() : null;
    if (!$x) api_error('Template not found', 404);
    api_success(['template' => $x]);
}

if ($action === 'template_save') {
    $id = jint('id');
    $name = trim((string)jin('name', ''));
    if ($name === '') api_error('Name is required', 422);
    $fields = sprintf("name='%s', category=%s, subject=%s, preheader=%s, body_html=%s, body_text=%s",
        esc($name),
        jin('category') ? "'" . esc(jin('category')) . "'" : 'NULL',
        jin('subject') ? "'" . esc(jin('subject')) . "'" : 'NULL',
        jin('preheader') ? "'" . esc(jin('preheader')) . "'" : 'NULL',
        "'" . esc((string)jin('body_html', '')) . "'",
        "'" . esc((string)jin('body_text', '')) . "'");
    if ($id) $conn->query("UPDATE kumo_templates SET $fields WHERE id=$id");
    else {
        $conn->query("INSERT INTO kumo_templates SET $fields, created_by='" . esc($ME) . "'");
        $id = (int)$conn->insert_id;
    }
    api_success(['id' => $id], 'Template saved');
}

if ($action === 'template_delete') {
    $id = jint('id');
    $conn->query("UPDATE kumo_templates SET status='archived' WHERE id=$id");
    api_success([], 'Template archived');
}

/* ════════════════════════════════════════════════════════════════════════════
   AUDIENCE — lists, contacts, segments, blocklist
   ════════════════════════════════════════════════════════════════════════════ */
if ($action === 'lists_list') {
    $rows = [];
    $r = $conn->query("SELECT * FROM kumo_lists ORDER BY id DESC LIMIT 500");
    while ($r && $x = $r->fetch_assoc()) $rows[] = [
        'id' => (int)$x['id'], 'name' => $x['name'], 'description' => $x['description'],
        'kind' => $x['kind'], 'contact_count' => (int)$x['contact_count'],
        'created_by' => $x['created_by'], 'created_at' => $x['created_at'], 'updated_at' => $x['updated_at'],
    ];
    api_success(['lists' => $rows]);
}

if ($action === 'list_save') {
    $id   = jint('id');
    $name = trim((string)jin('name', ''));
    if ($name === '') api_error('List name is required', 422);
    $desc = (string)jin('description', '');
    if ($id) $conn->query("UPDATE kumo_lists SET name='" . esc($name) . "', description='" . esc($desc) . "' WHERE id=$id");
    else {
        $conn->query("INSERT INTO kumo_lists (name, description, created_by) VALUES ('" . esc($name) . "','" . esc($desc) . "','" . esc($ME) . "')");
        $id = (int)$conn->insert_id;
    }
    api_success(['id' => $id], 'List saved');
}

if ($action === 'list_delete') {
    $id = jint('id');
    if (!$id) api_error('Missing id', 422);
    $conn->query("DELETE FROM kumo_list_members WHERE list_id=$id");
    $conn->query("DELETE FROM kumo_lists WHERE id=$id");
    api_success([], 'List deleted (contacts themselves are kept)');
}

if ($action === 'list_contacts') {
    $id  = jint('id');
    $p   = max(1, jint('page', 1));
    $per = min(200, max(10, jint('per_page', 50)));
    $off = ($p - 1) * $per;
    $q   = trim((string)jin('search', ''));

    $w = "m.list_id=$id";
    if ($q !== '') $w .= " AND c.email LIKE '%" . esc($q) . "%'";

    $rows = [];
    $r = $conn->query("SELECT c.* FROM kumo_list_members m JOIN kumo_contacts c ON c.id=m.contact_id
                       WHERE $w ORDER BY m.id DESC LIMIT $per OFFSET $off");
    while ($r && $x = $r->fetch_assoc()) $rows[] = $x;
    $t = $conn->query("SELECT COUNT(*) c FROM kumo_list_members m JOIN kumo_contacts c ON c.id=m.contact_id WHERE $w");
    api_success(['contacts' => $rows, 'total' => $t ? (int)$t->fetch_assoc()['c'] : 0, 'page' => $p, 'per_page' => $per]);
}

/* Take a contact off ONE list. The contact itself is kept — that is what makes
   this different from contact_delete. */
if ($action === 'list_remove_member') {
    $listId    = jint('list_id');
    $contactId = jint('contact_id');
    if (!$listId || !$contactId) api_error('Missing list or contact', 422);
    $conn->query("DELETE FROM kumo_list_members WHERE list_id=$listId AND contact_id=$contactId");
    $removed = $conn->affected_rows;
    kumo_list_recount($listId);
    api_success(['removed' => $removed], $removed ? 'Removed from the list' : 'That contact was not on the list');
}

/* CSV of one list, streamed straight out (no temp file). */
if ($action === 'list_export') {
    $listId = jint('id');
    if (!$listId) api_error('Missing list id', 422);

    $name = 'list-' . $listId;
    $r = $conn->query("SELECT name FROM kumo_lists WHERE id=$listId LIMIT 1");
    if ($r && $x = $r->fetch_assoc()) $name = preg_replace('/[^A-Za-z0-9_-]+/', '-', (string)$x['name']) ?: $name;

    while (ob_get_level() > 0) { @ob_end_clean(); }
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $name . '.csv"');
    header('Cache-Control: no-store');

    $out = fopen('php://output', 'w');
    fputcsv($out, ['email', 'first_name', 'last_name', 'phone', 'status', 'engagement', 'added_at']);
    $q = $conn->query("SELECT c.email, c.first_name, c.last_name, c.phone, c.status, c.engagement, m.added_at
                       FROM kumo_list_members m JOIN kumo_contacts c ON c.id = m.contact_id
                       WHERE m.list_id = $listId ORDER BY m.id");
    while ($q && $row = $q->fetch_assoc()) fputcsv($out, array_values($row));
    fclose($out);
    exit;
}

if ($action === 'contacts_list') {
    $p   = max(1, jint('page', 1));
    $per = min(200, max(10, jint('per_page', 50)));
    $off = ($p - 1) * $per;
    $q   = trim((string)jin('search', ''));
    $st  = (string)jin('status', '');

    $w = '1=1';
    if ($q !== '')  $w .= " AND email LIKE '%" . esc($q) . "%'";
    if ($st !== '' && in_array($st, ['active','unsubscribed','bounced','complained'], true)) $w .= " AND status='" . esc($st) . "'";

    $rows = [];
    $r = $conn->query("SELECT * FROM kumo_contacts WHERE $w ORDER BY id DESC LIMIT $per OFFSET $off");
    while ($r && $x = $r->fetch_assoc()) $rows[] = $x;
    $t = $conn->query("SELECT COUNT(*) c FROM kumo_contacts WHERE $w");
    api_success(['contacts' => $rows, 'total' => $t ? (int)$t->fetch_assoc()['c'] : 0, 'page' => $p, 'per_page' => $per]);
}

if ($action === 'contact_save') {
    $email = strtolower(trim((string)jin('email', '')));
    if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) api_error('Enter a valid email address', 422);
    $id  = jint('id');
    $cid = 0;

    if ($id) {
        /* Editing an existing row. Update it in place so that CHANGING the
           address renames the contact instead of leaving the old row behind
           (kumo_contact_upsert() keys on email, which cannot do that). */
        $dupe = $conn->query("SELECT id FROM kumo_contacts WHERE email='" . esc($email) . "' AND id <> $id LIMIT 1");
        if ($dupe && $dupe->fetch_assoc()) api_error('Another contact already uses that email address', 409);

        $conn->query(sprintf("UPDATE kumo_contacts SET email='%s',
                first_name=NULLIF('%s',''), last_name=NULLIF('%s',''), phone=NULLIF('%s','') WHERE id=%d",
            esc($email), esc((string)jin('first_name', '')), esc((string)jin('last_name', '')),
            esc((string)jin('phone', '')), $id));
        $cid = $conn->affected_rows >= 0 ? $id : 0;
    } else {
        $cid = kumo_contact_upsert($email, ['first_name' => jin('first_name'), 'last_name' => jin('last_name'), 'phone' => jin('phone')], 'manual');
    }

    $listId = jint('list_id');
    if ($cid && $listId) kumo_list_add($listId, [$cid]);
    /* Anything left blank is filled from the student record, if there is one. */
    if ($cid) kumo_enrich_contacts_from_users([$email]);
    api_success(['id' => $cid], 'Contact saved');
}

if ($action === 'contact_delete') {
    $id = jint('id');
    if (!$id) api_error('Missing id', 422);
    $conn->query("DELETE FROM kumo_list_members WHERE contact_id=$id");
    $conn->query("DELETE FROM kumo_contacts WHERE id=$id");
    api_success([], 'Contact deleted');
}

/*
 * CSV import. The frontend posts the file's text content (csv=…), optionally
 * with a target list. Columns are matched case-insensitively by header name:
 * email | first_name/first name | last_name/last name | phone
 */
/*
 * Step 1 of the import wizard: read the first rows so the user can map columns.
 * Nothing is stored.
 */
if ($action === 'csv_preview') {
    $csv = (string)jin('csv', '');
    if (trim($csv) === '') api_error('That file looked empty', 422);

    $lines = preg_split('/\r\n|\r|\n/', $csv);
    $rows  = [];
    $total = 0;
    foreach ($lines as $line) {
        if (trim($line) === '') continue;
        $total++;
        if (count($rows) < 6) $rows[] = str_getcsv($line);
    }
    $head      = $rows[0] ?? [];
    $looksHead = false;
    foreach ($head as $h) {
        $h = strtolower(trim((string)$h));
        if (in_array($h, ['email', 'email_address', 'e-mail', 'first_name', 'last_name', 'name', 'phone', 'mobile'], true)) { $looksHead = true; break; }
    }
    /* Guess a mapping so the wizard opens with the obvious answer already chosen. */
    $guess = ['email' => -1, 'first_name' => -1, 'last_name' => -1, 'phone' => -1];
    if ($looksHead) {
        foreach ($head as $i => $h) {
            $h = strtolower(trim(str_replace([' ', '-'], '_', (string)$h)));
            if ($h === 'email' || $h === 'email_address' || $h === 'e_mail') $guess['email'] = $i;
            elseif ($h === 'first_name' || $h === 'firstname' || $h === 'name') $guess['first_name'] = $i;
            elseif ($h === 'last_name' || $h === 'lastname' || $h === 'surname') $guess['last_name'] = $i;
            elseif ($h === 'phone' || $h === 'mobile' || $h === 'contact') $guess['phone'] = $i;
        }
    } else {
        foreach ($head as $i => $v) { if (filter_var(trim((string)$v), FILTER_VALIDATE_EMAIL)) { $guess['email'] = $i; break; } }
    }

    api_success([
        'columns'    => $head,
        'rows'       => $rows,
        'total_rows' => max(0, $total - ($looksHead ? 1 : 0)),
        'has_header' => $looksHead ? 1 : 0,
        'mapping'    => $guess,
    ]);
}

/**
 * One row in kumo_imports per CSV run. Kumo imports are synchronous, so a row is
 * only ever written once, already finished — there is no pending/processing state
 * to poll like Netcore's campaign_contact_uploads has.
 */
function kumo_log_import(int $listId, string $fileName, array $stats, bool $asBlocklist): void {
    global $conn, $ME;
    $conn->query(sprintf(
        "INSERT INTO kumo_imports (list_id, file_name, total_rows, imported, invalid, suppressed, duplicate, as_blocklist, status, created_by, created_at)
         VALUES (%s, %s, %d, %d, %d, %d, %d, %d, 'processed', '%s', NOW())",
        $listId ? (int)$listId : 'NULL',
        $fileName !== '' ? "'" . esc($fileName) . "'" : 'NULL',
        (int)($stats['rows']       ?? 0),
        (int)($stats['imported']   ?? 0),
        (int)($stats['invalid']    ?? 0),
        (int)($stats['suppressed'] ?? 0),
        (int)($stats['duplicate']  ?? 0),
        $asBlocklist ? 1 : 0,
        esc((string)$ME)
    ));
}

if ($action === 'import_logs') {
    $page    = max(1, jint('page') ?: 1);
    $perPage = min(100, max(5, jint('per_page') ?: 25));
    $search  = trim((string)jin('search', ''));
    $where   = $search !== '' ? "WHERE i.file_name LIKE '%" . esc($search) . "%'" : '';

    $total = 0;
    $r = $conn->query("SELECT COUNT(*) c FROM kumo_imports i ${where}");
    if ($r && $row = $r->fetch_assoc()) $total = (int)$row['c'];

    $off  = ($page - 1) * $perPage;
    $rows = [];
    $q = $conn->query("SELECT i.*, l.name AS list_name
                          FROM kumo_imports i
                          LEFT JOIN kumo_lists l ON l.id = i.list_id
                          ${where} ORDER BY i.id DESC LIMIT $perPage OFFSET $off");
    while ($q && $x = $q->fetch_assoc()) {
        $rows[] = [
            'id'           => (int)$x['id'],
            'file_name'    => $x['file_name'],
            'list_id'      => $x['list_id'] !== null ? (int)$x['list_id'] : null,
            'list_name'    => $x['list_name'],
            'total_rows'   => (int)$x['total_rows'],
            'imported'     => (int)$x['imported'],
            'invalid'      => (int)$x['invalid'],
            'suppressed'   => (int)$x['suppressed'],
            'duplicate'    => (int)$x['duplicate'],
            'as_blocklist' => (int)$x['as_blocklist'],
            'status'       => $x['status'],
            'created_by'   => $x['created_by'],
            'created_at'   => $x['created_at'],
        ];
    }
    api_success(['logs' => $rows, 'total' => $total, 'page' => $page, 'per_page' => $perPage]);
}
if ($action === 'contacts_import') {
    $csv    = (string)jin('csv', '');
    $listId = jint('list_id');
    $asBlock= jbool('as_blocklist', 0);
    if (trim($csv) === '') api_error('Nothing to import — the file looked empty', 422);

    /* An explicit column mapping from the wizard wins over header sniffing. */
    $explicit = jarr('mapping');
    if ($explicit && isset($explicit['email']) && (int)$explicit['email'] >= 0) {
        kumo_import_with_mapping($csv, $explicit, jbool('has_header', 1) === 1, $listId, $asBlock === 1);
    }

    $lines = preg_split('/\r\n|\r|\n/', $csv);
    $head  = null;
    $map   = ['email' => 0, 'first_name' => -1, 'last_name' => -1, 'phone' => -1];
    $ids   = [];
    $stats = ['rows' => 0, 'imported' => 0, 'invalid' => 0, 'suppressed' => 0, 'duplicate' => 0];
    $seenEmails = [];   // flushed to kumo_enrich_contacts_from_users() with each id batch

    foreach ($lines as $line) {
        if (trim($line) === '') continue;
        $cols = str_getcsv($line);
        if ($head === null) {
            $head = array_map(fn($h) => strtolower(trim(str_replace([' ', '-'], '_', (string)$h))), $cols);
            if (in_array('email', $head, true)) {
                $map['email']      = array_search('email', $head, true);
                $map['first_name'] = array_search('first_name', $head, true);
                $map['last_name']  = array_search('last_name', $head, true);
                $map['phone']      = array_search('phone', $head, true);
                continue;               // real header row
            }
            /* No header — treat the first column as the email and re-process. */
            $map = ['email' => 0, 'first_name' => false, 'last_name' => false, 'phone' => false];
        }

        $stats['rows']++;
        $email = strtolower(trim((string)($cols[$map['email']] ?? '')));
        if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) { $stats['invalid']++; continue; }

        if ($asBlock) {
            kumo_suppress($email, 'imported', 'CSV import');
            $stats['imported']++;
            continue;
        }
        if (kumo_is_suppressed($email)) { $stats['suppressed']++; continue; }

        $cid = kumo_contact_upsert($email, [
            'first_name' => $map['first_name'] !== false && $map['first_name'] !== -1 ? ($cols[$map['first_name']] ?? '') : '',
            'last_name'  => $map['last_name']  !== false && $map['last_name']  !== -1 ? ($cols[$map['last_name']]  ?? '') : '',
            'phone'      => $map['phone']      !== false && $map['phone']      !== -1 ? ($cols[$map['phone']]      ?? '') : '',
        ], 'csv');
        if ($cid) { $ids[] = $cid; $seenEmails[] = $email; $stats['imported']++; }
        if (count($ids) >= 2000) {
            if ($listId) kumo_list_add($listId, $ids);
            kumo_enrich_contacts_from_users($seenEmails);
            $ids = []; $seenEmails = [];
        }
        if ($stats['rows'] > 200000) break;      // one-file safety stop
    }
    if ($listId && $ids) kumo_list_add($listId, $ids);
    if ($listId) kumo_list_recount($listId);
    kumo_enrich_contacts_from_users($seenEmails);

    kumo_log_import($listId, (string)jin('file_name', ''), $stats, $asBlock === 1);
    api_success($stats, 'Import finished');
}

/**
 * Import using an explicit column mapping (step 2 of the wizard).
 * Ends the request itself via api_success().
 */
function kumo_import_with_mapping(string $csv, array $map, bool $hasHeader, int $listId, bool $asBlocklist): void {
    $idx = fn($k) => isset($map[$k]) && (int)$map[$k] >= 0 ? (int)$map[$k] : -1;
    $iEmail = $idx('email'); $iFirst = $idx('first_name'); $iLast = $idx('last_name'); $iPhone = $idx('phone');

    $stats = ['rows' => 0, 'imported' => 0, 'invalid' => 0, 'suppressed' => 0, 'duplicate' => 0];
    $seenEmails = [];   // flushed to kumo_enrich_contacts_from_users() with each id batch
    $ids   = [];
    $seen  = [];
    $first = true;

    foreach (preg_split('/\r\n|\r|\n/', $csv) as $line) {
        if (trim($line) === '') continue;
        if ($first && $hasHeader) { $first = false; continue; }
        $first = false;

        $cols = str_getcsv($line);
        $stats['rows']++;
        $email = strtolower(trim((string)($cols[$iEmail] ?? '')));

        if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) { $stats['invalid']++; continue; }
        if (isset($seen[$email])) { $stats['duplicate']++; continue; }
        $seen[$email] = true;

        if ($asBlocklist) { kumo_suppress($email, 'imported', 'CSV import'); $stats['imported']++; continue; }
        if (kumo_is_suppressed($email)) { $stats['suppressed']++; continue; }

        $cid = kumo_contact_upsert($email, [
            'first_name' => $iFirst >= 0 ? ($cols[$iFirst] ?? '') : '',
            'last_name'  => $iLast  >= 0 ? ($cols[$iLast]  ?? '') : '',
            'phone'      => $iPhone >= 0 ? ($cols[$iPhone] ?? '') : '',
        ], 'csv');
        if ($cid) { $ids[] = $cid; $seenEmails[] = $email; $stats['imported']++; }
        if (count($ids) >= 2000) {
            if ($listId) kumo_list_add($listId, $ids);
            kumo_enrich_contacts_from_users($seenEmails);
            $ids = []; $seenEmails = [];
        }
        if ($stats['rows'] > 200000) break;      // one-file safety stop
    }
    if ($listId && $ids) kumo_list_add($listId, $ids);
    if ($listId) kumo_list_recount($listId);
    kumo_enrich_contacts_from_users($seenEmails);

    kumo_log_import($listId, (string)jin('file_name', ''), $stats, $asBlocklist);
    api_success($stats, 'Import finished');
}

/* A page of the people a segment currently resolves to — the "view members"
   screen, and the preview inside the builder. */
if ($action === 'segment_users') {
    $id  = jint('id');
    $p   = max(1, jint('page', 1));
    $per = min(200, max(10, jint('per_page', 50)));
    $off = ($p - 1) * $per;

    $seg = $id ? kumo_segment_row($id) : ['source' => (string)jin('source', 'rules'), 'config' => jarr('config')];
    if (!$seg) api_error('Segment not found', 404);
    $sql = kumo_segment_select($seg);
    if (!$sql) api_success(['rows' => [], 'total' => 0, 'page' => $p, 'per_page' => $per]);

    $rows = [];
    try {
        $r = $conn->query("$sql LIMIT $per OFFSET $off");
        while ($r && $x = $r->fetch_assoc()) $rows[] = $x;
    } catch (\Throwable $e) { api_error('Could not read this segment: ' . $e->getMessage(), 500); }

    api_success(['rows' => $rows, 'total' => kumo_segment_count($seg), 'page' => $p, 'per_page' => $per]);
}

/* Import an audience you already own elsewhere in the panel — READ-ONLY on the
   source tables, rows are copied into kumo_contacts. */
if ($action === 'import_from_netcore_segment') {
    $nid    = jint('netcore_segment_id');
    $listId = jint('list_id');
    $limit  = min(200000, max(1, jint('limit', 50000)));
    if (!$nid || !$listId) api_error('Pick a segment and a destination list', 422);

    $seg = ['source' => 'netcore', 'config' => ['netcore_segment_id' => $nid]];
    $sql = kumo_segment_select($seg);
    if (!$sql) api_error('That segment could not be resolved', 422);

    $ids = []; $n = 0; $skipped = 0;
    try {
        $r = $conn->query($sql . " LIMIT $limit");
        while ($r && $x = $r->fetch_assoc()) {
            $email = strtolower(trim((string)$x['email']));
            if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) { $skipped++; continue; }
            if (kumo_is_suppressed($email)) { $skipped++; continue; }
            $cid = kumo_contact_upsert($email, ['first_name' => $x['first_name'] ?? '', 'last_name' => $x['last_name'] ?? ''], 'netcore_segment');
            if ($cid) { $ids[] = $cid; $n++; }
            if (count($ids) >= 2000) { kumo_list_add($listId, $ids); $ids = []; }
        }
        if ($ids) kumo_list_add($listId, $ids);
        kumo_list_recount($listId);
    } catch (\Throwable $e) { api_error('Import failed: ' . $e->getMessage(), 500); }

    api_success(['imported' => $n, 'skipped' => $skipped], 'Imported ' . $n . ' contacts');
}

/* Read-only list of the existing netcore segments, for the picker. */
if ($action === 'netcore_segments') {
    $rows = [];
    try {
        $r = $conn->query("SELECT id, name, user_count, email_count FROM netcore_segments ORDER BY id DESC LIMIT 300");
        while ($r && $x = $r->fetch_assoc()) $rows[] = [
            'id' => (int)$x['id'], 'name' => $x['name'],
            'user_count' => (int)($x['user_count'] ?? 0), 'email_count' => (int)($x['email_count'] ?? 0),
        ];
    } catch (\Throwable $e) { /* netcore not present — fine */ }
    api_success(['segments' => $rows]);
}

if ($action === 'segments_list') {
    $rows = [];
    $r = $conn->query("SELECT * FROM kumo_segments ORDER BY id DESC LIMIT 300");
    while ($r && $x = $r->fetch_assoc()) {
        $x['config'] = json_decode((string)$x['config'], true) ?: [];
        $x['id'] = (int)$x['id']; $x['cached_count'] = (int)$x['cached_count'];
        $rows[] = $x;
    }
    api_success(['segments' => $rows]);
}

if ($action === 'segment_get') {
    $seg = kumo_segment_row(jint('id'));
    if (!$seg) api_error('Segment not found', 404);
    api_success(['segment' => $seg]);
}

if ($action === 'segment_duplicate') {
    $seg = kumo_segment_row(jint('id'));
    if (!$seg) api_error('Segment not found', 404);
    $conn->query(sprintf("INSERT INTO kumo_segments (name, description, source, config, created_by)
                          VALUES ('%s','%s','%s','%s','%s')",
        esc($seg['name'] . ' (copy)'), esc((string)$seg['description']), esc($seg['source']),
        esc(json_encode($seg['config'])), esc($ME)));
    api_success(['id' => (int)$conn->insert_id], 'Segment duplicated');
}

if ($action === 'segment_save') {
    $id     = jint('id');
    $name   = trim((string)jin('name', ''));
    $source = (string)jin('source', 'engagement');
    if ($name === '') api_error('Segment name is required', 422);
    if (!in_array($source, ['kumo_list','engagement','netcore','rules'], true)) api_error('Unknown segment source', 422);
    $cfg = jarr('config');

    if ($id) {
        $conn->query(sprintf("UPDATE kumo_segments SET name='%s', description='%s', source='%s', config='%s' WHERE id=%d",
            esc($name), esc((string)jin('description', '')), esc($source), esc(json_encode($cfg)), $id));
    } else {
        $conn->query(sprintf("INSERT INTO kumo_segments (name, description, source, config, created_by) VALUES ('%s','%s','%s','%s','%s')",
            esc($name), esc((string)jin('description', '')), esc($source), esc(json_encode($cfg)), esc($ME)));
        $id = (int)$conn->insert_id;
    }
    $seg = kumo_segment_row($id);
    $count = $seg ? kumo_segment_count($seg) : 0;
    $conn->query("UPDATE kumo_segments SET cached_count=$count, counted_at=NOW() WHERE id=$id");
    api_success(['id' => $id, 'count' => $count], 'Segment saved');
}

if ($action === 'segment_delete') {
    $id = jint('id');
    $conn->query("DELETE FROM kumo_segments WHERE id=" . (int)$id);
    api_success([], 'Segment deleted');
}

if ($action === 'segment_count') {
    $id = jint('id');
    $seg = $id ? kumo_segment_row($id) : ['source' => (string)jin('source', 'engagement'), 'config' => jarr('config')];
    if (!$seg) api_error('Segment not found', 404);
    $count = kumo_segment_count($seg);
    if ($id) $conn->query("UPDATE kumo_segments SET cached_count=$count, counted_at=NOW() WHERE id=$id");
    api_success(['count' => $count]);
}

if ($action === 'blocklist_list') {
    $p      = max(1, jint('page', 1));
    $per    = min(200, max(10, jint('per_page', 50)));
    $off    = ($p - 1) * $per;
    $q      = trim((string)jin('search', ''));
    $rs     = (string)jin('reason', '');
    $source = (string)jin('source', 'kumo');       // kumo | netcore

    /* The shared Netcore blocklist, shown read-only. Everything here is also
       honoured at send time (see kumo_is_suppressed). */
    if ($source === 'netcore') {
        $w = "l.kind='blocklist'";
        if ($q !== '') $w .= " AND c.email LIKE '%" . esc($q) . "%'";
        $rows = [];
        try {
            $r = $conn->query("SELECT c.id, c.email, m.added_at AS created_at
                FROM campaign_list_members m
                JOIN campaign_lists   l ON l.id = m.list_id
                JOIN campaign_contacts c ON c.id = m.contact_id
                WHERE $w ORDER BY m.added_at DESC LIMIT $per OFFSET $off");
            while ($r && $x = $r->fetch_assoc()) {
                $rows[] = ['id' => (int)$x['id'], 'email' => $x['email'], 'reason' => 'netcore',
                           'detail' => 'From the Netcore blocklist (read-only)', 'campaign_id' => null,
                           'created_at' => $x['created_at']];
            }
            $t = $conn->query("SELECT COUNT(*) c FROM campaign_list_members m
                JOIN campaign_lists l ON l.id=m.list_id JOIN campaign_contacts c ON c.id=m.contact_id WHERE $w");
            $total = $t ? (int)$t->fetch_assoc()['c'] : 0;
        } catch (\Throwable $e) { $total = 0; }
        api_success(['rows' => $rows, 'total' => $total, 'page' => $p, 'per_page' => $per,
                     'by_reason' => [], 'readonly' => 1, 'netcore_total' => kumo_netcore_blocklist_count()]);
    }

    $w = '1=1';
    if ($q !== '')  $w .= " AND email LIKE '%" . esc($q) . "%'";
    if ($rs !== '') $w .= " AND reason='" . esc($rs) . "'";

    $rows = [];
    $r = $conn->query("SELECT * FROM kumo_blocklist WHERE $w ORDER BY id DESC LIMIT $per OFFSET $off");
    while ($r && $x = $r->fetch_assoc()) $rows[] = $x;
    $t = $conn->query("SELECT COUNT(*) c FROM kumo_blocklist WHERE $w");

    $byReason = [];
    $r2 = $conn->query("SELECT reason, COUNT(*) c FROM kumo_blocklist GROUP BY reason");
    while ($r2 && $x = $r2->fetch_assoc()) $byReason[$x['reason']] = (int)$x['c'];

    api_success(['rows' => $rows, 'total' => $t ? (int)$t->fetch_assoc()['c'] : 0, 'page' => $p, 'per_page' => $per,
                 'by_reason' => $byReason, 'readonly' => 0, 'netcore_total' => kumo_netcore_blocklist_count()]);
}

if ($action === 'blocklist_add') {
    $emails = array_filter(array_map('trim', preg_split('/[\s,;]+/', (string)jin('emails', ''))));
    $n = 0;
    foreach ($emails as $e) { if (filter_var($e, FILTER_VALIDATE_EMAIL)) { kumo_suppress($e, 'manual', 'Added by ' . $ME); $n++; } }
    api_success(['added' => $n], $n . ' address(es) blocklisted');
}

if ($action === 'blocklist_remove') {
    $email = strtolower(trim((string)jin('email', '')));
    if ($email === '') api_error('Missing email', 422);
    $conn->query("DELETE FROM kumo_blocklist WHERE email='" . esc($email) . "'");
    $conn->query("UPDATE kumo_contacts SET status='active' WHERE email='" . esc($email) . "'");
    api_success([], 'Removed from the blocklist');
}

/* ════════════════════════════════════════════════════════════════════════════
   ATTRIBUTES
   Our own rows live in kumo_attributes. The panel's existing campaign_attributes
   are listed alongside them READ-ONLY, so the screen shows everything you have
   while creation/editing never writes to the shared table.
   ════════════════════════════════════════════════════════════════════════════ */
if ($action === 'attributes_list') {
    $rows = [];

    $r = $conn->query("SELECT * FROM kumo_attributes ORDER BY category, name");
    while ($r && $x = $r->fetch_assoc()) {
        $x['id'] = (int)$x['id']; $x['origin'] = 'kumo'; $x['editable'] = 1;
        $rows[] = $x;
    }

    if (jbool('include_netcore', 1) === 1) {
        try {
            $r2 = $conn->query("SELECT id, name, category, data_type, date_format, mapped_db, mapped_table,
                                       mapped_column, mapped_join_col, resolver_json, default_value, created_at, updated_at
                                FROM campaign_attributes ORDER BY category, name");
            while ($r2 && $x = $r2->fetch_assoc()) {
                $x['id'] = (int)$x['id']; $x['origin'] = 'netcore'; $x['editable'] = 0;
                $rows[] = $x;
            }
        } catch (\Throwable $e) { /* attributes module absent */ }
    }

    $counts = ['total' => count($rows), 'kumo' => 0, 'netcore' => 0, 'custom' => 0, 'system' => 0, 'linked' => 0];
    foreach ($rows as $x) {
        $counts[$x['origin']]++;
        $counts[$x['category']] = ($counts[$x['category']] ?? 0) + 1;
    }
    api_success(['attributes' => $rows, 'counts' => $counts]);
}

if ($action === 'attribute_save') {
    $id   = jint('id');
    $name = trim((string)jin('name', ''));
    if ($name === '') api_error('An attribute name is required', 422);
    if (!preg_match('/^[A-Za-z0-9 _.-]{1,100}$/', $name)) api_error('Use letters, numbers, spaces, dot, dash or underscore', 422);

    $cat  = in_array(jin('category', 'custom'), ['custom','system','linked'], true) ? (string)jin('category') : 'custom';
    $type = in_array(jin('data_type', 'text'), ['text','number','date','url','boolean'], true) ? (string)jin('data_type') : 'text';

    /* A name that already exists on the Netcore side would be ambiguous at merge
       time, so refuse it rather than silently shadowing. */
    try {
        $dupe = $conn->query("SELECT id FROM campaign_attributes WHERE name='" . esc($name) . "' LIMIT 1");
        if ($dupe && $dupe->fetch_assoc()) api_error('An attribute with this name already exists in Netcore — pick another name', 409);
    } catch (\Throwable $e) { /* ignore */ }

    $fields = sprintf("name='%s', category='%s', data_type='%s', date_format=%s, mapped_db=%s, mapped_table=%s,
                       mapped_column=%s, mapped_join_col=%s, resolver_json=%s, default_value=%s",
        esc($name), esc($cat), esc($type),
        jin('date_format')     ? "'" . esc(jin('date_format'))     . "'" : 'NULL',
        jin('mapped_db')       ? "'" . esc(jin('mapped_db'))       . "'" : 'NULL',
        jin('mapped_table')    ? "'" . esc(jin('mapped_table'))    . "'" : 'NULL',
        jin('mapped_column')   ? "'" . esc(jin('mapped_column'))   . "'" : 'NULL',
        jin('mapped_join_col') ? "'" . esc(jin('mapped_join_col')) . "'" : 'NULL',
        jin('resolver_json')   ? "'" . esc(is_array(jin('resolver_json')) ? json_encode(jin('resolver_json')) : jin('resolver_json')) . "'" : 'NULL',
        jin('default_value')   ? "'" . esc(jin('default_value'))   . "'" : 'NULL');

    if ($id) $conn->query("UPDATE kumo_attributes SET $fields WHERE id=$id");
    else {
        $conn->query("INSERT INTO kumo_attributes SET $fields, created_by='" . esc($ME) . "'");
        $id = (int)$conn->insert_id;
    }
    api_success(['id' => $id], 'Attribute saved');
}

if ($action === 'attribute_delete') {
    $id = jint('id');
    if (!$id) api_error('Missing id', 422);
    $conn->query("DELETE FROM kumo_attributes WHERE id=$id");
    api_success([], $conn->affected_rows ? 'Attribute deleted' : 'Netcore attributes cannot be deleted from here');
}

/* ════════════════════════════════════════════════════════════════════════════
   COPY FROM NETCORE  (reads the existing tables, writes only kumo_* rows)
   ════════════════════════════════════════════════════════════════════════════ */
if ($action === 'copy_list_from_netcore') {
    $srcId = jint('list_id');
    $limit = min(500000, max(1, jint('limit', 200000)));
    if (!$srcId) api_error('Missing list id', 422);

    $src = null;
    try {
        $r = $conn->query("SELECT id, name, description FROM campaign_lists WHERE id=$srcId AND kind='list' LIMIT 1");
        $src = $r ? $r->fetch_assoc() : null;
    } catch (\Throwable $e) { /* handled below */ }
    if (!$src) api_error('That list could not be found in Netcore', 404);

    $name = trim((string)jin('name', '')) !== '' ? (string)jin('name') : (string)$src['name'];
    $conn->query(sprintf("INSERT INTO kumo_lists (name, description, kind, created_by) VALUES ('%s','%s','list','%s')",
        esc($name), esc('Copied from Netcore list #' . $srcId . ($src['description'] ? ' — ' . $src['description'] : '')), esc($ME)));
    $listId = (int)$conn->insert_id;

    $imported = 0; $skipped = 0; $ids = [];
    try {
        $q = $conn->query("SELECT c.email, c.first_name, c.last_name, c.phone
                           FROM campaign_list_members m JOIN campaign_contacts c ON c.id = m.contact_id
                           WHERE m.list_id = $srcId LIMIT $limit");
        while ($q && $x = $q->fetch_assoc()) {
            $email = strtolower(trim((string)$x['email']));
            if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) { $skipped++; continue; }
            if (kumo_is_suppressed($email)) { $skipped++; continue; }
            $cid = kumo_contact_upsert($email, ['first_name' => $x['first_name'], 'last_name' => $x['last_name'], 'phone' => $x['phone']], 'netcore_list');
            if ($cid) { $ids[] = $cid; $imported++; }
            if (count($ids) >= 2000) { kumo_list_add($listId, $ids); $ids = []; }
        }
        if ($ids) kumo_list_add($listId, $ids);
        kumo_list_recount($listId);
    } catch (\Throwable $e) { api_error('Copy failed: ' . $e->getMessage(), 500); }

    api_success(['list_id' => $listId, 'imported' => $imported, 'skipped' => $skipped],
        'Copied ' . $imported . ' contacts into Kumo');
}

if ($action === 'copy_segment_from_netcore') {
    $srcId = jint('segment_id');
    if (!$srcId) api_error('Missing segment id', 422);

    $src = null;
    try {
        $r = $conn->query("SELECT id, name, config FROM netcore_segments WHERE id=$srcId LIMIT 1");
        $src = $r ? $r->fetch_assoc() : null;
    } catch (\Throwable $e) { /* handled below */ }
    if (!$src) api_error('That segment could not be found in Netcore', 404);

    /* Copy the rule JSON itself, so the Kumo builder can open and edit it. */
    $cfg  = json_decode((string)$src['config'], true) ?: [];
    $name = trim((string)jin('name', '')) !== '' ? (string)jin('name') : (string)$src['name'];

    $conn->query(sprintf("INSERT INTO kumo_segments (name, description, source, config, created_by)
                          VALUES ('%s','%s','rules','%s','%s')",
        esc($name), esc('Copied from Netcore segment #' . $srcId), esc(json_encode($cfg)), esc($ME)));
    $id = (int)$conn->insert_id;

    $seg   = kumo_segment_row($id);
    $count = $seg ? kumo_segment_count($seg) : 0;
    $conn->query("UPDATE kumo_segments SET cached_count=$count, counted_at=NOW() WHERE id=$id");

    api_success(['segment_id' => $id, 'count' => $count], 'Segment copied — ' . nf_int($count) . ' contacts match');
}

if ($action === 'copy_template_from_netcore') {
    $srcId = jint('template_id');
    if (!$srcId) api_error('Missing template id', 422);

    $src = null;
    try {
        $r = $conn->query("SELECT id, name, category, subject_default, body_html FROM campaign_templates WHERE id=$srcId LIMIT 1");
        $src = $r ? $r->fetch_assoc() : null;
    } catch (\Throwable $e) { /* handled below */ }
    if (!$src) api_error('That template could not be found in Netcore', 404);

    $name = trim((string)jin('name', '')) !== '' ? (string)jin('name') : (string)$src['name'];
    $conn->query(sprintf("INSERT INTO kumo_templates (name, category, subject, body_html, created_by)
                          VALUES ('%s',%s,%s,'%s','%s')",
        esc($name),
        $src['category'] ? "'" . esc($src['category']) . "'" : 'NULL',
        $src['subject_default'] ? "'" . esc($src['subject_default']) . "'" : 'NULL',
        esc((string)$src['body_html']), esc($ME)));

    api_success(['template_id' => (int)$conn->insert_id], 'Template copied into Kumo');
}

function nf_int($n) { return number_format((int)$n); }

/* ════════════════════════════════════════════════════════════════════════════
   CAMPAIGNS
   ════════════════════════════════════════════════════════════════════════════ */
if ($action === 'campaigns_list') {
    $p   = max(1, jint('page', 1));
    $per = min(100, max(5, jint('per_page', 25)));
    $off = ($p - 1) * $per;
    $q   = trim((string)jin('search', ''));
    $st  = (string)jin('status', '');

    $w = '1=1';
    if ($q !== '')  $w .= " AND name LIKE '%" . esc($q) . "%'";
    if ($st !== '' && in_array($st, ['draft','scheduled','running','paused','sent','failed'], true)) $w .= " AND status='" . esc($st) . "'";

    $rows = [];
    $r = $conn->query("SELECT * FROM kumo_campaigns WHERE $w ORDER BY id DESC LIMIT $per OFFSET $off");
    while ($r && $x = $r->fetch_assoc()) $rows[] = kumo_campaign_public($x);
    $t = $conn->query("SELECT COUNT(*) c FROM kumo_campaigns WHERE $w");

    $counts = [];
    $r2 = $conn->query("SELECT status, COUNT(*) c FROM kumo_campaigns GROUP BY status");
    while ($r2 && $x = $r2->fetch_assoc()) $counts[$x['status']] = (int)$x['c'];

    api_success(['campaigns' => $rows, 'total' => $t ? (int)$t->fetch_assoc()['c'] : 0, 'page' => $p, 'per_page' => $per, 'counts' => $counts]);
}

/* Attachments live in S3 exactly as the Netcore campaigns module stores them
   (api/campaigns/campaigns.php), so the same bucket and the same size rules
   apply; only the key prefix and the owning table differ. */
const KUMO_ATTACH_MAX_FILE  = 5 * 1024 * 1024;
const KUMO_ATTACH_MAX_TOTAL = 15 * 1024 * 1024;
const KUMO_ATTACH_EXT = ['pdf','doc','docx','xls','xlsx','ppt','pptx','jpg','jpeg','png','gif','txt','csv','zip'];

function kumo_campaign_attachment_rows(int $id): array {
    global $conn;
    $r = $conn->query("SELECT attachments FROM kumo_campaigns WHERE id=" . (int)$id . " LIMIT 1");
    $row = $r ? $r->fetch_assoc() : null;
    if (!$row) api_error('Campaign not found', 404);
    return json_decode((string)($row['attachments'] ?? '[]'), true) ?: [];
}

if ($action === 'upload_attachment') {
    $id = jint('id');
    if (!$id) api_error('Save the campaign before adding attachments', 422);
    $existing = kumo_campaign_attachment_rows($id);

    if (empty($_FILES['file']) || $_FILES['file']['error'] !== UPLOAD_ERR_OK) api_error('Choose a file to attach', 422);
    $file = $_FILES['file'];
    $ext  = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    if (!in_array($ext, KUMO_ATTACH_EXT, true)) api_error('File type not allowed (.' . $ext . ') — allowed: ' . implode(', ', KUMO_ATTACH_EXT), 422);
    if ($file['size'] > KUMO_ATTACH_MAX_FILE) api_error('File too large — max 5MB per file', 422);

    $total = array_sum(array_map(fn($a) => (int)($a['size'] ?? 0), $existing));
    if ($total + $file['size'] > KUMO_ATTACH_MAX_TOTAL) api_error('Total attachments would exceed 15MB for this campaign', 422);

    $mimes = ['pdf' => 'application/pdf', 'doc' => 'application/msword',
        'docx' => 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        'xls' => 'application/vnd.ms-excel', 'xlsx' => 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        'ppt' => 'application/vnd.ms-powerpoint',
        'pptx' => 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
        'jpg' => 'image/jpeg', 'jpeg' => 'image/jpeg', 'png' => 'image/png', 'gif' => 'image/gif',
        'txt' => 'text/plain', 'csv' => 'text/csv', 'zip' => 'application/zip'];
    $mime = $mimes[$ext] ?? 'application/octet-stream';

    $s3lib = __DIR__ . '/../lib/S3Uploader.php';
    if (!is_file($s3lib)) api_error('Attachment storage is not configured on this server', 500);
    require_once $s3lib;

    $safe = preg_replace('/[^a-zA-Z0-9_.\-]/', '_', basename($file['name']));
    $key  = 'kumo_campaign_attachments/' . $id . '/' . bin2hex(random_bytes(8)) . '_' . $safe;
    $url  = s3_upload_file($file['tmp_name'], $key, $mime);
    if (!$url) api_error('Could not upload the attachment to storage', 500);

    $existing[] = ['filename' => $safe, 's3_key' => $key, 's3_url' => $url, 'size' => (int)$file['size'], 'mime' => $mime];
    $conn->query("UPDATE kumo_campaigns SET attachments='" . esc(json_encode($existing)) . "' WHERE id=" . (int)$id);
    api_success(['attachments' => $existing], 'Attached');
}

if ($action === 'remove_attachment') {
    $id  = jint('id');
    $key = (string)jin('s3_key', '');
    if (!$id || $key === '') api_error('Missing id or file', 422);
    $existing = kumo_campaign_attachment_rows($id);
    /* The S3 object is left in place on purpose — a campaign that already sent
       may still be reporting, and a stray 1MB file is cheaper than a broken one. */
    $remaining = array_values(array_filter($existing, fn($a) => ($a['s3_key'] ?? '') !== $key));
    $conn->query("UPDATE kumo_campaigns SET attachments='" . esc(json_encode($remaining)) . "' WHERE id=" . (int)$id);
    api_success(['attachments' => $remaining], 'Removed');
}

if ($action === 'campaign_get') {
    $id = jint('id');
    $r = $conn->query("SELECT * FROM kumo_campaigns WHERE id=$id LIMIT 1");
    $x = $r ? $r->fetch_assoc() : null;
    if (!$x) api_error('Campaign not found', 404);
    $x['list_ids']         = json_decode((string)$x['list_ids'], true) ?: [];
    $x['segment_ids']      = json_decode((string)$x['segment_ids'], true) ?: [];
    $x['exclude_list_ids'] = json_decode((string)$x['exclude_list_ids'], true) ?: [];
    $x['ip_ids']           = json_decode((string)$x['ip_ids'], true) ?: [];
    $x['attachments']      = json_decode((string)($x['attachments'] ?? '[]'), true) ?: [];
    api_success(['campaign' => $x, 'stats' => kumo_campaign_public($x)]);
}

if ($action === 'campaign_save') {
    $id   = jint('id');
    $name = trim((string)jin('name', ''));
    if ($name === '') api_error('Campaign name is required', 422);

    $audience = (string)jin('audience_type', 'list');
    if (!in_array($audience, ['list','segment','all_contacts'], true)) $audience = 'list';
    $ipMode = jin('ip_mode', 'auto') === 'fixed' ? 'fixed' : 'auto';
    $schedType = jin('schedule_type', 'now') === 'later' ? 'later' : 'now';
    $schedAt = jin('scheduled_at');

    $fields = sprintf(
        "name='%s', template_id=%s, subject=%s, preheader=%s, from_name=%s, from_email=%s, reply_to=%s,
         body_html=%s, body_text=%s, audience_type='%s', list_ids=%s, segment_ids=%s, exclude_list_ids=%s,
         ip_mode='%s', ip_ids=%s, schedule_type='%s', scheduled_at=%s, throttle_per_hour=%s,
         track_opens=%d, track_clicks=%d",
        esc($name),
        jint('template_id') ? jint('template_id') : 'NULL',
        jin('subject') !== null ? "'" . esc(jin('subject')) . "'" : 'NULL',
        jin('preheader') !== null ? "'" . esc(jin('preheader')) . "'" : 'NULL',
        jin('from_name') !== null ? "'" . esc(jin('from_name')) . "'" : 'NULL',
        jin('from_email') !== null ? "'" . esc(jin('from_email')) . "'" : 'NULL',
        jin('reply_to') !== null ? "'" . esc(jin('reply_to')) . "'" : 'NULL',
        "'" . esc((string)jin('body_html', '')) . "'",
        "'" . esc((string)jin('body_text', '')) . "'",
        esc($audience),
        jsonOrNull(array_map('intval', jarr('list_ids'))),
        jsonOrNull(array_map('intval', jarr('segment_ids'))),
        jsonOrNull(array_map('intval', jarr('exclude_list_ids'))),
        esc($ipMode),
        jsonOrNull(array_map('intval', jarr('ip_ids'))),
        esc($schedType),
        $schedAt ? "'" . esc(date('Y-m-d H:i:s', strtotime((string)$schedAt))) . "'" : 'NULL',
        jint('throttle_per_hour') ? jint('throttle_per_hour') : 'NULL',
        // Tracking is not a per-campaign option — every Kumo campaign is sent with
        // the open pixel and wrapped links, whatever the request carries.
        1, 1
    );

    if ($id) {
        $chk = $conn->query("SELECT status FROM kumo_campaigns WHERE id=$id LIMIT 1");
        $cur = $chk ? $chk->fetch_assoc() : null;
        if ($cur && in_array($cur['status'], ['running','sent'], true)) api_error('A running or completed campaign cannot be edited', 409);
        $conn->query("UPDATE kumo_campaigns SET $fields WHERE id=$id");
    } else {
        $conn->query("INSERT INTO kumo_campaigns SET $fields, created_by='" . esc($ME) . "'");
        $id = (int)$conn->insert_id;
    }
    api_success(['id' => $id], 'Campaign saved');
}

if ($action === 'campaign_preview_audience') {
    $count = kumo_audience_preview(
        (string)jin('audience_type', 'list'),
        array_map('intval', jarr('list_ids')),
        array_map('intval', jarr('segment_ids')),
        array_map('intval', jarr('exclude_list_ids'))
    );
    api_success(['count' => $count]);
}

if ($action === 'campaign_delete') {
    $id = jint('id');
    $chk = $conn->query("SELECT status FROM kumo_campaigns WHERE id=$id LIMIT 1");
    $cur = $chk ? $chk->fetch_assoc() : null;
    if (!$cur) api_error('Campaign not found', 404);
    if ($cur['status'] === 'running') api_error('Pause the campaign before deleting it', 409);
    $conn->query("DELETE FROM kumo_campaign_recipients WHERE campaign_id=$id");
    $conn->query("DELETE FROM kumo_campaigns WHERE id=$id");
    api_success([], 'Campaign deleted');
}

if ($action === 'campaign_duplicate') {
    $id = jint('id');
    $r = $conn->query("SELECT * FROM kumo_campaigns WHERE id=$id LIMIT 1");
    $c = $r ? $r->fetch_assoc() : null;
    if (!$c) api_error('Campaign not found', 404);
    $conn->query(sprintf("INSERT INTO kumo_campaigns
        (name, status, template_id, subject, preheader, from_name, from_email, reply_to, body_html, body_text,
         audience_type, list_ids, segment_ids, exclude_list_ids, ip_mode, ip_ids, schedule_type, track_opens, track_clicks, created_by)
        VALUES ('%s','draft',%s,%s,%s,%s,%s,%s,'%s','%s','%s',%s,%s,%s,'%s',%s,'now',%d,%d,'%s')",
        esc($c['name'] . ' (copy)'),
        $c['template_id'] ? (int)$c['template_id'] : 'NULL',
        $c['subject'] !== null ? "'" . esc($c['subject']) . "'" : 'NULL',
        $c['preheader'] !== null ? "'" . esc($c['preheader']) . "'" : 'NULL',
        $c['from_name'] !== null ? "'" . esc($c['from_name']) . "'" : 'NULL',
        $c['from_email'] !== null ? "'" . esc($c['from_email']) . "'" : 'NULL',
        $c['reply_to'] !== null ? "'" . esc($c['reply_to']) . "'" : 'NULL',
        esc((string)$c['body_html']), esc((string)$c['body_text']), esc($c['audience_type']),
        $c['list_ids'] ? "'" . esc($c['list_ids']) . "'" : 'NULL',
        $c['segment_ids'] ? "'" . esc($c['segment_ids']) . "'" : 'NULL',
        $c['exclude_list_ids'] ? "'" . esc($c['exclude_list_ids']) . "'" : 'NULL',
        esc($c['ip_mode']),
        $c['ip_ids'] ? "'" . esc($c['ip_ids']) . "'" : 'NULL',
        (int)$c['track_opens'], (int)$c['track_clicks'], esc($ME)));
    api_success(['id' => (int)$conn->insert_id], 'Campaign duplicated');
}

if ($action === 'campaign_send_test') {
    $id     = jint('id');
    $emails = array_filter(array_map('trim', preg_split('/[\s,;]+/', (string)jin('emails', ''))));
    if (!$id || !$emails) api_error('Pick a campaign and at least one test address', 422);

    $r = $conn->query("SELECT * FROM kumo_campaigns WHERE id=$id LIMIT 1");
    $c = $r ? $r->fetch_assoc() : null;
    if (!$c) api_error('Campaign not found', 404);

    $ips = kumo_eligible_ips($c['ip_mode'] === 'fixed' ? array_map('intval', json_decode((string)$c['ip_ids'], true) ?: []) : []);
    if (!$ips) api_error('No sending IP is currently available (check IP health and today\'s quota)', 409);

    $client = new KumoClient();
    if (!$client->isConfigured()) api_error('The KumoMTA bridge is not configured yet (Settings → Connection)', 409);

    $sent = 0; $errors = [];
    foreach ($emails as $em) {
        if (!filter_var($em, FILTER_VALIDATE_EMAIL)) { $errors[] = "$em is not a valid address"; continue; }
        $rid = kumo_rid();
        $conn->query(sprintf("INSERT INTO kumo_campaign_recipients (campaign_id, email, rid, status, is_test, ip_id, provider)
                              VALUES (%d, '%s', '%s', 'processing', 1, %d, '%s')",
            $id, esc(strtolower($em)), esc($rid), (int)$ips[0]['id'], esc(kumo_provider_of($em))));
        $rowId = (int)$conn->insert_id;

        $rcpt = ['id' => $rowId, 'email' => $em, 'rid' => $rid, 'first_name' => 'Test', 'last_name' => ''];
        /* A test has to be the real thing — same files, same [NAME] values — or it
           proves nothing about what the audience will receive. */
        $rcpt['attr_tokens'] = kumo_resolve_attributes([$rcpt])[strtolower($em)] ?? [];
        $msg  = kumo_build_message($c, $rcpt, $ips[0], kumo_campaign_attachments($c));
        $inj  = $client->inject($msg['envelope_sender'], $msg['content'], [['email' => $em]]);

        if (($inj['success_count'] ?? 0) > 0) {
            $conn->query("UPDATE kumo_campaign_recipients SET status='sent', sent_at=NOW() WHERE id=$rowId");
            /* The IP really did carry this message, and its delivery receipt will
               bump 'delivered' — so 'sent' has to move too or the per-IP delivery
               rate climbs past 100%. Campaign counters stay untouched: a test is
               not part of the audience. */
            kumo_stats_bump((int)$ips[0]['id'], kumo_provider_of($em), ['sent' => 1]);
            kumo_consume_quota((int)$ips[0]['id'], 1);
            $sent++;
        } else {
            $conn->query("UPDATE kumo_campaign_recipients SET status='failed', error='" . esc(substr((string)$inj['error'], 0, 400)) . "' WHERE id=$rowId");
            $errors[] = $em . ': ' . (string)$inj['error'];
        }
    }
    if ($sent === 0) api_error('Test send failed — ' . implode(' · ', $errors), 502);
    api_success(['sent' => $sent, 'errors' => $errors], 'Test sent to ' . $sent . ' address(es)');
}

if ($action === 'campaign_send_now' || $action === 'campaign_schedule') {
    $id = jint('id');
    $r = $conn->query("SELECT * FROM kumo_campaigns WHERE id=$id LIMIT 1");
    $c = $r ? $r->fetch_assoc() : null;
    if (!$c) api_error('Campaign not found', 404);
    if (trim((string)$c['subject']) === '')   api_error('Add a subject line first', 422);
    if (trim((string)$c['body_html']) === '') api_error('Add some content first', 422);
    if (trim((string)$c['from_email']) === '' && kumo_setting('from_email', '') === '') api_error('Set a From address (Settings → Sender)', 422);

    $client = new KumoClient();
    if (!$client->isConfigured()) api_error('The KumoMTA bridge is not configured yet (Settings → Connection)', 409);

    /* Materialise the audience now so the user immediately sees the real count. */
    $mat = kumo_materialize($id);
    if ($mat['error']) api_error($mat['error'], 422);
    if ((int)$mat['inserted'] === 0) {
        $chk = $conn->query("SELECT COUNT(*) c FROM kumo_campaign_recipients WHERE campaign_id=$id AND is_test=0");
        $have = $chk ? (int)$chk->fetch_assoc()['c'] : 0;
        if ($have === 0) api_error('This audience resolved to 0 contacts', 422);
    }

    if ($action === 'campaign_schedule') {
        $when = jin('scheduled_at');
        if (!$when) api_error('Pick a date and time', 422);
        $conn->query("UPDATE kumo_campaigns SET status='scheduled', schedule_type='later',
                        scheduled_at='" . esc(date('Y-m-d H:i:s', strtotime((string)$when))) . "' WHERE id=$id");
        api_success(['id' => $id, 'recipients' => (int)$mat['inserted']], 'Campaign scheduled');
    }

    $conn->query("UPDATE kumo_campaigns SET status='running', started_at=COALESCE(started_at, NOW()) WHERE id=$id");
    kumo_trigger_worker_async($id);
    api_success(['id' => $id, 'recipients' => (int)$mat['inserted']], 'Sending has started');
}

if ($action === 'campaign_pause' || $action === 'campaign_resume') {
    $id = jint('id');
    if (!$id) api_error('Missing id', 422);
    if ($action === 'campaign_pause') {
        $conn->query("UPDATE kumo_campaigns SET status='paused' WHERE id=$id AND status IN ('running','scheduled')");
        api_success([], 'Campaign paused — nothing more will be sent');
    }
    $conn->query("UPDATE kumo_campaigns SET status='running' WHERE id=$id AND status='paused'");
    kumo_trigger_worker_async($id);
    api_success([], 'Campaign resumed');
}

if ($action === 'campaign_report') {
    $id = jint('id');
    $r = $conn->query("SELECT * FROM kumo_campaigns WHERE id=$id LIMIT 1");
    $c = $r ? $r->fetch_assoc() : null;
    if (!$c) api_error('Campaign not found', 404);

    $byIp = [];
    $r = $conn->query("SELECT r.ip_id, i.ip, i.tenant,
                COUNT(*) sent,
                SUM(r.status='delivered') delivered,
                SUM(r.status='bounced') bounced,
                SUM(r.open_count > 0) opened,
                SUM(r.click_count > 0) clicked
            FROM kumo_campaign_recipients r LEFT JOIN kumo_ips i ON i.id=r.ip_id
            WHERE r.campaign_id=$id AND r.is_test=0 AND r.ip_id IS NOT NULL GROUP BY r.ip_id, i.ip, i.tenant");
    while ($r && $x = $r->fetch_assoc()) $byIp[] = array_map(fn($v) => is_numeric($v) ? (int)$v : $v, $x);

    $byProvider = [];
    $r = $conn->query("SELECT provider, COUNT(*) sent, SUM(status='delivered') delivered, SUM(status='bounced') bounced,
                SUM(open_count>0) opened, SUM(click_count>0) clicked
            FROM kumo_campaign_recipients WHERE campaign_id=$id AND is_test=0 AND provider IS NOT NULL GROUP BY provider");
    while ($r && $x = $r->fetch_assoc()) $byProvider[] = array_map(fn($v) => is_numeric($v) ? (int)$v : $v, $x);

    $timeline = [];
    $r = $conn->query("SELECT DATE_FORMAT(created_at, '%Y-%m-%d %H:00') b, type, COUNT(*) c
            FROM kumo_campaign_events WHERE campaign_id=$id GROUP BY b, type ORDER BY b");
    while ($r && $x = $r->fetch_assoc()) $timeline[] = ['bucket' => $x['b'], 'type' => $x['type'], 'count' => (int)$x['c']];

    api_success([
        'campaign'    => kumo_campaign_public($c),
        'by_ip'       => $byIp,
        'by_provider' => $byProvider,
        'timeline'    => $timeline,
        'responses'   => kumo_campaign_responses($id),
    ]);
}

function kumo_campaign_responses(int $id): array {
    global $conn;
    $out = [];
    $r = $conn->query("SELECT type, code, LEFT(COALESCE(response,''),160) msg, COUNT(*) c
        FROM kumo_campaign_events WHERE campaign_id=" . (int)$id . " AND type IN ('bounce','deferred','complaint')
        GROUP BY type, code, msg ORDER BY c DESC LIMIT 12");
    while ($r && $x = $r->fetch_assoc()) $out[] = ['type' => $x['type'], 'code' => $x['code'], 'message' => $x['msg'], 'count' => (int)$x['c']];
    return $out;
}

if ($action === 'campaign_recipients') {
    $id  = jint('id');
    $p   = max(1, jint('page', 1));
    $per = min(200, max(10, jint('per_page', 50)));
    $off = ($p - 1) * $per;
    $st  = (string)jin('status', '');
    $q   = trim((string)jin('search', ''));

    /* Every condition is qualified with r.: kumo_ips carries its own `status`
       column, so an unqualified status='sent' is ambiguous inside the join and
       MySQL rejects the whole query — which surfaced as a 500 on every tab
       except All. The count query joins nothing but takes the same alias so one
       WHERE can serve both. */
    $w = "r.campaign_id=$id";

    /* The tabs are outcomes, not raw status values: a delivered message was also
       sent, and a bounced one was too. Filtering status='sent' literally would
       empty the Sent tab the moment a receipt arrived. */
    switch ($st) {
        case '':          break;
        case 'sent':      $w .= " AND r.sent_at IS NOT NULL"; break;
        case 'delivered': $w .= " AND r.delivered_at IS NOT NULL"; break;
        case 'bounced':   $w .= " AND r.bounced_at IS NOT NULL"; break;
        case 'opened':    $w .= " AND r.opened_at IS NOT NULL"; break;
        case 'clicked':   $w .= " AND r.clicked_at IS NOT NULL"; break;
        default:          $w .= " AND r.status='" . esc($st) . "'"; break;   // failed, skipped, pending…
    }
    if ($q !== '')  $w .= " AND r.email LIKE '%" . esc($q) . "%'";

    $rows = [];
    $r = $conn->query("SELECT r.*, i.ip AS ip_addr FROM kumo_campaign_recipients r LEFT JOIN kumo_ips i ON i.id=r.ip_id
                       WHERE $w ORDER BY r.id DESC LIMIT $per OFFSET $off");
    while ($r && $x = $r->fetch_assoc()) $rows[] = $x;
    $t = $conn->query("SELECT COUNT(*) c FROM kumo_campaign_recipients r WHERE $w");
    api_success(['rows' => $rows, 'total' => $t ? (int)$t->fetch_assoc()['c'] : 0, 'page' => $p, 'per_page' => $per]);
}

/* ════════════════════════════════════════════════════════════════════════════
   MESSAGE LOG / EVENTS
   ════════════════════════════════════════════════════════════════════════════ */
if ($action === 'message_log') {
    $q   = trim((string)jin('search', ''));
    $p   = max(1, jint('page', 1));
    $per = min(200, max(10, jint('per_page', 50)));
    $off = ($p - 1) * $per;

    $w = '1=1';
    if ($q !== '') $w .= " AND r.email LIKE '%" . esc($q) . "%'";
    if (jint('campaign_id')) $w .= ' AND r.campaign_id=' . jint('campaign_id');
    if (jint('ip_id'))       $w .= ' AND r.ip_id=' . jint('ip_id');
    if (jin('status'))       $w .= " AND r.status='" . esc((string)jin('status')) . "'";

    $rows = [];
    $r = $conn->query("SELECT r.id, r.email, r.status, r.smtp_code, r.error, r.bounce_type, r.sent_at, r.delivered_at,
                              r.bounced_at, r.opened_at, r.clicked_at, r.open_count, r.click_count, r.provider,
                              c.name AS campaign, i.ip AS ip_addr
                       FROM kumo_campaign_recipients r
                       LEFT JOIN kumo_campaigns c ON c.id=r.campaign_id
                       LEFT JOIN kumo_ips i ON i.id=r.ip_id
                       WHERE $w ORDER BY r.id DESC LIMIT $per OFFSET $off");
    while ($r && $x = $r->fetch_assoc()) $rows[] = $x;
    $t = $conn->query("SELECT COUNT(*) c FROM kumo_campaign_recipients r WHERE $w");
    api_success(['rows' => $rows, 'total' => $t ? (int)$t->fetch_assoc()['c'] : 0, 'page' => $p, 'per_page' => $per]);
}

if ($action === 'message_events') {
    $rid = (string)jin('rid', '');
    $rcpId = jint('recipient_id');
    if ($rid === '' && !$rcpId) api_error('Missing rid', 422);
    $w = $rid !== '' ? "rid='" . esc($rid) . "'" : "recipient_id=$rcpId";
    $rows = [];
    $r = $conn->query("SELECT * FROM kumo_campaign_events WHERE $w ORDER BY id DESC LIMIT 200");
    while ($r && $x = $r->fetch_assoc()) $rows[] = $x;
    api_success(['events' => $rows]);
}

/* ════════════════════════════════════════════════════════════════════════════
   ALERTS + SETTINGS
   ════════════════════════════════════════════════════════════════════════════ */
if ($action === 'alerts_list') {
    api_success(['alerts' => kumo_alerts_list(jint('limit', 50), jbool('open_only', 1) === 1)]);
}

if ($action === 'alert_ack') {
    $id = jint('id');
    if ($id) $conn->query("UPDATE kumo_alerts SET acknowledged_at=NOW(), acknowledged_by='" . esc($ME) . "' WHERE id=$id");
    else     $conn->query("UPDATE kumo_alerts SET acknowledged_at=NOW(), acknowledged_by='" . esc($ME) . "' WHERE acknowledged_at IS NULL");
    api_success([], 'Acknowledged');
}

if ($action === 'settings_get') {
    $rows = [];
    $r = $conn->query("SELECT k, v FROM kumo_settings");
    while ($r && $x = $r->fetch_assoc()) $rows[$x['k']] = $x['v'];
    if (isset($rows['bridge_token']) && $rows['bridge_token'] !== '') {
        $rows['bridge_token_set'] = '1';
        $rows['bridge_token'] = str_repeat('•', 12) . substr($rows['bridge_token'], -4);
    } else {
        $rows['bridge_token_set'] = '0';
    }
    $plan = [];
    $r = $conn->query("SELECT * FROM kumo_warmup_plan ORDER BY day_from");
    while ($r && $x = $r->fetch_assoc()) $plan[] = ['id' => (int)$x['id'], 'day_from' => (int)$x['day_from'], 'day_to' => (int)$x['day_to'], 'daily_cap' => (int)$x['daily_cap']];

    api_success(['settings' => $rows, 'warmup_plan' => $plan, 'webhook_url' =>
        rtrim((string)($rows['public_base_url'] ?? KUMO_PUBLIC_BASE_URL), '/') . '/kumo-webhook.php?secret=' . KUMO_CRON_SECRET]);
}

if ($action === 'settings_save') {
    $allowed = ['bridge_url','bridge_token','from_name','from_email','reply_to','bounce_domain','tracking_domain',
                'public_base_url','th_bounce_yellow','th_bounce_red','th_complaint_yellow','th_complaint_red',
                'th_deferral_yellow','th_deferral_red','recovery_hours','send_window_start','send_window_end',
                'spamhaus_dqs_key','alert_emails','warmup_auto','honour_netcore_blocklist'];
    $saved = 0;
    foreach ($allowed as $k) {
        $v = jin($k, null);
        if ($v === null) continue;
        /* Never overwrite a stored token with the masked placeholder. */
        if ($k === 'bridge_token' && strpos((string)$v, '•') !== false) continue;
        kumo_set_setting($k, (string)$v);
        $saved++;
    }

    $plan = jarr('warmup_plan');
    if ($plan) {
        $conn->query("DELETE FROM kumo_warmup_plan");
        foreach ($plan as $row) {
            $conn->query(sprintf("INSERT IGNORE INTO kumo_warmup_plan (day_from, day_to, daily_cap) VALUES (%d,%d,%d)",
                (int)($row['day_from'] ?? 1), (int)($row['day_to'] ?? 1), (int)($row['daily_cap'] ?? 0)));
        }
        kumo_warmup_tick();
    }
    api_success(['saved' => $saved], 'Settings saved');
}

if ($action === 'bridge_test') {
    $url   = (string)jin('bridge_url', (string)kumo_setting('bridge_url', KUMO_BRIDGE_URL));
    $token = (string)jin('bridge_token', '');
    if ($token === '' || strpos($token, '•') !== false) $token = (string)kumo_setting('bridge_token', '');
    $c = new KumoClient($url, $token);
    $h = $c->health();
    if (!$h['ok']) api_error('Could not reach the KumoMTA bridge: ' . ($h['error'] ?: 'unknown error'), 502);
    api_success($h, 'Bridge is reachable');
}

/* ════════════════════════════════════════════════════════════════════════════ */
api_error('Unknown action: ' . htmlspecialchars($action), 400);

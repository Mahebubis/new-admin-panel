<?php
/*
 * Receiver for KumoMTA's log hook.
 *
 * KumoMTA posts one JSON record (or an array of records) per event:
 *   {"type":"Delivery","id":"…","sender":"b-<rid>@bounce…","recipient":"…",
 *    "response":{"code":250,"content":"…"},"egress_source":"ip1",
 *    "bounce_classification":"BadMailbox","headers":{"X-Message-Ref":"…"}, …}
 *
 * Contract with the sender: always answer HTTP 200 with {"ok":true,…} so a
 * failure here never makes KumoMTA retry-storm. Everything is idempotent —
 * a replayed event must not double-count.
 *
 * URL configured on the mail server:
 *   https://cit3.internshipstudio.com/admin/react-api/api/kumo/kumo-webhook.php?secret=<KUMO_CRON_SECRET>
 */
ini_set('display_errors', 0);
error_reporting(E_ALL & ~E_WARNING & ~E_NOTICE & ~E_DEPRECATED);

try {
    require_once __DIR__ . '/../../config/database.php';
} catch (\Throwable $e) {
    http_response_code(200);
    echo json_encode(['ok' => false, 'error' => 'db']);
    exit;
}
require_once __DIR__ . '/lib/config.php';
require_once __DIR__ . '/lib/schema.php';
require_once __DIR__ . '/lib/Stats.php';
require_once __DIR__ . '/lib/Audience.php';

kumo_ensure_schema();

header('Content-Type: application/json');

if (($_GET['secret'] ?? '') !== KUMO_CRON_SECRET) {
    http_response_code(403);
    echo json_encode(['ok' => false, 'error' => 'forbidden']);
    exit;
}

$raw  = file_get_contents('php://input');
$json = json_decode($raw, true);
if (!is_array($json)) { echo json_encode(['ok' => true, 'processed' => 0]); exit; }

/* A single record or a batch. */
$records = isset($json['type']) ? [$json] : $json;
$processed = 0;

foreach ($records as $rec) {
    if (!is_array($rec)) continue;
    try { kumo_handle_event($rec); $processed++; }
    catch (\Throwable $e) { error_log('kumo webhook: ' . $e->getMessage()); }
}

echo json_encode(['ok' => true, 'processed' => $processed]);

/* ─────────────────────────────────────────────────────────────────────────── */

function kumo_handle_event(array $rec): void {
    global $conn;

    $type = (string)($rec['type'] ?? '');
    if ($type === '') return;

    /* rid: from our own header first, else parsed out of the bounce address. */
    $headers = is_array($rec['headers'] ?? null) ? $rec['headers'] : [];
    $rid = (string)($headers['X-Message-Ref'] ?? '');
    if ($rid === '' && preg_match('/b-([0-9a-f]{32})@/i', (string)($rec['sender'] ?? ''), $m)) $rid = $m[1];
    if ($rid === '' && preg_match('/b-([0-9a-f]{32})@/i', (string)($rec['recipient'] ?? ''), $m)) $rid = $m[1];

    $recipientRow = null;
    if ($rid !== '') {
        $r = $conn->query("SELECT * FROM kumo_campaign_recipients WHERE rid='" . $conn->real_escape_string($rid) . "' LIMIT 1");
        $recipientRow = $r ? $r->fetch_assoc() : null;
    }

    $campaignId = $recipientRow ? (int)$recipientRow['campaign_id'] : (int)($headers['X-Campaign-ID'] ?? 0);

    /* A test send is real mail from a real IP — it belongs in the per-IP stats —
       but it is not part of the campaign's audience, so it must not touch the
       campaign's delivered/bounced/complaint counters. Before this, one test send
       left a campaign reading "0 sent, 2 delivered". */
    $isTest = $recipientRow ? ((int)($recipientRow['is_test'] ?? 0) === 1) : false;
    $ipId       = $recipientRow ? (int)$recipientRow['ip_id'] : 0;
    if (!$ipId) $ipId = kumo_ip_id_for_source((string)($rec['egress_source'] ?? ''));

    $email    = (string)($rec['recipient'] ?? ($recipientRow['email'] ?? ''));
    $provider = $email !== '' ? kumo_provider_of($email) : 'other';
    $code     = (string)($rec['response']['code'] ?? '');
    $content  = (string)($rec['response']['content'] ?? '');
    $cls      = (string)($rec['bounce_classification'] ?? '');

    $store = function (string $evType, array $extra = []) use ($conn, $campaignId, $recipientRow, $rid, $ipId, $provider, $code, $content, $rec) {
        $conn->query(sprintf(
            "INSERT INTO kumo_campaign_events (campaign_id, recipient_id, rid, ip_id, type, provider, code, response, meta, created_at)
             VALUES (%s, %s, %s, %s, '%s', '%s', %s, %s, %s, NOW())",
            $campaignId ? (int)$campaignId : 'NULL',
            $recipientRow ? (int)$recipientRow['id'] : 'NULL',
            $rid !== '' ? "'" . $conn->real_escape_string($rid) . "'" : 'NULL',
            $ipId ? (int)$ipId : 'NULL',
            $conn->real_escape_string($evType),
            $conn->real_escape_string($provider),
            $code !== '' ? "'" . $conn->real_escape_string(substr($code, 0, 16)) . "'" : 'NULL',
            $content !== '' ? "'" . $conn->real_escape_string(substr($content, 0, 2000)) . "'" : 'NULL',
            "'" . $conn->real_escape_string(json_encode(array_merge([
                'site' => $rec['site'] ?? null, 'egress_source' => $rec['egress_source'] ?? null,
                'classification' => $rec['bounce_classification'] ?? null,
            ], $extra), JSON_UNESCAPED_SLASHES)) . "'"
        ));
    };

    switch ($type) {
        case 'Delivery':
            if ($recipientRow && $recipientRow['delivered_at'] === null) {
                $conn->query("UPDATE kumo_campaign_recipients SET status='delivered', delivered_at=NOW(), smtp_code='" . $conn->real_escape_string(substr($code, 0, 16)) . "' WHERE id=" . (int)$recipientRow['id']);
                if (!$isTest) $conn->query("UPDATE kumo_campaigns SET delivered_count=delivered_count+1 WHERE id=" . (int)$campaignId);
                kumo_stats_bump($ipId, $provider, ['delivered' => 1]);
            }
            $store('delivery');
            break;

        case 'TransientFailure':
            $store('deferred');
            kumo_stats_bump($ipId, $provider, ['deferred' => 1]);
            break;

        case 'Bounce':
        case 'OOB':
            $hard = kumo_is_hard_bounce($cls, $code, $content);
            if ($recipientRow && $recipientRow['bounced_at'] === null) {
                $conn->query("UPDATE kumo_campaign_recipients SET status='bounced', bounced_at=NOW(),
                                bounce_type='" . ($hard ? 'hard' : 'soft') . "',
                                smtp_code='" . $conn->real_escape_string(substr($code, 0, 16)) . "',
                                error='" . $conn->real_escape_string(substr($content, 0, 480)) . "'
                              WHERE id=" . (int)$recipientRow['id']);
                if (!$isTest) $conn->query("UPDATE kumo_campaigns SET bounced_count=bounced_count+1,
                                delivered_count = GREATEST(0, delivered_count - " . ($recipientRow['delivered_at'] ? 1 : 0) . ")
                              WHERE id=" . (int)$campaignId);
                kumo_stats_bump($ipId, $provider, ['bounced' => 1]);
            }
            $store($type === 'OOB' ? 'bounce' : 'bounce', ['hard' => $hard]);
            if ($hard && $email !== '') kumo_suppress($email, 'hard_bounce', $code . ' ' . $content, $campaignId ?: null);
            break;

        case 'Feedback':   // ARF complaint forwarded by Microsoft JMRP / Yahoo CFL
            $fb   = is_array($rec['feedback_report'] ?? null) ? $rec['feedback_report'] : [];
            $addr = (string)($fb['original_rcpt_to'] ?? $email);
            if ($addr !== '' && $recipientRow === null) {
                $r2 = $conn->query("SELECT * FROM kumo_campaign_recipients WHERE email='" . $conn->real_escape_string(strtolower($addr)) . "' ORDER BY id DESC LIMIT 1");
                $recipientRow = $r2 ? $r2->fetch_assoc() : null;
                if ($recipientRow) { $campaignId = (int)$recipientRow['campaign_id']; $ipId = (int)$recipientRow['ip_id']; }
            }
            $store('complaint', ['feedback_type' => $fb['feedback_type'] ?? null]);
            if ($campaignId && !($recipientRow && (int)($recipientRow['is_test'] ?? 0) === 1)) {
                $conn->query("UPDATE kumo_campaigns SET complaint_count=complaint_count+1 WHERE id=" . (int)$campaignId);
            }
            kumo_stats_bump($ipId, $provider, ['complaints' => 1]);
            if ($addr !== '') kumo_suppress($addr, 'complaint', 'ARF feedback report', $campaignId ?: null);
            break;

        case 'AdminBounce':
            $store('admin_bounce');
            break;

        case 'Reception':
        default:
            /* Receptions are already recorded by the sender; ignore duplicates. */
            break;
    }
}

/** Maps KumoMTA's egress_source ("ip1") back to our kumo_ips row. */
function kumo_ip_id_for_source(string $source): int {
    global $conn;
    static $cache = [];
    $source = trim($source);
    if ($source === '') return 0;
    if (isset($cache[$source])) return $cache[$source];
    try {
        $r = $conn->query("SELECT id FROM kumo_ips WHERE tenant='" . $conn->real_escape_string($source) . "' LIMIT 1");
        $x = $r ? $r->fetch_assoc() : null;
        return $cache[$source] = $x ? (int)$x['id'] : 0;
    } catch (\Throwable $e) { return 0; }
}

/**
 * Hard vs soft. KumoMTA's own classifier is trusted first; the SMTP code is
 * the fallback (5xx permanent, 4xx temporary).
 */
function kumo_is_hard_bounce(string $classification, string $code, string $content): bool {
    $hardClasses = ['BadMailbox','BadDomain','InvalidRecipient','NoSuchUser','PolicyRelated','Spam','ContentRelated','ProhibitedAttachment','RelayDenied','AuthenticationFailed'];
    $softClasses = ['QuotaIssues','InactiveMailbox','MessageExpired','NetworkError','ProtocolErrors','Greylisting','Throttled','RoutingErrors'];
    if ($classification !== '') {
        if (in_array($classification, $softClasses, true)) return false;
        if (in_array($classification, $hardClasses, true)) return true;
    }
    if ($code !== '' && $code[0] === '5') {
        /* 5.2.2 mailbox full and 452 over quota are permanent codes for a
           temporary condition — treat them as soft so we don't suppress. */
        if (stripos($content, 'quota') !== false || stripos($content, 'mailbox full') !== false) return false;
        return true;
    }
    return false;
}

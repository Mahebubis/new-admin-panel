<?php
/**
 * problem_statements_api.php
 * ---------------------------------------------------------------------------
 * Admin API for Internship "Problem Statements".
 *
 * For every internship domain (internship_list row with is_full = 0) admins
 * can attach one or more problem-statement files. Each entry has an
 * (optional) title, an (optional) rich-HTML description and a (mandatory)
 * uploaded file. Files are stored on AWS S3 and the public URL is saved in
 * the internship_problem_statements table.
 *
 * Routes:
 *   GET  ?action=domains                      -> internships with is_full = 0 + counts
 *   GET  ?action=list&internship_id=ID        -> problem statements for a domain
 *   POST ?action=create        (multipart)    -> upload file + save row
 *   POST ?action=update                       -> edit title / description
 *   POST ?action=delete                       -> remove a row
 *   POST ?action=upload_image  (multipart)    -> editor inline image -> S3 URL
 *
 * Responses: { "status":"success", "data":{...} } | { "status":"error", ... }
 *
 * Mirrors the bootstrap / error-handling style of sim_admin_api.php and the
 * S3 upload approach of ../notes/notes.php (same bucket + credentials).
 * ---------------------------------------------------------------------------
 */

@ini_set('display_errors', '0');
error_reporting(E_ALL);

define('PS_LOG_FILE', __DIR__ . '/problem_statements_errors.log');
@ini_set('log_errors', '1');
@ini_set('error_log', PS_LOG_FILE);

function ps_log($label, $msg) {
    $line = '[' . date('Y-m-d H:i:s') . '] ' . $label . ': ' . $msg
          . '  {' . ($_SERVER['REQUEST_METHOD'] ?? 'CLI') . ' '
          . ($_SERVER['REQUEST_URI'] ?? '') . '}' . PHP_EOL;
    @file_put_contents(PS_LOG_FILE, $line, FILE_APPEND | LOCK_EX);
}

set_error_handler(function ($no, $str, $file, $line) {
    if (strpos($file, 'problem_statements_api.php') !== false) {
        ps_log('PHP-ERROR(' . $no . ')', $str . ' in ' . $file . ':' . $line);
    }
    return true;
});

/* shared bootstrap — provides global $conn (same as the other endpoints here) */
ob_start();
chdir('/home/istudio/public_html/cit/common');
include '/home/istudio/public_html/cit/common/helper.php';
ob_clean();

/* AWS SDK — same vendor autoload + bucket/creds as ../notes/notes.php */
require_once '/home/istudio/public_html/istudio_dashboard/api/vendor/autoload.php';
use Aws\S3\S3Client;
use Aws\Exception\AwsException;

header('Content-Type: application/json');

register_shutdown_function(function () {
    $e = error_get_last();
    if ($e && in_array($e['type'], [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR], true)) {
        ps_log('FATAL', $e['message'] . ' in ' . $e['file'] . ':' . $e['line']);
        if (!headers_sent()) header('Content-Type: application/json');
        echo json_encode(['status' => 'error', 'message' => 'Server error: ' . $e['message']]);
    }
});

set_exception_handler(function ($e) {
    ps_log('EXCEPTION', get_class($e) . ': ' . $e->getMessage()
        . ' in ' . $e->getFile() . ':' . $e->getLine());
    if (!headers_sent()) {
        http_response_code(500);
        header('Content-Type: application/json');
    }
    echo json_encode(['status' => 'error', 'message' => 'Server error: ' . $e->getMessage()]);
    exit;
});

/* ====== helpers ====== */
function ps_out($p) { echo json_encode($p); exit; }
function ps_error($m, $c = 400) {
    ps_log('API-ERROR(' . $c . ')', $m);
    http_response_code($c);
    ps_out(['status' => 'error', 'message' => $m]);
}
function ps_ok($d = null, $m = '') {
    $r = ['status' => 'success'];
    if ($m !== '') $r['message'] = $m;
    if ($d !== null) $r['data'] = $d;
    ps_out($r);
}
function ps_input() {
    $i = $_POST;
    if (empty($i)) {
        $j = json_decode(file_get_contents('php://input'), true);
        if (is_array($j)) $i = $j;
    }
    return $i;
}

/* ====== db ====== */
global $conn;
if (!$conn) ps_error('Database connection failed', 500);

/* ensure the table exists (safe to run every request) */
$conn->query("CREATE TABLE IF NOT EXISTS internship_problem_statements (
    id            INT AUTO_INCREMENT PRIMARY KEY,
    internship_id INT          NOT NULL,
    title         VARCHAR(255)      DEFAULT NULL,
    description   LONGTEXT          DEFAULT NULL,
    file_url      TEXT         NOT NULL,
    file_key      VARCHAR(512) NOT NULL,
    file_name     VARCHAR(255)      DEFAULT NULL,
    file_type     VARCHAR(40)       DEFAULT NULL,
    file_size     BIGINT            DEFAULT 0,
    mime_type     VARCHAR(150)      DEFAULT NULL,
    status        ENUM('active','inactive') DEFAULT 'active',
    created_by    INT               DEFAULT 0,
    created_at    TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,
    updated_at    TIMESTAMP    DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_internship_status (internship_id, status),
    INDEX idx_status_internship (status, internship_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

/* add composite indexes if the table already existed without them
   (CREATE TABLE IF NOT EXISTS won't add indexes to a pre-existing table).
   idx_internship_status -> list query (internship_id + status + order)
   idx_status_internship -> domain count query (status + GROUP BY internship_id) */
function ps_ensure_index($conn, $table, $index, $cols) {
    $r = $conn->query("SELECT COUNT(*) AS c FROM information_schema.statistics
                       WHERE table_schema = DATABASE() AND table_name = '$table'
                       AND index_name = '$index'");
    $exists = $r ? ((int)$r->fetch_assoc()['c'] > 0) : true;
    if (!$exists) @$conn->query("ALTER TABLE $table ADD INDEX $index ($cols)");
}
ps_ensure_index($conn, 'internship_problem_statements', 'idx_internship_status', 'internship_id, status');
ps_ensure_index($conn, 'internship_problem_statements', 'idx_status_internship', 'status, internship_id');

/* child items: each problem statement can hold many resources + datasets,
   and every item is either an uploaded file (S3) or an external link. */
$conn->query("CREATE TABLE IF NOT EXISTS internship_problem_statement_items (
    id           INT AUTO_INCREMENT PRIMARY KEY,
    statement_id INT NOT NULL,
    category     ENUM('resource','dataset') DEFAULT 'resource',
    kind         ENUM('file','link')        DEFAULT 'file',
    label        VARCHAR(255)      DEFAULT NULL,
    url          TEXT              DEFAULT NULL,
    file_url     TEXT              DEFAULT NULL,
    file_key     VARCHAR(512)      DEFAULT NULL,
    file_name    VARCHAR(255)      DEFAULT NULL,
    file_type    VARCHAR(40)       DEFAULT NULL,
    file_size    BIGINT            DEFAULT 0,
    mime_type    VARCHAR(150)      DEFAULT NULL,
    sort_order   INT               DEFAULT 0,
    status       ENUM('active','inactive') DEFAULT 'active',
    created_by   INT               DEFAULT 0,
    created_at   TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_stmt_status (statement_id, status, category, sort_order)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

/* coarse file-type bucket from extension / mime (for the right icon) */
function ps_file_type($name, $mime) {
    $ext = strtolower(pathinfo((string)$name, PATHINFO_EXTENSION));
    if ($ext === 'pdf') return 'pdf';
    if (in_array($ext, ['doc','docx','rtf','txt','odt'])) return 'doc';
    if (in_array($ext, ['xls','xlsx','csv','ods'])) return 'excel';
    if (in_array($ext, ['ppt','pptx','odp','key'])) return 'ppt';
    if (in_array($ext, ['mp4','mov','avi','mkv','webm'])) return 'video';
    if (in_array($ext, ['zip','rar','7z','tar','gz'])) return 'zip';
    if (in_array($ext, ['jpg','jpeg','png','gif','webp','svg','bmp'])) return 'image';
    if (strpos((string)$mime, 'image/') === 0) return 'image';
    if (strpos((string)$mime, 'video/') === 0) return 'video';
    return 'other';
}

$user_id  = (int)($_SESSION['user_id'] ?? 0);
$action   = $_GET['action'] ?? ($_POST['action'] ?? '');
$in       = ps_input();

/* ====== S3 config (same as ../notes/notes.php) ====== */
$awsRegion  = 'ap-south-1';
$bucketName = 'internshipstudio-prod-data-bucket-new';
$awsCreds   = [
    'key'    => 'AKIAYVYU7O43T344J2MD',
    'secret' => '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',
];
$buildS3 = function() use ($awsRegion, $awsCreds) {
    return new S3Client([
        'version'     => 'latest',
        'region'      => $awsRegion,
        'credentials' => $awsCreds,
    ]);
};

/* upload a $_FILES entry to S3, return [url, key, ...] or ps_error */
function ps_put_to_s3($file, $keyPrefix, $buildS3, $bucketName, $awsRegion) {
    if (empty($file) || !isset($file['error']) || $file['error'] !== UPLOAD_ERR_OK) {
        ps_error('File upload failed (code ' . ($file['error'] ?? 'n/a') . ')');
    }
    $maxSize = 50 * 1024 * 1024; // 50 MB
    if ($file['size'] > $maxSize) ps_error('File must be under 50MB');

    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION) ?: 'bin');
    $ext = preg_replace('/[^a-z0-9]+/', '', $ext) ?: 'bin';
    $key = rtrim($keyPrefix, '/') . '/' . date('Y/m') . '/' . uniqid('ps_', true) . '.' . $ext;

    $mime = $file['type'] ?: 'application/octet-stream';

    $s3 = $buildS3();
    try {
        $s3->putObject([
            'Bucket'      => $bucketName,
            'Key'         => $key,
            'SourceFile'  => $file['tmp_name'],
            'ContentType' => $mime,
        ]);
    } catch (AwsException $e) {
        ps_error('S3 upload error: ' . $e->getMessage(), 500);
    }
    return [
        'url'       => "https://{$bucketName}.s3.{$awsRegion}.amazonaws.com/{$key}",
        'key'       => $key,
        'name'      => $file['name'],
        'size'      => (int)$file['size'],
        'mime_type' => $mime,
    ];
}

/* =========================================================================
   DOMAINS — internship_list rows with is_full = 0, plus statement counts
   ========================================================================= */
if ($action === 'domains') {
    /* is_full = 0 domains, plus Energy Conservation (ecm) is always shown even when full */
    $sql = "SELECT il.id, il.internship_name, il.short_name
            FROM internship_list il
            WHERE il.is_full = 0 OR il.short_name = 'ecm'
            ORDER BY il.priority ASC, il.internship_name ASC";
    $res = $conn->query($sql);
    if ($res === false) ps_error('Could not read internship_list: ' . $conn->error, 500);

    $domains = [];
    while ($row = $res->fetch_assoc()) {
        $id = (int)$row['id'];
        $domains[$id] = [
            'internship_id' => $id,
            'name'          => $row['internship_name'],
            'short_name'    => $row['short_name'],
            'count'         => 0,
        ];
    }

    /* counts of active problem statements per domain */
    $cc = $conn->query("SELECT internship_id, COUNT(*) AS c
                        FROM internship_problem_statements
                        WHERE status = 'active'
                        GROUP BY internship_id");
    if ($cc) {
        while ($row = $cc->fetch_assoc()) {
            $id = (int)$row['internship_id'];
            if (isset($domains[$id])) $domains[$id]['count'] = (int)$row['c'];
        }
    }
    $conn->close();
    ps_ok(['domains' => array_values($domains)]);
}

/* =========================================================================
   LIST — problem statements for a single domain
   ========================================================================= */
if ($action === 'list') {
    $internship_id = isset($_GET['internship_id']) ? (int)$_GET['internship_id'] : 0;
    if ($internship_id <= 0) ps_error('internship_id is required');
    $stmt = $conn->prepare(
        "SELECT * FROM internship_problem_statements
         WHERE internship_id = ? AND status = 'active'
         ORDER BY created_at DESC, id DESC"
    );
    $stmt->bind_param('i', $internship_id);
    $stmt->execute();
    $r = $stmt->get_result();
    $rows = [];
    $byId = [];
    while ($row = $r->fetch_assoc()) {
        $row['id']            = (int)$row['id'];
        $row['internship_id'] = (int)$row['internship_id'];
        $row['file_size']     = (int)$row['file_size'];
        $row['items']         = [];
        $rows[] = $row;
        $byId[$row['id']] = count($rows) - 1;
    }
    $stmt->close();

    /* attach each statement's resource + dataset items */
    if ($rows) {
        $ids = implode(',', array_map(fn($r) => $r['id'], $rows));
        $ir = $conn->query("SELECT * FROM internship_problem_statement_items
                            WHERE statement_id IN ($ids) AND status='active'
                            ORDER BY category ASC, sort_order ASC, id ASC");
        if ($ir) {
            while ($it = $ir->fetch_assoc()) {
                $sid = (int)$it['statement_id'];
                if (!isset($byId[$sid])) continue;
                $it['id']         = (int)$it['id'];
                $it['statement_id'] = $sid;
                $it['file_size']  = (int)$it['file_size'];
                $rows[$byId[$sid]]['items'][] = $it;
            }
        }
    }
    $conn->close();
    ps_ok(['statements' => $rows]);
}

/* =========================================================================
   UPLOAD_IMAGE — inline image for the description editor -> S3
   ========================================================================= */
if ($action === 'upload_image') {
    if (empty($_FILES['image']) || $_FILES['image']['error'] !== UPLOAD_ERR_OK) {
        ps_error('Image file is required');
    }
    $file = $_FILES['image'];
    $allowed = ['image/jpeg','image/png','image/gif','image/webp'];
    if (!in_array($file['type'], $allowed, true)) ps_error('Only JPEG, PNG, GIF, WEBP images are allowed');
    if ($file['size'] > 5 * 1024 * 1024)          ps_error('Image must be under 5MB');

    $up = ps_put_to_s3($file, 'problem_statements/editor', $buildS3, $bucketName, $awsRegion);
    $conn->close();
    ps_ok([
        'url'           => $up['url'],
        'key'           => $up['key'],
        'original_name' => $up['name'],
    ], 'Image uploaded');
}

/* =========================================================================
   CREATE — upload the (mandatory) file + save the row
   ========================================================================= */
if ($action === 'create') {
    $internship_id = (int)($_POST['internship_id'] ?? 0);
    if ($internship_id <= 0) ps_error('internship_id is required');

    $title       = trim($_POST['title'] ?? '');
    $description = trim($_POST['description'] ?? '');

    /* The primary file is now OPTIONAL — resources & datasets live in the
       child items table. A legacy single file is still supported if sent. */
    $allowedTypes = ['pdf','image','doc','excel','ppt','video','zip','other'];
    $hasFile = !empty($_FILES['file']) && isset($_FILES['file']['error']) && $_FILES['file']['error'] === UPLOAD_ERR_OK;

    $file_url = ''; $file_key = ''; $file_name = null; $file_type = 'none';
    $file_size = 0; $mime_type = null;
    if ($hasFile) {
        $file_type = trim($_POST['file_type'] ?? 'other');
        if (!in_array($file_type, $allowedTypes, true)) $file_type = 'other';
        $up = ps_put_to_s3($_FILES['file'], "problem_statements/$internship_id", $buildS3, $bucketName, $awsRegion);
        $file_url = $up['url']; $file_key = $up['key']; $file_name = $up['name'];
        $file_size = $up['size']; $mime_type = $up['mime_type'];
    }

    $titleN = $title === '' ? null : $title;
    $descN  = $description === '' ? null : $description;
    $stmt = $conn->prepare(
        "INSERT INTO internship_problem_statements
            (internship_id, title, description, file_url, file_key, file_name,
             file_type, file_size, mime_type, created_by)
         VALUES (?,?,?,?,?,?,?,?,?,?)"
    );
    /* 10 params: i s s s s s s i s i */
    $stmt->bind_param(
        'isssssisii',
        $internship_id, $titleN, $descN, $file_url, $file_key, $file_name,
        $file_type, $file_size, $mime_type, $user_id
    );
    $stmt->execute();
    $id = $stmt->insert_id;
    $stmt->close();
    $conn->close();
    ps_ok(['id' => $id, 'file_url' => $file_url], 'Problem statement added');
}

/* =========================================================================
   ITEM_ADD — attach a resource/dataset item (file upload OR external link)
   ========================================================================= */
if ($action === 'item_add') {
    $statement_id = (int)($in['statement_id'] ?? 0);
    if ($statement_id <= 0) ps_error('statement_id is required');
    $category = ($in['category'] ?? 'resource') === 'dataset' ? 'dataset' : 'resource';
    $kind     = ($in['kind'] ?? 'file') === 'link' ? 'link' : 'file';
    $label    = trim($in['label'] ?? '');
    $labelN   = $label === '' ? null : $label;

    $mx = $conn->query("SELECT COALESCE(MAX(sort_order),0)+1 AS n FROM internship_problem_statement_items WHERE statement_id=$statement_id AND category='$category'")->fetch_assoc();
    $sort_order = (int)$mx['n'];

    if ($kind === 'link') {
        $url = trim($in['url'] ?? '');
        if ($url === '') ps_error('A link URL is required');
        $file_type = 'link';
        $stmt = $conn->prepare(
            "INSERT INTO internship_problem_statement_items
                (statement_id, category, kind, label, url, file_type, sort_order, created_by)
             VALUES (?,?,?,?,?,?,?,?)"
        );
        $stmt->bind_param('isssssii', $statement_id, $category, $kind, $labelN, $url, $file_type, $sort_order, $user_id);
        $stmt->execute();
        $id = $stmt->insert_id;
        $stmt->close();
        $conn->close();
        ps_ok(['id' => $id], 'Link added');
    } else {
        if (empty($_FILES['file'])) ps_error('A file upload is required');
        $up = ps_put_to_s3($_FILES['file'], "problem_statements/$statement_id", $buildS3, $bucketName, $awsRegion);
        $file_type = ps_file_type($up['name'], $up['mime_type']);
        $stmt = $conn->prepare(
            "INSERT INTO internship_problem_statement_items
                (statement_id, category, kind, label, file_url, file_key, file_name,
                 file_type, file_size, mime_type, sort_order, created_by)
             VALUES (?,?,?,?,?,?,?,?,?,?,?,?)"
        );
        /* 12 params: i s s s s s s s i s i i */
        $stmt->bind_param(
            'isssssssisii',
            $statement_id, $category, $kind, $labelN, $up['url'], $up['key'], $up['name'],
            $file_type, $up['size'], $up['mime_type'], $sort_order, $user_id
        );
        $stmt->execute();
        $id = $stmt->insert_id;
        $stmt->close();
        $conn->close();
        ps_ok(['id' => $id, 'file_url' => $up['url'], 'file_type' => $file_type], 'File added');
    }
}

/* =========================================================================
   ITEM_DELETE — soft-delete a resource/dataset item
   ========================================================================= */
if ($action === 'item_delete') {
    $id = (int)($in['id'] ?? 0);
    if ($id <= 0) ps_error('id is required');
    $stmt = $conn->prepare("UPDATE internship_problem_statement_items SET status='inactive' WHERE id=?");
    $stmt->bind_param('i', $id);
    $stmt->execute();
    $stmt->close();
    $conn->close();
    ps_ok(['id' => $id], 'Item removed');
}

/* =========================================================================
   UPDATE — edit title / description only
   ========================================================================= */
if ($action === 'update') {
    $id = (int)($in['id'] ?? 0);
    if ($id <= 0) ps_error('id is required');
    $title       = trim($in['title'] ?? '');
    $description = trim($in['description'] ?? '');
    $titleN = $title === '' ? null : $title;
    $descN  = $description === '' ? null : $description;
    $stmt = $conn->prepare("UPDATE internship_problem_statements SET title=?, description=? WHERE id=?");
    $stmt->bind_param('ssi', $titleN, $descN, $id);
    $stmt->execute();
    $stmt->close();
    $conn->close();
    ps_ok(['id' => $id], 'Problem statement updated');
}

/* =========================================================================
   DELETE — soft delete (keeps S3 object for audit, like notes.php)
   ========================================================================= */
if ($action === 'delete') {
    $id = (int)($in['id'] ?? 0);
    if ($id <= 0) ps_error('id is required');
    $stmt = $conn->prepare("UPDATE internship_problem_statements SET status='inactive' WHERE id=?");
    $stmt->bind_param('i', $id);
    $stmt->execute();
    $stmt->close();
    $conn->close();
    ps_ok(['id' => $id], 'Problem statement deleted');
}

ps_error('Unknown action');

<?php
/*
 * /api/campaigns/campaigns.php
 *
 * action=list            &page &per_page &status &search   → paginated list + per-status tab counts
 * action=get              &id                              → full campaign row
 * action=save      [&id]  &name &tags &... (see $fields)    → create/update (autosave from the wizard)
 * action=delete           &id
 * action=duplicate        &id
 * action=tags                                                → distinct tags used across all campaigns
 * action=domains                                              → distinct sending domains (campaigns + ESP defaults)
 * action=audience_count   &audience_type &segment_ids(json) &exclude_segment_ids(json) &domain_filter
 * action=upload_attachment &id &file (multipart)              → attach a file, max 5MB/file, 15MB/campaign
 * action=remove_attachment &id &stored_name
 * action=send_test        &id &emails (comma/newline separated)
 * action=send_now         &id
 * action=schedule         &id &scheduled_at
 * action=pause            &id   → suspend a draft/scheduled/running campaign
 * action=resume           &id   → un-suspend
 * action=requeue          &id   → retry failed recipients
 * action=report           &id &page &per_page               → stats + recent tracking events
 * action=conversions      &id &page &per_page &search [&export=1] → who converted on the campaign's goal
 * action=conversion_detail &id &user_id                     → one converted user: profile + raw goal-event rows
 */
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../middleware/auth.php';
require_once __DIR__ . '/lib/config.php';
require_once __DIR__ . '/lib/schema.php';
require_once __DIR__ . '/lib/AudienceResolver.php';
require_once __DIR__ . '/lib/SendWorker.php';
require_once __DIR__ . '/lib/ConversionTracker.php';
require_once __DIR__ . '/../lib/S3Uploader.php';

campaigns_ensure_schema();
attributes_ensure_schema();

$jwt = require_jwt();
require_permission('netcore_behaviour', $jwt);

function jin($k, $d = null) { $v = $_REQUEST[$k] ?? null; return ($v === null || $v === '') ? $d : $v; }

function validate_campaign_for_send(array $campaign): array {
    $blocking = [];
    if (empty($campaign['subject']))        $blocking[] = 'Subject is empty';
    if (empty($campaign['content_html']))   $blocking[] = 'No template selected';
    if (empty($campaign['sender_email']))   $blocking[] = 'Sender email is not set';
    if (empty($campaign['sending_domain'])) $blocking[] = 'Sending domain is not set';

    $cfg = [
        'audience_type'       => $campaign['audience_type'],
        'segment_ids'         => json_decode($campaign['segment_ids'] ?? '[]', true) ?: [],
        'exclude_segment_ids' => json_decode($campaign['exclude_segment_ids'] ?? '[]', true) ?: [],
        'list_ids'            => json_decode($campaign['list_ids'] ?? '[]', true) ?: [],
        'domain_filter'       => $campaign['domain_filter'],
    ];
    $count = resolve_audience_count($cfg);
    if ($count === 0) $blocking[] = 'Audience has 0 reachable contacts';
    return ['blocking' => $blocking, 'count' => $count];
}

$action = jin('action', '');

if ($action === 'list') {
    $page    = max(1, (int)jin('page', 1));
    $perPage = max(1, min(100, (int)jin('per_page', 10)));
    $status  = jin('status', 'all');
    $search  = trim((string)jin('search', ''));
    $offset  = ($page - 1) * $perPage;

    $where = [];
    if ($status !== 'all' && $status !== '') $where[] = "status='" . $conn->real_escape_string($status) . "'";
    if ($search !== '') $where[] = "name LIKE '%" . $conn->real_escape_string($search) . "%'";
    $whereSql = $where ? 'WHERE ' . implode(' AND ', $where) : '';

    $tr = $conn->query("SELECT COUNT(*) AS c FROM email_campaigns $whereSql");
    $total = $tr ? (int)$tr->fetch_assoc()['c'] : 0;

    $r = $conn->query("SELECT id, name, tags, status, campaign_type, esp_transport, total_recipients, sent_count,
                               delivered_count, open_count, unique_open_count, click_count, unique_click_count,
                               bounce_count, hard_bounce_count, soft_bounce_count, unsubscribe_count, spam_count,
                               goal_event_name, conversion_count, schedule_type, scheduled_at, started_at, completed_at,
                               created_at, updated_at
                        FROM email_campaigns $whereSql
                        ORDER BY id DESC LIMIT $perPage OFFSET $offset");
    $rows = [];
    while ($r && $row = $r->fetch_assoc()) $rows[] = $row;

    $counts = ['all' => 0, 'draft' => 0, 'scheduled' => 0, 'running' => 0, 'sent' => 0, 'suspended' => 0, 'failed' => 0];
    $cr = $conn->query("SELECT status, COUNT(*) AS c FROM email_campaigns GROUP BY status");
    while ($cr && $row = $cr->fetch_assoc()) { $counts[$row['status']] = (int)$row['c']; $counts['all'] += (int)$row['c']; }

    api_success([
        'campaigns' => $rows, 'total' => $total, 'page' => $page, 'per_page' => $perPage,
        'pages' => $total > 0 ? (int)ceil($total / $perPage) : 1, 'counts' => $counts,
    ]);
}

if ($action === 'get') {
    $id = (int)jin('id', 0);
    $r = $conn->query("SELECT * FROM email_campaigns WHERE id=$id LIMIT 1");
    $row = $r ? $r->fetch_assoc() : null;
    if (!$row) api_error('Not found', 404);
    $row['segment_ids'] = json_decode($row['segment_ids'] ?? '[]', true) ?: [];
    $row['exclude_segment_ids'] = json_decode($row['exclude_segment_ids'] ?? '[]', true) ?: [];
    $row['list_ids'] = json_decode($row['list_ids'] ?? '[]', true) ?: [];
    $row['attachments'] = json_decode($row['attachments'] ?? '[]', true) ?: [];
    // A draft hasn't committed to a provider yet — send_now/schedule re-stamp esp_transport
    // from the Active sender at that moment. Report the provider it WOULD go out through, so
    // the wizard's "Sending via" line doesn't show a stale value after the setting is changed.
    if (($row['status'] ?? '') === 'draft') {
        $row['esp_transport'] = TransportFactory::activeProvider();
    }
    api_success(['campaign' => $row]);
}

if ($action === 'save') {
    $id   = (int)jin('id', 0);
    $name = trim((string)jin('name', ''));
    if ($id === 0 && $name === '') api_error('Campaign name required');

    $fields = [
        'name' => 's', 'tags' => 's',
        'ga_source' => 's', 'ga_medium' => 's', 'ga_campaign' => 's', 'ga_content' => 's', 'ga_term' => 's',
        'goal_event_name' => 's', 'goal_window_days' => 'i', 'goal_revenue_param' => 's',
        'audience_type' => 's', 'domain_filter' => 's', 'reachable_count' => 'i',
        'sender_name' => 's', 'sender_email' => 's', 'sending_domain' => 's',
        'subject' => 's', 'preheader' => 's', 'reply_to' => 's',
        'esp_transport' => 's', 'exam_cit_version' => 's',
    ];
    $set = [];
    foreach ($fields as $f => $type) {
        $v = jin($f, null);
        if ($v === null) continue;
        $set[] = $type === 'i' ? "$f=" . (int)$v : "$f='" . $conn->real_escape_string((string)$v) . "'";
    }
    if (jin('segment_ids', null) !== null) {
        $arr = json_decode(jin('segment_ids'), true) ?: [];
        $set[] = "segment_ids='" . $conn->real_escape_string(json_encode(array_values(array_map('intval', $arr)))) . "'";
    }
    if (jin('exclude_segment_ids', null) !== null) {
        $arr = json_decode(jin('exclude_segment_ids'), true) ?: [];
        $set[] = "exclude_segment_ids='" . $conn->real_escape_string(json_encode(array_values(array_map('intval', $arr)))) . "'";
    }
    if (jin('list_ids', null) !== null) {
        $arr = json_decode(jin('list_ids'), true) ?: [];
        $set[] = "list_ids='" . $conn->real_escape_string(json_encode(array_values(array_map('intval', $arr)))) . "'";
    }

    // Snapshot the chosen template's HTML into content_html — a later edit to the
    // template won't retroactively change an already-scheduled/sent campaign.
    $templateId = jin('template_id', null);
    if ($templateId !== null) {
        $tid = (int)$templateId;
        if ($tid > 0) {
            $tRes = $conn->query("SELECT body_html FROM campaign_templates WHERE id=$tid LIMIT 1");
            $tRow = $tRes ? $tRes->fetch_assoc() : null;
            if ($tRow) {
                $set[] = "template_id=$tid";
                $set[] = "content_html='" . $conn->real_escape_string($tRow['body_html']) . "'";
            }
        }
    }

    // reachable_count is now just a plain stored field (see $fields above), NOT recomputed
    // here — the Audience step already calculates it live (action=audience_count, debounced)
    // as the user picks segments, and re-running that same heavy query again on every single
    // "Next Step" click (from every step, not just Audience) was the actual cause of multi-
    // second saves. The authoritative recheck still happens right before a real send, in
    // validate_campaign_for_send() (see send_now/schedule below) — so accuracy at the moment
    // that matters is unaffected.

    if ($id > 0) {
        if ($set) $conn->query("UPDATE email_campaigns SET " . implode(', ', $set) . " WHERE id=$id");
    } else {
        $set[] = "created_by=" . (int)($jwt['user_id'] ?? 0);
        // A brand-new campaign always sends through whichever provider is flagged "Active
        // sender" in Settings — that radio is the ONLY place the transport is chosen (there
        // is no per-campaign picker in the wizard), so the client's esp_transport is treated
        // as a display hint, not authority. Without this override the wizard's hardcoded
        // 'sendgrid' default would win and switching the Active sender to Elastic Email would
        // change nothing. Existing campaigns keep their stored transport (UPDATE branch above).
        $set = array_values(array_filter($set, fn($s) => strpos($s, 'esp_transport=') !== 0));
        $set[] = "esp_transport='" . $conn->real_escape_string(TransportFactory::activeProvider()) . "'";
        /* Stamped from PHP, not left to the column's DEFAULT CURRENT_TIMESTAMP: MySQL's clock is
           a different clock (see config/database.php). The unified campaigns list files a draft
           under created_at and a sent campaign under started_at/completed_at, both PHP-written —
           mixing the two put a brand-new draft hours in the past, where "Newest first" hid it. */
        $set[] = "created_at='" . $conn->real_escape_string(date('Y-m-d H:i:s')) . "'";
        $conn->query("INSERT INTO email_campaigns SET " . implode(', ', $set));
        $id = $conn->insert_id;
    }
    // esp_transport is echoed back because the INSERT branch above may have overridden
    // whatever the wizard sent with the Active sender from Settings — this is how the
    // Schedule step's "Sending via" line shows the provider that will really be used.
    $r = $conn->query("SELECT reachable_count, status, esp_transport FROM email_campaigns WHERE id=$id LIMIT 1");
    $row = $r ? $r->fetch_assoc() : ['reachable_count' => 0, 'status' => 'draft', 'esp_transport' => 'sendgrid'];
    api_success(['id' => $id, 'reachable_count' => (int)$row['reachable_count'], 'status' => $row['status'], 'esp_transport' => $row['esp_transport']]);
}

if ($action === 'delete') {
    $id = (int)jin('id', 0);
    if (!$id) api_error('id required');
    $conn->query("DELETE FROM email_campaign_events WHERE campaign_id=$id");
    $conn->query("DELETE FROM email_campaign_recipients WHERE campaign_id=$id");
    $conn->query("DELETE FROM email_campaigns WHERE id=$id");
    api_success([]);
}

if ($action === 'duplicate') {
    $id = (int)jin('id', 0);
    $r = $conn->query("SELECT * FROM email_campaigns WHERE id=$id LIMIT 1");
    $row = $r ? $r->fetch_assoc() : null;
    if (!$row) api_error('Not found', 404);

    // list_ids is copied too. Leaving it out gave the copy of a list-addressed campaign an empty
    // audience, which then resolved to zero recipients with nothing on screen explaining why.
    $cols = ['name', 'tags', 'campaign_type', 'ga_source', 'ga_medium', 'ga_campaign', 'ga_content', 'ga_term',
             'goal_event_name', 'goal_window_days', 'goal_revenue_param', 'audience_type', 'segment_ids',
             'exclude_segment_ids', 'list_ids', 'domain_filter', 'sender_name', 'sender_email', 'sending_domain', 'subject',
             'preheader', 'reply_to', 'template_id', 'content_html', 'esp_transport'];
    $vals = [];
    foreach ($cols as $c) {
        if ($c === 'name') { $vals[] = "'" . $conn->real_escape_string($row['name'] . ' (Copy)') . "'"; continue; }
        $v = $row[$c];
        $vals[] = $v === null ? 'NULL' : "'" . $conn->real_escape_string($v) . "'";
    }

    /*
     * created_at is written HERE rather than left to the column's DEFAULT CURRENT_TIMESTAMP.
     *
     * MySQL's clock is not PHP's: this host runs MySQL in one timezone and PHP in Asia/Kolkata
     * (see config/database.php), and CURRENT_TIMESTAMP uses MySQL's. The unified campaigns list
     * files a draft under created_at but a sent campaign under started_at/completed_at, and those
     * ARE written by PHP — so a brand-new copy was stamped hours in the PAST relative to every
     * row around it. "Newest first" then buried it below everything sent since, and it looked for
     * all the world like the duplicate had never been created. One clock, PHP's, for every date
     * this screen sorts on.
     */
    $now  = date('Y-m-d H:i:s');
    $nowQ = "'" . $conn->real_escape_string($now) . "'";
    $cols[] = 'created_at'; $vals[] = $nowQ;
    $cols[] = 'updated_at'; $vals[] = $nowQ;

    /*
     * The INSERT used to go completely unchecked: api_success() reported a copy that did not
     * exist, the list came back unchanged, and nothing anywhere said why. try/catch as well as
     * a return check because PHP 8.1 made mysqli throw on error rather than return false — one
     * of the two fires depending on how this host is configured, and both must end up as a
     * message the admin can read.
     */
    $err = '';
    try {
        $ok = $conn->query("INSERT INTO email_campaigns (" . implode(',', $cols) . ", created_by)
                            VALUES (" . implode(',', $vals) . ", " . (int)($jwt['user_id'] ?? 0) . ")");
    } catch (Throwable $e) { $ok = false; $err = $e->getMessage(); }
    if (!$ok || !$conn->insert_id) api_error('Could not duplicate: ' . ($err ?: ($conn->error ?: 'insert failed')), 500);

    // The new id, name and date go back so the list can show the copy immediately instead of
    // waiting to find it in the next fetch.
    api_success(['id' => (int)$conn->insert_id, 'name' => $row['name'] . ' (Copy)', 'created_at' => $now]);
}

if ($action === 'tags') {
    // Distinct tags used across every existing campaign — powers the tag picker's
    // "existing tags" list in the Setup step.
    //
    // NOTE: tags are collected into a plain list, NOT used as array keys to dedupe —
    // PHP silently casts any array key that looks like a whole number (e.g. "171") to
    // a real integer, which would then serialize as a bare JSON number instead of a
    // string and break the frontend's tag.toLowerCase() calls.
    $r = $conn->query("SELECT tags FROM email_campaigns WHERE tags IS NOT NULL AND tags <> ''");
    $all = [];
    while ($r && $row = $r->fetch_assoc()) {
        foreach (explode(',', $row['tags']) as $t) {
            $t = trim((string)$t);
            if ($t !== '') $all[] = $t;
        }
    }
    $tags = array_values(array_unique($all));
    sort($tags, SORT_NATURAL | SORT_FLAG_CASE);
    $tags = array_map('strval', $tags); // belt-and-suspenders: guarantee every entry is a JSON string
    api_success(['tags' => $tags]);
}

if ($action === 'domains') {
    // Distinct sending domains used across every existing campaign, plus every ESP's
    // configured default domain — powers the Content step's domain picker.
    $set = [];
    $r = $conn->query("SELECT DISTINCT sending_domain FROM email_campaigns WHERE sending_domain IS NOT NULL AND sending_domain <> ''");
    while ($r && $row = $r->fetch_assoc()) $set[] = (string)$row['sending_domain'];
    $r2 = $conn->query("SELECT DISTINCT default_sending_domain FROM email_esp_settings WHERE default_sending_domain IS NOT NULL AND default_sending_domain <> ''");
    while ($r2 && $row = $r2->fetch_assoc()) $set[] = (string)$row['default_sending_domain'];
    $domains = array_values(array_unique($set));
    sort($domains, SORT_NATURAL | SORT_FLAG_CASE);
    api_success(['domains' => $domains]);
}

if ($action === 'exam_versions') {
    // Powers the Content step's "Exam (for exam merge tags)" picker — lets an admin tie a
    // campaign to one specific exam, since exam results (score/rank/etc.) are per-exam, while
    // a campaign's audience (segment/contacts) is generally not. See lib/MergeTags.php's
    // resolve_exam_data() for how a recipient's result gets looked up at actual send time.
    $r = $conn->query("SELECT id, cit_name FROM cit_version ORDER BY id DESC");
    $rows = [];
    while ($r && $row = $r->fetch_assoc()) $rows[] = $row;
    api_success(['versions' => $rows]);
}

if ($action === 'audience_count') {
    $cfg = [
        'audience_type'       => jin('audience_type', 'segments'),
        'segment_ids'         => json_decode(jin('segment_ids', '[]'), true) ?: [],
        'exclude_segment_ids' => json_decode(jin('exclude_segment_ids', '[]'), true) ?: [],
        'list_ids'            => json_decode(jin('list_ids', '[]'), true) ?: [],
        'domain_filter'       => jin('domain_filter', ''),
    ];
    api_success(['count' => resolve_audience_count($cfg)]);
}

if ($action === 'upload_attachment') {
    $id = (int)jin('id', 0);
    if (!$id) api_error('Save the campaign before adding attachments');
    $r = $conn->query("SELECT attachments FROM email_campaigns WHERE id=$id LIMIT 1");
    $row = $r ? $r->fetch_assoc() : null;
    if (!$row) api_error('Not found', 404);

    if (empty($_FILES['file']) || $_FILES['file']['error'] !== UPLOAD_ERR_OK) api_error('Choose a file to attach');
    $file = $_FILES['file'];

    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    if (!in_array($ext, CAMPAIGN_ATTACHMENT_ALLOWED_EXT, true)) {
        api_error('File type not allowed (.' . $ext . ') — allowed: ' . implode(', ', CAMPAIGN_ATTACHMENT_ALLOWED_EXT));
    }
    if ($file['size'] > CAMPAIGN_ATTACHMENT_MAX_FILE_BYTES) {
        api_error('File too large — max ' . (CAMPAIGN_ATTACHMENT_MAX_FILE_BYTES / 1024 / 1024) . 'MB per file');
    }

    $existing = json_decode($row['attachments'] ?? '[]', true) ?: [];
    $existingTotal = array_sum(array_map(fn($a) => (int)($a['size'] ?? 0), $existing));
    if ($existingTotal + $file['size'] > CAMPAIGN_ATTACHMENT_MAX_TOTAL_BYTES) {
        api_error('Total attachments would exceed ' . (CAMPAIGN_ATTACHMENT_MAX_TOTAL_BYTES / 1024 / 1024) . 'MB for this campaign');
    }

    $mimeGuess = [
        'pdf' => 'application/pdf', 'doc' => 'application/msword',
        'docx' => 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        'xls' => 'application/vnd.ms-excel', 'xlsx' => 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        'jpg' => 'image/jpeg', 'jpeg' => 'image/jpeg', 'png' => 'image/png', 'gif' => 'image/gif',
        'txt' => 'text/plain', 'csv' => 'text/csv', 'zip' => 'application/zip',
    ];
    $mime = $mimeGuess[$ext] ?? 'application/octet-stream';

    // Small (<=5MB) and not chunk-processed — uploaded straight to S3, never touching local
    // disk permanently, unlike the CSV import pipeline which still needs local byte-offset
    // resumable processing (see ContactImportWorker.php).
    $safeName = preg_replace('/[^a-zA-Z0-9_.\-]/', '_', basename($file['name']));
    $key = 'campaign_attachments/' . $id . '/' . bin2hex(random_bytes(8)) . '_' . $safeName;
    $s3Url = s3_upload_file($file['tmp_name'], $key, $mime);
    if (!$s3Url) api_error('Could not upload attachment to storage');

    $existing[] = [
        'filename' => $safeName, 's3_key' => $key, 's3_url' => $s3Url, 'size' => (int)$file['size'], 'mime' => $mime,
    ];
    $conn->query("UPDATE email_campaigns SET attachments='" . $conn->real_escape_string(json_encode($existing)) . "' WHERE id=$id");
    api_success(['attachments' => $existing]);
}

if ($action === 'remove_attachment') {
    $id = (int)jin('id', 0);
    $s3Key = (string)jin('stored_name', ''); // param name kept for frontend compatibility; now carries s3_key
    if (!$id || !$s3Key) api_error('id and stored_name required');
    $r = $conn->query("SELECT attachments FROM email_campaigns WHERE id=$id LIMIT 1");
    $row = $r ? $r->fetch_assoc() : null;
    if (!$row) api_error('Not found', 404);

    $existing = json_decode($row['attachments'] ?? '[]', true) ?: [];
    $remaining = array_values(array_filter($existing, fn($a) => ($a['s3_key'] ?? '') !== $s3Key));
    s3_delete_key($s3Key);

    $conn->query("UPDATE email_campaigns SET attachments='" . $conn->real_escape_string(json_encode($remaining)) . "' WHERE id=$id");
    api_success(['attachments' => $remaining]);
}

if ($action === 'send_test') {
    $id = (int)jin('id', 0);
    $r = $conn->query("SELECT * FROM email_campaigns WHERE id=$id LIMIT 1");
    $campaign = $r ? $r->fetch_assoc() : null;
    if (!$campaign) api_error('Save the campaign before sending a test', 404);
    if (!$campaign['subject'] || !$campaign['content_html']) api_error('Add a subject and select a template first');

    $emailsRaw = (string)jin('emails', '');
    $emails = array_values(array_filter(array_map('trim', preg_split('/[,;\n]+/', $emailsRaw))));
    if (!$emails) api_error('Enter at least one test email address');

    $transport = TransportFactory::forProvider($campaign['esp_transport']);
    $attachments = load_campaign_attachments($campaign); // loaded once, reused for every test address
    $results = [];
    foreach ($emails as $email) {
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $results[] = ['email' => $email, 'ok' => false, 'error' => 'Invalid email address'];
            continue;
        }
        $rid = bin2hex(random_bytes(16));
        $emailE = $conn->real_escape_string($email);

        // If the test address happens to belong to a real registered student, use their
        // real user_id/name — this is what makes mapped Attributes (and exam merge tags)
        // resolve correctly on a test send instead of always looking like an anonymous
        // 'Test User' with nothing to look up.
        $uRes = $conn->query("SELECT user_id, fname, lname FROM users WHERE email='$emailE' LIMIT 1");
        $uRow = $uRes ? $uRes->fetch_assoc() : null;
        $testUserId = $uRow['user_id'] ?? null;
        $testFname = $uRow['fname'] ?? 'Test';
        $testLname = $uRow['lname'] ?? 'User';
        $testFnameE = $conn->real_escape_string($testFname);
        $testLnameE = $conn->real_escape_string($testLname);

        $conn->query("INSERT INTO email_campaign_recipients (campaign_id, user_id, email, first_name, last_name, phone, is_test, status, rid)
                      VALUES ($id, " . ($testUserId ? (int)$testUserId : 'NULL') . ", '$emailE', '$testFnameE', '$testLnameE', '', 1, 'pending', '$rid')");
        $recId = $conn->insert_id;

        if (!$transport) {
            $results[] = ['email' => $email, 'ok' => false, 'error' => 'ESP not configured — set an API key in Settings'];
            $conn->query("UPDATE email_campaign_recipients SET status='failed', error_message='ESP not configured' WHERE id=$recId");
            continue;
        }

        $recipient = ['email' => $email, 'user_id' => $testUserId, 'first_name' => $testFname, 'last_name' => $testLname, 'phone' => ''];
        if (!empty($campaign['exam_cit_version']) && $testUserId) {
            $examData = resolve_exam_data((int)$testUserId, $campaign['exam_cit_version']);
            if ($examData) $recipient = array_merge($recipient, $examData);
        }
        $attributes = load_all_attributes();
        $attrTokens = $attributes ? (resolve_attribute_values_batch($attributes, [$recipient])[strtolower($email)] ?? []) : [];

        $subject    = substitute_merge_tags((string)$campaign['subject'], $recipient, $attrTokens);
        $senderName = substitute_merge_tags((string)$campaign['sender_name'], $recipient, $attrTokens);
        $preheader  = substitute_merge_tags((string)$campaign['preheader'], $recipient, $attrTokens);
        $html       = substitute_merge_tags((string)$campaign['content_html'], $recipient, $attrTokens);
        $html       = inject_preheader($html, $preheader);
        $banner     = '<div style="background:#fef3c7;color:#92400e;padding:8px 14px;font:600 12px sans-serif;border-radius:6px;margin-bottom:12px;">TEST EMAIL — sent from the campaign builder, not a real recipient</div>';
        $html       = $banner . $html;
        $html       = inject_tracking($html, $rid);

        $res = $transport->sendEmail($email, '[TEST] ' . $subject, $html,
            $senderName !== '' ? $senderName : (string)$campaign['sender_name'],
            (string)$campaign['sender_email'], $campaign['reply_to'] ?: null, $rid, $attachments);

        if ($res['ok']) {
            $conn->query("UPDATE email_campaign_recipients SET status='sent', sent_at=NOW() WHERE id=$recId");
        } else {
            $errE = $conn->real_escape_string(substr((string)($res['error'] ?? ''), 0, 480));
            $conn->query("UPDATE email_campaign_recipients SET status='failed', error_message='$errE' WHERE id=$recId");
        }
        $results[] = ['email' => $email, 'ok' => $res['ok'], 'error' => $res['error'] ?? null];
    }
    api_success(['results' => $results]);
}

if ($action === 'send_now') {
    $id = (int)jin('id', 0);
    $r = $conn->query("SELECT * FROM email_campaigns WHERE id=$id LIMIT 1");
    $campaign = $r ? $r->fetch_assoc() : null;
    if (!$campaign) api_error('Not found', 404);

    $checklist = validate_campaign_for_send($campaign);
    if ($checklist['blocking']) api_error('Cannot send: ' . implode('; ', $checklist['blocking']));

    // Recipients are NOT materialized here — that (a full 20k-40k row resolve+insert) now
    // happens inside the worker's own background run, which has no web-request execution-time
    // limit, instead of blocking this click on modest shared hosting. $checklist['count'] is a
    // cheap COUNT(*) preview, not the real queued rows yet.
    // esp_transport is re-stamped from the Active sender at the moment of sending, not left
    // at whatever was active when the draft was first created. A draft written last week and
    // sent today must go through the provider selected in Settings NOW — that radio is the
    // only place the sender is chosen, so anything else makes the setting look ignored.
    $transportE = $conn->real_escape_string(TransportFactory::activeProvider());
    $conn->query("UPDATE email_campaigns SET status='running', schedule_type='now', scheduled_at=NULL, started_at=NOW(), total_recipients=0, materialized_at=NULL, esp_transport='$transportE' WHERE id=$id");
    trigger_worker_async($id);
    api_success(['queued' => $checklist['count']]);
}

if ($action === 'schedule') {
    $id = (int)jin('id', 0);
    $at = trim((string)jin('scheduled_at', ''));
    if (!$at) api_error('Pick a date & time');
    $ts = strtotime($at);
    if (!$ts || $ts <= time()) api_error('Scheduled time must be in the future');

    $r = $conn->query("SELECT * FROM email_campaigns WHERE id=$id LIMIT 1");
    $campaign = $r ? $r->fetch_assoc() : null;
    if (!$campaign) api_error('Not found', 404);

    $checklist = validate_campaign_for_send($campaign);
    if ($checklist['blocking']) api_error('Cannot schedule: ' . implode('; ', $checklist['blocking']));

    // Same reasoning as send_now: the actual audience resolve+insert happens in the worker,
    // right after scheduled_at arrives and the campaign flips to 'running' — not here.
    $atE = $conn->real_escape_string(date('Y-m-d H:i:s', $ts));
    // Same re-stamp as send_now — the provider is resolved when the send is committed.
    $transportE = $conn->real_escape_string(TransportFactory::activeProvider());
    $conn->query("UPDATE email_campaigns SET status='scheduled', schedule_type='later', scheduled_at='$atE', total_recipients=0, materialized_at=NULL, esp_transport='$transportE' WHERE id=$id");
    api_success(['queued' => $checklist['count'], 'scheduled_at' => $atE]);
}

if ($action === 'pause') {
    $id = (int)jin('id', 0);
    $r = $conn->query("SELECT status FROM email_campaigns WHERE id=$id LIMIT 1");
    $row = $r ? $r->fetch_assoc() : null;
    if (!$row) api_error('Not found', 404);
    if (!in_array($row['status'], ['draft', 'scheduled', 'running'], true)) api_error('Only draft, scheduled or running campaigns can be suspended');
    $conn->query("UPDATE email_campaigns SET status='suspended' WHERE id=$id");
    api_success([]);
}

if ($action === 'resume') {
    $id = (int)jin('id', 0);
    $r = $conn->query("SELECT * FROM email_campaigns WHERE id=$id LIMIT 1");
    $campaign = $r ? $r->fetch_assoc() : null;
    if (!$campaign) api_error('Not found', 404);
    if ($campaign['status'] !== 'suspended') api_error('Only suspended campaigns can be resumed');

    if ($campaign['schedule_type'] === 'later' && $campaign['scheduled_at'] && strtotime($campaign['scheduled_at']) > time()) {
        $conn->query("UPDATE email_campaigns SET status='scheduled' WHERE id=$id");
    } else {
        $conn->query("UPDATE email_campaigns SET status='running' WHERE id=$id");
        trigger_worker_async($id);
    }
    api_success([]);
}

if ($action === 'requeue') {
    $id = (int)jin('id', 0);
    $r = $conn->query("SELECT total_recipients FROM email_campaigns WHERE id=$id LIMIT 1");
    $row = $r ? $r->fetch_assoc() : null;
    if (!$row) api_error('Not found', 404);

    if ((int)$row['total_recipients'] === 0) {
        // This campaign never actually had any recipients (its audience resolved to 0 people)
        // — clearing materialized_at forces the worker to re-resolve the audience from scratch
        // on its next tick, instead of re-flagging "running" over an audience check that's
        // already been done and will never change on its own (this was the actual "stuck at
        // Running forever" bug — Requeue used to just relabel the status without re-checking
        // anything). If you've since fixed the segment selection, this pass will pick it up.
        $conn->query("UPDATE email_campaigns SET status='running', materialized_at=NULL WHERE id=$id");
    } else {
        // Real per-recipient send failures exist — audience was already correctly resolved,
        // so just retry those specific people instead of re-resolving anything.
        $conn->query("UPDATE email_campaign_recipients SET status='pending', attempts=0, error_message=NULL WHERE campaign_id=$id AND status='failed'");
        $conn->query("UPDATE email_campaigns SET status='running' WHERE id=$id AND status IN ('sent','failed','suspended')");
    }
    trigger_worker_async($id);
    api_success([]);
}

if ($action === 'report') {
    $id = (int)jin('id', 0);
    $r = $conn->query("SELECT * FROM email_campaigns WHERE id=$id LIMIT 1");
    $campaign = $r ? $r->fetch_assoc() : null;
    if (!$campaign) api_error('Not found', 404);

    $statusCounts = ['pending' => 0, 'processing' => 0, 'sent' => 0, 'failed' => 0, 'bounced' => 0];
    $sc = $conn->query("SELECT status, COUNT(*) AS c FROM email_campaign_recipients WHERE campaign_id=$id AND is_test=0 GROUP BY status");
    while ($sc && $row = $sc->fetch_assoc()) $statusCounts[$row['status']] = (int)$row['c'];

    $page = max(1, (int)jin('page', 1));
    $perPage = max(1, min(100, (int)jin('per_page', 25)));
    $offset = ($page - 1) * $perPage;
    // 'open_bot'/'click_bot' rows are machine fetches (Apple Mail prefetch, security
    // scanners, duplicate re-renders — see lib/BotDetector.php). They are kept in the table
    // so the filtering stays auditable, but they'd drown the human activity they were
    // filtered out of, so the feed shows real engagement only; their volume is reported
    // through the bot_open_count / bot_click_count tiles instead. Test-send recipients are
    // excluded for the same reason they no longer move the counters.
    $evWhere = "e.campaign_id=$id AND r.is_test=0 AND e.event_type NOT IN ('open_bot','click_bot')";
    $evR = $conn->query("SELECT e.event_type, e.url, e.created_at, r.email
                          FROM email_campaign_events e JOIN email_campaign_recipients r ON r.id = e.recipient_id
                          WHERE $evWhere ORDER BY e.id DESC LIMIT $perPage OFFSET $offset");
    $events = [];
    while ($evR && $row = $evR->fetch_assoc()) $events[] = $row;
    $evTotalR = $conn->query("SELECT COUNT(*) AS c
                                FROM email_campaign_events e JOIN email_campaign_recipients r ON r.id = e.recipient_id
                               WHERE $evWhere");
    $evTotal = $evTotalR ? (int)$evTotalR->fetch_assoc()['c'] : 0;

    // The raw error text from the ESP (e.g. SendGrid's actual rejection message) is already
    // captured per recipient when a send fails — this just surfaces it, capped at the 50 most
    // recent failures, so "what is SendGrid actually saying" is visible without needing to
    // query the database by hand.
    $failedR = $conn->query("SELECT email, attempts, error_message, sent_at
                              FROM email_campaign_recipients
                              WHERE campaign_id=$id AND status='failed' AND is_test=0
                              ORDER BY id DESC LIMIT 50");
    $failedRecipients = [];
    while ($failedR && $row = $failedR->fetch_assoc()) $failedRecipients[] = $row;

    api_success([
        'campaign' => $campaign, 'recipient_status_counts' => $statusCounts,
        'events' => $events, 'events_total' => $evTotal, 'page' => $page, 'per_page' => $perPage,
        'pages' => $evTotal > 0 ? (int)ceil($evTotal / $perPage) : 1,
        'failed_recipients' => $failedRecipients,
    ]);
}

if ($action === 'device_breakdown') {
    $id = (int)jin('id', 0);
    $r = $conn->query("SELECT COALESCE(device_type,'unknown') AS device_type, COUNT(DISTINCT recipient_id) AS c
                        FROM email_campaign_events
                        WHERE campaign_id=$id AND event_type='click'
                        GROUP BY COALESCE(device_type,'unknown')");
    $out = ['mobile' => 0, 'tablet' => 0, 'desktop' => 0, 'unknown' => 0];
    while ($r && $row = $r->fetch_assoc()) $out[$row['device_type']] = (int)$row['c'];
    api_success(['devices' => $out]);
}

if ($action === 'bounced_recipients') {
    $id = (int)jin('id', 0);
    $page = max(1, (int)jin('page', 1));
    $perPage = max(1, min(100, (int)jin('per_page', 25)));
    $offset = ($page - 1) * $perPage;

    $r = $conn->query("SELECT email, bounce_type, bounced_at
                        FROM email_campaign_recipients
                        WHERE campaign_id=$id AND status='bounced' AND is_test=0
                        ORDER BY bounced_at DESC LIMIT $perPage OFFSET $offset");
    $rows = [];
    while ($r && $row = $r->fetch_assoc()) $rows[] = $row;
    $totalR = $conn->query("SELECT COUNT(*) AS c FROM email_campaign_recipients WHERE campaign_id=$id AND status='bounced' AND is_test=0");
    $total = $totalR ? (int)$totalR->fetch_assoc()['c'] : 0;

    api_success([
        'recipients' => $rows, 'total' => $total, 'page' => $page, 'per_page' => $perPage,
        'pages' => $total > 0 ? (int)ceil($total / $perPage) : 1,
    ]);
}

/*
 * Who actually converted — the named list behind the Conversions tile.
 * &export=1 drops pagination (capped) so the report page can build a CSV of
 * every converted user, not just the page on screen.
 */
if ($action === 'conversions') {
    $id = (int)jin('id', 0);
    $r = $conn->query("SELECT * FROM email_campaigns WHERE id=$id LIMIT 1");
    $campaign = $r ? $r->fetch_assoc() : null;
    if (!$campaign) api_error('Not found', 404);

    $search = trim((string)jin('search', ''));
    $q = conversion_list_sql($campaign, $search);
    if (!$q) {
        api_success([
            'goal_event_name' => $campaign['goal_event_name'] ?? '',
            'rows' => [], 'total' => 0, 'page' => 1, 'per_page' => 20, 'pages' => 1,
        ]);
    }

    $totalR = $conn->query($q['count']);
    $total  = $totalR ? (int)$totalR->fetch_assoc()['c'] : 0;

    $export = (int)jin('export', 0) === 1;
    if ($export) {
        $limitSql = ' LIMIT 50000';
        $page = 1; $perPage = $total;
    } else {
        $page    = max(1, (int)jin('page', 1));
        $perPage = max(1, min(100, (int)jin('per_page', 20)));
        $limitSql = " LIMIT $perPage OFFSET " . (($page - 1) * $perPage);
    }

    $rowsR = $conn->query($q['select'] . ' ' . $q['from'] . $q['group'] . $q['order'] . $limitSql);
    $rows = [];
    while ($rowsR && $row = $rowsR->fetch_assoc()) $rows[] = $row;

    api_success([
        'goal_event_name'  => $campaign['goal_event_name'],
        'goal_window_days' => (int)($campaign['goal_window_days'] ?: 2),
        'attribution_mode' => $q['mode'],
        'campaign_name'    => $campaign['name'],
        'rows'  => $rows, 'total' => $total, 'page' => $page,
        'per_page' => $export ? $total : $perPage,
        'pages' => (!$export && $total > 0) ? (int)ceil($total / $perPage) : 1,
    ]);
}

/* One converted user in full — profile plus the raw goal-event rows. */
if ($action === 'conversion_detail') {
    $id     = (int)jin('id', 0);
    $userId = (int)jin('user_id', 0);
    $r = $conn->query("SELECT * FROM email_campaigns WHERE id=$id LIMIT 1");
    $campaign = $r ? $r->fetch_assoc() : null;
    if (!$campaign) api_error('Not found', 404);
    if ($userId <= 0) api_error('user_id is required');

    $uR = $conn->query("SELECT * FROM users WHERE user_id=$userId LIMIT 1");
    $user = $uR ? $uR->fetch_assoc() : null;
    if ($user) $user = conversion_strip_secrets($user);

    $recR = $conn->query("SELECT email, status, sent_at, first_clicked_at, opened_at, open_count, click_count
                            FROM email_campaign_recipients
                           WHERE campaign_id=$id AND user_id=$userId AND is_test=0
                           ORDER BY id DESC LIMIT 1");
    $recipient = $recR ? $recR->fetch_assoc() : null;

    // medium='email' for the same reason as in ConversionTracker: campaign_attributions is shared
    // with the WhatsApp channel, and a WhatsApp campaign can hold the same numeric id.
    $attrR = $conn->query("SELECT medium, clicked_at, attributed_at
                             FROM campaign_attributions
                            WHERE campaign_id=$id AND user_id=$userId AND medium='email'
                              AND event_key='" . $conn->real_escape_string($campaign['goal_event_name']) . "'
                            LIMIT 1");
    $attribution = $attrR ? $attrR->fetch_assoc() : null;

    // Scope the raw event rows to the window this campaign earned — otherwise a
    // user who converted for two campaigns shows both campaigns' events here.
    [$evFrom, $evTo] = conversion_event_window($campaign, $attribution, $recipient);

    api_success([
        'user'            => $user,
        'recipient'       => $recipient,
        'attribution'     => $attribution,
        'goal_event_name' => $campaign['goal_event_name'],
        'events'          => conversion_user_events((string)$campaign['goal_event_name'], $userId, $evFrom, $evTo),
    ]);
}

api_error('Invalid action');

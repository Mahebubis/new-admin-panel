# KumoMTA module — server setup

This module has two halves:

| Half | Where it runs | What it does |
|---|---|---|
| Panel (this code) | `cit3.internshipstudio.com` | UI, database, audience, campaigns, health scoring, warmup |
| Mail server | OVH VPS `146.59.144.171` (`mail1.nitrocampus.com`) | KumoMTA itself + the 5 sending IPs |

They talk over exactly two links:

```
panel  ──POST https://mailer.nitrocampus.com/kumo/inject──▶  KumoMTA 127.0.0.1:8000
panel  ◀──POST .../api/kumo/kumo-webhook.php?secret=…────── KumoMTA log hook
```

Nothing else is exposed. KumoMTA's HTTP API stays bound to `127.0.0.1`.

---

## 1. Panel side (cit3)

### 1.1 Deploy
The module lives in `react-api/api/kumo/`. Deploy it the same way as the rest of
`react-api`. The frontend lives in `src/pages/kumo/` and ships with the normal
Vite build.

### 1.2 Permission
Give the admin user the **Kumo MTA** permission (`kumo_mta`) in
*Settings → Permissions*. Superadmins bypass it.

### 1.3 Tables
Created automatically on first request by `kumo_ensure_schema()`. Every table is
new and prefixed `kumo_`; the module never alters an existing table. The SQL is
mirrored for review in `kumo_schema.sql`.

### 1.4 Cron
```cron
# batch sender — every minute
* * * * * /usr/local/bin/php /home/istudio/public_html/admin/react-api/api/kumo/kumo-send-worker.php >> /home/istudio/logs/kumo-worker.log 2>&1

# health, warmup, blocklist + bridge probe — every 10 minutes
*/10 * * * * /usr/local/bin/php /home/istudio/public_html/admin/react-api/api/kumo/kumo-health-worker.php >> /home/istudio/logs/kumo-health.log 2>&1
```
If the workers are to run on the monitoring box instead, add these paths to
`monitoring/deploy/worker-files.txt`:
```
api/kumo/kumo-send-worker.php
api/kumo/kumo-health-worker.php
api/kumo/lib/config.php
api/kumo/lib/schema.php
api/kumo/lib/Stats.php
api/kumo/lib/Health.php
api/kumo/lib/Audience.php
api/kumo/lib/Mailer.php
api/kumo/lib/KumoClient.php
api/kumo/lib/SendWorker.php
```

---

## 2. Mail server side (the OVH VPS)

### 2.1 A bearer token
Generate one and keep it — it goes into nginx below **and** into
*Kumo MTA → Settings → Connection* in the panel.

```bash
openssl rand -hex 32
```

### 2.2 nginx bridge

Order matters: certbot needs port 80 answering for `mailer.nitrocampus.com`
*before* a server block can reference the certificate, otherwise `nginx -t`
fails on a missing file.

```bash
sudo apt install -y nginx certbot python3-certbot-nginx
sudo ufw allow 80/tcp && sudo ufw allow 443/tcp
sudo certbot --nginx -d mailer.nitrocampus.com     # A record → 146.59.144.171 exists
```

The guard block goes in its own snippet, because nginx matches `location =`
(exact) **before** `location /kumo/` (prefix) — guards written only in the
prefix block would never run for /kumo/inject, leaving injection open.

`/etc/nginx/snippets/kumo-guard.conf`:

```nginx
if ($kumo_allowed = 0)   { return 403; }
if ($kumo_bad_token)     { return 401; }
client_max_body_size 25m;
proxy_read_timeout   60s;
proxy_set_header Host $host;
proxy_set_header Authorization "";   # our token is for nginx, not for KumoMTA
```

`/etc/nginx/sites-available/mailer.nitrocampus.com`:

```nginx
# Only these two hosts may reach the bridge at all.
geo $kumo_allowed {
    default           0;
    15.207.59.247/32  1;    # cit3 — the panel itself
    13.207.16.208/32  1;    # monitoring box — send + health crons
}

# "Bearer " + a 64-hex token is 71 chars — past nginx default 64-byte bucket.
map_hash_bucket_size 128;

map $http_authorization $kumo_bad_token {
    default                    1;
    "Bearer PASTE_TOKEN_HERE"  0;    # token from 2.1
}

server {
    listen 443 ssl;
    server_name mailer.nitrocampus.com;

    ssl_certificate     /etc/letsencrypt/live/mailer.nitrocampus.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/mailer.nitrocampus.com/privkey.pem;

    location = /kumo/ping    { return 200 "ok
"; }   # deliberately public
    location = /kumo/inject  { include snippets/kumo-guard.conf; proxy_pass http://127.0.0.1:8000/api/inject/v1; }
    location = /kumo/metrics { include snippets/kumo-guard.conf; proxy_pass http://127.0.0.1:8000/metrics.json; }
    location = /kumo/bounce  { include snippets/kumo-guard.conf; proxy_pass http://127.0.0.1:8000/api/admin/bounce/v1; }

    location / { return 404; }
}
```

```bash
sudo ln -s /etc/nginx/sites-available/mailer.nitrocampus.com /etc/nginx/sites-enabled/
sudo nginx -t && sudo systemctl reload nginx
```

The panel's "Test connection" and the health cron both call **GET /kumo/metrics**
with the bearer token — `/kumo/ping` is only for external uptime checks, so a
200 from ping does not prove the bridge works.

### 2.3 Tell KumoMTA where to post its events

In `/opt/kumomta/etc/policy/init.lua`, **before** the queue helper:

```lua
local log_hooks = require 'policy-extras.log_hooks'

log_hooks:new_json {
  name = 'panel',
  url  = 'https://cit3.internshipstudio.com/admin/react-api/api/kumo/kumo-webhook.php?secret=<KUMO_CRON_SECRET>',
  log_parameters = {
    headers = { 'X-Campaign-ID', 'X-Message-Ref', 'Feedback-ID' },
  },
}
```

`<KUMO_CRON_SECRET>` is the constant in `lib/config.php`. The panel shows the
full URL to paste in *Settings → Connection → Webhook URL*.

```bash
sudo systemctl restart kumomta
sudo journalctl -u kumomta -n 30 --no-pager
```

### 2.4 Pools must match the tenants
Each IP row in the panel has a **tenant** (`ip1` … `ip5`). The sender puts it on
every message as `X-Tenant`, and `queues.toml` maps it to the egress pool:

```toml
tenant_header = "X-Tenant"
remove_tenant_header = true
[tenant.'ip1']
egress_pool = 'pool-ip1'
```

If a tenant in the panel has no matching pool, KumoMTA falls back to
`default_tenant` and the mail leaves from the wrong IP — so keep the two lists
identical.

---

## 3. First-run checklist

1. Panel → *Kumo MTA → Settings → Connection*: bridge URL + token → **Test connection** (expect "Bridge is reachable").
2. *Settings → Sender*: from name/address, bounce domain, tracking domain.
3. *Sending IPs*: add the five IPs with their tenants (`ip1`…`ip5`) and hostnames (`mail1.nitrocampus.com`…).
4. Press **Check blocklists** — confirms reverse DNS and DNSBL status per IP.
5. *Audience*: create a list, import contacts (CSV or from an existing Netcore segment — read-only).
6. *Templates*: create one template.
7. *Campaigns*: build a campaign → **Send test** to your own address → check SPF/DKIM/DMARC in "Show original".
8. Start with warmup on (Settings → Warmup, auto = on). Day 1 caps each IP at 500.

## 4. Safety notes

- The module writes only to `kumo_*` tables. The only statements touching existing
  tables are `SELECT`s: `netcore_segments` + `users` when you import an audience.
- Deleting a Kumo list deletes only `kumo_list_members` rows; contacts stay.
- Hard bounces, complaints and unsubscribes are auto-suppressed in `kumo_blocklist`
  and skipped on every future send, including mid-campaign.

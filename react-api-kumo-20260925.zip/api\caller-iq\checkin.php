<?php
/**
 * /api/caller-iq/checkin.php  —  a phone saying it exists, and how it is set up (no JWT: phones cannot log in)
 * ---------------------------------------------------------------------------
 * POST { device_id, device_model, manufacturer, brand, os_release, sdk, app_version, app_build,
 *        popup_ok, health: { steps: [{key,title,status,required,how}], sync_ok_at, sync_error,
 *                            bg_run_at, pending_uploads, sims, popup_enabled } }
 *
 * Sent by app v1.4+ when its setup changes, and at most twice a day otherwise. It is what lets a
 * phone appear on the Agents tab the moment the app is installed — before a single call has
 * uploaded — and lets the panel say exactly which switch is off on which phone.
 * ---------------------------------------------------------------------------
 */
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../middleware/auth.php';
require_once __DIR__ . '/ciq_lib.php';

mysqli_report(MYSQLI_REPORT_OFF);
set_exception_handler(function (Throwable $e) {
    error_log('[caller-iq checkin] ' . $e->getMessage() . ' @ ' . $e->getFile() . ':' . $e->getLine());
    api_error('Temporary failure, retry later', 503);
});

require_method('POST');

if (!function_exists('ciq_checkin')) {
    api_error('Server not ready: deploy react-api/api/caller-iq/ciq_lib.php', 503);
}

$in = get_json_input();

if (CALLER_IQ_INGEST_KEY !== '') {
    $sent = $_SERVER['HTTP_X_CALLIQ_KEY'] ?? ($in['key'] ?? '');
    if (!hash_equals(CALLER_IQ_INGEST_KEY, (string)$sent)) api_error('Invalid ingest key', 401);
}

// A report that can never be stored must not be retried by the phone forever: answer 200.
if (!$in || !is_array($in)) api_success(['stored' => false], 'Empty payload ignored');

ciq_ensure_schema($conn);

$r = ciq_checkin($conn, $in, (string)($_SERVER['REMOTE_ADDR'] ?? ''));
if (!$r['ok']) {
    error_log('[caller-iq checkin] ' . ($r['reason'] ?? 'unknown'));
    if (($r['reason'] ?? '') === 'device_id is required') api_success(['stored' => false], 'Ignored');
    api_error('Could not store the check-in, retry later', 503);
}

api_success(['stored' => true, 'server_time' => date('c')], 'Stored');

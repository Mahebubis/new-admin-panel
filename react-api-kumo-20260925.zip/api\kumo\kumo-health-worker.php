<?php
/*
 * Cron entrypoint for IP health, warmup and the blocklist / bridge probes.
 *
 *   (every 10 minutes — see SETUP.md for the exact crontab line, which cannot be
 *   written inside this comment because it contains a comment-closing sequence)
 *   .../api/kumo/kumo-health-worker.php >> /home/istudio/logs/kumo-health.log 2>&1
 *
 * What runs when:
 *   every tick  → bridge probe (API-health widget) + health scoring
 *   hourly      → DNSBL + reverse-DNS checks
 *   after 00:00 → warmup ladder for the new day
 *
 * Everything it writes goes into kumo_* tables only.
 */
ini_set('display_errors', 0);
error_reporting(E_ALL & ~E_WARNING & ~E_NOTICE & ~E_DEPRECATED);
$_SERVER['REQUEST_METHOD'] = $_SERVER['REQUEST_METHOD'] ?? 'CLI';

try {
    require_once __DIR__ . '/../../config/database.php';
} catch (\Throwable $e) {
    @file_put_contents(__DIR__ . '/worker.log', '[' . date('Y-m-d H:i:s') . '] FATAL — no database: ' . $e->getMessage() . "\n", FILE_APPEND | LOCK_EX);
    exit;
}

require_once __DIR__ . '/lib/config.php';
require_once __DIR__ . '/lib/schema.php';
require_once __DIR__ . '/lib/Health.php';

kumo_ensure_schema();

$isCli = (php_sapi_name() === 'cli');
if (!$isCli && (($_GET['secret'] ?? '') !== KUMO_CRON_SECRET)) {
    http_response_code(403);
    echo "forbidden\n";
    exit;
}

$lock = $conn->query("SELECT GET_LOCK('kumo_health_worker', 0) AS l");
if (!$lock || (int)$lock->fetch_assoc()['l'] !== 1) {
    if ($isCli) echo "another health worker is running\n";
    exit;
}

$out = [];
try {
    $out['api']    = kumo_api_probe();
    $out['warmup'] = kumo_warmup_tick();

    /* The DNS probes are the slow part — once an hour is plenty.
       `--force` (CLI) or ?force=1 (HTTP) runs them immediately, which is what
       you want right after adding or changing an IP.
       They run BEFORE scoring: reverse DNS and blocklist state are inputs to
       the health score, and scoring on last hour's values made a freshly added
       IP look yellow for a whole cycle. */
    $minute = (int)date('i');
    $forced = (($_GET['force'] ?? '') === '1') || in_array('--force', (array)($argv ?? []), true);
    if ($minute < 10 || $forced) {
        $out['blocklist'] = kumo_blocklist_tick();
    }

    $out['health'] = kumo_health_tick();
} catch (\Throwable $e) {
    kumo_log('health worker error: ' . $e->getMessage());
    $out['error'] = $e->getMessage();
} finally {
    @$conn->query("SELECT RELEASE_LOCK('kumo_health_worker')");
}

$line = sprintf('health: api=%s scored=%d green=%d yellow=%d red=%d%s',
    !empty($out['api']['ok']) ? 'up' : 'down',
    $out['health']['scored'] ?? 0, $out['health']['green'] ?? 0,
    $out['health']['yellow'] ?? 0, $out['health']['red'] ?? 0,
    !empty($out['health']['paused']) ? ' paused=' . implode(',', $out['health']['paused']) : '');
kumo_log($line);

if ($isCli) {
    echo $line . "\n";
} else {
    header('Content-Type: application/json');
    echo json_encode(['ok' => true, 'summary' => $out]);
}

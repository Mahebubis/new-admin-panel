<?php
/**
 * /api/profile-metrics/pm_lib.php — the metric engine behind Resume/Profile Metrics.
 * ---------------------------------------------------------------------------
 * Everything the page can count is declared once in pm_metrics() below: where the
 * rows live, which column carries the event's date, and which JOINs are available
 * if a filter happens to need them. Every action (series, breakdown, rows,
 * overview) is then the same three steps — pick a metric, hand it the filters,
 * group by a dimension — which is why adding a new counter is a six-line entry
 * rather than a new endpoint.
 *
 * Two things about this database shaped the design:
 *
 *  1. Nothing logged resume uploads or profile-section edits. `upload_resume.php`
 *     overwrote `users.resume`; `update_profile.php` DELETEd and re-INSERTed
 *     `user_work` / `user_education` / … which carry no timestamps at all, and
 *     only bumped `users.last_updated`. So those two families read from
 *     `user_activity_log` — the generic (user_id, activity_type, activity_data,
 *     created_at) table this codebase already uses for certificate downloads —
 *     which the student dashboard now writes to.
 *
 *  2. `users.last_updated` is a single overwritten column, so "profiles updated"
 *     is a LAST-TOUCH measure: a learner who edited on five days appears only on
 *     the fifth. It is kept because it is the only thing that covers the old
 *     history, and it is labelled as such everywhere it is shown.
 *
 * ── Why the queries are shaped the way they are ───────────────────────────────
 * The first cut joined applications → jobs → companies → users on EVERY metric,
 * because some filter might want one of them. On a table with millions of chat
 * messages that is four joins and a COUNT(DISTINCT) to answer "how many messages
 * last week", and the page timed out at thirty seconds.
 *
 * So a metric now declares a minimal `base` table plus `joins` that are added
 * only when a filter, a grouping or a requested column actually needs them. With
 * no filters set — which is how the page first loads — "messages from companies"
 * is a single indexed range scan of `chat_messages` and nothing else. And when no
 * join is emitted, nothing can duplicate a row, so the count is a plain COUNT(*)
 * instead of a COUNT(DISTINCT) that would build a temp table over the whole range.
 *
 * The other half of that fix is the indexes in schema.sql. Without them every one
 * of these is a full table scan whatever the query looks like; `pm_missing_indexes()`
 * reports the ones that are absent so the page can offer to create them.
 *
 * Column presence is probed once per request against information_schema rather
 * than assumed, because `soft_delete`, `is_test_account` and friends exist on
 * some of these tables and not others and a missing one would 500 the page.
 */

/* ── schema probe ───────────────────────────────────────────────────────────
   One query, cached for the request. Cheaper than being wrong: several of these
   columns were added to live tables at different times. */
function pm_cols() {
    global $conn;
    static $map = null;
    if ($map !== null) return $map;

    $map    = [];
    $tables = [
        'users', 'user_activity_log', 'removed_resumes', 'candidates',
        'hiring_applications_new', 'job_list', 'hiring_employer',
        'chat_messages', 'hiring_assignment_new', 'hiring_submit_assignment_new',
        'hiring_schedule_interview_new', 'reschedule_interview_new', 'invited_candidate',
    ];
    $in  = "'" . implode("','", $tables) . "'";
    $res = $conn->query(
        "SELECT TABLE_NAME AS t, COLUMN_NAME AS c
           FROM information_schema.COLUMNS
          WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME IN ($in)"
    );
    if ($res) {
        while ($r = $res->fetch_assoc()) {
            $map[strtolower($r['t'])][strtolower($r['c'])] = true;
        }
        $res->free();
    }
    return $map;
}

function pm_has($table, $col) {
    $m = pm_cols();
    return isset($m[strtolower($table)][strtolower($col)]);
}
function pm_table($table) {
    $m = pm_cols();
    return isset($m[strtolower($table)]);
}

/* ── the indexes this page lives or dies by ─────────────────────────────────
   Same list as schema.sql, in a form the endpoint can check and create. Every
   panel on the page filters by a date range first, so each one leads with the
   date column. */
function pm_index_plan() {
    return [
        ['users',                          'idx_pm_registered_at',   '`registered_at`'],
        ['users',                          'idx_pm_last_updated',    '`last_updated`'],
        /* Not for counting — for the two lookups that otherwise read the whole
           of `users` before any counting starts. See pm_test_user_ids(). */
        ['users',                          'idx_pm_is_test',         '`is_test_account`'],
        ['users',                          'idx_pm_applyforexam',    '`applyforexam`'],
        ['user_activity_log',              'idx_pm_type_created',    '`activity_type`, `created_at`'],
        ['hiring_applications_new',        'idx_pm_applied_date',    '`applied_date`'],
        ['hiring_applications_new',        'idx_pm_job_id',          '`job_id`'],
        ['hiring_applications_new',        'idx_pm_user_id',         '`user_id`'],
        ['job_list',                       'idx_pm_employer_id',     '`employer_id`'],
        ['invited_candidate',              'idx_pm_created_at',      '`created_at`'],
        ['hiring_assignment_new',          'idx_pm_created_at',      '`created_at`'],
        ['hiring_assignment_new',          'idx_pm_application',     '`application_id`'],
        ['hiring_submit_assignment_new',   'idx_pm_created_at',      '`created_at`'],
        ['hiring_submit_assignment_new',   'idx_pm_assignment',      '`assignment_id`'],
        ['hiring_schedule_interview_new',  'idx_pm_created_at',      '`created_at`'],
        ['hiring_schedule_interview_new',  'idx_pm_interview_date',  '`interview_date`'],
        ['hiring_schedule_interview_new',  'idx_pm_application',     '`application_id`'],
        ['reschedule_interview_new',       'idx_pm_created_at',      '`created_at`'],
        ['reschedule_interview_new',       'idx_pm_interview',       '`interview_id`'],
        ['chat_messages',                  'idx_pm_created_sender',  '`created_at`, `sender_type`, `status`'],
        ['chat_messages',                  'idx_pm_application',     '`application_id`'],
    ];
}

/** Which of them are not there yet. One query, not one per index. */
function pm_missing_indexes() {
    global $conn;
    $have = [];
    $res  = $conn->query(
        "SELECT TABLE_NAME AS t, INDEX_NAME AS i
           FROM information_schema.STATISTICS
          WHERE TABLE_SCHEMA = DATABASE() AND INDEX_NAME LIKE 'idx\\_pm\\_%'"
    );
    if ($res) {
        while ($r = $res->fetch_assoc()) $have[strtolower($r['t']) . '.' . strtolower($r['i'])] = true;
        $res->free();
    }

    $missing = [];
    foreach (pm_index_plan() as [$table, $name, $cols]) {
        if (!pm_table($table)) continue;                       // table not in this database
        if (isset($have[strtolower($table) . '.' . strtolower($name)])) continue;
        $missing[] = ['table' => $table, 'index' => $name, 'columns' => $cols];
    }
    return $missing;
}

/**
 * Create the missing ones. Triggered deliberately from the page by a superadmin,
 * never automatically on a page load — these are big tables and the operation,
 * online or not, is not something a dashboard should start behind somebody's back.
 */
function pm_create_indexes($limit = 1) {
    global $conn;

    /* ONE index per request by default, and the page calls back for the next.
       An ALTER on `users` or `chat_messages` can run for minutes; doing all
       nineteen in a single request meant one long-running call that a proxy or
       an FPM timeout could cut in the middle, losing both the work in flight and
       any report of what had already succeeded. Incrementally, every index that
       lands is committed and visible before the next one starts.

       Each is also caught on its own: a table that refuses an ALTER — locked,
       out of disk, already has an equivalent index under another name — must not
       stop the other eighteen. */
    $done = [];
    foreach (pm_missing_indexes() as $ix) {
        if (count($done) >= max(1, (int)$limit)) break;

        $sql = "ALTER TABLE `{$ix['table']}` ADD INDEX `{$ix['index']}` ({$ix['columns']})";
        $t0  = microtime(true);
        $ok  = false;
        $err = null;
        try {
            $ok = (bool)$conn->query($sql);
            if (!$ok) $err = $conn->error;
        } catch (Throwable $e) {
            $err = $e->getMessage();
        }
        $done[] = [
            'table' => $ix['table'],
            'index' => $ix['index'],
            'ok'    => $ok,
            'ms'    => (int)round((microtime(true) - $t0) * 1000),
            'error' => $ok ? null : $err,
        ];
        if (!$ok) error_log('[profile-metrics] index ' . $ix['index'] . ' on ' . $ix['table'] . ': ' . $err);
    }
    return $done;
}

/* ── escaping ─────────────────────────────────────────────────────────────── */
function pm_esc($v) {
    global $conn;
    return $conn->real_escape_string((string)$v);
}
/** IN() list of ints. Returns '' when the caller passed nothing usable. */
function pm_int_list($arr) {
    if (!is_array($arr)) $arr = ($arr === null || $arr === '') ? [] : [$arr];
    $out = [];
    foreach ($arr as $v) { $n = (int)$v; if ($n > 0) $out[$n] = $n; }
    return $out ? implode(',', $out) : '';
}
/** IN() list of quoted strings. */
function pm_str_list($arr) {
    if (!is_array($arr)) $arr = ($arr === null || $arr === '') ? [] : [$arr];
    $out = [];
    foreach ($arr as $v) {
        $s = trim((string)$v);
        if ($s !== '') { $q = "'" . pm_esc($s) . "'"; $out[$q] = $q; }
    }
    return $out ? implode(',', $out) : '';
}

/**
 * The learner ids flagged as test accounts.
 *
 * Excluding them used to be `COALESCE(u.is_test_account,0) = 0`, which forced a
 * join to `users` on every single metric just to apply a default. There are a
 * handful of these rows, so fetching the ids once and writing them as a NOT IN
 * gives the same answer with no join at all. If the list is ever big enough that
 * inlining it would be worse than the join, this returns null and the join comes
 * back.
 */
function pm_test_user_ids() {
    global $conn;
    static $ids = false;
    if ($ids !== false) return $ids;

    $ids = [];
    if (!pm_has('users', 'is_test_account')) return $ids;

    /* `WHERE is_test_account = 1` on an unindexed column reads every row in
       `users` — millions of them — and this runs once per request BEFORE a
       single number is counted. It was, on its own, most of the thirty seconds.
       So it only runs when the index exists; until then test accounts are simply
       included, which the page states rather than hiding. */
    if (!pm_index_exists('users', 'idx_pm_is_test')) {
        pm_degraded('test_accounts_included',
            'Test accounts are being counted: excluding them needs an index on users.is_test_account, '
            . 'which is not there yet. Create the indexes to filter them out.');
        return $ids;
    }

    /* Cached across requests too — the list changes about never, and even an
       indexed lookup is wasted work on every single call. */
    $cached = pm_file_cache('test_user_ids', 1800);
    if (is_array($cached)) { $ids = $cached['ids']; return $ids === null ? null : $ids; }

    $res = $conn->query("SELECT user_id FROM users WHERE is_test_account = 1 LIMIT 2001");
    if ($res) {
        while ($r = $res->fetch_row()) $ids[] = (int)$r[0];
        $res->free();
    }
    if (count($ids) > 2000) $ids = null;   // too many to inline — fall back to the join
    pm_file_cache('test_user_ids', 1800, ['ids' => $ids]);
    return $ids;
}

/** One index, by name. Backed by the same single STATISTICS read as the health check. */
function pm_index_exists($table, $name) {
    static $set = null;
    if ($set === null) {
        $set = [];
        foreach (pm_missing_indexes() as $ix) {
            $set[strtolower($ix['table']) . '.' . strtolower($ix['index'])] = true;
        }
    }
    if (!pm_table($table)) return false;
    return !isset($set[strtolower($table) . '.' . strtolower($name)]);
}

/**
 * Things the page had to skip, and why. Collected rather than thrown: a metric
 * that quietly drops a filter to stay fast is a number that means something
 * slightly different, and the reader is entitled to know which.
 */
function pm_degraded($key = null, $msg = null) {
    static $notes = [];
    if ($key !== null) { $notes[$key] = $msg; return null; }
    return $notes;
}

/** Read-or-write file cache. Passing $value writes; omitting it reads. */
function pm_file_cache($key, $ttl, $value = null) {
    $path = rtrim(sys_get_temp_dir(), '/\\') . DIRECTORY_SEPARATOR
          . 'pm_' . preg_replace('/[^a-z0-9_]/i', '', $key) . '.json';

    if ($value !== null) {
        @file_put_contents($path, json_encode($value), LOCK_EX);
        return $value;
    }
    if (!is_file($path) || (time() - filemtime($path)) > $ttl) return null;
    $raw = @file_get_contents($path);
    if ($raw === false) return null;
    $v = json_decode($raw, true);
    return is_array($v) ? $v : null;
}

/**
 * A server-side ceiling on every SELECT this endpoint runs.
 *
 * Without it a query with no usable index simply runs until the browser gives
 * up, which is what "timeout of 30000ms exceeded" with no other information
 * looked like. With it the server aborts first and the page can say which
 * counter failed and why. MySQL 5.7.8+ and MariaDB spell this differently and
 * neither is fatal if unsupported.
 */
function pm_query_budget($ms = 15000) {
    global $conn;
    static $done = false;
    if ($done) return;
    $done = true;
    $ms = (int)$ms;
    if (!@$conn->query("SET SESSION max_execution_time = $ms")) {
        @$conn->query("SET SESSION max_statement_time = " . ($ms / 1000));  // MariaDB, in seconds
    }
}

/* ── dates ──────────────────────────────────────────────────────────────────
   Ranges are inclusive whole days in Asia/Kolkata (set by config/database.php),
   which is what "today" means to the people reading this page. */
function pm_day($s, $fallback) {
    $s = trim((string)$s);
    if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $s)) {
        [$y, $m, $d] = array_map('intval', explode('-', $s));
        if (checkdate($m, $d, $y)) return $s;
    }
    return $fallback;
}
function pm_range($in) {
    $today = date('Y-m-d');
    $end   = pm_day($in['end']   ?? '', $today);
    $start = pm_day($in['start'] ?? '', date('Y-m-d', strtotime('-29 days')));
    if (strtotime($start) > strtotime($end)) { $t = $start; $start = $end; $end = $t; }

    /* The comparison window is the same number of days sitting immediately
       before the range, so "last 7 days" always compares against the 7 before
       it — no month-length surprises. */
    $days       = (int)round((strtotime($end) - strtotime($start)) / 86400) + 1;
    $prev_end   = date('Y-m-d', strtotime($start . ' -1 day'));
    $prev_start = date('Y-m-d', strtotime($prev_end . ' -' . ($days - 1) . ' day'));

    return [
        'start' => $start, 'end' => $end, 'days' => $days,
        'prev_start' => $prev_start, 'prev_end' => $prev_end,
    ];
}

/* ── metric registry ────────────────────────────────────────────────────────
   base     : the ONE table the metric is really about
   joins    : alias => JOIN clause, emitted only if something needs that alias
   deps     : alias => aliases it must be preceded by
   date     : the column that makes a row belong to a day
   date_day : true when that column is a calendar day, not a timestamp
   key      : what COUNT(DISTINCT …) counts when joins are in play
   user_col : where the learner id lives WITHOUT any join, if it does
   where    : always-on predicate
   has      : aliases reachable at all, i.e. which filters this metric can honour
   dims     : dimensions this metric may be grouped by
   family   : which tab it belongs to
   source   : 'db' = full history | 'log' = only since instrumentation
─────────────────────────────────────────────────────────────────────────── */
function pm_metrics() {
    static $M = null;
    if ($M !== null) return $M;

    /* Applications are the spine of the hiring side: every assignment, interview
       and message hangs off one, so they all reuse this chain to reach the job,
       the company and the learner — but only when a filter asks them to. */
    $chain = function ($fk) {
        return [
            'joins' => [
                'a'  => "JOIN hiring_applications_new a ON a.id = $fk",
                'jl' => 'LEFT JOIN job_list jl ON jl.job_id = a.job_id',
                'he' => 'LEFT JOIN hiring_employer he ON he.employer_id = jl.employer_id',
                'u'  => 'LEFT JOIN users u ON u.user_id = a.user_id',
            ],
            'deps' => ['jl' => ['a'], 'he' => ['a', 'jl'], 'u' => ['a']],
            'has'  => ['a', 'jl', 'he', 'u'],
            'dims' => ['day', 'employer', 'job', 'app_status', 'job_type', 'job_mode', 'user'],
            'user_via' => 'a.user_id',
        ];
    };

    /* The same chain, but starting AT hiring_applications_new. */
    $appSelf = [
        'joins' => [
            'jl' => 'LEFT JOIN job_list jl ON jl.job_id = a.job_id',
            'he' => 'LEFT JOIN hiring_employer he ON he.employer_id = jl.employer_id',
            'u'  => 'LEFT JOIN users u ON u.user_id = a.user_id',
        ],
        'deps' => ['he' => ['jl']],
        'has'  => ['a', 'jl', 'he', 'u'],
        'dims' => ['day', 'employer', 'job', 'app_status', 'job_type', 'job_mode', 'user'],
    ];

    /* user_activity_log already carries user_id, so the profile family never
       needs a join unless somebody searches by name. */
    $logBase = [
        'joins' => ['u' => 'LEFT JOIN users u ON u.user_id = al.user_id'],
        'has'   => ['al', 'u'],
        'user_col' => 'al.user_id',
    ];

    $M = [
        /* ── profile & resume ─────────────────────────────────────────────── */
        'new_profiles' => [
            'label' => 'New profiles', 'family' => 'profile', 'source' => 'db',
            'hint'  => 'Accounts created in the range (users.registered_at).',
            'base'  => 'users u', 'date' => 'u.registered_at', 'key' => 'u.user_id',
            'user_col' => 'u.user_id',
            'where' => 'u.applyforexam = 1',
            'has'   => ['u'], 'dims' => ['day', 'user'],
        ],
        'profiles_updated' => [
            'label' => 'Profiles updated', 'family' => 'profile', 'source' => 'db',
            'hint'  => 'Last-touch only — users.last_updated holds one date per learner, '
                     . 'so somebody who edited on five days is counted on the fifth. '
                     . 'Same-day-as-signup edits are excluded.',
            'base'  => 'users u', 'date' => 'u.last_updated', 'key' => 'u.user_id',
            'user_col' => 'u.user_id',
            'where' => 'u.applyforexam = 1 AND u.registered_at IS NOT NULL
                        AND DATE(u.last_updated) > DATE(u.registered_at)',
            'has'   => ['u'], 'dims' => ['day', 'user'],
        ],
        'resume_uploaded' => $logBase + [
            'label' => 'Resumes uploaded', 'family' => 'profile', 'source' => 'log',
            'hint'  => 'Every upload, including replacements — one row per upload.',
            'base'  => 'user_activity_log al', 'date' => 'al.created_at', 'key' => 'al.id',
            'where' => "al.activity_type = 'resume_uploaded'",
            'dims'  => ['day', 'user', 'resume_kind', 'source_page'],
        ],
        'resume_first_upload' => $logBase + [
            'label' => 'First-time resumes', 'family' => 'profile', 'source' => 'log',
            'hint'  => 'Uploads by a learner who had no resume on file before.',
            'base'  => 'user_activity_log al', 'date' => 'al.created_at', 'key' => 'al.id',
            'where' => "al.activity_type = 'resume_uploaded'
                        AND COALESCE(JSON_UNQUOTE(JSON_EXTRACT(al.activity_data,'$.replaced')),'0') IN ('0','false')",
            'dims'  => ['day', 'user'],
        ],
        'resume_replaced' => $logBase + [
            'label' => 'Resumes replaced', 'family' => 'profile', 'source' => 'log',
            'hint'  => 'Uploads that overwrote an existing resume.',
            'base'  => 'user_activity_log al', 'date' => 'al.created_at', 'key' => 'al.id',
            'where' => "al.activity_type = 'resume_uploaded'
                        AND COALESCE(JSON_UNQUOTE(JSON_EXTRACT(al.activity_data,'$.replaced')),'0') IN ('1','true')",
            'dims'  => ['day', 'user'],
        ],
        'resume_removed' => $logBase + [
            'label' => 'Resumes removed', 'family' => 'profile', 'source' => 'log',
            'hint'  => 'Learner deleted the resume on file.',
            'base'  => 'user_activity_log al', 'date' => 'al.created_at', 'key' => 'al.id',
            'where' => "al.activity_type = 'resume_removed'",
            'dims'  => ['day', 'user'],
        ],
        'profile_section_updated' => $logBase + [
            'label' => 'Profile section edits', 'family' => 'profile', 'source' => 'log',
            'hint'  => 'One row per section saved — experience, education, certifications, '
                     . 'personal details and the rest, counted separately.',
            'base'  => 'user_activity_log al', 'date' => 'al.created_at', 'key' => 'al.id',
            'where' => "al.activity_type = 'profile_section_updated'",
            'dims'  => ['day', 'user', 'section'],
        ],
        'profile_editors' => $logBase + [
            'label' => 'Learners who edited', 'family' => 'profile', 'source' => 'log',
            'hint'  => 'Distinct learners behind the edits — how many people, not how many saves.',
            'base'  => 'user_activity_log al', 'date' => 'al.created_at', 'key' => 'al.user_id',
            /* Counts PEOPLE, so it is the one metric that must stay DISTINCT
               even when nothing is joined. */
            'distinct' => true,
            'where' => "al.activity_type IN ('profile_section_updated','resume_uploaded','profile_photo_updated')",
            'dims'  => ['day', 'user', 'section'],
        ],
        'profile_photo_updated' => $logBase + [
            'label' => 'Profile photos set', 'family' => 'profile', 'source' => 'log',
            'hint'  => 'Photo uploaded or changed.',
            'base'  => 'user_activity_log al', 'date' => 'al.created_at', 'key' => 'al.id',
            'where' => "al.activity_type = 'profile_photo_updated'",
            'dims'  => ['day', 'user'],
        ],

        /* ── hiring portal ────────────────────────────────────────────────── */
        'applications' => $appSelf + [
            'label' => 'Applications', 'family' => 'hiring', 'source' => 'db',
            'hint'  => 'Applications to jobs, internships and contracts in the hiring portal. '
                     . 'Revoking hard-deletes the row in the student dashboard, so past days can shrink.',
            'base'  => 'hiring_applications_new a',
            'date'  => 'a.applied_date', 'key' => 'a.id',
            'user_col' => 'a.user_id',
        ],
        'invites' => [
            'label' => 'Invites from companies', 'family' => 'hiring', 'source' => 'db',
            'hint'  => 'Companies inviting a learner to apply.',
            'base'  => 'invited_candidate ic',
            'joins' => [
                'jl' => 'LEFT JOIN job_list jl ON jl.job_id = ic.job_id',
                'he' => 'LEFT JOIN hiring_employer he ON he.employer_id = jl.employer_id',
                'u'  => 'LEFT JOIN users u ON u.user_id = ic.user_id',
                'a'  => 'LEFT JOIN hiring_applications_new a ON a.id = ic.application_id',
            ],
            'deps' => ['he' => ['jl']],
            'date' => 'ic.created_at', 'key' => 'ic.id',
            'user_col' => 'ic.user_id',
            'has'  => ['a', 'jl', 'he', 'u'],
            'dims' => ['day', 'employer', 'job', 'job_type', 'job_mode', 'user'],
        ],
        'assignments_sent' => $chain('asg.application_id') + [
            'label' => 'Assignments sent', 'family' => 'hiring', 'source' => 'db',
            'hint'  => 'Assignments a company sent to a candidate.',
            'base'  => 'hiring_assignment_new asg',
            'date'  => 'asg.created_at', 'key' => 'asg.id',
        ],
        'assignments_submitted' => [
            'label' => 'Assignments submitted', 'family' => 'hiring', 'source' => 'db',
            'hint'  => 'Candidate submissions against those assignments.',
            'base'  => 'hiring_submit_assignment_new sub',
            'joins' => [
                'asg' => 'JOIN hiring_assignment_new asg ON asg.id = sub.assignment_id',
                'a'   => 'JOIN hiring_applications_new a ON a.id = asg.application_id',
                'jl'  => 'LEFT JOIN job_list jl ON jl.job_id = a.job_id',
                'he'  => 'LEFT JOIN hiring_employer he ON he.employer_id = jl.employer_id',
                'u'   => 'LEFT JOIN users u ON u.user_id = a.user_id',
            ],
            'deps' => ['a' => ['asg'], 'jl' => ['asg', 'a'], 'he' => ['asg', 'a', 'jl'], 'u' => ['asg', 'a']],
            'date' => 'sub.created_at', 'key' => 'sub.id',
            'user_via' => 'a.user_id',
            'has'  => ['a', 'jl', 'he', 'u'],
            'dims' => ['day', 'employer', 'job', 'app_status', 'job_type', 'job_mode', 'user'],
        ],
        'interviews_scheduled' => $chain('iv.application_id') + [
            'label' => 'Interviews scheduled', 'family' => 'hiring', 'source' => 'db',
            'hint'  => 'Counted on the day the company booked it, not the day it happens.',
            'base'  => 'hiring_schedule_interview_new iv',
            'date'  => 'iv.created_at', 'key' => 'iv.id',
        ],
        'interviews_held' => $chain('iv.application_id') + [
            'label' => 'Interviews due', 'family' => 'hiring', 'source' => 'db',
            'hint'  => 'Counted on the interview date itself — the sitting, not the booking.',
            'base'  => 'hiring_schedule_interview_new iv',
            /* The only date column here that is a calendar day rather than a
               timestamp. Compared day-to-day (see date_day) — appending
               '23:59:59' to a DATE makes MySQL cast the column for every row,
               which drops the index. */
            'date'  => 'iv.interview_date', 'key' => 'iv.id', 'date_day' => true,
        ],
        'reschedule_requests' => [
            'label' => 'Reschedule requests', 'family' => 'hiring', 'source' => 'db',
            'hint'  => 'Candidate asked to move an interview.',
            'base'  => 'reschedule_interview_new rs',
            'joins' => [
                'iv' => 'JOIN hiring_schedule_interview_new iv ON iv.id = rs.interview_id',
                'a'  => 'JOIN hiring_applications_new a ON a.id = iv.application_id',
                'jl' => 'LEFT JOIN job_list jl ON jl.job_id = a.job_id',
                'he' => 'LEFT JOIN hiring_employer he ON he.employer_id = jl.employer_id',
                'u'  => 'LEFT JOIN users u ON u.user_id = a.user_id',
            ],
            'deps' => ['a' => ['iv'], 'jl' => ['iv', 'a'], 'he' => ['iv', 'a', 'jl'], 'u' => ['iv', 'a']],
            'date' => 'rs.created_at', 'key' => 'rs.id',
            'user_via' => 'a.user_id',
            'has'  => ['a', 'jl', 'he', 'u'],
            'dims' => ['day', 'employer', 'job', 'app_status', 'job_type', 'job_mode', 'user'],
        ],

        /* ── messaging ────────────────────────────────────────────────────────
           chat_messages.status is 'sent' until the other side opens it, then
           'read'. It is a live flag with no timestamp of its own, so read/unread
           always describes the CURRENT state of messages sent in the range —
           which is exactly the question being asked.
           This is by far the biggest table on the page, which is why its base is
           `chat_messages` alone and the application chain only appears when a
           company or learner filter needs it. */
        'msg_from_company' => [
            'label' => 'Messages from companies', 'family' => 'messaging', 'source' => 'db',
            'hint'  => 'Chat messages a company sent to a candidate.',
            'base'  => 'chat_messages cm', 'date' => 'cm.created_at', 'key' => 'cm.id',
            'where' => "cm.sender_type = 'recruiter'",
            'has'   => ['a', 'jl', 'he', 'u', 'cm'],
            'dims'  => ['day', 'employer', 'job', 'read_state', 'app_status', 'job_type', 'user'],
        ] + $chain('cm.application_id'),
        'msg_from_company_read' => [
            'label' => 'Read by candidate', 'family' => 'messaging', 'source' => 'db',
            'hint'  => 'Of the company messages sent in the range, how many the candidate has opened.',
            'base'  => 'chat_messages cm', 'date' => 'cm.created_at', 'key' => 'cm.id',
            'where' => "cm.sender_type = 'recruiter' AND cm.status = 'read'",
            'has'   => ['a', 'jl', 'he', 'u', 'cm'],
            'dims'  => ['day', 'employer', 'job', 'app_status', 'job_type', 'user'],
        ] + $chain('cm.application_id'),
        'msg_from_company_unread' => [
            'label' => 'Still unread by candidate', 'family' => 'messaging', 'source' => 'db',
            'hint'  => 'Company messages sent in the range that the candidate has not opened yet.',
            'base'  => 'chat_messages cm', 'date' => 'cm.created_at', 'key' => 'cm.id',
            'where' => "cm.sender_type = 'recruiter' AND (cm.status IS NULL OR cm.status <> 'read')",
            'has'   => ['a', 'jl', 'he', 'u', 'cm'],
            'dims'  => ['day', 'employer', 'job', 'app_status', 'job_type', 'user'],
        ] + $chain('cm.application_id'),
        'msg_from_student' => [
            'label' => 'Messages from students', 'family' => 'messaging', 'source' => 'db',
            'hint'  => 'Chat messages a candidate sent to a company.',
            'base'  => 'chat_messages cm', 'date' => 'cm.created_at', 'key' => 'cm.id',
            'where' => "cm.sender_type = 'candidate'",
            'has'   => ['a', 'jl', 'he', 'u', 'cm'],
            'dims'  => ['day', 'employer', 'job', 'read_state', 'app_status', 'job_type', 'user'],
        ] + $chain('cm.application_id'),
        'msg_from_student_read' => [
            'label' => 'Read by employer', 'family' => 'messaging', 'source' => 'db',
            'hint'  => 'Of the student messages sent in the range, how many the employer has opened.',
            'base'  => 'chat_messages cm', 'date' => 'cm.created_at', 'key' => 'cm.id',
            'where' => "cm.sender_type = 'candidate' AND cm.status = 'read'",
            'has'   => ['a', 'jl', 'he', 'u', 'cm'],
            'dims'  => ['day', 'employer', 'job', 'app_status', 'job_type', 'user'],
        ] + $chain('cm.application_id'),
        'msg_from_student_unread' => [
            'label' => 'Still unread by employer', 'family' => 'messaging', 'source' => 'db',
            'hint'  => 'Student messages sent in the range the employer has not opened yet.',
            'base'  => 'chat_messages cm', 'date' => 'cm.created_at', 'key' => 'cm.id',
            'where' => "cm.sender_type = 'candidate' AND (cm.status IS NULL OR cm.status <> 'read')",
            'has'   => ['a', 'jl', 'he', 'u', 'cm'],
            'dims'  => ['day', 'employer', 'job', 'app_status', 'job_type', 'user'],
        ] + $chain('cm.application_id'),
    ];
    return $M;
}

function pm_metric($key) {
    $M = pm_metrics();
    if (!isset($M[$key])) api_error('Unknown metric: ' . $key);
    return $M[$key] + [
        'where' => '', 'has' => [], 'dims' => ['day'], 'source' => 'db',
        'date_day' => false, 'joins' => [], 'deps' => [], 'distinct' => false,
        'user_col' => null, 'user_via' => null,
    ];
}

/**
 * Is this alias actually usable in the query being built?
 *
 * Two ways it can be: it was emitted as a JOIN, or it IS the base table. Getting
 * this wrong is silent and one-directional — a predicate that quietly stops
 * being applied, not an error — so it is one function rather than a `||` at each
 * of the eight call sites. `applications` is its own `a`, messaging is its own
 * `cm`, the profile family is its own `al`, and none of those appear in `joins`.
 */
function pm_base_alias($m) {
    $parts = preg_split('/\s+/', trim($m['base']));
    return end($parts);
}
function pm_live($m, $emitted, $alias) {
    return isset($emitted[$alias]) || pm_base_alias($m) === $alias;
}

/**
 * Where the learner id can be read from in the query as it currently stands —
 * the metric's own column if it has one (user_activity_log and
 * hiring_applications_new both carry user_id), otherwise whichever joined table
 * reached it. Null when nothing in the query knows who the learner is, in which
 * case learner filters are simply not applied rather than referencing an alias
 * that is not in the FROM.
 */
function pm_user_col($m, $emitted) {
    if ($m['user_col'] && pm_live($m, $emitted, explode('.', $m['user_col'])[0])) return $m['user_col'];
    if ($m['user_via'] && pm_live($m, $emitted, explode('.', $m['user_via'])[0])) return $m['user_via'];
    if (isset($emitted['u'])) return 'u.user_id';
    return null;
}

/* ── which joins this request actually needs ───────────────────────────────
   The whole performance story in one function: a filter nobody set costs
   nothing. Returns the alias list; pm_from() turns it into SQL. */
function pm_need($m, $f, $extra = []) {
    $has  = array_flip($m['has']);
    $need = [];
    $want = function ($alias) use (&$need, $has, $m) {
        if (isset($has[$alias]) && isset($m['joins'][$alias])) $need[$alias] = true;
    };

    if (isset($has['jl'])) {
        if (pm_int_list($f['employer_id'] ?? [])) { $want('jl'); }
        if (pm_int_list($f['job_id']      ?? [])) { $want('jl'); }
        if (pm_str_list($f['job_type']    ?? [])) { $want('jl'); }
        if (pm_str_list($f['job_mode']    ?? [])) { $want('jl'); }
    }
    if (isset($has['a']) && pm_str_list($f['app_status'] ?? [])) $want('a');

    /* A learner filter needs a user column. Some metrics carry one already
       (user_activity_log.user_id, hiring_applications_new.user_id); the rest have
       to join their way to it. Free-text search always needs `users` itself. */
    $userFilter = pm_int_list($f['user_id'] ?? '') !== '' || trim((string)($f['q'] ?? '')) !== '';
    if ($userFilter) {
        if (trim((string)($f['q'] ?? '')) !== '') $want('u');
        elseif (!$m['user_col']) $want('u');
    }

    /* Test-account exclusion only needs a join when the id list was too big to
       inline, or when the metric has no user column of its own. */
    if (empty($f['include_test']) && pm_has('users', 'is_test_account')) {
        $ids = pm_test_user_ids();
        if ($ids === null) $want('u');
        elseif ($ids && !$m['user_col'] && !$m['user_via']) $want('u');
        elseif ($ids && !$m['user_col'] && $m['user_via']) $want('a');
    }

    if (isset($has['a']) && empty($f['include_revoked']) && pm_has('hiring_applications_new', 'soft_delete')) {
        $want('a');
    }

    foreach ($extra as $alias) $want($alias);

    return array_keys($need);
}

/** FROM + only the JOINs in $need, with their dependencies, in declaration order. */
function pm_from($m, array $need) {
    $joins = $m['joins'];
    $deps  = $m['deps'];

    $want = [];
    $add  = function ($a) use (&$add, &$want, $deps, $joins) {
        if (isset($want[$a]) || !isset($joins[$a])) return;
        $want[$a] = true;                                  // set first: guards a cycle
        foreach ($deps[$a] ?? [] as $d) $add($d);
    };
    foreach ($need as $a) $add($a);

    $sql = $m['base'];
    foreach ($joins as $alias => $clause) {
        if (isset($want[$alias])) $sql .= "\n       " . $clause;
    }
    return [$sql, $want];
}

/**
 * COUNT expression. With no joins emitted nothing can duplicate a row, so this
 * is a plain COUNT(*) — which matters: COUNT(DISTINCT id) over a month of chat
 * messages builds a temp table, and that was a large part of the thirty seconds.
 */
function pm_count($m, array $emitted) {
    if ($m['distinct'] || $emitted) return "COUNT(DISTINCT {$m['key']})";
    return 'COUNT(*)';
}

/* ── filters ────────────────────────────────────────────────────────────────
   Only predicates whose alias is actually in the query are emitted, so the same
   filter payload can be thrown at every metric and each one honours the part of
   it that is meaningful. */
function pm_where($m, $f, $start, $end, array $emitted = []) {
    $w = [];

    /* A whole-day column gets a plain BETWEEN; a timestamp column gets the
       midnight-to-23:59:59 window. Both keep the bare column on the left so the
       index on it is usable — never DATE(col) BETWEEN …, which is a scan. */
    if (!empty($m['date_day'])) {
        $w[] = sprintf("%s BETWEEN '%s' AND '%s'", $m['date'], pm_esc($start), pm_esc($end));
    } else {
        $w[] = sprintf("%s >= '%s 00:00:00' AND %s <= '%s 23:59:59'",
                       $m['date'], pm_esc($start), $m['date'], pm_esc($end));
    }

    if (!empty($m['where'])) $w[] = '(' . $m['where'] . ')';

    /* A learner column that needs no join, if this metric has one. */
    $uid = pm_user_col($m, $emitted);

    /* Test accounts are excluded by default — they are staff rigs and would sit
       at the top of every company and every day otherwise. */
    if (empty($f['include_test']) && pm_has('users', 'is_test_account')) {
        $ids = pm_test_user_ids();
        if ($ids === null && isset($emitted['u'])) {
            $w[] = 'COALESCE(u.is_test_account, 0) = 0';
        } elseif (is_array($ids) && $ids && $uid) {
            $w[] = "$uid NOT IN (" . implode(',', $ids) . ")";
        }
    }

    if (pm_live($m, $emitted, 'a') && empty($f['include_revoked']) && pm_has('hiring_applications_new', 'soft_delete')) {
        $w[] = 'COALESCE(a.soft_delete, 0) = 0';
    }

    if (pm_live($m, $emitted, 'jl')) {
        if ($v = pm_int_list($f['employer_id'] ?? [])) $w[] = "jl.employer_id IN ($v)";
        if ($v = pm_int_list($f['job_id']      ?? [])) $w[] = "jl.job_id IN ($v)";
        if ($v = pm_str_list($f['job_type']    ?? [])) $w[] = "jl.job_type IN ($v)";
        if ($v = pm_str_list($f['job_mode']    ?? [])) $w[] = "jl.job_mode IN ($v)";
    }
    if (pm_live($m, $emitted, 'a')) {
        if ($v = pm_str_list($f['app_status'] ?? [])) $w[] = "a.status IN ($v)";
    }
    if (pm_live($m, $emitted, 'al')) {
        if ($v = pm_str_list($f['section'] ?? [])) {
            $w[] = "JSON_UNQUOTE(JSON_EXTRACT(al.activity_data, '$.section')) IN ($v)";
        }
    }
    if (pm_live($m, $emitted, 'cm')) {
        $rs = $f['read_state'] ?? '';
        if ($rs === 'read')   $w[] = "cm.status = 'read'";
        if ($rs === 'unread') $w[] = "(cm.status IS NULL OR cm.status <> 'read')";
    }
    if ($uid) {
        if ($v = pm_int_list($f['user_id'] ?? [])) $w[] = "$uid IN ($v)";
    }
    if (pm_live($m, $emitted, 'u')) {
        $q = trim((string)($f['q'] ?? ''));
        if ($q !== '') {
            $like = "'%" . pm_esc($q) . "%'";
            $num  = ctype_digit($q) ? " OR u.user_id = " . (int)$q : '';
            $w[]  = "(u.name LIKE $like OR u.fname LIKE $like OR u.lname LIKE $like
                      OR u.email LIKE $like OR u.phone LIKE $like$num)";
        }
    }
    return implode("\n   AND ", $w);
}

/* ── dimensions ─────────────────────────────────────────────────────────────
   Every entry is ONE expression per role, never a hand-written SELECT list.
   pm_breakdown groups by `id` verbatim and wraps every other expression in
   MIN(), which is what keeps this working under ONLY_FULL_GROUP_BY — on by
   default since MySQL 5.7.5.

   Two things used to break here, both worth remembering:

     - `GROUP BY 1` plus a `label` expression that was not IDENTICAL to the `id`
       expression. MySQL matches functional dependency on the text of the
       expression, so 'resume_kind' and 'read_state' — whose id says
       'replaced'/'first' while the label says 'Replaced an existing resume' /
       'First upload' — were rejected with error 1055 and the panel 500'd.
       Everything else happened to pass only because its id and label were the
       same string.

     - Columns like he.employer_logo or u.email, grouped by their table's key.
       MySQL 8 can sometimes infer that dependency and sometimes cannot (LEFT
       JOINs defeat it), so it was luck, not design.

   MIN() over a group whose rows all share the value returns that value, so
   nothing about the results changes — only that the server will now accept the
   query on any configuration. */
function pm_dim($m, $dim) {
    $has = array_flip($m['has']);
    switch ($dim) {
        case 'day':
            return ['id' => "DATE({$m['date']})", 'order' => 'id ASC'];

        case 'employer':
            if (!isset($has['he'])) return null;
            return [
                'id'     => 'jl.employer_id',
                'label'  => "COALESCE(NULLIF(he.employer_name,''), CONCAT('Company #', jl.employer_id))",
                'extra'  => 'he.employer_logo',
                'extra2' => 'he.employer_email',
                'needs'  => ['jl', 'he'],
            ];

        case 'job':
            if (!isset($has['jl'])) return null;
            return [
                'id'     => 'jl.job_id',
                'label'  => "COALESCE(NULLIF(jl.job_title,''), CONCAT('Job #', jl.job_id))",
                'extra'  => "COALESCE(NULLIF(he.employer_name,''),'Unknown company')",
                'extra2' => "COALESCE(NULLIF(jl.job_type,''),'-')",
                'needs'  => ['jl', 'he'],
            ];

        case 'app_status':
            if (!isset($has['a'])) return null;
            return ['id' => "COALESCE(NULLIF(a.status,''),'unknown')", 'needs' => ['a']];

        case 'job_type':
            if (!isset($has['jl'])) return null;
            return ['id' => "COALESCE(NULLIF(jl.job_type,''),'unknown')", 'needs' => ['jl']];

        case 'job_mode':
            if (!isset($has['jl'])) return null;
            return ['id' => "COALESCE(NULLIF(jl.job_mode,''),'unknown')", 'needs' => ['jl']];

        case 'read_state':
            if (!isset($has['cm'])) return null;
            return [
                'id'    => "IF(cm.status = 'read','read','unread')",
                'label' => "IF(cm.status = 'read','Read','Unread')",
            ];

        case 'section':
            if (!isset($has['al'])) return null;
            return ['id' => "COALESCE(NULLIF(JSON_UNQUOTE(JSON_EXTRACT(al.activity_data,'$.section')),''),'other')"];

        case 'resume_kind':
            if (!isset($has['al'])) return null;
            return [
                'id'    => "IF(COALESCE(JSON_UNQUOTE(JSON_EXTRACT(al.activity_data,'$.replaced')),'0') IN ('1','true'),'replaced','first')",
                'label' => "IF(COALESCE(JSON_UNQUOTE(JSON_EXTRACT(al.activity_data,'$.replaced')),'0') IN ('1','true'),'Replaced an existing resume','First upload')",
            ];

        case 'source_page':
            if (!isset($has['al'])) return null;
            return ['id' => "COALESCE(NULLIF(JSON_UNQUOTE(JSON_EXTRACT(al.activity_data,'$.source')),''),'dashboard')"];

        case 'user':
            if (!isset($has['u'])) return null;
            return [
                'id'     => 'u.user_id',
                'label'  => "COALESCE(NULLIF(TRIM(u.name),''),
                                      NULLIF(TRIM(CONCAT(COALESCE(u.fname,''),' ',COALESCE(u.lname,''))),''),
                                      u.email, CONCAT('User #', u.user_id))",
                'extra'  => 'u.email',
                'extra2' => 'u.phone',
                'needs'  => ['u'],
            ];
    }
    return null;
}

/* ── per-metric failure notes ───────────────────────────────────────────────
   A metric whose query fails must not take the whole tab down with it. But it
   must not come back as a silent zero either: on a page whose entire job is
   counting, "0" and "that query did not run" look identical and only one of them
   is news. The note travels with the metric and the tile shows it. */
function pm_note($key = null, $msg = null) {
    static $notes = [];
    if ($key !== null) { $notes[$key] = $msg; return null; }
    return $notes;
}

/* ── the query shapes ───────────────────────────────────────────────────── */

/** Day-by-day counts. Returns ['YYYY-MM-DD' => int]. */
function pm_daily($metricKey, $f, $start, $end) {
    global $conn;
    $m = pm_metric($metricKey);
    [$from, $emitted] = pm_from($m, pm_need($m, $f));

    $sql = "SELECT DATE({$m['date']}) AS d, " . pm_count($m, $emitted) . " AS cnt
              FROM $from
             WHERE " . pm_where($m, $f, $start, $end, $emitted) . "
             GROUP BY DATE({$m['date']})";
    $res = $conn->query($sql);
    if (!$res) {
        error_log('[profile-metrics] ' . $metricKey . ': ' . $conn->error);
        pm_note($metricKey, 'This counter could not be read from the database.');
        return [];
    }
    $out = [];
    while ($r = $res->fetch_assoc()) $out[$r['d']] = (int)$r['cnt'];
    $res->free();
    return $out;
}

/** A single number for the range. */
function pm_total($metricKey, $f, $start, $end) {
    global $conn;
    $m = pm_metric($metricKey);
    [$from, $emitted] = pm_from($m, pm_need($m, $f));

    $sql = "SELECT " . pm_count($m, $emitted) . " AS cnt
              FROM $from
             WHERE " . pm_where($m, $f, $start, $end, $emitted);
    $res = $conn->query($sql);
    if (!$res) {
        error_log('[profile-metrics] ' . $metricKey . ' total: ' . $conn->error);
        pm_note($metricKey, 'This counter could not be read from the database.');
        return 0;
    }
    $r = $res->fetch_assoc();
    $res->free();
    return (int)($r['cnt'] ?? 0);
}

/** Grouped counts for a dimension — this is what every drill-down list is. */
function pm_breakdown($metricKey, $dim, $f, $start, $end, $limit = 200, $offset = 0) {
    global $conn;
    $m = pm_metric($metricKey);
    if (!in_array($dim, $m['dims'], true)) api_error("'$dim' is not available for this metric");
    $d = pm_dim($m, $dim);
    if (!$d) api_error("'$dim' is not available for this metric");

    [$from, $emitted] = pm_from($m, pm_need($m, $f, $d['needs'] ?? []));

    $id     = $d['id'];
    /* A role the dimension does not use stays a bare NULL literal — constants
       are always legal under ONLY_FULL_GROUP_BY. */
    $label  = isset($d['label'])  ? "MIN({$d['label']})"  : "MIN($id)";
    $extra  = isset($d['extra'])  ? "MIN({$d['extra']})"  : 'NULL';
    $extra2 = isset($d['extra2']) ? "MIN({$d['extra2']})" : 'NULL';
    $order  = $d['order'] ?? 'cnt DESC';

    $limit  = max(1, min(20000, (int)$limit));
    $offset = max(0, (int)$offset);

    $sql = "SELECT $id AS id, $label AS label, $extra AS extra, $extra2 AS extra2,
                   " . pm_count($m, $emitted) . " AS cnt
              FROM $from
             WHERE " . pm_where($m, $f, $start, $end, $emitted) . "
             GROUP BY $id
             ORDER BY $order
             LIMIT $limit OFFSET $offset";
    $res = $conn->query($sql);
    if (!$res) {
        error_log('[profile-metrics] breakdown ' . $metricKey . '/' . $dim . ': ' . $conn->error);
        api_error('Could not group "' . $m['label'] . '" by ' . $dim . ': ' . $conn->error, 500);
    }

    $rows = [];
    while ($r = $res->fetch_assoc()) {
        $rows[] = [
            'id'     => $r['id'],
            'label'  => $r['label'],
            'extra'  => $r['extra']  ?? null,
            'extra2' => $r['extra2'] ?? null,
            'count'  => (int)$r['cnt'],
        ];
    }
    $res->free();
    return $rows;
}

/** How many distinct groups a breakdown has — for the drawer's "showing N of M". */
function pm_breakdown_size($metricKey, $dim, $f, $start, $end) {
    global $conn;
    $m = pm_metric($metricKey);
    $d = pm_dim($m, $dim);
    if (!$d) return 0;

    [$from, $emitted] = pm_from($m, pm_need($m, $f, $d['needs'] ?? []));

    $sql = "SELECT COUNT(DISTINCT {$d['id']}) AS c
              FROM $from
             WHERE " . pm_where($m, $f, $start, $end, $emitted);
    $res = $conn->query($sql);
    if (!$res) return 0;
    $r = $res->fetch_assoc();
    $res->free();
    return (int)($r['c'] ?? 0);
}

/** The FROM/WHERE a leaf row listing needs, given the columns it wants to show. */
function pm_leaf_context($m, $f, $start, $end, array $needAliases) {
    [$from, $emitted] = pm_from($m, pm_need($m, $f, $needAliases));
    return [$from, $emitted, pm_where($m, $f, $start, $end, $emitted)];
}

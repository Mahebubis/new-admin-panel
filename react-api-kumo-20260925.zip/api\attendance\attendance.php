<?php
/* ════════════════════════════════════════════════════════════
   ATTENDANCE API
   Endpoint: /admin/react-api/api/attendance/attendance.php

   Actions (GET):
     ?action=list                    -> recent 15 users from attendance_log
     ?action=search&q=<email|phone>  -> matching users (exact match — fast)
     ?action=calendar&payment_id=<id>-> day-by-day calendar for one payment

   One user can have several internship_payment rows with refund='yes' —
   each such payment becomes its own row (its own batch + duration).

   Present-day rule:
     - dates < 2026-05-13 : present if a user_login_activity record exists
     - dates >= 2026-05-13: present ONLY if BOTH a user_login_activity record
                            AND an attendance_log record exist for that date
════════════════════════════════════════════════════════════ */
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../middleware/auth.php';

/* Match the database's calendar so "today" lines up with DATE() in MySQL —
   otherwise a UTC server treats the IST current date as future and skips it. */
date_default_timezone_set('Asia/Kolkata');

$jwt = require_jwt();
require_permission('attendance', $jwt);

define('ATT_CUTOFF', '2026-05-13');   // dual-table rule applies on/after this date

/* total_duration column value -> number of months */
function att_months($days) {
    $days = (int)$days;
    if ($days <= 0)   return 0;
    if ($days <= 35)  return 1;
    if ($days <= 65)  return 2;
    if ($days <= 95)  return 3;
    if ($days <= 125) return 4;
    if ($days <= 155) return 5;
    return 6;
}

/* "19th March, 2026" -> DateTime | null */
function att_parse_batch($batch) {
    if (!$batch) return null;
    $clean = preg_replace('/(\d+)(st|nd|rd|th)/i', '$1', trim($batch));
    try { return new DateTime($clean); } catch (Exception $e) { return null; }
}

/* project submission date — 1mo=day25, 2mo=day55, 3mo=day85 ... (25 + (m-1)*30),
   counting the batch day itself as day 1 */
function att_submission_date($start, $months) {
    if (!$start || $months < 1) return null;
    $dayNo = 25 + ($months - 1) * 30;
    $d = clone $start;
    $d->modify('+' . ($dayNo - 1) . ' days');
    return $d->format('Y-m-d');
}

/* core: day-by-day attendance for one user over [start, start + durationDays) */
function att_compute($conn, $user_id, DateTime $start, $durationDays) {
    $end = clone $start;
    $end->modify('+' . ($durationDays - 1) . ' days');
    $startStr = $start->format('Y-m-d');
    $endStr   = $end->format('Y-m-d');
    /* Force the MySQL session to IST so CURDATE() and DATE(login_date) /
       DATE(attendance_date) all interpret "today" in the same timezone the user
       experiences — otherwise a UTC-defaulted server pushes today into
       "future" and silently drops today's marking from the count. Belt and
       braces: also derive today from PHP with an explicit IST timezone so
       the cutoff stays correct even if SET time_zone fails silently. */
    $conn->query("SET time_zone = '+05:30'");
    $todayStr = (new DateTime('now', new DateTimeZone('Asia/Kolkata')))->format('Y-m-d');

    /* bulk: login dates in the window */
    $loginSet = [];
    $st = $conn->prepare("SELECT DISTINCT DATE(login_date) d FROM user_login_activity
                          WHERE user_id = ? AND DATE(login_date) BETWEEN ? AND ? AND activity_level >= 1");
    $st->bind_param('iss', $user_id, $startStr, $endStr);
    $st->execute();
    $r = $st->get_result();
    while ($row = $r->fetch_assoc()) $loginSet[$row['d']] = true;
    $st->close();

    /* bulk: attendance_log dates in the window (matched on attendance_date) */
    $attSet = [];
    $st = $conn->prepare("SELECT DISTINCT DATE(attendance_date) d FROM attendance_log
                          WHERE user_id = ? AND DATE(attendance_date) BETWEEN ? AND ?");
    $st->bind_param('iss', $user_id, $startStr, $endStr);
    $st->execute();
    $r = $st->get_result();
    while ($row = $r->fetch_assoc()) $attSet[$row['d']] = true;
    $st->close();

    $days = []; $present = 0; $absent = 0; $future = 0;
    $cur = clone $start;
    for ($i = 0; $i < $durationDays; $i++) {
        $ds = $cur->format('Y-m-d');
        /* String compare on YYYY-MM-DD avoids any DateTime timezone-offset
           subtleties — today is past (evaluable), strictly later dates are
           future. */
        if ($ds > $todayStr) {
            $status = 'future'; $future++;
        } else {
            $inLogin = isset($loginSet[$ds]);
            if ($ds < ATT_CUTOFF) {
                $isPresent = $inLogin;                          // old rule
            } else {
                $isPresent = $inLogin && isset($attSet[$ds]);   // dual-table rule
            }
            if ($isPresent) { $status = 'present'; $present++; }
            else            { $status = 'absent';  $absent++;  }
        }
        $days[] = ['date' => $ds, 'status' => $status];
        $cur->modify('+1 day');
    }
    /* percentage is against the FULL duration (e.g. 30 days = 100%), not elapsed days */
    $pct = $durationDays > 0 ? round($present / $durationDays * 100, 1) : 0;
    return compact('days', 'present', 'absent', 'future', 'pct');
}

/* build a row from one internship_payment record + user info */
function att_build_row($conn, $user, $p, $withDays = false) {
    $months = att_months($p['total_duration'] ?? 0);
    $start  = att_parse_batch($p['batch'] ?? '');

    $row = [
        'payment_id'              => (int)$p['id'],
        'user_id'                 => (int)$user['user_id'],
        'name'                    => $user['name'],
        'email'                   => $user['email'],
        'phone'                   => $user['phone'],
        'internship_name'         => $p['internship'],
        'batch'                   => $p['batch'],
        'batch_start'             => $start ? $start->format('Y-m-d') : null,
        'paid_at'                 => $p['paid_at'],
        'duration_months'         => $months,
        'duration_days'           => $months * 30,
        'attendance_pct'          => 0,
        'present'                 => 0,
        'absent'                  => 0,
        'future'                  => 0,
        'project_submission_date' => null,
    ];
    if ($start && $months > 0) {
        $c = att_compute($conn, (int)$user['user_id'], $start, $months * 30);
        $row['attendance_pct']          = $c['pct'];
        $row['present']                 = $c['present'];
        $row['absent']                  = $c['absent'];
        $row['future']                  = $c['future'];
        $row['project_submission_date'] = att_submission_date($start, $months);
        if ($withDays) $row['days'] = $c['days'];
    }
    return $row;
}

/* one row per refund='yes' internship_payment for a user */
function att_rows_for_user($conn, $user_id) {
    $st = $conn->prepare("SELECT user_id, name, email, phone FROM users WHERE user_id = ? LIMIT 1");
    $st->bind_param('i', $user_id);
    $st->execute();
    $user = $st->get_result()->fetch_assoc();
    $st->close();
    if (!$user) return [];

    $pst = $conn->prepare("SELECT id, batch, paid_at, internship, total_duration
                           FROM internship_payment
                           WHERE user_id = ? AND refund = 'yes'
                           ORDER BY paid_at DESC");
    $pst->bind_param('i', $user_id);
    $pst->execute();
    $pres = $pst->get_result();
    $rows = [];
    while ($p = $pres->fetch_assoc()) $rows[] = att_build_row($conn, $user, $p, false);
    $pst->close();
    return $rows;
}

/* ════════ ROUTING ════════ */
$action = $_GET['action'] ?? 'list';

/* ── recent 15 users who have attendance_log entries ── */
if ($action === 'list') {
    $res = $conn->query("SELECT user_id, MAX(marked_at) lm
                         FROM attendance_log
                         GROUP BY user_id
                         ORDER BY lm DESC
                         LIMIT 15");
    $out = [];
    if ($res) while ($r = $res->fetch_assoc()) {
        foreach (att_rows_for_user($conn, (int)$r['user_id']) as $row) $out[] = $row;
    }
    api_success(['records' => $out]);
}

/* ── search by email / phone — EXACT match so the index is used (fast) ── */
if ($action === 'search') {
    $q = trim($_GET['q'] ?? '');
    if ($q === '') api_error('Search query required', 400);

    if (strpos($q, '@') !== false) {
        $st = $conn->prepare("SELECT DISTINCT user_id FROM users WHERE email = ? LIMIT 20");
    } else {
        $st = $conn->prepare("SELECT DISTINCT user_id FROM users WHERE phone = ? LIMIT 20");
    }
    $st->bind_param('s', $q);
    $st->execute();
    $ids = $st->get_result();
    $out = [];
    while ($r = $ids->fetch_assoc()) {
        foreach (att_rows_for_user($conn, (int)$r['user_id']) as $row) $out[] = $row;
    }
    $st->close();
    api_success(['records' => $out]);
}

/* ── full calendar for one internship payment ── */
if ($action === 'calendar') {
    $payment_id = (int)($_GET['payment_id'] ?? 0);
    if (!$payment_id) api_error('payment_id required', 400);

    $st = $conn->prepare("SELECT ip.id, ip.user_id, ip.batch, ip.paid_at, ip.internship, ip.total_duration,
                                 u.name, u.email, u.phone
                          FROM internship_payment ip
                          JOIN users u ON u.user_id = ip.user_id
                          WHERE ip.id = ? LIMIT 1");
    $st->bind_param('i', $payment_id);
    $st->execute();
    $p = $st->get_result()->fetch_assoc();
    $st->close();
    if (!$p) api_error('Payment not found', 404);

    $user = ['user_id' => $p['user_id'], 'name' => $p['name'], 'email' => $p['email'], 'phone' => $p['phone']];
    $cal  = att_build_row($conn, $user, $p, true);
    if (!isset($cal['days'])) $cal['days'] = [];
    api_success(['calendar' => $cal]);
}

/* ════════════════════════════════════════════════════════════
   MANUAL DAY TOGGLE (admin)
   ?action=day     (GET)  -> what exists for one user+date in BOTH tables
   ?action=toggle  (POST) -> apply / remove attendance for one user+date

   "Present" needs a user_login_activity row AND (on/after ATT_CUTOFF) an
   attendance_log row, so applying inserts whichever of the two is missing and
   SKIPS the one that is already there; removing deletes both.
════════════════════════════════════════════════════════════ */

/* note written into attendance_log when an admin marks the day by hand */
define('ATT_ADMIN_NOTE', 'Attendance marked manually by the Internship Studio admin team from the admin panel.');

/* payment + user + batch window for one internship_payment row (api_error if unusable) */
function att_load_payment($conn, $payment_id) {
    $st = $conn->prepare("SELECT ip.id, ip.user_id, ip.batch, ip.internship, ip.total_duration,
                                 u.name, u.email
                          FROM internship_payment ip
                          JOIN users u ON u.user_id = ip.user_id
                          WHERE ip.id = ? LIMIT 1");
    $st->bind_param('i', $payment_id);
    $st->execute();
    $p = $st->get_result()->fetch_assoc();
    $st->close();
    if (!$p) api_error('Payment not found', 404);

    $months = att_months($p['total_duration'] ?? 0);
    $start  = att_parse_batch($p['batch'] ?? '');
    if (!$start || $months < 1) api_error('This user has no batch / duration data, so days cannot be edited', 400);

    $end = clone $start;
    $end->modify('+' . ($months * 30 - 1) . ' days');

    return [
        'id'         => (int)$p['id'],
        'user_id'    => (int)$p['user_id'],
        'name'       => $p['name'],
        'email'      => $p['email'],
        'internship' => $p['internship'],
        'start'      => $start->format('Y-m-d'),
        'end'        => $end->format('Y-m-d'),
    ];
}

/* validate a posted date against the batch window and today (api_error if unusable) */
function att_validate_date($date, $pay) {
    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', (string)$date)) api_error('A valid date (YYYY-MM-DD) is required', 400);
    $today = (new DateTime('now', new DateTimeZone('Asia/Kolkata')))->format('Y-m-d');
    if ($date > $today)        api_error('Attendance cannot be changed for a future date', 400);
    if ($date < $pay['start']) api_error('That date is before the batch start date', 400);
    if ($date > $pay['end'])   api_error('That date is after the internship duration ends', 400);
    return $date;
}

/* what already exists for this user on this date, in each of the two tables */
function att_day_flags($conn, $user_id, $date) {
    $conn->query("SET time_zone = '+05:30'");

    $st = $conn->prepare("SELECT COUNT(*) c FROM user_login_activity
                          WHERE user_id = ? AND DATE(login_date) = ? AND activity_level >= 1");
    $st->bind_param('is', $user_id, $date);
    $st->execute();
    $hasLogin = (int)$st->get_result()->fetch_assoc()['c'] > 0;
    $st->close();

    $st = $conn->prepare("SELECT COUNT(*) c FROM attendance_log
                          WHERE user_id = ? AND DATE(attendance_date) = ?");
    $st->bind_param('is', $user_id, $date);
    $st->execute();
    $hasAtt = (int)$st->get_result()->fetch_assoc()['c'] > 0;
    $st->close();

    /* same present-day rule the calendar uses */
    $isPresent = ($date < ATT_CUTOFF) ? $hasLogin : ($hasLogin && $hasAtt);

    return [
        'date'           => $date,
        'has_login'      => $hasLogin,
        'has_attendance' => $hasAtt,
        'is_present'     => $isPresent,
        'legacy_rule'    => $date < ATT_CUTOFF,
    ];
}

/* ── what exists for one user+date (drives the confirmation popup) ── */
if ($action === 'day') {
    $pay  = att_load_payment($conn, (int)($_GET['payment_id'] ?? 0));
    $date = att_validate_date($_GET['date'] ?? '', $pay);
    $f    = att_day_flags($conn, $pay['user_id'], $date);

    api_success(['day' => $f + [
        'user_id'         => $pay['user_id'],
        'name'            => $pay['name'],
        'email'           => $pay['email'],
        'internship_name' => $pay['internship'],
        'next_action'     => $f['is_present'] ? 'remove' : 'apply',
    ]]);
}

/* ── apply / remove attendance for one user+date ── */
if ($action === 'toggle') {
    require_method('POST');
    $in = get_json_input();

    $pay  = att_load_payment($conn, (int)($in['payment_id'] ?? 0));
    $date = att_validate_date($in['date'] ?? '', $pay);
    $mode = ($in['mode'] ?? '');
    if ($mode !== 'apply' && $mode !== 'remove') api_error('mode must be "apply" or "remove"', 400);

    $uid    = $pay['user_id'];
    $before = att_day_flags($conn, $uid, $date);

    /* the popup was built from `before` — refuse if the day changed underneath it */
    if ($mode === 'apply' && $before['is_present']) {
        api_error('Attendance is already applied for ' . $date, 409);
    }
    if ($mode === 'remove' && !$before['has_login'] && !$before['has_attendance']) {
        api_error('There is no attendance record to remove for ' . $date, 409);
    }

    $done    = [];
    $skipped = [];

    if ($mode === 'apply') {
        /* 1) user_login_activity — skipped when a row is already there */
        if ($before['has_login']) {
            $skipped[] = 'user_login_activity (row already exists)';
        } else {
            $st = $conn->prepare("INSERT INTO user_login_activity (user_id, login_date, activity_level)
                                  VALUES (?, ?, 1)");
            $st->bind_param('is', $uid, $date);
            if (!$st->execute()) { $e = $st->error; $st->close(); api_error('Could not insert login activity: ' . $e, 500); }
            $st->close();
            $done[] = 'user_login_activity';
        }

        /* 2) attendance_log — attendance_date AND marked_at both carry the SELECTED date */
        if ($before['has_attendance']) {
            $skipped[] = 'attendance_log (row already exists)';
        } else {
            $note     = ATT_ADMIN_NOTE;
            $chars    = mb_strlen($note);
            $markedAt = $date . ' 00:00:00';
            $ip       = get_client_ip();
            $ua       = 'admin-panel';
            $st = $conn->prepare("INSERT INTO attendance_log
                                    (user_id, internship_id, attendance_date, note, character_count,
                                     marked_at, ip_address, user_agent)
                                  VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
            $st->bind_param('iississs', $uid, $pay['id'], $date, $note, $chars, $markedAt, $ip, $ua);
            if (!$st->execute()) {
                $dup = ($conn->errno === 1062);
                $e   = $st->error;
                $st->close();
                if (!$dup) api_error('Could not insert attendance log: ' . $e, 500);
                $skipped[] = 'attendance_log (row already exists)';
            } else {
                $st->close();
                $done[] = 'attendance_log';
            }
        }
    } else {
        /* remove — drop whatever exists in either table for that date */
        if ($before['has_attendance']) {
            $st = $conn->prepare("DELETE FROM attendance_log WHERE user_id = ? AND DATE(attendance_date) = ?");
            $st->bind_param('is', $uid, $date);
            if (!$st->execute()) { $e = $st->error; $st->close(); api_error('Could not delete attendance log: ' . $e, 500); }
            $st->close();
            $done[] = 'attendance_log';
        } else {
            $skipped[] = 'attendance_log (nothing to delete)';
        }

        if ($before['has_login']) {
            $st = $conn->prepare("DELETE FROM user_login_activity WHERE user_id = ? AND DATE(login_date) = ?");
            $st->bind_param('is', $uid, $date);
            if (!$st->execute()) { $e = $st->error; $st->close(); api_error('Could not delete login activity: ' . $e, 500); }
            $st->close();
            $done[] = 'user_login_activity';
        } else {
            $skipped[] = 'user_login_activity (nothing to delete)';
        }
    }

    $after = att_day_flags($conn, $uid, $date);

    api_success([
        'date'    => $date,
        'mode'    => $mode,
        'done'    => $done,
        'skipped' => $skipped,
        'before'  => $before,
        'after'   => $after,
    ], $mode === 'apply' ? 'Attendance applied for ' . $date : 'Attendance removed for ' . $date);
}

api_error('Unknown action', 400);

<?php
/*
 * lib/EspRateLimiter.php — a sends-PER-SECOND ceiling that every worker, on every machine, shares.
 *
 * WHY THIS EXISTS
 * Amazon SES allows a fixed number of sends per second (14 on this account) and refuses the rest
 * with "429 Maximum sending rate exceeded". The worker used to limit SES by CONCURRENCY — 14
 * requests in flight at once — on the reasoning that concurrency is roughly a rate. It is not: an
 * SES call answers in about 70ms, so 14 in flight is about 200 sends a second. Campaigns #100 and
 * #101 went out at 199/s and 204/s, a third of every batch came back throttled, and the failover
 * read the throttling as a spent quota and moved both campaigns to Elastic Email.
 *
 * WHY IT IS SHARED
 * The same campaign is worked by two processes on two machines: the HTTP kick on cit3 when Send is
 * pressed, and the cron on the monitoring box every minute. Each pacing itself to 11/s would still
 * be 22/s at SES. So the slots are handed out from one row in the database, which both can see.
 *
 * WHY IT USES THE DATABASE CLOCK
 * The two machines' clocks disagree. A slot is therefore reserved on MySQL's clock and handed back
 * as "this many seconds from now", which each process applies to its own clock.
 *
 * If the database cannot be used for this (the table cannot be created, a lock times out) the
 * limiter falls back to pacing this process alone rather than not pacing at all.
 */

if (!function_exists('esp_rate_ensure_schema')) {
    function esp_rate_ensure_schema(): void {
        global $conn;
        static $done = false;
        if ($done) return;
        $conn->query("CREATE TABLE IF NOT EXISTS esp_send_rate (
            provider  VARCHAR(32)    NOT NULL PRIMARY KEY,
            next_at   DECIMAL(17,6)  NOT NULL DEFAULT 0
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        $done = true;
    }
}

class EspRateLimiter {
    private string $provider;
    private float  $rate;
    /** Local microtime() stamps already reserved for this process, earliest first. */
    private array  $slots = [];
    private bool   $shared = true;
    private float  $localNext = 0.0;

    public function __construct(string $provider, float $ratePerSecond) {
        $this->provider = $provider;
        $this->rate = max(0.1, $ratePerSecond);
    }

    public function rate(): float { return $this->rate; }

    /** The local microtime() at which the next send may start. Each call uses up one slot. */
    public function take(): float {
        if (!$this->slots) $this->reserve();
        return (float)array_shift($this->slots);
    }

    /** Reserves one second's worth of slots, after every slot any other worker already holds. */
    private function reserve(): void {
        global $conn;
        $n    = max(1, (int)floor($this->rate));
        $step = 1.0 / $this->rate;

        if ($this->shared) {
            $inTx = false;
            try {
                esp_rate_ensure_schema();
                $p = $conn->real_escape_string($this->provider);
                $conn->query("INSERT IGNORE INTO esp_send_rate (provider, next_at) VALUES ('$p', 0)");
                $conn->begin_transaction();
                $inTx = true;
                $r = $conn->query("SELECT next_at, UNIX_TIMESTAMP(NOW(6)) AS db_now
                                     FROM esp_send_rate WHERE provider = '$p' FOR UPDATE");
                $row   = $r ? $r->fetch_assoc() : null;
                $dbNow = (float)($row['db_now'] ?? 0);
                $held  = (float)($row['next_at'] ?? 0);
                // A reservation more than a minute ahead cannot be real traffic — at most a few
                // workers each hold a second. Treat it as a leftover and start from now.
                if ($held > $dbNow + 60) $held = $dbNow;
                $start = max($held, $dbNow);
                $conn->query("UPDATE esp_send_rate SET next_at = " . sprintf('%.6F', $start + $n * $step)
                           . " WHERE provider = '$p'");
                $conn->commit();
                $inTx = false;

                $base = microtime(true) + ($start - $dbNow);
                for ($i = 0; $i < $n; $i++) $this->slots[] = $base + $i * $step;
                return;
            } catch (Throwable $e) {
                if ($inTx) { try { $conn->rollback(); } catch (Throwable $e2) {} }
                $this->shared = false;
                if (function_exists('campaign_log')) {
                    campaign_log('rate limiter: shared pacing unavailable, pacing this process only — ' . $e->getMessage());
                }
            }
        }

        $start = max($this->localNext, microtime(true));
        for ($i = 0; $i < $n; $i++) $this->slots[] = $start + $i * $step;
        $this->localNext = $start + $n * $step;
    }
}

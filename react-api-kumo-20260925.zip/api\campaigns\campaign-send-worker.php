<?php
/*
 * Cron / instant-kick entrypoint for the campaign batch sender.
 *
 * Cron (reliable safety-net — runs every minute once set up):
 *   * * * * * /usr/local/bin/php /home/istudio/public_html/admin/react-api/api/campaigns/campaign-send-worker.php >> /home/istudio/logs/campaign-worker.log 2>&1
 *
 * HTTP fallback (used internally by trigger_worker_async() for the instant
 * "Send Now" kick — requires the shared cron_secret, NOT a public endpoint):
 *   GET .../campaign-send-worker.php?cron_secret=...&campaign_id=123
 */
ini_set('display_errors', 0);
error_reporting(E_ALL & ~E_WARNING & ~E_NOTICE & ~E_DEPRECATED);
$_SERVER['REQUEST_METHOD'] = $_SERVER['REQUEST_METHOD'] ?? 'CLI';

// Kept permanently (not just for the one debugging session that found it): PHP 8.1+ made
// mysqli throw a mysqli_sql_exception on connection failure by default, instead of the old
// silent ->connect_error behavior config/database.php's own check assumes. With display_errors
// off, an uncaught exception here would vanish with zero trace — this is what caused every
// cron-invoked script to die completely silently the moment the DB host was misconfigured for
// the CLI environment (see database.php's own comment on DB_HOST for the actual root cause).
try {
    require_once __DIR__ . '/../../config/database.php';
} catch (\Throwable $e) {
    @file_put_contents(__DIR__ . '/worker.log', '[' . date('Y-m-d H:i:s') . '] FATAL — could not connect to the database: '
        . '[' . get_class($e) . '] ' . $e->getMessage() . "\n", FILE_APPEND | LOCK_EX);
    exit;
}

require_once __DIR__ . '/lib/config.php';
require_once __DIR__ . '/lib/schema.php';
require_once __DIR__ . '/lib/SendWorker.php';
require_once __DIR__ . '/lib/ConversionTracker.php';
require_once __DIR__ . '/../attributes/lib/schema.php';
campaigns_ensure_schema();
attributes_ensure_schema();

$isCli = (php_sapi_name() === 'cli');
$isAuthorizedHttp = !$isCli && ($_GET['cron_secret'] ?? '') === CRON_SECRET;
if (!$isCli && !$isAuthorizedHttp) {
    http_response_code(403);
    echo "forbidden\n";
    exit;
}

$campaignId = isset($_GET['campaign_id']) ? (int)$_GET['campaign_id'] : null;
if ($isCli && isset($argv[1])) $campaignId = (int)$argv[1];

// Logged here (not just via campaigns_process_batch's internal lines) so a run that
// never gets past the lock check below still leaves a trace — this file is the one
// place that proves whether the cron tick AND the instant "Send Now" kick actually
// fired, since the instant kick's HTTP response is otherwise fire-and-forget and
// discarded by trigger_worker_async() (nothing else ever reads it).
campaign_log('worker invoked via ' . ($isCli ? 'CLI (cron)' : 'HTTP (instant Send Now kick)')
    . ($campaignId ? ", campaign_id=$campaignId" : ', no specific campaign_id (cron sweep)'));

// Exclusive lock — prevents an overlapping cron tick (or a tick racing an instant kick) from double-sending.
/*
 * THE LOCK THAT ACTUALLY SPANS MACHINES.
 *
 * The flock below is kept — it is cheap and it settles the common case of two ticks on the same
 * box — but on its own it was never enough. This worker runs in two places: a cron on the
 * monitoring server and an HTTP kick to cit3 from trigger_worker_async(). Each takes a lock on a
 * file in its own temp directory, so each is convinced it is the only one running, and campaign
 * #91 went out to 8,736 people twice.
 *
 * GET_LOCK is held by the DATABASE, which is the one thing both machines share. Timeout 0, so a
 * second worker leaves immediately rather than queueing up behind a ten-minute campaign and then
 * starting a redundant run the moment it finishes.
 *
 * The connection releases it automatically when this process ends, however it ends — which is the
 * property that matters, because a worker killed mid-run must not leave every later run locked
 * out. (The claim token in SendWorker.php is what makes double-sending impossible even if this
 * lock were somehow bypassed; this one exists so two workers do not burn CPU racing each other.)
 */
/*
 * Deliver alerts cit3 raised but cannot send (it has no Slack or mail settings). Before the lock
 * on purpose: while cit3 holds the lock for a long send, this minute's run leaves at the lock —
 * and the alert about that very send would otherwise wait for it to finish. A no-op on cit3.
 */
try { alert_outbox_flush(); } catch (Throwable $e) { /* never stops a send */ }

/*
 * The mail server's own bounce reports, turned into blocklist entries.
 *
 * Free, and more accurate than any paid check: a 5.x.x answer from Gmail is the mailbox itself
 * saying it does not exist. Reads what the Freshdesk sync has already imported from contact@, so
 * it costs one indexed query when there is nothing new. Outside the worker lock on purpose — it
 * writes to lists, never to a campaign, and must run even while a long send holds the lock.
 */
try {
    require_once __DIR__ . '/lib/BounceMailbox.php';
    $bounce = bounce_mailbox_scan();
    if ($bounce['messages'] > 0) {
        campaign_log("bounce mailbox: read {$bounce['messages']} report(s), {$bounce['hard']} permanent, "
            . "{$bounce['soft']} temporary, {$bounce['blocklisted']} address(es) blocklisted");
    }
} catch (Throwable $e) {
    campaign_log('bounce mailbox scan skipped — ' . $e->getMessage());
}

$gotDbLock = false;
$lr = $conn->query("SELECT GET_LOCK('istudio_campaign_send_worker', 0) AS got");
if ($lr && $row = $lr->fetch_assoc()) $gotDbLock = ((int)$row['got'] === 1);
if (!$gotDbLock) {
    // Normal and frequent: the cron fires every minute and a long campaign spans many minutes.
    exit;
}

$lockPath = sys_get_temp_dir() . '/campaign_worker.lock';
$lockFp = fopen($lockPath, 'c');
if (!$lockFp || !flock($lockFp, LOCK_EX | LOCK_NB)) {
    campaign_log('skip — another worker run is already in progress');
    exit;
}

// No execution-time ceiling on this run. Cron invokes it via CLI where max_execution_time is
// normally already 0, but the instant "Send Now" kick arrives over HTTP, where the default
// 30s would kill the run mid-campaign and leave a block of recipients stuck in 'processing'.
@set_time_limit(0);
ignore_user_abort(true);

/*
 * Keep pulling batches until the queue is empty or the time budget runs out, instead of
 * doing exactly one batch and waiting for the next cron minute.
 *
 * That one-batch-per-tick design was the second throughput ceiling: even after making the
 * sends themselves concurrent, a campaign could only ever drain CAMPAIGN_SEND_BATCH_SIZE
 * recipients per minute. Looping here is safe specifically because of the flock() above —
 * cron ticks that land while this run is still going simply no-op instead of double-sending.
 */
/*
 * Before anything is claimed: make sure the claim columns exist, and free any row a previous
 * worker died holding. Both are cheap and both have to happen while this run owns the lock —
 * requeueing a row another worker is mid-flight on is the double-send this change exists to stop.
 */
campaign_claim_ensure_schema();
campaign_requeue_stale_claims();

$deadline = microtime(true) + WORKER_MAX_RUNTIME_SECONDS;
$result = ['processed' => 0, 'sent' => 0, 'failed' => 0, 'campaigns' => 0];
$rounds = 0;

do {
    $round = campaigns_process_batch(CAMPAIGN_SEND_BATCH_SIZE, $campaignId);
    $rounds++;
    $result['processed'] += $round['processed'];
    $result['sent']      += $round['sent'];
    $result['failed']    += $round['failed'];
    $result['campaigns']  = $round['campaigns'];
    // Nothing claimed means every running campaign is drained (or none are running) — stop
    // rather than spinning through the campaign lookup until the deadline for no reason.
    if ($round['processed'] === 0) break;
} while (microtime(true) < $deadline);

campaign_log("run finished after $rounds batch round(s): " . json_encode($result)
    . (microtime(true) >= $deadline ? ' — hit the ' . WORKER_MAX_RUNTIME_SECONDS . 's budget, the next cron tick picks up the rest' : ''));

// Cheap — only queries campaigns actually 'sent' with a goal event configured and still
// inside their window, so this runs safely on every tick alongside the send batch above.
campaigns_recompute_conversions();

flock($lockFp, LOCK_UN);
fclose($lockFp);

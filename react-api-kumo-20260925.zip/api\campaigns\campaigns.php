<?php
/*
 * /api/campaigns/campaigns.php
 *
 * action=list            &page &per_page &status &search   → paginated list + per-status tab counts
 * action=get              &id                              → full campaign row
 * action=save      [&id]  &name &tags &... (see $fields)    → create/update (autosave from the wizard)
 * action=delete           &id
 * action=duplicate        &id
 * action=tags                                                → distinct tags used across all campaigns
 * action=domains                                              → distinct sending domains (campaigns + ESP defaults)
 * action=audience_count   &audience_type &segment_ids(json) &list_ids(json) &exclude_segment_ids(json) &exclude_list_ids(json) &domain_filter
 * action=audience_export  (same audience params) [&name]                     → the resolved audience as a CSV
 * action=upload_attachment &id &file (multipart)              → attach a file, max 5MB/file, 15MB/campaign
 * action=remove_attachment &id &stored_name
 * action=send_test        &id &emails (comma/newline separated)
 * action=send_now         &id
 * action=schedule         &id &scheduled_at
 * action=pause            &id   → suspend a draft/scheduled/running campaign
 * action=resume           &id   → un-suspend
 * action=requeue          &id   → retry failed recipients
 * action=report           &id &page &per_page               → stats + recent tracking events
 * action=conversions      &id &page &per_page &search [&export=1] → who converted on the campaign's goal
 * action=conversion_detail &id &user_id                     → one converted user: profile + raw goal-event rows
 */
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../middleware/auth.php';
require_once __DIR__ . '/lib/config.php';
require_once __DIR__ . '/lib/schema.php';
require_once __DIR__ . '/lib/AudienceResolver.php';
require_once __DIR__ . '/lib/SendWorker.php';
require_once __DIR__ . '/lib/ConversionTracker.php';
require_once __DIR__ . '/../lib/S3Uploader.php';

campaigns_ensure_schema();
attributes_ensure_schema();

$jwt = require_jwt();
require_permission('netcore_behaviour', $jwt);

function jin($k, $d = null) { $v = $_REQUEST[$k] ?? null; return ($v === null || $v === '') ? $d : $v; }

/**
 * Refuses to commit a send that would mail people who have already had this campaign.
 *
 * THE SECOND DUPLICATE-SEND PATH, and the one a person can trigger with a single click.
 *
 * send_now and schedule both clear materialized_at, and the worker treats a cleared
 * materialized_at as "resolve the audience". Resolving DELETES every existing recipient row for
 * the campaign and writes the whole audience back as 'pending'. On a campaign that has already
 * gone out that is not a re-send of the stragglers — it is the entire list, again, with the
 * evidence of the first send removed on the way past.
 *
 * Nothing stopped it. A campaign sitting at 'sent' accepted Send Now and mailed everybody twice,
 * which is the same damage as the worker race and needed its own answer: that race was a bug in
 * the machinery, this is a missing question.
 *
 * What IS allowed:
 *   draft, scheduled  nothing has gone out; scheduled is also how you move the time
 *   failed            the completion rule only marks a campaign failed when ZERO sends
 *                     succeeded, so there is nobody to mail twice
 *
 * Suspended is sent on with Resume, which continues the queue in place instead of rebuilding it.
 */
function campaign_block_resend(array $campaign, string $verb): void {
    $status = (string)($campaign['status'] ?? '');
    $sent   = (int)($campaign['sent_count'] ?? 0);

    if ($status === 'running') {
        api_error('This campaign is sending right now. Wait for it to finish, or suspend it first.');
    }
    if ($status === 'suspended') {
        api_error('This campaign is suspended. Use Resume to carry on with the recipients it has not reached '
            . '— ' . $verb . ' would start the whole audience again from the beginning.');
    }
    if ($status === 'sent' || $sent > 0) {
        api_error('This campaign has already gone out to ' . number_format($sent) . ' recipient(s). '
            . ucfirst($verb) . ' would send it to the entire audience a second time. '
            . 'Duplicate it instead if you mean to run it again.');
    }
}

/** Display name for a stored esp_transport value, for messages a human reads. */
function esp_provider_label(string $provider): string {
    $labels = ['sendgrid' => 'SendGrid', 'elasticemail' => 'Elastic Email', 'ses' => 'Amazon SES'];
    return $labels[$provider] ?? ($provider !== '' ? $provider : 'the sender');
}

/** The provider a campaign sends through: its own, or the Settings active sender when it names
 *  nothing usable (a draft from before the Content step had a "Send through" picker). */
function campaign_transport(array $campaign): string {
    $p = (string)($campaign['esp_transport'] ?? '');
    return in_array($p, TransportFactory::PROVIDERS, true) ? $p : TransportFactory::activeProvider();
}

function validate_campaign_for_send(array $campaign): array {
    global $conn;
    $blocking = [];
    if (empty($campaign['subject']))        $blocking[] = 'Subject is empty';
    if (empty($campaign['content_html']))   $blocking[] = 'No template selected';
    if (empty($campaign['sender_email']))   $blocking[] = 'Sender email is not set';
    if (empty($campaign['sending_domain'])) $blocking[] = 'Sending domain is not set';

    /*
     * The campaign now names its OWN sender (the Content step's "Send through" picker), so it can
     * be pointed at a provider nobody has finished setting up. That used to be impossible — every
     * send went through whichever provider Settings had flagged active, and that one was
     * configured by definition. Caught here rather than at send time, where it would surface as
     * every single recipient failing with an authentication error.
     */
    $provider = campaign_transport($campaign);
    $pe = $conn->real_escape_string($provider);
    $pr = $conn->query("SELECT api_key FROM email_esp_settings WHERE provider='$pe' LIMIT 1");
    $prow = $pr ? $pr->fetch_assoc() : null;
    if (!$prow || trim((string)$prow['api_key']) === '') {
        $blocking[] = esp_provider_label($provider) . ' has no API key saved — open Settings and finish setting it up, or pick another sender on the Content step';
    }

    $cfg = [
        'audience_type'       => $campaign['audience_type'],
        'segment_ids'         => json_decode($campaign['segment_ids'] ?? '[]', true) ?: [],
        'exclude_segment_ids' => json_decode($campaign['exclude_segment_ids'] ?? '[]', true) ?: [],
        'exclude_list_ids'    => json_decode($campaign['exclude_list_ids'] ?? '[]', true) ?: [],
        'list_ids'            => json_decode($campaign['list_ids'] ?? '[]', true) ?: [],
        'domain_filter'       => $campaign['domain_filter'],
    ];
    $count = resolve_audience_count($cfg);
    if ($count === 0) $blocking[] = 'Audience has 0 reachable contacts';
    return ['blocking' => $blocking, 'count' => $count];
}

$action = jin('action', '');

if ($action === 'list') {
    $page    = max(1, (int)jin('page', 1));
    $perPage = max(1, min(100, (int)jin('per_page', 10)));
    $status  = jin('status', 'all');
    $search  = trim((string)jin('search', ''));
    $offset  = ($page - 1) * $perPage;

    $where = [];
    if ($status !== 'all' && $status !== '') $where[] = "status='" . $conn->real_escape_string($status) . "'";
    if ($search !== '') $where[] = "name LIKE '%" . $conn->real_escape_string($search) . "%'";
    $whereSql = $where ? 'WHERE ' . implode(' AND ', $where) : '';

    $tr = $conn->query("SELECT COUNT(*) AS c FROM email_campaigns $whereSql");
    $total = $tr ? (int)$tr->fetch_assoc()['c'] : 0;

    $r = $conn->query("SELECT id, name, tags, status, campaign_type, esp_transport, total_recipients, sent_count,
                               delivered_count, open_count, unique_open_count, click_count, unique_click_count,
                               bounce_count, hard_bounce_count, soft_bounce_count, unsubscribe_count, spam_count,
                               goal_event_name, conversion_count, schedule_type, scheduled_at, started_at, completed_at,
                               created_at, updated_at
                        FROM email_campaigns $whereSql
                        ORDER BY id DESC LIMIT $perPage OFFSET $offset");
    $rows = [];
    while ($r && $row = $r->fetch_assoc()) {
        /*
         * Belt to the braces in DeliveryReceipts.php: a running campaign is a moving target, and
         * no arrangement of counters should ever let this screen claim more delivered than sent.
         * Clamped for display only — the stored numbers are left exactly as they are.
         */
        $row['delivered_count'] = (string)min((int)$row['delivered_count'], (int)$row['sent_count']);
        $rows[] = $row;
    }

    $counts = ['all' => 0, 'draft' => 0, 'scheduled' => 0, 'running' => 0, 'sent' => 0, 'suspended' => 0, 'failed' => 0];
    $cr = $conn->query("SELECT status, COUNT(*) AS c FROM email_campaigns GROUP BY status");
    while ($cr && $row = $cr->fetch_assoc()) { $counts[$row['status']] = (int)$row['c']; $counts['all'] += (int)$row['c']; }

    api_success([
        'campaigns' => $rows, 'total' => $total, 'page' => $page, 'per_page' => $perPage,
        'pages' => $total > 0 ? (int)ceil($total / $perPage) : 1, 'counts' => $counts,
    ]);
}

if ($action === 'get') {
    $id = (int)jin('id', 0);
    $r = $conn->query("SELECT * FROM email_campaigns WHERE id=$id LIMIT 1");
    $row = $r ? $r->fetch_assoc() : null;
    if (!$row) api_error('Not found', 404);
    $row['segment_ids'] = json_decode($row['segment_ids'] ?? '[]', true) ?: [];
    $row['exclude_segment_ids'] = json_decode($row['exclude_segment_ids'] ?? '[]', true) ?: [];
    $row['exclude_list_ids'] = json_decode($row['exclude_list_ids'] ?? '[]', true) ?: [];
    $row['list_ids'] = json_decode($row['list_ids'] ?? '[]', true) ?: [];
    $row['attachments'] = json_decode($row['attachments'] ?? '[]', true) ?: [];
    // A campaign made before the Content step had a "Send through" picker can carry an empty or
    // retired esp_transport. Only THEN is the Settings active sender used to fill the blank —
    // overwriting a real stored choice here is what would make the picker look ignored, because
    // the wizard reloads the draft and would read Settings' answer back over the admin's.
    if (!in_array((string)($row['esp_transport'] ?? ''), TransportFactory::PROVIDERS, true)) {
        $row['esp_transport'] = TransportFactory::activeProvider();
    }
    api_success(['campaign' => $row]);
}

if ($action === 'save') {
    $id   = (int)jin('id', 0);
    $name = trim((string)jin('name', ''));
    if ($id === 0 && $name === '') api_error('Campaign name required');

    $fields = [
        'name' => 's', 'tags' => 's',
        'ga_source' => 's', 'ga_medium' => 's', 'ga_campaign' => 's', 'ga_content' => 's', 'ga_term' => 's',
        'goal_event_name' => 's', 'goal_window_days' => 'i', 'goal_revenue_param' => 's',
        'audience_type' => 's', 'domain_filter' => 's', 'reachable_count' => 'i',
        'sender_name' => 's', 'sender_email' => 's', 'sending_domain' => 's',
        'subject' => 's', 'preheader' => 's', 'reply_to' => 's',
        'exam_cit_version' => 's',
        // Per-campaign address verification. 'i' because the wizard sends 0/1; a campaign that
        // never sends the field keeps its NULL and follows the Settings default.
        'verify_before_send' => 'i',
    ];
    $set = [];
    foreach ($fields as $f => $type) {
        $v = jin($f, null);
        if ($v === null) continue;
        $set[] = $type === 'i' ? "$f=" . (int)$v : "$f='" . $conn->real_escape_string((string)$v) . "'";
    }
    if (jin('segment_ids', null) !== null) {
        $arr = json_decode(jin('segment_ids'), true) ?: [];
        $set[] = "segment_ids='" . $conn->real_escape_string(json_encode(array_values(array_map('intval', $arr)))) . "'";
    }
    if (jin('exclude_segment_ids', null) !== null) {
        $arr = json_decode(jin('exclude_segment_ids'), true) ?: [];
        $set[] = "exclude_segment_ids='" . $conn->real_escape_string(json_encode(array_values(array_map('intval', $arr)))) . "'";
    }
    if (jin('exclude_list_ids', null) !== null) {
        $arr = json_decode(jin('exclude_list_ids'), true) ?: [];
        $set[] = "exclude_list_ids='" . $conn->real_escape_string(json_encode(array_values(array_map('intval', $arr)))) . "'";
    }
    if (jin('list_ids', null) !== null) {
        $arr = json_decode(jin('list_ids'), true) ?: [];
        $set[] = "list_ids='" . $conn->real_escape_string(json_encode(array_values(array_map('intval', $arr)))) . "'";
    }

    // Snapshot the chosen template's HTML into content_html — a later edit to the
    // template won't retroactively change an already-scheduled/sent campaign.
    $templateId = jin('template_id', null);
    if ($templateId !== null) {
        $tid = (int)$templateId;
        if ($tid > 0) {
            $tRes = $conn->query("SELECT body_html FROM campaign_templates WHERE id=$tid LIMIT 1");
            $tRow = $tRes ? $tRes->fetch_assoc() : null;
            if ($tRow) {
                $set[] = "template_id=$tid";
                $set[] = "content_html='" . $conn->real_escape_string($tRow['body_html']) . "'";
            }
        }
    }

    // reachable_count is now just a plain stored field (see $fields above), NOT recomputed
    // here — the Audience step already calculates it live (action=audience_count, debounced)
    // as the user picks segments, and re-running that same heavy query again on every single
    // "Next Step" click (from every step, not just Audience) was the actual cause of multi-
    // second saves. The authoritative recheck still happens right before a real send, in
    // validate_campaign_for_send() (see send_now/schedule below) — so accuracy at the moment
    // that matters is unaffected.

    /*
     * THE CAMPAIGN CHOOSES ITS OWN SENDER.
     *
     * This used to be the opposite: esp_transport was stripped from whatever the wizard sent and
     * replaced with Settings' "Active sender", on the reasoning that the radio there was the only
     * place a transport could be picked. The Content step now has a "Send through" picker, so a
     * campaign built to go out through Amazon SES has to go out through Amazon SES whatever
     * Settings is pointing at this week — otherwise changing the active sender for one campaign
     * silently redirects every other one.
     *
     * Validated against the real provider list rather than trusted: the value reaches an SQL
     * string and an ENUM column, and a campaign carrying a provider nobody can instantiate would
     * fail at send time with nothing on screen explaining why.
     */
    $wantedTransport = trim((string)jin('esp_transport', ''));
    if ($wantedTransport !== '' && in_array($wantedTransport, TransportFactory::PROVIDERS, true)) {
        $set[] = "esp_transport='" . $conn->real_escape_string($wantedTransport) . "'";
    }

    if ($id > 0) {
        if ($set) $conn->query("UPDATE email_campaigns SET " . implode(', ', $set) . " WHERE id=$id");
    } else {
        $set[] = "created_by=" . (int)($jwt['user_id'] ?? 0);
        // Only a campaign that named no provider at all falls back to the Active sender — a
        // brand-new draft whose Content step the admin has not reached yet.
        $hasTransport = false;
        foreach ($set as $s) { if (strpos($s, 'esp_transport=') === 0) { $hasTransport = true; break; } }
        if (!$hasTransport) $set[] = "esp_transport='" . $conn->real_escape_string(TransportFactory::activeProvider()) . "'";
        /* Stamped from PHP, not left to the column's DEFAULT CURRENT_TIMESTAMP: MySQL's clock is
           a different clock (see config/database.php). The unified campaigns list files a draft
           under created_at and a sent campaign under started_at/completed_at, both PHP-written —
           mixing the two put a brand-new draft hours in the past, where "Newest first" hid it. */
        $set[] = "created_at='" . $conn->real_escape_string(date('Y-m-d H:i:s')) . "'";
        $conn->query("INSERT INTO email_campaigns SET " . implode(', ', $set));
        $id = $conn->insert_id;
    }
    // esp_transport is echoed back so the Schedule step's "Sending via" line shows the provider
    // that will really be used — normally the one just picked, and the Active sender only for a
    // draft saved before the Content step named one.
    $r = $conn->query("SELECT reachable_count, status, esp_transport FROM email_campaigns WHERE id=$id LIMIT 1");
    $row = $r ? $r->fetch_assoc() : ['reachable_count' => 0, 'status' => 'draft', 'esp_transport' => 'sendgrid'];
    api_success(['id' => $id, 'reachable_count' => (int)$row['reachable_count'], 'status' => $row['status'], 'esp_transport' => $row['esp_transport']]);
}

if ($action === 'delete') {
    $id = (int)jin('id', 0);
    if (!$id) api_error('id required');
    $conn->query("DELETE FROM email_campaign_events WHERE campaign_id=$id");
    $conn->query("DELETE FROM email_campaign_recipients WHERE campaign_id=$id");
    $conn->query("DELETE FROM email_campaigns WHERE id=$id");
    api_success([]);
}

if ($action === 'duplicate') {
    $id = (int)jin('id', 0);
    $r = $conn->query("SELECT * FROM email_campaigns WHERE id=$id LIMIT 1");
    $row = $r ? $r->fetch_assoc() : null;
    if (!$row) api_error('Not found', 404);

    // list_ids is copied too. Leaving it out gave the copy of a list-addressed campaign an empty
    // audience, which then resolved to zero recipients with nothing on screen explaining why.
    $cols = ['name', 'tags', 'campaign_type', 'ga_source', 'ga_medium', 'ga_campaign', 'ga_content', 'ga_term',
             'goal_event_name', 'goal_window_days', 'goal_revenue_param', 'audience_type', 'segment_ids',
             'exclude_segment_ids', 'exclude_list_ids', 'list_ids', 'domain_filter', 'sender_name', 'sender_email', 'sending_domain', 'subject',
             'preheader', 'reply_to', 'template_id', 'content_html', 'esp_transport'];
    $vals = [];
    foreach ($cols as $c) {
        if ($c === 'name') { $vals[] = "'" . $conn->real_escape_string($row['name'] . ' (Copy)') . "'"; continue; }
        $v = $row[$c];
        $vals[] = $v === null ? 'NULL' : "'" . $conn->real_escape_string($v) . "'";
    }

    /*
     * created_at is written HERE rather than left to the column's DEFAULT CURRENT_TIMESTAMP.
     *
     * MySQL's clock is not PHP's: this host runs MySQL in one timezone and PHP in Asia/Kolkata
     * (see config/database.php), and CURRENT_TIMESTAMP uses MySQL's. The unified campaigns list
     * files a draft under created_at but a sent campaign under started_at/completed_at, and those
     * ARE written by PHP — so a brand-new copy was stamped hours in the PAST relative to every
     * row around it. "Newest first" then buried it below everything sent since, and it looked for
     * all the world like the duplicate had never been created. One clock, PHP's, for every date
     * this screen sorts on.
     */
    $now  = date('Y-m-d H:i:s');
    $nowQ = "'" . $conn->real_escape_string($now) . "'";
    $cols[] = 'created_at'; $vals[] = $nowQ;
    $cols[] = 'updated_at'; $vals[] = $nowQ;

    /*
     * The INSERT used to go completely unchecked: api_success() reported a copy that did not
     * exist, the list came back unchanged, and nothing anywhere said why. try/catch as well as
     * a return check because PHP 8.1 made mysqli throw on error rather than return false — one
     * of the two fires depending on how this host is configured, and both must end up as a
     * message the admin can read.
     */
    $err = '';
    try {
        $ok = $conn->query("INSERT INTO email_campaigns (" . implode(',', $cols) . ", created_by)
                            VALUES (" . implode(',', $vals) . ", " . (int)($jwt['user_id'] ?? 0) . ")");
    } catch (Throwable $e) { $ok = false; $err = $e->getMessage(); }
    if (!$ok || !$conn->insert_id) api_error('Could not duplicate: ' . ($err ?: ($conn->error ?: 'insert failed')), 500);

    // The new id, name and date go back so the list can show the copy immediately instead of
    // waiting to find it in the next fetch.
    api_success(['id' => (int)$conn->insert_id, 'name' => $row['name'] . ' (Copy)', 'created_at' => $now]);
}

if ($action === 'tags') {
    // Distinct tags used across every existing campaign — powers the tag picker's
    // "existing tags" list in the Setup step.
    //
    // NOTE: tags are collected into a plain list, NOT used as array keys to dedupe —
    // PHP silently casts any array key that looks like a whole number (e.g. "171") to
    // a real integer, which would then serialize as a bare JSON number instead of a
    // string and break the frontend's tag.toLowerCase() calls.
    $r = $conn->query("SELECT tags FROM email_campaigns WHERE tags IS NOT NULL AND tags <> ''");
    $all = [];
    while ($r && $row = $r->fetch_assoc()) {
        foreach (explode(',', $row['tags']) as $t) {
            $t = trim((string)$t);
            if ($t !== '') $all[] = $t;
        }
    }
    $tags = array_values(array_unique($all));
    sort($tags, SORT_NATURAL | SORT_FLAG_CASE);
    $tags = array_map('strval', $tags); // belt-and-suspenders: guarantee every entry is a JSON string
    api_success(['tags' => $tags]);
}

if ($action === 'domains') {
    /*
     * Feeds the Content step's two linked pickers: "Send through" and the sending domain beside
     * the sender email. They are one call because the second depends entirely on the first.
     *
     * A PROVIDER'S DOMAINS ARE THE ONES CONFIGURED AGAINST IT, and nothing else — its default
     * plus any others verified with it (see esp_domains_from_row).
     *
     * This used to add every domain the panel had ever sent through that provider, read off
     * email_campaigns. It sounded harmless and was not: a domain used once through the wrong
     * provider, or before a sender was set up properly, stays in that history for ever and is
     * then offered as though it were verified. Amazon SES had been offered a SendGrid domain on
     * the strength of six old campaigns, and picking it would fail every single recipient with an
     * authentication error and nothing on screen explaining why. A domain is verified with one
     * provider; only the configuration knows which.
     *
     * The flat union is still returned as 'domains', for a provider that has nothing configured
     * yet — otherwise its first campaign could not be addressed at all.
     */
    $inList = "'" . implode("','", array_map([$conn, 'real_escape_string'], TransportFactory::PROVIDERS)) . "'";
    $set = [];
    $senders = [];
    $rs = $conn->query("SELECT * FROM email_esp_settings WHERE provider IN ($inList) ORDER BY FIELD(provider, $inList)");
    while ($rs && $row = $rs->fetch_assoc()) {
        $p   = (string)$row['provider'];
        $dom = strtolower(trim((string)($row['default_sending_domain'] ?? '')));
        $own = esp_domains_from_row($row);
        foreach ($own as $d) $set[] = $d;

        $senders[] = [
            'provider'              => $p,
            'label'                 => esp_provider_label($p),
            // Whether the sender can actually send. The key itself is never returned — only the
            // fact that one exists, which is all the picker needs to grey an option out.
            'configured'            => trim((string)($row['api_key'] ?? '')) !== '' ? 1 : 0,
            'is_active'             => (int)$row['is_active'],
            'default_sender_name'   => (string)($row['default_sender_name'] ?? ''),
            'default_sender_email'  => (string)($row['default_sender_email'] ?? ''),
            'default_sending_domain'=> $dom,
            // Kept in configured order — the default first — rather than sorted, so the picker's
            // first entry is the one the sender is actually set up to use.
            'domains'               => $own,
        ];
    }

    $domains = array_values(array_unique($set));
    sort($domains, SORT_NATURAL | SORT_FLAG_CASE);
    /*
     * What a NEW campaign should start its verification switch at, and whether verifying is even
     * possible. The wizard needs both: a campaign that has never been asked carries NULL, and
     * showing that as "off" would be a lie when the account default is on.
     */
    $vr = @$conn->query("SELECT api_key, verify_before_send FROM email_esp_settings WHERE provider='elasticemail' LIMIT 1");
    $vrow = $vr ? $vr->fetch_assoc() : null;
    $verifyPossible = trim((string)($vrow['api_key'] ?? '')) !== '';

    api_success([
        'domains' => $domains,
        'senders' => $senders,
        'active_provider' => TransportFactory::activeProvider(),
        'verify_default'  => $verifyPossible && (int)($vrow['verify_before_send'] ?? 0) === 1,
        'verify_possible' => $verifyPossible,
    ]);
}

if ($action === 'exam_versions') {
    // Powers the Content step's "Exam (for exam merge tags)" picker — lets an admin tie a
    // campaign to one specific exam, since exam results (score/rank/etc.) are per-exam, while
    // a campaign's audience (segment/contacts) is generally not. See lib/MergeTags.php's
    // resolve_exam_data() for how a recipient's result gets looked up at actual send time.
    $r = $conn->query("SELECT id, cit_name FROM cit_version ORDER BY id DESC");
    $rows = [];
    while ($r && $row = $r->fetch_assoc()) $rows[] = $row;
    api_success(['versions' => $rows]);
}

/** The Audience step's live figures. Both actions below read the same params off the request. */
function audience_config_from_request(): array {
    return [
        'audience_type'       => jin('audience_type', 'segments'),
        'segment_ids'         => json_decode(jin('segment_ids', '[]'), true) ?: [],
        'exclude_segment_ids' => json_decode(jin('exclude_segment_ids', '[]'), true) ?: [],
        'exclude_list_ids'    => json_decode(jin('exclude_list_ids', '[]'), true) ?: [],
        'list_ids'            => json_decode(jin('list_ids', '[]'), true) ?: [],
        'domain_filter'       => jin('domain_filter', ''),
    ];
}

if ($action === 'audience_count') {
    // matched/excluded ride along with count so the step can say WHY the number dropped
    // rather than only showing the smaller figure.
    api_success(resolve_audience_breakdown(audience_config_from_request()));
}

/*
 * The audience the wizard has actually built, as a CSV — every contact who would receive this
 * campaign right now, exclusions and Blocklist already applied. This is the audience being
 * checked before a send goes out, so it is resolved through the very same function the send
 * itself materializes from rather than re-derived here.
 */
if ($action === 'audience_export') {
    $users = resolve_audience_users(audience_config_from_request());

    $slug = preg_replace('/[^A-Za-z0-9_-]+/', '-', trim((string)jin('name', 'audience')));
    $slug = trim($slug, '-') ?: 'audience';

    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $slug . '-audience-' . date('Y-m-d') . '.csv"');
    $out = fopen('php://output', 'w');
    fwrite($out, chr(0xEF) . chr(0xBB) . chr(0xBF)); // BOM, so Excel reads the names as UTF-8 instead of mojibake
    fputcsv($out, ['Email', 'First name', 'Last name', 'Phone', 'User ID']);
    foreach ($users as $u) {
        fputcsv($out, [
            $u['email'] ?? '', $u['first_name'] ?? '', $u['last_name'] ?? '',
            $u['phone'] ?? '', $u['user_id'] ?? '',
        ]);
    }
    fclose($out);
    exit;
}

if ($action === 'upload_attachment') {
    $id = (int)jin('id', 0);
    if (!$id) api_error('Save the campaign before adding attachments');
    $r = $conn->query("SELECT attachments FROM email_campaigns WHERE id=$id LIMIT 1");
    $row = $r ? $r->fetch_assoc() : null;
    if (!$row) api_error('Not found', 404);

    if (empty($_FILES['file']) || $_FILES['file']['error'] !== UPLOAD_ERR_OK) api_error('Choose a file to attach');
    $file = $_FILES['file'];

    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    if (!in_array($ext, CAMPAIGN_ATTACHMENT_ALLOWED_EXT, true)) {
        api_error('File type not allowed (.' . $ext . ') — allowed: ' . implode(', ', CAMPAIGN_ATTACHMENT_ALLOWED_EXT));
    }
    if ($file['size'] > CAMPAIGN_ATTACHMENT_MAX_FILE_BYTES) {
        api_error('File too large — max ' . (CAMPAIGN_ATTACHMENT_MAX_FILE_BYTES / 1024 / 1024) . 'MB per file');
    }

    $existing = json_decode($row['attachments'] ?? '[]', true) ?: [];
    $existingTotal = array_sum(array_map(fn($a) => (int)($a['size'] ?? 0), $existing));
    if ($existingTotal + $file['size'] > CAMPAIGN_ATTACHMENT_MAX_TOTAL_BYTES) {
        api_error('Total attachments would exceed ' . (CAMPAIGN_ATTACHMENT_MAX_TOTAL_BYTES / 1024 / 1024) . 'MB for this campaign');
    }

    $mimeGuess = [
        'pdf' => 'application/pdf', 'doc' => 'application/msword',
        'docx' => 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        'xls' => 'application/vnd.ms-excel', 'xlsx' => 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        'jpg' => 'image/jpeg', 'jpeg' => 'image/jpeg', 'png' => 'image/png', 'gif' => 'image/gif',
        'txt' => 'text/plain', 'csv' => 'text/csv', 'zip' => 'application/zip',
    ];
    $mime = $mimeGuess[$ext] ?? 'application/octet-stream';

    // Small (<=5MB) and not chunk-processed — uploaded straight to S3, never touching local
    // disk permanently, unlike the CSV import pipeline which still needs local byte-offset
    // resumable processing (see ContactImportWorker.php).
    $safeName = preg_replace('/[^a-zA-Z0-9_.\-]/', '_', basename($file['name']));
    $key = 'campaign_attachments/' . $id . '/' . bin2hex(random_bytes(8)) . '_' . $safeName;
    $s3Url = s3_upload_file($file['tmp_name'], $key, $mime);
    if (!$s3Url) api_error('Could not upload attachment to storage');

    $existing[] = [
        'filename' => $safeName, 's3_key' => $key, 's3_url' => $s3Url, 'size' => (int)$file['size'], 'mime' => $mime,
    ];
    $conn->query("UPDATE email_campaigns SET attachments='" . $conn->real_escape_string(json_encode($existing)) . "' WHERE id=$id");
    api_success(['attachments' => $existing]);
}

if ($action === 'remove_attachment') {
    $id = (int)jin('id', 0);
    $s3Key = (string)jin('stored_name', ''); // param name kept for frontend compatibility; now carries s3_key
    if (!$id || !$s3Key) api_error('id and stored_name required');
    $r = $conn->query("SELECT attachments FROM email_campaigns WHERE id=$id LIMIT 1");
    $row = $r ? $r->fetch_assoc() : null;
    if (!$row) api_error('Not found', 404);

    $existing = json_decode($row['attachments'] ?? '[]', true) ?: [];
    $remaining = array_values(array_filter($existing, fn($a) => ($a['s3_key'] ?? '') !== $s3Key));
    s3_delete_key($s3Key);

    $conn->query("UPDATE email_campaigns SET attachments='" . $conn->real_escape_string(json_encode($remaining)) . "' WHERE id=$id");
    api_success(['attachments' => $remaining]);
}

if ($action === 'send_test') {
    $id = (int)jin('id', 0);
    $r = $conn->query("SELECT * FROM email_campaigns WHERE id=$id LIMIT 1");
    $campaign = $r ? $r->fetch_assoc() : null;
    if (!$campaign) api_error('Save the campaign before sending a test', 404);
    if (!$campaign['subject'] || !$campaign['content_html']) api_error('Add a subject and select a template first');

    $emailsRaw = (string)jin('emails', '');
    $emails = array_values(array_filter(array_map('trim', preg_split('/[,;\n]+/', $emailsRaw))));
    if (!$emails) api_error('Enter at least one test email address');

    // The campaign's own sender, so a test lands in the inbox through the same provider the real
    // send will use — a test that quietly went out through SendGrid proves nothing about whether
    // the Amazon SES setup this campaign depends on actually works.
    $transport = TransportFactory::forProvider(campaign_transport($campaign));
    $attachments = load_campaign_attachments($campaign); // loaded once, reused for every test address
    $results = [];
    foreach ($emails as $email) {
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $results[] = ['email' => $email, 'ok' => false, 'error' => 'Invalid email address'];
            continue;
        }
        $rid = bin2hex(random_bytes(16));
        $emailE = $conn->real_escape_string($email);

        // If the test address happens to belong to a real registered student, use their
        // real user_id/name — this is what makes mapped Attributes (and exam merge tags)
        // resolve correctly on a test send instead of always looking like an anonymous
        // 'Test User' with nothing to look up.
        $uRes = $conn->query("SELECT user_id, fname, lname FROM users WHERE email='$emailE' LIMIT 1");
        $uRow = $uRes ? $uRes->fetch_assoc() : null;
        $testUserId = $uRow['user_id'] ?? null;
        $testFname = $uRow['fname'] ?? 'Test';
        $testLname = $uRow['lname'] ?? 'User';
        $testFnameE = $conn->real_escape_string($testFname);
        $testLnameE = $conn->real_escape_string($testLname);

        $conn->query("INSERT INTO email_campaign_recipients (campaign_id, user_id, email, first_name, last_name, phone, is_test, status, rid)
                      VALUES ($id, " . ($testUserId ? (int)$testUserId : 'NULL') . ", '$emailE', '$testFnameE', '$testLnameE', '', 1, 'pending', '$rid')");
        $recId = $conn->insert_id;

        if (!$transport) {
            $results[] = ['email' => $email, 'ok' => false, 'error' => 'ESP not configured — set an API key in Settings'];
            $conn->query("UPDATE email_campaign_recipients SET status='failed', error_message='ESP not configured' WHERE id=$recId");
            continue;
        }

        $recipient = ['email' => $email, 'user_id' => $testUserId, 'first_name' => $testFname, 'last_name' => $testLname, 'phone' => ''];
        if (!empty($campaign['exam_cit_version']) && $testUserId) {
            $examData = resolve_exam_data((int)$testUserId, $campaign['exam_cit_version']);
            if ($examData) $recipient = array_merge($recipient, $examData);
        }
        $attributes = load_all_attributes();
        $attrTokens = $attributes ? (resolve_attribute_values_batch($attributes, [$recipient])[strtolower($email)] ?? []) : [];

        $subject    = substitute_merge_tags((string)$campaign['subject'], $recipient, $attrTokens);
        $senderName = substitute_merge_tags((string)$campaign['sender_name'], $recipient, $attrTokens);
        $preheader  = substitute_merge_tags((string)$campaign['preheader'], $recipient, $attrTokens);
        $html       = substitute_merge_tags((string)$campaign['content_html'], $recipient, $attrTokens);
        $html       = inject_preheader($html, $preheader);
        $banner     = '<div style="background:#fef3c7;color:#92400e;padding:8px 14px;font:600 12px sans-serif;border-radius:6px;margin-bottom:12px;">TEST EMAIL — sent from the campaign builder, not a real recipient</div>';
        $html       = $banner . $html;
        $html       = inject_tracking($html, $rid);
        /*
         * The same unsubscribe link a real send gets, AFTER tracking exactly as SendWorker does.
         * A test that skips it arrives with the raw placeholder, which Gmail turns into
         * http://XX_UNSUBSCRIBE_URL_XX — so the one email a person checks the link in was the one
         * email where it could never work.
         */
        $html       = inject_unsubscribe($html, $email);

        $res = $transport->sendEmail($email, '[TEST] ' . $subject, $html,
            $senderName !== '' ? $senderName : (string)$campaign['sender_name'],
            (string)$campaign['sender_email'], $campaign['reply_to'] ?: null, $rid, $attachments);

        if ($res['ok']) {
            $conn->query("UPDATE email_campaign_recipients SET status='sent', sent_at=NOW() WHERE id=$recId");
        } else {
            $errE = $conn->real_escape_string(substr((string)($res['error'] ?? ''), 0, 480));
            $conn->query("UPDATE email_campaign_recipients SET status='failed', error_message='$errE' WHERE id=$recId");
        }
        $results[] = ['email' => $email, 'ok' => $res['ok'], 'error' => $res['error'] ?? null];
    }
    api_success(['results' => $results]);
}

if ($action === 'send_now') {
    $id = (int)jin('id', 0);
    $r = $conn->query("SELECT * FROM email_campaigns WHERE id=$id LIMIT 1");
    $campaign = $r ? $r->fetch_assoc() : null;
    if (!$campaign) api_error('Not found', 404);
    campaign_block_resend($campaign, 'sending it now');

    $checklist = validate_campaign_for_send($campaign);
    if ($checklist['blocking']) api_error('Cannot send: ' . implode('; ', $checklist['blocking']));

    // Recipients are NOT materialized here — that (a full 20k-40k row resolve+insert) now
    // happens inside the worker's own background run, which has no web-request execution-time
    // limit, instead of blocking this click on modest shared hosting. $checklist['count'] is a
    // cheap COUNT(*) preview, not the real queued rows yet.
    // The provider the campaign itself names, resolved once here so the worker and the report
    // agree on it. Settings' Active sender is only consulted for a legacy campaign that names
    // nothing — re-stamping it unconditionally, as this did, meant a campaign built for Amazon
    // SES went out through SendGrid the moment somebody changed that radio for another campaign.
    $transportE = $conn->real_escape_string(campaign_transport($campaign));
    $conn->query("UPDATE email_campaigns SET status='running', schedule_type='now', scheduled_at=NULL, started_at=NOW(), total_recipients=0, materialized_at=NULL, esp_transport='$transportE' WHERE id=$id");
    trigger_worker_async($id);
    api_success(['queued' => $checklist['count']]);
}

if ($action === 'schedule') {
    $id = (int)jin('id', 0);
    $at = trim((string)jin('scheduled_at', ''));
    if (!$at) api_error('Pick a date & time');
    $ts = strtotime($at);
    if (!$ts || $ts <= time()) api_error('Scheduled time must be in the future');

    $r = $conn->query("SELECT * FROM email_campaigns WHERE id=$id LIMIT 1");
    $campaign = $r ? $r->fetch_assoc() : null;
    if (!$campaign) api_error('Not found', 404);
    campaign_block_resend($campaign, 'scheduling it');

    $checklist = validate_campaign_for_send($campaign);
    if ($checklist['blocking']) api_error('Cannot schedule: ' . implode('; ', $checklist['blocking']));

    // Same reasoning as send_now: the actual audience resolve+insert happens in the worker,
    // right after scheduled_at arrives and the campaign flips to 'running' — not here.
    $atE = $conn->real_escape_string(date('Y-m-d H:i:s', $ts));
    // Same as send_now — the campaign's own choice, frozen at the moment the send is committed.
    $transportE = $conn->real_escape_string(campaign_transport($campaign));
    $conn->query("UPDATE email_campaigns SET status='scheduled', schedule_type='later', scheduled_at='$atE', total_recipients=0, materialized_at=NULL, esp_transport='$transportE' WHERE id=$id");
    api_success(['queued' => $checklist['count'], 'scheduled_at' => $atE]);
}

if ($action === 'pause') {
    $id = (int)jin('id', 0);
    $r = $conn->query("SELECT status FROM email_campaigns WHERE id=$id LIMIT 1");
    $row = $r ? $r->fetch_assoc() : null;
    if (!$row) api_error('Not found', 404);
    if (!in_array($row['status'], ['draft', 'scheduled', 'running'], true)) api_error('Only draft, scheduled or running campaigns can be suspended');
    $conn->query("UPDATE email_campaigns SET status='suspended' WHERE id=$id");
    api_success([]);
}

if ($action === 'resume') {
    $id = (int)jin('id', 0);
    $r = $conn->query("SELECT * FROM email_campaigns WHERE id=$id LIMIT 1");
    $campaign = $r ? $r->fetch_assoc() : null;
    if (!$campaign) api_error('Not found', 404);
    if ($campaign['status'] !== 'suspended') api_error('Only suspended campaigns can be resumed');

    if ($campaign['schedule_type'] === 'later' && $campaign['scheduled_at'] && strtotime($campaign['scheduled_at']) > time()) {
        $conn->query("UPDATE email_campaigns SET status='scheduled' WHERE id=$id");
    } else {
        $conn->query("UPDATE email_campaigns SET status='running' WHERE id=$id");
        trigger_worker_async($id);
    }
    api_success([]);
}

if ($action === 'requeue') {
    $id = (int)jin('id', 0);
    $r = $conn->query("SELECT total_recipients FROM email_campaigns WHERE id=$id LIMIT 1");
    $row = $r ? $r->fetch_assoc() : null;
    if (!$row) api_error('Not found', 404);

    if ((int)$row['total_recipients'] === 0) {
        // This campaign never actually had any recipients (its audience resolved to 0 people)
        // — clearing materialized_at forces the worker to re-resolve the audience from scratch
        // on its next tick, instead of re-flagging "running" over an audience check that's
        // already been done and will never change on its own (this was the actual "stuck at
        // Running forever" bug — Requeue used to just relabel the status without re-checking
        // anything). If you've since fixed the segment selection, this pass will pick it up.
        $conn->query("UPDATE email_campaigns SET status='running', materialized_at=NULL WHERE id=$id");
    } else {
        // Real per-recipient send failures exist — audience was already correctly resolved,
        // so just retry those specific people instead of re-resolving anything.
        $conn->query("UPDATE email_campaign_recipients SET status='pending', attempts=0, error_message=NULL WHERE campaign_id=$id AND status='failed'");
        $conn->query("UPDATE email_campaigns SET status='running' WHERE id=$id AND status IN ('sent','failed','suspended')");
    }
    trigger_worker_async($id);
    api_success([]);
}

if ($action === 'report') {
    $id = (int)jin('id', 0);
    $r = $conn->query("SELECT * FROM email_campaigns WHERE id=$id LIMIT 1");
    $campaign = $r ? $r->fetch_assoc() : null;
    if (!$campaign) api_error('Not found', 404);

    $statusCounts = ['pending' => 0, 'processing' => 0, 'sent' => 0, 'failed' => 0, 'bounced' => 0];
    $sc = $conn->query("SELECT status, COUNT(*) AS c FROM email_campaign_recipients WHERE campaign_id=$id AND is_test=0 GROUP BY status");
    while ($sc && $row = $sc->fetch_assoc()) $statusCounts[$row['status']] = (int)$row['c'];

    $page = max(1, (int)jin('page', 1));
    $perPage = max(1, min(100, (int)jin('per_page', 25)));
    $offset = ($page - 1) * $perPage;
    // 'open_bot'/'click_bot' rows are machine fetches (Apple Mail prefetch, security
    // scanners, duplicate re-renders — see lib/BotDetector.php). They are kept in the table
    // so the filtering stays auditable, but they'd drown the human activity they were
    // filtered out of, so the feed shows real engagement only; their volume is reported
    // through the bot_open_count / bot_click_count tiles instead. Test-send recipients are
    // excluded for the same reason they no longer move the counters.
    $evWhere = "e.campaign_id=$id AND r.is_test=0 AND e.event_type NOT IN ('open_bot','click_bot')";
    $evR = $conn->query("SELECT e.event_type, e.url, e.created_at, r.email
                          FROM email_campaign_events e JOIN email_campaign_recipients r ON r.id = e.recipient_id
                          WHERE $evWhere ORDER BY e.id DESC LIMIT $perPage OFFSET $offset");
    $events = [];
    while ($evR && $row = $evR->fetch_assoc()) $events[] = $row;
    $evTotalR = $conn->query("SELECT COUNT(*) AS c
                                FROM email_campaign_events e JOIN email_campaign_recipients r ON r.id = e.recipient_id
                               WHERE $evWhere");
    $evTotal = $evTotalR ? (int)$evTotalR->fetch_assoc()['c'] : 0;

    // The raw error text from the ESP (e.g. SendGrid's actual rejection message) is already
    // captured per recipient when a send fails — this just surfaces it, capped at the 50 most
    // recent failures, so "what is SendGrid actually saying" is visible without needing to
    // query the database by hand.
    $failedR = $conn->query("SELECT email, attempts, error_message, sent_at
                              FROM email_campaign_recipients
                              WHERE campaign_id=$id AND status='failed' AND is_test=0
                              ORDER BY id DESC LIMIT 50");
    $failedRecipients = [];
    while ($failedR && $row = $failedR->fetch_assoc()) $failedRecipients[] = $row;

    api_success([
        'campaign' => $campaign, 'recipient_status_counts' => $statusCounts,
        'events' => $events, 'events_total' => $evTotal, 'page' => $page, 'per_page' => $perPage,
        'pages' => $evTotal > 0 ? (int)ceil($evTotal / $perPage) : 1,
        'failed_recipients' => $failedRecipients,
    ]);
}

if ($action === 'device_breakdown') {
    $id = (int)jin('id', 0);
    $r = $conn->query("SELECT COALESCE(device_type,'unknown') AS device_type, COUNT(DISTINCT recipient_id) AS c
                        FROM email_campaign_events
                        WHERE campaign_id=$id AND event_type='click'
                        GROUP BY COALESCE(device_type,'unknown')");
    $out = ['mobile' => 0, 'tablet' => 0, 'desktop' => 0, 'unknown' => 0];
    while ($r && $row = $r->fetch_assoc()) $out[$row['device_type']] = (int)$row['c'];
    api_success(['devices' => $out]);
}

if ($action === 'bounced_recipients') {
    $id = (int)jin('id', 0);
    $page = max(1, (int)jin('page', 1));
    $perPage = max(1, min(100, (int)jin('per_page', 25)));
    $offset = ($page - 1) * $perPage;

    $r = $conn->query("SELECT email, bounce_type, bounced_at
                        FROM email_campaign_recipients
                        WHERE campaign_id=$id AND status='bounced' AND is_test=0
                        ORDER BY bounced_at DESC LIMIT $perPage OFFSET $offset");
    $rows = [];
    while ($r && $row = $r->fetch_assoc()) $rows[] = $row;
    $totalR = $conn->query("SELECT COUNT(*) AS c FROM email_campaign_recipients WHERE campaign_id=$id AND status='bounced' AND is_test=0");
    $total = $totalR ? (int)$totalR->fetch_assoc()['c'] : 0;

    api_success([
        'recipients' => $rows, 'total' => $total, 'page' => $page, 'per_page' => $perPage,
        'pages' => $total > 0 ? (int)ceil($total / $perPage) : 1,
    ]);
}

/*
 * Who actually converted — the named list behind the Conversions tile.
 * &export=1 drops pagination (capped) so the report page can build a CSV of
 * every converted user, not just the page on screen.
 */
/*
 * Who clicked — one row per person, or one row per tap.
 *
 * ── Why this reads events and not the counter ────────────────────────────────
 * email_campaign_recipients.click_count already says HOW MANY times somebody clicked, and it is
 * what the report's Clicked figure is built from. It cannot answer "which link", "when", or
 * "was that one person clicking four times or four people clicking once" — and those are the
 * only questions anybody actually has when they look at a click number and want to do something
 * with it. email_campaign_events keeps every tap, so this reads that.
 *
 * ── unique=1 is the default view for a reason ───────────────────────────────
 * Raw taps flatter the number: an email opened twice on a phone and once on a laptop is three
 * rows and one interested person. Grouping by recipient answers "who", which is the question
 * asked; the per-tap view is there for when the question is "what did they do", and both come
 * from the same rows so they can never disagree.
 *
 * ── The bot rows are excluded, deliberately ─────────────────────────────────
 * 'click_bot' exists because corporate mail scanners (Outlook Safe Links, Mimecast, Proofpoint)
 * fetch every URL in every message before delivering it, and those fetches are indistinguishable
 * from a person clicking unless they are classified at write time — which is what that enum
 * value is. Including them here would fill a "who clicked" list with people who never opened
 * the email, which is worse than showing nothing.
 */
/*
 * The activity log — every recipient of this campaign and what actually happened to them.
 *
 * ── Why a per-recipient list is not the same as the counters ─────────────────
 * The report's tiles say 4,000 sent and 37 failed. They cannot say WHICH 37, or why, and "why"
 * is nearly always one answer repeated 37 times — an expired token, a suppressed domain, a
 * bounce category — that is invisible while it is only a number. This returns the rows behind
 * the tiles so the number can be opened and read.
 *
 * ── Status here is derived, not stored ──────────────────────────────────────
 * email_campaign_recipients.status only knows about the SEND (pending → sent → failed/bounced).
 * Engagement lives in separate timestamp columns, so a recipient who was sent to, opened, and
 * clicked is status='sent' with two more facts attached. Reporting that as "Sent" throws away
 * the two most interesting things about them, so the furthest stage reached is computed here —
 * clicked > opened > sent — and the raw status is returned alongside it for anyone filtering on
 * the send itself.
 *
 * bounced and failed stay distinct: a bounce is the mailbox refusing delivery after the ESP
 * accepted it, a failure is the ESP refusing to accept it at all. They have different causes and
 * different fixes, and collapsing them into "didn't work" is how the actual problem gets missed.
 */
if ($action === 'recipients') {
    $id      = (int)jin('id', 0);
    $page    = max(1, (int)jin('page', 1));
    $perPage = max(1, min(200, (int)jin('per_page', 25)));
    $status  = trim((string)jin('status', 'all'));
    $search  = trim((string)jin('search', ''));
    $export  = (int)jin('export', 0) === 1;
    $offset  = ($page - 1) * $perPage;
    if (!$id) api_error('Missing campaign id');

    $where = ["r.campaign_id = $id", 'r.is_test = 0'];

    /*
     * The engagement filters are windows onto the same rows rather than values of `status`, which
     * is why they cannot simply be passed through to a WHERE on that column. 'failed' deliberately
     * covers both hard outcomes, because somebody looking for what went wrong wants both.
     */
    switch ($status) {
        case 'clicked':  $where[] = 'r.first_clicked_at IS NOT NULL'; break;
        case 'opened':   $where[] = 'r.opened_at IS NOT NULL AND r.first_clicked_at IS NULL'; break;
        case 'bounced':  $where[] = "r.status = 'bounced'"; break;
        case 'failed':   $where[] = "r.status IN ('failed','bounced')"; break;
        case 'sent':     $where[] = "r.status = 'sent'"; break;
        case 'pending':  $where[] = "r.status IN ('pending','processing')"; break;
        case 'all': case '': break;
        default:         $where[] = "r.status = '" . $conn->real_escape_string($status) . "'";
    }

    if ($search !== '') {
        $s = $conn->real_escape_string($search);
        $where[] = "(r.email LIKE '%$s%' OR r.phone LIKE '%$s%'
                     OR CONCAT_WS(' ', r.first_name, r.last_name) LIKE '%$s%'
                     OR r.error_message LIKE '%$s%')";
    }
    $whereSql = 'WHERE ' . implode(' AND ', $where);

    $tr = $conn->query("SELECT COUNT(*) AS c FROM email_campaign_recipients r $whereSql");
    $total = $tr ? (int)$tr->fetch_assoc()['c'] : 0;

    /*
     * Ordered by "most interesting first" rather than by id: failures at the top, then the
     * people who engaged, then everyone else. A 4,000-row log opened at row 1 of an alphabetical
     * list is a log nobody reads to the end, and the rows that need acting on are at the top.
     */
    $sql = "SELECT r.id, r.user_id, r.email, r.phone,
                   TRIM(CONCAT_WS(' ', r.first_name, r.last_name)) AS name,
                   r.status, r.error_message, r.bounce_type, r.esp_message_id,
                   r.sent_at, r.opened_at, r.first_clicked_at, r.bounced_at,
                   r.open_count, r.click_count,
                   CASE
                     WHEN r.status = 'bounced'              THEN 'bounced'
                     WHEN r.status = 'failed'               THEN 'failed'
                     WHEN r.first_clicked_at IS NOT NULL    THEN 'clicked'
                     WHEN r.opened_at IS NOT NULL           THEN 'opened'
                     WHEN r.status = 'sent'                 THEN 'sent'
                     ELSE r.status
                   END AS stage,
                   COALESCE(r.bounced_at, r.first_clicked_at, r.opened_at, r.sent_at, r.queued_at) AS last_at
              FROM email_campaign_recipients r
              $whereSql
             ORDER BY (r.status IN ('failed','bounced')) DESC,
                      (r.first_clicked_at IS NOT NULL) DESC,
                      (r.opened_at IS NOT NULL) DESC,
                      last_at DESC, r.id ASC";

    $sql .= $export ? ' LIMIT 50000' : " LIMIT $perPage OFFSET $offset";

    $rr = $conn->query($sql);
    $rows = [];
    while ($rr && $row = $rr->fetch_assoc()) $rows[] = $row;

    if ($export) {
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="campaign-' . $id . '-activity.csv"');
        $out = fopen('php://output', 'w');
        fputcsv($out, ['Name', 'Email', 'Channel', 'Outcome', 'Reason', 'Sent', 'Opened', 'Clicked']);
        foreach ($rows as $r) {
            fputcsv($out, [$r['name'] ?? '', $r['email'] ?? '', 'Email', $r['stage'] ?? '',
                           $r['error_message'] ?? '', $r['sent_at'] ?? '',
                           $r['opened_at'] ?? '', $r['first_clicked_at'] ?? '']);
        }
        fclose($out);
        exit;
    }

    // The per-outcome tallies the filter chips show. One query rather than one per chip, and
    // scoped to the search so the numbers always match what filtering would actually produce.
    $counts = ['all' => 0, 'sent' => 0, 'opened' => 0, 'clicked' => 0, 'bounced' => 0, 'failed' => 0, 'pending' => 0];
    $searchOnly = $search !== ''
        ? " AND (r.email LIKE '%" . $conn->real_escape_string($search) . "%'
                 OR CONCAT_WS(' ', r.first_name, r.last_name) LIKE '%" . $conn->real_escape_string($search) . "%')"
        : '';
    $cr = $conn->query("SELECT
            COUNT(*) AS all_c,
            SUM(r.status = 'sent' AND r.opened_at IS NULL) AS sent_c,
            SUM(r.opened_at IS NOT NULL AND r.first_clicked_at IS NULL) AS opened_c,
            SUM(r.first_clicked_at IS NOT NULL) AS clicked_c,
            SUM(r.status = 'bounced') AS bounced_c,
            SUM(r.status IN ('failed','bounced')) AS failed_c,
            SUM(r.status IN ('pending','processing')) AS pending_c
          FROM email_campaign_recipients r
         WHERE r.campaign_id = $id AND r.is_test = 0$searchOnly");
    if ($cr && $c = $cr->fetch_assoc()) {
        $counts = [
            'all' => (int)$c['all_c'], 'sent' => (int)$c['sent_c'], 'opened' => (int)$c['opened_c'],
            'clicked' => (int)$c['clicked_c'], 'bounced' => (int)$c['bounced_c'],
            'failed' => (int)$c['failed_c'], 'pending' => (int)$c['pending_c'],
        ];
    }

    api_success([
        'recipients' => $rows,
        'rows'       => $rows,   // both names, so either shape of caller works
        'counts'     => $counts,
        'total'      => $total,
        'page'       => $page,
        'per_page'   => $perPage,
        'pages'      => $total > 0 ? (int)ceil($total / $perPage) : 1,
    ]);
}

if ($action === 'clicks') {
    $id      = (int)jin('id', 0);
    $page    = max(1, (int)jin('page', 1));
    $perPage = max(1, min(200, (int)jin('per_page', 25)));
    $unique  = (int)jin('unique', 1) === 1;
    $search  = trim((string)jin('search', ''));
    $export  = (int)jin('export', 0) === 1;
    $offset  = ($page - 1) * $perPage;
    if (!$id) api_error('Missing campaign id');

    $where = ["e.campaign_id = $id", "e.event_type = 'click'"];
    if ($search !== '') {
        $s = $conn->real_escape_string($search);
        $where[] = "(r.email LIKE '%$s%' OR r.phone LIKE '%$s%'
                     OR CONCAT_WS(' ', r.first_name, r.last_name) LIKE '%$s%'
                     OR e.url LIKE '%$s%')";
    }
    $whereSql = 'WHERE ' . implode(' AND ', $where);

    // INNER JOIN, not LEFT: an event whose recipient row is gone cannot be attributed to a
    // person, and a "who clicked" list with anonymous rows in it is not answering its question.
    $from = "FROM email_campaign_events e
             INNER JOIN email_campaign_recipients r ON r.id = e.recipient_id";

    if ($unique) {
        $tr    = $conn->query("SELECT COUNT(DISTINCT e.recipient_id) AS c $from $whereSql");
        $total = $tr ? (int)$tr->fetch_assoc()['c'] : 0;

        /*
         * MIN/MAX rather than bare columns — legal under ONLY_FULL_GROUP_BY, and the pair reads
         * as "first seen / last seen", which is what someone checking a click wants to know.
         * The URL shown is the most recent one, because with several links in a message the last
         * thing they clicked is the more interesting one.
         */
        $sql = "SELECT r.id AS recipient_id, r.user_id, r.email, r.phone,
                       TRIM(CONCAT_WS(' ', r.first_name, r.last_name)) AS name,
                       COUNT(*) AS taps,
                       COUNT(DISTINCT e.url) AS links,
                       MIN(e.created_at) AS first_clicked_at,
                       MAX(e.created_at) AS clicked_at,
                       SUBSTRING_INDEX(GROUP_CONCAT(e.url ORDER BY e.created_at DESC SEPARATOR '\\n'), '\\n', 1) AS url,
                       MAX(e.device_type) AS device_type
                $from $whereSql
                GROUP BY r.id, r.user_id, r.email, r.phone, name
                ORDER BY clicked_at DESC";
    } else {
        $tr    = $conn->query("SELECT COUNT(*) AS c $from $whereSql");
        $total = $tr ? (int)$tr->fetch_assoc()['c'] : 0;

        $sql = "SELECT e.id, r.id AS recipient_id, r.user_id, r.email, r.phone,
                       TRIM(CONCAT_WS(' ', r.first_name, r.last_name)) AS name,
                       1 AS taps, 1 AS links,
                       e.created_at AS first_clicked_at, e.created_at AS clicked_at,
                       e.url, e.device_type, e.ip_address, e.user_agent
                $from $whereSql
                ORDER BY e.created_at DESC, e.id DESC";
    }

    /*
     * Export is the whole list, not the page. A 25-row CSV of a 4,000-click campaign is a
     * trap — it looks like a complete file and silently is not. Capped high enough that any
     * real campaign fits and low enough that it cannot exhaust memory.
     */
    $sql .= $export ? ' LIMIT 50000' : " LIMIT $perPage OFFSET $offset";

    $lr   = $conn->query($sql);
    $rows = [];
    while ($lr && $row = $lr->fetch_assoc()) $rows[] = $row;

    if ($export) {
        // Streamed as CSV with the same columns the table shows, so what is downloaded matches
        // what was on screen rather than being a differently-shaped second export format.
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="campaign-' . $id . '-clicks.csv"');
        $out = fopen('php://output', 'w');
        fputcsv($out, ['Name', 'Email', 'Phone', 'Clicks', 'Links', 'First clicked', 'Last clicked', 'Last URL']);
        foreach ($rows as $r) {
            fputcsv($out, [$r['name'] ?? '', $r['email'] ?? '', $r['phone'] ?? '',
                           $r['taps'] ?? 1, $r['links'] ?? 1,
                           $r['first_clicked_at'] ?? '', $r['clicked_at'] ?? '', $r['url'] ?? '']);
        }
        fclose($out);
        exit;
    }

    api_success([
        'rows'     => $rows,
        'total'    => $total,
        'page'     => $page,
        'per_page' => $perPage,
        'pages'    => $total > 0 ? (int)ceil($total / $perPage) : 1,
        'unique'   => $unique,
    ]);
}

if ($action === 'conversions') {
    $id = (int)jin('id', 0);
    $r = $conn->query("SELECT * FROM email_campaigns WHERE id=$id LIMIT 1");
    $campaign = $r ? $r->fetch_assoc() : null;
    if (!$campaign) api_error('Not found', 404);

    $search = trim((string)jin('search', ''));
    $q = conversion_list_sql($campaign, $search);
    if (!$q) {
        api_success([
            'goal_event_name' => $campaign['goal_event_name'] ?? '',
            'rows' => [], 'total' => 0, 'page' => 1, 'per_page' => 20, 'pages' => 1,
        ]);
    }

    $totalR = $conn->query($q['count']);
    $total  = $totalR ? (int)$totalR->fetch_assoc()['c'] : 0;

    $export = (int)jin('export', 0) === 1;
    if ($export) {
        $limitSql = ' LIMIT 50000';
        $page = 1; $perPage = $total;
    } else {
        $page    = max(1, (int)jin('page', 1));
        $perPage = max(1, min(100, (int)jin('per_page', 20)));
        $limitSql = " LIMIT $perPage OFFSET " . (($page - 1) * $perPage);
    }

    $rowsR = $conn->query($q['select'] . ' ' . $q['from'] . $q['group'] . $q['order'] . $limitSql);
    $rows = [];
    while ($rowsR && $row = $rowsR->fetch_assoc()) $rows[] = $row;

    api_success([
        'goal_event_name'  => $campaign['goal_event_name'],
        'goal_window_days' => (int)($campaign['goal_window_days'] ?: 2),
        'attribution_mode' => $q['mode'],
        'campaign_name'    => $campaign['name'],
        'rows'  => $rows, 'total' => $total, 'page' => $page,
        'per_page' => $export ? $total : $perPage,
        'pages' => (!$export && $total > 0) ? (int)ceil($total / $perPage) : 1,
    ]);
}

/* One converted user in full — profile plus the raw goal-event rows. */
if ($action === 'conversion_detail') {
    $id     = (int)jin('id', 0);
    $userId = (int)jin('user_id', 0);
    $r = $conn->query("SELECT * FROM email_campaigns WHERE id=$id LIMIT 1");
    $campaign = $r ? $r->fetch_assoc() : null;
    if (!$campaign) api_error('Not found', 404);
    if ($userId <= 0) api_error('user_id is required');

    $uR = $conn->query("SELECT * FROM users WHERE user_id=$userId LIMIT 1");
    $user = $uR ? $uR->fetch_assoc() : null;
    if ($user) $user = conversion_strip_secrets($user);

    $recR = $conn->query("SELECT email, status, sent_at, first_clicked_at, opened_at, open_count, click_count
                            FROM email_campaign_recipients
                           WHERE campaign_id=$id AND user_id=$userId AND is_test=0
                           ORDER BY id DESC LIMIT 1");
    $recipient = $recR ? $recR->fetch_assoc() : null;

    // medium='email' for the same reason as in ConversionTracker: campaign_attributions is shared
    // with the WhatsApp channel, and a WhatsApp campaign can hold the same numeric id.
    $attrR = $conn->query("SELECT medium, clicked_at, attributed_at
                             FROM campaign_attributions
                            WHERE campaign_id=$id AND user_id=$userId AND medium='email'
                              AND event_key='" . $conn->real_escape_string($campaign['goal_event_name']) . "'
                            LIMIT 1");
    $attribution = $attrR ? $attrR->fetch_assoc() : null;

    // Scope the raw event rows to the window this campaign earned — otherwise a
    // user who converted for two campaigns shows both campaigns' events here.
    [$evFrom, $evTo] = conversion_event_window($campaign, $attribution, $recipient);

    api_success([
        'user'            => $user,
        'recipient'       => $recipient,
        'attribution'     => $attribution,
        'goal_event_name' => $campaign['goal_event_name'],
        'events'          => conversion_user_events((string)$campaign['goal_event_name'], $userId, $evFrom, $evTo),
    ]);
}

api_error('Invalid action');

<?php
/*
 * /api/freshdesk/lib/ImapClient.php
 *
 * A self-contained IMAP4rev1 client speaking the protocol directly over a
 * stream socket.
 *
 * WHY NOT ext/imap: cPanel/shared PHP builds very often ship without the imap
 * extension, and it cannot be enabled from the panel. Worse, ext/imap is being
 * removed from PHP core (unbundled in 8.4), so a desk built on it acquires an
 * expiry date. This class needs only openssl streams, which are always present.
 *
 * It implements exactly the subset the sync worker needs, and no more:
 *   CAPABILITY, STARTTLS, LOGIN, LIST, SELECT/EXAMINE, UID SEARCH,
 *   UID FETCH, UID STORE, APPEND, NOOP, LOGOUT.
 *
 * THE ONE THING TO UNDERSTAND before editing: IMAP is not line-based. A server
 * may answer with a "literal" -- {1234}\r\n followed by exactly 1234 raw bytes
 * that can contain anything, CRLF included. Any parser that reads by lines
 * corrupts every message containing a blank line, which is all of them. So
 * readResponseLine() reassembles one logical response, pulling literals out by
 * exact byte count and leaving a \x00LITn\x00 placeholder behind; parsers then
 * work on a flat, newline-free string and look up the real bytes by index.
 */

class FdImapException extends Exception {}

class ImapClient
{
    private $sock = null;
    private $tagSeq = 0;
    private $host, $port, $security, $user, $pass, $timeout, $verifyPeer;
    private $capabilities = array();
    private $selected = null;
    private $selectedInfo = array();
    /** Literals pulled from the response currently being read. */
    private $literals = array();
    /** Raw protocol trace, kept for the Settings -> Test Connection panel. */
    private $trace = array();
    private $traceEnabled = false;

    public function __construct($opts = array())
    {
        $this->host       = isset($opts['host'])     ? $opts['host']     : fd_cfg('IMAP_HOST');
        $this->port       = isset($opts['port'])     ? (int)$opts['port'] : fd_cfg_int('IMAP_PORT', 993);
        $this->security   = isset($opts['security']) ? strtolower($opts['security']) : strtolower((string)fd_cfg('IMAP_SECURITY', 'ssl'));
        $this->user       = isset($opts['user'])     ? $opts['user']     : fd_cfg('IMAP_USER');
        $this->pass       = isset($opts['pass'])     ? $opts['pass']     : fd_cfg('IMAP_PASS');
        $this->timeout    = isset($opts['timeout'])  ? (int)$opts['timeout'] : fd_cfg_int('IMAP_TIMEOUT', 30);
        $this->verifyPeer = isset($opts['verify_peer']) ? (bool)$opts['verify_peer'] : (bool)fd_cfg_int('IMAP_VERIFY_PEER', 0);
        $this->traceEnabled = !empty($opts['trace']);
        if ($this->timeout < 5) $this->timeout = 5;
    }

    public function getTrace()        { return $this->trace; }
    public function getCapabilities() { return $this->capabilities; }
    public function getSelectedInfo() { return $this->selectedInfo; }

    private function tr($dir, $line)
    {
        if (!$this->traceEnabled) return;
        // Never let a password reach a log or an API response.
        $line = preg_replace('/(LOGIN\s+\S+\s+).*/i', '$1***', $line);
        if (strlen($line) > 300) $line = substr($line, 0, 300) . '... (' . strlen($line) . ' bytes)';
        $this->trace[] = $dir . ' ' . rtrim($line);
    }

    /* ==================================================== connection ==== */

    public function connect()
    {
        if ($this->sock) return true;
        if (!$this->host || !$this->user) {
            throw new FdImapException('Mailbox is not configured (host/user missing). Set them in Settings > Email.');
        }

        $scheme = ($this->security === 'ssl') ? 'ssl://' : 'tcp://';
        $ctx = stream_context_create(array('ssl' => array(
            'verify_peer'       => $this->verifyPeer,
            'verify_peer_name'  => $this->verifyPeer,
            'allow_self_signed' => !$this->verifyPeer,
            'SNI_enabled'       => true,
            'peer_name'         => $this->host,
            // TLS 1.0/1.1 are dead but some cPanel mailhosts still negotiate
            // down; let the stream pick the best available rather than pinning.
            'ciphers'           => 'HIGH:!SSLv2:!SSLv3:!aNULL:!eNULL',
        )));

        $errno = 0; $errstr = '';
        $target = $scheme . $this->host . ':' . $this->port;
        // @ because a refused connection is an expected, reportable condition,
        // not a PHP warning we want spraying into the JSON response body.
        $this->sock = @stream_socket_client($target, $errno, $errstr, $this->timeout, STREAM_CLIENT_CONNECT, $ctx);

        if (!$this->sock) {
            $hint = '';
            if ($errno === 110 || stripos($errstr, 'timed out') !== false) {
                $hint = ' The host may be blocking outbound port ' . $this->port . ' -- shared hosts often firewall IMAP; ask the provider to open it.';
            } elseif (stripos($errstr, 'refused') !== false) {
                $hint = ' Nothing is listening on that port. Check IMAP_PORT (993 for SSL, 143 for STARTTLS).';
            } elseif (stripos($errstr, 'certificate') !== false || stripos($errstr, 'ssl') !== false) {
                $hint = ' TLS handshake failed. If the mailhost uses a self-signed certificate, set IMAP_VERIFY_PEER to 0.';
            }
            throw new FdImapException('Cannot reach ' . $this->host . ':' . $this->port . ' -- ' . $errstr . ' (' . $errno . ').' . $hint);
        }

        stream_set_timeout($this->sock, $this->timeout);

        // Server greeting: "* OK [CAPABILITY ...] Dovecot ready."
        $greet = $this->readResponseLine();
        $this->tr('<<', $greet);
        if (stripos($greet, '* OK') !== 0 && stripos($greet, '* PREAUTH') !== 0) {
            $this->close();
            throw new FdImapException('Mail server refused the connection: ' . trim($greet));
        }
        $this->parseCapability($greet);

        if ($this->security === 'tls') {
            $this->startTls();
        }
        return true;
    }

    private function startTls()
    {
        $r = $this->command('STARTTLS');
        if (!$r['ok']) throw new FdImapException('STARTTLS refused: ' . $r['message']);
        $crypto = STREAM_CRYPTO_METHOD_TLS_CLIENT;
        if (defined('STREAM_CRYPTO_METHOD_TLSv1_2_CLIENT')) {
            $crypto |= STREAM_CRYPTO_METHOD_TLSv1_2_CLIENT;
        }
        if (!@stream_socket_enable_crypto($this->sock, true, $crypto)) {
            $this->close();
            throw new FdImapException('Could not negotiate TLS after STARTTLS. Try security=ssl on port 993 instead.');
        }
        $this->capabilities = array();   // capabilities change post-TLS; re-read on demand
    }

    public function login()
    {
        $this->connect();
        // Quoted-string form handles the punctuation real mail passwords contain
        // ("5Hbe!j9rhbal~po1"); only " and \ need escaping inside it.
        $u = '"' . addcslashes($this->user, '"\\') . '"';
        $p = '"' . addcslashes($this->pass, '"\\') . '"';
        $r = $this->command('LOGIN ' . $u . ' ' . $p);
        if (!$r['ok']) {
            $msg = $r['message'];
            $hint = '';
            if (stripos($msg, 'authentication fail') !== false || stripos($msg, 'invalid credentials') !== false || stripos($msg, 'AUTHENTICATIONFAILED') !== false) {
                $hint = ' Check the mailbox password in Settings > Email. Note this must be the MAILBOX password, not a cPanel or webmail-app password.';
            }
            throw new FdImapException('IMAP login failed for ' . $this->user . ': ' . $msg . $hint);
        }
        $this->parseCapability(implode(' ', $r['untagged']));
        return true;
    }

    public function close()
    {
        if ($this->sock) {
            @fwrite($this->sock, 'ZZZZ LOGOUT' . "\r\n");
            @fclose($this->sock);
            $this->sock = null;
        }
        $this->selected = null;
    }

    /* ======================================================= protocol ==== */

    /**
     * Read one LOGICAL response line, resolving IMAP literals.
     *
     * A line ending in "{1234}" is followed by exactly 1234 raw bytes that are
     * NOT line-delimited. Those bytes are stashed in $this->literals and the
     * placeholder \x00LITn\x00 is left in the returned string, so callers get a
     * single flat line they can regex safely while still being able to recover
     * the exact original bytes.
     */
    private function readResponseLine()
    {
        $line = $this->readRawLine();
        if ($line === false) return false;

        // A response may chain several literals ("... {12}\r\nabcdefghijkl rest {5}\r\nhello)")
        $guard = 0;
        while (preg_match('/\{(\d+)\}\r?\n$/', $line, $m)) {
            if (++$guard > 200) throw new FdImapException('Malformed IMAP response: too many literals in one line.');
            $len   = (int)$m[1];
            $bytes = $this->readBytes($len);
            $idx   = count($this->literals);
            $this->literals[$idx] = $bytes;
            $line  = preg_replace('/\{' . $len . '\}\r?\n$/', "\x00LIT" . $idx . "\x00", $line);
            $more  = $this->readRawLine();
            if ($more === false) break;
            $line .= $more;
        }
        return $line;
    }

    private function readRawLine()
    {
        if (!$this->sock) throw new FdImapException('Connection lost.');
        $line = @fgets($this->sock, 8192);
        if ($line === false) {
            $meta = @stream_get_meta_data($this->sock);
            if (!empty($meta['timed_out'])) {
                throw new FdImapException('Mail server stopped responding (timeout after ' . $this->timeout . 's).');
            }
            return false;
        }
        // fgets stops at the buffer size too, so keep pulling until CRLF.
        while (substr($line, -1) !== "\n") {
            $next = @fgets($this->sock, 8192);
            if ($next === false) break;
            $line .= $next;
        }
        return $line;
    }

    private function readBytes($len)
    {
        $buf = '';
        $remaining = $len;
        $deadline = time() + $this->timeout;
        while ($remaining > 0) {
            $chunk = @fread($this->sock, min(8192, $remaining));
            if ($chunk === false || $chunk === '') {
                $meta = @stream_get_meta_data($this->sock);
                if (!empty($meta['timed_out']) || time() > $deadline) {
                    throw new FdImapException('Timed out reading ' . $len . ' bytes from the mail server.');
                }
                usleep(20000);
                continue;
            }
            $buf .= $chunk;
            $remaining -= strlen($chunk);
        }
        return $buf;
    }

    /**
     * Send a command and collect everything up to its tagged completion.
     * Returns ['ok'=>bool, 'status'=>OK|NO|BAD, 'message'=>..., 'untagged'=>[lines], 'literals'=>[...]]
     */
    private function command($cmd)
    {
        if (!$this->sock) throw new FdImapException('Not connected.');
        $tag = sprintf('A%04d', ++$this->tagSeq);
        $this->literals = array();
        $wire = $tag . ' ' . $cmd . "\r\n";
        $this->tr('>>', $wire);
        if (@fwrite($this->sock, $wire) === false) {
            throw new FdImapException('Failed to write to the mail server (connection dropped).');
        }

        $untagged = array();
        $status = 'BAD'; $message = '';
        $guard = 0;
        while (true) {
            if (++$guard > 100000) throw new FdImapException('Runaway IMAP response.');
            $line = $this->readResponseLine();
            if ($line === false) throw new FdImapException('Mail server closed the connection unexpectedly.');
            $this->tr('<<', $line);
            if (strpos($line, $tag . ' ') === 0) {
                $rest = trim(substr($line, strlen($tag) + 1));
                $parts = explode(' ', $rest, 2);
                $status  = strtoupper($parts[0]);
                $message = isset($parts[1]) ? trim($parts[1]) : '';
                break;
            }
            // "+ " is a continuation request (used by APPEND); the caller handles it.
            if (substr($line, 0, 2) === '+ ' || $line === "+\r\n") {
                $untagged[] = $line;
                break;
            }
            $untagged[] = $line;
        }
        return array(
            'ok'       => ($status === 'OK'),
            'status'   => $status,
            'message'  => $message,
            'untagged' => $untagged,
            'literals' => $this->literals,
            'tag'      => $tag,
        );
    }

    private function parseCapability($text)
    {
        if (preg_match('/\[?CAPABILITY ([^\]\r\n]+)\]?/i', $text, $m)) {
            $this->capabilities = array_map('strtoupper', preg_split('/\s+/', trim($m[1])));
        }
    }

    public function hasCapability($cap)
    {
        if (empty($this->capabilities)) {
            $r = $this->command('CAPABILITY');
            $this->parseCapability(implode(' ', $r['untagged']));
        }
        return in_array(strtoupper($cap), $this->capabilities, true);
    }

    /* ========================================================= folders ==== */

    /** List every selectable folder -- used by Settings to populate the folder pickers. */
    public function listFolders($pattern = '*')
    {
        $r = $this->command('LIST "" "' . addcslashes($pattern, '"\\') . '"');
        if (!$r['ok']) throw new FdImapException('LIST failed: ' . $r['message']);
        $out = array();
        foreach ($r['untagged'] as $line) {
            // * LIST (\HasNoChildren) "." INBOX.Sent
            if (preg_match('/^\* LIST \(([^)]*)\) (?:"([^"]*)"|NIL) (?:"(.*)"|(\S+))\s*$/i', trim($line), $m)) {
                $flags = strtoupper($m[1]);
                if (strpos($flags, '\\NOSELECT') !== false) continue;
                $name = ($m[3] !== '' && $m[3] !== null) ? $m[3] : (isset($m[4]) ? $m[4] : '');
                $name = $this->decodeModifiedUtf7($name);
                if ($name !== '') $out[] = $name;
            }
        }
        return $out;
    }

    /** SELECT a folder. Returns ['uidvalidity'=>int,'uidnext'=>int,'exists'=>int]. */
    public function selectFolder($folder, $readOnly = false)
    {
        $cmd = ($readOnly ? 'EXAMINE ' : 'SELECT ') . '"' . addcslashes($this->encodeModifiedUtf7($folder), '"\\') . '"';
        $r = $this->command($cmd);
        if (!$r['ok']) {
            throw new FdImapException('Cannot open folder "' . $folder . '": ' . $r['message']
                . ' -- check the exact folder name (cPanel uses "INBOX.Sent", not "Sent").');
        }
        $info = array('uidvalidity' => 0, 'uidnext' => 0, 'exists' => 0, 'recent' => 0);
        foreach ($r['untagged'] as $line) {
            if (preg_match('/UIDVALIDITY (\d+)/i', $line, $m)) $info['uidvalidity'] = (int)$m[1];
            if (preg_match('/UIDNEXT (\d+)/i', $line, $m))     $info['uidnext']     = (int)$m[1];
            if (preg_match('/^\* (\d+) EXISTS/i', trim($line), $m)) $info['exists']  = (int)$m[1];
            if (preg_match('/^\* (\d+) RECENT/i', trim($line), $m)) $info['recent']  = (int)$m[1];
        }
        $this->selected = $folder;
        $this->selectedInfo = $info;
        return $info;
    }

    /* ========================================================= searching == */

    /**
     * UIDs strictly greater than $sinceUid.
     *
     * "UID SEARCH UID n:*" is the correct incremental query and it has one
     * famous quirk: n:* ALWAYS matches at least one message (the highest UID)
     * even when nothing is newer than n, because IMAP ranges are inclusive and
     * * is clamped. So the result is filtered again in PHP. Skipping that
     * filter makes the newest email in the mailbox re-import on every single
     * sync tick, forever.
     */
    public function searchSinceUid($sinceUid)
    {
        $sinceUid = max(0, (int)$sinceUid);
        $from = $sinceUid + 1;
        $r = $this->command('UID SEARCH UID ' . $from . ':*');
        if (!$r['ok']) throw new FdImapException('UID SEARCH failed: ' . $r['message']);
        $uids = $this->parseSearchResult($r['untagged']);
        $uids = array_values(array_filter($uids, function ($u) use ($sinceUid) { return $u > $sinceUid; }));
        sort($uids, SORT_NUMERIC);
        return $uids;
    }

    /** UIDs of mail received in the last N days -- used to baseline a fresh mailbox. */
    public function searchSinceDays($days)
    {
        $days = max(1, (int)$days);
        $date = date('d-M-Y', strtotime('-' . $days . ' days'));
        $r = $this->command('UID SEARCH SINCE ' . $date);
        if (!$r['ok']) throw new FdImapException('UID SEARCH SINCE failed: ' . $r['message']);
        $uids = $this->parseSearchResult($r['untagged']);
        sort($uids, SORT_NUMERIC);
        return $uids;
    }

    /**
     * UIDs whose INTERNALDATE falls in [$since, $before) -- either bound may be
     * null for an open end. Dates are IMAP's own "01-Jan-2026" form.
     *
     * This is how the archive screen counts what the mailbox holds per year
     * WITHOUT importing any of it: SEARCH returns UIDs only, so a 40k-message
     * mailbox costs a few short round trips instead of 40k body fetches.
     *
     * SINCE is inclusive and BEFORE is exclusive in IMAP, so consecutive years
     * expressed as SINCE 01-Jan-Y BEFORE 01-Jan-Y+1 tile the calendar exactly
     * once with no double counting at the boundary.
     *
     * Note this matches on INTERNALDATE (when the server received it), not the
     * Date: header -- the two differ on forwarded and backdated mail, which is
     * also why these counts are shown beside, not merged into, the DB figures.
     */
    /**
     * @param array $exclude Header tests to negate, as array(array('FROM','mailer-daemon'), ...).
     *                       Each becomes `NOT FROM "mailer-daemon"`, ANDed with the rest, so the
     *                       SERVER drops them and their UIDs never reach us. That matters: the
     *                       alternative is fetching the message to find out it was a bounce, which
     *                       costs the full RFC822 download -- the expensive part -- for mail we are
     *                       going to throw away. On contact@internshipstudio.com two mailer-daemon
     *                       addresses alone account for about 70% of the mailbox.
     */
    public function searchDateRange($since = null, $before = null, $loUid = 0, $hiUid = 0, $exclude = array())
    {
        $criteria = array();
        /*
         * Optional UID window.
         *
         * Without it, a backfill over a 400,000-message mailbox re-downloads
         * and re-parses all 400,000 UIDs on EVERY batch -- gigabytes of
         * redundant transfer across a run, and a PHP array big enough to
         * threaten memory_limit on the HTTP path. Bounding the search to the
         * slice actually about to be processed makes each batch cost the same
         * whether the mailbox holds ten thousand messages or a million.
         *
         * "lo:hi" is a UID RANGE, not a sequence range -- correct here because
         * every other number this class deals in is also a UID.
         */
        if ($loUid > 0 && $hiUid > 0) $criteria[] = 'UID ' . (int)$loUid . ':' . (int)$hiUid;
        if ($since)  $criteria[] = 'SINCE ' . $since;
        if ($before) $criteria[] = 'BEFORE ' . $before;

        /*
         * Negated header tests. IMAP quoted strings escape \ and " only, and a
         * search key is a bare atom, so the key is whitelisted rather than
         * quoted -- anything else would be a protocol injection through what is
         * ultimately a config value.
         */
        foreach ($exclude as $ex) {
            if (!is_array($ex) || count($ex) < 2) continue;
            $key = strtoupper(preg_replace('/[^A-Za-z]/', '', $ex[0]));
            if (!in_array($key, array('FROM', 'TO', 'CC', 'BCC', 'SUBJECT', 'BODY', 'TEXT'), true)) continue;
            $val = (string)$ex[1];
            if ($val === '') continue;
            $criteria[] = 'NOT ' . $key . ' "' . str_replace(array('\\', '"'), array('\\\\', '\\"'), $val) . '"';
        }

        if (empty($criteria)) $criteria[] = 'ALL';

        $r = $this->command('UID SEARCH ' . implode(' ', $criteria));
        if (!$r['ok']) throw new FdImapException('UID SEARCH ' . implode(' ', $criteria) . ' failed: ' . $r['message']);
        $uids = $this->parseSearchResult($r['untagged']);
        sort($uids, SORT_NUMERIC);
        return $uids;
    }

    public function searchAll()
    {
        $r = $this->command('UID SEARCH ALL');
        if (!$r['ok']) throw new FdImapException('UID SEARCH ALL failed: ' . $r['message']);
        $uids = $this->parseSearchResult($r['untagged']);
        sort($uids, SORT_NUMERIC);
        return $uids;
    }

    private function parseSearchResult($untagged)
    {
        $uids = array();
        foreach ($untagged as $line) {
            if (preg_match('/^\* SEARCH(.*)$/i', trim($line), $m)) {
                foreach (preg_split('/\s+/', trim($m[1])) as $tok) {
                    if ($tok !== '' && ctype_digit($tok)) $uids[] = (int)$tok;
                }
            }
        }
        return array_values(array_unique($uids));
    }

    /* ========================================================= fetching == */

    /**
     * The FIRST few kilobytes of each message's body, for a whole set of UIDs in ONE command.
     *
     * fetchMessages() below asks for one message per command on purpose, so that a single
     * oversized or broken message cannot spoil a batch — the right trade for the helpdesk sync,
     * where a stuck batch means a deaf inbox. It is the wrong trade for reading four hundred
     * thousand archived delivery reports: there the cost is the round trips, and the only thing
     * wanted from each message is the address and SMTP code, which sit in the first kilobytes.
     *
     * BODY.PEEK[TEXT]<0.N> asks for exactly that prefix and, like everything else here, PEEK so
     * the mailbox's unread state is never touched.
     *
     * @return array [uid => string] partial body text
     */
    public function fetchPartialBodies($uids, $bytes = 8192)
    {
        $out = array();
        if (empty($uids)) return $out;
        $set = implode(',', array_map('intval', $uids));
        $r = $this->command('UID FETCH ' . $set . ' (UID BODY.PEEK[TEXT]<0.' . (int)$bytes . '>)');
        if (!$r['ok']) throw new FdImapException('Partial FETCH failed: ' . $r['message']);
        $literals = $r['literals'];
        $joined = implode('', $r['untagged']);
        if (preg_match_all('/UID (\d+).*?\x00LIT(\d+)\x00/is', $joined, $ms, PREG_SET_ORDER)) {
            foreach ($ms as $m) {
                $uid = (int)$m[1]; $idx = (int)$m[2];
                if (isset($literals[$idx])) $out[$uid] = $literals[$idx];
            }
        }
        return $out;
    }

    /**
     * Fetch full RFC822 sources for a set of UIDs.
     * Returns [uid => ['raw'=>string,'size'=>int,'internaldate'=>string,'flags'=>string]].
     *
     * BODY.PEEK[] rather than BODY[] on purpose: BODY[] sets \Seen, which would
     * mean the helpdesk silently marks every customer email as read in the
     * shared mailbox that humans also use in Roundcube.
     */
    public function fetchMessages($uids)
    {
        $out = array();
        if (empty($uids)) return $out;

        // One UID per FETCH. Slower than a batched range, but a single oversized
        // message can no longer blow up the whole batch, and a parse failure is
        // isolated to the message that caused it -- which matters far more here
        // than throughput, since a stuck batch means a deaf inbox.
        foreach ($uids as $uid) {
            $uid = (int)$uid;
            try {
                $r = $this->command('UID FETCH ' . $uid . ' (UID RFC822.SIZE INTERNALDATE FLAGS BODY.PEEK[])');
                if (!$r['ok']) {
                    fd_log('warn', 'FETCH failed for UID ' . $uid . ': ' . $r['message']);
                    continue;
                }
                $joined = implode('', $r['untagged']);
                $literals = $r['literals'];

                $raw = '';
                if (preg_match('/BODY\[\]\s*\x00LIT(\d+)\x00/i', $joined, $m)) {
                    $idx = (int)$m[1];
                    if (isset($literals[$idx])) $raw = $literals[$idx];
                } elseif (count($literals) === 1) {
                    // Some servers answer BODY[] without repeating the section name.
                    $raw = reset($literals);
                }
                if ($raw === '') {
                    fd_log('warn', 'Empty body for UID ' . $uid . ' -- skipped');
                    continue;
                }

                $size = 0; $idate = ''; $flags = '';
                if (preg_match('/RFC822\.SIZE (\d+)/i', $joined, $m))         $size  = (int)$m[1];
                if (preg_match('/INTERNALDATE "([^"]+)"/i', $joined, $m))     $idate = $m[1];
                if (preg_match('/FLAGS \(([^)]*)\)/i', $joined, $m))          $flags = trim($m[1]);

                $out[$uid] = array(
                    'uid'          => $uid,
                    'raw'          => $raw,
                    'size'         => $size ?: strlen($raw),
                    'internaldate' => $idate,
                    'flags'        => $flags,
                );
            } catch (FdImapException $e) {
                // A dead socket must abort the run; a per-message oddity must not.
                if (stripos($e->getMessage(), 'connection') !== false || stripos($e->getMessage(), 'closed') !== false) throw $e;
                fd_log('warn', 'Skipping UID ' . $uid . ': ' . $e->getMessage());
            }
        }
        return $out;
    }

    /** Headers only -- cheap enough to scan a large backlog for relevance. */
    public function fetchHeaders($uids)
    {
        $out = array();
        if (empty($uids)) return $out;
        $set = implode(',', array_map('intval', $uids));
        $r = $this->command('UID FETCH ' . $set . ' (UID INTERNALDATE BODY.PEEK[HEADER])');
        if (!$r['ok']) throw new FdImapException('Header FETCH failed: ' . $r['message']);
        $literals = $r['literals'];
        $joined = implode('', $r['untagged']);
        if (preg_match_all('/UID (\d+).*?\x00LIT(\d+)\x00/is', $joined, $ms, PREG_SET_ORDER)) {
            foreach ($ms as $m) {
                $uid = (int)$m[1]; $idx = (int)$m[2];
                if (isset($literals[$idx])) $out[$uid] = $literals[$idx];
            }
        }
        return $out;
    }

    /** Mark messages \Seen (optional -- off by default so humans keep their unread state). */
    public function markSeen($uids)
    {
        if (empty($uids)) return true;
        $set = implode(',', array_map('intval', $uids));
        $r = $this->command('UID STORE ' . $set . ' +FLAGS.SILENT (\\Seen)');
        return $r['ok'];
    }

    /**
     * APPEND a raw message into a folder -- how a reply sent through SMTP also
     * turns up in the mailbox's Sent folder, so an agent looking at Roundcube or
     * Outlook sees the same history the panel shows.
     *
     * Deliberately non-fatal at the caller: failing to file a copy must never
     * fail the send. The customer already has the mail.
     */
    public function appendMessage($folder, $rawMessage, $flags = '\\Seen')
    {
        if (!$this->sock) throw new FdImapException('Not connected.');
        $folderEnc = '"' . addcslashes($this->encodeModifiedUtf7($folder), '"\\') . '"';
        $len = strlen($rawMessage);
        $tag = sprintf('A%04d', ++$this->tagSeq);
        $cmd = $tag . ' APPEND ' . $folderEnc . ' (' . $flags . ') {' . $len . "}\r\n";
        $this->tr('>>', $cmd);
        @fwrite($this->sock, $cmd);

        // Server must answer "+ go ahead" before the literal is written.
        $cont = $this->readRawLine();
        $this->tr('<<', (string)$cont);
        if ($cont === false || substr(ltrim((string)$cont), 0, 1) !== '+') {
            throw new FdImapException('APPEND rejected by server: ' . trim((string)$cont));
        }
        @fwrite($this->sock, $rawMessage . "\r\n");

        $guard = 0;
        while (true) {
            if (++$guard > 1000) throw new FdImapException('APPEND: no completion from server.');
            $line = $this->readResponseLine();
            if ($line === false) throw new FdImapException('APPEND: connection closed.');
            $this->tr('<<', $line);
            if (strpos($line, $tag . ' ') === 0) {
                return stripos($line, ' OK') !== false;
            }
        }
    }

    public function noop()
    {
        $r = $this->command('NOOP');
        return $r['ok'];
    }

    /* ================================================== modified UTF-7 ==== */
    /*
     * IMAP folder names are modified UTF-7 (RFC 3501 s5.1.3), not UTF-8: an
     * "&" is literally "&-", and non-ASCII is base64 in &...- runs. Folders
     * here are ASCII ("INBOX.Sent"), but a mailbox with a localised "Sent" name
     * fails to SELECT without this, and the error ("folder does not exist")
     * gives no hint why.
     */

    public function encodeModifiedUtf7($s)
    {
        if (preg_match('/^[\x20-\x25\x27-\x7e]*$/', $s)) return str_replace('&', '&-', $s);
        $out = ''; $buf = '';
        $len = mb_strlen($s, 'UTF-8');
        for ($i = 0; $i < $len; $i++) {
            $ch = mb_substr($s, $i, 1, 'UTF-8');
            $isPrintable = preg_match('/^[\x20-\x25\x27-\x7e]$/', $ch);
            if ($isPrintable) {
                if ($buf !== '') { $out .= '&' . $this->b64u(mb_convert_encoding($buf, 'UTF-16BE', 'UTF-8')) . '-'; $buf = ''; }
                $out .= ($ch === '&') ? '&-' : $ch;
            } else {
                $buf .= $ch;
            }
        }
        if ($buf !== '') $out .= '&' . $this->b64u(mb_convert_encoding($buf, 'UTF-16BE', 'UTF-8')) . '-';
        return $out;
    }

    public function decodeModifiedUtf7($s)
    {
        if (strpos($s, '&') === false) return $s;
        return preg_replace_callback('/&([^-]*)-/', function ($m) {
            if ($m[1] === '') return '&';
            $b64 = str_replace(',', '/', $m[1]);
            $pad = strlen($b64) % 4;
            if ($pad) $b64 .= str_repeat('=', 4 - $pad);
            $bytes = base64_decode($b64);
            return $bytes === false ? $m[0] : mb_convert_encoding($bytes, 'UTF-8', 'UTF-16BE');
        }, $s);
    }

    private function b64u($bytes)
    {
        return str_replace(array('/', '='), array(',', ''), base64_encode($bytes));
    }

    public function __destruct()
    {
        // Best-effort; a half-open socket left behind ties up a server-side
        // connection slot, and cPanel mailboxes have very few of them.
        if ($this->sock) { @fclose($this->sock); $this->sock = null; }
    }
}

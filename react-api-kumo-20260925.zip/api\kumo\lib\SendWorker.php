<?php
/*
 * SendWorker — the batch engine.
 *
 * One tick:
 *   1. promote due scheduled campaigns to running (materialising the audience)
 *   2. for each running campaign, claim a batch of pending recipients
 *   3. spread them across the sending IPs that are healthy AND still have
 *      warmup quota left today
 *   4. build each message and hand it to KumoMTA through the bridge
 *   5. write results (recipient row, campaign counters, hourly stats, quota)
 *
 * Safety: an atomic claim (UPDATE … SET status='processing', claim_token=…)
 * plus a MySQL GET_LOCK means two overlapping cron ticks can never send the
 * same row twice.
 */

require_once __DIR__ . '/schema.php';
require_once __DIR__ . '/Stats.php';
require_once __DIR__ . '/Health.php';
require_once __DIR__ . '/Audience.php';
require_once __DIR__ . '/Mailer.php';
require_once __DIR__ . '/KumoClient.php';

/* Read-only attribute engine shared with the Netcore campaigns module: it only
   ever SELECTs (load_all_attributes + resolve_attribute_values_batch), so the
   Kumo sender can reuse it instead of carrying a second copy of the chain
   walker. Guarded because the workers box may not carry that folder. */
$kumoAttrLib = __DIR__ . '/../../campaigns/lib/AttributeResolver.php';
if (is_file($kumoAttrLib)) require_once $kumoAttrLib;

function kumo_within_send_window(): bool {
    $s = (int)kumo_setting('send_window_start', KUMO_SEND_WINDOW_START);
    $e = (int)kumo_setting('send_window_end',   KUMO_SEND_WINDOW_END);
    $h = (int)date('G');
    if ($s === $e) return true;                 // 24h sending
    return $s < $e ? ($h >= $s && $h < $e) : ($h >= $s || $h < $e);
}

/** IPs that may send right now, each with its remaining quota for today. */
function kumo_eligible_ips(array $restrictIds = []): array {
    global $conn;
    $rows = [];
    try {
        $where = "status='active' AND health <> 'red'";
        if ($restrictIds) $where .= ' AND id IN (' . implode(',', array_map('intval', $restrictIds)) . ')';
        $r = $conn->query("SELECT * FROM kumo_ips WHERE $where ORDER BY sort_order, id");
        while ($r && $x = $r->fetch_assoc()) {
            $remaining = kumo_remaining_today((int)$x['id']);
            if ($remaining <= 0) continue;
            $x['remaining'] = $remaining;
            $rows[] = $x;
        }
    } catch (\Throwable $e) { error_log('kumo_eligible_ips: ' . $e->getMessage()); }
    return $rows;
}

/** Promote scheduled campaigns whose time has come. */
function kumo_promote_due(): int {
    global $conn;
    $n = 0;
    try {
        $r = $conn->query("SELECT id FROM kumo_campaigns WHERE status='scheduled' AND scheduled_at IS NOT NULL AND scheduled_at <= NOW() LIMIT 20");
        $ids = [];
        while ($r && $x = $r->fetch_assoc()) $ids[] = (int)$x['id'];
        foreach ($ids as $id) {
            $conn->query("UPDATE kumo_campaigns SET status='running', started_at=COALESCE(started_at, NOW()) WHERE id=$id AND status='scheduled'");
            $chk = $conn->query("SELECT materialized_at FROM kumo_campaigns WHERE id=$id LIMIT 1");
            $row = $chk ? $chk->fetch_assoc() : null;
            if (!$row || $row['materialized_at'] === null) kumo_materialize($id);
            $n++;
        }
    } catch (\Throwable $e) { error_log('kumo_promote_due: ' . $e->getMessage()); }
    return $n;
}

/** Claims up to $limit pending rows for one campaign. Returns the claim token. */
function kumo_claim(int $campaignId, int $limit): array {
    global $conn;
    $token = bin2hex(random_bytes(16));
    try {
        $conn->query(sprintf(
            "UPDATE kumo_campaign_recipients SET status='processing', claim_token='%s', claimed_at=NOW()
             WHERE campaign_id=%d AND status='pending' ORDER BY id LIMIT %d",
            $conn->real_escape_string($token), $campaignId, max(1, $limit)
        ));
        if ($conn->affected_rows === 0) return ['token' => $token, 'rows' => []];

        $rows = [];
        $r = $conn->query("SELECT * FROM kumo_campaign_recipients WHERE campaign_id=$campaignId AND claim_token='" . $conn->real_escape_string($token) . "'");
        while ($r && $x = $r->fetch_assoc()) $rows[] = $x;
        return ['token' => $token, 'rows' => $rows];
    } catch (\Throwable $e) {
        error_log('kumo_claim: ' . $e->getMessage());
        return ['token' => $token, 'rows' => []];
    }
}

/** Puts a claimed-but-unsent row back in the queue (no attempt burned). */
function kumo_release(array $ids): void {
    global $conn;
    if (!$ids) return;
    $in = implode(',', array_map('intval', $ids));
    try {
        $conn->query("UPDATE kumo_campaign_recipients SET status='pending', claim_token=NULL, claimed_at=NULL WHERE id IN ($in) AND status='processing'");
    } catch (\Throwable $e) { error_log('kumo_release: ' . $e->getMessage()); }
}

/**
 * Sends one batch. Returns counts.
 */
/**
 * Files to attach to every message of this campaign, fetched once per batch.
 * Shape matches what kumo_build_message() expects: filename / content (base64) / type.
 */
function kumo_campaign_attachments(array $campaign): array {
    $list = json_decode((string)($campaign['attachments'] ?? '[]'), true) ?: [];
    if (!$list) return [];
    $s3 = __DIR__ . '/../../lib/S3Uploader.php';
    if (!is_file($s3)) return [];
    require_once $s3;

    $out = [];
    foreach ($list as $a) {
        $url = (string)($a['s3_url'] ?? '');
        if ($url === '') continue;
        $bytes = s3_fetch_bytes($url);
        if ($bytes === null) continue;
        $out[] = [
            'filename' => $a['filename'] ?? basename($url),
            'content'  => base64_encode($bytes),
            'type'     => $a['mime'] ?? 'application/octet-stream',
        ];
    }
    return $out;
}

/**
 * [NAME] => value for every recipient in the batch, in one pass.
 *
 * resolve_attribute_values_batch() wants rows with 'email' and 'user_id'; ours
 * carry the email only, so the resolver falls back to its email-keyed lookups —
 * which is what a Kumo contact (who may never have been a registered student)
 * can support anyway.
 */
function kumo_resolve_attributes(array $rows): array {
    if (!function_exists('load_all_attributes') || !function_exists('resolve_attribute_values_batch')) return [];
    try {
        $attrs = load_all_attributes();

        /* Attributes created with "Save in: Kumo" live in kumo_attributes and are
           invisible to load_all_attributes(). Their columns match campaign_attributes
           row for row, so the resolver walks them just the same once merged. A shared
           attribute of the same name wins — it is the one the picker inserted. */
        global $conn;
        $seen = [];
        foreach ($attrs as $a) $seen[strtolower((string)$a['name'])] = true;
        $q = $conn->query("SELECT * FROM kumo_attributes");
        while ($q && $x = $q->fetch_assoc()) {
            if (isset($seen[strtolower((string)$x['name'])])) continue;
            $attrs[] = $x;
        }

        if (!$attrs) return [];
        /* The resolver keys most attributes off users.id and only digs the id out
           of the email itself for LINKED ones — without this lookup every simple
           mapped attribute silently falls back to its default value. One query
           for the whole batch. */
        global $conn;
        $idByEmail = [];
        $emails = array_values(array_unique(array_filter(array_map(
            fn($r) => strtolower(trim((string)($r['email'] ?? ''))), $rows
        ))));
        foreach (array_chunk($emails, 500) as $chunk) {
            $in = implode(',', array_map(fn($e) => "'" . $conn->real_escape_string($e) . "'", $chunk));
            $r = $conn->query("SELECT user_id, email FROM users WHERE email IN ($in)");
            while ($r && $u = $r->fetch_assoc()) $idByEmail[strtolower((string)$u['email'])] = (int)$u['user_id'];
        }

        return resolve_attribute_values_batch($attrs, array_map(
            fn($r) => [
                'email'   => $r['email'],
                'user_id' => (int)($r['user_id'] ?? 0) ?: ($idByEmail[strtolower((string)$r['email'])] ?? 0),
            ],
            $rows
        ));
    } catch (\Throwable $e) {
        kumo_log('attribute resolve failed: ' . $e->getMessage());
        return [];
    }
}

function kumo_send_batch(array $campaign, array $rows, array $ips, KumoClient $client): array {
    global $conn;
    $res = ['sent' => 0, 'failed' => 0, 'skipped' => 0, 'released' => 0];
    if (!$rows) return $res;

    $attachments = kumo_campaign_attachments($campaign);
    $attrByEmail = kumo_resolve_attributes($rows);

    /* Round-robin across eligible IPs, but never beyond an IP's remaining quota. */
    $pool = [];
    foreach ($ips as $ip) $pool[] = ['ip' => $ip, 'left' => (int)$ip['remaining']];
    if (!$pool) { kumo_release(array_column($rows, 'id')); $res['released'] = count($rows); return $res; }

    $cursor   = 0;
    $perIp    = [];   // ip_id => sent count (for quota + stats)
    $statBump = [];   // ip_id|provider => sent

    foreach ($rows as $row) {
        /* Late suppression check — someone may have unsubscribed after the
           audience was materialised. */
        if (kumo_is_suppressed($row['email'])) {
            $conn->query("UPDATE kumo_campaign_recipients SET status='skipped', error='suppressed', claim_token=NULL WHERE id=" . (int)$row['id']);
            $res['skipped']++;
            continue;
        }

        /* Pick the next IP with quota left. */
        $chosen = null;
        for ($i = 0; $i < count($pool); $i++) {
            $idx = ($cursor + $i) % count($pool);
            if ($pool[$idx]['left'] > 0) { $chosen = $idx; break; }
        }
        if ($chosen === null) {            // every IP is out of quota for today
            kumo_release([$row['id']]);
            $res['released']++;
            continue;
        }
        $cursor = ($chosen + 1) % count($pool);
        $ipRow  = $pool[$chosen]['ip'];

        $row['attr_tokens'] = $attrByEmail[strtolower((string)$row['email'])] ?? [];
        $msg = kumo_build_message($campaign, $row, $ipRow, $attachments);
        $inj = $client->inject($msg['envelope_sender'], $msg['content'], [['email' => $row['email']]]);

        $ipId     = (int)$ipRow['id'];
        $provider = kumo_provider_of($row['email']);

        if (($inj['success_count'] ?? 0) > 0) {
            $pool[$chosen]['left']--;
            $perIp[$ipId]   = ($perIp[$ipId] ?? 0) + 1;
            $key            = $ipId . '|' . $provider;
            $statBump[$key] = ($statBump[$key] ?? 0) + 1;

            $conn->query("UPDATE kumo_campaign_recipients
                          SET status='sent', ip_id=$ipId, provider='" . $conn->real_escape_string($provider) . "',
                              sent_at=NOW(), attempts=attempts+1, claim_token=NULL, error=NULL
                          WHERE id=" . (int)$row['id']);
            $conn->query(sprintf(
                "INSERT INTO kumo_campaign_events (campaign_id, recipient_id, rid, ip_id, type, provider, created_at)
                 VALUES (%d, %d, '%s', %d, 'reception', '%s', NOW())",
                (int)$campaign['id'], (int)$row['id'], $conn->real_escape_string($row['rid']), $ipId,
                $conn->real_escape_string($provider)
            ));
            $res['sent']++;
        } else {
            $err        = substr((string)($inj['error'] ?? 'inject failed'), 0, 480);
            $attempts   = (int)$row['attempts'] + 1;
            $retryable  = ($inj['status'] ?? 0) === 0 || ($inj['status'] ?? 0) >= 500 || ($inj['status'] ?? 0) === 429;
            if ($retryable && $attempts < 4) {
                $conn->query("UPDATE kumo_campaign_recipients SET status='pending', claim_token=NULL, claimed_at=NULL,
                                 error='" . $conn->real_escape_string($err) . "' WHERE id=" . (int)$row['id']);
                $res['released']++;
            } else {
                $conn->query("UPDATE kumo_campaign_recipients SET status='failed', attempts=$attempts,
                                 error='" . $conn->real_escape_string($err) . "', claim_token=NULL WHERE id=" . (int)$row['id']);
                $res['failed']++;
            }
            if (!$retryable) kumo_log('inject failed for ' . $row['email'] . ': ' . $err);
        }
    }

    foreach ($perIp as $ipId => $n)   kumo_consume_quota((int)$ipId, (int)$n);
    foreach ($statBump as $key => $n) {
        [$ipId, $prov] = explode('|', $key, 2);
        kumo_stats_bump((int)$ipId, $prov, ['sent' => $n]);
    }
    return $res;
}

/** Recomputes a campaign's counters from its recipient rows (cheap, indexed). */
function kumo_refresh_campaign_counters(int $campaignId): void {
    global $conn;
    try {
        $r = $conn->query("SELECT
                SUM(status IN ('sent','delivered','bounced')) sent,
                SUM(status='delivered') delivered,
                SUM(status='bounced') bounced,
                SUM(status='failed') failed,
                SUM(status='skipped') skipped,
                SUM(status IN ('pending','processing')) remaining
            FROM kumo_campaign_recipients WHERE campaign_id=" . (int)$campaignId . " AND is_test=0");
        $x = $r ? $r->fetch_assoc() : null;
        if (!$x) return;
        $conn->query(sprintf(
            "UPDATE kumo_campaigns SET sent_count=%d, bounced_count=%d, skipped_count=%d, queued_count=%d WHERE id=%d",
            (int)$x['sent'], (int)$x['bounced'], (int)$x['skipped'], (int)$x['remaining'], (int)$campaignId
        ));
        if ((int)$x['remaining'] === 0) {
            $conn->query("UPDATE kumo_campaigns SET status='sent', completed_at=NOW()
                          WHERE id=" . (int)$campaignId . " AND status='running'");
        }
    } catch (\Throwable $e) { error_log('kumo_refresh_campaign_counters: ' . $e->getMessage()); }
}

/**
 * One worker tick. Returns a summary array (also used by the "Send now"
 * button's immediate response).
 */
function kumo_worker_tick(int $onlyCampaignId = 0): array {
    global $conn;
    $started = microtime(true);
    $out = ['promoted' => 0, 'campaigns' => [], 'sent' => 0, 'failed' => 0, 'skipped' => 0, 'note' => null];

    /* One worker at a time, across every machine. */
    $lock = $conn->query("SELECT GET_LOCK('kumo_send_worker', 0) AS l");
    $got  = $lock ? (int)$lock->fetch_assoc()['l'] : 0;
    if (!$got) { $out['note'] = 'another worker is already running'; return $out; }

    try {
        if (!kumo_within_send_window()) {
            $out['note'] = 'outside the sending window (' . kumo_setting('send_window_start', KUMO_SEND_WINDOW_START) . ':00–' . kumo_setting('send_window_end', KUMO_SEND_WINDOW_END) . ':00)';
            return $out;
        }

        kumo_warmup_tick();                 // makes sure today's caps exist
        $out['promoted'] = kumo_promote_due();

        $client = new KumoClient();
        if (!$client->isConfigured()) { $out['note'] = 'bridge not configured'; return $out; }

        $where = "status='running'";
        if ($onlyCampaignId) $where .= ' AND id=' . (int)$onlyCampaignId;
        $r = $conn->query("SELECT * FROM kumo_campaigns WHERE $where ORDER BY COALESCE(scheduled_at, created_at) LIMIT 10");
        $campaigns = [];
        while ($r && $x = $r->fetch_assoc()) $campaigns[] = $x;

        foreach ($campaigns as $c) {
            $restrict = $c['ip_mode'] === 'fixed'
                      ? array_filter(array_map('intval', json_decode((string)$c['ip_ids'], true) ?: []))
                      : [];
            $ips = kumo_eligible_ips($restrict);
            if (!$ips) {
                $out['campaigns'][] = ['id' => (int)$c['id'], 'note' => 'no IP with quota/health available'];
                continue;
            }

            $budget = array_sum(array_column($ips, 'remaining'));
            $claimN = min(KUMO_CLAIM_BATCH, max(1, $budget));
            $sentThis = 0;

            while (microtime(true) - $started < KUMO_WORKER_MAX_SECONDS) {
                $claim = kumo_claim((int)$c['id'], $claimN);
                if (!$claim['rows']) break;

                $res = kumo_send_batch($c, $claim['rows'], $ips, $client);
                $out['sent']    += $res['sent'];
                $out['failed']  += $res['failed'];
                $out['skipped'] += $res['skipped'];
                $sentThis       += $res['sent'];

                /* Refresh remaining quota after the batch. */
                $ips = kumo_eligible_ips($restrict);
                if (!$ips) break;
                if ($res['released'] > 0 && $res['sent'] === 0) break;   // nothing could go out
            }

            kumo_refresh_campaign_counters((int)$c['id']);
            $out['campaigns'][] = ['id' => (int)$c['id'], 'name' => $c['name'], 'sent' => $sentThis];
        }
    } catch (\Throwable $e) {
        $out['note'] = 'error: ' . $e->getMessage();
        kumo_log('worker tick error: ' . $e->getMessage());
    } finally {
        @$conn->query("SELECT RELEASE_LOCK('kumo_send_worker')");
    }

    return $out;
}

/** Fire-and-forget kick so "Send now" doesn't wait for the cron minute. */
function kumo_trigger_worker_async(int $campaignId = 0): void {
    $url = rtrim((string)kumo_setting('public_base_url', KUMO_PUBLIC_BASE_URL), '/') . '/kumo-send-worker.php?secret=' . urlencode(KUMO_CRON_SECRET);
    if ($campaignId) $url .= '&campaign_id=' . (int)$campaignId;

    $p = parse_url($url);
    $host = $p['host'] ?? '';
    if ($host === '') return;
    $path = ($p['path'] ?? '/') . (isset($p['query']) ? '?' . $p['query'] : '');
    $fp = @fsockopen('ssl://' . $host, 443, $errno, $errstr, 1);
    if (!$fp) return;
    stream_set_timeout($fp, 1);
    fwrite($fp, "GET $path HTTP/1.1\r\nHost: $host\r\nConnection: Close\r\n\r\n");
    fclose($fp);
}

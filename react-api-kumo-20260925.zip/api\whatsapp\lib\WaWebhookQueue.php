<?php
/*
 * The WhatsApp webhook INGEST side — deliberately the smallest file in this folder.
 *
 * WHY THIS EXISTS
 * webhook.php used to do the whole job inline: parse the payload, correlate every event back to
 * a recipient row, update the row, bump a counter on wa_campaigns, insert an event row, and only
 * then answer 'ok'. That works at 500 messages and collapses at 50,000, for three reasons that
 * all compound:
 *
 *   1. It required WaSendWorker.php (53 KB), WaInbox.php (55 KB) and schema.php (50 KB) — roughly
 *      160 KB of PHP parsed per delivery receipt, to record one word.
 *   2. wa_log() appends with LOCK_EX to a single 8 MB file, and the request summary line meant
 *      every callback took that exclusive lock. Concurrent receipts could not run in parallel at
 *      all; they queued on a file lock.
 *   3. `UPDATE wa_campaigns SET delivered_count = delivered_count + 1` took a row lock on the
 *      SAME row for every receipt in the campaign. 50,000 receipts is 50,000 serialized lock
 *      acquisitions on one row.
 *
 * Together those capped intake at roughly 3-5 receipts/second. A 490-message campaign drains in
 * about two minutes (which is what the reports actually showed); a 50,000-message campaign would
 * need three to five HOURS, on top of the genuine delivery delay.
 *
 * So the endpoint now does the least work that is still correct: authenticate the caller, write
 * the raw body to a queue table, answer 'ok'. Everything else moved to WaWebhookProcessor.php,
 * drained by wa-webhook-worker.php. Target for the ingest path is single-digit milliseconds.
 *
 * NOTHING HEAVY MAY BE REQUIRED FROM HERE. That is the whole point of the file, and it is easy
 * to undo by accident: pulling in schema.php for one helper puts 50 KB back on every callback.
 * The two helpers this needs (a minimal settings read and a lock-free log) are therefore
 * duplicated below rather than borrowed, and each says why.
 */

if (!defined('WA_WQ_LOADED')) define('WA_WQ_LOADED', 1);

/** Queue rows claimed per drain chunk. Big enough that the bulk queries below actually amortize,
 *  small enough that one crashed chunk re-runs quickly. */
if (!defined('WA_WEBHOOK_CHUNK')) define('WA_WEBHOOK_CHUNK', 2000);

/** How long one drainer invocation keeps polling before exiting for cron to restart it. Just
 *  under a minute so the every-minute cron never overlaps with itself for long. */
if (!defined('WA_WEBHOOK_WORKER_SECONDS')) define('WA_WEBHOOK_WORKER_SECONDS', 55);

/** Idle poll interval while a campaign is delivering. This is what makes "delivered updates
 *  within a second" true: an empty queue is re-checked five times a second, so a receipt is
 *  picked up almost the moment it lands rather than waiting for the next cron minute. */
if (!defined('WA_WEBHOOK_IDLE_POLL_MS')) define('WA_WEBHOOK_IDLE_POLL_MS', 200);

/** Idle poll interval when nothing is delivering. The drainer runs against a REMOTE database, so
 *  the fast poll above is five network round trips a second forever — worth paying only while
 *  someone is actually watching a number move. Still 30x faster than the cron minute. */
if (!defined('WA_WEBHOOK_QUIET_POLL_MS')) define('WA_WEBHOOK_QUIET_POLL_MS', 2000);

/** How long after a campaign finishes sending to keep polling fast. */
if (!defined('WA_WEBHOOK_ACTIVE_WINDOW')) define('WA_WEBHOOK_ACTIVE_WINDOW', 1800);   // 30 min

/** A queue row that fails this many times is parked as 'error' rather than retried forever —
 *  one malformed payload must never block the receipts queued behind it. */
if (!defined('WA_WEBHOOK_MAX_ATTEMPTS')) define('WA_WEBHOOK_MAX_ATTEMPTS', 3);

/** Ingest-side log, SEPARATE from wa-worker.log and written without LOCK_EX — see wa_wq_log(). */
if (!defined('WA_WEBHOOK_LOG_PATH')) define('WA_WEBHOOK_LOG_PATH', __DIR__ . '/../wa-webhook.log');

/**
 * A lock-free logger for the ingest path.
 *
 * wa_log() in WaSendWorker.php appends with LOCK_EX, and that single exclusive lock is the main
 * reason concurrent callbacks could not run in parallel. This one takes no lock: an append under
 * PIPE_BUF (4 KB on Linux) is atomic enough for a diagnostic log, and a very occasionally
 * interleaved line is an infinitely better trade than serializing the endpoint.
 *
 * It is also called sparingly — errors and once-a-minute summaries, never once per receipt.
 */
function wa_wq_log(string $msg): void {
    static $checked = false;
    // Trim opportunistically, once per process, so this file cannot grow without bound either.
    if (!$checked) {
        $checked = true;
        $size = @filesize(WA_WEBHOOK_LOG_PATH);
        if ($size !== false && $size > 4 * 1024 * 1024) {
            $fp = @fopen(WA_WEBHOOK_LOG_PATH, 'r');
            if ($fp) {
                @fseek($fp, -1048576, SEEK_END);
                @fgets($fp);
                $tail = @stream_get_contents($fp);
                @fclose($fp);
                if ($tail !== false) @file_put_contents(WA_WEBHOOK_LOG_PATH, $tail);
            }
        }
    }
    @file_put_contents(WA_WEBHOOK_LOG_PATH, '[' . date('Y-m-d H:i:s') . '] ' . $msg . "\n", FILE_APPEND);
}

/**
 * Creates the queue table.
 *
 * Stamped in the temp dir exactly like whatsapp_ensure_schema(), so this costs one is_file()
 * after the first call rather than a DDL round trip per callback.
 */
function wa_wq_ensure_schema(): void {
    global $conn;
    if (!$conn) return;

    static $done = false;
    if ($done) return;

    $stamp = sys_get_temp_dir() . '/wa_webhook_queue_v2.ok';
    if (@is_file($stamp)) { $done = true; return; }
    $done = true;

    /*
     * raw_body is MEDIUMTEXT rather than TEXT: a Meta batch callback carrying several hundred
     * statuses comfortably passes TEXT's 64 KB ceiling, and a silently TRUNCATED payload is the
     * worst possible failure here — it would parse as valid JSON right up to the cut and drop
     * the receipts after it with no error anywhere.
     *
     * idx_status_id is the claim index: the drainer's only hot query is
     * "oldest N rows WHERE status='pending'", and (status, id) serves it as a range scan with
     * no filesort.
     *
     * claim_token is what makes the queue safe on MORE THAN ONE MACHINE, which this deployment
     * actually is: webhook.php has to live on the public web server because that is where Netcore
     * POSTs, while the drainer's cron runs on the monitoring box, and both talk to the same
     * database. An flock() is a LOCAL lock and cannot see across machines, so "flip rows to
     * processing, then read back the processing rows" would let a drainer on one host read the
     * rows another host had just claimed — applying every one of them twice. Most of the apply is
     * idempotent, but wa_campaign_events would gain duplicate rows and click/reply counts would
     * genuinely double.
     *
     * So each claim stamps a token that is unique to that one claim, and reads back only its own
     * rows. Two drainers then simply take different work, on the same machine or on different
     * ones, with no coordination between them.
     *
     * claimed_at is the companion: it is how a run that died mid-chunk is told apart from one
     * still working, so recovery never steals rows out from under a live drainer.
     */
    try {
        $conn->query("CREATE TABLE IF NOT EXISTS wa_webhook_queue (
        id            BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        raw_body      MEDIUMTEXT NOT NULL,
        source        VARCHAR(16)  DEFAULT NULL,
        status        ENUM('pending','processing','error') NOT NULL DEFAULT 'pending',
        attempts      TINYINT UNSIGNED NOT NULL DEFAULT 0,
        claim_token   CHAR(32)     DEFAULT NULL,
        claimed_at    DATETIME     DEFAULT NULL,
        error_message VARCHAR(500) DEFAULT NULL,
        received_at   DATETIME NOT NULL,
            INDEX idx_status_id (status, id),
            INDEX idx_claim (claim_token),
            INDEX idx_received (received_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        @touch($stamp);
    } catch (\Throwable $e) {
        // No stamp is written, so the next request retries the DDL. The enqueue below will fail
        // loudly in the meantime rather than this throwing a 500 at the provider.
        wa_wq_log('could not create wa_webhook_queue — ' . $e->getMessage());
    }
}

/**
 * Writes one raw callback body to the queue. This is the entire hot path.
 *
 * received_at is stamped with PHP's clock rather than MySQL's NOW() for the same reason
 * wa_activate_due_scheduled() does: on shared hosting the two can sit in different timezones,
 * and this timestamp is what the lag figure in the drain summary is measured against.
 *
 * @return bool false when the insert failed — the caller must then answer 'ok' anyway (a webhook
 *              that returns an error gets retried and eventually disabled by the provider) but
 *              log it, because a dropped receipt is a permanently wrong report.
 */
function wa_wq_enqueue(string $raw, ?string $source = null): bool {
    global $conn;
    if (!$conn) return false;

    $src = $source === null ? 'NULL' : "'" . $conn->real_escape_string(substr($source, 0, 16)) . "'";
    try {
        $ok = $conn->query("INSERT INTO wa_webhook_queue (raw_body, source, status, received_at)
                            VALUES ('" . $conn->real_escape_string($raw) . "', $src, 'pending', '" . date('Y-m-d H:i:s') . "')");
        return (bool)$ok;
    } catch (\Throwable $e) {
        wa_wq_log('ENQUEUE FAILED — ' . $e->getMessage() . ' — body: ' . substr($raw, 0, 300));
        return false;
    }
}

/**
 * The two settings the ingest path needs, read directly instead of through wa_settings_row().
 *
 * wa_settings_row() lives in schema.php, and requiring that file for two columns would put 50 KB
 * of DDL-building code back on every single callback — precisely the cost this rewrite removes.
 * Static-cached because the signature check and the source guess both call it.
 */
function wa_wq_auth_settings(): array {
    global $conn;
    static $cached = null;
    if ($cached !== null) return $cached;

    $cached = ['webhook_secret' => '', 'meta_app_secret' => ''];
    /*
     * try/catch, not just @: PHP 8.1+ puts mysqli in exception mode by default, so a wa_settings
     * table this install has not created yet THROWS rather than returning false. Uncaught, that
     * would 500 the endpoint and make the provider retry — and eventually disable — the webhook.
     * No settings simply means no credentials are configured, which the caller already handles.
     */
    try {
        $r = $conn->query("SELECT webhook_secret, meta_app_secret FROM wa_settings ORDER BY id LIMIT 1");
        if ($r && $row = $r->fetch_assoc()) {
            $cached['webhook_secret']  = trim((string)($row['webhook_secret'] ?? ''));
            $cached['meta_app_secret'] = trim((string)($row['meta_app_secret'] ?? ''));
        }
    } catch (\Throwable $e) {
        // fall through with empty credentials
    }
    return $cached;
}

/**
 * Nudges the drainer so a receipt is processed now rather than at the next cron minute.
 *
 * RATE-LIMITED ON PURPOSE, and that is the important part: a kick per receipt would put an
 * fsockopen() back on the hot path and undo the rewrite. The stamp file means at most one kick
 * every WA_WEBHOOK_KICK_EVERY seconds no matter how many callbacks arrive, and the drainer's own
 * flock makes a redundant kick a no-op.
 *
 * Failure is silently ignored: cron is the reliable path, this is only the accelerator.
 */
function wa_wq_kick(): void {
    if (!defined('WA_WORKER_HOST') || !defined('WA_CRON_SECRET')) return;

    $stamp = sys_get_temp_dir() . '/wa_webhook_kick.stamp';
    $now   = time();
    clearstatcache(true, $stamp);
    $last  = @filemtime($stamp);
    if ($last !== false && $now - $last < 5) return;
    @touch($stamp);

    $path = dirname(WA_WORKER_PATH) . '/wa-webhook-worker.php?cron_secret=' . urlencode(WA_CRON_SECRET);
    // 1-second connect timeout, write, close without reading: the response is fire-and-forget.
    $fp = @fsockopen('ssl://' . WA_WORKER_HOST, 443, $errno, $errstr, 1);
    if (!$fp) return;
    stream_set_timeout($fp, 1);
    @fwrite($fp, "GET $path HTTP/1.1\r\nHost: " . WA_WORKER_HOST . "\r\nConnection: Close\r\n\r\n");
    @fclose($fp);
}

<?php
/*
 * /api/attributes/attributes.php
 *
 * action=list            &page &per_page &search   → paginated campaign_attributes
 * action=get              &id                       → single attribute row
 * action=search_columns   &q                         → cross-database column search for the mapping picker
 * action=search_tables    &q                         → cross-database table search for the chain builder
 * action=table_columns    &db &table                 → every column of one table, for the chain builder
 * action=date_formats                                → the date output presets + a rendered sample of each
 * action=preview          &email &data_type [&date_format] [&default_value]
 *                          [&mapped_db &mapped_table &mapped_column] [&resolver_json]
 *                                                    → resolve an UNSAVED definition for one real
 *                                                      recipient, so a chain can be tested before saving
 * action=create           &name &data_type &default_value [&date_format]
 *                          [&mapped_db &mapped_table &mapped_column] [&resolver_json]
 * action=update           &id [&default_value] [&date_format] [&resolver_json]
 *                          [&name — only if still unmapped]
 * action=delete           &id
 * action=logs             &page &per_page            → paginated campaign_attribute_logs
 *
 * An attribute is one of three kinds, decided by what create receives:
 *   resolver_json → 'linked'  (multi-step lookup chain)
 *   mapped_*      → 'system'  (one table.column)
 *   neither       → 'custom'  (no database source at all — default_value is then REQUIRED,
 *                              since it is the only value the attribute can ever produce
 *                              until a CSV import fills it in per contact)
 */
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../middleware/auth.php';
require_once __DIR__ . '/lib/schema.php';
require_once __DIR__ . '/../campaigns/lib/AttributeResolver.php'; // action=preview resolves through the real send-time resolver

attributes_ensure_schema();

$jwt = require_jwt();
/* Shared with the Kumo MTA module, which manages the same data through
   this endpoint — so either permission may use it. */
require_any_permission(['netcore_behaviour', 'kumo_mta'], $jwt);

function jin($k, $d = null) { $v = $_REQUEST[$k] ?? null; return ($v === null || $v === '') ? $d : $v; }

// ATTRIBUTES_SEARCHABLE_DBS (the databases this feature may read from) now lives in
// lib/schema.php, because the send-time resolver needs the same allowlist.

/** Which of 'user_id' / 'email' (in that priority order) exists as a real column on
 *  $db.$table — the join key used to correlate that table's row back to a recipient.
 *  Returns null if neither exists (table can't be used as an attribute source). */
function detect_join_column(string $db, string $table): ?string {
    global $conn;
    $dbE = $conn->real_escape_string($db);
    $tableE = $conn->real_escape_string($table);
    $r = $conn->query("SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS
                        WHERE TABLE_SCHEMA='$dbE' AND TABLE_NAME='$tableE'
                          AND COLUMN_NAME IN ('user_id','email')");
    $found = [];
    while ($r && $row = $r->fetch_assoc()) $found[$row['COLUMN_NAME']] = true;
    if (isset($found['user_id'])) return 'user_id';
    if (isset($found['email'])) return 'email';
    return null;
}

$action = jin('action', '');

if ($action === 'list') {
    $page    = max(1, (int)jin('page', 1));
    $perPage = max(1, min(100, (int)jin('per_page', 25)));
    $search  = trim((string)jin('search', ''));
    $offset  = ($page - 1) * $perPage;

    $where = '';
    if ($search !== '') $where = "WHERE name LIKE '%" . $conn->real_escape_string($search) . "%'";

    $tr = $conn->query("SELECT COUNT(*) AS c FROM campaign_attributes $where");
    $total = $tr ? (int)$tr->fetch_assoc()['c'] : 0;

    $r = $conn->query("SELECT id, name, category, data_type, date_format, mapped_db, mapped_table, mapped_column, mapped_join_col, resolver_json, default_value, created_at, updated_at
                        FROM campaign_attributes $where
                        ORDER BY id DESC LIMIT $perPage OFFSET $offset");
    $rows = [];
    while ($r && $row = $r->fetch_assoc()) {
        // Pre-rendered so the list's Mapped source column doesn't have to re-derive it in JS.
        $row['chain_summary'] = $row['category'] === 'linked' ? attr_chain_summary($row['resolver_json']) : '';
        $rows[] = $row;
    }

    api_success([
        'attributes' => $rows, 'total' => $total, 'page' => $page, 'per_page' => $perPage,
        'pages' => $total > 0 ? (int)ceil($total / $perPage) : 1,
    ]);
}

if ($action === 'get') {
    $id = (int)jin('id', 0);
    $r = $conn->query("SELECT * FROM campaign_attributes WHERE id=$id LIMIT 1");
    $row = $r ? $r->fetch_assoc() : null;
    if (!$row) api_error('Not found', 404);
    api_success(['attribute' => $row]);
}

if ($action === 'search_columns') {
    $q = trim((string)jin('q', ''));
    if (strlen($q) < 2) api_success(['results' => []]);
    $qE = $conn->real_escape_string($q);

    $dbList = implode(',', array_map(fn($d) => "'" . $conn->real_escape_string($d) . "'", ATTRIBUTES_SEARCHABLE_DBS));
    $r = $conn->query("SELECT TABLE_SCHEMA AS db, TABLE_NAME AS tbl, COLUMN_NAME AS col, DATA_TYPE AS data_type
                        FROM INFORMATION_SCHEMA.COLUMNS
                        WHERE TABLE_SCHEMA IN ($dbList)
                          AND (COLUMN_NAME LIKE '%$qE%' OR TABLE_NAME LIKE '%$qE%')
                        ORDER BY TABLE_NAME, COLUMN_NAME
                        LIMIT 200");

    // Group by table first so we only run detect_join_column() once per distinct table,
    // not once per matching column.
    $byTable = [];
    while ($r && $row = $r->fetch_assoc()) {
        $key = $row['db'] . '.' . $row['tbl'];
        $byTable[$key]['db'] = $row['db'];
        $byTable[$key]['table'] = $row['tbl'];
        $byTable[$key]['columns'][] = ['column' => $row['col'], 'data_type' => $row['data_type']];
    }

    $results = [];
    foreach ($byTable as $t) {
        $joinCol = detect_join_column($t['db'], $t['table']);
        if (!$joinCol) continue; // no user_id/email on this table — can't correlate to a recipient
        foreach ($t['columns'] as $c) {
            if ($c['column'] === $joinCol) continue; // don't offer the join key itself as a value column
            $results[] = ['db' => $t['db'], 'table' => $t['table'], 'column' => $c['column'], 'data_type' => $c['data_type'], 'join_col' => $joinCol];
        }
    }
    api_success(['results' => array_slice($results, 0, 100)]);
}

if ($action === 'date_formats') {
    api_success(['formats' => attr_date_presets_with_samples()]);
}

/* Table search for the chain builder. Unlike search_columns this does NOT require the
 * table to carry a user_id/email column: a chain's later steps join on whatever the
 * previous step returned (an assigned_id, a CIT version string, …), so a lookup table
 * with no notion of a user at all is a perfectly valid step. */
if ($action === 'search_tables') {
    $q = trim((string)jin('q', ''));
    if (strlen($q) < 2) api_success(['results' => []]);
    $qE = $conn->real_escape_string($q);
    $dbList = implode(',', array_map(fn($d) => "'" . $conn->real_escape_string($d) . "'", ATTRIBUTES_SEARCHABLE_DBS));
    $r = $conn->query("SELECT TABLE_SCHEMA AS db, TABLE_NAME AS tbl
                        FROM INFORMATION_SCHEMA.TABLES
                        WHERE TABLE_SCHEMA IN ($dbList) AND TABLE_NAME LIKE '%$qE%'
                        ORDER BY TABLE_NAME LIMIT 60");
    $results = [];
    while ($r && $row = $r->fetch_assoc()) $results[] = ['db' => $row['db'], 'table' => $row['tbl']];
    api_success(['results' => $results]);
}

if ($action === 'table_columns') {
    $db = trim((string)jin('db', ''));
    $table = trim((string)jin('table', ''));
    if (!in_array($db, ATTRIBUTES_SEARCHABLE_DBS, true)) api_error('Invalid database');
    $cols = attr_table_columns($db, $table);
    if (!$cols) api_error('That table does not exist', 404);
    $out = [];
    foreach ($cols as $name => $type) $out[] = ['column' => $name, 'data_type' => $type];
    api_success(['columns' => $out]);
}

/* Resolve a definition that has NOT been saved yet, for one real recipient — the "Test"
 * button in the create drawer. Runs through the exact same send-time code path as a real
 * campaign (resolve_attribute_values_batch), so what it shows is what the template will
 * render, including the date format. Nothing is written. */
if ($action === 'preview') {
    $email = strtolower(trim((string)jin('email', '')));
    if ($email === '') api_error('Enter an email address to test with');

    // The recipient row a campaign would have built: email plus the user_id behind it,
    // since a user_id-seeded chain (and a user_id-joined mapping) needs both.
    $emailE = $conn->real_escape_string($email);
    $ur = $conn->query("SELECT user_id FROM `" . ATTRIBUTES_USERS_DB . "`.`" . ATTRIBUTES_USERS_TABLE . "` WHERE email='$emailE' LIMIT 1");
    $userId = ($ur && $ur->num_rows) ? (int)$ur->fetch_assoc()['user_id'] : null;

    $dataType = jin('data_type', 'text');
    $dateFormat = trim((string)jin('date_format', ''));
    $resolverJson = trim((string)jin('resolver_json', ''));
    $mappedDb = trim((string)jin('mapped_db', ''));
    $mappedTable = trim((string)jin('mapped_table', ''));
    $mappedColumn = trim((string)jin('mapped_column', ''));

    $attr = [
        'id' => 0, 'name' => 'PREVIEW', 'category' => 'custom', 'data_type' => $dataType,
        'date_format' => $dateFormat !== '' ? $dateFormat : null,
        'mapped_db' => null, 'mapped_table' => null, 'mapped_column' => null, 'mapped_join_col' => null,
        'resolver_json' => null, 'default_value' => jin('default_value', ''),
    ];

    if ($resolverJson !== '') {
        $norm = attr_chain_normalize($resolverJson);
        if (!$norm['ok']) api_error($norm['error']);
        $attr['category'] = 'linked';
        $attr['resolver_json'] = json_encode($norm['chain']);
    } elseif ($mappedDb !== '' && $mappedTable !== '' && $mappedColumn !== '') {
        if (!in_array($mappedDb, ATTRIBUTES_SEARCHABLE_DBS, true)) api_error('Invalid database');
        $cols = attr_table_columns($mappedDb, $mappedTable);
        if (!isset($cols[$mappedColumn])) api_error('That table/column does not exist');
        $joinCol = detect_join_column($mappedDb, $mappedTable);
        if (!$joinCol) api_error('That table has no user_id or email column to match it back to a recipient');
        $attr['category'] = 'system';
        $attr['mapped_db'] = $mappedDb; $attr['mapped_table'] = $mappedTable;
        $attr['mapped_column'] = $mappedColumn; $attr['mapped_join_col'] = $joinCol;
    } else {
        // No source at all — the default value is the whole answer, and there is nothing to
        // look up. Answered here rather than through the resolver, which would go looking for
        // a campaign_attribute_data column this unsaved attribute doesn't have.
        api_success(['value' => (string)$attr['default_value'], 'user_id' => $userId, 'used_default' => true]);
    }

    $resolved = resolve_attribute_values_batch([$attr], [['email' => $email, 'user_id' => $userId]]);
    $value = $resolved[$email]['[PREVIEW]'] ?? '';
    api_success([
        'value' => $value,
        'user_id' => $userId,
        'used_default' => ($value !== '' && $value === (string)$attr['default_value']),
    ]);
}

if ($action === 'create') {
    $rawName = trim((string)jin('name', ''));
    $dataType = jin('data_type', 'text');
    $defaultValue = jin('default_value', null);
    $mappedDb = trim((string)jin('mapped_db', ''));
    $mappedTable = trim((string)jin('mapped_table', ''));
    $mappedColumn = trim((string)jin('mapped_column', ''));
    $resolverJson = trim((string)jin('resolver_json', ''));
    $dateFormat = trim((string)jin('date_format', ''));

    if ($rawName === '') api_error('Attribute name required');
    $name = normalize_attribute_name($rawName);
    if ($name === '') api_error('Attribute name must contain at least one letter or number');
    if (!in_array($dataType, ['text', 'number', 'date', 'url', 'boolean'], true)) $dataType = 'text';
    if ($dateFormat !== '' && ($dataType !== 'date' || !attr_is_valid_date_format($dateFormat))) $dateFormat = '';

    $existing = $conn->query("SELECT id FROM campaign_attributes WHERE name='" . $conn->real_escape_string($name) . "' LIMIT 1");
    if ($existing && $existing->num_rows > 0) api_error("An attribute named $name already exists");

    $category = 'custom';
    $joinCol = null;
    $chainStore = null;
    if ($resolverJson !== '') {
        // A multi-step chain, e.g. user_id → assigned_links.assigned_id →
        // whatsapp_placement_club_link.community_link, with a fallback path through the
        // *_for_refund tables. attr_chain_normalize() re-verifies every db/table/column
        // against INFORMATION_SCHEMA, since these become SQL identifiers at send time.
        $norm = attr_chain_normalize($resolverJson);
        if (!$norm['ok']) api_error($norm['error']);
        $chainStore = json_encode($norm['chain']);
        $category = 'linked';
    } elseif ($mappedDb !== '' && $mappedTable !== '' && $mappedColumn !== '') {
        if (!in_array($mappedDb, ATTRIBUTES_SEARCHABLE_DBS, true)) api_error('Invalid database');
        // Never trust the client's earlier search_columns response blindly — re-verify
        // server-side that this exact column really exists before wiring it up.
        $dbE = $conn->real_escape_string($mappedDb);
        $tableE = $conn->real_escape_string($mappedTable);
        $colE = $conn->real_escape_string($mappedColumn);
        $chk = $conn->query("SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS
                              WHERE TABLE_SCHEMA='$dbE' AND TABLE_NAME='$tableE' AND COLUMN_NAME='$colE'");
        if (!$chk || $chk->num_rows === 0) api_error('That table/column no longer exists');
        $joinCol = detect_join_column($mappedDb, $mappedTable);
        if (!$joinCol) api_error('That table has no user_id or email column to match it back to a recipient');
        $category = 'system';
    }

    // With no database source of any kind there is nothing to look up, so the default value
    // IS the attribute's value — requiring it here is what stops a template rendering an
    // empty token for every recipient.
    if ($category === 'custom' && ($defaultValue === null || trim((string)$defaultValue) === '')) {
        api_error('A default value is required when the attribute is not linked to the database');
    }

    $nameE = $conn->real_escape_string($name);
    $catE = $conn->real_escape_string($category);
    $typeE = $conn->real_escape_string($dataType);
    $fmtE = $dateFormat !== '' ? "'" . $conn->real_escape_string($dateFormat) . "'" : 'NULL';
    $defaultE = $defaultValue !== null ? "'" . $conn->real_escape_string($defaultValue) . "'" : 'NULL';
    $mDbE = $category === 'system' ? "'" . $conn->real_escape_string($mappedDb) . "'" : 'NULL';
    $mTableE = $category === 'system' ? "'" . $conn->real_escape_string($mappedTable) . "'" : 'NULL';
    $mColE = $category === 'system' ? "'" . $conn->real_escape_string($mappedColumn) . "'" : 'NULL';
    $mJoinE = $joinCol !== null ? "'" . $conn->real_escape_string($joinCol) . "'" : 'NULL';
    $chainE = $chainStore !== null ? "'" . $conn->real_escape_string($chainStore) . "'" : 'NULL';

    $conn->query("INSERT INTO campaign_attributes (name, category, data_type, date_format, mapped_db, mapped_table, mapped_column, mapped_join_col, resolver_json, default_value, created_by)
                  VALUES ('$nameE', '$catE', '$typeE', $fmtE, $mDbE, $mTableE, $mColE, $mJoinE, $chainE, $defaultE, " . (int)($jwt['user_id'] ?? 0) . ")");
    $id = $conn->insert_id;
    if ($category === 'custom') attribute_data_ensure_column($name);
    attribute_log($id, $name, 'Attribute created', (string)($jwt['user_id'] ?? ''));
    api_success(['id' => $id, 'name' => $name]);
}

if ($action === 'update') {
    $id = (int)jin('id', 0);
    if (!$id) api_error('id required');
    $r = $conn->query("SELECT * FROM campaign_attributes WHERE id=$id LIMIT 1");
    $row = $r ? $r->fetch_assoc() : null;
    if (!$row) api_error('Not found', 404);

    $set = [];
    // Same rule as create: an attribute with no database source has nothing but its default
    // value, so an existing one can't be blanked out. Scoped to attributes that actually
    // HAVE a default today, so a CSV-auto-created attribute (real per-contact data, no
    // default) stays editable without being forced to invent one. array_key_exists (not
    // jin) because jin() maps '' to its default and would hide the case being rejected.
    $defaultValue = jin('default_value', null);
    if (array_key_exists('default_value', $_REQUEST) && trim((string)$_REQUEST['default_value']) === ''
        && $row['category'] === 'custom' && trim((string)$row['default_value']) !== ''
        && trim((string)jin('resolver_json', '')) === ''
        && trim((string)jin('mapped_column', '')) === '') {
        api_error('A default value is required when the attribute is not linked to the database');
    }
    if ($defaultValue !== null) $set[] = "default_value='" . $conn->real_escape_string($defaultValue) . "'";

    // The date output format is presentation only — it can be changed at any time, on any
    // kind of attribute, without touching a single stored value. Passing an empty string
    // clears it (back to the raw database value).
    if (array_key_exists('date_format', $_REQUEST) && $row['data_type'] === 'date') {
        $dateFormat = trim((string)$_REQUEST['date_format']);
        if ($dateFormat !== '' && !attr_is_valid_date_format($dateFormat)) api_error('Unknown date format');
        $set[] = $dateFormat === '' ? "date_format=NULL" : "date_format='" . $conn->real_escape_string($dateFormat) . "'";
    }

    // A chain is a definition, not data, so unlike a table.column mapping it stays editable —
    // getting a multi-step lookup right usually takes a couple of passes.
    $resolverJson = trim((string)jin('resolver_json', ''));
    if ($resolverJson !== '') {
        if ($row['category'] === 'system') api_error('This attribute is mapped to a single column — mappings cannot be changed once set');
        $norm = attr_chain_normalize($resolverJson);
        if (!$norm['ok']) api_error($norm['error']);
        $set[] = "category='linked'";
        $set[] = "resolver_json='" . $conn->real_escape_string(json_encode($norm['chain'])) . "'";
    }

    // Renaming is only allowed while the attribute is still unmapped — once mapped, the
    // name (and its token) is locked, matching the reference product's own rule that a
    // mapped attribute "cannot be unmapped or changed".
    $rawName = jin('name', null);
    if ($rawName !== null && $row['category'] !== 'system') {
        $name = normalize_attribute_name($rawName);
        if ($name === '') api_error('Attribute name must contain at least one letter or number');
        $dup = $conn->query("SELECT id FROM campaign_attributes WHERE name='" . $conn->real_escape_string($name) . "' AND id<>$id LIMIT 1");
        if ($dup && $dup->num_rows > 0) api_error("An attribute named $name already exists");
        $set[] = "name='" . $conn->real_escape_string($name) . "'";
    }

    // "Select existing attribute" flow (CreateAttributeModal.jsx's second tab) — attach a
    // table.column mapping to an attribute that already exists (commonly a 'custom' one
    // auto-created from a CSV import), turning it into a 'system' attribute in place,
    // instead of creating a brand-new duplicate attribute for the same data.
    $mappedDb = trim((string)jin('mapped_db', ''));
    $mappedTable = trim((string)jin('mapped_table', ''));
    $mappedColumn = trim((string)jin('mapped_column', ''));
    if ($mappedDb !== '' && $mappedTable !== '' && $mappedColumn !== '') {
        if ($row['category'] === 'system') api_error('This attribute is already mapped — mappings cannot be changed once set');
        if ($row['category'] === 'linked' || $resolverJson !== '') api_error('This attribute uses a multi-step lookup — edit its steps instead of mapping it to a single column');
        if (!in_array($mappedDb, ATTRIBUTES_SEARCHABLE_DBS, true)) api_error('Invalid database');
        $dbE = $conn->real_escape_string($mappedDb);
        $tableE = $conn->real_escape_string($mappedTable);
        $colE = $conn->real_escape_string($mappedColumn);
        $chk = $conn->query("SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS
                              WHERE TABLE_SCHEMA='$dbE' AND TABLE_NAME='$tableE' AND COLUMN_NAME='$colE'");
        if (!$chk || $chk->num_rows === 0) api_error('That table/column no longer exists');
        $joinCol = detect_join_column($mappedDb, $mappedTable);
        if (!$joinCol) api_error('That table has no user_id or email column to match it back to a recipient');

        $set[] = "category='system'";
        $set[] = "mapped_db='$dbE'";
        $set[] = "mapped_table='$tableE'";
        $set[] = "mapped_column='$colE'";
        $set[] = "mapped_join_col='" . $conn->real_escape_string($joinCol) . "'";
    }

    if ($set) $conn->query("UPDATE campaign_attributes SET " . implode(', ', $set) . " WHERE id=$id");

    /*
     * A CHANGED VALUE HAS TO REACH THE TEMPLATES THAT BAKED IT IN.
     *
     * A WhatsApp Call button cannot hold a variable — Meta approves the button once and dials the
     * stored number for everyone — so the panel resolves the attribute when the template is
     * submitted and Meta keeps a literal number from then on. Editing the attribute here changes
     * nothing at Meta: the approved template carries on dialling the number it was approved with.
     * That is how a template went on ringing +917507869003 long after the attribute said
     * +918087129679, with every screen in this panel showing the new one.
     *
     * So the templates that reference this attribute are resubmitted, which for an already-approved
     * template is an edit — Meta accepts it and reviews the change. Doing it here rather than
     * leaving a note for somebody is the whole point: a number nobody remembered to republish is
     * exactly the kind of thing that stays wrong for weeks.
     *
     * Wrapped, because this is a courtesy the attribute save performs on its way past. A Meta
     * outage must not stop somebody editing an attribute.
     */
    $resubmitted = [];
    if ($defaultValue !== null && trim((string)$defaultValue) !== trim((string)$row['default_value'])) {
        try {
            require_once __DIR__ . '/../whatsapp/lib/WaTemplateSubmit.php';
            $token = '[' . $row['name'] . ']';
            /* _ and % mean something to LIKE, and an attribute name almost always contains an
               underscore — [SUPPORT_NUMBER] would otherwise match [SUPPORTXNUMBER] as well and
               resubmit a template that has nothing to do with this attribute. */
            $escaped = str_replace(['\\', '_', '%'], ['\\\\', '\\_', '\\%'], $token);
            $like  = '%' . $conn->real_escape_string($escaped) . '%';
            /* Only live templates, and only ones Meta already holds — a draft that has never been
               submitted will pick the new value up on its first submission anyway. */
            $tq = $conn->query("SELECT DISTINCT t.id, t.name
                                  FROM wa_templates t
                                  JOIN wa_template_wabas w ON w.template_id = t.id
                                 WHERE t.status = 'active'
                                   AND t.buttons LIKE '$like' ESCAPE '\\\\'
                                   AND w.meta_template_id IS NOT NULL AND w.meta_template_id <> ''");
            $targets = [];
            while ($tq && $trow = $tq->fetch_assoc()) $targets[] = $trow;

            foreach ($targets as $trow) {
                $tid = (int)$trow['id'];
                $res = wa_submit_template($tid);
                $err = !empty($res['ok']) ? null : (string)($res['error'] ?? 'Meta refused it');

                /* Meta allows one edit of an approved template per 24 hours. A change it cannot take
                   yet is parked and retried by the worker the moment it can — see the queue in
                   lib/WaTemplateSubmit.php — so the template does end up with the new value. */
                $retryAt = null;
                if ($err !== null && wa_resubmit_is_edit_window($err)) {
                    $retryAt = wa_resubmit_next_allowed($tid);
                    wa_resubmit_enqueue($tid, $retryAt, 'attribute ' . $row['name'] . ' changed');
                }

                $resubmitted[] = [
                    'id'       => $tid,
                    'name'     => (string)$trow['name'],
                    'ok'       => !empty($res['ok']),
                    'error'    => $err,
                    'retry_at' => $retryAt,
                ];
            }
        } catch (Throwable $e) {
            $resubmitted[] = ['id' => 0, 'name' => '', 'ok' => false,
                              'error' => 'Could not resubmit templates: ' . $e->getMessage()];
        }
    }
    attribute_log($id, $row['name'], 'Attribute edited', (string)($jwt['user_id'] ?? ''));
    api_success(["resubmitted" => $resubmitted]);
}

if ($action === 'delete') {
    $id = (int)jin('id', 0);
    if (!$id) api_error('id required');
    $r = $conn->query("SELECT name FROM campaign_attributes WHERE id=$id LIMIT 1");
    $row = $r ? $r->fetch_assoc() : null;
    if (!$row) api_error('Not found', 404);

    $conn->query("DELETE FROM campaign_attributes WHERE id=$id"); // FK cascade clears campaign_attribute_values
    attribute_log(null, $row['name'], 'Attribute deleted', (string)($jwt['user_id'] ?? ''));
    api_success([]);
}

if ($action === 'logs') {
    $page    = max(1, (int)jin('page', 1));
    $perPage = max(1, min(100, (int)jin('per_page', 25)));
    $offset  = ($page - 1) * $perPage;

    $tr = $conn->query("SELECT COUNT(*) AS c FROM campaign_attribute_logs");
    $total = $tr ? (int)$tr->fetch_assoc()['c'] : 0;

    $r = $conn->query("SELECT id, attribute_id, attribute_name, action, username, status, created_at
                        FROM campaign_attribute_logs
                        ORDER BY id DESC LIMIT $perPage OFFSET $offset");
    $rows = [];
    while ($r && $row = $r->fetch_assoc()) $rows[] = $row;

    api_success([
        'logs' => $rows, 'total' => $total, 'page' => $page, 'per_page' => $perPage,
        'pages' => $total > 0 ? (int)ceil($total / $perPage) : 1,
    ]);
}

api_error('Invalid action');

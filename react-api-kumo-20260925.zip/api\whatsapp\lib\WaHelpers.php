<?php
/*
 * Small shared helpers for the WhatsApp channel.
 *
 * These used to live inside WhatsAppTransport.php (the Netcore transport). That file is gone —
 * everything now goes through Meta's Cloud API directly — so the pieces that were never
 * provider-specific moved here rather than being deleted along with it.
 */
require_once __DIR__ . '/config.php';

/** Performs one already-built request. The single-shot path (test sends) and the fallback when
 *  there is only one job in a batch, so both share identical cURL options. */
function wa_http_exec(array $req, int $timeout = 20): array {
    $ch = curl_init($req['url']);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST           => true,
        CURLOPT_POSTFIELDS     => $req['body'],
        CURLOPT_HTTPHEADER     => $req['headers'],
        CURLOPT_TIMEOUT        => $timeout,
    ]);
    $body    = curl_exec($ch);
    $status  = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $curlErr = curl_error($ch);
    curl_close($ch);
    return [$status, $body === false ? null : $body, $curlErr];
}

/** How many {{n}} placeholders a template string declares. Reads the HIGHEST index rather than
 *  counting matches, so a body repeating {{1}} twice still declares one variable. */
function wa_placeholder_count(string $text): int {
    if ($text === '') return 0;
    preg_match_all('/\{\{\s*(\d+)\s*\}\}/', $text, $m);
    if (!$m[1]) return 0;
    return max(array_map('intval', $m[1]));
}

/** Substitutes {{1}}, {{2}} … with the given ordered values — used for previews and for the
 *  human-readable copy of the message stored on each recipient row. */
function wa_fill_placeholders(string $text, array $values): string {
    return preg_replace_callback('/\{\{\s*(\d+)\s*\}\}/', function ($m) use ($values) {
        return (string)($values[((int)$m[1]) - 1] ?? '');
    }, $text);
}

/**
 * One Meta Graph API call, returning a uniform result rather than throwing.
 *
 * Meta's error bodies are genuinely descriptive (expired token, missing scope, wrong WABA,
 * business not verified), so `error` carries the message verbatim instead of a status code.
 *
 * @return array{ok: bool, error: ?string, code: ?string, data: ?array}
 */
function wa_graph_call(string $method, string $url, string $token, ?array $payload = null, int $timeout = 25): array {
    $ch = curl_init($url);
    $opts = [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HTTPHEADER     => ['Content-Type: application/json', 'Authorization: Bearer ' . $token],
        CURLOPT_TIMEOUT        => $timeout,
    ];
    if ($method !== 'GET') {
        $opts[CURLOPT_CUSTOMREQUEST] = $method;
        if ($payload !== null) $opts[CURLOPT_POSTFIELDS] = json_encode($payload);
    }
    curl_setopt_array($ch, $opts);
    $body   = curl_exec($ch);
    $status = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $err    = curl_error($ch);
    curl_close($ch);

    if ($err !== '') return ['ok' => false, 'error' => "Could not reach Meta: $err", 'code' => 'network', 'data' => null];

    $decoded = json_decode((string)$body, true);
    if ($status < 200 || $status >= 300 || !is_array($decoded)) {
        $e = $decoded['error'] ?? [];
        $msg = $e['error_user_msg'] ?? ($e['message'] ?? (is_string($body) ? mb_substr($body, 0, 300) : "HTTP $status"));
        $code = (string)($e['code'] ?? $status);
        if (!empty($e['error_data']['details'])) $msg .= ' — ' . $e['error_data']['details'];
        return ['ok' => false, 'error' => $msg, 'code' => $code, 'data' => $decoded];
    }
    return ['ok' => true, 'error' => null, 'code' => null, 'data' => $decoded];
}

/** The account's Meta System User token, or '' when none is configured. */
function wa_meta_token(): string {
    $s = wa_settings_row() ?: [];
    return trim((string)($s['meta_access_token'] ?? ''));
}

/**
 * Is this button entry a DYNAMIC url button — one Meta will demand a parameter for?
 *
 * Every caller used to decide this with
 *
 *     ($btn['type'] ?? '') === 'url' && !empty($btn['dynamic'])
 *
 * which trusts two keys that are not always written. Campaign 53's stored button was
 *
 *     [{"url": "https://nctrckg.com/{{1}}", "text": "Result"}]
 *
 * — unmistakably a dynamic url button, carrying neither key. So every check said "not dynamic",
 * the button parameter was never built, and Meta rejected all 2,946 remaining sends with
 *
 *     131008  buttons: Button at index 0 of type Url requires a parameter
 *
 * The url itself is the one field that cannot be missing or wrong: a "{{1}}" placeholder in it
 * IS what makes a button dynamic, whatever the sibling flags happen to say. So the flags are
 * kept as a fast path for rows that do carry them, and the url is the fallback that makes the
 * answer right for rows that do not.
 *
 * Note this can only ever turn a "no" into a "yes" — a button with no placeholder and no flags
 * is still correctly treated as static, so a quick-reply or a fixed link is unaffected.
 */
function wa_is_dynamic_url_button($btn): bool {
    if (!is_array($btn)) return false;
    if (($btn['type'] ?? '') === 'url' && !empty($btn['dynamic'])) return true;
    $url = (string)($btn['url'] ?? '');
    return $url !== '' && preg_match('~\{\{\s*\d+\s*\}\}~', $url) === 1;
}

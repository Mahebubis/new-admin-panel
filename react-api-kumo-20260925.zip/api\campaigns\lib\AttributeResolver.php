<?php
/*
 * Resolves Customer Attribute values (public/react-api/api/attributes/) for a
 * batch of recipients at send time — either a live lookup against the
 * attribute's mapped table.column (category='system'), a multi-step lookup
 * chain across several tables (category='linked' — see
 * resolve_chain_for_emails()), or a lookup against campaign_attribute_data's
 * own column for that attribute (category='custom', usually populated by a CSV
 * import — see lists/lib/ContactImportWorker.php).
 * Batched per tick (one query per attribute — or per chain STEP — for the WHOLE
 * tick's recipients), not per-recipient, since SendWorker.php already processes
 * recipients in small chunks (50/tick).
 */
require_once __DIR__ . '/../../attributes/lib/schema.php';

/** Logs to worker.log when available (real sends, via SendWorker.php's campaign_log()),
 *  else falls back to the PHP error log (test sends from campaigns.php/templates.php,
 *  which don't load SendWorker.php) — so this is traceable either way. */
function attr_resolve_log(string $msg): void {
    if (function_exists('campaign_log')) { campaign_log('[attributes] ' . $msg); return; }
    error_log('[attributes] ' . $msg);
}

/**
 * Turns one raw looked-up value into what the template actually receives: the attribute's
 * default when nothing was found, and the chosen date format applied when there was.
 *
 * The default is deliberately NOT run through the date formatter — an admin who types
 * "Not available yet" as the fallback for a date attribute wants exactly that text.
 */
function attr_finalize_value(array $attr, $value) {
    if ($value === null || $value === '') return $attr['default_value'] ?? '';
    if (($attr['data_type'] ?? '') === 'date' && !empty($attr['date_format'])) {
        return attr_format_date($value, $attr['date_format']);
    }
    return $value;
}

/** Strips backticks so a stored identifier can never break out of its `quoting`. Every
 *  name reaching here was already checked against INFORMATION_SCHEMA when the attribute was
 *  saved (attr_chain_normalize()); this is the belt to that braces. */
function attr_ident(string $name): string {
    return str_replace('`', '', $name);
}

/**
 * Runs ONE step of a lookup chain for a whole batch at once.
 *
 * @param array $step      {db, table, match_col, out_col, order_by, order_dir}
 * @param array $inByEmail email => the value produced by the previous step (or the seed)
 * @return array           email => this step's output value, for the emails that matched
 */
function attr_chain_step(array $step, array $inByEmail): array {
    global $conn;

    $values = [];
    foreach ($inByEmail as $v) {
        if ($v === null || $v === '') continue;
        $values[(string)$v] = true;
    }
    if (!$values) return [];

    $db = attr_ident($step['db']); $table = attr_ident($step['table']);
    $matchCol = attr_ident($step['match_col']); $outCol = attr_ident($step['out_col']);

    // (string) because array_keys() turns a numeric-looking key like a user_id back into an int.
    $list = implode(',', array_map(fn($v) => "'" . $conn->real_escape_string((string)$v) . "'", array_keys($values)));
    $order = '';
    if (!empty($step['order_by'])) {
        /*
         * One input can match many rows (a user has one cit_results row per attempt), and the
         * map below keeps whichever row is read LAST. So the SQL sorts the opposite way to the
         * direction asked for: 'desc' (give me the newest) reads ascending and lets the newest
         * row overwrite everything before it. That keeps this a single batched query instead of
         * a per-recipient "latest row" subquery.
         */
        $dir = (strtolower($step['order_dir'] ?? 'desc') === 'desc') ? 'ASC' : 'DESC';
        $order = " ORDER BY `" . attr_ident($step['order_by']) . "` $dir";
    }

    $sql = "SELECT `$matchCol` AS k, `$outCol` AS v FROM `$db`.`$table` WHERE `$matchCol` IN ($list)$order";
    $r = $conn->query($sql);
    if (!$r) { attr_resolve_log("chain step FAILED — $sql — " . $conn->error); return []; }

    $byKey = [];
    while ($row = $r->fetch_assoc()) $byKey[(string)$row['k']] = $row['v'];
    attr_resolve_log("chain step sql=[$sql] rows found=" . count($byKey));

    $out = [];
    foreach ($inByEmail as $email => $v) {
        if ($v === null || $v === '') continue;
        $k = (string)$v;
        if (array_key_exists($k, $byKey) && $byKey[$k] !== null && $byKey[$k] !== '') $out[$email] = $byKey[$k];
    }
    return $out;
}

/**
 * Resolves a category='linked' attribute for a batch of recipients.
 *
 * Every path in the chain starts from the same seed (the recipient's user_id or email) and
 * walks its steps, each step matching on what the one before it returned. Paths are tried
 * in order and a recipient drops out as soon as one produces a value — which is exactly how
 * COMMUNITY_LINK is expressed: path 1 goes through assigned_links →
 * whatsapp_placement_club_link, path 2 through assigned_links_for_refund →
 * whatsapp_placement_club_link_for_refund, and a user is in one or the other, never both.
 *
 * @return array email(lowercase) => resolved value, only for the emails that resolved
 */
function resolve_chain_for_emails(array $attr, array $emails, array $userIdByEmail): array {
    global $conn;

    $chain = json_decode((string)($attr['resolver_json'] ?? ''), true);
    if (!is_array($chain) || empty($chain['branches'])) {
        attr_resolve_log("attribute {$attr['name']} (linked): SKIPPED — resolver_json is empty or unreadable");
        return [];
    }
    $seed = $chain['seed'] ?? 'user_id';

    // What feeds the first step of every path.
    $seedByEmail = [];
    if ($seed === 'email') {
        foreach ($emails as $e) $seedByEmail[$e] = $e;
    } else {
        foreach ($emails as $e) if (!empty($userIdByEmail[$e])) $seedByEmail[$e] = $userIdByEmail[$e];
        // A recipient can reach a send without a user_id on its row (a CSV-imported contact
        // carries only an email), so the missing ones are looked up by email here — the
        // "first get the user_id from the users table" step, done once for the whole batch
        // rather than being repeated as step 1 of every path.
        $missing = array_values(array_diff($emails, array_keys($seedByEmail)));
        if ($missing) {
            $list = implode(',', array_map(fn($e) => "'" . $conn->real_escape_string($e) . "'", $missing));
            $sql = "SELECT email, user_id FROM `" . ATTRIBUTES_USERS_DB . "`.`" . ATTRIBUTES_USERS_TABLE . "` WHERE email IN ($list)";
            $r = $conn->query($sql);
            if (!$r) attr_resolve_log("chain seed lookup FAILED — $sql — " . $conn->error);
            while ($r && $row = $r->fetch_assoc()) $seedByEmail[strtolower($row['email'])] = $row['user_id'];
        }
    }
    attr_resolve_log("attribute {$attr['name']} (linked): seed=$seed resolved for " . count($seedByEmail) . '/' . count($emails) . ' recipients');

    $out = [];
    $pending = $seedByEmail; // emails still without a value, with their seed value
    foreach ($chain['branches'] as $bi => $branch) {
        if (!$pending) break;
        if (!is_array($branch['steps'] ?? null)) continue;
        $cur = $pending;
        foreach ($branch['steps'] as $step) {
            $cur = attr_chain_step($step, $cur);
            if (!$cur) break;
        }
        foreach ($cur as $email => $value) {
            $out[$email] = $value;
            unset($pending[$email]);
        }
        attr_resolve_log("attribute {$attr['name']} (linked): path " . ($bi + 1) . ' resolved ' . count($cur) . ' recipient(s), ' . count($pending) . ' still unresolved');
    }
    return $out;
}

function load_all_attributes(): array {
    global $conn;
    $r = $conn->query("SELECT * FROM campaign_attributes");
    $rows = [];
    while ($r && $row = $r->fetch_assoc()) $rows[] = $row;
    return $rows;
}

/**
 * @param array $attributes    rows from load_all_attributes()
 * @param array $recipientRows rows from email_campaign_recipients (must have 'email', 'user_id')
 * @return array email(lowercase) => ['[NAME]' => value, ...] — ready to merge straight
 *               into substitute_merge_tags()'s $extraTokens argument.
 */
function resolve_attribute_values_batch(array $attributes, array $recipientRows): array {
    global $conn;
    if (!$attributes || !$recipientRows) return [];

    $emails = array_values(array_unique(array_map(fn($r) => strtolower($r['email']), $recipientRows)));
    $userIds = array_values(array_unique(array_filter(array_map(fn($r) => (int)($r['user_id'] ?? 0), $recipientRows))));
    // email(lowercase) -> user_id, so a 'user_id'-joined attribute can still be resolved
    // per-email even though the lookup itself runs against user_id.
    $userIdByEmail = [];
    foreach ($recipientRows as $r) {
        if (!empty($r['user_id'])) $userIdByEmail[strtolower($r['email'])] = (int)$r['user_id'];
    }

    $out = []; // email -> [token => value]
    attr_resolve_log('batch start — recipients=' . json_encode(array_map(fn($r) => ['email' => $r['email'] ?? null, 'user_id' => $r['user_id'] ?? null], $recipientRows))
        . ', resolved emails=' . json_encode($emails) . ', resolved user_ids=' . json_encode($userIds));

    foreach ($attributes as $attr) {
        // Attributes use [NAME] bracket tokens — deliberately different from the fixed
        // identity/exam XX_..._XX tags (MergeTags.php), per explicit request.
        $token = '[' . $attr['name'] . ']';

        if ($attr['category'] === 'linked') {
            $found = resolve_chain_for_emails($attr, $emails, $userIdByEmail);
            foreach ($emails as $e) $out[$e][$token] = attr_finalize_value($attr, $found[$e] ?? null);
            continue;
        }

        if ($attr['category'] === 'custom') {
            if (!$emails) continue;
            // No LOWER()/COLLATE wrapping on the `email` column here — these VARCHAR columns
            // already use a case-insensitive (_ci) collation, so a plain `email IN (...)`
            // already matches regardless of case AND keeps the index usable (wrapping the
            // column in a function defeats it — the exact mistake that caused a 9s page load
            // earlier this session).
            $col = attribute_column_name($attr['name']);
            $emailList = implode(',', array_map(fn($e) => "'" . $conn->real_escape_string($e) . "'", $emails));
            $sql = "SELECT email, `$col` AS val FROM campaign_attribute_data WHERE email IN ($emailList)";
            $r = $conn->query($sql);
            if (!$r) { attr_resolve_log("attribute {$attr['name']} (custom): QUERY FAILED — $sql — " . $conn->error); continue; }
            $byEmail = [];
            while ($row = $r->fetch_assoc()) $byEmail[strtolower($row['email'])] = $row['val'];
            attr_resolve_log("attribute {$attr['name']} (custom): sql=[$sql] rows found=" . count($byEmail));
            foreach ($emails as $e) {
                $out[$e][$token] = attr_finalize_value($attr, $byEmail[$e] ?? null);
            }
            continue;
        }

        // Mapped ('system') attribute — live lookup against its source table.
        $db = $attr['mapped_db']; $table = $attr['mapped_table']; $col = $attr['mapped_column']; $joinCol = $attr['mapped_join_col'];
        if (!$db || !$table || !$col || !$joinCol) {
            attr_resolve_log("attribute {$attr['name']} (id={$attr['id']}): SKIPPED — missing mapped_db/table/column/join_col (db=" . var_export($db, true) . ", table=" . var_export($table, true) . ", col=" . var_export($col, true) . ", joinCol=" . var_export($joinCol, true) . ")");
            continue;
        }
        $qualified = "`$db`.`$table`";

        if ($joinCol === 'user_id') {
            if (!$userIds) {
                attr_resolve_log("attribute {$attr['name']}: no user_id available on any recipient in this batch — falling back to default_value for all");
                foreach ($emails as $e) $out[$e][$token] = attr_finalize_value($attr, null);
                continue;
            }
            $idList = implode(',', array_map('intval', $userIds));
            $sql = "SELECT user_id, `$col` AS val FROM $qualified WHERE user_id IN ($idList)";
            $r = $conn->query($sql);
            if (!$r) { attr_resolve_log("attribute {$attr['name']}: QUERY FAILED — $sql — " . $conn->error); continue; }
            $byUserId = [];
            while ($row = $r->fetch_assoc()) $byUserId[(int)$row['user_id']] = $row['val'];
            attr_resolve_log("attribute {$attr['name']}: sql=[$sql] rows found=" . count($byUserId) . ' -> ' . json_encode($byUserId));
            foreach ($emails as $e) {
                $uid = $userIdByEmail[$e] ?? null;
                $out[$e][$token] = attr_finalize_value($attr, $uid !== null ? ($byUserId[$uid] ?? null) : null);
            }
        } else { // joinCol === 'email'
            $emailList = implode(',', array_map(fn($e) => "'" . $conn->real_escape_string($e) . "'", $emails));
            $sql = "SELECT email, `$col` AS val FROM $qualified WHERE email IN ($emailList)";
            $r = $conn->query($sql);
            if (!$r) { attr_resolve_log("attribute {$attr['name']}: QUERY FAILED — $sql — " . $conn->error); continue; }
            $byEmail = [];
            while ($row = $r->fetch_assoc()) $byEmail[strtolower($row['email'])] = $row['val'];
            attr_resolve_log("attribute {$attr['name']}: sql=[$sql] rows found=" . count($byEmail) . ' -> ' . json_encode($byEmail));
            foreach ($emails as $e) {
                $out[$e][$token] = attr_finalize_value($attr, $byEmail[$e] ?? null);
            }
        }
    }

    attr_resolve_log('batch result -> ' . json_encode($out));
    return $out;
}

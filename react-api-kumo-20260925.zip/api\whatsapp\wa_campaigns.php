<?php
/*
 * /api/whatsapp/wa_campaigns.php — WhatsApp campaign builder backend.
 *
 * action=list            &page &per_page &status &search   → paginated list + per-status tab counts
 * action=get              &id                              → full campaign row
 * action=save      [&id]  &name &... (see $fields)          → create/update (autosave from the wizard)
 * action=delete           &id
 * action=duplicate        &id
 * action=tags                                               → distinct tags across all WhatsApp campaigns
 * action=audience_count   &audience_type &segment_ids &list_ids &exclude_segment_ids &exclude_list_ids
 * action=audience_export  (same audience params) [&name]      → the resolved audience as a CSV
 *                         &dedup_enabled &dedup_window_hours &dedup_scope [&template_name] [&id]
 *                                                           → reachable / unreachable / duplicates / dedup preview
 * action=preflight        &id                               → the pre-send checklist (blocking + warnings)
 * action=send_test        &id &phones (comma/newline separated)
 * action=send_now         &id
 * action=schedule         &id &scheduled_at
 * action=pause  | resume | requeue   &id
 * action=report           &id                               → stats + recent events
 * action=recipients       &id &page &per_page &status &search
 */
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../middleware/auth.php';
require_once __DIR__ . '/lib/config.php';
require_once __DIR__ . '/lib/schema.php';
require_once __DIR__ . '/lib/WaSendWorker.php';   // pulls in the transport, resolver and merge tags
require_once __DIR__ . '/../attributes/lib/schema.php';
require_once __DIR__ . '/lib/WaTemplateWabas.php';  // per-WABA approval, read by wa_validate_for_send()

whatsapp_ensure_schema();
wa_template_wabas_ensure_schema();
attributes_ensure_schema();

$jwt = require_jwt();
require_permission('netcore_behaviour', $jwt);

function jin($k, $d = null) { $v = $_REQUEST[$k] ?? null; return ($v === null || $v === '') ? $d : $v; }

/** Audience config in the shape the resolver expects, read off a stored campaign row. */
function wa_campaign_audience_config(array $c): array {
    return [
        'audience_type'       => $c['audience_type'],
        'segment_ids'         => json_decode($c['segment_ids'] ?? '[]', true) ?: [],
        'exclude_segment_ids' => json_decode($c['exclude_segment_ids'] ?? '[]', true) ?: [],
        'exclude_list_ids'    => json_decode($c['exclude_list_ids'] ?? '[]', true) ?: [],
        'list_ids'            => json_decode($c['list_ids'] ?? '[]', true) ?: [],
        'domain_filter'       => '',
    ];
}

/**
 * Will a tap on this campaign's link be able to say WHO tapped it?
 *
 * ── The distinction this answers ─────────────────────────────────────────────
 * A WhatsApp template's approved BUTTON url is byte-identical in every copy of the message —
 * Meta will not approve a button whose URL carries a variable, so it is frozen as
 * …/login/<link id>. Every recipient taps the same string. The landing page therefore sees a
 * stranger, and the click is recorded against a visitor key rather than a person. That is not a
 * fault in the tracking; it is the only thing a static link can possibly report.
 *
 * A per-recipient link is the alternative, and it has to live somewhere Meta does not freeze:
 *
 *   a BODY or HEADER variable   free text, so the whole attribution query string can go in it.
 *                               Works on any approved template, needs no re-review.
 *   a DYNAMIC button suffix     only for a template approved with {{1}} in its button URL.
 *
 * Either one expands to …?campaign_id=…&phone=919…&wa_rid=<this message's id>, and phone + rid
 * are the identity — read with no session at all.
 *
 * Knowing which of the two a campaign used is what lets the report say "this campaign cannot
 * identify clicks" instead of the far more misleading "this person was probably forwarded the
 * message", and what lets the preflight warn BEFORE the send rather than after.
 */
function wa_campaign_click_is_identifiable(array $campaign): bool {
    $vars = $campaign['variables'] ?? '{}';
    if (is_string($vars)) $vars = json_decode($vars, true) ?: [];
    if (!is_array($vars)) return false;

    $carries = static function ($v): bool {
        return is_string($v) && strpos($v, 'XX_WA_ATTR_XX') !== false;
    };

    foreach (['body', 'header'] as $part) {
        foreach ((array)($vars[$part] ?? []) as $v) if ($carries($v)) return true;
    }
    if ($carries((string)($vars['button_url_suffix'] ?? ''))) return true;

    /*
     * The auto-filled button. wa_render_for_recipient() defaults a DYNAMIC url button's value to
     * XX_WA_ATTR_XX when the campaign has a goal and nothing was typed — so a campaign can be
     * identifiable without the token appearing anywhere in its saved variables. Missing this
     * would tell somebody their tracking is broken when it is working.
     */
    $autoOk = !array_key_exists('auto_button_attr', $campaign) || !empty($campaign['auto_button_attr']);
    if ($autoOk && trim((string)($campaign['goal_event_name'] ?? '')) !== '') {
        $btns = $campaign['buttons'] ?? [];
        if (is_string($btns)) $btns = json_decode($btns, true) ?: [];
        foreach ((array)$btns as $b) {
            if (($b['type'] ?? '') === 'url' && !empty($b['dynamic'])) return true;
        }
    }

    return false;
}

/**
 * Everything that must be true before a real send, separated into blocking problems and
 * warnings.
 *
 * The checks worth having are the silent ones. Meta accepts a message and then drops it when
 * the template name isn't one it approved, or when a free-text message goes to someone outside
 * the 24-hour service window. Catching those here is the difference between a visible error and
 * a campaign that reports 4,000 sent with nobody receiving anything.
 */
function wa_validate_for_send(array $campaign): array {
    $blocking = [];
    $warnings = [];

    // Which number this goes out from, and whether that number can actually send. Checked here
    // rather than in the browser because it's server state the wizard can't see.
    $sender = wa_sender_for_campaign($campaign);
    if (!$sender) {
        $blocking[] = 'No sending number selected';
    } else {
        // Credentials differ by route, so checking for Meta's on a Netcore campaign would block a
        // send that is perfectly configured — and say nothing about the key it actually needs.
        $provider = wa_resolve_provider($sender, $campaign['send_provider'] ?? null);
        if ($provider === 'netcore') {
            if (trim((string)$sender['api_key']) === '') {
                $blocking[] = 'No Netcore API key on the selected sending number';
            }
            /*
             * ── Netcore cannot deliver a dynamic URL button ─────────────────────────────────
             *
             * A template whose button URL ends in {{1}} needs a per-message parameter. Netcore
             * accepts the send, returns success, and then Meta rejects every message with
             * "131008: buttons: Button at index 0 of type Url requires a parameter" — the value
             * we sent never reaches Meta. Both payload shapes Netcore documents were tried: the
             * object form [{type,index,parameter}] and the flat positional list. Neither arrives.
             *
             * This is not a guess. Across this account's own history:
             *
             *   netcore + dynamic button   3,548 sent → 644 delivered, 2,905 failed
             *   netcore + static button      491 sent → 465 delivered,    19 failed
             *   meta    + dynamic button       2 sent →   2 delivered,     0 failed
             *
             * Campaign #53 is the 3,548 — a whole send lost to a combination the panel happily
             * accepted. Blocking it here is the difference between finding out now and finding
             * out from the failure column afterwards.
             *
             * The wording deliberately does NOT say "switch to Meta" on its own. Meta's route does
             * handle these correctly, but this account's Meta token currently has no WhatsApp
             * Business Account assigned to it, so every Meta send comes back "(#200) You do not
             * have the necessary permissions". Advising a route that is also broken would just
             * move the dead end. Both real options are named instead.
             */
            $btns = json_decode((string)($campaign['buttons'] ?? '[]'), true) ?: [];
            foreach ((array)$btns as $b) {
                if (strpos((string)($b['url'] ?? ''), '{{') !== false) {
                    $blocking[] = 'This template has a dynamic link button. Netcore accepts the send and then Meta '
                                . 'rejects every message with 131008, because the button value never reaches Meta — '
                                . 'that is what lost campaign #53 (2,905 of 3,548 failed). Either use a template whose '
                                . 'button link is fixed, or fix the Meta token (Settings, WhatsApp, Run diagnostics) '
                                . 'and send this campaign through the Meta Cloud API route instead.';
                    break;
                }
            }
            if (trim((string)$sender['source_id']) === '') {
                $warnings[] = 'No Source ID set for this number. Netcore only sends delivery receipts for messages whose source matches the Source key on its webhook, so Delivered / Read will stay at 0 without it.';
            }
        } else {
            if (trim((string)$sender['phone_number_id']) === '') $blocking[] = 'No phone number ID for the selected sending number';
            if (wa_meta_token() === '') $blocking[] = 'Meta access token is not configured';
        }
        if ((int)$sender['is_active'] !== 1) $blocking[] = 'The selected sending number is switched off';
    }

    if ($campaign['message_type'] === 'template') {
        if (trim((string)$campaign['template_name']) === '') {
            $blocking[] = 'No template selected';
        } else {
            /*
             * ── Is this template still approved, on the account this campaign will send FROM? ──
             *
             * The campaign snapshots the template's copy at build time, deliberately — an edit to
             * the library must not change what an already-scheduled campaign sends. But approval
             * is not copy: it is a live fact about the template on a specific WhatsApp Business
             * Account, and it can change between building the campaign and sending it.
             *
             * Two things are checked, and both are silent failures otherwise:
             *   the WABA         a template approved on one business account is not approved on
             *                    another. Sending from a number under a different WABA is
             *                    accepted by the API and dropped by WhatsApp.
             *   the category     a template Meta has re-filed from UTILITY to MARKETING is billed
             *                    differently, needs marketing opt-in, and is dropped for anyone
             *                    over their marketing cap. The campaign would report thousands
             *                    sent and a fraction delivered.
             */
            $tplId = (int)($campaign['template_id'] ?? 0);
            if ($tplId > 0) {
                global $conn;
                $tr = $conn->query("SELECT * FROM wa_templates WHERE id = $tplId LIMIT 1");
                $tpl = $tr ? $tr->fetch_assoc() : null;

                if (!$tpl) {
                    $warnings[] = 'The template this campaign was built from has since been deleted. The snapshotted copy will still be sent, but its approval can no longer be checked.';
                } else {
                    if (!empty($tpl['auto_disabled'])) {
                        $blocking[] = 'Template "' . $tpl['name'] . '" has been disabled: '
                            . (string)($tpl['disabled_reason'] ?? 'Meta re-classified it.');
                    }
                    $wabaId = trim((string)($sender['waba_id'] ?? ''));
                    if ($wabaId !== '') {
                        $wr = $conn->query("SELECT approval_status, meta_category FROM wa_template_wabas
                                             WHERE template_id = $tplId
                                               AND waba_id = '" . $conn->real_escape_string($wabaId) . "' LIMIT 1");
                        $w = $wr ? $wr->fetch_assoc() : null;
                        $st = $w['approval_status'] ?? null;

                        if ($st === 'rejected') {
                            $blocking[] = 'Template "' . $tpl['name'] . '" is rejected on the business account this number belongs to.';
                        } elseif ($st === 'not_submitted' || $st === null) {
                            // A warning rather than blocking: a template synced before this panel
                            // tracked accounts genuinely has no row, and refusing to send would
                            // break every campaign built before the upgrade.
                            $warnings[] = 'Template "' . $tpl['name'] . '" has never been submitted to the business account this number belongs to. '
                                . 'If messages are accepted and never arrive, submit it from Content → WhatsApp templates.';
                        } elseif ($st === 'pending') {
                            $blocking[] = 'Template "' . $tpl['name'] . '" is still awaiting approval on the business account this number belongs to.';
                        }
                    }
                }
            }

            $vars = json_decode($campaign['variables'] ?? '{}', true) ?: [];
            $bodyNeeded = wa_placeholder_count((string)$campaign['body_text']);
            $bodyGiven  = array_filter((array)($vars['body'] ?? []), fn($v) => trim((string)$v) !== '');
            if (count($bodyGiven) < $bodyNeeded) {
                $blocking[] = 'Template variables are not all filled in';
            }
            if (($campaign['header_type'] ?? 'none') === 'text') {
                $headerNeeded = wa_placeholder_count((string)$campaign['header_text']);
                $headerGiven  = array_filter((array)($vars['header'] ?? []), fn($v) => trim((string)$v) !== '');
                if (count($headerGiven) < $headerNeeded) $blocking[] = 'Template variables are not all filled in';
            }
            // A URL button whose approved link contains {{1}} expects a value at send time.
            // Left empty, Meta rejects the send outright rather than dropping it silently — but
            // it is still worth flagging before the campaign is queued.
            $btns = json_decode($campaign['buttons'] ?? '[]', true) ?: [];
            foreach ($btns as $b) {
                if (($b['type'] ?? '') === 'url' && !empty($b['dynamic'])
                    && trim((string)($vars['button_url_suffix'] ?? '')) === '') {
                    $warnings[] = 'This template has a dynamic URL button ({{1}} in its link) but no suffix value. If messages are accepted and never arrive, that is the first thing to fill in.';
                    break;
                }
            }
            /*
             * A conversion goal on a template whose button URL is STATIC.
             *
             * This combination looks completely configured and reports zero forever. WhatsApp
             * tells nobody when a link button is tapped — the phone opens the URL directly and
             * our server is never contacted — so a static button produces no click, no
             * campaign_id on the landing page, no attribution cookie and therefore no
             * conversion. Nothing errors; the number is just always 0.
             *
             * Only a template approved with a DYNAMIC ({{1}}) button URL pointing at c.php can
             * be attributed, and a template's URL cannot be changed after approval.
             */
            if (trim((string)$campaign['goal_event_name']) !== '') {
                $urlButtons = array_filter($btns, fn($b) => ($b['type'] ?? '') === 'url');
                $trackable  = array_filter($urlButtons, fn($b) => !empty($b['dynamic']));
                if ($urlButtons && !$trackable) {
                    $warnings[] = 'This campaign has a conversion goal, but the template\'s link button uses a FIXED url ('
                        . (string)(reset($urlButtons)['url'] ?? '') . '). WhatsApp does not report taps on a fixed link, '
                        . 'so clicks and conversions will both stay at 0. To track them, submit a new template whose button url is '
                        . 'dynamic — ending in {{1}} and pointing at /api/whatsapp/c.php?t={{1}} — then set the button variable to XX_WA_CLICK_TOKEN_XX.';
                } elseif (!$urlButtons) {
                    $warnings[] = 'This campaign has a conversion goal but the template has no link button, so there is nothing for a recipient to click through. Conversions will stay at 0.';
                }
            }
            /*
             * ── Every click from this campaign will be ANONYMOUS ────────────────────────
             *
             * Separate from the goal warning above, and worth its own line, because it fires in a
             * case that otherwise looks completely healthy: the tracking works, the clicks are
             * counted, the report fills in — and every single row reads "Anonymous visitor",
             * which is the least useful thing a click report can say.
             *
             * The cause is always the same and is never visible from the wizard: the message
             * carries only the template's APPROVED button, whose URL is byte-identical in every
             * copy ever sent. There is nothing in that URL to say who tapped it, so the landing
             * page records a visitor key and no person. It is not a bug, it is the ceiling of a
             * static link — and it is fixable in ten seconds by putting the tracked link in a
             * body variable instead, which is exactly what this says.
             */
            if (!wa_campaign_click_is_identifiable($campaign)) {
                $hasLinkButton = (bool)array_filter($btns, fn($b) => ($b['type'] ?? '') === 'url');
                $warnings[] = 'Clicks from this campaign will be recorded as "Anonymous visitor" — nothing in it '
                    . 'identifies who tapped. '
                    . ($hasLinkButton
                        ? 'The template\'s button URL is fixed at approval and is identical in every message, so a tap cannot name anybody. '
                        : '')
                    . 'To get named clicks, set one of the BODY variables to the "Tracked link" entry in the '
                    . 'attribute picker on the Content step. Each recipient then gets their own link carrying '
                    . 'their phone number and this message\'s id, and a tap is credited to them even if they '
                    . 'never sign in. The template does not need re-approving — body variables are free text.';
            }


            /*
              A Call button that will dial a different number from the one its attribute holds.
              Campaigns 81 and 82 were sent straight into this with nothing on screen to say so.
              A warning rather than a block: the change is on its way and the send may be wanted
              anyway, but nobody should find out which number it dials from a recipient.
            */
            if (!empty($tpl) && !empty($sender['waba_id'])) {
                try {
                    require_once __DIR__ . '/lib/WaMetaComponents.php';
                    require_once __DIR__ . '/lib/WaTemplateSubmit.php';
                    $drift = wa_template_phone_drift($tpl, (string)$sender['waba_id']);
                    if ($drift) {
                        $when = $drift['retry_at']
                            ? 'Your change reaches Meta automatically at ' . date('d M, h:i a', strtotime($drift['retry_at']))
                              . ', and takes effect once Meta approves it.'
                            : 'Resubmit the template to Meta for the new number to take effect.';
                        $warnings[] = 'The Call button will dial ' . $drift['actual'] . ', not ' . $drift['expected']
                            . '. ' . $drift['token'] . ' has changed, but Meta still holds the number this template was approved with — '
                            . 'Meta allows one edit of an approved template every 24 hours. ' . $when;
                    }
                } catch (Throwable $e) { /* advisory only — never stops a send */ }
            }

            if (strtolower((string)$campaign['template_category']) === 'marketing') {
                $warnings[] = 'This is a MARKETING template — it needs opt-in, and WhatsApp caps how many marketing messages one person receives. A utility template has far fewer restrictions.';
            }
        }
    } else {
        if (trim((string)$campaign['text_content']) === '') $blocking[] = 'Message text is empty';
        // A free-text (non-template) message is only deliverable inside the 24-hour customer
        // service window — outside it WhatsApp drops it. Worth saying out loud, not blocking.
        $warnings[] = 'Free-text messages only reach contacts who messaged you in the last 24 hours. Use an approved template for everyone else.';
    }

    $audience = wa_resolve_audience_count(wa_campaign_audience_config($campaign));
    if ($audience['count'] === 0) $blocking[] = 'Audience has 0 reachable WhatsApp numbers';
    if ($audience['unreachable'] > 0) {
        $warnings[] = number_format($audience['unreachable']) . ' contact(s) in this audience have no usable phone number and will be skipped.';
    }
    if ($audience['duplicates'] > 0) {
        $warnings[] = number_format($audience['duplicates']) . ' duplicate number(s) were merged — each person receives exactly one message.';
    }

    return [
        'blocking' => array_values(array_unique($blocking)),
        'warnings' => $warnings,
        'audience' => $audience,
        'sender'   => $sender ? [
            'id' => (int)$sender['id'], 'business_number' => $sender['business_number'],
            'display_name' => $sender['display_name'], 'waba_id' => $sender['waba_id'],
        ] : null,
    ];
}

$action = jin('action', '');

if ($action === 'list') {
    $page    = max(1, (int)jin('page', 1));
    $perPage = max(1, min(100, (int)jin('per_page', 10)));
    $status  = jin('status', 'all');
    $search  = trim((string)jin('search', ''));
    $offset  = ($page - 1) * $perPage;

    $where = [];
    if ($status !== 'all' && $status !== '') $where[] = "status='" . $conn->real_escape_string($status) . "'";
    if ($search !== '') $where[] = "name LIKE '%" . $conn->real_escape_string($search) . "%'";
    $whereSql = $where ? 'WHERE ' . implode(' AND ', $where) : '';

    $tr = $conn->query("SELECT COUNT(*) AS c FROM wa_campaigns $whereSql");
    $total = $tr ? (int)$tr->fetch_assoc()['c'] : 0;

    /*
     * clicked_users below is PEOPLE who clicked, not TAPS.
     *
     * click_count counts every tap — five taps by one person is five — which is a real engagement
     * signal but makes a nonsense of a column sitting next to Sent: it can, and did, exceed it.
     * The list shows the distinct-people figure instead and keeps click_count as the separate
     * total-taps number behind it.
     *
     * GREATEST of two sources, because a campaign is measured by one mechanism or the other:
     *
     *   wa_link_clicks              the current static tracked link. Anonymous but deduplicated —
     *                               one row per browser per campaign, collapsed onto user_id for
     *                               anyone who later signed in.
     *   recipients.first_clicked_at the older per-recipient c.php links, where the tap identified
     *                               the person outright. Empty for static-link campaigns except
     *                               where somebody was identified, and those are already counted
     *                               in wa_link_clicks — which is exactly why GREATEST is exact
     *                               here rather than a fudge: the two never both under-report, and
     *                               adding them would double-count the identified overlap.
     *
     * Cheap despite the correlated subqueries: both are covered by indexes — idx_clicked is
     * (campaign_id, first_clicked_at), idx_campaign is on wa_link_clicks.campaign_id — and only
     * one page of campaigns is ever selected.
     *
     * Kept OUT of the SQL string on purpose — a prose comment inside a double-quoted PHP string
     * ends it at the first quotation mark, which is a parse error, not a bad query.
     */
    $r = $conn->query("SELECT id, name, tags, status, last_error, message_type, template_name, template_category,
                              business_number, sender_id, send_provider,
                              total_recipients, sent_count, delivered_count, read_count, failed_count,
                              click_count, reply_count, conversion_count, goal_event_name, skipped_dedup_count, dedup_enabled,
                              GREATEST(
                                (SELECT COUNT(DISTINCT lc.identity_key)
                                   FROM wa_link_clicks lc WHERE lc.campaign_id = wa_campaigns.id),
                                (SELECT COUNT(*) FROM wa_campaign_recipients cr
                                  WHERE cr.campaign_id = wa_campaigns.id
                                    AND cr.is_test = 0
                                    AND cr.first_clicked_at IS NOT NULL)
                              ) AS clicked_users,
                              schedule_type, scheduled_at, started_at, completed_at, created_at, updated_at
                         FROM wa_campaigns $whereSql
                        ORDER BY id DESC LIMIT $perPage OFFSET $offset");
    $rows = [];
    while ($r && $row = $r->fetch_assoc()) $rows[] = $row;

    $counts = ['all' => 0, 'draft' => 0, 'scheduled' => 0, 'running' => 0, 'sent' => 0, 'suspended' => 0, 'failed' => 0];
    $cr = $conn->query("SELECT status, COUNT(*) AS c FROM wa_campaigns GROUP BY status");
    while ($cr && $row = $cr->fetch_assoc()) { $counts[$row['status']] = (int)$row['c']; $counts['all'] += (int)$row['c']; }

    api_success([
        'campaigns' => $rows, 'total' => $total, 'page' => $page, 'per_page' => $perPage,
        'pages' => $total > 0 ? (int)ceil($total / $perPage) : 1, 'counts' => $counts,
    ]);
}

if ($action === 'get') {
    $id = (int)jin('id', 0);
    $r = $conn->query("SELECT * FROM wa_campaigns WHERE id=$id LIMIT 1");
    $row = $r ? $r->fetch_assoc() : null;
    if (!$row) api_error('Not found', 404);
    foreach (['segment_ids', 'exclude_segment_ids', 'exclude_list_ids', 'list_ids'] as $k) {
        $row[$k] = json_decode($row[$k] ?? '[]', true) ?: [];
    }
    $row['buttons']   = json_decode($row['buttons'] ?? '[]', true) ?: [];
    $row['variables'] = json_decode($row['variables'] ?? '{}', true) ?: [];
    api_success(['campaign' => $row]);
}

if ($action === 'save') {
    $id   = (int)jin('id', 0);
    $name = trim((string)jin('name', ''));
    if ($id === 0 && $name === '') api_error('Campaign name required');

    $fields = [
        'name' => 's', 'tags' => 's',
        'ga_source' => 's', 'ga_medium' => 's', 'ga_campaign' => 's', 'ga_content' => 's', 'ga_term' => 's',
        'audience_type' => 's', 'reachable_count' => 'i',
        'sender_id' => 'i', 'send_provider' => 's',
        'goal_event_name' => 's', 'goal_window_days' => 'i',
        'goal_attribution' => 's', 'click_target_url' => 's',
        'dedup_enabled' => 'i', 'dedup_window_hours' => 'i', 'dedup_scope' => 's',
        'message_type' => 's', 'template_language' => 's', 'template_category' => 's',
        'header_type' => 's', 'header_text' => 's', 'header_media_url' => 's',
        'footer_text' => 's', 'text_content' => 's', 'preview_url' => 'i',
        'schedule_type' => 's',
        'contact_limit_enabled' => 'i', 'contact_limit' => 'i', 'retry_enabled' => 'i',
    ];
    $set = [];
    foreach ($fields as $f => $type) {
        $v = jin($f, null);
        if ($v === null) continue;
        $set[] = $type === 'i' ? "$f=" . (int)$v : "$f='" . $conn->real_escape_string((string)$v) . "'";
    }
    foreach (['segment_ids', 'exclude_segment_ids', 'exclude_list_ids', 'list_ids'] as $f) {
        if (jin($f, null) === null) continue;
        $arr = json_decode(jin($f), true) ?: [];
        $set[] = "$f='" . $conn->real_escape_string(json_encode(array_values(array_map('intval', $arr)))) . "'";
    }
    // Per-variable values as chosen in the Content step. Stored as-is (they may contain merge
    // tags) and only resolved per recipient at send time.
    if (jin('variables', null) !== null) {
        $vars = json_decode(jin('variables'), true);
        if (!is_array($vars)) $vars = [];
        $set[] = "variables='" . $conn->real_escape_string(json_encode($vars)) . "'";
    }

    /*
     * Snapshot the chosen template's content onto the campaign — exactly like the email
     * builder snapshots content_html. A later edit to the template (or an archive) must not
     * retroactively change what an already-scheduled campaign will send.
     */
    $templateId = jin('template_id', null);
    if ($templateId !== null) {
        $tid = (int)$templateId;
        if ($tid > 0) {
            $tRes = $conn->query("SELECT * FROM wa_templates WHERE id=$tid LIMIT 1");
            $t = $tRes ? $tRes->fetch_assoc() : null;
            if ($t) {
                $set[] = 'template_id=' . $tid;
                $set[] = "template_name='"     . $conn->real_escape_string($t['name']) . "'";
                $set[] = "template_language='" . $conn->real_escape_string($t['language']) . "'";
                $set[] = "template_category='" . $conn->real_escape_string($t['category']) . "'";
                $set[] = "header_type='"       . $conn->real_escape_string($t['header_type']) . "'";
                $set[] = "header_text='"       . $conn->real_escape_string((string)$t['header_text']) . "'";
                $set[] = "header_media_url='"  . $conn->real_escape_string((string)$t['header_media_url']) . "'";
                $set[] = "body_text='"         . $conn->real_escape_string((string)$t['body_text']) . "'";
                $set[] = "footer_text='"       . $conn->real_escape_string((string)$t['footer_text']) . "'";
                $set[] = "buttons='"           . $conn->real_escape_string((string)($t['buttons'] ?: '[]')) . "'";
            }
        } else {
            // Explicit "no template" (switching to a free-text message).
            $set[] = 'template_id=NULL';
            $set[] = "template_name=''";
        }
    }

    if ($id > 0) {
        if ($set) $conn->query("UPDATE wa_campaigns SET " . implode(', ', $set) . " WHERE id=$id");
    } else {
        $set[] = 'created_by=' . (int)($jwt['user_id'] ?? 0);
        /* Stamped from PHP, not left to the column's DEFAULT CURRENT_TIMESTAMP: MySQL's clock is
           a different clock (see config/database.php). The unified campaigns list files a draft
           under created_at and a sent campaign under started_at/completed_at, both PHP-written —
           mixing the two put a brand-new draft hours in the past, where "Newest first" hid it. */
        $set[] = "created_at='" . $conn->real_escape_string(date('Y-m-d H:i:s')) . "'";
        $conn->query("INSERT INTO wa_campaigns SET " . implode(', ', $set));
        $id = $conn->insert_id;
    }

    $r = $conn->query("SELECT reachable_count, status FROM wa_campaigns WHERE id=$id LIMIT 1");
    $row = $r ? $r->fetch_assoc() : ['reachable_count' => 0, 'status' => 'draft'];
    api_success(['id' => $id, 'reachable_count' => (int)$row['reachable_count'], 'status' => $row['status']]);
}

if ($action === 'delete') {
    $id = (int)jin('id', 0);
    if (!$id) api_error('id required');
    $conn->query("DELETE FROM wa_campaign_events WHERE campaign_id=$id");
    $conn->query("DELETE FROM wa_campaign_recipients WHERE campaign_id=$id");
    $conn->query("DELETE FROM wa_campaigns WHERE id=$id");
    api_success([]);
}

if ($action === 'duplicate') {
    $id = (int)jin('id', 0);
    $r = $conn->query("SELECT * FROM wa_campaigns WHERE id=$id LIMIT 1");
    $row = $r ? $r->fetch_assoc() : null;
    if (!$row) api_error('Not found', 404);

    // conversion_count is deliberately NOT in this list: a copy that has never been sent was
    // inheriting the original's conversions and showing them in the list on day zero.
    $cols = ['name', 'tags', 'ga_source', 'ga_medium', 'ga_campaign', 'ga_content', 'ga_term',
             'sender_id', 'send_provider', 'goal_event_name', 'goal_window_days', 'goal_attribution', 'click_target_url',
             'audience_type', 'segment_ids', 'exclude_segment_ids', 'exclude_list_ids', 'list_ids',
             'dedup_enabled', 'dedup_window_hours', 'dedup_scope',
             'message_type', 'template_id', 'template_name', 'template_language', 'template_category',
             'header_type', 'header_text', 'header_media_url', 'body_text', 'footer_text', 'buttons',
             'variables', 'text_content', 'preview_url',
             'contact_limit_enabled', 'contact_limit', 'retry_enabled'];
    $vals = [];
    foreach ($cols as $c) {
        if ($c === 'name') { $vals[] = "'" . $conn->real_escape_string($row['name'] . ' (Copy)') . "'"; continue; }
        $v = $row[$c];
        $vals[] = $v === null ? 'NULL' : "'" . $conn->real_escape_string((string)$v) . "'";
    }

    /*
     * created_at written by PHP, not left to DEFAULT CURRENT_TIMESTAMP — MySQL's clock is not
     * PHP's (see config/database.php's date_default_timezone_set). The unified campaigns list
     * sorts a draft by created_at and a sent campaign by started_at/completed_at, which are
     * PHP-written, so a copy stamped on MySQL's clock landed hours in the past and "Newest first"
     * hid it below everything sent since. Same fix as campaigns.php's duplicate.
     */
    $now  = date('Y-m-d H:i:s');
    $nowQ = "'" . $conn->real_escape_string($now) . "'";
    $cols[] = 'created_at'; $vals[] = $nowQ;
    $cols[] = 'updated_at'; $vals[] = $nowQ;

    /*
     * The INSERT used to go completely unchecked: api_success() reported a copy that did not
     * exist, the list came back unchanged, and nothing anywhere said why. try/catch as well as
     * a return check because PHP 8.1 made mysqli throw on error rather than return false — one
     * of the two fires depending on how this host is configured, and both must end up as a
     * message the admin can read.
     */
    $err = '';
    try {
        $ok = $conn->query("INSERT INTO wa_campaigns (" . implode(',', $cols) . ", created_by)
                            VALUES (" . implode(',', $vals) . ', ' . (int)($jwt['user_id'] ?? 0) . ')');
    } catch (Throwable $e) { $ok = false; $err = $e->getMessage(); }
    if (!$ok || !$conn->insert_id) api_error('Could not duplicate: ' . ($err ?: ($conn->error ?: 'insert failed')), 500);

    api_success(['id' => (int)$conn->insert_id, 'name' => $row['name'] . ' (Copy)', 'created_at' => $now]);
}

if ($action === 'tags') {
    // Collected into a plain list, NOT used as array keys — PHP silently casts any key that
    // looks like a whole number ("171") to an int, which then serializes as a bare JSON number
    // and breaks the frontend's tag.toLowerCase() calls.
    $r = $conn->query("SELECT tags FROM wa_campaigns WHERE tags IS NOT NULL AND tags <> ''");
    $all = [];
    while ($r && $row = $r->fetch_assoc()) {
        foreach (explode(',', $row['tags']) as $t) {
            $t = trim((string)$t);
            if ($t !== '') $all[] = $t;
        }
    }
    $tags = array_map('strval', array_values(array_unique($all)));
    sort($tags, SORT_NATURAL | SORT_FLAG_CASE);
    api_success(['tags' => $tags]);
}

if ($action === 'audience_count') {
    $config = [
        'audience_type'       => jin('audience_type', 'segments'),
        'segment_ids'         => json_decode(jin('segment_ids', '[]'), true) ?: [],
        'exclude_segment_ids' => json_decode(jin('exclude_segment_ids', '[]'), true) ?: [],
        'exclude_list_ids'    => json_decode(jin('exclude_list_ids', '[]'), true) ?: [],
        'list_ids'            => json_decode(jin('list_ids', '[]'), true) ?: [],
        'domain_filter'       => '',
    ];
    $resolved = wa_resolve_audience($config);
    $phones   = array_column($resolved['recipients'], 'phone');

    // Opt-outs are always subtracted; the dedup preview is only computed when the toggle is on,
    // since it's the expensive part (a JOIN across every past campaign's recipients).
    $optins   = wa_optin_map($phones);
    $optedOut = count(array_filter($phones, fn($p) => ($optins[$p] ?? '') === 'optout'));

    $dedupSkipped = 0;
    if ((int)jin('dedup_enabled', 0) === 1) {
        $recent = wa_recently_messaged(
            $phones,
            max(1, (int)jin('dedup_window_hours', 24)),
            (string)jin('dedup_scope', 'all_campaigns'),
            jin('template_name', null),
            (int)jin('id', 0)
        );
        $dedupSkipped = count(array_intersect_key(array_flip($phones), $recent));
    }

    $reachable = count($phones) - $optedOut - $dedupSkipped;
    api_success([
        'count'           => max(0, $reachable),
        'raw_count'       => count($phones),
        'unreachable'     => $resolved['unreachable'],
        'duplicates'      => $resolved['duplicates'],
        'opted_out'       => $optedOut,
        'dedup_skipped'   => $dedupSkipped,
        // Removed by the "Exclude contacts" picker, before phone reachability was even looked at.
        'matched'         => $resolved['matched'],
        'excluded'        => $resolved['excluded'],
    ]);
}

/*
 * The audience this campaign would message right now, as a CSV. Exclusions are applied and
 * unusable numbers are already gone; opt-outs get a column of their own rather than being
 * dropped, since "who asked to stop hearing from us" is the reason people open this file.
 * Resolved through wa_resolve_audience(), the same function the send materializes from, so the
 * file is the send list and not a second opinion.
 */
if ($action === 'audience_export') {
    $config = [
        'audience_type'       => jin('audience_type', 'segments'),
        'segment_ids'         => json_decode(jin('segment_ids', '[]'), true) ?: [],
        'exclude_segment_ids' => json_decode(jin('exclude_segment_ids', '[]'), true) ?: [],
        'exclude_list_ids'    => json_decode(jin('exclude_list_ids', '[]'), true) ?: [],
        'list_ids'            => json_decode(jin('list_ids', '[]'), true) ?: [],
        'domain_filter'       => '',
    ];
    $resolved = wa_resolve_audience($config);
    $phones   = array_column($resolved['recipients'], 'phone');
    $optins   = wa_optin_map($phones);

    $slug = preg_replace('/[^A-Za-z0-9_-]+/', '-', trim((string)jin('name', 'audience')));
    $slug = trim($slug, '-') ?: 'audience';

    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $slug . '-audience-' . date('Y-m-d') . '.csv"');
    $out = fopen('php://output', 'w');
    fwrite($out, chr(0xEF) . chr(0xBB) . chr(0xBF)); // BOM, so Excel reads names as UTF-8
    fputcsv($out, ['Phone', 'First name', 'Last name', 'Email', 'User ID', 'Opted out']);
    foreach ($resolved['recipients'] as $r) {
        fputcsv($out, [
            $r['phone'], $r['first_name'] ?? '', $r['last_name'] ?? '', $r['email'] ?? '',
            $r['user_id'] ?? '', (($optins[$r['phone']] ?? '') === 'optout') ? 'Yes' : 'No',
        ]);
    }
    fclose($out);
    exit;
}

if ($action === 'preflight') {
    $id = (int)jin('id', 0);
    $r = $conn->query("SELECT * FROM wa_campaigns WHERE id=$id LIMIT 1");
    $campaign = $r ? $r->fetch_assoc() : null;
    if (!$campaign) api_error('Not found', 404);
    api_success(wa_validate_for_send($campaign));
}

if ($action === 'send_test') {
    $id = (int)jin('id', 0);
    $r = $conn->query("SELECT * FROM wa_campaigns WHERE id=$id LIMIT 1");
    $campaign = $r ? $r->fetch_assoc() : null;
    if (!$campaign) api_error('Save the campaign before sending a test', 404);

    $raw = (string)jin('phones', '');
    $inputs = array_values(array_filter(array_map('trim', preg_split('/[,;\n]+/', $raw))));
    if (!$inputs) api_error('Enter at least one WhatsApp number');

    $settings  = wa_settings_row() ?: [];
    // A test must go out through the SAME number and credentials the real send will use, or it
    // proves nothing about whether that number is set up correctly.
    $sender    = wa_sender_for_campaign($campaign);
    if (!$sender) api_error('Add a sending number in WhatsApp settings first');
    // Same route as the real send too, not just the same number — a test that quietly went out
    // through the other API would prove the wrong thing.
    $transport = wa_transport_for_sender($settings, $sender, $campaign['send_provider'] ?? null);
    $cc        = wa_default_cc();
    $attributes = load_all_attributes();

    $results = [];
    foreach ($inputs as $input) {
        $phone = wa_normalize_phone($input, $cc);
        if ($phone === null) {
            $results[] = ['phone' => $input, 'ok' => false, 'error' => 'Not a valid WhatsApp number'];
            continue;
        }

        // If the number belongs to a real student, use their real identity so merge tags and
        // mapped Customer Attributes resolve exactly as they will on the real send — otherwise
        // a test tells you nothing about whether personalization works.
        $phoneE = $conn->real_escape_string($phone);
        $last10 = substr($phone, -10);
        // Matched against the handful of literal shapes a number is actually stored in, rather
        // than wrapping the column in REPLACE()/LIKE — a function on the column defeats any
        // index on `phone` and turns this into a full scan of the users table.
        $candidates = array_unique([$phone, $last10, '+' . $phone, '0' . $last10, '+91' . $last10]);
        $inList = implode(',', array_map(fn($p) => "'" . $conn->real_escape_string($p) . "'", $candidates));
        $uRes = $conn->query("SELECT user_id, fname, lname, email FROM users WHERE phone IN ($inList) LIMIT 1");
        $u = $uRes ? $uRes->fetch_assoc() : null;

        $recipient = [
            'user_id'    => $u['user_id'] ?? null,
            'email'      => $u['email'] ?? '',
            'first_name' => $u['fname'] ?? 'Test',
            'last_name'  => $u['lname'] ?? 'User',
            'phone'      => $phone,
        ];
        $attrTokens = ($attributes && !empty($recipient['email']))
            ? (resolve_attribute_values_batch($attributes, [$recipient])[strtolower($recipient['email'])] ?? [])
            : [];

        $rid = bin2hex(random_bytes(16));
        // Test rows live in the same table (is_test=1) so a test send is auditable and shows up
        // in the report's own "test sends" view — uq_campaign_phone keeps them from clashing
        // with the real audience.
        $conn->query("INSERT INTO wa_campaign_recipients
            (campaign_id, user_id, phone, raw_phone, email, first_name, last_name, is_test, status, rid)
            VALUES ($id, " . ($recipient['user_id'] ? (int)$recipient['user_id'] : 'NULL') . ", '$phoneE',
                    '" . $conn->real_escape_string($input) . "',
                    '" . $conn->real_escape_string((string)$recipient['email']) . "',
                    '" . $conn->real_escape_string((string)$recipient['first_name']) . "',
                    '" . $conn->real_escape_string((string)$recipient['last_name']) . "',
                    1, 'pending', '$rid')
            ON DUPLICATE KEY UPDATE status='pending', rid=VALUES(rid), attempts=0, error_message=NULL");
        $recIdRes = $conn->query("SELECT id, rid FROM wa_campaign_recipients WHERE campaign_id=$id AND is_test=1 AND phone='$phoneE' LIMIT 1");
        $recRow = $recIdRes ? $recIdRes->fetch_assoc() : null;
        $recId = (int)($recRow['id'] ?? 0);
        $rid   = (string)($recRow['rid'] ?? $rid);

        $rendered = wa_render_for_recipient($campaign, $recipient, $attrTokens);
        $res = $transport->sendMessage($phone, $rendered['content'], $rid);

        if ($recId) {
            if ($res['ok']) {
                $mid = $conn->real_escape_string((string)($res['message_id'] ?? ''));
                $body = $conn->real_escape_string(mb_substr($rendered['preview'], 0, 4000));
                $conn->query("UPDATE wa_campaign_recipients SET status='sent', sent_at=NOW(), wa_message_id='$mid', rendered_body='$body' WHERE id=$recId");
            } else {
                $err = $conn->real_escape_string(substr((string)($res['error'] ?? ''), 0, 480));
                $conn->query("UPDATE wa_campaign_recipients SET status='failed', failed_at=NOW(), error_message='$err' WHERE id=$recId");
            }
        }
        $results[] = ['phone' => $phone, 'ok' => $res['ok'], 'error' => $res['error'] ?? null, 'message_id' => $res['message_id'] ?? null];
    }
    api_success([
        'results'   => $results,
        'sent_from' => $sender['business_number'],
    ]);
}

if ($action === 'send_now') {
    $id = (int)jin('id', 0);
    $r = $conn->query("SELECT * FROM wa_campaigns WHERE id=$id LIMIT 1");
    $campaign = $r ? $r->fetch_assoc() : null;
    if (!$campaign) api_error('Not found', 404);

    $checks = wa_validate_for_send($campaign);
    if ($checks['blocking']) api_error('Cannot send: ' . implode('; ', $checks['blocking']));

    // Recipients are NOT materialized here — the resolve + insert happens inside the worker's
    // background run, which has no web-request time limit, so this click stays instant even for
    // a 40k-number audience. The count below is a preview, not the queued rows.
    // Snapshot the sending identity now. Changing the default number, editing a Source ID or
    // deleting a sender tomorrow must not silently re-route a campaign that is already running.
    $sender = wa_sender_for_campaign($campaign);
    $srcE  = $conn->real_escape_string((string)($sender['source_id'] ?? ''));
    $numE  = $conn->real_escape_string((string)($sender['business_number'] ?? ''));
    $wabaE = $conn->real_escape_string((string)($sender['waba_id'] ?? ''));
    $sid   = (int)($sender['id'] ?? 0);
    /*
     * The ROUTE is frozen here alongside the number, for exactly the same reason: "send through"
     * is a decision made at send time, and flipping a number from Netcore to Meta in Settings
     * afterwards must not silently re-route a campaign that is already going out.
     * wa_resolve_provider() keeps the campaign's own explicit choice when it has one.
     */
    $provE = $conn->real_escape_string((string)wa_resolve_provider($sender, $campaign['send_provider'] ?? null));
    $conn->query("UPDATE wa_campaigns
                     SET status='running', schedule_type='now', scheduled_at=NULL, started_at=NOW(), last_error=NULL,
                         total_recipients=0, sent_count=0, failed_count=0, materialized_at=NULL,
                         source_id='$srcE', business_number='$numE', waba_id='$wabaE', send_provider='$provE'"
                         . ($sid ? ", sender_id=$sid" : '') . "
                   WHERE id=$id");
    wa_trigger_worker_async($id);
    api_success(['queued' => $checks['audience']['count']]);
}

if ($action === 'schedule') {
    $id = (int)jin('id', 0);
    $at = trim((string)jin('scheduled_at', ''));
    if (!$at) api_error('Pick a date & time');
    $ts = strtotime($at);
    if (!$ts || $ts <= time()) api_error('Scheduled time must be in the future');

    $r = $conn->query("SELECT * FROM wa_campaigns WHERE id=$id LIMIT 1");
    $campaign = $r ? $r->fetch_assoc() : null;
    if (!$campaign) api_error('Not found', 404);

    $checks = wa_validate_for_send($campaign);
    if ($checks['blocking']) api_error('Cannot schedule: ' . implode('; ', $checks['blocking']));

    $sender = wa_sender_for_campaign($campaign);
    $atE   = $conn->real_escape_string(date('Y-m-d H:i:s', $ts));
    $srcE  = $conn->real_escape_string((string)($sender['source_id'] ?? ''));
    $numE  = $conn->real_escape_string((string)($sender['business_number'] ?? ''));
    $wabaE = $conn->real_escape_string((string)($sender['waba_id'] ?? ''));
    $sid   = (int)($sender['id'] ?? 0);
    // The AUDIENCE is deliberately re-resolved by the worker when the time arrives (a reminder
    // scheduled for tomorrow should go to whoever qualifies tomorrow), but the SENDING NUMBER
    // and its ROUTE are frozen here — both are explicit choices, not moving targets.
    $provE = $conn->real_escape_string((string)wa_resolve_provider($sender, $campaign['send_provider'] ?? null));
    $conn->query("UPDATE wa_campaigns
                     SET status='scheduled', schedule_type='later', scheduled_at='$atE', last_error=NULL,
                         total_recipients=0, materialized_at=NULL,
                         source_id='$srcE', business_number='$numE', waba_id='$wabaE', send_provider='$provE'"
                         . ($sid ? ", sender_id=$sid" : '') . "
                   WHERE id=$id");
    api_success(['queued' => $checks['audience']['count'], 'scheduled_at' => $atE]);
}

if ($action === 'pause') {
    $id = (int)jin('id', 0);
    $r = $conn->query("SELECT status FROM wa_campaigns WHERE id=$id LIMIT 1");
    $row = $r ? $r->fetch_assoc() : null;
    if (!$row) api_error('Not found', 404);
    if (!in_array($row['status'], ['draft', 'scheduled', 'running'], true)) {
        api_error('Only draft, scheduled or running campaigns can be suspended');
    }
    $conn->query("UPDATE wa_campaigns SET status='suspended' WHERE id=$id");
    api_success([]);
}

if ($action === 'resume') {
    $id = (int)jin('id', 0);
    $r = $conn->query("SELECT * FROM wa_campaigns WHERE id=$id LIMIT 1");
    $campaign = $r ? $r->fetch_assoc() : null;
    if (!$campaign) api_error('Not found', 404);
    if ($campaign['status'] !== 'suspended') api_error('Only suspended campaigns can be resumed');

    if ($campaign['schedule_type'] === 'later' && $campaign['scheduled_at'] && strtotime($campaign['scheduled_at']) > time()) {
        $conn->query("UPDATE wa_campaigns SET status='scheduled', last_error=NULL WHERE id=$id");
    } else {
        $conn->query("UPDATE wa_campaigns SET status='running', last_error=NULL WHERE id=$id");
        wa_trigger_worker_async($id);
    }
    api_success([]);
}

if ($action === 'requeue') {
    $id = (int)jin('id', 0);
    $r = $conn->query("SELECT total_recipients FROM wa_campaigns WHERE id=$id LIMIT 1");
    $row = $r ? $r->fetch_assoc() : null;
    if (!$row) api_error('Not found', 404);

    if ((int)$row['total_recipients'] === 0) {
        // This campaign never had any recipients at all. Clearing materialized_at forces a
        // fresh audience resolve on the next tick instead of just relabelling the status over
        // a check that has already been made and will never change on its own.
        $conn->query("UPDATE wa_campaigns SET status='running', materialized_at=NULL WHERE id=$id");
    } else {
        // Real per-number failures — the audience was resolved correctly, so retry only those.
        $conn->query("UPDATE wa_campaign_recipients SET status='pending', attempts=0, error_message=NULL, error_code=NULL
                       WHERE campaign_id=$id AND status='failed' AND is_test=0");
        $conn->query("UPDATE wa_campaigns SET status='running', failed_count=0 WHERE id=$id AND status IN ('sent','failed','suspended')");
    }
    wa_trigger_worker_async($id);
    api_success([]);
}

if ($action === 'report') {
    $id = (int)jin('id', 0);
    $r = $conn->query("SELECT * FROM wa_campaigns WHERE id=$id LIMIT 1");
    $campaign = $r ? $r->fetch_assoc() : null;
    if (!$campaign) api_error('Not found', 404);
    $campaign['buttons']   = json_decode($campaign['buttons'] ?? '[]', true) ?: [];
    $campaign['variables'] = json_decode($campaign['variables'] ?? '{}', true) ?: [];

    // People who clicked, alongside click_count's total taps — same two sources, same reasoning
    // as the list query above.
    $cu = $conn->query("SELECT GREATEST(
                          (SELECT COUNT(DISTINCT lc.identity_key)
                             FROM wa_link_clicks lc WHERE lc.campaign_id = $id),
                          (SELECT COUNT(*) FROM wa_campaign_recipients cr
                            WHERE cr.campaign_id = $id AND cr.is_test = 0
                              AND cr.first_clicked_at IS NOT NULL)
                        ) AS c");
    $campaign['clicked_users'] = $cu ? (int)$cu->fetch_assoc()['c'] : 0;

    /*
     * Recomputed on open rather than only on the cron tick, so a report you deliberately went to
     * look at is never stale — the cron's job is to keep the LIST accurate in the background.
     * Null means no goal is set, which the report renders as "not tracked" rather than zero:
     * "0 conversions" and "we weren't counting" are very different statements.
     */
    /*
     * Re-check the campaign's own status before rendering anything.
     *
     * A campaign is marked 'sent' the instant the provider accepts the last message; rejections
     * arrive afterwards on the webhook. Campaigns finished before wa_reconcile_campaign_status()
     * existed can therefore still carry a stale verdict — a green SENT badge above "Failed 2" —
     * and opening the report is exactly when someone is looking at that contradiction.
     */
    wa_reconcile_campaign_status($id);
    $cRe = $conn->query("SELECT status FROM wa_campaigns WHERE id=$id LIMIT 1");
    if ($cRe && $cReRow = $cRe->fetch_assoc()) $campaign['status'] = $cReRow['status'];

    require_once __DIR__ . '/lib/WaConversionTracker.php';

    /*
     * Conversion figures are a PANEL on the report, not the report itself.
     *
     * Both calls below touch tables outside this feature — `users` for the identity backfill, the
     * goal's own event table for the count — and either can throw on an environment difference
     * that has nothing to do with the campaign: a collation mismatch between utf8mb4_general_ci
     * and utf8mb4_unicode_ci, a column a migration hasn't added yet, a permission. Uncaught, that
     * turned the entire report endpoint into a 500 and the admin lost sent/delivered/read/failed
     * as well — every number on the page — because one optional panel could not be computed.
     */
    try {
        wa_backfill_recipient_user_ids($id);   // list-sourced recipients have no user_id to join on
        $campaign['conversion_count'] = wa_conversion_count($campaign);
    } catch (\Throwable $e) {
        // null, not 0: "we could not measure this" and "nobody converted" are different claims,
        // and the UI already renders an em dash for the first.
        $campaign['conversion_count'] = null;
        $campaign['conversion_error'] = $e->getMessage();
        wa_log("campaign #$id: conversion panel unavailable on the report — " . $e->getMessage());
    }
    if ($campaign['conversion_count'] !== null) {
        $conn->query('UPDATE wa_campaigns SET conversion_count = ' . (int)$campaign['conversion_count'] . " WHERE id=$id");
    }

    $statusCounts = ['pending' => 0, 'processing' => 0, 'sent' => 0, 'delivered' => 0, 'read' => 0, 'failed' => 0, 'skipped' => 0];
    $sc = $conn->query("SELECT status, COUNT(*) AS c FROM wa_campaign_recipients WHERE campaign_id=$id AND is_test=0 GROUP BY status");
    while ($sc && $row = $sc->fetch_assoc()) $statusCounts[$row['status']] = (int)$row['c'];

    $evR = $conn->query("SELECT e.event_type, e.error_code, e.detail, e.created_at, r.phone
                           FROM wa_campaign_events e
                           JOIN wa_campaign_recipients r ON r.id = e.recipient_id
                          WHERE e.campaign_id=$id AND r.is_test=0
                          ORDER BY e.id DESC LIMIT 30");
    $events = [];
    while ($evR && $row = $evR->fetch_assoc()) $events[] = $row;

    // The provider's own rejection text, grouped — one bad template name produces thousands of
    // identical failures, and "what is Netcore actually saying" should be one line, not a scroll.
    $fgR = $conn->query("SELECT COALESCE(error_message,'Unknown error') AS error_message,
                                COALESCE(error_code,'') AS error_code, COUNT(*) AS c
                           FROM wa_campaign_recipients
                          WHERE campaign_id=$id AND status='failed' AND is_test=0
                          GROUP BY error_message, error_code ORDER BY c DESC LIMIT 20");
    $failureGroups = [];
    while ($fgR && $row = $fgR->fetch_assoc()) $failureGroups[] = $row;

    $testR = $conn->query("SELECT phone, status, error_message, sent_at
                             FROM wa_campaign_recipients WHERE campaign_id=$id AND is_test=1
                            ORDER BY id DESC LIMIT 20");
    $tests = [];
    while ($testR && $row = $testR->fetch_assoc()) $tests[] = $row;

    api_success([
        'campaign' => $campaign, 'recipient_status_counts' => $statusCounts,
        'events' => $events, 'failure_groups' => $failureGroups, 'test_sends' => $tests,
    ]);
}

if ($action === 'recipients') {
    $id      = (int)jin('id', 0);
    $page    = max(1, (int)jin('page', 1));
    $perPage = max(1, min(100, (int)jin('per_page', 25)));
    $status  = jin('status', 'all');
    $search  = trim((string)jin('search', ''));
    $offset  = ($page - 1) * $perPage;

    $where = ["campaign_id=$id", 'is_test=0'];
    /*
     * 'sent' means ACCEPTED BY THE PROVIDER, not "currently sitting at status sent".
     *
     * A recipient's status is a single value that moves forward: sent → delivered → read. So an
     * exact match on 'sent' only ever returns the rows whose receipt has not arrived yet, and
     * once a campaign's receipts are all in it returns NOTHING — which is what put "0 recipients"
     * under a Sent tab on a report whose header said Sent 3,696. The empty list was accurate and
     * completely misleading.
     *
     * The header stat counts every message the provider took, so the filter beside it has to
     * mean the same thing. Delivered and Read stay exact — those tabs are asking a narrower
     * question and their counts already match the stats above them.
     */
    if ($status === 'sent') {
        $where[] = "status IN ('sent','delivered','read')";
    } elseif ($status !== 'all' && $status !== '') {
        $where[] = "status='" . $conn->real_escape_string($status) . "'";
    }
    if ($search !== '') {
        $s = $conn->real_escape_string($search);
        $where[] = "(phone LIKE '%$s%' OR first_name LIKE '%$s%' OR last_name LIKE '%$s%' OR email LIKE '%$s%')";
    }
    $whereSql = 'WHERE ' . implode(' AND ', $where);

    $tr = $conn->query("SELECT COUNT(*) AS c FROM wa_campaign_recipients $whereSql");
    $total = $tr ? (int)$tr->fetch_assoc()['c'] : 0;

    /* error_code alongside error_message: the message is what happened, the code is what to look
       up. "131042" is the difference between guessing and searching Meta's error reference, and
       it is what the Activity log filters and groups by. skip_reason covers the rows that never
       reached the provider at all (deduplicated, opted out, no usable number) — those are not
       failures and must not read as one. */
    $r = $conn->query("SELECT id, phone, first_name, last_name, email, status,
                              error_message, error_code, skip_reason,
                              wa_message_id, sent_at, delivered_at, read_at, failed_at, click_count
                         FROM wa_campaign_recipients $whereSql
                        ORDER BY id ASC LIMIT $perPage OFFSET $offset");
    $rows = [];
    while ($r && $row = $r->fetch_assoc()) $rows[] = $row;


    api_success([
        'recipients' => $rows, 'total' => $total, 'page' => $page, 'per_page' => $perPage,
        'pages' => $total > 0 ? (int)ceil($total / $perPage) : 1,
    ]);
}

/*
 * The people who converted — the list behind the Converted number.
 *
 * A count nobody can open is a claim nobody can check. This returns the same rows the count
 * counts, from the same wa_conversion_list_sql() definition, so the two can never disagree: change
 * how a conversion is defined and both move together.
 *
 * Which columns come back depends on which branch that function took — 'live' reads
 * campaign_attributions and knows the user, the window branch reads the recipient list — so the
 * response names the mode and the UI renders what it actually got.
 */
if ($action === 'conversions') {
    require_once __DIR__ . '/lib/WaConversionTracker.php';

    $id      = (int)jin('id', 0);
    $page    = max(1, (int)jin('page', 1));
    $perPage = max(1, min(100, (int)jin('per_page', 25)));
    $search  = trim((string)jin('search', ''));
    $offset  = ($page - 1) * $perPage;

    $r = $conn->query("SELECT * FROM wa_campaigns WHERE id=$id LIMIT 1");
    $campaign = $r ? $r->fetch_assoc() : null;
    if (!$campaign) api_error('Not found', 404);

    // Same reasoning as the report: one optional panel must never 500 the page it sits on.
    try {
        $sql = wa_conversion_list_sql($campaign, $search);
    } catch (\Throwable $e) {
        api_success(['rows' => [], 'total' => 0, 'page' => 1, 'pages' => 1,
                     'mode' => null, 'error' => $e->getMessage()]);
    }

    // No goal set, or a goal this install can't source. Not an error — just nothing to list.
    if (!$sql) {
        api_success(['rows' => [], 'total' => 0, 'page' => 1, 'pages' => 1, 'mode' => null,
                     'goal' => (string)($campaign['goal_event_name'] ?? '')]);
    }

    $tr    = $conn->query($sql['count']);
    $total = $tr ? (int)$tr->fetch_assoc()['c'] : 0;

    $listSql = $sql['select'] . ' ' . $sql['from'] . ($sql['group'] ?? '') . ($sql['order'] ?? '')
             . " LIMIT $perPage OFFSET $offset";
    $lr   = $conn->query($listSql);
    $rows = [];
    while ($lr && $row = $lr->fetch_assoc()) $rows[] = $row;

    api_success([
        'rows'     => $rows,
        'total'    => $total,
        'page'     => $page,
        'per_page' => $perPage,
        'pages'    => $total > 0 ? (int)ceil($total / $perPage) : 1,
        'mode'     => $sql['mode'] ?? 'window',
        'goal'     => (string)($campaign['goal_event_name'] ?? ''),
        'window'   => wa_goal_window_days($campaign),
    ]);
}

/*
 * One converted person, in full — but only ever WITHIN THIS CAMPAIGN.
 *
 * Every query below is scoped by campaign_id as well as by the person. The same user can be in
 * several campaigns, and showing their history from all of them next to one campaign's number is
 * how a report starts overstating what that campaign did.
 */
if ($action === 'conversion_detail') {
    $id     = (int)jin('id', 0);
    $userId = (int)jin('user_id', 0);
    if (!$id || !$userId) api_error('id and user_id are required');

    $out = ['campaign_id' => $id, 'user_id' => $userId];

    $ur = $conn->query("SELECT user_id, email, phone,
                               TRIM(CONCAT(COALESCE(fname,''),' ',COALESCE(lname,''))) AS name
                          FROM users WHERE user_id = $userId LIMIT 1");
    $out['user'] = $ur ? $ur->fetch_assoc() : null;

    // Their row in THIS campaign: what was sent, when it landed, whether they tapped.
    $rr = $conn->query("SELECT id, phone, email, first_name, last_name, status, error_message, error_code,
                               wa_message_id, queued_at, sent_at, delivered_at, read_at,
                               click_count, first_clicked_at
                          FROM wa_campaign_recipients
                         WHERE campaign_id = $id AND user_id = $userId AND is_test = 0
                         LIMIT 1");
    $out['recipient'] = $rr ? $rr->fetch_assoc() : null;

    /*
     * Every attribution row, not just the first.
     *
     * The Converted number counts this person ONCE — that is the fix for the double counting —
     * but the rows behind it are still worth seeing: they are what shows a goal firing three
     * times in one window, which is exactly the shape that produced the inflated count.
     */
    $ar = $conn->query("SELECT id, event_key, medium, clicked_at, attributed_at, campaign_id
                          FROM campaign_attributions
                         WHERE campaign_id = $id AND user_id = $userId
                           AND medium = 'whatsapp'
                         ORDER BY attributed_at ASC");
    $out['attributions'] = [];
    while ($ar && $row = $ar->fetch_assoc()) $out['attributions'][] = $row;

    // The campaign's own timeline for this person — sends, delivery, taps, opt-outs.
    if (!empty($out['recipient']['id'])) {
        $recipientId = (int)$out['recipient']['id'];
        $er = $conn->query("SELECT event_type, detail, created_at
                              FROM wa_campaign_events
                             WHERE campaign_id = $id AND recipient_id = $recipientId
                             ORDER BY created_at ASC, id ASC LIMIT 100");
        $out['events'] = [];
        while ($er && $row = $er->fetch_assoc()) $out['events'][] = $row;
    } else {
        $out['events'] = [];
    }

    api_success($out);
}

/*
 * The raw click log — every tap, in order, exactly as it was recorded.
 *
 * The Clicked tile is a deduplicated number and deduplicated numbers cannot be audited: "3 taps,
 * 1 person" is only believable if the three taps can be looked at. This is that list.
 *
 * unique=1 collapses it to one line per person, on the same identity_key the tile counts — so the
 * two views are the same data asked two different questions, not two separate implementations
 * that can drift.
 */
/*
 * Who clicked.
 *
 * ── Why this needs a join at all ─────────────────────────────────────────────
 * wa_link_clicks records what was knowable AT THE MOMENT OF THE TAP, which on WhatsApp is a
 * phone number and often nothing else: a tracked link is opened in the phone's browser, usually
 * logged out, so there is no name and frequently no email on the row. The result was a list of
 * bare numbers — technically "who clicked" and useless for actually recognising anybody.
 *
 * The campaign's own recipient row has the name and email, snapshotted when the campaign was
 * materialised. Joining to it is what turns +9198… into a person.
 *
 * Matched on recipient_id when the tap carried one, and on the phone number when it did not —
 * a tap from a static tracked link has no recipient id to carry, which is precisely the common
 * case. Both are scoped to THIS campaign, so a number that appears in several campaigns cannot
 * pull in another campaign's name.
 */
if ($action === 'clicks') {
    $id      = (int)jin('id', 0);
    $page    = max(1, (int)jin('page', 1));
    $perPage = max(1, min(200, (int)jin('per_page', 25)));
    $unique  = (int)jin('unique', 1) === 1;
    $search  = trim((string)jin('search', ''));
    $export  = (int)jin('export', 0) === 1;
    $offset  = ($page - 1) * $perPage;
    if (!$id) api_error('Missing campaign id');

    /* Loaded for one question only: could a click from this campaign have named anybody? The
       report needs it to explain an anonymous row honestly instead of guessing at forwarding. */
    $cr = $conn->query("SELECT id, variables, buttons, goal_event_name FROM wa_campaigns WHERE id=$id LIMIT 1");
    $clickCampaign = $cr ? ($cr->fetch_assoc() ?: []) : [];

    /*
     * LEFT JOIN, unlike the email version. A WhatsApp tap can legitimately belong to nobody we
     * know: the link is identical in every copy of the message, so somebody who was forwarded it
     * can tap it. Dropping those would under-count the clicks the report already shows, and the
     * two figures disagreeing is worse than a row that reads "not in this campaign's audience".
     */
    /*
     * COLLATE is required here, not cosmetic.
     *
     * wa_link_clicks was created as `DEFAULT CHARSET=utf8mb4` with no COLLATE clause, so on
     * MySQL 8 it takes the server default utf8mb4_0900_ai_ci — while wa_campaign_recipients
     * names utf8mb4_unicode_ci explicitly. Comparing two IMPLICIT-collation columns across that
     * boundary raises "Illegal mix of collations ... for operation '='" (error 1267) and takes
     * the whole request down with a 500. The same boundary already bites elsewhere in this
     * codebase — see the journey list trigger and campaign_attribute_data — and the fix is the
     * same: state the collation on the comparison.
     *
     * Applied to lc.phone, NOT r.phone, and that side is chosen deliberately: wrapping a column
     * in a function or a COLLATE makes its index unusable, and wa_campaign_recipients is the
     * side with the (campaign_id, phone) index worth keeping. wa_link_clicks has no index on
     * phone at all, so coercing it costs nothing.
     */
    $join = "LEFT JOIN wa_campaign_recipients r
                    ON r.campaign_id = lc.campaign_id
                   AND (r.id = lc.recipient_id
                        OR (lc.recipient_id IS NULL
                            AND r.phone = lc.phone COLLATE utf8mb4_unicode_ci))";

    $where = ["lc.campaign_id = $id"];
    if ($search !== '') {
        $s = $conn->real_escape_string($search);
        $where[] = "(lc.phone LIKE '%$s%' OR lc.email LIKE '%$s%' OR lc.identity_key LIKE '%$s%'
                     OR r.email LIKE '%$s%' OR CONCAT_WS(' ', r.first_name, r.last_name) LIKE '%$s%')";
    }
    $whereSql = 'WHERE ' . implode(' AND ', $where);

    // COALESCE order matters: the recipient row is the better source for a name and an email,
    // the click row for a phone — that is the one thing the tap always knows first-hand.
    $person = "TRIM(CONCAT_WS(' ', MIN(r.first_name), MIN(r.last_name))) AS name,
               COALESCE(MIN(NULLIF(lc.email, '') COLLATE utf8mb4_unicode_ci), MIN(r.email)) AS email,
               COALESCE(MIN(NULLIF(lc.phone, '') COLLATE utf8mb4_unicode_ci), MIN(r.phone)) AS phone";

    if ($unique) {
        $tr    = $conn->query("SELECT COUNT(DISTINCT lc.identity_key) AS c
                                 FROM wa_link_clicks lc $join $whereSql");
        $total = $tr ? (int)$tr->fetch_assoc()['c'] : 0;

        // MIN/MAX rather than bare columns: legal under ONLY_FULL_GROUP_BY, and the pair reads as
        // "first seen / last seen", which is what someone checking a click actually wants.
        $sql = "SELECT lc.identity_key, $person,
                       MIN(lc.user_id) AS user_id, MIN(lc.recipient_id) AS recipient_id,
                       COUNT(*) AS taps,
                       MIN(lc.clicked_at) AS first_clicked_at,
                       MAX(lc.clicked_at) AS clicked_at
                  FROM wa_link_clicks lc $join $whereSql
                 GROUP BY lc.identity_key
                 ORDER BY clicked_at DESC";
    } else {
        $tr    = $conn->query("SELECT COUNT(*) AS c FROM wa_link_clicks lc $join $whereSql");
        $total = $tr ? (int)$tr->fetch_assoc()['c'] : 0;

        $sql = "SELECT lc.id, lc.identity_key,
                       TRIM(CONCAT_WS(' ', r.first_name, r.last_name)) AS name,
                       COALESCE(NULLIF(lc.email, '') COLLATE utf8mb4_unicode_ci, r.email) AS email,
                       COALESCE(NULLIF(lc.phone, '') COLLATE utf8mb4_unicode_ci, r.phone) AS phone,
                       lc.user_id, lc.recipient_id,
                       lc.visitor_key, lc.ip, lc.user_agent, lc.clicked_at, 1 AS taps
                  FROM wa_link_clicks lc $join $whereSql
                 ORDER BY lc.clicked_at DESC, lc.id DESC";
    }

    // Export is the whole list, not the page — a 25-row CSV of a 4,000-click campaign looks
    // complete and silently is not.
    $sql .= $export ? ' LIMIT 50000' : " LIMIT $perPage OFFSET $offset";

    $lr   = $conn->query($sql);
    $rows = [];
    while ($lr && $row = $lr->fetch_assoc()) $rows[] = $row;

    if ($export) {
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="wa-campaign-' . $id . '-clicks.csv"');
        $out = fopen('php://output', 'w');
        fputcsv($out, ['Name', 'Phone', 'Email', 'Taps', 'First clicked', 'Last clicked']);
        foreach ($rows as $r) {
            fputcsv($out, [$r['name'] ?? '', $r['phone'] ?? '', $r['email'] ?? '',
                           $r['taps'] ?? 1, $r['first_clicked_at'] ?? '', $r['clicked_at'] ?? '']);
        }
        fclose($out);
        exit;
    }

    api_success([
        'rows'     => $rows,
        'total'    => $total,
        'page'     => $page,
        'per_page' => $perPage,
        'pages'    => $total > 0 ? (int)ceil($total / $perPage) : 1,
        'unique'   => $unique,
        /*
         * Whether a click from this campaign COULD have been identified at all.
         *
         * Without it the report has to guess why a row is anonymous, and it guessed wrong in the
         * most common case: it said "forwarded, most likely" for a campaign whose every click is
         * anonymous by construction, because the message carried only the static approved button.
         * Blaming the recipient for a configuration choice is worse than saying nothing.
         */
        'identifiable' => wa_campaign_click_is_identifiable($clickCampaign),
    ]);
}

api_error('Invalid action');

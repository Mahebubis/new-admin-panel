<?php
/**
 * /api/caller-iq/tag_call.php  —  an outcome tagged on the phone (no JWT: phones cannot log in)
 * ---------------------------------------------------------------------------
 * POST { device_id, outcome, started_at (ms), number?, idempotency_key?, tagged_via? }
 *
 * The post-call popup opens the instant a call ends, which is seconds BEFORE that call reaches
 * log_call.php. A counselor who taps an outcome in that window must not lose it, and must not
 * create a second, phantom call — so a tag is matched to its call by the call's start time (and
 * its number when known), and parked in caller_iq_pending_tags when the call is not here yet.
 * The next sync of that call picks the tag up.
 *
 * Answers 200 whether the tag was attached now or parked; only our own failures give 503, which
 * the phone's worker retries.
 * ---------------------------------------------------------------------------
 */
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../middleware/auth.php';
require_once __DIR__ . '/ciq_lib.php';

mysqli_report(MYSQLI_REPORT_OFF);
set_exception_handler(function (Throwable $e) {
    error_log('[caller-iq tag] ' . $e->getMessage() . ' @ ' . $e->getFile() . ':' . $e->getLine());
    api_error('Temporary failure, retry later', 503);
});

require_method('POST');

/* ciq_apply_tag() / ciq_store_pending_tag() live in ciq_lib.php. A partial upload must not lose a
   counselor's tag: 503 keeps it queued on the phone until the library is there. */
if (!function_exists('ciq_apply_tag') || !function_exists('ciq_store_pending_tag')) {
    api_error('Server not ready: deploy react-api/api/caller-iq/ciq_lib.php', 503);
}

$in = get_json_input();

if (CALLER_IQ_INGEST_KEY !== '') {
    $sent = $_SERVER['HTTP_X_CALLIQ_KEY'] ?? ($in['key'] ?? '');
    if (!hash_equals(CALLER_IQ_INGEST_KEY, (string)$sent)) api_error('Invalid ingest key', 401);
}

$outcome = ciq_str($in['outcome'] ?? '', 60);
$startedMs = (int)round((float)($in['started_at'] ?? 0));
if ($startedMs > 0 && $startedMs < 100000000000) $startedMs *= 1000;   // seconds, not ms
if ($outcome === '' || $startedMs <= 0) api_success(['stored' => false], 'Nothing to tag');

ciq_ensure_schema($conn);

$device = substr(preg_replace('/[^A-Za-z0-9_\-:.]/', '', (string)($in['device_id'] ?? '')), 0, 64);
$key    = ciq_str($in['idempotency_key'] ?? '', 120);
$norm   = ciq_norm_number(ciq_str($in['number'] ?? '', 40));
$via    = ciq_str($in['tagged_via'] ?? 'popup', 16);
if (!in_array($via, ['popup', 'notification', 'app'], true)) $via = 'popup';

$r = ciq_apply_tag($conn, $device, $key, $norm, $startedMs, $outcome, $via);

if (!$r['matched']) {
    // The call has not synced yet — hold the tag for it.
    ciq_store_pending_tag($conn, $device, $norm, $startedMs, $outcome, $via);
}

api_success([
    'stored'  => true,
    'matched' => (bool)$r['matched'],
    'call_id' => $r['id'],
], $r['matched'] ? 'Tagged' : 'Held until the call syncs');

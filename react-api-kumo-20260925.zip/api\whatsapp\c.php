<?php
/*
 * /api/whatsapp/c.php — the WhatsApp click tracker.
 *
 *   WhatsApp button  →  c.php?t=<recipient rid>  →  records the tap  →  302 to the real page
 *
 * WHY THIS FILE HAS TO EXIST
 * WhatsApp tells nobody when a URL button is tapped. The phone opens a browser and that is the
 * end of it — no webhook from Meta, none from Netcore, nothing to subscribe to. The click is
 * only observable if the link points here first.
 *
 * That single fact is also what makes honest conversion attribution possible. Without it a
 * "conversion" can only mean "received the message, and later did the thing" — which credits the
 * campaign for people who would have signed in anyway. With it, a conversion means "clicked
 * THROUGH this message, and then did the thing", which is the claim you actually want to make.
 *
 * And it deliberately keeps counting after the visit ends: the window runs from the CLICK, so
 * someone who taps the button, closes the browser, and comes back the next day by typing the
 * address still converts. What it will not do is credit someone who never tapped at all.
 *
 * SETUP — the template's button URL must be DYNAMIC, ending in {{1}}:
 *
 *     https://cit3.internshipstudio.com/admin/react-api/api/whatsapp/c.php?t={{1}}
 *
 * and the campaign's button variable is filled with XX_WA_CLICK_TOKEN_XX, which the send worker
 * swaps for that recipient's rid. A static button URL cannot carry a token and therefore cannot
 * be attributed to a person — only re-approving the template with a dynamic button fixes that.
 *
 * NO AUTH, deliberately: this is opened by a phone tapping a link, and it must be as fast and as
 * unconditional as a redirect can be. The rid is a 128-bit random value that only identifies one
 * recipient row, and the worst a forged one can do is add a click to a campaign — so the endpoint
 * writes nothing else and reveals nothing at all.
 */
ini_set('display_errors', 0);
error_reporting(E_ALL & ~E_WARNING & ~E_NOTICE & ~E_DEPRECATED);

require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/lib/config.php';
require_once __DIR__ . '/lib/schema.php';

/** Last-resort destination, used when a click can't be resolved to a campaign. Better to land the
 *  visitor somewhere real than to show them an error page they can do nothing about. */
if (!defined('WA_CLICK_FALLBACK_URL')) define('WA_CLICK_FALLBACK_URL', 'https://internshipstudio.com/');

/** Sends the visitor on their way and stops. Called on every path, including failures — a
 *  tracking problem is ours, never the customer's. */
function wa_click_redirect(string $url): void {
    if (!preg_match('~^https?://~i', $url)) $url = WA_CLICK_FALLBACK_URL;
    header('Location: ' . $url, true, 302);
    header('Cache-Control: no-store, no-cache, must-revalidate');
    exit;
}

$token = trim((string)($_GET['t'] ?? ''));

// Shape check before touching the database: the rid is exactly 32 hex characters, so anything
// else is a crawler or a mangled link and deserves no query.
if (!preg_match('/^[a-f0-9]{32}$/i', $token)) {
    wa_click_redirect(WA_CLICK_FALLBACK_URL);
}

$rid = $conn->real_escape_string($token);
// The campaign's snapshot first, the template's live value as a fallback — a campaign sent before
// the destination was filled in still needs somewhere to send this visitor.
/*
 * The RECIPIENT's own destination wins, then the campaign's, then the template's.
 *
 * That first one is what lets a button carry a per-person link — each student's own WhatsApp
 * group, say — which the button URL itself never could: Meta freezes the URL at approval and
 * allows a variable only at the very end, so the domain is identical in every copy. The send
 * worker resolves the nominated attribute per recipient and stores it on the row; this reads it
 * back. Everyone still passes through here, so the tap is counted either way.
 */
$r = $conn->query("SELECT r.id, r.campaign_id, r.first_clicked_at, c.goal_window_days,
                          COALESCE(NULLIF(r.click_target_url, ''), NULLIF(c.click_target_url, ''), t.click_target_url) AS click_target_url
                     FROM wa_campaign_recipients r
                     JOIN wa_campaigns c ON c.id = r.campaign_id
                     LEFT JOIN wa_templates t ON t.id = c.template_id
                    WHERE r.rid = '$rid' LIMIT 1");
$row = $r ? $r->fetch_assoc() : null;

/*
 * Not a campaign recipient — try the JOURNEY side before giving up.
 *
 * A journey's WhatsApp messages live in journey_messages, not wa_campaign_recipients, so a tap
 * from a journey step found nothing here and every visitor was dumped on the fallback page. They
 * reach the same button through the same approved template, so they deserve the same redirect.
 *
 * Counting is kept where it belongs: journey clicks are recorded on the journey message, and the
 * campaign counters below are skipped entirely, so a journey tap can never inflate a campaign.
 */
if (!$row) {
    $jr = $conn->query("SELECT id, click_target_url, first_clicked_at FROM journey_messages WHERE rid = '$rid' LIMIT 1");
    $jrow = $jr ? $jr->fetch_assoc() : null;
    if ($jrow) {
        $jid = (int)$jrow['id'];
        $conn->query("UPDATE journey_messages
                         SET click_count = click_count + 1,
                             first_clicked_at = COALESCE(first_clicked_at, NOW())
                       WHERE id = $jid");
        $jTarget = trim((string)($jrow['click_target_url'] ?? ''));
        wa_click_redirect($jTarget !== '' ? $jTarget : WA_CLICK_FALLBACK_URL);
    }
}

if (!$row) wa_click_redirect(WA_CLICK_FALLBACK_URL);

$recipientId = (int)$row['id'];
$campaignId  = (int)$row['campaign_id'];

/*
 * Every tap increments click_count — five taps is five taps, and that's a real engagement signal.
 * But first_clicked_at is written ONCE, because it anchors the attribution window: letting a
 * later tap move it would quietly extend the window every time someone revisited, and a
 * conversion could then be credited indefinitely.
 */
$conn->query("UPDATE wa_campaign_recipients
                 SET click_count = click_count + 1,
                     first_clicked_at = COALESCE(first_clicked_at, NOW())
               WHERE id = $recipientId");
$conn->query("UPDATE wa_campaigns SET click_count = click_count + 1 WHERE id = $campaignId");

// Only the first tap becomes a timeline event; the rest are already in the counter and would
// otherwise bury everything else in the report's event list.
if (empty($row['first_clicked_at'])) {
    $conn->query("INSERT INTO wa_campaign_events (campaign_id, recipient_id, event_type, detail)
                  VALUES ($campaignId, $recipientId, 'button_click', 'WhatsApp button tap')");
}

/*
 * Where to send them — and with EXACTLY the three parameters the email tracker sends.
 *
 *   campaign_id   which campaign gets the credit
 *   medium        'whatsapp' rather than 'email', so the two channels stay separable in
 *                 campaign_attributions (they share that table and would otherwise collide on
 *                 campaign_id — WhatsApp #11 and email #11 are different campaigns)
 *   attr_window   the campaign's own goal_window_days, which sizes the attribution cookie's
 *                 expiry at the other end
 *
 * The dashboard's src/utils/attribution.js reads these three and nothing else — see
 * campaigns/track-click.php, which builds the identical string. Matching it exactly is the point:
 * a WhatsApp visitor is then attributed by the same code, on the same terms, as an email one, and
 * record_conversion() writes the campaign_attributions row when the goal fires.
 *
 * attr_window is clamped 1..90 for the same reason it is there: a nonsense stored value must not
 * be able to produce a never-expiring cookie.
 *
 * Existing query strings are preserved — the target may already carry its own parameters, and
 * appending with a bare "?" would corrupt them.
 */
$target = trim((string)($row['click_target_url'] ?? ''));
if ($target === '') $target = WA_CLICK_FALLBACK_URL;

$windowDays = (int)($row['goal_window_days'] ?: 2);
$windowDays = max(1, min(90, $windowDays));

$sep = (strpos($target, '?') === false) ? '?' : '&';
$target .= $sep . 'campaign_id=' . $campaignId . '&medium=whatsapp&attr_window=' . $windowDays;

wa_click_redirect($target);

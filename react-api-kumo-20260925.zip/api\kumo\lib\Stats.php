<?php
/*
 * Stats — every number the KumoMTA dashboard shows.
 *
 * Reads exclusively from this module's own tables. The hourly rollup
 * (kumo_ip_stats) is written by the webhook/worker so the dashboard never has
 * to scan the raw event table, which is the one that grows into millions of
 * rows.
 */

require_once __DIR__ . '/schema.php';

/** Upsert one or more counters into the hourly rollup. */
function kumo_stats_bump(?int $ipId, string $provider, array $inc, ?string $whenSql = null): void {
    global $conn;
    if (!$ipId) $ipId = 0;
    $cols = ['sent','delivered','deferred','bounced','complaints','opens','clicks','unsubs'];
    $set = [];
    $vals = [];
    foreach ($cols as $c) {
        $n = (int)($inc[$c] ?? 0);
        $vals[$c] = $n;
        if ($n !== 0) $set[] = "$c = $c + $n";
    }
    if (!$set) return;

    $bucket = $whenSql ?: "DATE_FORMAT(NOW(), '%Y-%m-%d %H:00:00')";
    $p = $conn->real_escape_string(substr($provider ?: 'other', 0, 32));
    $sql = "INSERT INTO kumo_ip_stats (ip_id, bucket, provider, " . implode(',', $cols) . ")
            VALUES ($ipId, $bucket, '$p', " . implode(',', array_map(fn($c) => (int)$vals[$c], $cols)) . ")
            ON DUPLICATE KEY UPDATE " . implode(', ', $set);
    try { $conn->query($sql); } catch (\Throwable $e) { error_log('kumo_stats_bump: ' . $e->getMessage()); }
}

/** Normalises a {from,to} pair (YYYY-MM-DD or datetime) into SQL-safe bounds. */
function kumo_range(?string $from, ?string $to): array {
    $f = $from ? date('Y-m-d H:i:s', strtotime(strlen($from) <= 10 ? $from . ' 00:00:00' : $from)) : date('Y-m-d 00:00:00', strtotime('-29 days'));
    $t = $to   ? date('Y-m-d H:i:s', strtotime(strlen($to)   <= 10 ? $to   . ' 23:59:59' : $to))   : date('Y-m-d 23:59:59');
    return [$f, $t];
}

/** Headline totals + every ratio the dashboard tiles show. */
function kumo_stats_overview(?string $from = null, ?string $to = null, ?int $ipId = null): array {
    global $conn;
    [$f, $t] = kumo_range($from, $to);
    $where = "bucket BETWEEN '" . $conn->real_escape_string($f) . "' AND '" . $conn->real_escape_string($t) . "'";
    if ($ipId) $where .= ' AND ip_id = ' . (int)$ipId;

    $row = ['sent'=>0,'delivered'=>0,'deferred'=>0,'bounced'=>0,'complaints'=>0,'opens'=>0,'clicks'=>0,'unsubs'=>0];
    try {
        $r = $conn->query("SELECT
                COALESCE(SUM(sent),0) sent, COALESCE(SUM(delivered),0) delivered,
                COALESCE(SUM(deferred),0) deferred, COALESCE(SUM(bounced),0) bounced,
                COALESCE(SUM(complaints),0) complaints, COALESCE(SUM(opens),0) opens,
                COALESCE(SUM(clicks),0) clicks, COALESCE(SUM(unsubs),0) unsubs
            FROM kumo_ip_stats WHERE $where");
        if ($r && $x = $r->fetch_assoc()) $row = array_map('intval', $x);
    } catch (\Throwable $e) { error_log('kumo_stats_overview: ' . $e->getMessage()); }

    return kumo_with_ratios($row);
}

/** Adds delivery/open/click/bounce/complaint/deferral percentages to a totals row. */
function kumo_with_ratios(array $r): array {
    $sent      = max(0, (int)($r['sent'] ?? 0));
    $delivered = max(0, (int)($r['delivered'] ?? 0));
    $base      = $delivered > 0 ? $delivered : $sent;   // ratios are vs delivered when known
    $pct = fn($n, $d) => $d > 0 ? round(($n / $d) * 100, 2) : 0.0;

    $r['delivery_rate']  = $pct($delivered, $sent);
    $r['bounce_rate']    = $pct((int)($r['bounced'] ?? 0), $sent);
    $r['deferral_rate']  = $pct((int)($r['deferred'] ?? 0), $sent);
    $r['complaint_rate'] = $pct((int)($r['complaints'] ?? 0), $base);
    $r['open_rate']      = $pct((int)($r['opens'] ?? 0), $base);
    $r['click_rate']     = $pct((int)($r['clicks'] ?? 0), $base);
    $r['ctor']           = $pct((int)($r['clicks'] ?? 0), max(1, (int)($r['opens'] ?? 0)));
    $r['unsub_rate']     = $pct((int)($r['unsubs'] ?? 0), $base);
    return $r;
}

/** Time series for the big chart. $bucket = 'hour' | 'day'. */
function kumo_stats_series(?string $from, ?string $to, string $bucket = 'day', ?int $ipId = null): array {
    global $conn;
    [$f, $t] = kumo_range($from, $to);
    $fmt   = $bucket === 'hour' ? "DATE_FORMAT(bucket, '%Y-%m-%d %H:00')" : "DATE(bucket)";
    $where = "bucket BETWEEN '" . $conn->real_escape_string($f) . "' AND '" . $conn->real_escape_string($t) . "'";
    if ($ipId) $where .= ' AND ip_id = ' . (int)$ipId;

    $out = [];
    try {
        $r = $conn->query("SELECT $fmt AS b,
                SUM(sent) sent, SUM(delivered) delivered, SUM(deferred) deferred,
                SUM(bounced) bounced, SUM(complaints) complaints,
                SUM(opens) opens, SUM(clicks) clicks, SUM(unsubs) unsubs
            FROM kumo_ip_stats WHERE $where GROUP BY b ORDER BY b");
        while ($r && $x = $r->fetch_assoc()) {
            $row = ['bucket' => (string)$x['b']] + array_map('intval', array_intersect_key($x, array_flip(
                ['sent','delivered','deferred','bounced','complaints','opens','clicks','unsubs'])));
            $out[] = kumo_with_ratios($row);
        }
    } catch (\Throwable $e) { error_log('kumo_stats_series: ' . $e->getMessage()); }
    return $out;
}

/** Per-mailbox-provider breakdown (Gmail / Outlook / Yahoo / …). */
function kumo_stats_by_provider(?string $from, ?string $to, ?int $ipId = null): array {
    global $conn;
    [$f, $t] = kumo_range($from, $to);
    $where = "bucket BETWEEN '" . $conn->real_escape_string($f) . "' AND '" . $conn->real_escape_string($t) . "'";
    if ($ipId) $where .= ' AND ip_id = ' . (int)$ipId;

    $out = [];
    try {
        $r = $conn->query("SELECT provider,
                SUM(sent) sent, SUM(delivered) delivered, SUM(deferred) deferred, SUM(bounced) bounced,
                SUM(complaints) complaints, SUM(opens) opens, SUM(clicks) clicks, SUM(unsubs) unsubs
            FROM kumo_ip_stats WHERE $where GROUP BY provider ORDER BY sent DESC");
        while ($r && $x = $r->fetch_assoc()) {
            $row = array_map('intval', $x);
            $row['provider'] = (string)$x['provider'];
            $out[] = kumo_with_ratios($row);
        }
    } catch (\Throwable $e) { error_log('kumo_stats_by_provider: ' . $e->getMessage()); }
    return $out;
}

/** One row per sending IP, with today's quota and current health. */
function kumo_ip_rows(?string $from = null, ?string $to = null): array {
    global $conn;
    [$f, $t] = kumo_range($from, $to);
    $fE = $conn->real_escape_string($f);
    $tE = $conn->real_escape_string($t);
    $today = date('Y-m-d');

    $out = [];
    try {
        $sql = "SELECT i.*,
                    d.cap AS today_cap, d.sent AS today_sent,
                    COALESCE(s.sent,0) sent, COALESCE(s.delivered,0) delivered, COALESCE(s.deferred,0) deferred,
                    COALESCE(s.bounced,0) bounced, COALESCE(s.complaints,0) complaints,
                    COALESCE(s.opens,0) opens, COALESCE(s.clicks,0) clicks, COALESCE(s.unsubs,0) unsubs
                FROM kumo_ips i
                LEFT JOIN kumo_ip_daily d ON d.ip_id = i.id AND d.day = '$today'
                LEFT JOIN (
                    SELECT ip_id, SUM(sent) sent, SUM(delivered) delivered, SUM(deferred) deferred,
                           SUM(bounced) bounced, SUM(complaints) complaints, SUM(opens) opens,
                           SUM(clicks) clicks, SUM(unsubs) unsubs
                    FROM kumo_ip_stats WHERE bucket BETWEEN '$fE' AND '$tE' GROUP BY ip_id
                ) s ON s.ip_id = i.id
                WHERE i.status <> 'retired'
                ORDER BY i.sort_order, i.id";
        $r = $conn->query($sql);
        while ($r && $x = $r->fetch_assoc()) {
            $row = [
                'id' => (int)$x['id'], 'ip' => $x['ip'], 'hostname' => $x['hostname'], 'tenant' => $x['tenant'],
                'label' => $x['label'], 'status' => $x['status'], 'health' => $x['health'],
                'batch_no' => (int)($x['batch_no'] ?? 1), 'batch_size' => (int)($x['batch_size'] ?? 0),
                'batch_index' => (int)($x['batch_index'] ?? 0), 'purchased_at' => $x['purchased_at'] ?? null,
                'health_reason' => $x['health_reason'], 'warmup_enabled' => (int)$x['warmup_enabled'],
                'warmup_day' => (int)$x['warmup_day'], 'warmup_started_at' => $x['warmup_started_at'],
                'manual_cap' => $x['manual_cap'] === null ? null : (int)$x['manual_cap'],
                'ptr_ok' => (int)$x['ptr_ok'], 'ptr_value' => $x['ptr_value'],
                'blocklisted' => (int)$x['blocklisted'], 'blocklist_note' => $x['blocklist_note'],
                'good_hours' => (int)$x['good_hours'],
                'paused_reason' => $x['paused_reason'], 'paused_by' => $x['paused_by'], 'paused_at' => $x['paused_at'],
                'last_health_at' => $x['last_health_at'], 'last_send_at' => $x['last_send_at'],
                'today_cap' => (int)($x['today_cap'] ?? 0), 'today_sent' => (int)($x['today_sent'] ?? 0),
                'sent' => (int)$x['sent'], 'delivered' => (int)$x['delivered'], 'deferred' => (int)$x['deferred'],
                'bounced' => (int)$x['bounced'], 'complaints' => (int)$x['complaints'],
                'opens' => (int)$x['opens'], 'clicks' => (int)$x['clicks'], 'unsubs' => (int)$x['unsubs'],
            ];
            $row = kumo_with_ratios($row);
            $row['today_remaining'] = max(0, $row['today_cap'] - $row['today_sent']);
            $row['today_pct'] = $row['today_cap'] > 0 ? round($row['today_sent'] / $row['today_cap'] * 100, 1) : 0;
            $out[] = $row;
        }
    } catch (\Throwable $e) { error_log('kumo_ip_rows: ' . $e->getMessage()); }
    return $out;
}

/** Latest bridge probe + short history for the API-health widget. */
function kumo_api_health_summary(int $points = 24): array {
    global $conn;
    $out = ['latest' => null, 'history' => [], 'uptime_24h' => null];
    try {
        $r = $conn->query("SELECT * FROM kumo_api_health ORDER BY id DESC LIMIT " . max(1, min(200, $points)));
        $rows = [];
        while ($r && $x = $r->fetch_assoc()) {
            $rows[] = [
                'checked_at' => $x['checked_at'], 'ok' => (int)$x['ok'], 'latency_ms' => (int)$x['latency_ms'],
                'queue_size' => (int)$x['queue_size'], 'scheduled' => (int)$x['scheduled'], 'error' => $x['error'],
            ];
        }
        $out['history'] = array_reverse($rows);
        $out['latest']  = $rows[0] ?? null;

        $r2 = $conn->query("SELECT COUNT(*) n, SUM(ok) o FROM kumo_api_health WHERE checked_at >= DATE_SUB(NOW(), INTERVAL 24 HOUR)");
        if ($r2 && $x = $r2->fetch_assoc()) {
            $n = (int)$x['n'];
            $out['uptime_24h'] = $n > 0 ? round(((int)$x['o'] / $n) * 100, 2) : null;
        }
    } catch (\Throwable $e) { error_log('kumo_api_health_summary: ' . $e->getMessage()); }
    return $out;
}

/** Counts used by the dashboard's secondary tiles. */
function kumo_audience_counts(): array {
    global $conn;
    $out = ['contacts' => 0, 'active' => 0, 'blocklisted' => 0, 'lists' => 0, 'segments' => 0, 'templates' => 0];
    try {
        $q = fn($sql) => (($r = $conn->query($sql)) && ($x = $r->fetch_assoc())) ? (int)array_values($x)[0] : 0;
        $out['contacts']    = $q("SELECT COUNT(*) FROM kumo_contacts");
        $out['active']      = $q("SELECT COUNT(*) FROM kumo_contacts WHERE status='active'");
        $out['blocklisted'] = $q("SELECT COUNT(*) FROM kumo_blocklist");
        $out['lists']       = $q("SELECT COUNT(*) FROM kumo_lists");
        $out['segments']    = $q("SELECT COUNT(*) FROM kumo_segments");
        $out['templates']   = $q("SELECT COUNT(*) FROM kumo_templates WHERE status='active'");
    } catch (\Throwable $e) { error_log('kumo_audience_counts: ' . $e->getMessage()); }
    return $out;
}

/** Queue snapshot straight from the recipients table (what is still to send). */
function kumo_queue_snapshot(): array {
    global $conn;
    $out = ['pending' => 0, 'processing' => 0, 'running_campaigns' => 0, 'scheduled_campaigns' => 0, 'next_scheduled_at' => null];
    try {
        $r = $conn->query("SELECT status, COUNT(*) c FROM kumo_campaign_recipients WHERE status IN ('pending','processing') GROUP BY status");
        while ($r && $x = $r->fetch_assoc()) $out[$x['status']] = (int)$x['c'];

        $r = $conn->query("SELECT COUNT(*) c FROM kumo_campaigns WHERE status='running'");
        if ($r && $x = $r->fetch_assoc()) $out['running_campaigns'] = (int)$x['c'];

        $r = $conn->query("SELECT COUNT(*) c, MIN(scheduled_at) m FROM kumo_campaigns WHERE status='scheduled'");
        if ($r && $x = $r->fetch_assoc()) { $out['scheduled_campaigns'] = (int)$x['c']; $out['next_scheduled_at'] = $x['m']; }
    } catch (\Throwable $e) { error_log('kumo_queue_snapshot: ' . $e->getMessage()); }
    return $out;
}

/** Most recent SMTP responses, grouped — the "why are things failing" table. */
function kumo_top_responses(?string $from, ?string $to, int $limit = 8): array {
    global $conn;
    [$f, $t] = kumo_range($from, $to);
    $out = [];
    try {
        $r = $conn->query("SELECT type, code, LEFT(COALESCE(response,''), 160) msg, COUNT(*) c
            FROM kumo_campaign_events
            WHERE created_at BETWEEN '" . $conn->real_escape_string($f) . "' AND '" . $conn->real_escape_string($t) . "'
              AND type IN ('bounce','deferred','complaint')
            GROUP BY type, code, msg ORDER BY c DESC LIMIT " . max(1, min(50, $limit)));
        while ($r && $x = $r->fetch_assoc()) {
            $out[] = ['type' => $x['type'], 'code' => $x['code'], 'message' => $x['msg'], 'count' => (int)$x['c']];
        }
    } catch (\Throwable $e) { error_log('kumo_top_responses: ' . $e->getMessage()); }
    return $out;
}

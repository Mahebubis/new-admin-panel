<?php
/*
 * lib/BounceMailbox.php — the mail server's own answer about every address we write to.
 *
 * WHY THIS EXISTS
 * An address is only proved good by mail arriving at it. Paid verification guesses in advance, and
 * for this account it guesses "Unknown" 87% of the time because most mail servers refuse to confirm
 * a mailbox exists. Meanwhile the true answer has been arriving all along, in the mailbox itself:
 *
 *     This is a permanent error. The following address(es) failed:
 *       tudio@gmail.com
 *       550-5.1.1 The email account that you tried to reach does not exist.
 *
 * That is Gmail saying the mailbox is not real. It costs nothing, it cannot be wrong, and it covers
 * every message this company sends — the dashboard's registration mail, the LMS, campaigns,
 * journeys, support replies — not only what somebody remembered to check.
 *
 * The messages are already in the database: the Freshdesk sync imports contact@'s mailbox into
 * fd_messages, and roughly one in thirteen of those is a delivery failure. This reads them, takes
 * out the address that failed and the reason, and puts the dead ones on the shared Blocklist that
 * every send already consults.
 *
 * ── WHAT IT REFUSES TO DO ────────────────────────────────────────────────────
 * A blocklisted student never receives anything from us again, so the bar is deliberately high:
 *   - only a PERMANENT failure (SMTP 5.x.x) blocks on the first occurrence;
 *   - a temporary one (mailbox full, greylisted, 4.x.x) is recorded and only blocks after three in
 *     thirty days — the same rule journey bounces use;
 *   - our own addresses are never blocked, whatever a loop reports.
 */

require_once __DIR__ . '/../../lists/lib/schema.php';
require_once __DIR__ . '/../../lists/lib/ContactImportWorker.php';

/** Addresses at these domains are ours; a bounce naming one is a loop, not a dead student. */
if (!defined('BOUNCE_OWN_DOMAINS')) {
    define('BOUNCE_OWN_DOMAINS', 'internshipstudio.com,mailer.internshipstudio.com,alert.internshipstudio.com,mailhost.internshipstudio.com');
}
/*
 * TEMPORARY FAILURES NEVER BLOCK. 0 disables it; a positive number would be a strike count.
 *
 * This was 3, and the first pass over the backlog blocklisted 210 people on it — almost every one
 * of them Gmail answering "452-4.2.2 The recipient's inbox is out of storage space". That is a real
 * student with a full inbox, not a dead address: the mailbox exists, and next week the mail lands.
 * Blocking them is the one mistake this feature must never make, because a blocklisted person is
 * invisible — they simply never hear from us again and nothing on screen says why.
 *
 * A permanent 5.x.x answer ("the email account that you tried to reach does not exist") is a fact,
 * and blocks on sight. Everything else is recorded only; the send paths have their own rules for an
 * address that keeps failing.
 */
if (!defined('BOUNCE_SOFT_STRIKES')) define('BOUNCE_SOFT_STRIKES', 0);
/** Messages read per run. The backlog drains over a few minutes; new ones arrive a handful at a time. */
if (!defined('BOUNCE_SCAN_LIMIT')) define('BOUNCE_SCAN_LIMIT', 300);

function bounce_mailbox_ensure_schema(): void {
    global $conn;
    static $done = false;
    if ($done) return;
    $done = true;

    /*
     * One row per (bounce message, address). The message id is kept so the same report can never be
     * counted twice, and so a blocklist entry months later can be traced back to the mail that
     * caused it.
     */
    @$conn->query("CREATE TABLE IF NOT EXISTS email_bounce_reports (
        id            BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
        fd_message_id BIGINT UNSIGNED NOT NULL,
        email         VARCHAR(190) NOT NULL,
        kind          ENUM('hard','soft') NOT NULL DEFAULT 'hard',
        smtp_code     VARCHAR(16)  DEFAULT NULL,
        reason        VARCHAR(400) DEFAULT NULL,
        blocklisted   TINYINT(1)   NOT NULL DEFAULT 0,
        reported_at   DATETIME     NOT NULL,
        UNIQUE KEY uq_msg_email (fd_message_id, email),
        KEY idx_email (email),
        KEY idx_reported (reported_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    // Where the last run stopped, so each message is read once.
    @$conn->query("CREATE TABLE IF NOT EXISTS email_bounce_state (
        id         TINYINT UNSIGNED NOT NULL PRIMARY KEY,
        last_fd_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
        updated_at DATETIME DEFAULT NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
}

/** Is this one of ours? */
function bounce_is_own_address(string $email): bool {
    $domain = strtolower(substr(strrchr($email, '@') ?: '', 1));
    if ($domain === '') return true;   // unparseable: treat as ours, i.e. never block
    foreach (explode(',', BOUNCE_OWN_DOMAINS) as $own) {
        $own = trim(strtolower($own));
        if ($own !== '' && ($domain === $own || str_ends_with($domain, '.' . $own))) return true;
    }
    return false;
}

/**
 * Is this failure about something OTHER than a dead mailbox?
 *
 * Three kinds live here, and none of them justifies blocking a person for ever:
 *   - a 4xx reply: the mailbox exists, it is full or the server is busy;
 *   - our own mail server giving up ("retry timeout exceeded", "all hosts failing") — that says
 *     the far side was unreachable, not that the address is wrong;
 *   - a policy rejection ("access denied", "banned sending IP", 5.7.x): the receiving server is
 *     refusing US, and the student did nothing. Blocking them would hide our own problem.
 */
function bounce_reason_is_temporary(string $reason): bool {
    $r = strtolower($reason);
    if ($r === '') return false;
    if (preg_match('~\b4\d\d[ -]~', $r)) return true;          // 452-4.2.2, 421 4.7.0, …
    foreach (['out of storage', 'over quota', 'quota exceeded', 'mailbox full', 'insufficient system storage',
              'try again', 'retry timeout', 'temporarily', 'temporary failure', 'greylist', 'deferred',
              'connection timed out', 'have been failing', 'access denied', 'banned sending ip',
              'blocked using', 'spam content', 'policy reasons', '5.7.1', '5.7.6', '5.7.606'] as $needle) {
        if (strpos($r, $needle) !== false) return true;
    }
    return false;
}

/**
 * Reads one delivery-failure report and returns what it says.
 *
 * Mail servers write these in several shapes and none of them is optional reading:
 *   - the machine-readable DSN block (Final-Recipient / Status / Diagnostic-Code), which Gmail,
 *     Outlook and anything modern attach;
 *   - Exim's prose ("The following address(es) failed:" then the address, then the remote server's
 *     reply), which is what mailhost.internshipstudio.com sends;
 *   - and the bare conversation ("SMTP error from remote mail server after RCPT TO:<x@y>: 550 ...").
 * Whichever is present, the two things wanted are the same: which address, and was it permanent.
 *
 * @return array<string, array{kind:string, code:?string, reason:string}> keyed by lowercase address
 */
function bounce_parse_report(string $body): array {
    $out = [];
    $body = str_replace("\r\n", "\n", $body);

    $addRecipient = function (string $email, ?string $code, string $reason) use (&$out) {
        $email = strtolower(trim($email, " \t<>.,;:\"'"));
        if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) return;
        if (bounce_is_own_address($email)) return;
        // A permanent failure wins over a temporary one for the same address in the same report.
        $kind = ($code !== null && str_starts_with($code, '5')) ? 'hard' : 'soft';
        /*
         * THE REMOTE SERVER'S OWN WORDS OUTRANK OUR MAIL SERVER'S VERDICT.
         *
         * Exim keeps retrying a temporary failure and, after 72 hours, gives up with "This is a
         * permanent error" — while the reply it quotes underneath is Gmail's "452-4.2.2 The
         * recipient's inbox is out of storage space". Permanent to Exim (it stopped trying),
         * temporary in reality (the mailbox exists and the person is real). Trusting Exim's
         * wording blocklisted 30,177 real students in one afternoon, which is the worst thing this
         * feature can do: they simply never hear from us again, and nothing on screen says why.
         *
         * So a 4xx anywhere in the quoted reply, or a reason that plainly describes a working
         * mailbox that is full or busy, is temporary whatever the envelope says.
         */
        if ($kind === 'hard' && bounce_reason_is_temporary($reason)) $kind = 'soft';
        if (isset($out[$email]) && $out[$email]['kind'] === 'hard' && $kind !== 'hard') return;
        /*
         * One tidy line. A delivery report is laid out over several indented lines, and pasting it
         * in raw put things like "shailesh@refiffmail.com\n    all hosts for 'refiffmail.com'" into
         * the Reason column of the Blocklist screen, where somebody reads it months later to
         * understand why a person is blocked. The address itself is dropped from the front for the
         * same reason: the row already says who it is.
         */
        $reason = trim(preg_replace('~\s+~', ' ', $reason));
        $reason = trim(preg_replace('~^' . preg_quote($email, '~') . '\s*:?~i', '', $reason));
        $out[$email] = ['kind' => $kind, 'code' => $code, 'reason' => trim(mb_substr($reason, 0, 380))];
    };

    /* ── 1. the DSN block ─────────────────────────────────────────────────── */
    if (preg_match_all('~Final-Recipient:\s*(?:rfc822;)?\s*([^\s<>]+@[^\s<>]+)~i', $body, $m, PREG_OFFSET_CAPTURE)) {
        foreach ($m[1] as $hit) {
            $tail = substr($body, $hit[1], 1200);
            $code = null; $reason = '';
            if (preg_match('~Status:\s*([245]\.\d+\.\d+)~i', $tail, $s)) $code = $s[1];
            if (preg_match('~Diagnostic-Code:\s*[^;]*;\s*(.+)~i', $tail, $d)) {
                $reason = trim(preg_split('~\n(?=\S)~', $d[1])[0]);
                if ($code === null && preg_match('~\b([245]\d\d)\b~', $reason, $c)) $code = $c[1][0] . '.x.x';
            }
            $addRecipient($hit[0], $code, $reason !== '' ? $reason : 'Reported by the receiving mail server');
        }
    }

    /* ── 2. the conversation, which carries the clearest wording ──────────── */
    if (preg_match_all('~RCPT TO:\s*<([^>]+)>\s*:?\s*\n?\s*((?:\d{3}[ -][^\n]*\n?){1,4})~i', $body, $m)) {
        foreach ($m[1] as $i => $email) {
            $text = trim(preg_replace('~\s+~', ' ', $m[2][$i]));
            $code = preg_match('~\b(\d{3})\b~', $text, $c) ? $c[1] : null;
            $addRecipient($email, $code, $text);
        }
    }

    /* ── 3. Exim's prose, for reports carrying neither of the above ───────── */
    if (!$out && preg_match('~address(?:\(es\))? failed:\s*\n(.+?)(?:\n\s*\n|$)~is', $body, $m)) {
        $permanent = stripos($body, 'permanent error') !== false;
        foreach (preg_split('~\n~', $m[1]) as $line) {
            if (preg_match('~([^\s<>]+@[^\s<>]+)~', $line, $e)) {
                $addRecipient($e[1], $permanent ? '5.0.0' : null, trim($m[1]));
            }
        }
    }
    return $out;
}

/**
 * Reads one bounce that is NOT stored anywhere, and acts on it.
 *
 * The support desk deliberately throws orphan bounces away — a "Mail delivery failed" that belongs
 * to no ticket is not a support request, and importing them once left the desk showing hundreds of
 * unresolved machine messages. Correct for the desk, and it took this feature's evidence with it:
 * every bounce since that rule shipped was dropped before anything could read the dead address out
 * of it. So the drop point hands the raw message here first. The desk still ignores it.
 *
 * @param string $body the delivery-failure report, as text
 * @param ?string $when when it arrived ('Y-m-d H:i:s'), for the record
 * @return array{addresses:int,hard:int,blocklisted:int}
 */
function bounce_process_report(string $body, ?string $when = null): array {
    global $conn;
    $stats = ['addresses' => 0, 'hard' => 0, 'blocklisted' => 0];
    $body = trim($body);
    if ($body === '') return $stats;

    bounce_mailbox_ensure_schema();
    $at = $conn->real_escape_string($when ?: date('Y-m-d H:i:s'));
    $listId = (int)lists_get_or_create_blocklist_id();

    foreach (bounce_parse_report($body) as $email => $info) {
        $stats['addresses']++;
        if ($info['kind'] === 'hard') $stats['hard']++;
        $e = $conn->real_escape_string($email);
        /*
         * fd_message_id 0 means "this bounce was never stored as a message". The unique key then
         * keeps one row per address for these, which is all that is needed: a permanent failure
         * acts the first time, and a temporary one never blocks anybody.
         */
        $conn->query("INSERT IGNORE INTO email_bounce_reports (fd_message_id, email, kind, smtp_code, reason, reported_at)
                      VALUES (0, '$e', '" . $info['kind'] . "',
                              " . ($info['code'] === null ? 'NULL' : "'" . $conn->real_escape_string($info['code']) . "'") . ",
                              '" . $conn->real_escape_string($info['reason']) . "', '$at')");

        if (!bounce_should_blocklist($email, $info['kind'])) continue;
        if (bounce_email_already_blocklisted($email)) continue;
        contact_upsert_many([['email' => $email, 'reason' => 'Hard bounce: ' . mb_substr($info['reason'], 0, 160)]], $listId, false);
        $conn->query("UPDATE email_bounce_reports SET blocklisted = 1 WHERE fd_message_id = 0 AND email = '$e'");
        $stats['blocklisted']++;
    }
    return $stats;
}

/** Every address is looked at once: has it failed permanently, or often enough to count? */
function bounce_should_blocklist(string $email, string $kind): bool {
    global $conn;
    if ($kind === 'hard') return true;
    if ((int)BOUNCE_SOFT_STRIKES < 1) return false;   // temporary failures never block — see above
    $e = $conn->real_escape_string($email);
    $r = $conn->query("SELECT COUNT(*) c FROM email_bounce_reports
                        WHERE email = '$e' AND reported_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)");
    return $r && (int)$r->fetch_assoc()['c'] >= (int)BOUNCE_SOFT_STRIKES;
}

/**
 * Reads the delivery failures that have arrived since the last run and blocklists the dead ones.
 *
 * @param bool $dryRun report what it would do, and write nothing
 * @return array counts, for the worker log
 */
function bounce_mailbox_scan(int $limit = 0, bool $dryRun = false): array {
    global $conn;
    $limit = $limit > 0 ? $limit : (int)BOUNCE_SCAN_LIMIT;
    $stats = ['messages' => 0, 'addresses' => 0, 'hard' => 0, 'soft' => 0, 'blocklisted' => 0, 'already' => 0, 'last_id' => 0];

    bounce_mailbox_ensure_schema();
    $r = $conn->query("SELECT last_fd_id FROM email_bounce_state WHERE id = 1 LIMIT 1");
    $since = $r && ($row = $r->fetch_assoc()) ? (int)$row['last_fd_id'] : 0;

    $q = $conn->query("SELECT id, body_text, body_html, message_date, created_at
                         FROM fd_messages
                        WHERE id > $since
                          AND (from_email LIKE '%mailer-daemon%' OR from_email LIKE '%postmaster%'
                               OR subject LIKE '%delivery failed%' OR subject LIKE '%Undelivered Mail%'
                               OR subject LIKE '%Delivery Status Notification%')
                        ORDER BY id LIMIT $limit");
    $rows = [];
    while ($q && $row = $q->fetch_assoc()) $rows[] = $row;
    if (!$rows) return $stats;

    $blocklistId = $dryRun ? 0 : (int)lists_get_or_create_blocklist_id();

    foreach ($rows as $row) {
        $stats['messages']++;
        $stats['last_id'] = (int)$row['id'];
        $body = trim((string)$row['body_text']);
        if ($body === '') $body = trim(html_entity_decode(strip_tags((string)$row['body_html'])));
        if ($body === '') continue;

        $when = $conn->real_escape_string((string)($row['message_date'] ?: $row['created_at'] ?: date('Y-m-d H:i:s')));
        foreach (bounce_parse_report($body) as $email => $info) {
            $stats['addresses']++;
            $stats[$info['kind']]++;
            $e = $conn->real_escape_string($email);

            if (!$dryRun) {
                $conn->query("INSERT IGNORE INTO email_bounce_reports (fd_message_id, email, kind, smtp_code, reason, reported_at)
                              VALUES (" . (int)$row['id'] . ", '$e', '" . $info['kind'] . "',
                                      " . ($info['code'] === null ? 'NULL' : "'" . $conn->real_escape_string($info['code']) . "'") . ",
                                      '" . $conn->real_escape_string($info['reason']) . "', '$when')");
                if ($conn->affected_rows < 1) continue;   // this report was already read
            }

            if (!bounce_should_blocklist($email, $info['kind'])) continue;
            if (bounce_email_already_blocklisted($email)) { $stats['already']++; continue; }
            $stats['blocklisted']++;
            if ($dryRun) continue;

            /*
             * OUR blocklist only — the providers are deliberately not told.
             *
             * contact_upsert() suppresses the address at SendGrid, Elastic Email and SES as a side
             * effect, which is right for a spam complaint (a legal obligation belongs everywhere)
             * and wrong here: a bounce is our own data-quality signal, it is reversible, and a
             * suppression list at a provider is far harder to undo than a row in this database.
             * contact_upsert_many()'s third argument is what switches that off.
             */
            contact_upsert_many([[ 'email' => $email,
                'reason' => $info['kind'] === 'hard'
                    ? 'Hard bounce: ' . mb_substr($info['reason'], 0, 160)
                    : BOUNCE_SOFT_STRIKES . ' soft bounces in 30 days' ]], $blocklistId, false);
            $conn->query("UPDATE email_bounce_reports SET blocklisted = 1 WHERE email = '$e' AND fd_message_id = " . (int)$row['id']);
        }
    }

    if (!$dryRun && $stats['last_id'] > 0) {
        $now = date('Y-m-d H:i:s');
        $conn->query("INSERT INTO email_bounce_state (id, last_fd_id, updated_at) VALUES (1, {$stats['last_id']}, '$now')
                      ON DUPLICATE KEY UPDATE last_fd_id = VALUES(last_fd_id), updated_at = VALUES(updated_at)");
    }
    return $stats;
}

/** Already on the Blocklist? Asked before writing, so the count reported is newly blocked people. */
function bounce_email_already_blocklisted(string $email): bool {
    global $conn;
    static $listId = null;
    if ($listId === null) $listId = (int)lists_get_or_create_blocklist_id();
    $e = $conn->real_escape_string(strtolower($email));
    $r = $conn->query("SELECT 1 FROM campaign_contacts c
                        INNER JOIN campaign_list_members m ON m.contact_id = c.id AND m.list_id = $listId
                        WHERE c.email = '$e' LIMIT 1");
    return (bool)($r && $r->num_rows > 0);
}

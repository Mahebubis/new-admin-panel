<?php
/*
 * /api/freshdesk/fd_attachments.php
 *
 *   action=upload    &ticket_id  file=<multipart>   -> stage a file for a reply
 *   action=download  &id [&exp&sig]                 -> force-download
 *   action=view      &id [&exp&sig]                 -> render inline (images/PDF)
 *   action=delete    &id                            -> remove a staged file
 *   action=list      &ticket_id
 *
 * TWO WAYS IN, and the reason there are two:
 *
 *   - Bearer JWT, for anything the panel calls with axios (upload, delete, list).
 *   - A short-lived HMAC signature in the URL, for GETs the BROWSER makes on its
 *     own: <img src="..."> inside a customer's email body, a PDF in an iframe, a
 *     download link. The browser attaches no Authorization header to those, so a
 *     JWT-only endpoint renders every inline screenshot as a broken image.
 *
 * The signature is scoped to one attachment id and expires (default 6h), so a
 * URL copied out of the page cannot be used to walk the attachment table, and
 * stops working shortly after. Both paths still verify the file belongs to a
 * real ticket row before a single byte is written out.
 */

require_once __DIR__ . '/../../config/database.php';
// Required unconditionally, not inside the JWT branch: it defines api_success()
// and api_error(), which the signed-URL path still needs for its own errors.
// Requiring it does not authenticate anything -- only require_jwt() does that.
require_once __DIR__ . '/../../middleware/auth.php';
require_once __DIR__ . '/lib/config.php';
require_once __DIR__ . '/lib/Helpers.php';
require_once __DIR__ . '/lib/schema.php';
require_once __DIR__ . '/lib/MimeParser.php';
require_once __DIR__ . '/lib/Storage.php';

fd_ensure_schema();

$action = fd_str('action', 'download');
$GLOBALS['FD_ACTION'] = $action;

$isBrowserGet = in_array($action, array('download', 'view'), true);
$authorised = false;
$ME = array('id' => null, 'name' => 'Agent');

// ---- signed-URL path (browser GETs only) --------------------------------
if ($isBrowserGet && fd_str('sig', '') !== '') {
    $id  = fd_int('id', 0);
    $exp = fd_int('exp', 0);
    $sig = fd_str('sig', '');
    if (fd_verify_attachment_sig($id, $exp, $sig)) {
        $authorised = true;
    } else {
        // A plain 403 in an <img> shows a broken icon with no explanation; the
        // status text at least lands in the network tab.
        http_response_code(403);
        header('Content-Type: text/plain');
        echo ($exp && $exp < time())
            ? 'This attachment link has expired. Reload the ticket.'
            : 'Invalid attachment signature.';
        exit;
    }
}

// ---- JWT path ------------------------------------------------------------
if (!$authorised) {
    $jwt = require_jwt();
    require_permission('freshdesk', $jwt);
    $authorised = true;
    $ME = array('id' => isset($jwt['user_id']) ? (int)$jwt['user_id'] : null,
                'name' => isset($jwt['name']) ? $jwt['name'] : 'Agent');
}

fd_install_error_handlers();

/* --------------------------------------------------------- repair_inline -- */
/*
 * action=repair_inline [&apply=1] [&after=<id>] [&limit=500]
 *
 * Un-hides attachments the old parser stored as inline; see
 * fd_repair_hidden_attachments(). A dry run unless apply=1, because it rewrites
 * rows across the whole table. Call again with after=<next_after> until done.
 */
if ($action === 'repair_inline') {
    require_once __DIR__ . '/lib/TicketStore.php';
    $apply = fd_bool('apply', false);
    $r = fd_repair_hidden_attachments(fd_int('after', 0), fd_int('limit', 500), !$apply);
    api_success($r, $apply ? 'Attachments repaired' : 'Dry run -- nothing changed');
}

/* ---------------------------------------------------------------- upload -- */
if ($action === 'upload') {
    $ticketId = fd_int('ticket_id', 0);
    if ($ticketId <= 0) api_error('ticket_id is required', 400);
    $ticket = fd_query_one("SELECT id FROM fd_tickets WHERE id = ?", 'i', array($ticketId));
    if (!$ticket) api_error('Ticket not found', 404);

    if (empty($_FILES) || !isset($_FILES['file'])) {
        /*
         * An empty $_FILES with a POST body almost always means the upload was
         * larger than post_max_size, which PHP discards BEFORE any of this code
         * runs -- there is no error code to read, the array is simply empty.
         * Saying "no file" there sends the agent hunting for a bug in the
         * picker instead of at the 8MB limit that actually stopped them.
         */
        $len = isset($_SERVER['CONTENT_LENGTH']) ? (int)$_SERVER['CONTENT_LENGTH'] : 0;
        $postMax = fd_bytes_from_ini(ini_get('post_max_size'));
        if ($len > 0 && $postMax > 0 && $len > $postMax) {
            api_error('That file is larger than the server accepts in one request ('
                . ini_get('post_max_size') . '). Attach a smaller file or send a link.', 413);
        }
        api_error('No file was received.', 400);
    }

    $f = $_FILES['file'];
    if ($f['error'] !== UPLOAD_ERR_OK) {
        api_error(fd_upload_error_text($f['error']), 400);
    }
    if ($f['size'] <= 0) api_error('The file is empty.', 400);
    if ($f['size'] > FD_ATTACH_MAX_FILE_BYTES) {
        api_error('File is too large. Maximum is ' . round(FD_ATTACH_MAX_FILE_BYTES / 1048576) . ' MB.', 400);
    }

    // Budget across everything already staged on this ticket.
    $sum = fd_query_one("SELECT COALESCE(SUM(size_bytes),0) AS s FROM fd_attachments WHERE ticket_id = ? AND direction = 'outbound'",
                        'i', array($ticketId));
    if ($sum && ((int)$sum['s'] + (int)$f['size']) > FD_ATTACH_MAX_TOTAL_BYTES) {
        api_error('Total attachments for this reply would exceed '
            . round(FD_ATTACH_MAX_TOTAL_BYTES / 1048576) . ' MB.', 400);
    }

    $original = MimeParser::sanitizeFilename($f['name']);
    $ext = strtolower(pathinfo($original, PATHINFO_EXTENSION));
    $allowed = array_map('trim', explode(',', (string)fd_cfg('ATTACH_ALLOWED_EXT', FD_ATTACH_ALLOWED_EXT)));
    if ($ext === '' || !in_array($ext, $allowed, true)) {
        api_error('That file type is not allowed. Permitted: ' . implode(', ', $allowed), 400);
    }

    /*
     * is_uploaded_file() before anything else: it is what proves tmp_name really
     * came from this multipart request and is not an arbitrary server path a
     * crafted POST asked us to read and then publish to S3.
     */
    if (!@is_uploaded_file($f['tmp_name'])) {
        api_error('That upload could not be verified.', 400);
    }

    // Trust the bytes, not the browser's Content-Type header -- it is
    // attacker-controlled and is what ends up as the S3 object's ContentType.
    $mime = 'application/octet-stream';
    if (function_exists('finfo_open')) {
        $fi = @finfo_open(FILEINFO_MIME_TYPE);
        if ($fi) { $detected = @finfo_file($fi, $f['tmp_name']); @finfo_close($fi); if ($detected) $mime = $detected; }
    }

    $checksum = @md5_file($f['tmp_name']);

    /*
     * Straight from PHP's upload temp file into the bucket -- the file is never
     * written into the web root at all. (fd_storage_put_file falls back to local
     * disk only when S3 is unreachable, and flags the row so Diagnostics can
     * report it.)
     */
    $put = fd_storage_put_file($ticketId, $original, $f['tmp_name'], $mime);
    if (empty($put['ok'])) {
        fd_log('error', 'Attachment upload failed: ' . $put['error'], array('name' => $original));
        api_error($put['error'], 500);
    }

    $id = fd_exec(
        "INSERT INTO fd_attachments
            (ticket_id, message_id, filename, stored_name, rel_path, storage, s3_key, s3_url,
             mime_type, size_bytes, is_inline, checksum, direction, uploaded_by)
         VALUES (?, NULL, ?,?,?,?,?,?,?,?, 0, ?, 'outbound', ?)",
        'isssssssisi',
        array($ticketId, $original, basename($put['key']), $put['rel_path'],
              $put['storage'], $put['key'], $put['url'],
              $mime, (int)$f['size'], $checksum, $ME['id']),
        true
    );

    api_success(array(
        'id'       => (int)$id,
        'name'     => $original,
        'size'     => (int)$f['size'],
        'sizeText' => fd_bytes_human2((int)$f['size']),
        'mime'     => $mime,
        'storage'  => $put['storage'],
        'url'      => fd_attachment_url((int)$id, 'download'),
        // Inline (Content-Disposition: inline) so the composer can PREVIEW a
        // freshly staged file rather than only offer to download it.
        'viewUrl'  => fd_attachment_url((int)$id, 'view'),
    ), $put['storage'] === 's3' ? 'File attached' : 'File attached (stored locally - S3 is unreachable)');
}

/* ------------------------------------------------------ download / view -- */
if ($action === 'download' || $action === 'view') {
    $id = fd_int('id', 0);
    if ($id <= 0) { http_response_code(400); echo 'Missing id'; exit; }

    $a = fd_query_one("SELECT * FROM fd_attachments WHERE id = ?", 'i', array($id));
    if (!$a) { http_response_code(404); echo 'Attachment not found'; exit; }

    $mime = $a['mime_type'] ?: 'application/octet-stream';
    $storage = isset($a['storage']) ? $a['storage'] : 'local';

    /*
     * S3-backed row: hand the browser a redirect rather than proxying 15MB
     * through PHP. The signature on THIS url is what was checked above, so the
     * access decision has already been made; the redirect just avoids paying
     * for the same bytes twice (S3 -> our server -> the browser).
     *
     * A download still goes through the proxy branch below, because a redirect
     * loses the Content-Disposition and the browser would save the file under
     * its random S3 key instead of the name the customer gave it.
     */
    if ($storage === 's3' && !empty($a['s3_url'])) {
        if ($action === 'view') {
            header('Location: ' . $a['s3_url'], true, 302);
            header('Cache-Control: private, max-age=300');
            exit;
        }
        $bytes = fd_storage_get_bytes($a);
        if ($bytes === null) {
            fd_log('warn', 'S3 object unreadable', array('id' => $id, 'key' => $a['s3_key']));
            http_response_code(404);
            echo 'The stored file could not be retrieved.';
            exit;
        }
        while (ob_get_level() > 0) { ob_end_clean(); }
        header_remove('Content-Type');
        header('Content-Type: ' . $mime);
        header('Content-Length: ' . strlen($bytes));
        header('Content-Disposition: attachment; filename="' . str_replace('"', '', $a['filename']) . '"'
            . "; filename*=UTF-8''" . rawurlencode($a['filename']));
        header('X-Content-Type-Options: nosniff');
        header('Cache-Control: private, max-age=600');
        header_remove('Pragma');
        header_remove('Expires');
        echo $bytes;
        exit;
    }

    // Local fallback rows (written while S3 was unreachable) still stream from disk.
    $path = FD_ATTACH_DIR . '/' . $a['rel_path'];
    // realpath + prefix check: rel_path comes from our own INSERT, but this is
    // the one place a stored value turns into a filesystem read, so it is
    // verified rather than trusted.
    $real = @realpath($path);
    $base = @realpath(FD_ATTACH_DIR);
    if (!$real || !$base || strpos($real, $base) !== 0 || !is_file($real)) {
        fd_log('warn', 'Attachment missing on disk', array('id' => $id, 'path' => $path));
        http_response_code(404);
        echo 'The file is no longer on the server.';
        exit;
    }

    $inlineOk = $action === 'view' && (
        strpos($mime, 'image/') === 0 || $mime === 'application/pdf' || strpos($mime, 'text/plain') === 0
    );
    // SVG is an image that can carry script. Never render it inline in the
    // panel's origin; it downloads instead.
    if (stripos($mime, 'svg') !== false) $inlineOk = false;

    // Buffered output from an earlier include would corrupt a binary body.
    while (ob_get_level() > 0) { ob_end_clean(); }

    header_remove('Content-Type');
    header('Content-Type: ' . $mime);
    header('Content-Length: ' . filesize($real));
    header('Content-Disposition: ' . ($inlineOk ? 'inline' : 'attachment')
        . '; filename="' . str_replace('"', '', $a['filename']) . '"'
        . "; filename*=UTF-8''" . rawurlencode($a['filename']));
    header('X-Content-Type-Options: nosniff');
    // A stray HTML/JS attachment must not be able to script the panel's origin.
    header("Content-Security-Policy: default-src 'none'; img-src 'self' data:; style-src 'unsafe-inline'; sandbox");
    // Signed URLs already carry an expiry; a short private cache keeps a thread
    // full of inline images from re-fetching every one on each scroll.
    header('Cache-Control: private, max-age=600');
    header_remove('Pragma');
    header_remove('Expires');

    $fp = @fopen($real, 'rb');
    if (!$fp) { http_response_code(500); echo 'Could not read the file.'; exit; }
    // Streamed, not file_get_contents: a 15MB attachment would otherwise have to
    // fit inside PHP's memory_limit all at once.
    while (!feof($fp)) {
        $chunk = fread($fp, 65536);
        if ($chunk === false) break;
        echo $chunk;
        @flush();
    }
    fclose($fp);
    exit;
}

/* ---------------------------------------------------------------- delete -- */
if ($action === 'delete') {
    $id = fd_int('id', 0);
    $a = fd_query_one("SELECT * FROM fd_attachments WHERE id = ?", 'i', array($id));
    if (!$a) api_error('Attachment not found', 404);
    // Only files still staged for an unsent reply. Anything already attached to
    // a delivered message is part of the record.
    if ($a['message_id'] !== null) api_error('That file has already been sent and cannot be removed.', 400);

    fd_storage_delete($a);
    fd_exec("DELETE FROM fd_attachments WHERE id = ?", 'i', array($id));
    api_success(array('deleted' => true), 'Attachment removed');
}

/* ------------------------------------------------------------------ list -- */
if ($action === 'list') {
    $ticketId = fd_int('ticket_id', 0);
    if ($ticketId <= 0) api_error('ticket_id is required', 400);
    $rows = fd_query("SELECT id, message_id, filename, mime_type, size_bytes, is_inline, direction, created_at
                      FROM fd_attachments WHERE ticket_id = ? ORDER BY id DESC", 'i', array($ticketId));
    $out = array();
    foreach ($rows as $r) {
        $out[] = array(
            'id' => (int)$r['id'], 'name' => $r['filename'], 'mime' => $r['mime_type'],
            'size' => (int)$r['size_bytes'], 'sizeText' => fd_bytes_human2((int)$r['size_bytes']),
            'inline' => (bool)$r['is_inline'], 'staged' => $r['message_id'] === null,
            'url' => fd_attachment_url((int)$r['id'], 'download'),
            'viewUrl' => fd_attachment_url((int)$r['id'], 'view'),
            'at' => fd_relative_time($r['created_at']),
        );
    }
    api_success(array('attachments' => $out), 'OK');
}

api_error('Unknown action: ' . $action, 400);

/* ================================================================ helpers == */

function fd_bytes_human2($b)
{
    if ($b < 1024) return $b . ' B';
    if ($b < 1048576) return round($b / 1024, 1) . ' KB';
    if ($b < 1073741824) return round($b / 1048576, 1) . ' MB';
    return round($b / 1073741824, 2) . ' GB';
}

function fd_bytes_from_ini($val)
{
    $val = trim((string)$val);
    if ($val === '') return 0;
    $unit = strtolower(substr($val, -1));
    $num = (int)$val;
    if ($unit === 'g') return $num * 1073741824;
    if ($unit === 'm') return $num * 1048576;
    if ($unit === 'k') return $num * 1024;
    return $num;
}

function fd_upload_error_text($code)
{
    switch ($code) {
        case UPLOAD_ERR_INI_SIZE:   return 'The file is larger than the server allows (upload_max_filesize = ' . ini_get('upload_max_filesize') . ').';
        case UPLOAD_ERR_FORM_SIZE:  return 'The file is larger than the form allows.';
        case UPLOAD_ERR_PARTIAL:    return 'The upload was interrupted. Try again.';
        case UPLOAD_ERR_NO_FILE:    return 'No file was selected.';
        case UPLOAD_ERR_NO_TMP_DIR: return 'The server has no temp folder configured for uploads. Contact the host.';
        case UPLOAD_ERR_CANT_WRITE: return 'The server could not write the file to disk (permissions or disk full).';
        case UPLOAD_ERR_EXTENSION:  return 'A PHP extension blocked this upload.';
        default:                    return 'Upload failed (code ' . $code . ').';
    }
}

<?php
/*
 * Mailer — builds the exact RFC822 message that is handed to KumoMTA.
 *
 * Everything a bulk sender is judged on is assembled here: DKIM-signable
 * headers, a real Message-ID, List-Unsubscribe + one-click POST, Feedback-ID,
 * the X-Tenant header that tells KumoMTA WHICH IP to send from, tracking
 * rewrites and a plain-text alternative.
 */

require_once __DIR__ . '/schema.php';

/* ── Signed links ──────────────────────────────────────────────────────────── */

function kumo_sign(string $payload): string {
    return rtrim(strtr(base64_encode(hash_hmac('sha256', $payload, KUMO_LINK_SECRET, true)), '+/', '-_'), '=');
}

/** token = base64url(payload) . '.' . sig  — payload is "rid|campaignId|kind|extra" */
function kumo_token(string $rid, int $campaignId, string $kind, string $extra = ''): string {
    $payload = $rid . '|' . $campaignId . '|' . $kind . '|' . $extra;
    $b64     = rtrim(strtr(base64_encode($payload), '+/', '-_'), '=');
    return $b64 . '.' . kumo_sign($payload);
}

function kumo_token_verify(string $token): ?array {
    $parts = explode('.', $token, 2);
    if (count($parts) !== 2) return null;
    $payload = base64_decode(strtr($parts[0], '-_', '+/'));
    if ($payload === false) return null;
    if (!hash_equals(kumo_sign($payload), $parts[1])) return null;
    $bits = explode('|', $payload, 4);
    if (count($bits) < 3) return null;
    return ['rid' => $bits[0], 'campaign_id' => (int)$bits[1], 'kind' => $bits[2], 'extra' => $bits[3] ?? ''];
}

/* ── Content ───────────────────────────────────────────────────────────────── */

/**
 * Replaces {{first_name}} / XX_FIRST_NAME_XX style tokens, plus the [NAME]
 * attribute tokens the Attributes screen creates.
 *
 * $attrTokens is what AttributeResolver returned for THIS recipient —
 * ['[COURSE]' => 'Data Science', …] — already keyed with the brackets, so the
 * substitution is a plain replace. An attribute with no value for this person
 * resolves to its default (or an empty string), never to the raw token: a
 * literal "[COURSE]" reaching an inbox looks broken.
 */
function kumo_merge(string $html, array $rcpt, array $attrTokens = []): string {
    $first = trim((string)($rcpt['first_name'] ?? ''));
    $last  = trim((string)($rcpt['last_name'] ?? ''));
    $email = (string)($rcpt['email'] ?? '');
    $map = [
        'first_name' => $first !== '' ? $first : 'there',
        'last_name'  => $last,
        'full_name'  => trim($first . ' ' . $last),
        'email'      => $email,
    ];
    foreach ($map as $k => $v) {
        $html = str_ireplace(['{{' . $k . '}}', '{{ ' . $k . ' }}', 'XX_' . strtoupper($k) . '_XX'], $v, $html);
    }
    if ($attrTokens) {
        $html = str_replace(array_keys($attrTokens), array_values($attrTokens), $html);
    }
    return $html;
}

/** Adds the open pixel and rewrites links through the click tracker. */
function kumo_inject_tracking(string $html, string $rid, int $campaignId, bool $opens, bool $clicks): string {
    $base = rtrim((string)kumo_setting('public_base_url', KUMO_PUBLIC_BASE_URL), '/');

    if ($clicks) {
        $html = preg_replace_callback('/href\s*=\s*"(https?:\/\/[^"]+)"/i', function ($m) use ($base, $rid, $campaignId) {
            $url = $m[1];
            // Never rewrite our own unsubscribe/tracking links.
            if (stripos($url, '/track-') !== false || stripos($url, '/unsubscribe.php') !== false) return $m[0];
            $tok = kumo_token($rid, $campaignId, 'c', substr(md5($url), 0, 8));
            return 'href="' . $base . '/track-click.php?t=' . rawurlencode($tok) . '&u=' . rawurlencode($url) . '"';
        }, $html) ?: $html;
    }

    if ($opens) {
        $tok   = kumo_token($rid, $campaignId, 'o');
        $pixel = '<img src="' . $base . '/track-open.php?t=' . rawurlencode($tok) . '" width="1" height="1" alt="" style="display:block;width:1px;height:1px;border:0" />';
        $html  = (stripos($html, '</body>') !== false)
               ? preg_replace('/<\/body>/i', $pixel . '</body>', $html, 1)
               : $html . $pixel;
    }
    return $html;
}

/** Very small HTML→text fallback for the plain-text alternative. */
function kumo_html_to_text(string $html): string {
    $t = preg_replace('/<(script|style)\b[^>]*>.*?<\/\1>/is', '', $html);
    $t = preg_replace('/<br\s*\/?>/i', "\n", (string)$t);
    $t = preg_replace('/<\/(p|div|tr|h[1-6])>/i', "\n\n", (string)$t);
    $t = strip_tags((string)$t);
    $t = html_entity_decode((string)$t, ENT_QUOTES | ENT_HTML5, 'UTF-8');
    $t = preg_replace("/[ \t]+/", ' ', (string)$t);
    $t = preg_replace("/\n{3,}/", "\n\n", (string)$t);
    return trim((string)$t);
}

/* ── Message assembly ──────────────────────────────────────────────────────── */

function kumo_encode_header(string $value): string {
    return preg_match('/[\x80-\xFF]/', $value)
        ? '=?UTF-8?B?' . base64_encode($value) . '?='
        : $value;
}

/**
 * A display name safe to put before <address>.
 *
 * RFC 5322 lets an unquoted display name hold only atoms: the moment it contains
 * a special — , ; : < > @ [ ] " \ or a dot — the header stops parsing there. A
 * sender name carrying an attribute is full of them ("Internship Studio
 * [RESULT_DATE]" becomes "Internship Studio 13 Jul, 2026"), and KumoMTA answers
 * such a message with "552 DKIM signing requires a From header, but it is
 * missing" — it could not read the header at all.
 *
 * Non-ASCII goes through MIME base64, which needs no quoting; anything else with
 * a special is quoted, with embedded quotes and backslashes escaped. Any CR/LF is
 * stripped first: a newline in a header value would end the header block early
 * and let the rest be read as body, or worse, as injected headers.
 */
function kumo_display_name(string $name): string {
    $name = trim(preg_replace('/[\r\n]+/', ' ', $name) ?? '');
    if ($name === '') return '';
    if (preg_match('/[\x80-\xFF]/', $name)) return kumo_encode_header($name);
    if (preg_match('/[()<>@,;:\\".\[\]]/', $name)) {
        return '"' . str_replace(['\\', '"'], ['\\\\', '\\"'], $name) . '"';
    }
    return $name;
}

/**
 * Builds the full message for one recipient.
 *
 * @return array{content:string, envelope_sender:string}
 */
function kumo_build_message(array $campaign, array $rcpt, array $ipRow, array $attachments = []): array {
    $base         = rtrim((string)kumo_setting('public_base_url', KUMO_PUBLIC_BASE_URL), '/');
    $bounceDomain = (string)kumo_setting('bounce_domain', 'bounce.nitrocampus.com');
    $fromName     = (string)($campaign['from_name']  ?: kumo_setting('from_name', 'Internship Studio'));
    $fromEmail    = (string)($campaign['from_email'] ?: kumo_setting('from_email', 'hello@mail.nitrocampus.com'));
    $replyTo      = (string)($campaign['reply_to']   ?: kumo_setting('reply_to', ''));
    $rid          = (string)$rcpt['rid'];
    $cid          = (int)$campaign['id'];

    /* Put there by kumo_send_batch(), resolved once for the whole batch. */
    $attrTokens = is_array($rcpt['attr_tokens'] ?? null) ? $rcpt['attr_tokens'] : [];

    /* The sender name takes attributes as well — it is offered in the picker,
       so it has to be merged like every other personalisable field. */
    $fromName = kumo_merge($fromName, $rcpt, $attrTokens);

    $subject = kumo_merge((string)($campaign['subject'] ?? ''), $rcpt, $attrTokens);
    $html    = kumo_merge((string)($campaign['body_html'] ?? ''), $rcpt, $attrTokens);

    $unsubToken = kumo_token($rid, $cid, 'u');
    $unsubUrl   = $base . '/unsubscribe.php?t=' . rawurlencode($unsubToken);

    /* A visible unsubscribe link is required as well as the header, so add a
       footer when the template does not already contain one. */
    if (stripos($html, 'unsubscribe') === false) {
        $html .= '<div style="margin-top:28px;padding-top:14px;border-top:1px solid #e5e7eb;font:12px/1.6 Arial,sans-serif;color:#6b7280">'
               . 'You are receiving this because you signed up with Internship Studio.<br>'
               . '<a href="' . htmlspecialchars($unsubUrl, ENT_QUOTES) . '" style="color:#6b7280">Unsubscribe</a>'
               . '</div>';
    } else {
        $html = str_ireplace(['{{unsubscribe_url}}', 'XX_UNSUBSCRIBE_XX'], htmlspecialchars($unsubUrl, ENT_QUOTES), $html);
    }

    $html = kumo_inject_tracking($html, $rid, $cid, (int)($campaign['track_opens'] ?? 1) === 1, (int)($campaign['track_clicks'] ?? 1) === 1);
    $text = trim((string)($campaign['body_text'] ?? '')) !== ''
          ? kumo_merge((string)$campaign['body_text'], $rcpt, $attrTokens)
          : kumo_html_to_text($html);
    $text .= "\n\n---\nUnsubscribe: " . $unsubUrl . "\n";

    $envelopeSender = 'b-' . $rid . '@' . $bounceDomain;
    $boundary       = 'kumo_' . bin2hex(random_bytes(12));
    $msgIdDomain    = substr(strrchr($fromEmail, '@') ?: '@mail.nitrocampus.com', 1);

    $headers = [
        'From: ' . kumo_display_name($fromName) . ' <' . $fromEmail . '>',
        'To: ' . $rcpt['email'],
        'Subject: ' . kumo_encode_header($subject),
        'Message-ID: <' . $rid . '@' . $msgIdDomain . '>',
        'Date: ' . date('r'),
        'MIME-Version: 1.0',
        'X-Tenant: ' . ($ipRow['tenant'] ?? 'ip1'),            // KumoMTA maps this to the egress pool
        'X-Campaign-ID: ' . $cid,
        'X-Message-Ref: ' . $rid,
        'Feedback-ID: ' . $cid . ':kumo:istudio:' . ($ipRow['tenant'] ?? 'ip1'),
        'List-Unsubscribe: <' . $unsubUrl . '>, <mailto:unsubscribe@' . $bounceDomain . '?subject=' . $rid . '>',
        'List-Unsubscribe-Post: List-Unsubscribe=One-Click',
        'Precedence: bulk',
        'Auto-Submitted: auto-generated',
    ];
    if ($replyTo !== '') $headers[] = 'Reply-To: ' . $replyTo;
    if (!empty($campaign['preheader'])) {
        // Hidden preheader text, prepended into the body (not a header).
        $pre = htmlspecialchars(kumo_merge((string)$campaign['preheader'], $rcpt, $attrTokens), ENT_QUOTES);
        $html = '<div style="display:none;max-height:0;overflow:hidden;opacity:0">' . $pre . '</div>' . $html;
    }

    $alt = "--$boundary\r\n"
        . "Content-Type: text/plain; charset=UTF-8\r\n"
        . "Content-Transfer-Encoding: quoted-printable\r\n\r\n"
        . quoted_printable_encode($text) . "\r\n"
        . "--$boundary\r\n"
        . "Content-Type: text/html; charset=UTF-8\r\n"
        . "Content-Transfer-Encoding: quoted-printable\r\n\r\n"
        . quoted_printable_encode($html) . "\r\n"
        . "--$boundary--\r\n";

    if ($attachments) {
        /* multipart/mixed { multipart/alternative { text, html }, file… } — the
           shape every client understands; a flat mixed part would make some of
           them show the HTML as a downloadable file instead of rendering it. */
        $mixed = 'kumo_mix_' . bin2hex(random_bytes(12));
        $headers[] = 'Content-Type: multipart/mixed; boundary="' . $mixed . '"';

        $body = "--$mixed\r\n"
              . 'Content-Type: multipart/alternative; boundary="' . $boundary . '"' . "\r\n\r\n"
              . $alt;
        foreach ($attachments as $a) {
            $name = str_replace('"', '', (string)($a['filename'] ?? 'attachment'));
            $body .= "--$mixed\r\n"
                   . 'Content-Type: ' . ($a['type'] ?? 'application/octet-stream') . '; name="' . $name . '"' . "\r\n"
                   . "Content-Transfer-Encoding: base64\r\n"
                   . 'Content-Disposition: attachment; filename="' . $name . '"' . "\r\n\r\n"
                   . chunk_split((string)($a['content'] ?? ''), 76, "\r\n")
                   . "\r\n";
        }
        $body .= "--$mixed--\r\n";
    } else {
        $headers[] = 'Content-Type: multipart/alternative; boundary="' . $boundary . '"';
        $body = $alt;
    }

    return [
        'content'         => implode("\r\n", $headers) . "\r\n\r\n" . $body,
        'envelope_sender' => $envelopeSender,
    ];
}

<?php
/**
 * /api/students/ad_visits.php — which ads a student came through (see api/lib/AdJourney.php).
 *
 * GET ?action=counts&user_ids=1,2,3   → { counts: { "1": {total, device, ip, before_register}, ... } }
 *                                        for one page of the All Students table (max 100 ids)
 * GET ?action=user&user_id=123        → the full journey for the drawer
 * GET ?action=filter&from=Y-m-d&to=Y-m-d&min=2&source=&match=any|device&timing=any|before|after
 *                    &sort=visits|recent|first_visit&page=1&per_page=20
 *                                     → students registered in range with at least `min` matching visits
 */
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../middleware/auth.php';
require_once __DIR__ . '/../lib/AdJourney.php';

require_method('GET');
$jwt = require_jwt();
require_permission('all_students', $jwt);

$action = $_GET['action'] ?? 'counts';

try {
    if ($action === 'counts') {
        $ids = array_slice(array_filter(array_map('intval', explode(',', (string) ($_GET['user_ids'] ?? '')))), 0, 100);
        if (!$ids) api_success(['counts' => (object) []]);
        api_success(['counts' => (object) ad_journey_counts($conn, $ids)]);
    }

    if ($action === 'user') {
        $userId = (int) ($_GET['user_id'] ?? 0);
        if ($userId <= 0) api_error('Missing user_id', 400);
        $journey = ad_journey_detail($conn, $userId);
        if (!$journey) api_error('Student not found', 404);
        api_success($journey);
    }

    if ($action === 'filter') {
        $date = fn($k) => preg_match('/^\d{4}-\d{2}-\d{2}$/', $_GET[$k] ?? '') ? $_GET[$k] : date('Y-m-d');
        $from = $date('from');
        $to   = $date('to');
        if ($from > $to) [$from, $to] = [$to, $from];
        if ((strtotime($to) - strtotime($from)) / 86400 > 31) api_error('Pick a range of 31 days or less', 400);

        $pick = fn($k, $allowed) => in_array($_GET[$k] ?? '', $allowed, true) ? $_GET[$k] : $allowed[0];
        $opts = [
            'from'   => $from,
            'to'     => $to,
            'min'    => max(1, min(100, (int) ($_GET['min'] ?? 1))),
            'source' => substr(strtolower(trim((string) ($_GET['source'] ?? ''))), 0, 64),
            'match'  => $pick('match', ['any', 'device']),
            'timing' => $pick('timing', ['any', 'before', 'after']),
            'sort'   => $pick('sort', ['visits', 'recent', 'first_visit']),
        ];

        // The whole filtered set is built once and paged from cache, so page 2 is instant.
        require_once __DIR__ . '/../../config/cache.php';
        $key = 'ad_filter_' . md5(json_encode($opts));
        $res = cache_get($key);
        if (!$res) {
            $res = ad_journey_filter($conn, $opts);
            cache_set($key, $res, 60);
        }

        [$page, $per_page, $offset] = get_pagination();
        api_success([
            'filters'           => $opts,
            'summary'           => $res['summary'],
            'available_sources' => (object) $res['available_sources'],
            'total'             => count($res['students']),
            'page'              => $page,
            'per_page'          => $per_page,
            'students'          => array_slice($res['students'], $offset, $per_page),
        ]);
    }

    api_error('Unknown action', 400);
} catch (Throwable $e) {
    error_log('[ad_visits] ' . $e->getMessage());
    api_error('Could not load ad visits', 500);
}

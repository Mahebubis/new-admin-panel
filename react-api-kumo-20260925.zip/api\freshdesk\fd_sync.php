<?php
/*
 * /api/freshdesk/fd_sync.php
 *
 * The inbound mail worker. Connects to contact@internshipstudio.com over IMAP,
 * pulls anything newer than the stored watermark, and turns each message into a
 * ticket + conversation entry + attachments, then publishes a realtime event so
 * open panels update without a refresh.
 *
 * Three ways to run it, all landing in the same code:
 *
 *   CLI (cron -- the normal way, every minute):
 *     * * * * * /usr/local/bin/php /home/istudio/public_html/cit3/admin/react-api/api/freshdesk/fd_sync.php
 *
 *   HTTP with the shared secret (for uptime pingers / external schedulers):
 *     GET fd_sync.php?secret=<FD_CRON_SECRET>
 *
 *   HTTP with a JWT (the panel's "Refresh" button and its background poll):
 *     GET fd_sync.php?action=sync   (Authorization: Bearer ...)
 *
 * SAFETY PROPERTIES, none of which are optional:
 *   - A DB-level lock stops the cron tick and an agent's Refresh from importing
 *     the same UID range twice.
 *   - The watermark is only advanced past a UID that was actually stored, so a
 *     crash mid-batch re-reads rather than skips. Re-reading is free (the
 *     unique Message-ID index makes it a no-op); skipping loses a customer's
 *     email forever.
 *   - UIDVALIDITY is checked every run. When the server changes it, every
 *     stored UID is meaningless and the worker re-baselines instead of trusting
 *     numbers that now point at different messages.
 *   - A wall-clock budget stops the run cleanly with its progress committed,
 *     instead of being killed by max_execution_time holding the lock.
 */

// $FD_IS_CLI = (php_sapi_name() === 'cli');

// if ($FD_IS_CLI) {
//     // A cron run has no web-server context; give it the paths the endpoints get
//     // from Apache, and never emit CORS/JSON headers into a terminal.
//     $_SERVER['REQUEST_METHOD'] = 'GET';
//     $_SERVER['HTTP_HOST'] = 'cit3.internshipstudio.com';
//     set_time_limit(0);
// }

// require_once __DIR__ . '/../../config/database.php';
// require_once __DIR__ . '/lib/config.php';
// require_once __DIR__ . '/lib/Helpers.php';
// require_once __DIR__ . '/lib/schema.php';
// require_once __DIR__ . '/lib/Sla.php';
// require_once __DIR__ . '/lib/Automation.php';
// require_once __DIR__ . '/lib/Pusher.php';
// require_once __DIR__ . '/lib/ImapClient.php';
// require_once __DIR__ . '/lib/MimeParser.php';
// require_once __DIR__ . '/lib/Storage.php';
// require_once __DIR__ . '/lib/TicketStore.php';
// require_once __DIR__ . '/lib/Mailer.php';

// fd_install_error_handlers();
// fd_ensure_schema();

// /* ------------------------------------------------------------ authorise --- */

// $authorised = false;
// $actor = array('id' => null, 'name' => 'cron');

// if ($FD_IS_CLI) {
//     $authorised = true;
// } else {
//     $secret = fd_str('secret', '');
//     if ($secret !== '' && hash_equals((string)fd_cfg('CRON_SECRET', FD_CRON_SECRET), $secret)) {
//         $authorised = true;
//     } else {
//         // Fall back to the normal panel auth so the Refresh button works.
//         require_once __DIR__ . '/../../middleware/auth.php';
//         $jwt = require_jwt();
//         require_permission('freshdesk', $jwt);
//         $authorised = true;
//         $actor = array('id' => isset($jwt['user_id']) ? (int)$jwt['user_id'] : null,
//                        'name' => isset($jwt['name']) ? $jwt['name'] : 'Agent');
//     }
// }
// if (!$authorised) {
//     http_response_code(403);
//     echo json_encode(array('success' => false, 'message' => 'Not authorised'));
//     exit;
// }

// /* ------------------------------------------------------------- locking --- */

// /**
//  * Claim the mailbox for this run.
//  *
//  * The UPDATE ... WHERE lock is stale-or-free is a single atomic statement, so
//  * two workers starting in the same millisecond cannot both win: MySQL serialises
//  * the row update and exactly one sees affected_rows = 1.
//  *
//  * The 5-minute staleness window is the crash recovery: a worker killed by the
//  * host (OOM, deploy, max_execution_time) leaves its lock behind, and without
//  * this the desk would stop receiving mail permanently and silently.
//  */
// function fd_acquire_lock($mailbox, $token)
// {
//     fd_exec("INSERT IGNORE INTO fd_mailbox_state (mailbox, last_uid, last_status) VALUES (?, 0, 'idle')",
//             's', array($mailbox));
//     $n = fd_exec(
//         "UPDATE fd_mailbox_state
//          SET lock_token = ?, lock_at = NOW(), last_status = 'running', last_sync_at = NOW()
//          WHERE mailbox = ?
//            AND (lock_token IS NULL OR lock_at IS NULL OR lock_at < DATE_SUB(NOW(), INTERVAL 5 MINUTE))",
//         'ss', array($token, $mailbox)
//     );
//     return $n > 0;
// }

// function fd_release_lock($mailbox, $token, $status, $error = null)
// {
//     fd_exec(
//         "UPDATE fd_mailbox_state
//          SET lock_token = NULL, lock_at = NULL, last_status = ?, last_error = ?,
//              last_success_at = CASE WHEN ? = 'ok' THEN NOW() ELSE last_success_at END,
//              consecutive_fails = CASE WHEN ? = 'ok' THEN 0 ELSE consecutive_fails + 1 END
//          WHERE mailbox = ? AND (lock_token = ? OR lock_token IS NULL)",
//         'ssssss', array($status, $error, $status, $status, $mailbox, $token)
//     );
// }

// /* ---------------------------------------------------------------- run ---- */

// function fd_run_sync($actor)
// {
//     $started  = microtime(true);
//     $mailbox  = (string)fd_cfg('IMAP_FOLDER', 'INBOX');
//     $token    = bin2hex(random_bytes(8));
//     $budget   = fd_cfg_int('SYNC_MAX_SECONDS', 50);
//     $batch    = max(1, fd_cfg_int('SYNC_BATCH', 40));

//     $result = array(
//         'ok' => false, 'mailbox' => $mailbox, 'scanned' => 0, 'imported' => 0,
//         'duplicates' => 0, 'new_tickets' => 0, 'errors' => 0, 'skipped' => 0,
//         'ignored' => 0, 'ignored_reasons' => array(),
//         'remaining' => 0, 'cursor' => 0, 'took_ms' => 0, 'message' => '',
//         'new_ticket_ids' => array(), 'touched_ticket_ids' => array(),
//     );

//     if (!fd_acquire_lock($mailbox, $token)) {
//         // Not a failure: another run holds it and is doing the work.
//         $result['ok'] = true;
//         $result['message'] = 'Another sync is already running; skipped this tick.';
//         $result['locked'] = true;
//         return $result;
//     }

//     $imap = null;
//     try {
//         $state = fd_query_one("SELECT * FROM fd_mailbox_state WHERE mailbox = ?", 's', array($mailbox));
//         $lastUid     = $state ? (int)$state['last_uid'] : 0;
//         $knownValidity = $state ? (int)$state['uidvalidity'] : 0;

//         $imap = new ImapClient();
//         $imap->login();
//         $info = $imap->selectFolder($mailbox, true);   // read-only: never touch \Seen
//         $validity = (int)$info['uidvalidity'];

//         $rebaselined = false;
//         if ($knownValidity && $validity && $validity !== $knownValidity) {
//             /*
//              * UIDVALIDITY changed -- the mailbox was rebuilt/restored and every
//              * UID now refers to a different message. Continuing with the old
//              * watermark would either skip everything or re-import the whole
//              * mailbox as new. Re-baseline against the recent window instead and
//              * let the Message-ID unique index absorb whatever we already have.
//              */
//             fd_log('warn', 'UIDVALIDITY changed -- re-baselining', array(
//                 'mailbox' => $mailbox, 'was' => $knownValidity, 'now' => $validity));
//             $lastUid = 0;
//             $rebaselined = true;
//         }

//         if ($lastUid === 0) {
//             // First ever run (or a re-baseline): import only the recent window,
//             // never the entire history of a mailbox that may hold 40k messages.
//             $days = max(1, fd_cfg_int('SYNC_INITIAL_DAYS', 7));
//             $uids = $imap->searchSinceDays($days);
//             fd_log('info', 'Baseline sync', array('mailbox' => $mailbox, 'days' => $days, 'found' => count($uids)));
//         } else {
//             $uids = $imap->searchSinceUid($lastUid);
//         }

//         $result['remaining'] = max(0, count($uids) - $batch);
//         $uids = array_slice($uids, 0, $batch);
//         $result['scanned'] = count($uids);

//         $highestDone = $lastUid;
//         $newTicketIds = array();
//         $touched = array();

//         foreach ($uids as $uid) {
//             if ((microtime(true) - $started) > $budget) {
//                 fd_log('info', 'Sync budget reached, stopping cleanly', array('done_upto_uid' => $highestDone));
//                 $result['message'] = 'Time budget reached; the rest will be picked up on the next run.';
//                 $result['remaining'] += 1;
//                 break;
//             }

//             try {
//                 $fetched = $imap->fetchMessages(array($uid));
//                 if (empty($fetched[$uid])) { $result['skipped']++; $highestDone = max($highestDone, (int)$uid); continue; }

//                 $raw = $fetched[$uid]['raw'];
//                 $parsed = MimeParser::parse($raw);

//                 $stored = fd_store_inbound($parsed, array(
//                     'mailbox'     => $mailbox,
//                     'uid'         => (int)$uid,
//                     'uidvalidity' => $validity,
//                     'size'        => $fetched[$uid]['size'],
//                 ));

//                 if (!empty($stored['skipped'])) {
//                     // Orphan bounces / auto-responders: machine mail referring
//                     // to a conversation this desk never had. Counted so the
//                     // number is visible rather than silently vanishing.
//                     $result['ignored']++;
//                     $result['ignored_reasons'][$stored['skipped']] =
//                         (isset($result['ignored_reasons'][$stored['skipped']]) ? $result['ignored_reasons'][$stored['skipped']] : 0) + 1;
//                 } elseif (!empty($stored['duplicate'])) {
//                     $result['duplicates']++;
//                 } else {
//                     $result['imported']++;
//                     $tid = (int)$stored['ticket_id'];
//                     $touched[$tid] = true;

//                     if (!empty($stored['is_new_ticket'])) {
//                         $result['new_tickets']++;
//                         $newTicketIds[] = $tid;
//                     }
//                     fd_publish_inbound($tid, (int)$stored['message_id'], !empty($stored['is_new_ticket']), $parsed);

//                     /*
//                      * Rules run BEFORE the auto-acknowledgement, so a rule that
//                      * closes a ticket as spam does not also send the customer a
//                      * "we have received your query" first.
//                      */
//                     fd_automation_run(
//                         !empty($stored['is_new_ticket']) ? 'ticket_created' : 'ticket_updated',
//                         $tid, (int)$stored['message_id']);

//                     // Re-read: a rule may have just closed or reassigned it.
//                     $after = fd_query_one("SELECT status FROM fd_tickets WHERE id = ?", 'i', array($tid));
//                     $stillOpen = $after && !in_array($after['status'], array('Closed', 'Resolved'), true);

//                     if (!empty($stored['is_new_ticket']) && $stillOpen) {
//                         fd_send_auto_ack($tid, $parsed);
//                     }
//                 }

//                 // Only now is it safe to move the watermark past this UID.
//                 $highestDone = max($highestDone, (int)$uid);

//             } catch (FdImapException $e) {
//                 // A protocol/connection failure ends the run -- carrying on would
//                 // just produce a stream of identical errors.
//                 throw $e;
//             } catch (Throwable $e) {
//                 /*
//                  * One malformed message must not wedge the mailbox forever. Log
//                  * it loudly, count it, and step past it -- if the watermark
//                  * never advanced, this same message would be retried on every
//                  * tick and nothing behind it would ever arrive.
//                  */
//                 $result['errors']++;
//                 $highestDone = max($highestDone, (int)$uid);
//                 fd_log('error', 'Failed to import UID ' . $uid . ': ' . $e->getMessage(), array('mailbox' => $mailbox));
//             }
//         }

//         if ($highestDone > $lastUid || $rebaselined || !$knownValidity) {
//             fd_exec(
//                 "UPDATE fd_mailbox_state
//                  SET last_uid = GREATEST(last_uid, ?), uidvalidity = ?, imported_total = imported_total + ?
//                  WHERE mailbox = ?",
//                 'iiis', array($highestDone, $validity, $result['imported'], $mailbox)
//             );
//         }

//         /*
//          * The Sent folder, on the same connection.
//          *
//          * Answers given from the real Freshdesk (or from webmail) never touch
//          * this panel's Mailer, so without this pass the conversation showed the
//          * customer's question with nothing under it. Reading Sent is how those
//          * replies become part of the thread.
//          *
//          * Runs inside the same lock and the same time budget: it is a second
//          * folder, not a second sync.
//          */
//         $sent = fd_sync_sent_folder($imap, $started, $budget);
//         $result['sent'] = $sent;
//         foreach ($sent['touched_ticket_ids'] as $tid) $touched[$tid] = true;

//         $imap->close();
//         $imap = null;

//         // Clocks must tick even when nobody has the page open.
//         fd_sla_sweep(300);

//         // ...and stale tickets close themselves, if that is switched on.
//         $result['auto_closed'] = fd_auto_close_stale();

//         $result['ok'] = true;
//         $result['new_ticket_ids']     = $newTicketIds;
//         $result['touched_ticket_ids'] = array_keys($touched);
//         if ($result['message'] === '') {
//             $bits = array();
//             if ($result['imported'] > 0) {
//                 $bits[] = $result['imported'] . ' new message' . ($result['imported'] === 1 ? '' : 's');
//             }
//             if (!empty($result['sent']['imported'])) {
//                 $bits[] = $result['sent']['imported'] . ' reply sent elsewhere'
//                         . ($result['sent']['imported'] === 1 ? '' : 'ies');
//             }
//             $result['message'] = empty($bits) ? 'Mailbox is up to date' : (implode(' and ', $bits) . ' imported');
//         }
//         fd_release_lock($mailbox, $token, 'ok', null);

//     } catch (Throwable $e) {
//         if ($imap) { try { $imap->close(); } catch (Throwable $e2) {} }
//         $msg = $e->getMessage();
//         $result['ok'] = false;
//         $result['message'] = $msg;
//         fd_log('error', 'Sync run failed: ' . $msg, array('mailbox' => $mailbox));
//         fd_release_lock($mailbox, $token, 'error', substr($msg, 0, 900));

//         /*
//          * Tell the panel when the mailbox has been unreachable repeatedly. A
//          * desk that quietly stops receiving mail is the worst failure mode
//          * this system has -- it looks exactly like "a quiet day".
//          */
//         $st = fd_query_one("SELECT consecutive_fails FROM fd_mailbox_state WHERE mailbox = ?", 's', array($mailbox));
//         if ($st && (int)$st['consecutive_fails'] >= 3) {
//             fd_emit('mailbox-down', array(
//                 'mailbox' => $mailbox,
//                 'fails'   => (int)$st['consecutive_fails'],
//                 'error'   => fd_snippet($msg, 200),
//             ), array('summary' => 'Mailbox unreachable: ' . fd_snippet($msg, 120)));
//         }
//     }

//     $result['took_ms'] = (int)round((microtime(true) - $started) * 1000);
//     $cur = fd_query_one("SELECT MAX(id) AS c FROM fd_activity");
//     $result['cursor'] = $cur ? (int)$cur['c'] : 0;
//     return $result;
// }

// /**
//  * Import replies from the mailbox's Sent folder.
//  *
//  * WHY
//  * The team answers this mailbox from more than one place -- the real Freshdesk,
//  * and occasionally webmail. Those replies leave through someone else's SMTP and
//  * this panel never saw them, so a ticket that had been answered hours ago still
//  * showed as waiting on us. Every one of them lands in Sent, which makes that
//  * folder the record of "what we have actually told this customer".
//  *
//  * Shares the caller's connection, lock and time budget, and keeps its own UID
//  * watermark in fd_mailbox_state under the folder's own name -- so this and the
//  * INBOX advance independently.
//  *
//  * WHAT IT CANNOT SEE
//  * A copy has to exist in the folder. If Freshdesk is configured to send purely
//  * through its own servers with no IMAP copy back to this mailbox, there is
//  * nothing here to read and no IMAP-based sync can reach those replies; that
//  * case needs Freshdesk's API instead.
//  *
//  * Set FD_IMAP_SENT_FOLDER to '' to switch the whole pass off.
//  */
// function fd_sync_sent_folder($imap, $started, $budget)
// {
//     $out = array('folder' => '', 'scanned' => 0, 'imported' => 0, 'duplicates' => 0,
//                  'skipped' => 0, 'errors' => 0, 'touched_ticket_ids' => array());

//     $folder = trim((string)fd_cfg('IMAP_SENT_FOLDER', ''));
//     if ($folder === '') return $out;
//     $out['folder'] = $folder;

//     $touched = array();
//     try {
//         $state = fd_query_one("SELECT * FROM fd_mailbox_state WHERE mailbox = ?", 's', array($folder));
//         if (!$state) {
//             fd_exec("INSERT INTO fd_mailbox_state (mailbox, last_uid, uidvalidity) VALUES (?, 0, 0)",
//                     's', array($folder));
//             $state = null;
//         }
//         $lastUid       = $state ? (int)$state['last_uid'] : 0;
//         $knownValidity = $state ? (int)$state['uidvalidity'] : 0;

//         $info = $imap->selectFolder($folder, true);      // read-only, same as the inbox
//         $validity = (int)$info['uidvalidity'];

//         $rebaselined = false;
//         if ($knownValidity && $validity && $validity !== $knownValidity) {
//             fd_log('warn', 'Sent folder UIDVALIDITY changed -- re-baselining', array('folder' => $folder));
//             $lastUid = 0;
//             $rebaselined = true;
//         }

//         if ($lastUid === 0) {
//             $days = max(1, fd_cfg_int('SYNC_INITIAL_DAYS', 7));
//             $uids = $imap->searchSinceDays($days);
//         } else {
//             $uids = $imap->searchSinceUid($lastUid);
//         }

//         // Half the inbox batch: incoming mail is what an agent is waiting for,
//         // and this pass must never starve it of the time budget.
//         $batch = max(1, (int)floor(fd_cfg_int('SYNC_BATCH', 40) / 2));
//         $uids  = array_slice($uids, 0, $batch);
//         $out['scanned'] = count($uids);

//         $highestDone = $lastUid;
//         foreach ($uids as $uid) {
//             if ((microtime(true) - $started) > $budget) break;
//             try {
//                 $fetched = $imap->fetchMessages(array($uid));
//                 if (empty($fetched[$uid])) { $out['skipped']++; $highestDone = max($highestDone, (int)$uid); continue; }

//                 $parsed = MimeParser::parse($fetched[$uid]['raw']);
//                 $stored = fd_store_outbound_copy($parsed, array(
//                     'mailbox'     => $folder,
//                     'uid'         => (int)$uid,
//                     'uidvalidity' => $validity,
//                     'size'        => $fetched[$uid]['size'],
//                 ));

//                 if (!empty($stored['skipped']))        $out['skipped']++;
//                 elseif (!empty($stored['duplicate']))  $out['duplicates']++;
//                 else {
//                     $out['imported']++;
//                     $tid = (int)$stored['ticket_id'];
//                     $touched[$tid] = true;
//                     // Tell any open panel, so a reply sent from Freshdesk shows
//                     // up in the thread without a manual refresh.
//                     fd_emit('message-sent', array(
//                         'ticket_id'  => $tid,
//                         'message_id' => (int)$stored['message_id'],
//                         'type'       => 'reply',
//                         'external'   => true,
//                     ), array(
//                         'ticket_id' => $tid,
//                         'summary'   => 'Reply sent from the mailbox on #' . $tid,
//                     ));
//                 }
//                 $highestDone = max($highestDone, (int)$uid);

//             } catch (FdImapException $e) {
//                 throw $e;
//             } catch (Throwable $e) {
//                 // One bad message must not wedge the folder: step past it.
//                 $out['errors']++;
//                 $highestDone = max($highestDone, (int)$uid);
//                 fd_log('error', 'Sent-folder import failed for UID ' . $uid . ': ' . $e->getMessage(),
//                        array('folder' => $folder));
//             }
//         }

//         if ($highestDone > $lastUid || $rebaselined || !$knownValidity) {
//             fd_exec("UPDATE fd_mailbox_state
//                      SET last_uid = GREATEST(last_uid, ?), uidvalidity = ?, imported_total = imported_total + ?
//                      WHERE mailbox = ?",
//                     'iiis', array($highestDone, $validity, $out['imported'], $folder));
//         }

//     } catch (Throwable $e) {
//         /*
//          * A failure here is NOT a failed sync. The inbox has already been read
//          * and committed by this point, and a missing or misnamed Sent folder
//          * (the name differs between Dovecot and Gmail-style servers) must not
//          * turn a good run into a red one.
//          */
//         $out['errors']++;
//         $out['error'] = $e->getMessage();
//         fd_log('warn', 'Sent-folder pass skipped: ' . $e->getMessage(), array('folder' => $folder));
//     }

//     $out['touched_ticket_ids'] = array_keys($touched);
//     return $out;
// }

// /**
//  * Close tickets that nobody has touched for FD_AUTO_CLOSE_DAYS.
//  *
//  * Off unless configured. Measured on last_message_at, so any reply -- from the
//  * customer or from an agent -- resets the clock and the ticket stays open.
//  *
//  * Set-based and bounded: one UPDATE over at most 1,000 rows per run, and ONE
//  * activity entry rather than one per ticket. On a big backlog it simply takes a
//  * few cron ticks to work through, which is fine -- nothing is waiting on it.
//  *
//  * No email is sent. Closing writes columns only.
//  */
// function fd_auto_close_stale()
// {
//     $days = fd_cfg_int('AUTO_CLOSE_DAYS', 0);
//     if ($days <= 0) return 0;

//     $rows = fd_query(
//         "SELECT id FROM fd_tickets
//          WHERE is_trash = 0 AND merged_into IS NULL
//            AND status NOT IN ('Resolved','Closed')
//            AND COALESCE(last_message_at, created_at) < DATE_SUB(NOW(), INTERVAL ? DAY)
//          ORDER BY id ASC LIMIT 1000",
//         'i', array($days)
//     );
//     if (empty($rows)) return 0;

//     $ids = array_map(function ($r) { return (int)$r['id']; }, $rows);
//     $place = implode(',', array_fill(0, count($ids), '?'));

//     $n = fd_exec(
//         "UPDATE fd_tickets
//          SET status = 'Closed',
//              resolved_at = COALESCE(resolved_at, NOW()),
//              closed_at   = COALESCE(closed_at, NOW()),
//              response_status = 'Resolved',
//              unread_count = 0, customer_replied = 0,
//              -- The clock stopped when the ticket closed; leaving it breached
//              -- would keep the dashboard permanently red.
//              sla_status = 'On track', sla_breached = 0,
//              updated_at = NOW()
//          WHERE id IN ($place)",
//         str_repeat('i', count($ids)), $ids
//     );

//     if ($n > 0) {
//         fd_log('info', 'Auto-closed ' . $n . ' stale ticket(s) (>' . $days . ' days idle)');
//         fd_emit('tickets-auto-closed', array('closed' => $n, 'days' => $days), array(
//             'actor_type' => 'system',
//             'actor_name' => 'Automation',
//             'summary'    => 'Auto-closed ' . $n . ' ticket(s) with no activity for ' . $days . ' days',
//         ));
//     }
//     return $n;
// }

// /**
//  * Publish the realtime event for one imported message.
//  *
//  * The payload is deliberately small and preview-only -- enough for the panel to
//  * show a toast, play the chime, and bump the counters, but never the full body.
//  * The client fetches the real record over HTTP. That keeps every event under
//  * Pusher's 10KB cap and keeps message bodies off the websocket entirely.
//  */
// function fd_publish_inbound($ticketId, $messageId, $isNewTicket, $parsed)
// {
//     $t = fd_query_one("SELECT id, subject, requester_name, requester_email, status, priority, category, sla_status, unread_count
//                        FROM fd_tickets WHERE id = ?", 'i', array((int)$ticketId));
//     if (!$t) return;

//     $payload = array(
//         'ticket_id'   => (int)$ticketId,
//         'message_id'  => (int)$messageId,
//         'is_new'      => $isNewTicket ? 1 : 0,
//         'subject'     => fd_snippet($t['subject'], 120),
//         'from_name'   => fd_snippet($t['requester_name'], 60),
//         'from_email'  => $t['requester_email'],
//         'preview'     => fd_snippet(fd_strip_quoted_text(isset($parsed['body_text']) ? $parsed['body_text'] : ''), 140),
//         'priority'    => $t['priority'],
//         'status'      => $t['status'],
//         'category'    => $t['category'],
//         'has_attachments' => !empty($parsed['attachments']) ? 1 : 0,
//         // Drives the chime + browser notification on the client.
//         'notify'      => 1,
//         'sound'       => $isNewTicket ? 'new-ticket' : 'new-reply',
//     );

//     fd_emit($isNewTicket ? 'new-ticket' : 'new-message', $payload, array(
//         'ticket_id'  => (int)$ticketId,
//         'message_id' => (int)$messageId,
//         'actor_type' => 'customer',
//         'actor_name' => $t['requester_name'],
//         'summary'    => ($isNewTicket ? 'New ticket from ' : 'Reply from ') . $t['requester_name'] . ': ' . fd_snippet($t['subject'], 80),
//     ));
// }

// /* ------------------------------------------------------------- respond --- */

// $out = fd_run_sync($actor);

// if ($FD_IS_CLI) {
//     echo date('Y-m-d H:i:s') . ' | sync | ' . json_encode($out) . "\n";
//     fd_log('info', 'Cron sync: ' . $out['message'], array(
//         'imported' => $out['imported'], 'dupes' => $out['duplicates'],
//         'errors' => $out['errors'], 'ms' => $out['took_ms'],
//     ));
//     exit($out['ok'] ? 0 : 1);
// }

// http_response_code($out['ok'] ? 200 : 500);
// echo json_encode(array(
//     'success' => $out['ok'],
//     'message' => $out['message'],
//     'data'    => $out,
// ), JSON_UNESCAPED_UNICODE);



















/*
 * /api/freshdesk/fd_sync.php
 *
 * The inbound mail worker. Connects to contact@internshipstudio.com over IMAP,
 * pulls anything newer than the stored watermark, and turns each message into a
 * ticket + conversation entry + attachments, then publishes a realtime event so
 * open panels update without a refresh.
 *
 * Three ways to run it, all landing in the same code:
 *
 *   CLI (cron -- the normal way, every minute):
 *     * * * * * /usr/local/bin/php /home/istudio/public_html/cit3/admin/react-api/api/freshdesk/fd_sync.php
 *
 *   HTTP with the shared secret (for uptime pingers / external schedulers):
 *     GET fd_sync.php?secret=<FD_CRON_SECRET>
 *
 *   HTTP with a JWT (the panel's "Refresh" button and its background poll):
 *     GET fd_sync.php?action=sync   (Authorization: Bearer ...)
 *
 * SAFETY PROPERTIES, none of which are optional:
 *   - A DB-level lock stops the cron tick and an agent's Refresh from importing
 *     the same UID range twice.
 *   - The watermark is only advanced past a UID that was actually stored, so a
 *     crash mid-batch re-reads rather than skips. Re-reading is free (the
 *     unique Message-ID index makes it a no-op); skipping loses a customer's
 *     email forever.
 *   - UIDVALIDITY is checked every run. When the server changes it, every
 *     stored UID is meaningless and the worker re-baselines instead of trusting
 *     numbers that now point at different messages.
 *   - A wall-clock budget stops the run cleanly with its progress committed,
 *     instead of being killed by max_execution_time holding the lock.
 */

$FD_IS_CLI = (php_sapi_name() === 'cli');

if ($FD_IS_CLI) {
    // A cron run has no web-server context; give it the paths the endpoints get
    // from Apache, and never emit CORS/JSON headers into a terminal.
    $_SERVER['REQUEST_METHOD'] = 'GET';
    $_SERVER['HTTP_HOST'] = 'cit3.internshipstudio.com';
    set_time_limit(0);
}

require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/lib/config.php';
require_once __DIR__ . '/lib/Helpers.php';
require_once __DIR__ . '/lib/schema.php';
require_once __DIR__ . '/lib/Sla.php';
require_once __DIR__ . '/lib/Automation.php';
require_once __DIR__ . '/lib/Pusher.php';
require_once __DIR__ . '/lib/ImapClient.php';
require_once __DIR__ . '/lib/MimeParser.php';
require_once __DIR__ . '/lib/Storage.php';
require_once __DIR__ . '/lib/TicketStore.php';
require_once __DIR__ . '/lib/Mailer.php';

fd_install_error_handlers();
fd_ensure_schema();

/* ------------------------------------------------------------ authorise --- */

$authorised = false;
$actor = array('id' => null, 'name' => 'cron');

if ($FD_IS_CLI) {
    $authorised = true;
} else {
    $secret = fd_str('secret', '');
    if ($secret !== '' && hash_equals((string)fd_cfg('CRON_SECRET', FD_CRON_SECRET), $secret)) {
        $authorised = true;
    } else {
        // Fall back to the normal panel auth so the Refresh button works.
        require_once __DIR__ . '/../../middleware/auth.php';
        $jwt = require_jwt();
        require_permission('freshdesk', $jwt);
        $authorised = true;
        $actor = array('id' => isset($jwt['user_id']) ? (int)$jwt['user_id'] : null,
                       'name' => isset($jwt['name']) ? $jwt['name'] : 'Agent');
    }
}
if (!$authorised) {
    http_response_code(403);
    echo json_encode(array('success' => false, 'message' => 'Not authorised'));
    exit;
}

/* ------------------------------------------------------------- locking --- */

/**
 * Claim the mailbox for this run.
 *
 * The UPDATE ... WHERE lock is stale-or-free is a single atomic statement, so
 * two workers starting in the same millisecond cannot both win: MySQL serialises
 * the row update and exactly one sees affected_rows = 1.
 *
 * The 5-minute staleness window is the crash recovery: a worker killed by the
 * host (OOM, deploy, max_execution_time) leaves its lock behind, and without
 * this the desk would stop receiving mail permanently and silently.
 */
function fd_acquire_lock($mailbox, $token)
{
    fd_exec("INSERT IGNORE INTO fd_mailbox_state (mailbox, last_uid, last_status) VALUES (?, 0, 'idle')",
            's', array($mailbox));
    $n = fd_exec(
        "UPDATE fd_mailbox_state
         SET lock_token = ?, lock_at = NOW(), last_status = 'running', last_sync_at = NOW()
         WHERE mailbox = ?
           AND (lock_token IS NULL OR lock_at IS NULL OR lock_at < DATE_SUB(NOW(), INTERVAL 5 MINUTE))",
        'ss', array($token, $mailbox)
    );
    return $n > 0;
}

function fd_release_lock($mailbox, $token, $status, $error = null)
{
    fd_exec(
        "UPDATE fd_mailbox_state
         SET lock_token = NULL, lock_at = NULL, last_status = ?, last_error = ?,
             last_success_at = CASE WHEN ? = 'ok' THEN NOW() ELSE last_success_at END,
             consecutive_fails = CASE WHEN ? = 'ok' THEN 0 ELSE consecutive_fails + 1 END
         WHERE mailbox = ? AND (lock_token = ? OR lock_token IS NULL)",
        'ssssss', array($status, $error, $status, $status, $mailbox, $token)
    );
}

/* ---------------------------------------------------------------- run ---- */

function fd_run_sync($actor)
{
    $started  = microtime(true);
    $mailbox  = (string)fd_cfg('IMAP_FOLDER', 'INBOX');
    $token    = bin2hex(random_bytes(8));
    $budget   = fd_cfg_int('SYNC_MAX_SECONDS', 50);
    $batch    = max(1, fd_cfg_int('SYNC_BATCH', 40));

    $result = array(
        'ok' => false, 'mailbox' => $mailbox, 'scanned' => 0, 'imported' => 0,
        'duplicates' => 0, 'new_tickets' => 0, 'errors' => 0, 'skipped' => 0,
        'ignored' => 0, 'ignored_reasons' => array(),
        'remaining' => 0, 'cursor' => 0, 'took_ms' => 0, 'message' => '',
        'new_ticket_ids' => array(), 'touched_ticket_ids' => array(),
    );

    if (!fd_acquire_lock($mailbox, $token)) {
        // Not a failure: another run holds it and is doing the work.
        $result['ok'] = true;
        $result['message'] = 'Another sync is already running; skipped this tick.';
        $result['locked'] = true;
        return $result;
    }

    $imap = null;
    try {
        $state = fd_query_one("SELECT * FROM fd_mailbox_state WHERE mailbox = ?", 's', array($mailbox));
        $lastUid     = $state ? (int)$state['last_uid'] : 0;
        $knownValidity = $state ? (int)$state['uidvalidity'] : 0;

        $imap = new ImapClient();
        $imap->login();
        $info = $imap->selectFolder($mailbox, true);   // read-only: never touch \Seen
        $validity = (int)$info['uidvalidity'];

        $rebaselined = false;
        if ($knownValidity && $validity && $validity !== $knownValidity) {
            /*
             * UIDVALIDITY changed -- the mailbox was rebuilt/restored and every
             * UID now refers to a different message. Continuing with the old
             * watermark would either skip everything or re-import the whole
             * mailbox as new. Re-baseline against the recent window instead and
             * let the Message-ID unique index absorb whatever we already have.
             */
            fd_log('warn', 'UIDVALIDITY changed -- re-baselining', array(
                'mailbox' => $mailbox, 'was' => $knownValidity, 'now' => $validity));
            $lastUid = 0;
            $rebaselined = true;
        }

        if ($lastUid === 0) {
            // First ever run (or a re-baseline): import only the recent window,
            // never the entire history of a mailbox that may hold 40k messages.
            $days = max(1, fd_cfg_int('SYNC_INITIAL_DAYS', 7));
            $uids = $imap->searchSinceDays($days);
            fd_log('info', 'Baseline sync', array('mailbox' => $mailbox, 'days' => $days, 'found' => count($uids)));
        } else {
            $uids = $imap->searchSinceUid($lastUid);
        }

        $result['remaining'] = max(0, count($uids) - $batch);
        $uids = array_slice($uids, 0, $batch);
        $result['scanned'] = count($uids);

        $highestDone = $lastUid;
        $newTicketIds = array();
        $touched = array();

        foreach ($uids as $uid) {
            if ((microtime(true) - $started) > $budget) {
                fd_log('info', 'Sync budget reached, stopping cleanly', array('done_upto_uid' => $highestDone));
                $result['message'] = 'Time budget reached; the rest will be picked up on the next run.';
                $result['remaining'] += 1;
                break;
            }

            try {
                $fetched = $imap->fetchMessages(array($uid));
                if (empty($fetched[$uid])) { $result['skipped']++; $highestDone = max($highestDone, (int)$uid); continue; }

                $raw = $fetched[$uid]['raw'];
                $parsed = MimeParser::parse($raw);

                $stored = fd_store_inbound($parsed, array(
                    'mailbox'     => $mailbox,
                    'uid'         => (int)$uid,
                    'uidvalidity' => $validity,
                    'size'        => $fetched[$uid]['size'],
                ));

                if (!empty($stored['skipped'])) {
                    // Orphan bounces / auto-responders: machine mail referring
                    // to a conversation this desk never had. Counted so the
                    // number is visible rather than silently vanishing.
                    $result['ignored']++;
                    $result['ignored_reasons'][$stored['skipped']] =
                        (isset($result['ignored_reasons'][$stored['skipped']]) ? $result['ignored_reasons'][$stored['skipped']] : 0) + 1;
                } elseif (!empty($stored['duplicate'])) {
                    $result['duplicates']++;
                } else {
                    $result['imported']++;
                    $tid = (int)$stored['ticket_id'];
                    $touched[$tid] = true;

                    if (!empty($stored['is_new_ticket'])) {
                        $result['new_tickets']++;
                        $newTicketIds[] = $tid;
                    }
                    fd_publish_inbound($tid, (int)$stored['message_id'], !empty($stored['is_new_ticket']), $parsed);

                    /*
                     * Rules run BEFORE the auto-acknowledgement, so a rule that
                     * closes a ticket as spam does not also send the customer a
                     * "we have received your query" first.
                     */
                    fd_automation_run(
                        !empty($stored['is_new_ticket']) ? 'ticket_created' : 'ticket_updated',
                        $tid, (int)$stored['message_id']);

                    // Re-read: a rule may have just closed or reassigned it.
                    $after = fd_query_one("SELECT status FROM fd_tickets WHERE id = ?", 'i', array($tid));
                    $stillOpen = $after && !in_array($after['status'], array('Closed', 'Resolved'), true);

                    if (!empty($stored['is_new_ticket']) && $stillOpen) {
                        fd_send_auto_ack($tid, $parsed);
                    }
                }

                // Only now is it safe to move the watermark past this UID.
                $highestDone = max($highestDone, (int)$uid);

            } catch (FdImapException $e) {
                // A protocol/connection failure ends the run -- carrying on would
                // just produce a stream of identical errors.
                throw $e;
            } catch (Throwable $e) {
                /*
                 * One malformed message must not wedge the mailbox forever. Log
                 * it loudly, count it, and step past it -- if the watermark
                 * never advanced, this same message would be retried on every
                 * tick and nothing behind it would ever arrive.
                 */
                $result['errors']++;
                $highestDone = max($highestDone, (int)$uid);
                fd_log('error', 'Failed to import UID ' . $uid . ': ' . $e->getMessage(), array('mailbox' => $mailbox));
            }
        }

        if ($highestDone > $lastUid || $rebaselined || !$knownValidity) {
            fd_exec(
                "UPDATE fd_mailbox_state
                 SET last_uid = GREATEST(last_uid, ?), uidvalidity = ?, imported_total = imported_total + ?
                 WHERE mailbox = ?",
                'iiis', array($highestDone, $validity, $result['imported'], $mailbox)
            );
        }

        /*
         * The Sent folder, on the same connection.
         *
         * Answers given from the real Freshdesk (or from webmail) never touch
         * this panel's Mailer, so without this pass the conversation showed the
         * customer's question with nothing under it. Reading Sent is how those
         * replies become part of the thread.
         *
         * Runs inside the same lock and the same time budget: it is a second
         * folder, not a second sync.
         */
        $sent = fd_sync_sent_folder($imap, $started, $budget);
        $result['sent'] = $sent;
        foreach ($sent['touched_ticket_ids'] as $tid) $touched[$tid] = true;

        $imap->close();
        $imap = null;

        // Clocks must tick even when nobody has the page open.
        fd_sla_sweep(300);

        // ...and stale tickets close themselves, if that is switched on.
        $result['auto_closed'] = fd_auto_close_stale();

        $result['ok'] = true;
        $result['new_ticket_ids']     = $newTicketIds;
        $result['touched_ticket_ids'] = array_keys($touched);
        if ($result['message'] === '') {
            $bits = array();
            if ($result['imported'] > 0) {
                $bits[] = $result['imported'] . ' new message' . ($result['imported'] === 1 ? '' : 's');
            }
            if (!empty($result['sent']['imported'])) {
                $bits[] = $result['sent']['imported'] . ' reply sent elsewhere'
                        . ($result['sent']['imported'] === 1 ? '' : 'ies');
            }
            $result['message'] = empty($bits) ? 'Mailbox is up to date' : (implode(' and ', $bits) . ' imported');
        }
        fd_release_lock($mailbox, $token, 'ok', null);

    } catch (Throwable $e) {
        if ($imap) { try { $imap->close(); } catch (Throwable $e2) {} }
        $msg = $e->getMessage();
        $result['ok'] = false;
        $result['message'] = $msg;
        fd_log('error', 'Sync run failed: ' . $msg, array('mailbox' => $mailbox));
        fd_release_lock($mailbox, $token, 'error', substr($msg, 0, 900));

        /*
         * Tell the panel when the mailbox has been unreachable repeatedly. A
         * desk that quietly stops receiving mail is the worst failure mode
         * this system has -- it looks exactly like "a quiet day".
         */
        $st = fd_query_one("SELECT consecutive_fails FROM fd_mailbox_state WHERE mailbox = ?", 's', array($mailbox));
        if ($st && (int)$st['consecutive_fails'] >= 3) {
            fd_emit('mailbox-down', array(
                'mailbox' => $mailbox,
                'fails'   => (int)$st['consecutive_fails'],
                'error'   => fd_snippet($msg, 200),
            ), array('summary' => 'Mailbox unreachable: ' . fd_snippet($msg, 120)));
        }
    }

    $result['took_ms'] = (int)round((microtime(true) - $started) * 1000);
    $cur = fd_query_one("SELECT MAX(id) AS c FROM fd_activity");
    $result['cursor'] = $cur ? (int)$cur['c'] : 0;
    return $result;
}

/**
 * Import replies from the mailbox's Sent folder.
 *
 * WHY
 * The team answers this mailbox from more than one place -- the real Freshdesk,
 * and occasionally webmail. Those replies leave through someone else's SMTP and
 * this panel never saw them, so a ticket that had been answered hours ago still
 * showed as waiting on us. Every one of them lands in Sent, which makes that
 * folder the record of "what we have actually told this customer".
 *
 * Shares the caller's connection, lock and time budget, and keeps its own UID
 * watermark in fd_mailbox_state under the folder's own name -- so this and the
 * INBOX advance independently.
 *
 * WHAT IT CANNOT SEE
 * A copy has to exist in the folder. If Freshdesk is configured to send purely
 * through its own servers with no IMAP copy back to this mailbox, there is
 * nothing here to read and no IMAP-based sync can reach those replies; that
 * case needs Freshdesk's API instead.
 *
 * Set FD_IMAP_SENT_FOLDER to '' to switch the whole pass off.
 */
function fd_sync_sent_folder($imap, $started, $budget)
{
    $out = array('folder' => '', 'scanned' => 0, 'imported' => 0, 'duplicates' => 0,
                 'skipped' => 0, 'errors' => 0, 'touched_ticket_ids' => array());

    $folder = trim((string)fd_cfg('IMAP_SENT_FOLDER', ''));
    if ($folder === '') return $out;
    $out['folder'] = $folder;

    $touched = array();
    try {
        $state = fd_query_one("SELECT * FROM fd_mailbox_state WHERE mailbox = ?", 's', array($folder));
        if (!$state) {
            fd_exec("INSERT INTO fd_mailbox_state (mailbox, last_uid, uidvalidity) VALUES (?, 0, 0)",
                    's', array($folder));
            $state = null;
        }
        $lastUid       = $state ? (int)$state['last_uid'] : 0;
        $knownValidity = $state ? (int)$state['uidvalidity'] : 0;

        $info = $imap->selectFolder($folder, true);      // read-only, same as the inbox
        $validity = (int)$info['uidvalidity'];

        $rebaselined = false;
        if ($knownValidity && $validity && $validity !== $knownValidity) {
            fd_log('warn', 'Sent folder UIDVALIDITY changed -- re-baselining', array('folder' => $folder));
            $lastUid = 0;
            $rebaselined = true;
        }

        if ($lastUid === 0) {
            $days = max(1, fd_cfg_int('SYNC_INITIAL_DAYS', 7));
            $uids = $imap->searchSinceDays($days);
        } else {
            $uids = $imap->searchSinceUid($lastUid);
        }

        // Half the inbox batch: incoming mail is what an agent is waiting for,
        // and this pass must never starve it of the time budget.
        $batch = max(1, (int)floor(fd_cfg_int('SYNC_BATCH', 40) / 2));
        $uids  = array_slice($uids, 0, $batch);
        $out['scanned'] = count($uids);

        $highestDone = $lastUid;
        foreach ($uids as $uid) {
            if ((microtime(true) - $started) > $budget) break;
            try {
                $fetched = $imap->fetchMessages(array($uid));
                if (empty($fetched[$uid])) { $out['skipped']++; $highestDone = max($highestDone, (int)$uid); continue; }

                $parsed = MimeParser::parse($fetched[$uid]['raw']);
                $stored = fd_store_outbound_copy($parsed, array(
                    'mailbox'     => $folder,
                    'uid'         => (int)$uid,
                    'uidvalidity' => $validity,
                    'size'        => $fetched[$uid]['size'],
                ));

                if (!empty($stored['skipped']))        $out['skipped']++;
                elseif (!empty($stored['duplicate']))  $out['duplicates']++;
                else {
                    $out['imported']++;
                    $tid = (int)$stored['ticket_id'];
                    $touched[$tid] = true;
                    // Tell any open panel, so a reply sent from Freshdesk shows
                    // up in the thread without a manual refresh.
                    fd_emit('message-sent', array(
                        'ticket_id'  => $tid,
                        'message_id' => (int)$stored['message_id'],
                        'type'       => 'reply',
                        'external'   => true,
                    ), array(
                        'ticket_id' => $tid,
                        'summary'   => 'Reply sent from the mailbox on #' . $tid,
                    ));
                }
                $highestDone = max($highestDone, (int)$uid);

            } catch (FdImapException $e) {
                throw $e;
            } catch (Throwable $e) {
                // One bad message must not wedge the folder: step past it.
                $out['errors']++;
                $highestDone = max($highestDone, (int)$uid);
                fd_log('error', 'Sent-folder import failed for UID ' . $uid . ': ' . $e->getMessage(),
                       array('folder' => $folder));
            }
        }

        if ($highestDone > $lastUid || $rebaselined || !$knownValidity) {
            fd_exec("UPDATE fd_mailbox_state
                     SET last_uid = GREATEST(last_uid, ?), uidvalidity = ?, imported_total = imported_total + ?
                     WHERE mailbox = ?",
                    'iiis', array($highestDone, $validity, $out['imported'], $folder));
        }

    } catch (Throwable $e) {
        /*
         * A failure here is NOT a failed sync. The inbox has already been read
         * and committed by this point, and a missing or misnamed Sent folder
         * (the name differs between Dovecot and Gmail-style servers) must not
         * turn a good run into a red one.
         */
        $out['errors']++;
        $out['error'] = $e->getMessage();
        fd_log('warn', 'Sent-folder pass skipped: ' . $e->getMessage(), array('folder' => $folder));
    }

    $out['touched_ticket_ids'] = array_keys($touched);
    return $out;
}

/**
 * Close tickets that nobody has touched for FD_AUTO_CLOSE_DAYS.
 *
 * Off unless configured. Measured on last_message_at, so any reply -- from the
 * customer or from an agent -- resets the clock and the ticket stays open.
 *
 * Set-based and bounded: one UPDATE over at most 1,000 rows per run, and ONE
 * activity entry rather than one per ticket. On a big backlog it simply takes a
 * few cron ticks to work through, which is fine -- nothing is waiting on it.
 *
 * No email is sent. Closing writes columns only.
 */
function fd_auto_close_stale()
{
    $days = fd_cfg_int('AUTO_CLOSE_DAYS', 0);
    if ($days <= 0) return 0;

    $rows = fd_query(
        "SELECT id FROM fd_tickets
         WHERE is_trash = 0 AND merged_into IS NULL
           AND status NOT IN ('Resolved','Closed')
           AND COALESCE(last_message_at, created_at) < DATE_SUB(NOW(), INTERVAL ? DAY)
         ORDER BY id ASC LIMIT 1000",
        'i', array($days)
    );
    if (empty($rows)) return 0;

    $ids = array_map(function ($r) { return (int)$r['id']; }, $rows);
    $place = implode(',', array_fill(0, count($ids), '?'));

    $n = fd_exec(
        "UPDATE fd_tickets
         SET status = 'Closed',
             resolved_at = COALESCE(resolved_at, NOW()),
             closed_at   = COALESCE(closed_at, NOW()),
             response_status = 'Resolved',
             unread_count = 0, customer_replied = 0,
             -- The clock stopped when the ticket closed; leaving it breached
             -- would keep the dashboard permanently red.
             sla_status = 'On track', sla_breached = 0,
             updated_at = NOW()
         WHERE id IN ($place)",
        str_repeat('i', count($ids)), $ids
    );

    if ($n > 0) {
        fd_log('info', 'Auto-closed ' . $n . ' stale ticket(s) (>' . $days . ' days idle)');
        fd_emit('tickets-auto-closed', array('closed' => $n, 'days' => $days), array(
            'actor_type' => 'system',
            'actor_name' => 'Automation',
            'summary'    => 'Auto-closed ' . $n . ' ticket(s) with no activity for ' . $days . ' days',
        ));
    }
    return $n;
}

/**
 * Publish the realtime event for one imported message.
 *
 * The payload is deliberately small and preview-only -- enough for the panel to
 * show a toast, play the chime, and bump the counters, but never the full body.
 * The client fetches the real record over HTTP. That keeps every event under
 * Pusher's 10KB cap and keeps message bodies off the websocket entirely.
 */
function fd_publish_inbound($ticketId, $messageId, $isNewTicket, $parsed)
{
    $t = fd_query_one("SELECT id, subject, requester_name, requester_email, status, priority, category, sla_status, unread_count
                       FROM fd_tickets WHERE id = ?", 'i', array((int)$ticketId));
    if (!$t) return;

    $payload = array(
        'ticket_id'   => (int)$ticketId,
        'message_id'  => (int)$messageId,
        'is_new'      => $isNewTicket ? 1 : 0,
        'subject'     => fd_snippet($t['subject'], 120),
        'from_name'   => fd_snippet($t['requester_name'], 60),
        'from_email'  => $t['requester_email'],
        'preview'     => fd_snippet(fd_strip_quoted_text(isset($parsed['body_text']) ? $parsed['body_text'] : ''), 140),
        'priority'    => $t['priority'],
        'status'      => $t['status'],
        'category'    => $t['category'],
        'has_attachments' => !empty($parsed['attachments']) ? 1 : 0,
        // Drives the chime + browser notification on the client.
        'notify'      => 1,
        'sound'       => $isNewTicket ? 'new-ticket' : 'new-reply',
    );

    fd_emit($isNewTicket ? 'new-ticket' : 'new-message', $payload, array(
        'ticket_id'  => (int)$ticketId,
        'message_id' => (int)$messageId,
        'actor_type' => 'customer',
        'actor_name' => $t['requester_name'],
        'summary'    => ($isNewTicket ? 'New ticket from ' : 'Reply from ') . $t['requester_name'] . ': ' . fd_snippet($t['subject'], 80),
    ));
}

/* ------------------------------------------------------------- respond --- */

$out = fd_run_sync($actor);

if ($FD_IS_CLI) {
    echo date('Y-m-d H:i:s') . ' | sync | ' . json_encode($out) . "\n";
    fd_log('info', 'Cron sync: ' . $out['message'], array(
        'imported' => $out['imported'], 'dupes' => $out['duplicates'],
        'errors' => $out['errors'], 'ms' => $out['took_ms'],
    ));
    exit($out['ok'] ? 0 : 1);
}

http_response_code($out['ok'] ? 200 : 500);
echo json_encode(array(
    'success' => $out['ok'],
    'message' => $out['message'],
    'data'    => $out,
), JSON_UNESCAPED_UNICODE);

<?php
/*
 * /api/netcore/user_timeline.php
 *
 * GET / POST actions:
 *   action=timeline     → all events the given user has triggered, newest first
 *     params: user_id (int, required)  OR  email (string)
 *   action=event_detail → full row for one event occurrence
 *     params: event (string), user_id (int), ts (datetime "Y-m-d H:i:s")
 *
 * Designed to be fast:
 *   - One UNION ALL query that pulls the timestamp + event name from every relevant table
 *   - Indexed lookups by user_id everywhere
 */
// header('Content-Type: application/json');
// header('Cache-Control: no-cache, no-store, must-revalidate');
// ini_set('display_errors', 0);
// ob_start();

// chdir('/home/istudio/public_html/cit/common');
// include '/home/istudio/public_html/cit/common/helper.php';
// ob_clean();

// global $conn;
// if (!$conn) { echo json_encode(['status'=>'error','message'=>'DB connection missing']); exit; }

// $action = $_REQUEST['action'] ?? 'timeline';

// /* ── resolve user_id (allow email lookup as a convenience) ── */
// function resolveUserId($conn) {
//     $uid = (int)($_REQUEST['user_id'] ?? 0);
//     if ($uid > 0) return $uid;

//     $email = trim($_REQUEST['email'] ?? '');
//     if ($email === '') return 0;
//     $email = mysqli_real_escape_string($conn, $email);
//     $r = mysqli_query($conn, "SELECT user_id FROM users WHERE email='$email' LIMIT 1");
//     if ($r && $row = mysqli_fetch_assoc($r)) return (int)$row['user_id'];
//     return 0;
// }

// /* ════════════════════════════════════════
//   ACTION: timeline
//   Identifies each occurrence by (event, user_id, ts) — no per-table id needed.
// ════════════════════════════════════════ */
// if ($action === 'timeline') {
//     $userId = resolveUserId($conn);
//     if (!$userId) { echo json_encode(['status'=>'error','message'=>'Missing or invalid user_id/email']); exit; }

//     $sql = "
//       SELECT 'register'                 AS event, registered_at AS ts FROM users                       WHERE user_id=$userId
//       UNION ALL
//       SELECT 'signin'                   AS event, created_at    AS ts FROM signin_log                  WHERE user_id=$userId
//       UNION ALL
//       SELECT 'exam_success'             AS event, `timestamp`   AS ts FROM cit_results                 WHERE user_id=$userId
//       UNION ALL
//       SELECT 'course_purchase'          AS event, `timestamp`   AS ts FROM payment_status              WHERE user_id=$userId AND status='initiated'
//       UNION ALL
//       SELECT 'payment_success'          AS event, `timestamp`   AS ts FROM payment_status              WHERE user_id=$userId AND status='success'
//       UNION ALL
//       SELECT 'preferred_domain'         AS event, created_at    AS ts FROM user_slected_domain_new     WHERE user_id=$userId
//       UNION ALL
//       SELECT 'visited_iap'              AS event, visited_at    AS ts FROM user_iap_visits             WHERE user_id=$userId
//       UNION ALL
//       SELECT 'placement_community_link' AS event, assigned_at   AS ts FROM assigned_links              WHERE user_id=$userId
//       UNION ALL
//       SELECT 'placement_community_link' AS event, assigned_at   AS ts FROM assigned_links_for_refund   WHERE user_id=$userId
//       UNION ALL
//       SELECT 'instantexam_reminder'     AS event, created_at    AS ts FROM set_reminder                WHERE user_id=$userId
//       UNION ALL
//       SELECT 'course_edit'              AS event, created_at    AS ts FROM internship_edit_logs        WHERE user_id=$userId
//       ORDER BY ts DESC
//       LIMIT 500
//     ";

//     $res    = mysqli_query($conn, $sql);
//     $events = [];
//     if ($res) while ($row = mysqli_fetch_assoc($res)) {
//         $events[] = [
//             'event'     => $row['event'],
//             'user_id'   => $userId,
//             'timestamp' => $row['ts'],
//         ];
//     }
//     /* SQL already returns DESC (most recent first) — keep it that way so the newest event is at the TOP. */

//     /* basic profile snippet for the page header (incl. photo) */
//     $r = mysqli_query($conn, "SELECT user_id, email, fname, lname, phone, photo, registered_at
//                               FROM users WHERE user_id=$userId LIMIT 1");
//     $profile = $r ? mysqli_fetch_assoc($r) : null;

//     /* drop placeholder avatars so the UI can show initials instead */
//     if ($profile && !empty($profile['photo'])) {
//         $placeholder = 'https://hire.internshipstudio.com/assets/img/avatars/avatar_placeholder.png';
//         if ($profile['photo'] === $placeholder) $profile['photo'] = null;
//     }

//     /* device used to register (mobile / desktop) — from store_full_url, most recent row */
//     $device = null;
//     $r = mysqli_query($conn, "SELECT device FROM store_full_url WHERE user_id=$userId ORDER BY created_at DESC LIMIT 1");
//     if ($r && $row = mysqli_fetch_assoc($r)) $device = $row['device'];

//     echo json_encode([
//         'status'  => 'success',
//         'profile' => $profile,
//         'device'  => $device,
//         'events'  => $events,
//     ]);
//     exit;
// }

// /* ════════════════════════════════════════
//   ACTION: event_detail
//   Looks up the row by (user_id, exact timestamp) on the right source table.
// ════════════════════════════════════════ */
// if ($action === 'event_detail') {
//     $event = $_REQUEST['event']   ?? '';
//     $uid   = (int)($_REQUEST['user_id'] ?? 0);
//     $ts    = mysqli_real_escape_string($conn, $_REQUEST['ts'] ?? '');
//     if ($event === '' || !$uid || $ts === '') { echo json_encode(['status'=>'error','message'=>'Missing event/user_id/ts']); exit; }

//     /* table + datetime column for each event */
//     $eventTable = [
//         'register'                 => ['tables' => [['users',                   'registered_at']]],
//         'signin'                   => ['tables' => [['signin_log',              'created_at']]],
//         'exam_success'             => ['tables' => [['cit_results',             '`timestamp`']]],
//         'course_purchase'          => ['tables' => [['payment_status',          '`timestamp`']], 'extra' => "AND status='initiated'"],
//         'payment_success'          => ['tables' => [['payment_status',          '`timestamp`']], 'extra' => "AND status='success'"],
//         'preferred_domain'         => ['tables' => [['user_slected_domain_new', 'created_at']]],
//         'visited_iap'              => ['tables' => [['user_iap_visits',         'visited_at']]],
//         'instantexam_reminder'     => ['tables' => [['set_reminder',            'created_at']]],
//         'course_edit'              => ['tables' => [['internship_edit_logs',    'created_at']]],
//         /* placement_community_link spans two tables — try both */
//         'placement_community_link' => ['tables' => [
//             ['assigned_links',            'assigned_at'],
//             ['assigned_links_for_refund', 'assigned_at'],
//         ]],
//     ];

//     if (!isset($eventTable[$event])) { echo json_encode(['status'=>'error','message'=>'Unknown event']); exit; }
//     $extra = $eventTable[$event]['extra'] ?? '';

//     foreach ($eventTable[$event]['tables'] as [$tbl, $col]) {
//         $q = "SELECT * FROM $tbl WHERE user_id=$uid AND $col='$ts' $extra LIMIT 1";
//         $r = mysqli_query($conn, $q);
//         if ($r && $row = mysqli_fetch_assoc($r)) {
//             /* drop heavy/sensitive columns */
//             foreach (['password','token','employer_password','employer_password_plain','user_agent'] as $strip) {
//                 if (array_key_exists($strip, $row)) unset($row[$strip]);
//             }
//             echo json_encode(['status'=>'success','event'=>$event,'table'=>$tbl,'data'=>$row]);
//             exit;
//         }
//     }

//     echo json_encode(['status'=>'error','message'=>'Row not found']);
//     exit;
// }

// echo json_encode(['status'=>'error','message'=>'Invalid action']);
// exit;























/*
 * /api/netcore/user_timeline.php
 *
 * GET / POST actions:
 *   action=timeline     → all events the given user has triggered, newest first
 *     params: user_id (int, required)  OR  email (string)
 *   action=event_detail → full row for one event occurrence
 *     params: event (string), user_id (int), ts (datetime "Y-m-d H:i:s")
 *
 * Designed to be fast:
 *   - One UNION ALL query that pulls the timestamp + event name from every relevant table
 *   - Indexed lookups by user_id everywhere
 */
// header('Content-Type: application/json');
// header('Cache-Control: no-cache, no-store, must-revalidate');
// ini_set('display_errors', 0);
// ob_start();

// chdir('/home/istudio/public_html/cit/common');
// include '/home/istudio/public_html/cit/common/helper.php';
// ob_clean();

// global $conn;
// if (!$conn) { echo json_encode(['status'=>'error','message'=>'DB connection missing']); exit; }

// $action = $_REQUEST['action'] ?? 'timeline';

// /* ── resolve user_id (allow email lookup as a convenience) ── */
// function resolveUserId($conn) {
//     $uid = (int)($_REQUEST['user_id'] ?? 0);
//     if ($uid > 0) return $uid;

//     $email = trim($_REQUEST['email'] ?? '');
//     if ($email === '') return 0;
//     $email = mysqli_real_escape_string($conn, $email);
//     $r = mysqli_query($conn, "SELECT user_id FROM users WHERE email='$email' LIMIT 1");
//     if ($r && $row = mysqli_fetch_assoc($r)) return (int)$row['user_id'];
//     return 0;
// }

// /* ════════════════════════════════════════
//   ACTION: timeline
//   Identifies each occurrence by (event, user_id, ts) — no per-table id needed.
// ════════════════════════════════════════ */
// if ($action === 'timeline') {
//     $userId = resolveUserId($conn);
//     if (!$userId) { echo json_encode(['status'=>'error','message'=>'Missing or invalid user_id/email']); exit; }

//     $sql = "
//       SELECT 'register'                 AS event, registered_at AS ts FROM users                       WHERE user_id=$userId
//       UNION ALL
//       SELECT 'signin'                   AS event, created_at    AS ts FROM signin_log                  WHERE user_id=$userId
//       UNION ALL
//       SELECT 'exam_success'             AS event, `timestamp`   AS ts FROM cit_results                 WHERE user_id=$userId
//       UNION ALL
//       SELECT 'course_purchase'          AS event, `timestamp`   AS ts FROM payment_status              WHERE user_id=$userId AND status='initiated'
//       UNION ALL
//       SELECT 'payment_success'          AS event, `timestamp`   AS ts FROM payment_status              WHERE user_id=$userId AND status='success'
//       UNION ALL
//       SELECT 'preferred_domain'         AS event, created_at    AS ts FROM user_slected_domain_new     WHERE user_id=$userId
//       UNION ALL
//       SELECT 'visited_iap'              AS event, visited_at    AS ts FROM user_iap_visits             WHERE user_id=$userId
//       UNION ALL
//       SELECT 'result_view'              AS event, viewed_at     AS ts FROM score_view_logs             WHERE user_id=$userId
//       UNION ALL
//       SELECT 'placement_community_link' AS event, assigned_at   AS ts FROM assigned_links              WHERE user_id=$userId
//       UNION ALL
//       SELECT 'placement_community_link' AS event, assigned_at   AS ts FROM assigned_links_for_refund   WHERE user_id=$userId
//       UNION ALL
//       SELECT 'instantexam_reminder'     AS event, created_at    AS ts FROM set_reminder                WHERE user_id=$userId
//       UNION ALL
//       SELECT 'course_edit'              AS event, created_at    AS ts FROM internship_edit_logs        WHERE user_id=$userId
//       ORDER BY ts DESC
//       LIMIT 500
//     ";

//     $res    = mysqli_query($conn, $sql);
//     $events = [];
//     if ($res) while ($row = mysqli_fetch_assoc($res)) {
//         $events[] = [
//             'event'     => $row['event'],
//             'user_id'   => $userId,
//             'timestamp' => $row['ts'],
//         ];
//     }
//     /* SQL already returns DESC (most recent first) — keep it that way so the newest event is at the TOP. */

//     /* basic profile snippet for the page header (incl. photo) */
//     $r = mysqli_query($conn, "SELECT user_id, email, fname, lname, phone, photo, registered_at
//                               FROM users WHERE user_id=$userId LIMIT 1");
//     $profile = $r ? mysqli_fetch_assoc($r) : null;

//     /* drop placeholder avatars so the UI can show initials instead */
//     if ($profile && !empty($profile['photo'])) {
//         $placeholder = 'https://hire.internshipstudio.com/assets/img/avatars/avatar_placeholder.png';
//         if ($profile['photo'] === $placeholder) $profile['photo'] = null;
//     }

//     /* device used to register (mobile / desktop) — from store_full_url, most recent row */
//     $device = null;
//     $r = mysqli_query($conn, "SELECT device FROM store_full_url WHERE user_id=$userId ORDER BY created_at DESC LIMIT 1");
//     if ($r && $row = mysqli_fetch_assoc($r)) $device = $row['device'];

//     echo json_encode([
//         'status'  => 'success',
//         'profile' => $profile,
//         'device'  => $device,
//         'events'  => $events,
//     ]);
//     exit;
// }

// /* ════════════════════════════════════════
//   ACTION: event_detail
//   Looks up the row by (user_id, exact timestamp) on the right source table.
// ════════════════════════════════════════ */
// if ($action === 'event_detail') {
//     $event = $_REQUEST['event']   ?? '';
//     $uid   = (int)($_REQUEST['user_id'] ?? 0);
//     $ts    = mysqli_real_escape_string($conn, $_REQUEST['ts'] ?? '');
//     if ($event === '' || !$uid || $ts === '') { echo json_encode(['status'=>'error','message'=>'Missing event/user_id/ts']); exit; }

//     /* table + datetime column for each event */
//     $eventTable = [
//         'register'                 => ['tables' => [['users',                   'registered_at']]],
//         'signin'                   => ['tables' => [['signin_log',              'created_at']]],
//         'exam_success'             => ['tables' => [['cit_results',             '`timestamp`']]],
//         'course_purchase'          => ['tables' => [['payment_status',          '`timestamp`']], 'extra' => "AND status='initiated'"],
//         'payment_success'          => ['tables' => [['payment_status',          '`timestamp`']], 'extra' => "AND status='success'"],
//         'preferred_domain'         => ['tables' => [['user_slected_domain_new', 'created_at']]],
//         'visited_iap'              => ['tables' => [['user_iap_visits',         'visited_at']]],
//         'result_view'              => ['tables' => [['score_view_logs',         'viewed_at']]],
//         'instantexam_reminder'     => ['tables' => [['set_reminder',            'created_at']]],
//         'course_edit'              => ['tables' => [['internship_edit_logs',    'created_at']]],
//         /* placement_community_link spans two tables — try both */
//         'placement_community_link' => ['tables' => [
//             ['assigned_links',            'assigned_at'],
//             ['assigned_links_for_refund', 'assigned_at'],
//         ]],
//     ];

//     if (!isset($eventTable[$event])) { echo json_encode(['status'=>'error','message'=>'Unknown event']); exit; }
//     $extra = $eventTable[$event]['extra'] ?? '';

//     foreach ($eventTable[$event]['tables'] as [$tbl, $col]) {
//         $q = "SELECT * FROM $tbl WHERE user_id=$uid AND $col='$ts' $extra LIMIT 1";
//         $r = mysqli_query($conn, $q);
//         if ($r && $row = mysqli_fetch_assoc($r)) {
//             /* drop heavy/sensitive columns */
//             foreach (['password','token','employer_password','employer_password_plain','user_agent'] as $strip) {
//                 if (array_key_exists($strip, $row)) unset($row[$strip]);
//             }
//             echo json_encode(['status'=>'success','event'=>$event,'table'=>$tbl,'data'=>$row]);
//             exit;
//         }
//     }

//     echo json_encode(['status'=>'error','message'=>'Row not found']);
//     exit;
// }

// echo json_encode(['status'=>'error','message'=>'Invalid action']);
// exit;


























/*
 * /api/netcore/user_timeline.php
 *
 * GET / POST actions:
 *   action=timeline     → all events the given user has triggered, newest first
 *     params: user_id (int, required)  OR  email (string)
 *   action=event_detail → full row for one event occurrence
 *     params: event (string), user_id (int), ts (datetime "Y-m-d H:i:s")
 *
 * Designed to be fast:
 *   - One UNION ALL query that pulls the timestamp + event name from every relevant table
 *   - Indexed lookups by user_id everywhere
 */
header('Content-Type: application/json');
header('Cache-Control: no-cache, no-store, must-revalidate');
ini_set('display_errors', 0);
ob_start();

chdir('/home/istudio/public_html/cit/common');
include '/home/istudio/public_html/cit/common/helper.php';
ob_clean();

global $conn;
if (!$conn) { echo json_encode(['status'=>'error','message'=>'DB connection missing']); exit; }

$action = $_REQUEST['action'] ?? 'timeline';

/* ── resolve user_id (allow email lookup as a convenience) ── */
function resolveUserId($conn) {
    $uid = (int)($_REQUEST['user_id'] ?? 0);
    if ($uid > 0) return $uid;

    $email = trim($_REQUEST['email'] ?? '');
    if ($email === '') return 0;
    $email = mysqli_real_escape_string($conn, $email);
    $r = mysqli_query($conn, "SELECT user_id FROM users WHERE email='$email' LIMIT 1");
    if ($r && $row = mysqli_fetch_assoc($r)) return (int)$row['user_id'];
    return 0;
}

/* ════════════════════════════════════════
   ACTION: timeline
   Identifies each occurrence by (event, user_id, ts) — no per-table id needed.
════════════════════════════════════════ */
if ($action === 'timeline') {
    $userId = resolveUserId($conn);
    if (!$userId) { echo json_encode(['status'=>'error','message'=>'Missing or invalid user_id/email']); exit; }

    $t0 = microtime(true); $timing = [];
    $lap = function ($k) use (&$t0, &$timing) { $n = microtime(true); $timing[$k] = (int) round(($n - $t0) * 1000); $t0 = $n; return $timing; };
    $sql = "
      SELECT 'register'                 AS event, registered_at AS ts FROM users                       WHERE user_id=$userId
      UNION ALL
      SELECT 'signin'                   AS event, created_at    AS ts FROM signin_log                  WHERE user_id=$userId
      UNION ALL
      SELECT 'exam_success'             AS event, `timestamp`   AS ts FROM cit_results                 WHERE user_id=$userId
      UNION ALL
      SELECT 'course_purchase'          AS event, `timestamp`   AS ts FROM payment_status              WHERE user_id=$userId AND status='initiated'
      UNION ALL
      SELECT 'payment_success'          AS event, `timestamp`   AS ts FROM payment_status              WHERE user_id=$userId AND status='success'
      UNION ALL
      SELECT 'preferred_domain'         AS event, created_at    AS ts FROM user_slected_domain_new     WHERE user_id=$userId
      UNION ALL
      SELECT 'visited_iap'              AS event, visited_at    AS ts FROM user_iap_visits             WHERE user_id=$userId
      UNION ALL
      SELECT 'result_view'              AS event, viewed_at     AS ts FROM score_view_logs             WHERE user_id=$userId
      UNION ALL
      SELECT 'placement_community_link' AS event, assigned_at   AS ts FROM assigned_links              WHERE user_id=$userId
      UNION ALL
      SELECT 'placement_community_link' AS event, assigned_at   AS ts FROM assigned_links_for_refund   WHERE user_id=$userId
      UNION ALL
      SELECT 'link_assigned'            AS event, assigned_at   AS ts FROM assigned_links              WHERE user_id=$userId
      UNION ALL
      SELECT 'link_assigned'            AS event, assigned_at   AS ts FROM assigned_links_for_refund   WHERE user_id=$userId
      UNION ALL
      SELECT 'instantexam_reminder'     AS event, created_at    AS ts FROM set_reminder                WHERE user_id=$userId
      UNION ALL
      SELECT 'course_edit'              AS event, created_at    AS ts FROM internship_edit_logs        WHERE user_id=$userId
      UNION ALL
      SELECT 'exam_reminder'            AS event, created_at    AS ts FROM instant_exam_reminder_logs       WHERE user_id=$userId
      UNION ALL
      SELECT 'project_submission_reminder' AS event, created_at AS ts FROM project_submission_reminder_logs WHERE user_id=$userId
      UNION ALL
      SELECT 'one_day_before_batch_start' AS event, created_at  AS ts FROM one_day_before_batch_start_logs  WHERE user_id=$userId
      UNION ALL
      SELECT 'batch_end_reminder'       AS event, created_at    AS ts FROM same_day_batch_end_logs          WHERE user_id=$userId
      UNION ALL
      SELECT 'came_on_dashboard'        AS event, CONCAT(login_date, ' 00:00:00') AS ts
        FROM user_login_activity WHERE user_id=$userId
      UNION ALL
      /* mark_attendance (cutoff 2026-05-13):
           • Before cutoff → login_date alone counts as an attendance.
           • On/after cutoff → login_date only counts when an attendance_log row also exists.
         The ts is attendance_log.marked_at when available, else midnight of login_date. */
      SELECT 'mark_attendance' AS event,
             CASE
               WHEN ula.login_date >= '2026-05-13' THEN COALESCE(
                   (SELECT MIN(al.marked_at) FROM attendance_log al
                    WHERE al.user_id = ula.user_id AND al.attendance_date = ula.login_date),
                   CONCAT(ula.login_date, ' 00:00:00')
               )
               ELSE CONCAT(ula.login_date, ' 00:00:00')
             END AS ts
      FROM user_login_activity ula
      WHERE ula.user_id = $userId
        AND (
          ula.login_date < '2026-05-13'
          OR EXISTS (
              SELECT 1 FROM attendance_log al
              WHERE al.user_id = ula.user_id AND al.attendance_date = ula.login_date
          )
        )
      ORDER BY ts DESC
      LIMIT 500
    ";

    $res    = mysqli_query($conn, $sql);
    $events = [];
    if ($res) while ($row = mysqli_fetch_assoc($res)) {
        $events[] = [
            'event'     => $row['event'],
            'user_id'   => $userId,
            'timestamp' => $row['ts'],
        ];
    }

    /*
     * WHAT WE SENT THEM, merged into what they did.
     *
     * Kept out of the union above on purpose — see lib/MessageTimeline.php. Wrapped because this
     * reads campaign and journey tables that a stripped-down install may not have, and a missing
     * one must cost the messaging half of the timeline rather than the whole page.
     */
    $lap('activity');
    $profileEmail = '';
    $pe = mysqli_query($conn, "SELECT email FROM users WHERE user_id=$userId LIMIT 1");
    if ($pe && $prow = mysqli_fetch_assoc($pe)) $profileEmail = (string)$prow['email'];

    try {
        require_once __DIR__ . '/lib/MessageTimeline.php';
        foreach (message_timeline_events($userId, $profileEmail) as $m) {
            $events[] = $m + ['user_id' => $userId];
        }
        /* One clock for both halves. Re-sorted after the merge because the two were each ordered
           on their own, and interleaving them is the entire point of putting them together. */
        usort($events, fn($a, $b) => strcmp((string)$b['timestamp'], (string)$a['timestamp']));
        if (count($events) > 500) $events = array_slice($events, 0, 500);
    } catch (Throwable $e) {
        error_log('[user_timeline] messaging events unavailable: ' . $e->getMessage());
    }

    $lap('messages');
    /* Ads they arrived through — by the same browser, or from their network (lib/AdJourney.php).
       Carries its own details, so the popup needs no event_detail round-trip. */
    try {
        require_once __DIR__ . '/../lib/AdJourney.php';
        $journey = ad_journey_collect($conn, [$userId])[$userId] ?? ['visits' => []];
        foreach ($journey['visits'] as $v) {
            $events[] = [
                'event'     => 'ad_visit',
                'user_id'   => $userId,
                'timestamp' => $v['visited_at'],
                'title'     => $v['ad_label'],
                'detail'    => trim(($v['source'] ?: 'unknown source') . ' · '
                    . ($v['match_type'] === 'device' ? 'same browser' : 'same network (IPv' . $v['ip_version'] . ')')
                    . ($v['before_register'] === true ? ' · before signup' : '')),
                'ad'        => $v,
            ];
        }
        usort($events, fn($a, $b) => strcmp((string)$b['timestamp'], (string)$a['timestamp']));
        if (count($events) > 500) $events = array_slice($events, 0, 500);
    } catch (Throwable $e) {
        error_log('[user_timeline] ad visits unavailable: ' . $e->getMessage());
    }
    $lap('ads');
    /* SQL already returns DESC (most recent first) — keep it that way so the newest event is at the TOP. */

    /* basic profile snippet for the page header (incl. photo) */
    $r = mysqli_query($conn, "SELECT user_id, email, fname, lname, phone, photo, registered_at
                              FROM users WHERE user_id=$userId LIMIT 1");
    $profile = $r ? mysqli_fetch_assoc($r) : null;

    /* drop placeholder avatars so the UI can show initials instead */
    if ($profile && !empty($profile['photo'])) {
        $placeholder = 'https://hire.internshipstudio.com/assets/img/avatars/avatar_placeholder.png';
        if ($profile['photo'] === $placeholder) $profile['photo'] = null;
    }

    /* device used to register (mobile / desktop) — from store_full_url, most recent row */
    $device = null;
    $r = mysqli_query($conn, "SELECT device FROM store_full_url WHERE user_id=$userId ORDER BY created_at DESC LIMIT 1");
    if ($r && $row = mysqli_fetch_assoc($r)) $device = $row['device'];

    echo json_encode([
        'status'  => 'success',
        'profile' => $profile,
        'device'  => $device,
        'events'  => $events,
        'timing_ms' => $lap('profile'),  // per section, to find what is slow
    ]);
    exit;
}

/* ════════════════════════════════════════
   ACTION: event_detail
   Looks up the row by (user_id, exact timestamp) on the right source table.
════════════════════════════════════════ */
if ($action === 'event_detail') {
    $event = $_REQUEST['event']   ?? '';
    $uid   = (int)($_REQUEST['user_id'] ?? 0);
    $ts    = mysqli_real_escape_string($conn, $_REQUEST['ts'] ?? '');
    if ($event === '' || !$uid || $ts === '') { echo json_encode(['status'=>'error','message'=>'Missing event/user_id/ts']); exit; }

    /* table + datetime column for each event */
    $eventTable = [
        'register'                 => ['tables' => [['users',                   'registered_at']]],
        'signin'                   => ['tables' => [['signin_log',              'created_at']]],
        'exam_success'             => ['tables' => [['cit_results',             '`timestamp`']]],
        'course_purchase'          => ['tables' => [['payment_status',          '`timestamp`']], 'extra' => "AND status='initiated'"],
        'payment_success'          => ['tables' => [['payment_status',          '`timestamp`']], 'extra' => "AND status='success'"],
        'preferred_domain'         => ['tables' => [['user_slected_domain_new', 'created_at']]],
        'visited_iap'              => ['tables' => [['user_iap_visits',         'visited_at']]],
        'result_view'              => ['tables' => [['score_view_logs',         'viewed_at']]],
        'instantexam_reminder'     => ['tables' => [['set_reminder',            'created_at']]],
        'course_edit'              => ['tables' => [['internship_edit_logs',    'created_at']]],
        /* placement_community_link spans two tables — try both */
        'placement_community_link' => ['tables' => [
            ['assigned_links',            'assigned_at'],
            ['assigned_links_for_refund', 'assigned_at'],
        ]],
        /* link_assigned shares the same source tables as placement_community_link */
        'link_assigned' => ['tables' => [
            ['assigned_links',            'assigned_at'],
            ['assigned_links_for_refund', 'assigned_at'],
        ]],
        'exam_reminder'               => ['tables' => [['instant_exam_reminder_logs',    'created_at']]],
        'project_submission_reminder' => ['tables' => [['project_submission_reminder_logs','created_at']]],
        'one_day_before_batch_start'  => ['tables' => [['one_day_before_batch_start_logs','created_at']]],
        'batch_end_reminder'          => ['tables' => [['same_day_batch_end_logs',       'created_at']]],
    ];

    /* mark_attendance is sourced from two tables depending on the cutoff date.
       Before 2026-05-13 → row lives in user_login_activity (login_date = DATE(ts)).
       On/after cutoff  → primary row lives in attendance_log (marked_at = ts).
       Fall back to user_login_activity if no attendance_log row matches exactly. */
    if ($event === 'mark_attendance') {
        $tsDate = substr($ts, 0, 10);
        $cutoff = '2026-05-13';

        if ($tsDate < $cutoff) {
            $q = "SELECT * FROM user_login_activity WHERE user_id=$uid AND login_date='$tsDate' LIMIT 1";
        } else {
            $q = "SELECT * FROM attendance_log WHERE user_id=$uid AND marked_at='$ts' LIMIT 1";
        }
        $r = mysqli_query($conn, $q);
        if ($r && $row = mysqli_fetch_assoc($r)) {
            foreach (['password','token','user_agent'] as $strip) {
                if (array_key_exists($strip, $row)) unset($row[$strip]);
            }
            echo json_encode(['status'=>'success','event'=>$event,'data'=>$row]);
            exit;
        }
        /* fallback — show the login_activity row so the popup isn't empty for edge cases */
        $q2 = "SELECT * FROM user_login_activity WHERE user_id=$uid AND login_date='$tsDate' LIMIT 1";
        $r2 = mysqli_query($conn, $q2);
        if ($r2 && $row = mysqli_fetch_assoc($r2)) {
            echo json_encode(['status'=>'success','event'=>$event,'data'=>$row]);
            exit;
        }
        echo json_encode(['status'=>'error','message'=>'Row not found']);
        exit;
    }

    /* link_assigned → fetch assigned_links row + join WA link (community_link) so payload includes wa_link.
       Falls back to the refund tables if the row isn't found in the non-refund pair. */
    if ($event === 'link_assigned') {
        $tries = [
            ['assigned_links',            'whatsapp_placement_club_link'],
            ['assigned_links_for_refund', 'whatsapp_placement_club_link_for_refund'],
        ];
        foreach ($tries as [$alTbl, $waTbl]) {
            $q = "SELECT al.*, wp.community_link AS wa_link, wp.community_name AS wa_community, wp.status AS wa_status
                  FROM $alTbl al
                  LEFT JOIN $waTbl wp ON wp.id = al.assigned_id
                  WHERE al.user_id=$uid AND al.assigned_at='$ts'
                  LIMIT 1";
            $r = mysqli_query($conn, $q);
            if ($r && $row = mysqli_fetch_assoc($r)) {
                $row['source'] = ($alTbl === 'assigned_links_for_refund') ? 'refund' : 'non_refund';
                echo json_encode(['status'=>'success','event'=>$event,'table'=>$alTbl,'data'=>$row]);
                exit;
            }
        }
        echo json_encode(['status'=>'error','message'=>'Row not found']);
        exit;
    }

    /* came_on_dashboard → user_login_activity, keyed by DATE(ts) since login_date is a DATE column */
    if ($event === 'came_on_dashboard') {
        $tsDate = substr($ts, 0, 10);
        $q = "SELECT * FROM user_login_activity WHERE user_id=$uid AND login_date='$tsDate' LIMIT 1";
        $r = mysqli_query($conn, $q);
        if ($r && $row = mysqli_fetch_assoc($r)) {
            echo json_encode(['status'=>'success','event'=>$event,'data'=>$row]);
            exit;
        }
        echo json_encode(['status'=>'error','message'=>'Row not found']);
        exit;
    }

    if (!isset($eventTable[$event])) { echo json_encode(['status'=>'error','message'=>'Unknown event']); exit; }
    $extra = $eventTable[$event]['extra'] ?? '';

    foreach ($eventTable[$event]['tables'] as [$tbl, $col]) {
        $q = "SELECT * FROM $tbl WHERE user_id=$uid AND $col='$ts' $extra LIMIT 1";
        $r = mysqli_query($conn, $q);
        if ($r && $row = mysqli_fetch_assoc($r)) {
            /* drop heavy/sensitive columns */
            foreach (['password','token','employer_password','employer_password_plain','user_agent'] as $strip) {
                if (array_key_exists($strip, $row)) unset($row[$strip]);
            }
            echo json_encode(['status'=>'success','event'=>$event,'table'=>$tbl,'data'=>$row]);
            exit;
        }
    }

    echo json_encode(['status'=>'error','message'=>'Row not found']);
    exit;
}

echo json_encode(['status'=>'error','message'=>'Invalid action']);
exit;
?>

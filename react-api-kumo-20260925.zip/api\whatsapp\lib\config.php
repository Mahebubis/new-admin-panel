<?php
/*
 * WhatsApp Campaigns — tunables and shared constants.
 *
 * Deliberately a SEPARATE file from campaigns/lib/config.php even though the two look
 * similar: WhatsApp throughput is governed by the WABA's own messaging limit (shown in the
 * Netcore panel, e.g. "100000 messages per 24hrs"), not by an ESP's per-second API budget,
 * so these numbers are tuned independently and must never drift because someone retuned
 * email.
 */

/*
 * Bumped whenever this API gains something the frontend depends on. The Settings page compares
 * it against what the built JS expects and says so plainly when they disagree.
 *
 * This exists because public/react-api deploys separately from the React build (it's gitignored
 * — see the deploy notes), so it is entirely possible to be looking at a new settings screen
 * driven by an old backend, where a field you just filled in is silently ignored.
 *
 *   1  first release
 *   2  multiple sending numbers (wa_senders)
 *   3  API key stored PER sending number; `source` optional
 *   4  template sync via Meta's Graph API (Netcore's messaging API has no template endpoint)
 *   5  per-number provider: send via Meta Cloud API directly, or via Netcore
 *   6  Netcore removed entirely; phone-number registration + status via Meta
 *   7  Live Chat inbox — wa_conversations/wa_messages, inbound webhook ingestion, media proxy
 */
if (!defined('WA_API_VERSION')) define('WA_API_VERSION', 7);

/*
 * Meta Graph API version used for template management.
 *
 * Templates are approved by META, not by Netcore, so the authoritative list lives on the WABA
 * and is read straight from Meta: GET /{waba_id}/message_templates. Netcore's messaging API
 * (waapi.pepipost.com) has no template endpoint at all — its full documented surface is
 * consent, send-message, template-MESSAGE (sending one), media, webhooks and reports.
 */
if (!defined('WA_GRAPH_VERSION')) define('WA_GRAPH_VERSION', 'v21.0');
if (!defined('WA_GRAPH_BASE'))    define('WA_GRAPH_BASE', 'https://graph.facebook.com/');

/*
 * Shared secret guarding the HTTP fallback path of whatsapp-send-worker.php (the CLI-cron
 * path doesn't need it). Same idea as campaigns/lib/config.php's CRON_SECRET but a distinct
 * value, so leaking one worker's kick URL doesn't hand over the other channel too.
 */
if (!defined('WA_CRON_SECRET')) {
    define('WA_CRON_SECRET', 'wa_3d7b1f8a5c2e9046b3d8f1a7c4e0b9d6f2a8c5e3b0d7f4a1c8e6b2d9f0a3c7e5');
}

/*
 * Concurrent sends in flight (curl_multi — see lib/WaParallelSender.php). Lower than the
 * email pipeline's 32 on purpose: WhatsApp providers rate-limit far more aggressively than
 * bulk-email APIs, and a 429 storm here costs a retry cycle on every number in the batch.
 * Raise in steps and watch wa-worker.log for 'rate-limited/retryable' lines.
 */
if (!defined('WA_SEND_CONCURRENCY'))  define('WA_SEND_CONCURRENCY', 24);

/*
 * Per-route override, because the two providers have very different ceilings.
 *
 * Meta Cloud API publishes its own limit — 80 messages/second on a healthy number, rising to
 * 500 on request — and answers a 429 cleanly, so a wider window is safe and is the only lever
 * that raises throughput at all on that route: POST /{phone_number_id}/messages takes exactly
 * one recipient, and Meta has no bulk send endpoint.
 *
 * Netcore sits in front of that same Meta limit with its own undocumented budget on top, and
 * rate-limits harder and less predictably, so it stays lower. Raise either in steps and watch
 * wa-worker.log for 'rate-limited/retryable' lines — a 429 storm costs a whole retry cycle and
 * is slower than the smaller window would have been.
 */
if (!defined('WA_SEND_CONCURRENCY_META'))    define('WA_SEND_CONCURRENCY_META', 48);
if (!defined('WA_SEND_CONCURRENCY_NETCORE')) define('WA_SEND_CONCURRENCY_NETCORE', 24);

/** The window for one route, falling back to the shared default for an unknown provider. */
function wa_concurrency_for(string $provider): int {
    if ($provider === 'meta')    return WA_SEND_CONCURRENCY_META;
    if ($provider === 'netcore') return WA_SEND_CONCURRENCY_NETCORE;
    return WA_SEND_CONCURRENCY;
}

/** Recipients claimed from the queue per batch — comfortably above the concurrency so the
 *  in-flight window stays saturated, small enough that a crashed run strands little. */
if (!defined('WA_SEND_BATCH_SIZE'))   define('WA_SEND_BATCH_SIZE', 200);

/** How long one worker invocation keeps pulling batches before exiting. flock() means an
 *  overlapping cron tick simply no-ops, so a long run is safe. */
if (!defined('WA_WORKER_MAX_RUNTIME_SECONDS')) define('WA_WORKER_MAX_RUNTIME_SECONDS', 240);

/** Pause after a batch that hit provider rate-limiting, so the next batch doesn't
 *  immediately hammer the same window. */
if (!defined('WA_RATE_LIMIT_BACKOFF_SECONDS')) define('WA_RATE_LIMIT_BACKOFF_SECONDS', 3);

/** Three strikes and a recipient is permanently failed (provider-busy responses don't
 *  consume an attempt — see WaSendWorker.php's retryable handling). */
if (!defined('WA_MAX_ATTEMPTS')) define('WA_MAX_ATTEMPTS', 3);

/** Every worker run appends one line per event here — "did cron run", "how many numbers did
 *  it resolve", "what did Meta actually say" are all answerable without SSH/DB access. */
if (!defined('WA_WORKER_LOG_PATH')) define('WA_WORKER_LOG_PATH', __DIR__ . '/../wa-worker.log');

/*
 * Ceiling for that log, above which the oldest half is dropped (see wa_log()).
 *
 * It needs one: the webhook writes a line per callback, and this endpoint receives events for
 * EVERY app subscribed to the WABA — including a BSP's own campaign traffic. On a busy account
 * that is tens of thousands of lines a day against a shared-hosting disk quota, and an append-
 * only file with no ceiling eventually takes the whole site down rather than just filling up.
 *
 * 8 MB is roughly a week of heavy traffic — long enough to debug yesterday's campaign, small
 * enough to never matter.
 */
if (!defined('WA_LOG_MAX_BYTES')) define('WA_LOG_MAX_BYTES', 8 * 1024 * 1024);

/*
 * There is deliberately no API base constant here any more.
 *
 * The Netcore BSP endpoint (waapi.pepipost.com) used to be seeded into wa_settings.api_base_url.
 * Nothing has read that column since the switch to Meta Cloud API — every request is built from
 * WA_GRAPH_BASE above — but leaving a competitor's URL sitting in the settings response made it
 * look like traffic still went there. The column is now blanked on upgrade (see schema.php) and
 * kept out of the API response entirely.
 */

/** Applied to any audience phone number stored without a country code (the common case for
 *  Indian student records: a bare 10-digit mobile). Configurable in Settings. */
if (!defined('WA_DEFAULT_COUNTRY_CODE')) define('WA_DEFAULT_COUNTRY_CODE', '91');

/** Public host used for the fire-and-forget "Send now" worker kick — same host the email
 *  pipeline uses (see campaigns/lib/SendWorker.php's trigger_worker_async()). */
if (!defined('WA_WORKER_HOST')) define('WA_WORKER_HOST', 'cit3.internshipstudio.com');
if (!defined('WA_WORKER_PATH')) define('WA_WORKER_PATH', '/admin/react-api/api/whatsapp/whatsapp-send-worker.php');

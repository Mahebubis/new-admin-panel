<?php
/*
 * Public receiver for Elastic Email's HTTP web notifications — the Elastic Email
 * counterpart of sendgrid-webhook.php. Configure at:
 *   Elastic Email dashboard → Settings → Notifications → Manage webhooks
 *   → URL = this file's public URL, with Sent / Error / Unsubscribed / AbuseReport
 *     events enabled (Opened / Clicked are NOT needed — see below).
 *
 * !! PLAN NOTE: webhooks are a PRO-plan feature at Elastic Email. On the Free
 * plan the "Manage webhooks" link in their dashboard is padlocked, nothing will ever
 * POST here, and campaigns sent via this transport would show sent_count but
 * delivered_count = 0 and bounce_count = 0.
 *
 * That is what elasticemail-events-poll.php is for: it PULLS the same events from
 * GET /v4/events, which is not plan-gated, and feeds them through the very same
 * handler this file uses (lib/ElasticEmailEventSink.php). Run one or the other —
 * the webhook if the plan allows it, the poller otherwise. Running both is harmless
 * (every write in the sink is idempotent) but pointless.
 *
 * Open and click counts are unaffected either way — those are first-party
 * (track-open.php / track-click.php), not provider-reported.
 *
 * Two differences from SendGrid's webhook that shape this file:
 *   1. Elastic Email delivers ONE event per request as ordinary request parameters
 *      (query string / form fields), not a JSON array of many events. A JSON body
 *      is still accepted below as a fallback in case a future/PRO variant posts one.
 *   2. Correlation comes from `postback` — the arbitrary passthrough string we set to
 *      our rid in lib/ElasticEmailTransport.php. If it's missing we fall back to
 *      matching `messageid` against email_campaign_recipients.esp_message_id (indexed),
 *      which the transport stored from the send response. (The poller only ever has the
 *      second of those, which is why that fallback is load-bearing rather than belt-and-braces.)
 */
ini_set('display_errors', 0);
error_reporting(0);
header('Content-Type: application/json');

require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/lib/ElasticEmailEventSink.php';

// Accept params in whichever shape arrives: query string, form POST, or a JSON body.
$params = $_REQUEST;
$raw = file_get_contents('php://input');
if ($raw !== '' && $raw !== false) {
    $json = json_decode($raw, true);
    if (is_array($json)) {
        // A JSON body may itself be a single event object or a list of them; normalize
        // to a list so the loop below handles both without branching.
        $events = isset($json[0]) && is_array($json[0]) ? $json : [$json];
    } else {
        $events = [$params];
    }
} else {
    $events = [$params];
}

$processed = 0;
foreach ($events as $evt) {
    if (!is_array($evt)) continue;
    // Elastic Email posts every event for the account here, so the sink is also what
    // decides an event belongs to a journey rather than a campaign, or to neither.
    if (ee_handle_event($evt)) $processed++;
}

http_response_code(200);
echo json_encode(['ok' => true, 'processed' => $processed]);

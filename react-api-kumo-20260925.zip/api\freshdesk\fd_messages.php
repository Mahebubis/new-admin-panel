<?php
/*
 * /api/freshdesk/fd_messages.php
 *
 * The conversation: reading a thread, and everything an agent can put into it.
 *
 *   action=thread   &ticket_id                 -> full conversation
 *   action=reply    &ticket_id &body &to &cc &bcc &attachment_ids[]
 *   action=forward  &ticket_id &to &body &cc &bcc &attachment_ids[] &include_attachments
 *   action=note     &ticket_id &body           -> private, never emailed
 *   action=retry    &message_id                -> resend one failed message
 *   action=delete_note &message_id
 *   action=drafts / save_draft / discard_draft
 *
 * The reply/forward paths all funnel into FdMailer::sendTicketMessage(), which
 * owns threading headers, the Sent-folder copy and the failure bookkeeping.
 */

require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../middleware/auth.php';
require_once __DIR__ . '/lib/config.php';
require_once __DIR__ . '/lib/Helpers.php';
require_once __DIR__ . '/lib/schema.php';
require_once __DIR__ . '/lib/Sla.php';
require_once __DIR__ . '/lib/Automation.php';
require_once __DIR__ . '/lib/Pusher.php';
require_once __DIR__ . '/lib/ImapClient.php';
require_once __DIR__ . '/lib/MimeParser.php';
require_once __DIR__ . '/lib/Storage.php';
require_once __DIR__ . '/lib/TicketStore.php';
require_once __DIR__ . '/lib/Mailer.php';

$jwt = require_jwt();
require_permission('freshdesk', $jwt);
fd_install_error_handlers();
fd_ensure_schema();

$ME = array(
    'id'   => isset($jwt['user_id']) ? (int)$jwt['user_id'] : null,
    'name' => isset($jwt['name']) ? $jwt['name'] : 'Agent',
);


$action = fd_str('action', 'thread');
$GLOBALS['FD_ACTION'] = $action;

/* ---------------------------------------------------------------- thread -- */
if ($action === 'thread') {
    $ticketId = fd_int('ticket_id', 0);
    if ($ticketId <= 0) api_error('ticket_id is required', 400);

    $rows = fd_query(
        "SELECT id, direction, msg_type, from_name, from_email, to_emails, cc_emails, subject,
                body_html, body_text, has_attachments, attachment_count, delivery_status, delivery_error,
                sent_by_name, message_date, created_at, is_auto_reply
         FROM fd_messages WHERE ticket_id = ? ORDER BY id ASC", 'i', array($ticketId)
    );

    $atts = fd_query("SELECT id, message_id, filename, mime_type, size_bytes, is_inline
                      FROM fd_attachments WHERE ticket_id = ?", 'i', array($ticketId));
    $byMsg = array();
    foreach ($atts as $a) {
        $byMsg[(int)$a['message_id']][] = array(
            'id' => (int)$a['id'], 'name' => $a['filename'], 'mime' => $a['mime_type'],
            'size' => (int)$a['size_bytes'], 'inline' => (bool)$a['is_inline'],
            'url' => fd_attachment_url((int)$a['id'], 'download'),
        );
    }

    $out = array();
    foreach ($rows as $m) {
        $mid = (int)$m['id'];
        $parts = fd_split_quoted_html($m['body_html']);
        $out[] = array(
            'id'   => $mid,
            'who'  => $m['direction'] === 'inbound' ? 'cust' : ($m['direction'] === 'note' ? 'note' : 'agent'),
            'type' => $m['msg_type'],
            'msg'  => $m['body_text'] !== '' ? fd_strip_quoted_text($m['body_text']) : fd_html_to_text($m['body_html']),
            'html' => fd_sign_html_attachments(fd_tidy_email_html($parts['visible'])),
            'quoted' => $parts['quoted'] === '' ? '' : fd_sign_html_attachments(fd_tidy_email_html($parts['quoted'])),
            'from' => $m['from_name'] ?: $m['from_email'],
            'at'   => date('j M, g:i a', strtotime($m['message_date'] ?: $m['created_at'])),
            'ago'  => fd_relative_time($m['message_date'] ?: $m['created_at']),
            'att'  => (bool)$m['has_attachments'],
            'attachments' => isset($byMsg[$mid]) ? $byMsg[$mid] : array(),
            /*
             * How many files the EMAIL carried, which is not always how many we
             * managed to keep. fd_store_attachments() drops anything over
             * FD_ATTACH_MAX_FILE_BYTES, anything past the per-message budget,
             * and anything S3 refused -- each with a log line and nothing else.
             * The agent saw a thread with no files and no reason, while the
             * customer was certain they had attached their CV. Sending the
             * parsed count lets the reader say so out loud.
             */
            'attCount' => (int)$m['attachment_count'],
            'status' => $m['delivery_status'],
            'error'  => $m['delivery_error'],
            'sentBy' => $m['sent_by_name'],
            'isAuto' => (bool)$m['is_auto_reply'],
        );
    }
    api_success(array('messages' => $out), 'OK');
}

/* ------------------------------------------------------------ reply/fwd -- */
if ($action === 'reply' || $action === 'forward') {
    $ticketId = fd_int('ticket_id', 0);
    if ($ticketId <= 0) api_error('ticket_id is required', 400);

    $ticket = fd_query_one("SELECT * FROM fd_tickets WHERE id = ?", 'i', array($ticketId));
    if (!$ticket) api_error('Ticket not found', 404);

    $bodyRaw = fd_str('body', '');
    if (trim(fd_html_to_text($bodyRaw)) === '' && $action === 'reply') {
        api_error('Write something before sending.', 400);
    }

    $to = fd_arr('to', array());
    if (empty($to)) {
        if ($action === 'forward') api_error('Enter at least one address to forward to.', 400);
        $to = array($ticket['requester_email']);
    }

    $body = fd_apply_merge_tags($bodyRaw, $ticket, $ME);
    $bodyHtml = fd_compose_html($body, fd_bool('is_html', null));

    /*
     * Forwarding carries the original conversation with it -- that is the point
     * of forwarding. Attachments are re-sent by default too, since a forward
     * without the customer's screenshot is usually useless to whoever receives
     * it, but the composer can turn that off for a large thread.
     */
    $attachmentIds = array_map('intval', fd_arr('attachment_ids', array()));
    if ($action === 'forward' && fd_bool('include_attachments', true)) {
        $existing = fd_query("SELECT id FROM fd_attachments WHERE ticket_id = ? AND is_inline = 0", 'i', array($ticketId));
        foreach ($existing as $e) $attachmentIds[] = (int)$e['id'];
        $attachmentIds = array_values(array_unique($attachmentIds));
    }

    $mailer = new FdMailer();
    if (!$mailer->isReady()) {
        api_error('Email sending is not available: ' . $mailer->loadError(), 500);
    }

    try {
        $res = $mailer->sendTicketMessage(array(
            'ticket_id'      => $ticketId,
            'type'           => $action,
            'body_html'      => $bodyHtml,
            'to'             => $to,
            'cc'             => fd_arr('cc', array()),
            'bcc'            => fd_arr('bcc', array()),
            'subject'        => fd_str('subject', ''),
            'attachment_ids' => $attachmentIds,
            'agent'          => $ME,
            'include_signature' => fd_bool('include_signature', true),
            'quote_history'  => fd_bool('quote_history', $action === 'forward'),
        ));
    } catch (Throwable $e) {
        api_error($e->getMessage(), 500);
    }

    // A failed send is a 200 with sent=false, not an HTTP error: the message row
    // exists, it is visible in the thread marked "not delivered", and the panel
    // needs the message id to offer Retry. Returning a 5xx here would make the
    // client discard a reply that is actually recoverable.
    if (empty($res['sent'])) {
        api_success(array(
            'sent'       => false,
            'message_id' => $res['message_id'],
            'error'      => $res['error'],
            'ticket'     => $ticketId,
        ), 'Could not send: ' . $res['error']);
    }

    if ($action === 'forward') {
        $told = fd_notify_emails(
            array_merge($to, fd_arr('cc', array())),
            'forwarded', $ticketId,
            $ME['name'] . ' forwarded ticket #' . $ticketId . ' to you',
            (string)$ticket['subject'],
            array('id' => $ME['id'], 'name' => $ME['name']));
        if (!empty($told)) {
            fd_log('debug', 'Forward notified: ' . implode(', ', $told), array('ticket' => $ticketId));
        }
    }

    $msg = fd_query_one("SELECT * FROM fd_messages WHERE id = ?", 'i', array((int)$res['message_id']));
    api_success(array(
        'sent'       => true,
        'message_id' => (int)$res['message_id'],
        'subject'    => $res['subject'],
        'message'    => array(
            'id'   => (int)$msg['id'],
            'who'  => 'agent',
            'type' => $msg['msg_type'],
            'msg'  => fd_html_to_text($msg['body_html']),
            'html' => fd_sign_html_attachments($msg['body_html']),
            'from' => $msg['from_name'],
            'at'   => date('j M, g:i a', strtotime($msg['created_at'])),
            'ago'  => 'just now',
            'att'  => (bool)$msg['has_attachments'],
            'status' => 'sent',
            'sentBy' => $msg['sent_by_name'],
        ),
    ), $action === 'forward' ? 'Forwarded' : 'Reply sent');
}

/* ------------------------------------------------------------------ note -- */
if ($action === 'note') {
    $ticketId = fd_int('ticket_id', 0);
    $bodyRaw  = fd_str('body', '');
    if ($ticketId <= 0) api_error('ticket_id is required', 400);
    if (trim($bodyRaw) === '') api_error('The note is empty.', 400);

    $ticket = fd_query_one("SELECT * FROM fd_tickets WHERE id = ?", 'i', array($ticketId));
    if (!$ticket) api_error('Ticket not found', 404);

    $html = fd_compose_html(fd_apply_merge_tags($bodyRaw, $ticket, $ME), fd_bool('is_html', null));

    /*
     * direction='note' is what keeps this off the wire. It is written to the
     * same table as replies so the thread reads in one order, but nothing in
     * the send path ever selects it, and fd_tickets.php renders it with
     * who='note' so the panel can shade it as private.
     */
    $id = fd_exec(
        "INSERT INTO fd_messages
            (ticket_id, direction, msg_type, from_name, from_email, subject, body_html, body_text,
             snippet, delivery_status, sent_by_user_id, sent_by_name, message_date, created_at)
         VALUES (?, 'note', 'note', ?, ?, ?, ?, ?, ?, 'received', ?, ?, NOW(), NOW())",
        'issssssis',
        array($ticketId, $ME['name'], null, 'Internal note',
              $html, fd_html_to_text($html), fd_snippet(fd_html_to_text($html), 250),
              $ME['id'], $ME['name']),
        true
    );

    fd_recount_ticket($ticketId);
    fd_exec("UPDATE fd_tickets SET updated_at = NOW() WHERE id = ?", 'i', array($ticketId));

    fd_activity($ticketId, 'note-added', $ME['name'] . ' added a private note on #' . $ticketId,
                array('type' => 'agent', 'id' => $ME['id'], 'name' => $ME['name']),
                array('message_id' => (int)$id));

    foreach (fd_note_mentions($html) as $uid => $name) {
        fd_notify_user($uid, 'mentioned', $ticketId,
            $ME['name'] . ' mentioned you on ticket #' . $ticketId,
            fd_snippet(fd_html_to_text($html), 200),
            array('id' => $ME['id'], 'name' => $ME['name']));
    }

    api_success(array('message_id' => (int)$id, 'message' => array(
        'id' => (int)$id, 'who' => 'note', 'type' => 'note',
        'msg' => fd_html_to_text($html), 'html' => $html,
        'from' => $ME['name'], 'at' => date('j M, g:i a'), 'ago' => 'just now',
        'att' => false, 'attachments' => array(), 'status' => 'received', 'sentBy' => $ME['name'],
    )), 'Note added');
}

/**
 * Which agents a note mentions.
 *
 * Longest name first: "@Priya Nair Kumar" must not match the "Priya Nair" who
 * is a different person. Matching is case-insensitive because nobody
 * capitalises a colleague's surname consistently at four in the afternoon.
 */
function fd_note_mentions($text)
{
    $text = ' ' . mb_strtolower(preg_replace('/\s+/', ' ', strip_tags((string)$text))) . ' ';
    if (strpos($text, '@') === false) return array();

    try {
        $agents = fd_query("SELECT u.user_id, u.name
                            FROM admin_users a
                            INNER JOIN users u ON u.user_id = a.user_id
                            WHERE a.is_active = 1 AND u.name IS NOT NULL AND u.name <> ''");
    } catch (Throwable $e) {
        return array();
    }

    usort($agents, function ($x, $y) {
        return mb_strlen((string)$y['name']) - mb_strlen((string)$x['name']);
    });

    $hits = array();
    foreach ($agents as $a) {
        $needle = '@' . mb_strtolower(trim((string)$a['name']));
        if (strpos($text, $needle) !== false) $hits[(int)$a['user_id']] = $a['name'];
    }
    return $hits;
}

/* ----------------------------------------------------------------- retry -- */
if ($action === 'retry') {
    $messageId = fd_int('message_id', 0);
    if ($messageId <= 0) api_error('message_id is required', 400);

    $m = fd_query_one("SELECT * FROM fd_messages WHERE id = ?", 'i', array($messageId));
    if (!$m) api_error('Message not found', 404);
    if ($m['direction'] !== 'outbound') api_error('Only outgoing messages can be resent.', 400);
    if ($m['delivery_status'] === 'sent') api_error('That message was already delivered.', 400);
    // Runaway retries against a permanently-rejecting server are their own
    // outage; cap them and make the agent look at the error instead.
    if ((int)$m['retry_count'] >= 5) api_error('This message has failed 5 times. Fix the mail settings before retrying again.', 400);

    $attIds = fd_query("SELECT id FROM fd_attachments WHERE message_id = ?", 'i', array($messageId));
    $ids = array_map(function ($r) { return (int)$r['id']; }, $attIds);

    $mailer = new FdMailer();
    if (!$mailer->isReady()) api_error('Email sending is not available: ' . $mailer->loadError(), 500);

    try {
        $res = $mailer->sendTicketMessage(array(
            'ticket_id'      => (int)$m['ticket_id'],
            'type'           => $m['msg_type'] === 'forward' ? 'forward' : 'reply',
            'body_html'      => $m['body_html'],
            'to'             => json_decode((string)$m['to_emails'], true) ?: array(),
            'cc'             => json_decode((string)$m['cc_emails'], true) ?: array(),
            'bcc'            => json_decode((string)$m['bcc_emails'], true) ?: array(),
            'subject'        => $m['subject'],
            'attachment_ids' => $ids,
            'agent'          => $ME,
            'include_signature' => false,   // the stored body already has it
            'quote_history'  => false,      // and the quoted history
        ));
    } catch (Throwable $e) {
        api_error($e->getMessage(), 500);
    }

    if (!empty($res['sent'])) {
        // The original row is superseded by the new one; keep it out of the
        // thread rather than showing the same message twice.
        fd_exec("DELETE FROM fd_messages WHERE id = ?", 'i', array($messageId));
        fd_recount_ticket((int)$m['ticket_id']);
        api_success(array('sent' => true, 'message_id' => (int)$res['message_id']), 'Message resent');
    }
    api_success(array('sent' => false, 'error' => $res['error']), 'Retry failed: ' . $res['error']);
}

/* ----------------------------------------------------------- delete_note -- */
if ($action === 'delete_note') {
    $messageId = fd_int('message_id', 0);
    $m = fd_query_one("SELECT id, ticket_id, direction FROM fd_messages WHERE id = ?", 'i', array($messageId));
    if (!$m) api_error('Message not found', 404);
    // Only notes. A sent email cannot be un-sent, and letting an agent delete
    // one would quietly rewrite the record of what the customer was told.
    if ($m['direction'] !== 'note') api_error('Only internal notes can be deleted.', 400);

    fd_exec("DELETE FROM fd_messages WHERE id = ?", 'i', array($messageId));
    fd_recount_ticket((int)$m['ticket_id']);
    fd_activity((int)$m['ticket_id'], 'note-deleted', $ME['name'] . ' deleted a note',
                array('type' => 'agent', 'id' => $ME['id'], 'name' => $ME['name']));
    api_success(array('deleted' => true), 'Note deleted');
}

/* ---------------------------------------------------------------- drafts -- */
/*
 * Drafts live in fd_settings under a per-agent, per-ticket key rather than in
 * their own table: they are small, transient, and only ever read back by the
 * one agent who wrote them.
 */
if ($action === 'save_draft') {
    $ticketId = fd_int('ticket_id', 0);
    if ($ticketId <= 0) api_error('ticket_id is required', 400);
    $key = 'draft_' . (int)$ME['id'] . '_' . $ticketId;
    fd_cfg_set($key, json_encode(array(
        'body' => fd_str('body', ''),
        'to'   => fd_arr('to', array()),
        'cc'   => fd_arr('cc', array()),
        'mode' => fd_str('mode', 'Reply'),
        'at'   => date('c'),
    )));
    api_success(array('saved' => true), 'Draft saved');
}

/*
 * Every draft this agent has, newest first, with enough of each to recognise
 * it. Keyed per agent: a draft is private until it is sent.
 */
if ($action === 'drafts') {
    $prefix = 'draft_' . (int)$ME['id'] . '_';
    $rows = fd_query("SELECT setting_key, setting_value FROM fd_settings WHERE setting_key LIKE ?",
                     's', array($prefix . '%'));
    $out = array();
    foreach ($rows as $r) {
        $tid = (int)substr($r['setting_key'], strlen($prefix));
        if ($tid <= 0) continue;
        $d = json_decode((string)$r['setting_value'], true);
        if (!is_array($d)) continue;

        $t = fd_query_one("SELECT id, subject, requester_name FROM fd_tickets WHERE id = ?", 'i', array($tid));
        if (!$t) continue;                       // ticket deleted; the draft is noise

        $text = trim(fd_html_to_text(isset($d['body']) ? $d['body'] : ''));
        $out[] = array(
            'ticketId' => $tid,
            'subject'  => $t['subject'],
            'name'     => $t['requester_name'],
            'mode'     => isset($d['mode']) ? $d['mode'] : 'Reply',
            'at'       => isset($d['at']) ? $d['at'] : null,
            'ago'      => isset($d['at']) ? fd_relative_time($d['at']) : '',
            'preview'  => fd_snippet($text, 140),
        );
    }
    // Newest first.
    usort($out, function ($a, $b) { return strcmp((string)$b['at'], (string)$a['at']); });
    api_success(array('drafts' => $out, 'ticketIds' => array_map(function ($d) { return $d['ticketId']; }, $out)), 'OK');
}

if ($action === 'get_draft') {
    $ticketId = fd_int('ticket_id', 0);
    $key = 'draft_' . (int)$ME['id'] . '_' . $ticketId;
    $raw = fd_cfg($key, null);
    api_success(array('draft' => $raw ? json_decode($raw, true) : null), 'OK');
}

if ($action === 'discard_draft') {
    $ticketId = fd_int('ticket_id', 0);
    $key = 'draft_' . (int)$ME['id'] . '_' . $ticketId;
    fd_exec("DELETE FROM fd_settings WHERE setting_key = ?", 's', array($key));
    api_success(array('discarded' => true), 'Draft discarded');
}

/* -------------------------------------------------------- canned replies -- */
/*
 * Everything the picker and the settings screen need in one round trip: the
 * folders with their counts, and every response with the folder it is in. Two
 * queries, not one per folder -- with a dozen folders the N+1 shape is what
 * makes a settings page feel slow.
 */
if ($action === 'canned') {
    $all   = fd_bool('all', false);          // the settings screen wants inactive ones too
    $where = $all ? '1=1' : 'is_active = 1';

    $rows = fd_query("SELECT id, name, category, folder_id, body, shortcut, uses, is_active,
                             created_by_name, created_at, updated_at
                      FROM fd_canned_responses WHERE $where
                      ORDER BY uses DESC, name ASC LIMIT 1000");

    $folders = fd_query("SELECT f.id, f.name,
                                (SELECT COUNT(*) FROM fd_canned_responses r WHERE r.folder_id = f.id) AS count
                         FROM fd_canned_folders f ORDER BY f.name ASC");

    api_success(array('responses' => $rows, 'folders' => $folders), 'OK');
}

/* ---- folders ---- */
if ($action === 'canned_folder_save') {
    $id   = fd_int('id', 0);
    $name = trim(fd_str('name', ''));
    if ($name === '') api_error('Folder name is required', 400);

    // The UNIQUE key is the real guard; this only buys a readable message.
    $clash = fd_query_one("SELECT id FROM fd_canned_folders WHERE name = ? AND id <> ?", 'si', array($name, $id));
    if ($clash) api_error('A folder called "' . $name . '" already exists.', 409);

    if ($id > 0) {
        fd_exec("UPDATE fd_canned_folders SET name = ? WHERE id = ?", 'si', array($name, $id));
    } else {
        $id = fd_exec("INSERT INTO fd_canned_folders (name, created_by) VALUES (?,?)",
                      'si', array($name, $ME['id']), true);
    }
    api_success(array('id' => (int)$id), 'Folder saved');
}

if ($action === 'canned_folder_delete') {
    $id = fd_int('id', 0);
    if ($id <= 0) api_error('Folder id is required', 400);
    /*
     * Deleting a folder must not delete the work inside it. Its responses are
     * unfiled instead and the settings screen lists them under "Unfiled", so
     * they can be moved somewhere sensible rather than quietly disappearing.
     */
    $moved = fd_exec("UPDATE fd_canned_responses SET folder_id = NULL WHERE folder_id = ?", 'i', array($id));
    fd_exec("DELETE FROM fd_canned_folders WHERE id = ?", 'i', array($id));
    api_success(array('deleted' => true, 'unfiled' => $moved),
                $moved > 0 ? ($moved . ' response(s) moved to Unfiled') : 'Folder deleted');
}

if ($action === 'canned_save') {
    $id   = fd_int('id', 0);
    $name = fd_str('name', '');
    $body = fd_str('body', '');
    if ($name === '') api_error('Name is required', 400);
    if ($body === '') api_error('Body is required', 400);

    // 0 from the picker means "no folder"; the column is nullable.
    $folderId = fd_int('folder_id', 0);
    $folderId = $folderId > 0 ? $folderId : null;
    $active   = fd_bool('is_active', true) ? 1 : 0;
    $shortcut = fd_str('shortcut', null);
    $category = fd_str('category', null);

    if ($id > 0) {
        fd_exec("UPDATE fd_canned_responses
                 SET name = ?, category = ?, folder_id = ?, body = ?, shortcut = ?, is_active = ?
                 WHERE id = ?",
                'ssissii',
                array($name, $category, $folderId, $body, $shortcut, $active, $id));
    } else {
        $id = fd_exec("INSERT INTO fd_canned_responses
                        (name, category, folder_id, body, shortcut, is_active, created_by, created_by_name)
                       VALUES (?,?,?,?,?,?,?,?)",
                'ssissiis', array($name, $category, $folderId, $body, $shortcut, $active, $ME['id'], $ME['name']),
                true);
    }
    api_success(array('id' => (int)$id), 'Canned response saved');
}

if ($action === 'canned_use') {
    $id = fd_int('id', 0);
    fd_exec("UPDATE fd_canned_responses SET uses = uses + 1 WHERE id = ?", 'i', array($id));
    api_success(array('ok' => true), 'OK');
}

if ($action === 'canned_delete') {
    $id = fd_int('id', 0);
    fd_exec("DELETE FROM fd_canned_responses WHERE id = ?", 'i', array($id));
    api_success(array('deleted' => true), 'Deleted');
}

/* ============================================================ automations == */
/*
 * Rules live here rather than in their own file because they are read and
 * written from the same screen that manages canned responses, and an action
 * can send mail -- which is this file's job already.
 */

/**
 * Which of the four module screens a rule belongs on, from its first action.
 * Rules are one table and one engine; "kind" is only how the screens divide
 * them up, so it is derived rather than asked for.
 */
function fd_automation_kind_of($actions)
{
    $first = is_array($actions) && !empty($actions) ? $actions[0] : array();
    $type  = isset($first['type']) ? $first['type'] : '';
    if ($type === 'forward') return 'forward';
    if ($type === 'notify')  return 'notify';
    if ($type === 'send_canned') return 'canned';
    return 'closure';
}

if ($action === 'automations') {
    $kind = fd_str('kind', '');          // optional: one module's rules only
    $rows = $kind !== ''
        ? fd_query("SELECT * FROM fd_automations WHERE kind = ? ORDER BY position ASC, id ASC",
                   's', array($kind))
        : fd_query("SELECT * FROM fd_automations ORDER BY position ASC, id ASC");
    foreach ($rows as &$r) {
        $r['conditions'] = json_decode((string)$r['conditions'], true) ?: array();
        $r['actions']    = json_decode((string)$r['actions'], true) ?: array();
        $r['is_active']  = (int)$r['is_active'];
        $r['runs']       = (int)$r['runs'];
        $r['match_type'] = isset($r['match_type']) ? $r['match_type'] : 'all';
        /*
         * "kind" defaults to 'closure' at the column level, so a rule written
         * before the column existed would sit on the wrong screen. If the
         * stored kind is the default but the rule's first action says
         * otherwise, believe the action.
         */
        $derived = fd_automation_kind_of($r['actions']);
        $r['kind'] = (!isset($r['kind']) || ($r['kind'] === 'closure' && $derived !== 'closure'))
            ? $derived : $r['kind'];
        $r['lastRunAgo'] = $r['last_run_at'] ? fd_relative_time($r['last_run_at']) : '';
        $r['updatedAgo'] = $r['updated_at'] ? fd_relative_time($r['updated_at']) : '';
    }
    unset($r);

    $mods = fd_automation_modules();
    api_success(array('rules' => $rows, 'modules' => $mods), 'OK');
}

if ($action === 'automation_save') {
    $id    = fd_int('id', 0);
    $name  = trim(fd_str('name', ''));
    $event = fd_str('event', 'ticket_created');
    if ($name === '') api_error('Give the rule a name', 400);
    if (!in_array($event, array('ticket_created', 'ticket_updated', 'tag_added'), true)) {
        api_error('Unknown trigger: ' . $event, 400);
    }

    // Stored as JSON; validated only for shape, since the vocabulary of
    // operators and actions belongs to the engine, not the table.
    $conds   = fd_arr('conditions', array());
    $actions = fd_arr('actions', array());
    if (empty($actions)) api_error('A rule needs at least one action', 400);

    $active = fd_bool('is_active', true) ? 1 : 0;
    $desc   = fd_str('description', '');
    $pos    = fd_int('position', 0);
    $match  = fd_str('match_type', 'all') === 'any' ? 'any' : 'all';
    // Which module screen the rule belongs to. The caller may say; otherwise it
    // is read off the first action, so a rule always lands on the right table.
    $kind   = fd_str('kind', '');
    if (!in_array($kind, array('closure', 'forward', 'notify', 'canned'), true)) {
        $kind = fd_automation_kind_of($actions);
    }

    if ($id > 0) {
        fd_exec("UPDATE fd_automations
                 SET name = ?, description = ?, event = ?, conditions = ?, actions = ?,
                     is_active = ?, position = ?, match_type = ?, kind = ?
                 WHERE id = ?",
                'sssssiissi', array($name, $desc, $event, json_encode($conds), json_encode($actions),
                                    $active, $pos, $match, $kind, $id));
    } else {
        $id = fd_exec("INSERT INTO fd_automations
                        (name, description, event, conditions, actions, is_active, position,
                         match_type, kind, created_by, created_by_name)
                       VALUES (?,?,?,?,?,?,?,?,?,?,?)",
                'sssssiissis', array($name, $desc, $event, json_encode($conds), json_encode($actions),
                                     $active, $pos, $match, $kind, $ME['id'], $ME['name']), true);
    }
    api_success(array('id' => (int)$id), 'Automation saved');
}

if ($action === 'automation_toggle') {
    $id = fd_int('id', 0);
    $on = fd_bool('is_active', true) ? 1 : 0;
    if ($id <= 0) api_error('Rule id is required', 400);
    fd_exec("UPDATE fd_automations SET is_active = ? WHERE id = ?", 'ii', array($on, $id));
    api_success(array('id' => $id, 'is_active' => $on), $on ? 'Rule enabled' : 'Rule disabled');
}

if ($action === 'automation_delete') {
    $id = fd_int('id', 0);
    if ($id <= 0) api_error('Rule id is required', 400);
    fd_exec("DELETE FROM fd_automations WHERE id = ?", 'i', array($id));
    // The log is kept: it is the record of what already happened, and deleting
    // the rule does not un-close the tickets it closed.
    api_success(array('deleted' => true), 'Automation deleted');
}

/* The four module switches on the Automation screen. */
if ($action === 'automation_modules') {
    $map = array(
        'master'       => 'AUTOMATION_ENABLED',
        'auto_close'   => 'AUTOMATION_AUTO_CLOSE',
        'forwarding'   => 'AUTOMATION_FORWARDING',
        'tagged_notif' => 'AUTOMATION_TAGGED_NOTIF',
        'canned'       => 'AUTOMATION_CANNED',
    );
    foreach ($map as $key => $setting) {
        $v = fd_input($key, null);
        if ($v === null) continue;                 // only what was actually sent
        fd_cfg_set($setting, (fd_bool($key, true) ? '1' : '0'));
    }
    api_success(array('modules' => fd_automation_modules()), 'Automation settings saved');
}

/* What the rules have actually done, newest first. */
if ($action === 'automation_log') {
    $limit = max(1, min(200, fd_int('limit', 50)));
    $rows = fd_query("SELECT * FROM fd_automation_log ORDER BY id DESC LIMIT $limit");
    foreach ($rows as &$r) {
        $r['applied'] = json_decode((string)$r['applied'], true) ?: array();
        $r['skipped'] = json_decode((string)$r['skipped'], true) ?: array();
        $r['ago']     = fd_relative_time($r['created_at']);
    }
    unset($r);
    api_success(array('log' => $rows), 'OK');
}


/*
 * The numbers on the Automation screen.
 *
 * Every one of these is counted from fd_automations and fd_automation_log --
 * nothing here is an estimate. "applied" holds a JSON array of the phrases the
 * engine wrote when it did something ("forwarded to a@b.com", "status ->
 * Closed"), so the per-action counts match on those phrases: they are the
 * engine's own record of what it did, not a re-derivation from the rules.
 */
if ($action === 'automation_stats') {
    $days = max(1, min(90, fd_int('days', 30)));

    $rules = fd_query("SELECT id, is_active, kind, actions FROM fd_automations");
    $total = count($rules);
    $active = 0;
    $dist = array('closure' => 0, 'forward' => 0, 'notify' => 0, 'canned' => 0);
    foreach ($rules as $r) {
        if ((int)$r['is_active'] === 1) $active++;
        $k = isset($r['kind']) && isset($dist[$r['kind']])
            ? $r['kind']
            : fd_automation_kind_of(json_decode((string)$r['actions'], true) ?: array());
        $dist[$k]++;
    }

    $since = date('Y-m-d H:i:s', strtotime('-' . $days . ' days'));
    $one = function ($sql, $types = '', $args = array()) {
        $r = $types === '' ? fd_query_one($sql) : fd_query_one($sql, $types, $args);
        return $r ? (int)$r['n'] : 0;
    };

    $runs      = $one("SELECT COUNT(*) n FROM fd_automation_log WHERE created_at >= ?", 's', array($since));
    $succeeded = $one("SELECT COUNT(*) n FROM fd_automation_log
                       WHERE created_at >= ? AND applied <> '[]' AND applied IS NOT NULL",
                      's', array($since));
    $failed    = max(0, $runs - $succeeded);

    $today = date('Y-m-d') . ' 00:00:00';
    $forwardedToday = $one("SELECT COUNT(*) n FROM fd_automation_log
                            WHERE created_at >= ? AND applied LIKE '%forwarded to%'", 's', array($today));
    $closed    = $one("SELECT COUNT(*) n FROM fd_automation_log
                       WHERE created_at >= ? AND (applied LIKE '%status -> Closed%'
                                               OR applied LIKE '%status -> Resolved%')",
                      's', array($since));
    $notified  = $one("SELECT COUNT(*) n FROM fd_automation_log
                       WHERE created_at >= ? AND applied LIKE '%notified%'", 's', array($since));
    $cannedSent = $one("SELECT COUNT(*) n FROM fd_automation_log
                        WHERE created_at >= ? AND applied LIKE '%sent canned%'", 's', array($since));

    /* Runs per day for the last 7 days, oldest first, with empty days kept so
       the bar chart has a bar for every weekday rather than a ragged axis. */
    $rowsByDay = fd_query("SELECT DATE(created_at) d, COUNT(*) n FROM fd_automation_log
                           WHERE created_at >= ? GROUP BY DATE(created_at)",
                          's', array(date('Y-m-d', strtotime('-6 days')) . ' 00:00:00'));
    $byDay = array();
    foreach ($rowsByDay as $r) $byDay[$r['d']] = (int)$r['n'];
    $week = array();
    for ($i = 6; $i >= 0; $i--) {
        $ts = strtotime('-' . $i . ' days');
        $key = date('Y-m-d', $ts);
        $week[] = array('t' => date('D', $ts), 'runs' => isset($byDay[$key]) ? $byDay[$key] : 0);
    }

    api_success(array(
        'days'  => $days,
        'kpis'  => array(
            'totalRules'      => $total,
            'activeRules'     => $active,
            'disabledRules'   => $total - $active,
            'forwardedToday'  => $forwardedToday,
            'ticketsClosed'   => $closed,
            'notificationsSent' => $notified,
            'cannedSent'      => $cannedSent,
            'runs'            => $runs,
            'succeeded'       => $succeeded,
            'failed'          => $failed,
            'successRate'     => $runs > 0 ? (int)round($succeeded * 100 / $runs) : 0,
        ),
        'week'  => $week,
        'dist'  => array(
            array('name' => 'Auto-closure',  'value' => $dist['closure'], 'color' => '#5B5CEB'),
            array('name' => 'Forwarding',    'value' => $dist['forward'], 'color' => '#0EA5E9'),
            array('name' => 'Notifications', 'value' => $dist['notify'],  'color' => '#F59E0B'),
            array('name' => 'Canned',        'value' => $dist['canned'],  'color' => '#10B981'),
        ),
    ), 'OK');
}

/*
 * Dry run: which rules WOULD match this ticket, and what they would do.
 * Nothing is executed and nothing is logged -- this is how you check a rule
 * before turning it loose on the mailbox.
 */
if ($action === 'automation_test') {
    $ticketId = fd_int('ticket_id', 0);
    $subject  = fd_str('subject', '');
    $bodyText = fd_str('body', '');

    if ($ticketId === 0 && $subject === '' && $bodyText === '') {
        // "Try this rule" with nothing typed means "try it on the last thing
        // that arrived" -- an empty hypothetical ticket matches nothing and
        // would just report a false negative.
        $latest = fd_query_one("SELECT id FROM fd_tickets ORDER BY id DESC LIMIT 1");
        if ($latest) $ticketId = (int)$latest['id'];
    }

    if ($ticketId > 0) {
        $ticket = fd_query_one("SELECT * FROM fd_tickets WHERE id = ?", 'i', array($ticketId));
        if (!$ticket) api_error('Ticket not found', 404);
        $message = fd_query_one("SELECT * FROM fd_messages WHERE ticket_id = ? ORDER BY id ASC LIMIT 1",
                                'i', array($ticketId));
    } else {
        // A hypothetical ticket, so a rule can be tried before any mail arrives.
        $ticket = array('id' => 0, 'subject' => $subject, 'requester_email' => fd_str('from', ''),
                        'requester_name' => '', 'status' => 'New', 'priority' => 'Medium',
                        'category' => 'General', 'agent_name' => '', 'tags' => '[]');
        $message = array('body_html' => $bodyText);
    }

    $ruleId = fd_int('rule_id', 0);
    $event  = fd_str('event', '');

    // One named rule, or every rule for an event. Trying a single rule is what
    // the play button on each row does.
    if ($ruleId > 0) {
        $rules = fd_query("SELECT * FROM fd_automations WHERE id = ?", 'i', array($ruleId));
    } elseif ($event !== '') {
        $rules = fd_query("SELECT * FROM fd_automations WHERE event = ? ORDER BY position ASC, id ASC",
                          's', array($event));
    } else {
        $rules = fd_query("SELECT * FROM fd_automations ORDER BY position ASC, id ASC");
    }

    $out = array();
    foreach ($rules as $rule) {
        $conds = json_decode((string)$rule['conditions'], true) ?: array();
        $any   = isset($rule['match_type']) && $rule['match_type'] === 'any';
        $out[] = array(
            'id' => (int)$rule['id'], 'name' => $rule['name'],
            'active' => (int)$rule['is_active'] === 1,
            'matches' => fd_automation_matches($conds, $ticket, $message, $any),
            'actions' => json_decode((string)$rule['actions'], true) ?: array(),
        );
    }
    api_success(array(
        'results'  => $out,
        'ticket'   => array('id' => (int)$ticket['id'], 'subject' => $ticket['subject']),
    ), 'OK');
}

api_error('Unknown action: ' . $action, 400);

<?php
/*
 * /api/campaigns/all_campaigns.php — every campaign, both channels, one list.
 *
 * WHY A SEPARATE ENDPOINT
 * Email and WhatsApp campaigns live in two tables with different columns, different status
 * vocabularies for the same idea, and two separate list APIs — so the panel had two separate
 * screens, and there was no way to answer "what did we send last week?" without reading both and
 * merging them by hand. This is that merge, done once, server-side, where the sort can be correct:
 * interleaving two paginated lists in the browser cannot produce a true newest-first ordering
 * without fetching everything from both.
 *
 * THE COLUMNS ARE NOT THE SAME, AND THAT IS THE POINT
 * A shared table tempts you to invent a lowest common denominator. Instead every row reports what
 * its channel actually measures and returns null for the rest, and the UI prints NA:
 *
 *                   email                          whatsapp
 *   opened          unique opens (pixel/ESP)       read receipts
 *   clicked         unique clicks                  distinct people who tapped
 *   bounce          hard + soft bounces            — (no such concept)
 *   unsubscribed    ESP unsubscribes               — (opt-out is a STOP reply, not per campaign)
 *   undelivered     — (ESPs report bounces)        failed_count
 *   replied         —                              reply_count
 *
 * Printing 0 where the answer is "this channel does not have that" is the single most misleading
 * thing this screen could do — a 0% bounce rate on WhatsApp reads as excellent deliverability
 * rather than as a column that does not apply.
 *
 * action=list     &page &per_page &status &channel &search &from &to &tags &sort
 * action=trend    &from &to &metric &granularity   → daily/weekly series, split by channel
 * action=summary  &from &to                        → totals + per-channel attribution of
 *                                                    opens / clicks / conversions
 * action=tags                                      → every tag in use on either channel
 * action=export   (same filters as list)           → CSV of the filtered set
 */
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../middleware/auth.php';
require_once __DIR__ . '/lib/config.php';
require_once __DIR__ . '/lib/schema.php';

campaigns_ensure_schema();

$jwt = require_jwt();
require_permission('netcore_behaviour', $jwt);

function jin($k, $d = null) { $v = $_REQUEST[$k] ?? null; return ($v === null || $v === '') ? $d : $v; }

/** WhatsApp is an optional install; without it this is simply an email-only list. */
function ac_has_whatsapp(): bool {
    global $conn;
    static $has = null;
    if ($has !== null) return $has;
    $r = @$conn->query("SHOW TABLES LIKE 'wa_campaigns'");
    return $has = (bool)($r && $r->num_rows > 0);
}

/*
 * The one date a campaign is filed under.
 *
 * Not created_at: a draft made in January and sent in August belongs in August, and sorting a
 * merged list by creation date puts long-lived drafts above things that actually went out
 * yesterday. COALESCE walks the lifecycle backwards — finished, then started, then scheduled,
 * then created — so every row has a date and it is always the most meaningful one available.
 */
const AC_SENT_ON = "COALESCE(completed_at, started_at, scheduled_at, created_at)";

/**
 * The shared WHERE, built once so list / export / trend / summary can never disagree.
 *
 * Every clause is written against bare column names because it is applied INSIDE each channel's
 * SELECT, before the UNION — pushing the filter down to each table lets both use their own
 * indexes, where filtering the merged result would force a full read of both tables first.
 *
 * @param bool $withStatus false builds the same filter minus the status clause, which is what the
 *                         tab counts need: the tabs must keep counting every status while still
 *                         honouring the search, date and tag filters.
 */
function ac_filters(bool $withStatus = true): array {
    global $conn;
    $where = [];

    $status = (string)jin('status', 'all');
    if ($withStatus && $status !== 'all' && $status !== '') {
        $where[] = "status = '" . $conn->real_escape_string($status) . "'";
    }

    $search = trim((string)jin('search', ''));
    if ($search !== '') {
        $s = $conn->real_escape_string($search);
        // Searching the id too: people paste "9642" out of a report far more often than they
        // remember what the campaign was called.
        $where[] = "(name LIKE '%$s%'" . (ctype_digit($search) ? " OR id = " . (int)$search : '') . ")";
    }

    // Duration. Applied to the same COALESCE the list sorts on, so "last 7 days" means the same
    // thing as the order on screen rather than quietly filtering on a different column.
    $from = trim((string)jin('from', ''));
    $to   = trim((string)jin('to', ''));
    if ($from !== '') $where[] = AC_SENT_ON . " >= '" . $conn->real_escape_string($from) . " 00:00:00'";
    if ($to   !== '') $where[] = AC_SENT_ON . " <= '" . $conn->real_escape_string($to)   . " 23:59:59'";

    /*
     * Tags are a comma-separated string on the row, so matching is a LIKE against the list with
     * commas glued to both ends. Without the glue, tag "iCAT17" matches "iCAT175" — the classic
     * substring bug that quietly widens every tag filter.
     */
    $tags = trim((string)jin('tags', ''));
    if ($tags !== '') {
        $ors = [];
        foreach (array_filter(array_map('trim', explode(',', $tags))) as $t) {
            $e = $conn->real_escape_string($t);
            $ors[] = "CONCAT(',', REPLACE(tags, ', ', ','), ',') LIKE '%,$e,%'";
        }
        if ($ors) $where[] = '(' . implode(' OR ', $ors) . ')';
    }

    return $where;
}

function ac_where_sql(bool $withStatus = true): string {
    $w = ac_filters($withStatus);
    return $w ? 'WHERE ' . implode(' AND ', $w) : '';
}

/**
 * One SELECT per channel, column-for-column identical so they can be UNIONed.
 *
 * NULL is used for "this channel does not measure that", and the UI turns it into NA. Every
 * column is aliased explicitly rather than relying on position, because a UNION silently takes
 * its column names from the first branch — a mismatched order there produces a list where
 * WhatsApp's read count appears under "Bounce" and nothing anywhere reports an error.
 */
function ac_select_email(string $where): string {
    return "SELECT
        id, 'email' AS channel, name, tags, status,
        " . AC_SENT_ON . " AS sent_on,
        scheduled_at, started_at, completed_at, created_at,
        total_recipients AS published,
        sent_count       AS sent,
        delivered_count  AS delivered,
        unique_open_count  AS opened,
        unique_click_count AS clicked,
        conversion_count AS conversions,
        NULL             AS revenue,
        (total_recipients - sent_count) AS not_sent,
        unsubscribe_count AS unsubscribed,
        bounce_count      AS bounce,
        spam_count        AS spam,
        NULL              AS undelivered,
        NULL              AS replied,
        goal_event_name,
        esp_transport     AS provider,
        NULL              AS last_error,
        NULL              AS template_name,
        /*
         * Addresses verification removed before this campaign was ever queued.
         *
         * COALESCE because the column arrives with the verification feature and every campaign
         * that predates it has NULL, which would otherwise print as NA on rows where the honest
         * answer is zero — nothing was skipped, because nothing was checked.
         */
        COALESCE(verification_skipped, 0) AS verified_skipped
      FROM email_campaigns $where";
}

function ac_select_whatsapp(string $where): string {
    /*
     * clicked is PEOPLE, not taps — click_count counts every tap, so five taps by one person is
     * five, which sitting next to Sent can and did exceed it. GREATEST of the two click sources
     * rather than a sum: wa_link_clicks already folds an identified tapper onto their user_id, so
     * adding the per-recipient column would double-count exactly the overlap. (Same reasoning as
     * wa_campaigns.php's own list — kept identical on purpose so the two screens never disagree.)
     */
    return "SELECT
        id, 'whatsapp' AS channel, name, tags, status,
        " . AC_SENT_ON . " AS sent_on,
        scheduled_at, started_at, completed_at, created_at,
        total_recipients AS published,
        sent_count       AS sent,
        delivered_count  AS delivered,
        read_count       AS opened,
        GREATEST(
          (SELECT COUNT(DISTINCT lc.identity_key) FROM wa_link_clicks lc WHERE lc.campaign_id = wa_campaigns.id),
          (SELECT COUNT(*) FROM wa_campaign_recipients cr
            WHERE cr.campaign_id = wa_campaigns.id AND cr.is_test = 0 AND cr.first_clicked_at IS NOT NULL)
        )                AS clicked,
        conversion_count AS conversions,
        NULL             AS revenue,
        (total_recipients - sent_count) AS not_sent,
        NULL             AS unsubscribed,
        NULL             AS bounce,
        NULL             AS spam,
        failed_count     AS undelivered,
        reply_count      AS replied,
        goal_event_name,
        send_provider    AS provider,
        last_error,
        template_name,
        /* NULL, not 0: email verification has nothing to say about a WhatsApp campaign, and the
           list prints NULL as NA, which is the difference between none being skipped and the
           question not applying here at all. */
        NULL             AS verified_skipped
      FROM wa_campaigns $where";
}

/** The UNION for the requested channel(s). */
function ac_union(string $where): string {
    $channel = (string)jin('channel', 'all');
    $parts = [];
    if ($channel === 'all' || $channel === 'email')    $parts[] = ac_select_email($where);
    if (($channel === 'all' || $channel === 'whatsapp') && ac_has_whatsapp()) $parts[] = ac_select_whatsapp($where);
    // A channel filter that matches nothing must return nothing, not everything.
    if (!$parts) $parts[] = ac_select_email($where . ($where ? ' AND 1=0' : 'WHERE 1=0'));
    return implode(' UNION ALL ', $parts);
}

$action = (string)jin('action', 'list');

/* ═══════════════════════════════════════════════════════════════════════════════════════════
   list
   ═══════════════════════════════════════════════════════════════════════════════════════════ */
if ($action === 'list') {
    $page    = max(1, (int)jin('page', 1));
    $perPage = max(1, min(200, (int)jin('per_page', 25)));
    $offset  = ($page - 1) * $perPage;

    $where = ac_where_sql();
    $union = ac_union($where);

    // Whitelisted, never interpolated from input: this lands in an ORDER BY.
    $sorts = [
        'recent'   => 'sent_on DESC',
        'oldest'   => 'sent_on ASC',
        'name'     => 'name ASC',
        'sent'     => 'sent DESC',
        'opened'   => 'opened DESC',
        'clicked'  => 'clicked DESC',
        'converted'=> 'conversions DESC',
    ];
    $sort = $sorts[(string)jin('sort', 'recent')] ?? $sorts['recent'];

    $tr = $conn->query("SELECT COUNT(*) c FROM ($union) x");
    $total = $tr ? (int)$tr->fetch_assoc()['c'] : 0;

    // Secondary sort on sent_on then id: two campaigns sent in the same minute would otherwise
    // swap places between pages, which looks like rows going missing.
    $r = $conn->query("SELECT * FROM ($union) x ORDER BY $sort, sent_on DESC, id DESC LIMIT $perPage OFFSET $offset");
    $rows = [];
    while ($r && $row = $r->fetch_assoc()) {
        foreach (['id','published','sent','delivered','opened','clicked','conversions',
                  'not_sent','unsubscribed','bounce','spam','undelivered','replied',
                  'verified_skipped'] as $k) {
            // null stays null — it means "not applicable on this channel" and the UI prints NA.
            if ($row[$k] !== null) $row[$k] = (int)$row[$k];
        }
        // not_sent can go negative if a count drifts; a negative "not sent" is noise, not signal.
        if ($row['not_sent'] !== null && $row['not_sent'] < 0) $row['not_sent'] = 0;
        $row['tag_list'] = array_values(array_filter(array_map('trim', explode(',', (string)$row['tags']))));
        $rows[] = $row;
    }

    /*
     * Tab counts ignore the status filter but honour every other one — otherwise clicking "Sent"
     * would rewrite all the other tabs to 0 and there would be no way back except a reload.
     */
    $cw     = ac_where_sql(false);
    $cUnion = ac_union($cw);

    $counts = ['all' => 0, 'draft' => 0, 'scheduled' => 0, 'running' => 0,
               'sent' => 0, 'suspended' => 0, 'failed' => 0];
    $cr = $conn->query("SELECT status, COUNT(*) c FROM ($cUnion) x GROUP BY status");
    while ($cr && $row = $cr->fetch_assoc()) {
        $counts[$row['status']] = (int)$row['c'];
        $counts['all'] += (int)$row['c'];
    }

    // Per-channel counts for the channel chips in the filter drawer, on the same basis.
    $byChannel = ['email' => 0, 'whatsapp' => 0];
    $chUnion = ac_has_whatsapp()
        ? ac_select_email($cw) . ' UNION ALL ' . ac_select_whatsapp($cw)
        : ac_select_email($cw);
    $chr = $conn->query("SELECT channel, COUNT(*) c FROM ($chUnion) x GROUP BY channel");
    while ($chr && $row = $chr->fetch_assoc()) $byChannel[$row['channel']] = (int)$row['c'];

    api_success([
        'campaigns' => $rows, 'total' => $total, 'page' => $page, 'per_page' => $perPage,
        'pages' => $total > 0 ? (int)ceil($total / $perPage) : 1,
        'counts' => $counts, 'by_channel' => $byChannel,
        'has_whatsapp' => ac_has_whatsapp(),
    ]);
}

/* ═══════════════════════════════════════════════════════════════════════════════════════════
   summary — the stat tiles, plus which channel each result came from
   ═══════════════════════════════════════════════════════════════════════════════════════════ */
if ($action === 'summary') {
    $where = ac_where_sql();
    $union = ac_union($where);

    $r = $conn->query("SELECT channel,
                              COUNT(*)              AS campaigns,
                              SUM(published)        AS published,
                              SUM(sent)             AS sent,
                              SUM(delivered)        AS delivered,
                              SUM(opened)           AS opened,
                              SUM(clicked)          AS clicked,
                              SUM(conversions)      AS conversions,
                              SUM(COALESCE(unsubscribed,0)) AS unsubscribed,
                              SUM(COALESCE(bounce,0))       AS bounce,
                              SUM(COALESCE(undelivered,0))  AS undelivered,
                              SUM(COALESCE(replied,0))      AS replied
                         FROM ($union) x GROUP BY channel");

    $byChannel = [];
    $totals = ['campaigns' => 0, 'published' => 0, 'sent' => 0, 'delivered' => 0, 'opened' => 0,
               'clicked' => 0, 'conversions' => 0, 'unsubscribed' => 0, 'bounce' => 0,
               'undelivered' => 0, 'replied' => 0];
    while ($r && $row = $r->fetch_assoc()) {
        $ch = $row['channel'];
        unset($row['channel']);
        foreach ($row as $k => $v) { $row[$k] = (int)$v; $totals[$k] += (int)$v; }
        $byChannel[$ch] = $row;
    }

    api_success(['totals' => $totals, 'by_channel' => $byChannel]);
}

/* ═══════════════════════════════════════════════════════════════════════════════════════════
   trend — one point per day (or week), per channel

   Campaign counters are lifetime totals on the campaign row, not per-day event rows, so a trend
   attributes a campaign's whole result to the day it went out. That is the honest reading for a
   broadcast — the sends all happened that day — and it is what makes the series line up with the
   list above it. Engagement that trickles in for days afterwards is still counted on the send's
   day, which is stated on the chart rather than left to be discovered.
   ═══════════════════════════════════════════════════════════════════════════════════════════ */
if ($action === 'trend') {
    $where = ac_where_sql();
    $union = ac_union($where);

    $gran = (string)jin('granularity', 'day');
    $bucket = $gran === 'month' ? "DATE_FORMAT(sent_on, '%Y-%m-01')"
            : ($gran === 'week' ? "DATE(DATE_SUB(sent_on, INTERVAL WEEKDAY(sent_on) DAY))"
                                : "DATE(sent_on)");

    $r = $conn->query("SELECT $bucket AS bucket, channel,
                              SUM(sent) s, SUM(delivered) d, SUM(opened) o,
                              SUM(clicked) c, SUM(conversions) cv
                         FROM ($union) x
                        WHERE sent_on IS NOT NULL
                        GROUP BY bucket, channel
                        ORDER BY bucket ASC");

    // Pivoted to one object per bucket with a key per (metric, channel): a chart wants a row per
    // x-value, and doing this in SQL would mean a column list that changes with the channel filter.
    $byBucket = [];
    while ($r && $row = $r->fetch_assoc()) {
        $b = (string)$row['bucket'];
        if (!isset($byBucket[$b])) {
            $byBucket[$b] = ['date' => $b,
                'sent' => 0, 'delivered' => 0, 'opened' => 0, 'clicked' => 0, 'conversions' => 0,
                'email_sent' => 0, 'email_opened' => 0, 'email_clicked' => 0, 'email_conversions' => 0,
                'whatsapp_sent' => 0, 'whatsapp_opened' => 0, 'whatsapp_clicked' => 0, 'whatsapp_conversions' => 0];
        }
        $ch = $row['channel'];
        $map = ['sent' => 's', 'delivered' => 'd', 'opened' => 'o', 'clicked' => 'c', 'conversions' => 'cv'];
        foreach ($map as $name => $col) {
            $v = (int)$row[$col];
            $byBucket[$b][$name] += $v;
            if (isset($byBucket[$b]["{$ch}_{$name}"])) $byBucket[$b]["{$ch}_{$name}"] += $v;
        }
    }

    api_success(['series' => array_values($byBucket), 'granularity' => $gran]);
}

/* ═══════════════════════════════════════════════════════════════════════════════════════════
   tags
   ═══════════════════════════════════════════════════════════════════════════════════════════ */
if ($action === 'tags') {
    $tags = [];
    $collect = function ($sql) use (&$tags) {
        global $conn;
        $r = @$conn->query($sql);
        while ($r && $row = $r->fetch_assoc()) {
            foreach (explode(',', (string)$row['tags']) as $t) {
                $t = trim($t);
                if ($t !== '') $tags[$t] = ($tags[$t] ?? 0) + 1;
            }
        }
    };
    $collect("SELECT tags FROM email_campaigns WHERE tags IS NOT NULL AND tags <> ''");
    if (ac_has_whatsapp()) $collect("SELECT tags FROM wa_campaigns WHERE tags IS NOT NULL AND tags <> ''");

    arsort($tags);   // most-used first: the tag someone wants is nearly always a recent, busy one
    api_success(['tags' => array_keys($tags), 'counts' => $tags]);
}

/* ═══════════════════════════════════════════════════════════════════════════════════════════
   export — the filtered set as CSV
   ═══════════════════════════════════════════════════════════════════════════════════════════ */
if ($action === 'export') {
    $where = ac_where_sql();
    $union = ac_union($where);
    // Capped rather than unbounded: an accidental unfiltered export of 6,000 campaigns is a
    // request that times out halfway and leaves a truncated file with no indication it is short.
    $r = $conn->query("SELECT * FROM ($union) x ORDER BY sent_on DESC, id DESC LIMIT 5000");

    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="campaigns-' . date('Y-m-d') . '.csv"');
    $out = fopen('php://output', 'w');
    // BOM, so Excel opens a UTF-8 CSV as UTF-8 instead of mangling every non-ASCII campaign name.
    fwrite($out, "\xEF\xBB\xBF");

    fputcsv($out, ['Channel', 'ID', 'Campaign name', 'Status', 'Tags', 'Sent on', 'Published', 'Sent',
                   'Delivered', 'Opened / Read', 'Clicked', 'Conversions', 'Not sent', 'Unsubscribed',
                   'Bounce', 'Spam', 'Undelivered / Failed', 'Replied', 'Goal event', 'Provider']);
    while ($r && $row = $r->fetch_assoc()) {
        $na = fn($v) => $v === null ? 'NA' : $v;
        fputcsv($out, [
            $row['channel'] === 'whatsapp' ? 'WhatsApp' : 'Email',
            $row['id'], $row['name'], $row['status'], $row['tags'], $row['sent_on'],
            $row['published'], $row['sent'], $row['delivered'], $row['opened'], $row['clicked'],
            $row['conversions'], $row['not_sent'], $na($row['unsubscribed']), $na($row['bounce']),
            $na($row['spam']), $na($row['undelivered']), $na($row['replied']),
            $row['goal_event_name'], $row['provider'],
        ]);
    }
    fclose($out);
    exit;
}

/* ═══════════════════════════════════════════════════════════════════════════════════════════
   Custom detailed report — one row per RECIPIENT, with the columns the user picked.

   Different in kind from `export` above: that exports the campaign LIST (one row per campaign),
   this exports one campaign's recipients (one row per person). The three column groups mirror
   what the reference product offers, because they answer three different questions:

     campaign    which send is this row from      (constant down the file, but needed when
                                                   several campaigns are exported together)
     activity    what did this person do          the actual point of the export
     attribute   who is this person               so the file can be used for follow-up

   Delivered STRAIGHT TO THE BROWSER as a download, not mailed to an address with a password on
   it. The reference product's flow exists because its export runs on a queue somewhere else;
   ours is a single indexed query against one campaign's recipients, so making somebody wait for
   an email and then find a password would be ceremony around nothing.
   ═══════════════════════════════════════════════════════════════════════════════════════════ */

/** The picker's options. Sent to the client so the modal and the export can never disagree. */
if ($action === 'report_columns') {
    $campaignCols = [
        ['id' => 'campaign_name', 'label' => 'Campaign name'],
        ['id' => 'campaign_id',   'label' => 'Campaign ID'],
        ['id' => 'channel',       'label' => 'Channel'],
        ['id' => 'status',        'label' => 'Campaign status'],
        ['id' => 'tags',          'label' => 'Tags'],
        ['id' => 'sent_on',       'label' => 'Campaign sent on'],
        ['id' => 'subject',       'label' => 'Subject / template'],
    ];
    $activityCols = [
        ['id' => 'delivery_status', 'label' => 'Delivery status'],
        ['id' => 'sent_time',       'label' => 'Sent time'],
        ['id' => 'delivered_time',  'label' => 'Delivered time'],
        ['id' => 'open_time',       'label' => 'Open time'],
        ['id' => 'open_day',        'label' => 'Open day'],
        ['id' => 'open_count',      'label' => 'Open count'],
        ['id' => 'click_time',      'label' => 'First click time'],
        ['id' => 'click_count',     'label' => 'Click count'],
        ['id' => 'latest_link',     'label' => 'Latest link clicked'],
        ['id' => 'bounce_type',     'label' => 'Bounce type'],
        ['id' => 'bounce_reason',   'label' => 'Bounce reason'],
        ['id' => 'unsubscribed',    'label' => 'Unsubscribed'],
        ['id' => 'error_message',   'label' => 'Failure reason'],
    ];

    /*
     * Attributes come from the recipient row where it has them and from `users` otherwise.
     * Only columns that actually exist are offered — a picker listing a field the export then
     * leaves blank is worse than not offering it.
     */
    $attrs = [];
    $r = @$conn->query("SHOW COLUMNS FROM users");
    $skip = ['password', 'passwd', 'token', 'otp', 'remember_token', 'api_key'];
    while ($r && $row = $r->fetch_assoc()) {
        $f = strtolower($row['Field']);
        // Credentials are never exportable, whatever anyone ticks.
        foreach ($skip as $s) if (strpos($f, $s) !== false) continue 2;
        $attrs[] = ['id' => 'u.' . $row['Field'], 'label' => strtoupper($row['Field']), 'group' => 'System attributes'];
    }
    api_success(['campaign' => $campaignCols, 'activity' => $activityCols, 'attributes' => $attrs]);
}

if ($action === 'detailed_report') {
    $channel = jin('channel', 'email') === 'whatsapp' ? 'whatsapp' : 'email';
    $id      = (int)jin('id', 0);
    if ($id <= 0) api_error('Pick a campaign', 400);

    $pick = function ($k) {
        $v = $_REQUEST[$k] ?? [];
        if (is_string($v)) $v = array_filter(explode(',', $v));
        return array_values(array_map('strval', (array)$v));
    };
    $cCols = $pick('campaign_cols');
    $aCols = $pick('activity_cols');
    $xCols = $pick('attribute_cols');
    if (!$cCols && !$aCols && !$xCols) api_error('Select at least one column', 400);

    $tbl  = $channel === 'whatsapp' ? 'wa_campaigns' : 'email_campaigns';
    $rTbl = $channel === 'whatsapp' ? 'wa_campaign_recipients' : 'email_campaign_recipients';

    $cr = $conn->query("SELECT * FROM $tbl WHERE id=$id LIMIT 1");
    $camp = $cr ? $cr->fetch_assoc() : null;
    if (!$camp) api_error('Campaign not found', 404);

    /*
     * Attribute columns are the only user-supplied identifiers that reach the SQL, so they are
     * checked against the live column list rather than escaped — escaping a column name does not
     * make an arbitrary one safe, and a whitelist is the only thing that does.
     */
    $userCols = [];
    $uc = @$conn->query("SHOW COLUMNS FROM users");
    while ($uc && $row = $uc->fetch_assoc()) $userCols[strtolower($row['Field'])] = $row['Field'];

    $selectAttrs = [];
    foreach ($xCols as $x) {
        $name = strtolower(preg_replace('/^u\./', '', $x));
        if (isset($userCols[$name])) $selectAttrs[$userCols[$name]] = "u.`{$userCols[$name]}`";
    }
    $attrSql = $selectAttrs ? ', ' . implode(', ', $selectAttrs) : '';

    // LEFT JOIN, because a campaign legitimately reaches people with no user row (an imported
    // list). Those rows still belong in the file, with the attribute columns simply empty.
    $join = $channel === 'whatsapp'
        ? "LEFT JOIN users u ON u.user_id = r.user_id"
        : "LEFT JOIN users u ON u.user_id = r.user_id";

    $rows = $conn->query("SELECT r.* $attrSql FROM $rTbl r $join
                           WHERE r.campaign_id = $id AND r.is_test = 0
                           ORDER BY r.id ASC");

    $slug = preg_replace('/[^A-Za-z0-9_-]+/', '-', (string)$camp['name']);
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="report-' . $slug . '-' . $id . '.csv"');
    $out = fopen('php://output', 'w');
    fwrite($out, "\xEF\xBB\xBF");   // BOM so Excel reads UTF-8 correctly

    $campLabels = ['campaign_name' => 'Campaign name', 'campaign_id' => 'Campaign ID',
                   'channel' => 'Channel', 'status' => 'Campaign status', 'tags' => 'Tags',
                   'sent_on' => 'Campaign sent on', 'subject' => 'Subject / template'];
    $actLabels  = ['delivery_status' => 'Delivery status', 'sent_time' => 'Sent time',
                   'delivered_time' => 'Delivered time', 'open_time' => 'Open time',
                   'open_day' => 'Open day', 'open_count' => 'Open count',
                   'click_time' => 'First click time', 'click_count' => 'Click count',
                   'latest_link' => 'Latest link clicked', 'bounce_type' => 'Bounce type',
                   'bounce_reason' => 'Bounce reason', 'unsubscribed' => 'Unsubscribed',
                   'error_message' => 'Failure reason'];

    $header = [];
    // Recipient identity is always present — a report of activity with no way to tell whose it is
    // has no use, and nobody would think to tick it.
    $header[] = $channel === 'whatsapp' ? 'Phone' : 'Email';
    foreach ($cCols as $c) $header[] = $campLabels[$c] ?? $c;
    foreach ($aCols as $c) $header[] = $actLabels[$c] ?? $c;
    foreach (array_keys($selectAttrs) as $c) $header[] = strtoupper($c);
    fputcsv($out, $header);

    $campSentOn = $camp['completed_at'] ?: ($camp['started_at'] ?: ($camp['scheduled_at'] ?: $camp['created_at']));
    $day = fn($ts) => $ts ? date('l', strtotime($ts)) : '';

    while ($rows && $r = $rows->fetch_assoc()) {
        $line = [$channel === 'whatsapp' ? ($r['phone'] ?? '') : ($r['email'] ?? '')];

        foreach ($cCols as $c) {
            switch ($c) {
                case 'campaign_name': $line[] = $camp['name']; break;
                case 'campaign_id':   $line[] = $id; break;
                case 'channel':       $line[] = $channel === 'whatsapp' ? 'WhatsApp' : 'Email'; break;
                case 'status':        $line[] = $camp['status']; break;
                case 'tags':          $line[] = $camp['tags']; break;
                case 'sent_on':       $line[] = $campSentOn; break;
                case 'subject':       $line[] = $channel === 'whatsapp' ? ($camp['template_name'] ?? '') : ($camp['subject'] ?? ''); break;
                default:              $line[] = '';
            }
        }

        foreach ($aCols as $c) {
            switch ($c) {
                case 'delivery_status': $line[] = $r['status'] ?? ''; break;
                case 'sent_time':       $line[] = $r['sent_at'] ?? ''; break;
                case 'delivered_time':  $line[] = $r['delivered_at'] ?? ''; break;
                // WhatsApp calls it read_at; the column header still says Open time, because the
                // person exporting is asking one question regardless of channel.
                case 'open_time':       $line[] = $r['opened_at'] ?? ($r['read_at'] ?? ''); break;
                case 'open_day':        $line[] = $day($r['opened_at'] ?? ($r['read_at'] ?? null)); break;
                case 'open_count':      $line[] = $r['open_count'] ?? ''; break;
                case 'click_time':      $line[] = $r['first_clicked_at'] ?? ''; break;
                case 'click_count':     $line[] = $r['click_count'] ?? 0; break;
                case 'latest_link':     $line[] = ac_latest_link($channel, (int)$r['id']); break;
                case 'bounce_type':     $line[] = $r['bounce_type'] ?? ''; break;
                case 'bounce_reason':   $line[] = $r['error_message'] ?? ''; break;
                case 'unsubscribed':    $line[] = ac_was_unsubscribed($channel, (int)$r['id']) ? 'Yes' : 'No'; break;
                case 'error_message':   $line[] = $r['error_message'] ?? ''; break;
                default:                $line[] = '';
            }
        }

        foreach (array_keys($selectAttrs) as $c) $line[] = $r[$c] ?? '';
        fputcsv($out, $line);
    }
    fclose($out);
    exit;
}

/** The most recent URL this recipient clicked, or ''. Email only — WhatsApp taps carry no URL. */
function ac_latest_link(string $channel, int $recipientId): string {
    global $conn;
    if ($channel !== 'email') return '';
    $r = @$conn->query("SELECT url FROM email_campaign_events
                         WHERE recipient_id = $recipientId AND event_type = 'click' AND url IS NOT NULL
                         ORDER BY id DESC LIMIT 1");
    $row = $r ? $r->fetch_assoc() : null;
    return (string)($row['url'] ?? '');
}

/** Did this recipient unsubscribe from this send? Email only. */
function ac_was_unsubscribed(string $channel, int $recipientId): bool {
    global $conn;
    if ($channel !== 'email') return false;
    $r = @$conn->query("SELECT 1 FROM email_campaign_events
                         WHERE recipient_id = $recipientId AND event_type = 'unsubscribe' LIMIT 1");
    return (bool)($r && $r->num_rows > 0);
}

api_error('Invalid action', 400);

<?php
/**
 * /api/caller-iq/sim_status.php  —  what a carrier said about a SIM (no JWT: phones cannot log in)
 * ---------------------------------------------------------------------------
 * POST { device_id, slot, carrier?, ok, text, code?, valid_till?, balance?, checked_at? }
 *
 * Sent by the app after it runs the operator's own balance code (*121# and the like) on a SIM.
 * Android exposes no prepaid balance or plan validity to apps, so this reply — the same text the
 * counselor would see after dialling it by hand — is the only way to learn either.
 *
 * Whatever a person typed into the SIM register is never touched: the reply lands in its own
 * columns and the panel shows the human record first.
 * ---------------------------------------------------------------------------
 */
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../middleware/auth.php';
require_once __DIR__ . '/ciq_lib.php';

mysqli_report(MYSQLI_REPORT_OFF);
set_exception_handler(function (Throwable $e) {
    error_log('[caller-iq sim] ' . $e->getMessage() . ' @ ' . $e->getFile() . ':' . $e->getLine());
    api_error('Temporary failure, retry later', 503);
});

require_method('POST');

if (!function_exists('ciq_sim_status')) {
    api_error('Server not ready: deploy react-api/api/caller-iq/ciq_lib.php', 503);
}

$in = get_json_input();

if (CALLER_IQ_INGEST_KEY !== '') {
    $sent = $_SERVER['HTTP_X_CALLIQ_KEY'] ?? ($in['key'] ?? '');
    if (!hash_equals(CALLER_IQ_INGEST_KEY, (string)$sent)) api_error('Invalid ingest key', 401);
}

if (!$in || !is_array($in)) api_success(['stored' => false], 'Empty payload ignored');

ciq_ensure_schema($conn);

$r = ciq_sim_status($conn, $in);
if (!$r['ok']) {
    error_log('[caller-iq sim] ' . ($r['reason'] ?? 'unknown'));
    // A bad slot is the phone's problem and will never succeed; anything else is ours.
    if (($r['reason'] ?? '') === 'a SIM slot is required') api_success(['stored' => false], 'Ignored');
    api_error('Could not store the SIM status, retry later', 503);
}

api_success([
    'stored'            => true,
    'parsed_valid_till' => $r['parsed_valid_till'] ?? null,
    'parsed_balance'    => $r['parsed_balance'] ?? '',
], 'Stored');

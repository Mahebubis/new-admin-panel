<?php
/*
 * bounce-backfill.php — read the mailbox's own history and blocklist the addresses that do not exist.
 *
 * WHY THIS IS A SEPARATE, RESUMABLE JOB
 * Every registration email that ever failed produced a "Mail delivery failed" reply into contact@,
 * and that mailbox still holds 545,741 messages — roughly 115,000 of them inside the window this
 * job covers. The live path (fd_sync → TicketStore → BounceMailbox) handles new bounces from now
 * on; this one walks backwards through everything that arrived before it existed.
 *
 * It cannot be a single long run: reading 115,000 messages over IMAP takes hours, and a connection
 * drop, a deploy or a server restart would lose the lot. So it keeps its place in the database and
 * does a few minutes of work per invocation. Run it from cron every five minutes and it finishes on
 * its own; once it reaches the end it marks itself done and every later run exits immediately,
 * which is what makes leaving the cron in place harmless.
 *
 *   cron:  *X/5 * * * * flock -n /tmp/bounce-backfill.lock /usr/bin/php8.3 <this file>
 *   env:   SINCE=26-Apr-2026  BEFORE=24-Sep-2026  BUDGET=240  (seconds per run)
 *
 * THE RULES ARE THE LIVE ONES, NOT LOOSER ONES
 *   - only a PERMANENT failure (5.x.x, "the account does not exist") blocklists an address;
 *   - a full mailbox or a greylisting is recorded and never blocks anybody;
 *   - our own addresses are skipped;
 *   - the blocklist is OURS only — nothing is sent to SendGrid, SES or Elastic Email;
 *   - the mailbox is opened READ-ONLY: nothing is deleted, moved, or marked as read.
 */

$root = __DIR__ . '/../..';
require_once $root . '/config/database.php';
require_once $root . '/api/freshdesk/lib/config.php';
require_once $root . '/api/freshdesk/lib/Helpers.php';
require_once $root . '/api/freshdesk/lib/ImapClient.php';
require_once $root . '/api/freshdesk/lib/MimeParser.php';
require_once $root . '/api/campaigns/lib/BounceMailbox.php';

@set_time_limit(0);
ignore_user_abort(true);

/*
 * PHASE — which window this run is walking.
 *   1 = 26 Apr 2026 .. 23 Sep 2026 17:30   (done; the live path took over from there)
 *   2 = everything older, for people who registered up to 25 Apr 2026
 * Each phase keeps its own place in bounce_backfill_state, so they never overwrite one another
 * and either can be re-run or resumed on its own.
 */
$PHASE  = max(1, (int)(getenv('PHASE') ?: 1));
$SINCE  = getenv('SINCE')  ?: '26-Apr-2026';
$BEFORE = getenv('BEFORE') ?: '24-Sep-2026';   // exclusive; the 23rd is trimmed by time below
$BUDGET = (int)(getenv('BUDGET') ?: 240);          // seconds of work per run
$FETCH  = 25;                                       // bodies fetched per batch
$HEAD   = 500;                                      // headers per IMAP command — the cheap pass
$PARTIAL = 50;                                      // bodies per command on the fast path

/* Only people who registered in the window this backfill is about. */
$WIN_FROM = getenv('WIN_FROM') ?: '2026-04-26 00:00:00';
$WIN_TO   = getenv('WIN_TO')   ?: '2026-09-23 17:30:00';

function bb_log(string $msg): void {
    echo '[' . date('Y-m-d H:i:s') . '] ' . $msg . "\n";
}

/**
 * The database closes an idle connection, and this job spends minutes at a time waiting on IMAP.
 * The first run died exactly there — "MySQL server has gone away" on the query after a long fetch.
 * One cheap round trip before each burst of database work, and a reconnect when it has gone.
 */
function bb_db_alive(): void {
    global $conn;
    try { if (@$conn->query('SELECT 1')) return; } catch (\Throwable $e) { /* reconnect below */ }
    try {
        $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
        $conn->set_charset('utf8mb4');
        bb_log('database connection was dropped during a long read — reconnected');
    } catch (\Throwable $e) {
        bb_log('database reconnect FAILED — ' . $e->getMessage());
    }
}

/* ── where we got to last time ──────────────────────────────────────────── */
@$conn->query("CREATE TABLE IF NOT EXISTS bounce_backfill_state (
    id          TINYINT UNSIGNED NOT NULL PRIMARY KEY,
    last_uid    BIGINT UNSIGNED NOT NULL DEFAULT 0,
    done        TINYINT(1)      NOT NULL DEFAULT 0,
    seen_msgs   BIGINT UNSIGNED NOT NULL DEFAULT 0,
    seen_bounce BIGINT UNSIGNED NOT NULL DEFAULT 0,
    hard_found  BIGINT UNSIGNED NOT NULL DEFAULT 0,
    blocked     BIGINT UNSIGNED NOT NULL DEFAULT 0,
    updated_at  DATETIME DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
@$conn->query("INSERT IGNORE INTO bounce_backfill_state (id, updated_at) VALUES ($PHASE, NOW())");

$st = $conn->query("SELECT * FROM bounce_backfill_state WHERE id = $PHASE")->fetch_assoc();
if ((int)$st['done'] === 1) { bb_log("phase $PHASE already finished — nothing to do"); exit; }
$lastUid = (int)$st['last_uid'];

bounce_mailbox_ensure_schema();
$listId = (int)lists_get_or_create_blocklist_id();

/* ── the messages still to read ─────────────────────────────────────────── */
$imap = new ImapClient();
$imap->connect();
$imap->login();
$imap->selectFolder('INBOX', true);                 // read-only
/*
 * The SEARCH over five months of mail returns the same 115,000 ids every time, so it is asked once
 * and kept on disk. A cron every five minutes would otherwise spend a chunk of each run rebuilding
 * a list that cannot change: the window is closed and in the past.
 */
$cacheFile = sys_get_temp_dir() . '/bounce-backfill-uids-' . md5($SINCE . '|' . $BEFORE) . '.json';
$uids = @file_exists($cacheFile) ? (json_decode((string)@file_get_contents($cacheFile), true) ?: []) : [];
if (!$uids) {
    $uids = $imap->searchDateRange($SINCE, $BEFORE);
    @file_put_contents($cacheFile, json_encode(array_map('intval', $uids)));
}
sort($uids, SORT_NUMERIC);
$todo = array_values(array_filter($uids, fn($u) => (int)$u > $lastUid));
bb_log(sprintf('window %s..%s: %d message(s) in range, %d still to read (resuming after uid %d)',
    $SINCE, $BEFORE, count($uids), count($todo), $lastUid));

if (!$todo) {
    $conn->query("UPDATE bounce_backfill_state SET done = 1, updated_at = NOW() WHERE id = $PHASE");
    $imap->close();
    bb_log("FINISHED — phase $PHASE has read every message in its window. This cron can be removed.");
    exit;
}

/* ── read, parse, decide ────────────────────────────────────────────────── */
$deadline = microtime(true) + $BUDGET;
$run = ['msgs' => 0, 'bounces' => 0, 'hard' => 0, 'soft' => 0, 'blocked' => 0];
$pending = [];                                      // email => reason, flushed in batches

$flush = function () use (&$pending, &$run, &$conn, $listId, $WIN_FROM, $WIN_TO) {
    if (!$pending) return;
    bb_db_alive();
    $emails = array_keys($pending);
    $in = implode(',', array_map(fn($e) => "'" . $conn->real_escape_string($e) . "'", $emails));
    /* Registered inside the window this backfill is for — one query per batch, not per address. */
    $keep = [];
    $r = $conn->query("SELECT LOWER(email) e FROM istudio_cit.users
                        WHERE email IN ($in) AND registered_at BETWEEN '$WIN_FROM' AND '$WIN_TO'");
    while ($r && $row = $r->fetch_assoc()) $keep[] = $row['e'];

    /* Who is already blocked — one query for the whole batch, not one per address. */
    $blocked = [];
    if ($keep) {
        $inK = implode(',', array_map(fn($e) => "'" . $conn->real_escape_string($e) . "'", $keep));
        $rb = $conn->query("SELECT LOWER(c.email) e FROM campaign_contacts c
                             INNER JOIN campaign_list_members m ON m.contact_id = c.id AND m.list_id = $listId
                             WHERE c.email IN ($inK)");
        while ($rb && $row = $rb->fetch_assoc()) $blocked[$row['e']] = true;
    }

    $rows = [];
    foreach ($keep as $e) {
        if (isset($blocked[$e])) continue;
        $rows[] = ['email' => $e, 'reason' => $pending[$e]];
        $esc = $conn->real_escape_string($e);
        $conn->query("INSERT IGNORE INTO email_bounce_reports (fd_message_id, email, kind, smtp_code, reason, reported_at, blocklisted)
                      VALUES (0, '$esc', 'hard', '5.x.x', '" . $conn->real_escape_string($pending[$e]) . "', NOW(), 1)");
    }
    if ($rows) {
        contact_upsert_many($rows, $listId, false);  // our blocklist only
        $run['blocked'] += count($rows);
    }
    $pending = [];
};

/*
 * HEADERS FIRST, BODIES ONLY FOR BOUNCES.
 *
 * fetchMessages() asks for one message per IMAP command — 115,000 round trips for this window, and
 * most of them for ordinary support mail that is thrown away a line later. fetchHeaders() asks for
 * five hundred in ONE command and returns only the headers, which is all that is needed to answer
 * "is this a delivery failure". The body — the expensive part, and the only part that names the
 * dead address — is then fetched for the few that are.
 *
 * On this mailbox that turns roughly 115,000 full downloads into 230 header commands plus the
 * bodies of the actual bounces.
 */
foreach (array_chunk($todo, $HEAD) as $chunk) {
    if (microtime(true) >= $deadline) break;

    $headers = $imap->fetchHeaders($chunk);
    $candidates = [];
    foreach ($headers as $uid => $head) {
        $run['msgs']++;
        $lastUid = max($lastUid, (int)$uid);
        $h = strtolower($head);
        $isBounce = strpos($h, 'mailer-daemon') !== false || strpos($h, 'postmaster@') !== false
                 || strpos($h, 'subject: mail delivery failed') !== false
                 || strpos($h, 'undelivered mail') !== false
                 || strpos($h, 'delivery status notification') !== false;
        if (!$isBounce) continue;

        /* The live path owns everything after 23 Sep 17:30; read from the header, no body needed. */
        if (preg_match('~^date:\s*(.+)$~mi', $head, $dm)) {
            $when = strtotime(trim($dm[1])) ?: 0;
            if ($when && $when > strtotime($WIN_TO)) continue;
        }
        $candidates[] = (int)$uid;
    }

    /*
     * The bodies, cheaply: the first 8KB of fifty messages in ONE command. A delivery report puts
     * the failed address and the server's reply at the top, so the prefix answers the question for
     * almost all of them. The few it does not — a base64 body, an unusual layout — fall back to the
     * full download below, which is the slow path used only where it is actually needed.
     */
    foreach (array_chunk($candidates, $PARTIAL) as $bodyChunk) {
        $missed = [];
        try {
            $partials = $imap->fetchPartialBodies($bodyChunk, 8192);
        } catch (Throwable $e) {
            bb_log('partial fetch failed, falling back to full download — ' . $e->getMessage());
            $partials = [];
        }
        foreach ($bodyChunk as $uid) {
            $body = (string)($partials[$uid] ?? '');
            $found = $body !== '' ? bounce_parse_report($body) : [];
            if (!$found) { $missed[] = $uid; continue; }
            $run['bounces']++;
            foreach ($found as $email => $info) {
                if ($info['kind'] !== 'hard') { $run['soft']++; continue; }
                $run['hard']++;
                $pending[$email] = 'Hard bounce: ' . mb_substr($info['reason'], 0, 160);
            }
        }

        foreach (array_chunk($missed, $FETCH) as $slow) {
            foreach ($imap->fetchMessages($slow) as $uid => $msg) {
                $run['bounces']++;
                $parsed = MimeParser::parse($msg['raw']);
                $body = trim((string)($parsed['body_text'] ?? ''));
                if ($body === '') $body = trim(strip_tags((string)($parsed['body_html'] ?? '')));
                if ($body === '') $body = (string)$msg['raw'];
                foreach (bounce_parse_report($body) as $email => $info) {
                    if ($info['kind'] !== 'hard') { $run['soft']++; continue; }
                    $run['hard']++;
                    $pending[$email] = 'Hard bounce: ' . mb_substr($info['reason'], 0, 160);
                }
            }
            if (microtime(true) >= $deadline) break;
        }
        if (microtime(true) >= $deadline) break;
    }
    if (count($pending) >= 200) $flush();
}
$flush();
$imap->close();

bb_db_alive();
$conn->query("UPDATE bounce_backfill_state
                 SET last_uid = " . (int)$lastUid . ",
                     seen_msgs = seen_msgs + {$run['msgs']},
                     seen_bounce = seen_bounce + {$run['bounces']},
                     hard_found = hard_found + {$run['hard']},
                     blocked = blocked + {$run['blocked']},
                     updated_at = NOW()
               WHERE id = $PHASE");

$tot = $conn->query("SELECT seen_msgs, seen_bounce, hard_found, blocked FROM bounce_backfill_state WHERE id = $PHASE")->fetch_assoc();
bb_log(sprintf('this run: %d read, %d bounces, %d permanent, %d blocklisted | totals: %s read, %s bounces, %s blocklisted | next uid > %d',
    $run['msgs'], $run['bounces'], $run['hard'], $run['blocked'],
    $tot['seen_msgs'], $tot['seen_bounce'], $tot['blocked'], $lastUid));

<?php
/*
 * lib/WaTemplateSubmit.php — sending one template to Meta, callable from more than one place.
 *
 * This was the body of wa_templates.php?action=submit_to_meta and nothing else could reach it. It
 * has to be reachable now because a template is not only submitted when somebody presses the
 * button: a Call button carries the number an attribute held AT THE MOMENT IT WAS APPROVED, and
 * Meta renders that stored number for every recipient afterwards. Change the attribute and the
 * approved template keeps dialling the old number until it is submitted again.
 *
 * So attributes.php calls this when a value changes. The work is identical either way, which is
 * the point of moving it rather than writing it twice.
 *
 * NOTHING HERE EXITS. The endpoint version answered with api_error()/api_success(), which end the
 * request; a library that did that would kill the attribute save half way through. Every path
 * returns an array instead and the caller decides what to do with it.
 */

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/schema.php';
require_once __DIR__ . '/WaTemplateWabas.php';
require_once __DIR__ . '/WaMetaComponents.php';

/** A refusal, in the shape every caller checks. */
function wa_submit_fail(string $message): array {
    return ['ok' => false, 'error' => $message];
}

/** A success, carrying what the endpoint used to answer with. */
function wa_submit_ok(array $data): array {
    return ['ok' => true, 'data' => $data];
}

/**
 * Submit (or edit) one template on every active business account, or on one named account.
 *
 * @return array{ok: bool, error?: string, data?: array}
 */
function wa_submit_template(int $templateId, string $onlyWaba = ''): array {
    global $conn;
    $id = (int)$templateId;
    $r = $conn->query("SELECT * FROM wa_templates WHERE id=$id LIMIT 1");
    $t = $r ? $r->fetch_assoc() : null;
    if (!$t) return wa_submit_fail('That template no longer exists.');

    $settings = wa_settings_row() ?: [];
    $token = trim((string)($settings['meta_access_token'] ?? ''));
    if ($token === '') return wa_submit_fail('Add a Meta access token in Settings → Template sync first.');

    /*
     * Which accounts to submit to. A specific waba_id narrows it to one — used by the
     * editor's per-row "Submit to this account" button, for the case where one account
     * came back rejected and only that one needs resubmitting.
     */
    $onlyWaba = trim((string)$onlyWaba);
    $targets = wa_active_wabas();
    if ($onlyWaba !== '') {
        $targets = array_values(array_filter($targets, fn($w) => $w['waba_id'] === $onlyWaba));
        if (!$targets) return wa_submit_fail("No active sending number belongs to WABA $onlyWaba.");
    }
    if (!$targets) {
        return wa_submit_fail('No WABA ID on any active sending number — add one in Settings → Sending numbers.');
    }

    // Caught here rather than as a Meta rejection, because Meta's message for this is far less
    // clear than naming the specific missing sample. Checked once, not once per account.
    $bodyVars = wa_placeholder_count((string)$t['body_text']);
    $samples = json_decode($t['sample_values'] ?? '{}', true) ?: [];
    for ($i = 0; $i < $bodyVars; $i++) {
        if (trim((string)($samples['body'][$i] ?? '')) === '') {
            return wa_submit_fail('Meta needs a sample value for every variable. Fill in "Sample values" for body {{' . ($i + 1) . '}} before submitting.');
        }
    }

    /* Rendering can refuse — an attribute with no value behind a Call button, for one — and a
       refusal has to come back as a result, not as an exception escaping into whatever called us. */
    try {
        $components = wa_build_meta_components($t);
    } catch (Throwable $e) {
        return wa_submit_fail($e->getMessage());
    }
    $results = [];
    $anyOk = false;

    foreach ($targets as $target) {
        $wabaId = $target['waba_id'];

        // The id THIS account already knows this template by — per-WABA, because the same
        // template has a different id on each one and reusing the wrong id edits somebody
        // else's template or 404s.
        $exRow = $conn->query("SELECT meta_template_id FROM wa_template_wabas
                                WHERE template_id = $id AND waba_id = '" . $conn->real_escape_string($wabaId) . "' LIMIT 1");
        $existingId = trim((string)(($exRow ? $exRow->fetch_assoc() : null)['meta_template_id'] ?? ''));

        /*
         * CREATE a new template, or EDIT the one this account already has.
         *
         * Creating twice with the same name+language is refused outright:
         *   (#100) There is already English content for this template. You can create a new template
         *          and try again.
         * which is what every resubmit of a REJECTED template hits — exactly when someone is fixing
         * the thing Meta objected to. Editing is the operation that was wanted, and Meta allows it on
         * a rejected or approved template.
         *
         * Falls back to creating when the edit is refused, because a template id can go stale:
         * deleted on Meta, or recreated under a new id after a 30-day name cooldown.
         */
        $res = null;
        if ($existingId !== '') {
            /*
             * category is sent on the edit as well as the components.
             *
             * Meta FIXES a template's category when it is created, and an edit that omits it silently
             * keeps the old one — so a template rejected as INCORRECT_CATEGORY stays rejected no
             * matter how many times it is resubmitted, because the one thing that needed to change
             * never left this server.
             */
            $res = wa_graph('POST', WA_GRAPH_BASE . WA_GRAPH_VERSION . '/' . rawurlencode($existingId),
                $token, ['components' => $components, 'category' => strtoupper($t['category'])]);

            /*
             * ONLY A STALE ID IS A REASON TO CREATE INSTEAD.
             *
             * Every failed edit used to fall straight through to creating a new template. That is
             * right when the id no longer exists at Meta, and wrong for every other refusal —
             * because creating a second template under a name Meta already holds is refused too,
             * with "There is already English content for this template", which then became the
             * message somebody saw. The real reason was on the edit, and it was thrown away.
             *
             * The one that actually happens: Meta allows an approved template to be edited once in
             * 24 hours. An attribute changed twice in a day hits it on the second change, and the
             * panel reported a content clash that had nothing to do with anything.
             *
             * So the edit's own answer stands unless it says the template is gone.
             */
            if (!$res['ok']) {
                $editErr = strtolower((string)($res['error'] ?? ''));
                $stale = strpos($editErr, 'does not exist') !== false
                      || strpos($editErr, 'unsupported post request') !== false
                      || strpos($editErr, 'cannot be loaded') !== false
                      || strpos($editErr, 'missing permissions') !== false;
                if ($stale) { $existingId = ''; $res = null; }
            }
        }
        if ($res === null) {
            $res = wa_graph('POST', WA_GRAPH_BASE . WA_GRAPH_VERSION . '/' . rawurlencode($wabaId) . '/message_templates',
                $token, [
                    'name'       => $t['name'],
                    'language'   => $t['language'],
                    'category'   => strtoupper($t['category']),
                    'components' => $components,
                ]);
        }

        if (!$res['ok']) {
            wa_template_waba_upsert($id, $wabaId, [
                'waba_name'      => $target['waba_name'],
                'last_error'     => mb_substr((string)$res['error'], 0, 490),
                'last_synced_at' => date('Y-m-d H:i:s'),
            ]);
            $results[] = ['waba_id' => $wabaId, 'waba_name' => $target['waba_name'],
                          'ok' => false, 'error' => $res['error']];
            continue;
        }

        // An edit answers {"success": true} with no id, so the one this account already holds stands.
        $metaId = (string)($res['data']['id'] ?? $existingId);
        $status = strtolower((string)($res['data']['status'] ?? 'pending'));
        $status = in_array($status, ['approved', 'pending', 'rejected'], true) ? $status : 'pending';
        // Meta echoes the category it FILED it under, which is not always the one that was asked
        // for — capturing it here is what makes a same-day reclassification visible immediately
        // rather than on the next sweep.
        $cat = strtolower(trim((string)($res['data']['category'] ?? '')));

        wa_template_waba_upsert($id, $wabaId, [
            'waba_name'        => $target['waba_name'],
            'meta_template_id' => $metaId,
            'approval_status'  => $status,
            'meta_category'    => $cat !== '' ? $cat : null,
            'rejected_reason'  => null,
            'last_error'       => null,
            'submitted_at'     => date('Y-m-d H:i:s'),
            'last_synced_at'   => date('Y-m-d H:i:s'),
        ]);
        $results[] = ['waba_id' => $wabaId, 'waba_name' => $target['waba_name'], 'ok' => true,
                      'meta_template_id' => $metaId, 'approval_status' => $status, 'category' => $cat];
        $anyOk = true;
    }

    $summary = wa_template_recompute($id);

    /*
     * Every account refused it — that is a failure, not a partial success, and answering 200
     * with a green toast would be the panel telling somebody their template is in review when
     * nothing was submitted anywhere. The first error is the message, because they are usually
     * the same error repeated per account.
     */
    if (!$anyOk) {
        $first = $results[0]['error'] ?? 'Meta refused the submission.';
        return wa_submit_fail(count($results) > 1
            ? "Submitted to " . count($results) . " business accounts and every one refused it. First error: $first"
            : $first);
    }

    return wa_submit_ok([
        'results'         => $results,
        'submitted_to'    => count(array_filter($results, fn($x) => $x['ok'])),
        'failed'          => count(array_filter($results, fn($x) => !$x['ok'])),
        'approval_status' => $summary['approval_status'] ?? 'pending',
        'auto_disabled'   => $summary['auto_disabled'] ?? 0,
        'disabled_reason' => $summary['disabled_reason'] ?? null,
        'wabas'           => wa_template_waba_rows($id),
    ]);
}


/* ════════════════════════════════════════════════════════════════════════════
   RESUBMITS META WILL NOT TAKE YET
   ════════════════════════════════════════════════════════════════════════════

   Meta lets an approved template be edited ONCE IN 24 HOURS. An attribute changed a second time in
   a day therefore cannot reach the templates that use it until the window reopens — and the change
   has already been saved here. Left alone, the panel shows the new number while every message
   goes on dialling the old one, indefinitely, because nothing ever tries again.

   So a refusal for that reason is parked with the moment it becomes allowed, and the WhatsApp
   worker (which runs every minute) retries it then. The change does reach Meta; it just waits for
   Meta's rule. A refusal for any other reason is not parked — that one needs a person.
*/

if (!defined('WA_RESUBMIT_MARGIN_MINUTES')) define('WA_RESUBMIT_MARGIN_MINUTES', 5);

function wa_resubmit_ensure_schema(): void {
    global $conn;
    static $done = false;
    if ($done) return;
    $done = true;
    @$conn->query("CREATE TABLE IF NOT EXISTS wa_template_resubmits (
        template_id  INT UNSIGNED NOT NULL PRIMARY KEY,
        reason       VARCHAR(255) NOT NULL DEFAULT '',
        not_before   DATETIME NOT NULL,
        attempts     INT UNSIGNED NOT NULL DEFAULT 0,
        last_error   VARCHAR(500) DEFAULT NULL,
        created_at   DATETIME NOT NULL,
        updated_at   DATETIME NOT NULL,
        KEY idx_due (not_before)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
}

/** True when Meta refused because the template was already edited inside the last 24 hours. */
function wa_resubmit_is_edit_window(string $error): bool {
    return stripos($error, 'once in 24 hours') !== false;
}

/**
 * When Meta will next accept an edit of this template: 24 hours after the latest submission to any
 * account, plus a small margin so the retry does not land a few seconds early and get refused again.
 */
function wa_resubmit_next_allowed(int $templateId): string {
    global $conn;
    $r = $conn->query("SELECT MAX(submitted_at) t FROM wa_template_wabas WHERE template_id = " . (int)$templateId);
    $last = $r ? (string)($r->fetch_assoc()['t'] ?? '') : '';
    $base = $last !== '' ? strtotime($last) : time();
    return date('Y-m-d H:i:s', $base + 86400 + (int)WA_RESUBMIT_MARGIN_MINUTES * 60);
}

/** Park a template to be resubmitted at the given moment. Re-parking moves the time, never duplicates. */
function wa_resubmit_enqueue(int $templateId, string $notBefore, string $reason): void {
    global $conn;
    wa_resubmit_ensure_schema();
    $nb = $conn->real_escape_string($notBefore);
    $rs = $conn->real_escape_string(mb_substr($reason, 0, 250));
    $now = date('Y-m-d H:i:s');
    $conn->query("INSERT INTO wa_template_resubmits (template_id, reason, not_before, created_at, updated_at)
                  VALUES (" . (int)$templateId . ", '$rs', '$nb', '$now', '$now')
                  ON DUPLICATE KEY UPDATE reason = VALUES(reason), not_before = VALUES(not_before), updated_at = '$now'");
}

/**
 * Retry every parked resubmit whose time has come. Returns what happened, one row per template.
 * Never throws: it runs inside the send worker, and a Meta hiccup must not stop messages going out.
 */
function wa_resubmit_run_due(int $limit = 10): array {
    global $conn;
    $out = [];
    try {
        wa_resubmit_ensure_schema();
        $now = $conn->real_escape_string(date('Y-m-d H:i:s'));
        $q = $conn->query("SELECT template_id, reason, attempts FROM wa_template_resubmits
                            WHERE not_before <= '$now' ORDER BY not_before LIMIT " . (int)$limit);
        $due = [];
        while ($q && $row = $q->fetch_assoc()) $due[] = $row;

        foreach ($due as $row) {
            $tid = (int)$row['template_id'];
            $res = wa_submit_template($tid);
            if (!empty($res['ok'])) {
                $conn->query("DELETE FROM wa_template_resubmits WHERE template_id = $tid");
                $out[] = ['template_id' => $tid, 'ok' => true];
                continue;
            }
            $err = (string)($res['error'] ?? 'Meta refused it');
            if (wa_resubmit_is_edit_window($err)) {
                // Still inside the window after all — move it on rather than hammering Meta.
                wa_resubmit_enqueue($tid, wa_resubmit_next_allowed($tid), (string)$row['reason']);
            } else {
                // A different refusal needs a person. Keep the row, stop retrying it automatically.
                $conn->query("UPDATE wa_template_resubmits
                                 SET attempts = attempts + 1,
                                     last_error = '" . $conn->real_escape_string(mb_substr($err, 0, 490)) . "',
                                     not_before = DATE_ADD(NOW(), INTERVAL 100 YEAR),
                                     updated_at = '" . $now . "'
                               WHERE template_id = $tid");
            }
            $out[] = ['template_id' => $tid, 'ok' => false, 'error' => $err];
        }
    } catch (Throwable $e) {
        $out[] = ['template_id' => 0, 'ok' => false, 'error' => $e->getMessage()];
    }
    return $out;
}


/**
 * Will this template's Call button dial the number its attribute holds right now?
 *
 * A template carrying [SUPPORT_NUMBER] is approved holding whatever that resolved to at the time,
 * and Meta renders its own copy for every message. When the attribute changes, the template only
 * catches up once Meta accepts the edit — and Meta takes one edit of an approved template per 24
 * hours. In between, every campaign built on it dials the OLD number, while the panel shows the
 * new one everywhere. Campaigns 81 and 82 went out exactly like that, both dialling +918329597774
 * after the attribute had been changed twice.
 *
 * Returns what the button will really dial against what the attribute says, or null when they agree
 * (or when there is nothing to compare). Reads Meta live: the answer has to be true at the moment
 * someone is about to send, not true as of the last sync.
 *
 * @return array{token:string,expected:string,actual:string,retry_at:?string}|null
 */
function wa_template_phone_drift(array $tpl, string $wabaId): ?array {
    global $conn;
    $token = '';
    foreach ((json_decode((string)($tpl['buttons'] ?? '[]'), true) ?: []) as $b) {
        if (($b['type'] ?? '') === 'phone' && strpbrk((string)($b['phone'] ?? ''), '[{') !== false) {
            $token = (string)$b['phone'];
            break;
        }
    }
    if ($token === '' || $wabaId === '') return null;

    $missing = [];
    $expected = wa_button_phone_e164(wa_button_phone_resolved($token, $missing));
    if ($missing || $expected === '') return null;

    $w = $conn->query("SELECT meta_template_id FROM wa_template_wabas
                        WHERE template_id = " . (int)$tpl['id'] . "
                          AND waba_id = '" . $conn->real_escape_string($wabaId) . "' LIMIT 1");
    $mid = trim((string)(($w ? $w->fetch_assoc() : null)['meta_template_id'] ?? ''));
    if ($mid === '') return null;

    $settings = wa_settings_row() ?: [];
    $accessToken = trim((string)($settings['meta_access_token'] ?? ''));
    if ($accessToken === '') return null;

    $res = wa_graph('GET', WA_GRAPH_BASE . WA_GRAPH_VERSION . '/' . rawurlencode($mid) . '?fields=components', $accessToken, []);
    if (empty($res['ok'])) return null;
    $actual = '';
    foreach (($res['data']['components'] ?? []) as $c) {
        if (($c['type'] ?? '') !== 'BUTTONS') continue;
        foreach (($c['buttons'] ?? []) as $bb) {
            if (($bb['type'] ?? '') === 'PHONE_NUMBER') { $actual = (string)($bb['phone_number'] ?? ''); break 2; }
        }
    }
    if ($actual === '' || wa_button_phone_e164($actual) === $expected) return null;

    wa_resubmit_ensure_schema();
    $q = $conn->query("SELECT not_before FROM wa_template_resubmits WHERE template_id = " . (int)$tpl['id'] . " LIMIT 1");
    $retry = $q ? ($q->fetch_assoc()['not_before'] ?? null) : null;

    return ['token' => $token, 'expected' => $expected, 'actual' => $actual, 'retry_at' => $retry ?: null];
}


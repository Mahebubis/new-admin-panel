<?php
/*
 * /api/whatsapp/wa_templates.php — WhatsApp message templates.
 *
 * A row here is OUR record of a template that exists (or is being submitted) on the WhatsApp
 * Business Account. WhatsApp itself will only deliver a template Meta has approved, so `name`
 * + `language` must match the approved template exactly; everything else on the row (body
 * copy, buttons, variable labels, samples) is what lets the campaign wizard render a true
 * preview and offer variable mapping without calling the provider on every keystroke.
 *
 * action=list     &page &per_page &search &status(active|archived) &category
 * action=get       &id
 * action=save     [&id] &name &display_name &category &language &header_* &body_text
 *                  &footer_text &buttons(json) &variable_labels(json) &sample_values(json) &approval_status
 * action=archive | restore | delete   &id
 * action=sync                                → pull the approved-template list from the provider
 */
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../middleware/auth.php';
require_once __DIR__ . '/lib/config.php';
require_once __DIR__ . '/lib/schema.php';
require_once __DIR__ . '/lib/WaHelpers.php';
require_once __DIR__ . '/lib/WaLinks.php';
require_once __DIR__ . '/lib/WaTemplateWabas.php';
require_once __DIR__ . '/lib/WaMetaComponents.php';

whatsapp_ensure_schema();
// Every action on this endpoint reads or writes the multi-WABA columns, and one of them
// (disabled_reason) needs widening on installs that predate it. Running the migration here
// rather than leaving it to whichever helper happens to be reached first means it lands on
// the first request after deploy, whatever the caller asked for.
wa_template_wabas_ensure_schema();

$jwt = require_jwt();
require_permission('netcore_behaviour', $jwt);

function jin($k, $d = null) { $v = $_REQUEST[$k] ?? null; return ($v === null || $v === '') ? $d : $v; }

/** Decodes a JSON parameter into an array, tolerating an empty/garbage value. */
function jarr($k): array {
    $v = $_REQUEST[$k] ?? null;
    if ($v === null || $v === '') return [];
    $d = json_decode((string)$v, true);
    return is_array($d) ? $d : [];
}

$action = jin('action', '');

if ($action === 'list') {
    $page     = max(1, (int)jin('page', 1));
    $perPage  = max(1, min(200, (int)jin('per_page', 24)));
    $search   = trim((string)jin('search', ''));
    $status   = jin('status', 'active');
    $category = jin('category', '');
    $offset   = ($page - 1) * $perPage;

    /*
     * ── Check for category drift on every visit ──────────────────────────────────
     * Meta re-files templates on its own and tells nobody: a template approved as UTILITY
     * can be MARKETING a month later, at a different price, subject to marketing opt-in and
     * to a frequency cap that drops it silently. Nothing about that shows up until someone
     * reads a bill or wonders why a journey's delivery rate halved.
     *
     * So the check happens here, where a person is already looking at the list. It is two
     * passes: a free one that re-applies the rule to data already stored, and a capped,
     * oldest-first pass that asks Meta for a dozen templates' current categories. Anything
     * that has drifted is disabled on the spot — it stops being selectable in campaigns and
     * journeys — and the row says why. See lib/WaTemplateWabas.php.
     *
     * All of it is advisory, so all of it is wrapped: the drift check is a bonus this endpoint
     * performs on the way past, and it must never be the reason the list itself fails to load.
     * It was — a reason string one character too long for its column threw out of here and the
     * template picker went blank on every WhatsApp campaign.
     */
    $sweep = ['checked' => 0, 'refreshed' => 0, 'disabled' => 0, 'errors' => []];
    try {
        wa_template_wabas_backfill();
        $sweep = wa_template_category_sweep(jin('skip_sync', '') === '');
    } catch (Throwable $e) {
        $sweep['errors'][] = $e->getMessage();
    }

    $where = ["status='" . $conn->real_escape_string($status) . "'"];
    if ($search !== '') {
        $s = $conn->real_escape_string($search);
        $where[] = "(name LIKE '%$s%' OR display_name LIKE '%$s%' OR body_text LIKE '%$s%')";
    }
    if ($category !== '') $where[] = "category='" . $conn->real_escape_string($category) . "'";
    // With 130+ templates on an account, "show me only the ones I can actually send" is the
    // filter that matters most — an unapproved template is accepted by the API and then dropped.
    $approval = jin('approval', '');
    if ($approval === 'disabled') $where[] = 'auto_disabled = 1';
    elseif ($approval !== '')     $where[] = "approval_status='" . $conn->real_escape_string($approval) . "'";
    $whereSql = 'WHERE ' . implode(' AND ', $where);

    $tr = $conn->query("SELECT COUNT(*) AS c FROM wa_templates $whereSql");
    $total = $tr ? (int)$tr->fetch_assoc()['c'] : 0;

    $r = $conn->query("SELECT * FROM wa_templates $whereSql ORDER BY id DESC LIMIT $perPage OFFSET $offset");
    $rows = [];
    while ($r && $row = $r->fetch_assoc()) {
        $row['buttons']         = json_decode($row['buttons'] ?? '[]', true) ?: [];
        $row['variable_labels'] = json_decode($row['variable_labels'] ?? '{}', true) ?: [];
        $row['sample_values']   = json_decode($row['sample_values'] ?? '{}', true) ?: [];
        $row['var_defaults']    = json_decode($row['var_defaults'] ?? '{}', true) ?: [];
        // Placeholder counts are derived, never stored — a body edit can't leave them stale.
        $row['body_variable_count']   = wa_placeholder_count((string)$row['body_text']);
        $row['header_variable_count'] = $row['header_type'] === 'text' ? wa_placeholder_count((string)$row['header_text']) : 0;
        // Per-WABA approval travels with the row: on a two-account setup, one status is not
        // an answer, and the card has to be able to show both without a second request each.
        $row['wabas'] = wa_template_waba_rows((int)$row['id']);
        $rows[] = $row;
    }

    $counts = [];
    $cr = $conn->query("SELECT status, COUNT(*) AS c FROM wa_templates GROUP BY status");
    while ($cr && $row = $cr->fetch_assoc()) $counts[$row['status']] = (int)$row['c'];

    // Approval tallies for the filter chips — scoped to the active/archived tab in view, and to
    // the category filter, so the numbers always match what the chips would actually show.
    $aWhere = ["status='" . $conn->real_escape_string($status) . "'"];
    if ($category !== '') $aWhere[] = "category='" . $conn->real_escape_string($category) . "'";
    $approvalCounts = ['approved' => 0, 'pending' => 0, 'rejected' => 0, 'unknown' => 0, 'all' => 0, 'disabled' => 0];
    $ar = $conn->query("SELECT approval_status, COUNT(*) AS c FROM wa_templates WHERE "
        . implode(' AND ', $aWhere) . ' GROUP BY approval_status');
    while ($ar && $row = $ar->fetch_assoc()) {
        $approvalCounts[$row['approval_status']] = (int)$row['c'];
        $approvalCounts['all'] += (int)$row['c'];
    }
    $dr = $conn->query("SELECT COUNT(*) c FROM wa_templates WHERE " . implode(' AND ', $aWhere) . ' AND auto_disabled = 1');
    $approvalCounts['disabled'] = $dr ? (int)$dr->fetch_assoc()['c'] : 0;

    api_success(['templates' => $rows, 'total' => $total, 'page' => $page, 'per_page' => $perPage,
                 'pages' => $total > 0 ? (int)ceil($total / $perPage) : 1, 'counts' => $counts,
                 'approval_counts' => $approvalCounts,
                 'wabas' => wa_active_wabas(),
                 'category_sweep' => $sweep]);
}

if ($action === 'get') {
    $id = (int)jin('id', 0);
    $r = $conn->query("SELECT * FROM wa_templates WHERE id=$id LIMIT 1");
    $row = $r ? $r->fetch_assoc() : null;
    if (!$row) api_error('Not found', 404);
    $row['buttons']         = json_decode($row['buttons'] ?? '[]', true) ?: [];
    $row['variable_labels'] = json_decode($row['variable_labels'] ?? '{}', true) ?: [];
    $row['sample_values']   = json_decode($row['sample_values'] ?? '{}', true) ?: [];
    $row['var_defaults']    = json_decode($row['var_defaults'] ?? '{}', true) ?: [];
    $row['body_variable_count']   = wa_placeholder_count((string)$row['body_text']);
    $row['header_variable_count'] = $row['header_type'] === 'text' ? wa_placeholder_count((string)$row['header_text']) : 0;
    /* Per-WABA approval, so the editor can show one row per business account instead of
       a single status that can only ever be true for one of them. */
    $row['wabas'] = wa_template_waba_rows((int)$row['id']);
    api_success(['template' => $row, 'wabas' => wa_active_wabas()]);
}

if ($action === 'save') {
    $id   = (int)jin('id', 0);
    $name = trim((string)jin('name', ''));
    $body = (string)jin('body_text', '');

    if ($name === '') api_error('Template name is required');
    // Meta's own rule for template names — enforced here rather than discovered at submission,
    // since a name with spaces or capitals can never be approved.
    if (!preg_match('/^[a-z0-9_]+$/', $name)) {
        api_error('Template name may only contain lowercase letters, numbers and underscores (e.g. exam_reminder_1)');
    }
    if (trim($body) === '') api_error('Message body is required');
    if (mb_strlen($body) > 1024) api_error('Message body is limited to 1024 characters by WhatsApp');

    $footer = (string)jin('footer_text', '');
    if (mb_strlen($footer) > 60) api_error('Footer is limited to 60 characters by WhatsApp');

    $language   = trim((string)jin('language', 'en')) ?: 'en';
    $category   = jin('category', 'utility');
    if (!in_array($category, ['marketing', 'utility', 'authentication'], true)) $category = 'utility';
    $headerType = jin('header_type', 'none');
    if (!in_array($headerType, ['none', 'text', 'image', 'video', 'document'], true)) $headerType = 'none';
    $approval   = jin('approval_status', 'pending');
    if (!in_array($approval, ['approved', 'pending', 'rejected', 'unknown'], true)) $approval = 'pending';

    // Placeholders must be a complete 1..N run — WhatsApp rejects a body that uses {{1}} and
    // {{3}} but never {{2}}, and catching it here beats a rejection days later.
    foreach ([['body', $body], ['header', $headerType === 'text' ? (string)jin('header_text', '') : '']] as [$part, $text]) {
        if ($text === '') continue;
        preg_match_all('/\{\{\s*(\d+)\s*\}\}/', $text, $m);
        $used = array_values(array_unique(array_map('intval', $m[1] ?? [])));
        sort($used);
        $expected = range(1, count($used));
        if ($used && $used !== $expected) {
            api_error(ucfirst($part) . ' placeholders must be numbered consecutively from {{1}} — found {{' . implode('}}, {{', $used) . '}}');
        }
    }

    $buttons = jarr('buttons');
    // Kept as typed so a rejection can quote back what was actually entered.
    $GLOBALS['__wa_raw_buttons'] = $buttons;
    // Normalized so the send path can trust the shape without re-validating per recipient.
    // A Call button's number is normalised and checked HERE, before anything is submitted — see
    // wa_button_phone_e164().
    $buttons = array_values(array_map(function ($b) {
        $type = in_array(($b['type'] ?? ''), ['url', 'phone', 'quick_reply'], true) ? $b['type'] : 'quick_reply';
        return [
            'type'    => $type,
            'text'    => mb_substr(trim((string)($b['text'] ?? '')), 0, 25),
            'url'     => $type === 'url' ? trim((string)($b['url'] ?? '')) : '',
            'phone'   => $type === 'phone' ? wa_button_phone_e164((string)($b['phone'] ?? '')) : '',
            // A dynamic url button takes a per-recipient suffix appended to the base url.
            'dynamic' => $type === 'url' && !empty($b['dynamic']),
        ];
    }, $buttons));
    if (count($buttons) > 3) api_error('WhatsApp allows at most 3 buttons on a template');

    /*
      A Call button whose number could not be put in international form stops the save here.

      The alternative is what used to happen: the template is written to our database, submitted to
      every business account, and refused by all of them with Meta's own wording about
      components[2]['buttons'][1]['phone_number']. That names an array index, not a field anybody
      can see on screen, and it arrives three times. The number is checkable before any of that.
    */
    foreach ($buttons as $i => $b) {
        if (($b['type'] ?? '') !== 'phone') continue;
        if (($b['phone'] ?? '') !== '') continue;
        $typed = trim((string)(($GLOBALS['__wa_raw_buttons'][$i]['phone'] ?? '')));
        api_error('The Call button' . ($b['text'] !== '' ? ' "' . $b['text'] . '"' : '')
            . ' needs a phone number in international form'
            . ($typed !== '' ? ' — "' . $typed . '" is not one' : '')
            . '. Write it with the country code and nothing else, like +919876543210.');
    }

    $cols = [
        'name'             => $name,
        'display_name'     => (string)jin('display_name', $name),
        'category'         => $category,
        'language'         => $language,
        'header_type'      => $headerType,
        'header_text'      => $headerType === 'text' ? (string)jin('header_text', '') : '',
        'header_media_url' => in_array($headerType, ['image', 'video', 'document'], true) ? (string)jin('header_media_url', '') : '',
        'body_text'        => $body,
        'footer_text'      => $footer,
        'buttons'          => json_encode($buttons),
        // Where a tracked button actually sends people. Set once here rather than per campaign:
        // the button URL is part of what Meta approved, so its real destination belongs to the
        // template and is the same for every campaign that uses it.
        'click_target_url' => trim((string)jin('click_target_url', '')),
        'variable_labels'  => json_encode(jarr('variable_labels')),
        'sample_values'    => json_encode(jarr('sample_values')),
        // Which attribute fills each {{n}} — see the note on the column in lib/schema.php.
        'var_defaults'     => json_encode(jarr('var_defaults')),
        'approval_status'  => $approval,
    ];
    $set = [];
    foreach ($cols as $c => $v) $set[] = "`$c`='" . $conn->real_escape_string((string)$v) . "'";

    if ($id > 0) {
        $conn->query("UPDATE wa_templates SET " . implode(', ', $set) . " WHERE id=$id");
    } else {
        // uq_name_lang: the same approved template can't be registered twice for one language.
        $dup = $conn->query("SELECT id FROM wa_templates WHERE name='" . $conn->real_escape_string($name) . "'
                              AND language='" . $conn->real_escape_string($language) . "' LIMIT 1");
        if ($dup && $dup->num_rows > 0) api_error("A template named \"$name\" already exists for language \"$language\"");
        $set[] = 'created_by=' . (int)($jwt['user_id'] ?? 0);
        $conn->query("INSERT INTO wa_templates SET " . implode(', ', $set));
        $id = $conn->insert_id;
    }

    /*
     * Bake the tracked link in, AFTER the row exists — a brand-new template has no id until the
     * INSERT above returns one, and the link id is derived from it.
     *
     * The editor sends the destination plain, the way a non-technical person would type it:
     *
     *     https://dashboard.internshipstudio.com/login
     *
     * and what is stored — and therefore what Meta is asked to approve — is
     *
     *     https://dashboard.internshipstudio.com/login/23
     *
     * Rewritten in the body, the header and every URL button, so it does not matter which of
     * those the link was typed into. wa_link_rewrite() is idempotent, so saving repeatedly does
     * not stack ids, and it also recognises the "?{{1}}" and "?XX_WA_ATTR_XX" endings the earlier
     * variable-based scheme produced — which means an old template migrates by being re-saved.
     */
    $target = trim((string)$cols['click_target_url']);
    $linkId = 0;
    $tracked = '';
    if ($target !== '') {
        $linkId = wa_link_ensure($id, $target);
        if ($linkId > 0) {
            $tracked = wa_tracked_link($target, $linkId);

            $newBody   = wa_link_rewrite($body, $target, $linkId);
            $newHeader = wa_link_rewrite((string)$cols['header_text'], $target, $linkId);
            $newButtons = array_map(function ($b) use ($target, $linkId) {
                if (($b['type'] ?? '') === 'url') {
                    /*
                     * A URL button left blank means "send them to the destination above".
                     *
                     * That is by far the commonest template shape — a plain message and one
                     * button — and asking for the same URL twice on one screen is asking for one
                     * of the two to be mistyped. Only the blank case is filled; a button pointing
                     * somewhere else is left exactly as written.
                     */
                    if (trim((string)($b['url'] ?? '')) === '') $b['url'] = $target;

                    $b['url'] = wa_link_rewrite((string)$b['url'], $target, $linkId);
                    // The id carries the campaign now, so the button no longer needs a
                    // per-recipient variable — and it is precisely that variable Meta kept
                    // refusing. Clearing the flag stops the send path appending a {{1}} value to
                    // a URL that has no {{1}} left in it.
                    $b['dynamic'] = false;
                }
                return $b;
            }, $buttons);

            $conn->query("UPDATE wa_templates
                             SET body_text   = '" . $conn->real_escape_string($newBody) . "',
                                 header_text = '" . $conn->real_escape_string($newHeader) . "',
                                 buttons     = '" . $conn->real_escape_string(json_encode(array_values($newButtons))) . "'
                           WHERE id = $id");
        }
    }

    api_success(['id' => $id, 'link_id' => $linkId, 'tracked_url' => $tracked]);
}

if ($action === 'archive' || $action === 'restore') {
    $id = (int)jin('id', 0);
    $status = $action === 'archive' ? 'archived' : 'active';
    $conn->query("UPDATE wa_templates SET status='$status' WHERE id=$id");
    api_success([]);
}

/*
 * Copy a template so a near-identical one does not have to be retyped.
 *
 * Most of this library is one message written several times over: the same copy for three business
 * numbers, or last month's wording with two words changed. Retyping it is slow and it is how a
 * variable ends up numbered differently in one copy than another.
 *
 * WHAT DELIBERATELY DOES NOT COME ACROSS:
 *   meta_template_id   — belongs to the submission that was reviewed, not to the words.
 *   approval_status    — the copy has not been reviewed. Starting it at "approved" would offer it
 *                        for sending, and every send would fail at Meta.
 *   auto_disabled      — a re-classification applies to the template Meta filed, not to this one.
 *
 * The name gets a suffix because Meta's names are unique per account and lowercase with
 * underscores; two templates called the same thing cannot both be submitted.
 */
if ($action === 'duplicate') {
    $id = (int)jin('id', 0);
    if (!$id) api_error('id required');

    $r = $conn->query("SELECT * FROM wa_templates WHERE id=$id LIMIT 1");
    $src = $r ? $r->fetch_assoc() : null;
    if (!$src) api_error('Template not found', 404);

    /* A name Meta will accept, and one that is not already taken. */
    $base = preg_replace('~[^a-z0-9_]+~', '_', strtolower((string)$src['name']));
    $base = trim(preg_replace('~_copy(_d+)?$~', '', $base), '_');
    if ($base === '') $base = 'template';
    $name = '';
    for ($i = 1; $i <= 50; $i++) {
        $try = $i === 1 ? $base . '_copy' : $base . '_copy_' . $i;
        $try = substr($try, 0, 512);
        $e = $conn->real_escape_string($try);
        $chk = $conn->query("SELECT 1 FROM wa_templates WHERE name='$e' LIMIT 1");
        if (!$chk || $chk->num_rows === 0) { $name = $try; break; }
    }
    if ($name === '') api_error('Could not find a free name for the copy — rename the original first.');

    /* Every content column, and nothing that belongs to the original's review. */
    $copy = [
        'name'             => $name,
        'display_name'     => trim((string)($src['display_name'] ?? '')) !== ''
                              ? mb_substr($src['display_name'] . ' (copy)', 0, 255) : $name,
        'category'         => $src['category'],
        'meta_category'    => null,
        'language'         => $src['language'],
        'header_type'      => $src['header_type'],
        'header_text'      => $src['header_text'],
        'header_media_url' => $src['header_media_url'],
        'body_text'        => $src['body_text'],
        'footer_text'      => $src['footer_text'],
        'buttons'          => $src['buttons'],
        'click_target_url' => $src['click_target_url'],
        'variable_labels'  => $src['variable_labels'],
        'sample_values'    => $src['sample_values'],
        'var_defaults'     => $src['var_defaults'],
        // Not 'pending': that means Meta is reviewing it, and nothing has been sent to Meta yet.
        'approval_status'  => 'unknown',
        'status'           => 'active',
        'created_by'       => (int)($jwt['user_id'] ?? $jwt['id'] ?? 0) ?: null,
    ];
    $cols = []; $vals = [];
    foreach ($copy as $c => $v) {
        $cols[] = "`$c`";
        $vals[] = $v === null ? 'NULL' : "'" . $conn->real_escape_string((string)$v) . "'";
    }
    $conn->query("INSERT INTO wa_templates (" . implode(',', $cols) . ", created_at, updated_at)
                  VALUES (" . implode(',', $vals) . ", NOW(), NOW())");
    $newId = (int)$conn->insert_id;
    if (!$newId) api_error('The copy could not be created.');

    api_success(['id' => $newId, 'name' => $name]);
}

if ($action === 'delete') {
    $id = (int)jin('id', 0);
    if (!$id) api_error('id required');

    $r = $conn->query("SELECT name, language, meta_template_id FROM wa_templates WHERE id=$id LIMIT 1");
    $tpl = $r ? $r->fetch_assoc() : null;

    /*
     * Delete on META first, then locally.
     *
     * A template that exists on the WABA but not here is invisible and un-fixable from this
     * panel: its name is taken, so re-creating it fails, and there is no row left to press
     * anything on. Deleting locally first would strand exactly that, which is the state a
     * mis-submitted template (wrong button URL, say) leaves you in.
     *
     * Meta deletes BY NAME and removes every language variant, which is why the name is used
     * rather than the template id.
     */
    $metaResult = null;
    if ($tpl && trim((string)$tpl['meta_template_id']) !== '' && (int)jin('delete_on_meta', 1) === 1) {
        // Same resolution as submit_to_meta and sync: the WABA comes from the sending number,
        // which is the only place it is stored.
        $token  = trim((string)((wa_settings_row() ?: [])['meta_access_token'] ?? ''));
        $sender = wa_sender_by_id((int)jin('sender_id', 0)) ?: wa_default_sender();
        $wabaId = trim((string)($sender['waba_id'] ?? ''));
        if ($token !== '' && $wabaId !== '') {
            $res = wa_graph_call('DELETE', WA_GRAPH_BASE . WA_GRAPH_VERSION . '/' . rawurlencode($wabaId)
                . '/message_templates?name=' . rawurlencode((string)$tpl['name']), $token);
            $metaResult = $res['ok'] ? 'deleted on Meta' : ('Meta said: ' . $res['error']);
            /*
             * A Meta failure does NOT stop the local delete. The usual causes are "already gone"
             * and "still in use", and in both cases leaving an unusable row here helps nobody —
             * the outcome is reported instead so it isn't silently swallowed.
             */
        }
    }

    // Campaigns snapshot a template's content at save time (see wa_campaigns.php's save), so
    // deleting one never changes what an already-scheduled campaign will send.
    $conn->query("DELETE FROM wa_templates WHERE id=$id");
    api_success(['meta' => $metaResult], $metaResult ?: 'Deleted');
}

/*
 * Pulls the template list straight from Meta.
 *
 * Netcore's messaging API has NO template endpoint — its entire documented surface is consent,
 * send-message, template-MESSAGE (sending one), media, webhooks and reports, and every
 * /api/v2/template* path answers 404. Templates aren't Netcore's data anyway: they live on the
 * WhatsApp Business Account and Meta is what approves them, so the authoritative list is
 *
 *     GET https://graph.facebook.com/{version}/{waba_id}/message_templates
 *
 * which returns name, language, category, status and the full components array — exactly what
 * wa_upsert_templates() already knows how to read. Netcore's own "Integrate with third-party
 * BSPs" guide documents the same Meta System User token for this, with the
 * whatsapp_business_management scope.
 */
if ($action === 'sync') {
    $settings = wa_settings_row() ?: [];
    $token = trim((string)($settings['meta_access_token'] ?? ''));
    if ($token === '') {
        api_error('Add a Meta access token in Settings → Template sync. Netcore has no template API, so the list is read directly from your WhatsApp Business Account.');
    }

    /*
     * ── Every business account, not just the default sender's ────────────────────
     * A template library that reads only one WABA is wrong the moment there are two: the
     * second account's approvals never arrive, and its templates either never appear or
     * appear with the first account's verdict stamped on them. Each account is read on its
     * own and recorded on its own row (see lib/WaTemplateWabas.php).
     *
     * sender_id / waba_id still narrow it to one account, which is what the per-account
     * "Re-sync this account" button uses — and what a very large library wants when only
     * one account has changed.
     */
    $onlyWaba = trim((string)jin('waba_id', ''));
    if ($onlyWaba === '') {
        $senderId = (int)jin('sender_id', 0);
        if ($senderId) {
            $s = wa_sender_by_id($senderId);
            $onlyWaba = trim((string)($s['waba_id'] ?? ''));
        }
    }

    $targets = wa_active_wabas();
    if ($onlyWaba !== '') {
        $targets = array_values(array_filter($targets, fn($w) => $w['waba_id'] === $onlyWaba));
        // A WABA that is no longer an active sender can still be re-synced explicitly — the
        // templates on it are real, and refusing would make an account impossible to inspect
        // the moment its number was deactivated.
        if (!$targets) $targets = [['waba_id' => $onlyWaba, 'waba_name' => '', 'numbers' => '']];
    }
    if (!$targets) api_error('No WABA ID on any sending number — add one in Settings → Sending numbers.');

    $version = trim((string)jin('graph_version', '')) ?: WA_GRAPH_VERSION;
    $totals = ['imported' => 0, 'updated' => 0, 'skipped' => 0, 'skipped_names' => []];
    $perWaba = [];
    $anyFound = false;
    $lastError = null;

    foreach ($targets as $target) {
        $wabaId = $target['waba_id'];
        $url = WA_GRAPH_BASE . rawurlencode($version) . '/' . rawurlencode($wabaId) . '/message_templates'
             . '?limit=200&fields=' . rawurlencode('name,status,category,language,components');

        $found = [];
        $pages = 0;
        $err = null;

        // Meta paginates with a cursor; `paging.next` is a fully-formed URL (token included). The
        // page cap is a guard against a malformed next-link looping forever — 20 × 200 is far more
        // than the 250-templates-per-WABA ceiling Meta enforces.
        while ($url !== null && $pages < 20) {
            $ch = curl_init($url);
            curl_setopt_array($ch, [
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_HTTPHEADER     => ['Authorization: Bearer ' . $token],
                CURLOPT_TIMEOUT        => 25,
            ]);
            $body   = curl_exec($ch);
            $status = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
            $curlErr = curl_error($ch);
            curl_close($ch);
            $pages++;

            if ($curlErr !== '') { $err = 'Could not reach Meta: ' . $curlErr; break; }
            $decoded = json_decode((string)$body, true);

            if ($status < 200 || $status >= 300 || !is_array($decoded)) {
                // Meta's errors are genuinely descriptive (expired token, missing scope, wrong WABA),
                // so they're surfaced verbatim instead of being flattened into "sync failed".
                $msg  = $decoded['error']['message'] ?? (is_string($body) ? mb_substr($body, 0, 300) : "HTTP $status");
                $type = $decoded['error']['type'] ?? '';
                $code = $decoded['error']['code'] ?? $status;
                $err = "Meta refused the request (code $code" . ($type ? ", $type" : '') . "): $msg";
                break;
            }

            foreach ((array)($decoded['data'] ?? []) as $tpl) {
                if (is_array($tpl) && isset($tpl['name'])) $found[] = $tpl;
            }

            $next = $decoded['paging']['next'] ?? null;
            $url = (is_string($next) && strpos($next, 'https://graph.facebook.com/') === 0) ? $next : null;
        }

        if ($err !== null) {
            /*
             * One account failing does not abort the others. On a multi-account setup the usual
             * cause is a token that has been granted on one business and not the other, and
             * aborting would hide the accounts that DID sync behind the one that did not.
             */
            $lastError = $err;
            $perWaba[] = ['waba_id' => $wabaId, 'waba_name' => $target['waba_name'], 'ok' => false, 'error' => $err];
            continue;
        }

        $res = wa_upsert_templates($found, (int)($jwt['user_id'] ?? 0), $wabaId, (string)$target['waba_name']);
        $anyFound = $anyFound || count($found) > 0;

        foreach (['imported', 'updated', 'skipped'] as $k) $totals[$k] += (int)$res[$k];
        $totals['skipped_names'] = array_slice(array_merge($totals['skipped_names'], $res['skipped_names']), 0, 20);

        $perWaba[] = ['waba_id' => $wabaId, 'waba_name' => $target['waba_name'], 'ok' => true,
                      'found' => count($found), 'pages' => $pages] + $res;
    }

    if (!$anyFound && $lastError !== null) api_error($lastError);
    if (!$anyFound) {
        api_error('Meta returned no templates for ' . (count($targets) === 1 ? "WABA {$targets[0]['waba_id']}" : 'any of your business accounts')
            . '. Check that the token belongs to the business that owns them.');
    }

    // A drift check straight after a sync, so freshly-imported categories are acted on now
    // rather than on whatever page load happens to come next. Guarded for the same reason as
    // the one on the list: the sync has already succeeded and written rows by this point, and
    // a failure in the follow-up check must not report that work as an error.
    try {
        $sweep = wa_template_category_sweep(false);
    } catch (Throwable $e) {
        $sweep = ['checked' => 0, 'refreshed' => 0, 'disabled' => 0, 'errors' => [$e->getMessage()]];
    }

    api_success($totals + [
        'accounts'       => $perWaba,
        'found'          => array_sum(array_column(array_filter($perWaba, fn($x) => $x['ok']), 'found')),
        'category_sweep' => $sweep,
        'wabas'          => wa_active_wabas(),
    ]);
}

/*
 * Import templates from whatever the Netcore panel can hand you, because its messaging API
 * (waapi.pepipost.com) has no template endpoint at all — every path under /api/v2/template*
 * answers 404, since template management lives on the cpaas.netcorecloud.com side.
 *
 * Accepts either:
 *   - JSON  — the response body of the panel's own template-list XHR, copied from DevTools.
 *             This also reveals the real endpoint, so automatic sync can be wired up later.
 *   - CSV / TSV — the file behind the download icon on Template management.
 *
 * Columns/keys are matched loosely by name, since neither export format is documented here.
 */
if ($action === 'import') {
    $payload = (string)jin('payload', '');
    if ($payload === '' && !empty($_FILES['file']) && $_FILES['file']['error'] === UPLOAD_ERR_OK) {
        if ($_FILES['file']['size'] > 5 * 1024 * 1024) api_error('File too large (max 5MB)');
        $payload = (string)file_get_contents($_FILES['file']['tmp_name']);
    }
    $payload = trim($payload);
    if ($payload === '') api_error('Paste the exported template list, or choose a file');

    // Excel and some panel exports write a UTF-8 BOM, which would otherwise become part of the
    // first column's header name and break every match against it.
    $payload = preg_replace('/^\xEF\xBB\xBF/', '', $payload);

    $found = [];

    $decoded = json_decode($payload, true);
    if (is_array($decoded)) {
        $walk = function ($node) use (&$walk, &$found) {
            if (!is_array($node)) return;
            $nameVal = $node['name'] ?? ($node['template_name'] ?? null);
            if (is_string($nameVal) && preg_match('/^[a-z0-9_]+$/', $nameVal)
                && (isset($node['components']) || isset($node['body']) || isset($node['template_body'])
                    || isset($node['language']) || isset($node['category']))) {
                $found[] = $node;
                return;
            }
            foreach ($node as $child) if (is_array($child)) $walk($child);
        };
        $walk($decoded);
        if (!$found) api_error('That JSON parsed, but nothing template-shaped was found in it. Make sure you copied the full response body.');
    } else {
        // ── CSV / TSV ──────────────────────────────────────────────────────────────────
        // Read through a stream rather than splitting on newlines: a template body legitimately
        // contains line breaks inside a quoted field, which a naive split would tear apart.
        $firstLine = strtok($payload, "\n");
        $delimiter = substr_count($firstLine, "\t") > substr_count($firstLine, ',') ? "\t" : ',';

        $fh = fopen('php://memory', 'r+');
        fwrite($fh, $payload);
        rewind($fh);
        $rows = [];
        while (($r = fgetcsv($fh, 0, $delimiter)) !== false) {
            if ($r === [null] || $r === false) continue; // blank line
            $rows[] = $r;
        }
        fclose($fh);
        if (count($rows) < 2) api_error('That does not look like a template export — no header row plus data rows were found.');

        $header = array_shift($rows);
        /** Exact header match first, then a contains-match, so "Template Name" and "name" both work. */
        $col = function (array $needles) use ($header) {
            foreach ([true, false] as $exact) {
                foreach ($header as $i => $h) {
                    $h = strtolower(trim((string)$h));
                    foreach ($needles as $n) {
                        if ($exact ? $h === $n : strpos($h, $n) !== false) return $i;
                    }
                }
            }
            return null;
        };
        $iName   = $col(['template name', 'name', 'template']);
        $iLang   = $col(['language', 'lang']);
        $iCat    = $col(['category', 'type']);
        $iStatus = $col(['status']);
        $iBody   = $col(['body', 'message', 'content']);
        $iHeader = $col(['header']);
        $iFooter = $col(['footer']);
        if ($iName === null) api_error('No "Template name" column found in that file. Header row was: ' . implode(' | ', array_map('strval', $header)));

        $get = fn(array $r, $i) => ($i === null || !isset($r[$i])) ? '' : trim((string)$r[$i]);
        foreach ($rows as $r) {
            $name = $get($r, $iName);
            if ($name === '') continue;
            $found[] = [
                'name'     => $name,
                'language' => $get($r, $iLang) ?: 'en',
                'category' => $get($r, $iCat),
                'status'   => $get($r, $iStatus),
                'body'     => $get($r, $iBody),
                'header'   => $get($r, $iHeader),
                'footer'   => $get($r, $iFooter),
            ];
        }
        if (!$found) api_error('No template rows were found in that file.');
    }

    $res = wa_upsert_templates($found, (int)($jwt['user_id'] ?? 0));
    api_success($res + ['found' => count($found)]);
}

/**
 * Writes a batch of loosely-shaped template records into wa_templates, keyed on (name,
 * language). Shared by the API sync and the manual import so both land identical rows.
 *
 * Rows without message text are counted as skipped rather than written: body_text is what the
 * placeholder count is derived from, and a template imported with an empty body would look like
 * it has no variables — which would then send a real template with its parameters missing.
 *
 * @return array{imported:int, updated:int, skipped:int, skipped_names:string[]}
 */
function wa_upsert_templates(array $found, int $userId, string $wabaId = '', string $wabaName = ''): array {
    global $conn;
    $imported = 0; $updated = 0; $skipped = 0; $skippedNames = [];

    foreach ($found as $t) {
        // Field names differ between Meta's shape, Netcore's own, and a CSV export, so each is
        // read through a short list of spellings rather than one hard-coded key.
        $name = (string)($t['name'] ?? ($t['template_name'] ?? ''));
        if ($name === '' || !preg_match('/^[a-z0-9_]+$/', $name)) { $skipped++; continue; }

        $lang = (string)($t['language']['code'] ?? ($t['language'] ?? ($t['language_code'] ?? ($t['lang'] ?? 'en'))));
        // A CSV often writes "English" rather than the code Meta expects.
        $langMap = ['english' => 'en', 'hindi' => 'hi', 'marathi' => 'mr', 'gujarati' => 'gu',
                    'tamil' => 'ta', 'telugu' => 'te', 'bengali' => 'bn', 'kannada' => 'kn',
                    'malayalam' => 'ml', 'punjabi' => 'pa'];
        $lang = $langMap[strtolower(trim($lang))] ?? $lang;
        if ($lang === '') $lang = 'en';

        /*
         * ── What the source ACTUALLY said, kept apart from what we fall back to ──────
         *
         * $catRaw is null when the record carried no category at all — which is the normal
         * case for a CSV/paste import, and happens for a Meta record whenever the field was
         * not requested or came back empty.
         *
         * Keeping the two apart matters because they feed different columns. `category` is
         * our own intent and may reasonably default to utility on a brand-new record.
         * `meta_category` is EVIDENCE — "Meta told us this" — and a default written into it
         * is a lie the drift check will act on.
         *
         * That is exactly what went wrong: the default landed in meta_category, so every
         * MARKETING and AUTHENTICATION template on the account looked like it had been
         * re-filed as UTILITY the moment anybody pressed Sync or Paste import, and the drift
         * rule disabled all of them at once.
         */
        $catRaw = strtolower(trim((string)($t['category'] ?? ($t['template_category'] ?? ''))));
        if (!in_array($catRaw, ['marketing', 'utility', 'authentication'], true)) $catRaw = null;
        $cat = $catRaw ?? 'utility';

        $approval = strtolower(trim((string)($t['status'] ?? ($t['template_status'] ?? ($t['approval_status'] ?? 'unknown')))));
        $approval = in_array($approval, ['approved', 'pending', 'rejected'], true) ? $approval : 'unknown';

        // Meta's components array when present; the flat spellings otherwise.
        $bodyText = ''; $headerText = ''; $footerText = ''; $headerType = 'none'; $buttons = [];
        foreach ((array)($t['components'] ?? []) as $comp) {
            if (!is_array($comp)) continue;
            $ctype = strtolower((string)($comp['type'] ?? ''));
            if ($ctype === 'body')   $bodyText = (string)($comp['text'] ?? '');
            if ($ctype === 'footer') $footerText = (string)($comp['text'] ?? '');
            if ($ctype === 'header') {
                $fmt = strtolower((string)($comp['format'] ?? 'text'));
                $headerType = in_array($fmt, ['text', 'image', 'video', 'document'], true) ? $fmt : 'text';
                $headerText = (string)($comp['text'] ?? '');
            }
            if ($ctype === 'buttons') {
                foreach ((array)($comp['buttons'] ?? []) as $b) {
                    $bt = strtolower((string)($b['type'] ?? ''));
                    $buttons[] = [
                        'type'    => $bt === 'url' ? 'url' : ($bt === 'phone_number' ? 'phone' : 'quick_reply'),
                        'text'    => (string)($b['text'] ?? ''),
                        'url'     => (string)($b['url'] ?? ''),
                        'phone'   => (string)($b['phone_number'] ?? ''),
                        'dynamic' => isset($b['url']) && strpos((string)$b['url'], '{{') !== false,
                    ];
                }
            }
        }
        if ($bodyText === '')   $bodyText = (string)($t['body'] ?? ($t['template_body'] ?? ($t['content'] ?? '')));
        if ($headerText === '') $headerText = (string)($t['header'] ?? '');
        if ($footerText === '') $footerText = (string)($t['footer'] ?? '');
        if ($headerType === 'none' && trim($headerText) !== '') $headerType = 'text';

        if (trim($bodyText) === '') { $skipped++; $skippedNames[] = $name; continue; }

        $nameE = $conn->real_escape_string($name);
        $langE = $conn->real_escape_string($lang);
        $vals = [
            "name='$nameE'", "display_name='$nameE'",
            "language='$langE'",
            "header_type='" . $conn->real_escape_string($headerType) . "'",
            "header_text='" . $conn->real_escape_string($headerText) . "'",
            "body_text='"   . $conn->real_escape_string($bodyText) . "'",
            "footer_text='" . $conn->real_escape_string($footerText) . "'",
            "status='active'",
        ];
        /*
         * ── `category` is NOT overwritten on an existing template, and that is the point ──
         *
         * category means "what this template was built and submitted as". meta_category means
         * "what Meta files it as today". Drift is the difference between the two — so a sync
         * that copied Meta's answer into `category` would erase the very thing being detected,
         * every time anybody pressed Sync, and a template silently moved from UTILITY to
         * MARKETING would come back looking like it had always been marketing.
         *
         * A template being imported for the FIRST time has no local intent to preserve, so
         * Meta's category is the only answer there is and becomes both.
         */
        $catE = $conn->real_escape_string($cat);
        // meta_category is written ONLY from a category the source actually reported. A record
        // that carried none leaves the column exactly as it was, so "we have never been told"
        // stays distinguishable from "Meta says utility" — which is the difference between the
        // drift check staying quiet and disabling the whole library.
        $metaVals = $catRaw !== null
            ? array_merge($vals, ["meta_category='" . $conn->real_escape_string($catRaw) . "'"])
            : $vals;

        // Meta's own template id, when the record came from Meta — it's what lets a single
        // template's status be re-checked later without re-reading the whole account.
        $metaTplId = (!empty($t['id']) && is_string($t['id'])) ? (string)$t['id'] : '';
        if ($metaTplId !== '') {
            $metaVals[] = "meta_template_id='" . $conn->real_escape_string($metaTplId) . "'";
        }
        /*
         * approval_status on wa_templates is a ROLLUP across every account, recomputed below
         * by wa_template_recompute(). Writing this WABA's answer straight into it would mean
         * syncing account B overwrote account A's verdict — which is exactly the single-status
         * problem this whole change exists to remove. It is only written directly when there
         * is no per-WABA context at all (a CSV import, which belongs to no account).
         */
        if ($wabaId === '') {
            $metaVals[] = "approval_status='" . $conn->real_escape_string($approval) . "'";
        }

        // Buttons are only overwritten when the source actually carried some — a CSV export
        // usually has no button column, and blanking existing buttons would quietly break the
        // dynamic-URL mapping on a template that was imported properly earlier.
        $exists = $conn->query("SELECT id, buttons FROM wa_templates WHERE name='$nameE' AND language='$langE' LIMIT 1");
        $row = $exists ? $exists->fetch_assoc() : null;

        /*
         * A CALL BUTTON THAT POINTS AT AN ATTRIBUTE KEEPS POINTING AT IT.
         *
         * Meta never sees an attribute. A Call button cannot carry a variable, so the attribute is
         * resolved when the template is submitted and Meta stores the literal number. Reading the
         * template back from Meta therefore returns that number — and writing it over the local
         * copy replaced "[SUPPORT_NUMBER]" with "+918329597774".
         *
         * That silently severed the link this whole feature exists to keep. The next change to the
         * attribute found no template using it and resubmitted nothing, so Meta went on dialling
         * the old number. It also ran without anybody pressing Sync: the template list reads Meta on
         * every visit, so merely opening the page was enough to undo it. Template 168 and template
         * 169 were both reverted that way, each within minutes of being set.
         *
         * The local token is the source of truth and Meta's literal is only how it was rendered, so
         * a stored token on a phone button survives the sync. Everything else about the button —
         * its text, its type — still follows Meta.
         */
        if ($buttons && $row) {
            $local = json_decode((string)($row['buttons'] ?? ''), true);
            if (is_array($local)) {
                foreach ($buttons as $i => $b) {
                    if (($b['type'] ?? '') !== 'phone') continue;
                    $mine = $local[$i] ?? null;
                    if (!is_array($mine) || ($mine['type'] ?? '') !== 'phone') continue;
                    $stored = (string)($mine['phone'] ?? '');
                    if ($stored !== '' && strpbrk($stored, '[{') !== false) $buttons[$i]['phone'] = $stored;
                }
            }
        }
        if ($buttons) $metaVals[] = "buttons='" . $conn->real_escape_string(json_encode($buttons)) . "'";
        if ($row) {
            $templateId = (int)$row['id'];
            $conn->query("UPDATE wa_templates SET " . implode(', ', $metaVals) . " WHERE id=$templateId");
            $updated++;
        } else {
            $conn->query("INSERT INTO wa_templates SET " . implode(', ', $metaVals)
                . ", category='$catE', approval_status='" . $conn->real_escape_string($approval) . "'"
                . ', created_by=' . $userId);
            $templateId = (int)$conn->insert_id;
            $imported++;
        }

        /*
         * Record which account this answer came from. Without it a sync of account B would be
         * indistinguishable from a sync of account A, and the library would keep flip-flopping
         * between their two verdicts on every sync.
         */
        if ($wabaId !== '' && $templateId > 0) {
            $wabaFields = [
                'waba_name'        => $wabaName,
                'meta_template_id' => $metaTplId !== '' ? $metaTplId : null,
                'approval_status'  => $approval,
                'last_error'       => null,
                'last_synced_at'   => date('Y-m-d H:i:s'),
            ];
            // Only when the source actually reported one. Passing null here would WRITE null and
            // erase a category Meta had told us about on an earlier sync — turning known evidence
            // back into "we have never been told" every time somebody pastes a CSV.
            if ($catRaw !== null) $wabaFields['meta_category'] = $catRaw;

            wa_template_waba_upsert($templateId, $wabaId, $wabaFields);
            wa_template_recompute($templateId);
        }
    }

    return ['imported' => $imported, 'updated' => $updated, 'skipped' => $skipped,
            'skipped_names' => array_slice($skippedNames, 0, 20)];
}

/* ── Meta template management ───────────────────────────────────────────────────────────── */

/* wa_graph() moved to lib/WaMetaComponents.php — see the note there. */

/* wa_build_meta_components() moved to lib/WaMetaComponents.php — see the note there. */

/* WA_BUTTON_DEFAULT_CC moved to lib/WaMetaComponents.php, next to the function that uses it. */

/* wa_attribute_default() moved to lib/WaMetaComponents.php — see the note there. */

/* wa_button_phone_resolved() moved to lib/WaMetaComponents.php — see the note there. */

/* wa_button_phone_e164() moved to lib/WaMetaComponents.php — see the note there. */
/*
 * Submit one template to Meta — on EVERY business account this panel sends from.
 *
 * ── Why this is a loop and not a single call ─────────────────────────────────
 * A WhatsApp template is approved against ONE WABA. Add a second number under a second
 * business account and nothing carries over: the same copy has to be submitted again, and
 * is reviewed again, and can come back with a different verdict and even a different
 * category. Before this, the panel submitted to whichever sender happened to be the
 * default and recorded one status — so on a two-account setup the library was, at best,
 * right about one of them, and campaigns sent from the other number failed at Meta with a
 * template that this screen showed as approved.
 *
 * So: one submission per active WABA, each recorded on its own row, and one template in
 * the library. The template is written once and asked for everywhere, which is what
 * "single template management" has to mean when the approvals are not single.
 *
 * A per-WABA failure does NOT abort the rest. Accounts fail independently at Meta — a
 * business not verified, a name already used on that account, a category the reviewer
 * disagrees with — and stopping at the first one would leave the remaining accounts
 * untouched with nothing on screen to say which had gone through.
 */
if ($action === 'submit_to_meta') {
    /* The work lives in lib/WaTemplateSubmit.php so the attribute editor can do the same thing
       when a value changes — see the note at the top of that file. */
    require_once __DIR__ . '/lib/WaTemplateSubmit.php';
    $res = wa_submit_template((int)jin('id', 0), trim((string)jin('waba_id', '')));
    if (empty($res['ok'])) api_error((string)($res['error'] ?? 'Meta refused the submission.'));
    api_success($res['data'] ?? []);
}

/*
 * Re-check one template's approval and CATEGORY without re-syncing the whole account —
 * on every business account it lives on, since they answer independently.
 */
if ($action === 'refresh_status') {
    $id = (int)jin('id', 0);
    $r = $conn->query("SELECT * FROM wa_templates WHERE id=$id LIMIT 1");
    $t = $r ? $r->fetch_assoc() : null;
    if (!$t) api_error('Not found', 404);

    $settings = wa_settings_row() ?: [];
    $token = trim((string)($settings['meta_access_token'] ?? ''));
    if ($token === '') api_error('Add a Meta access token in Settings → Template sync first.');

    $rows = [];
    $q = $conn->query("SELECT * FROM wa_template_wabas
                        WHERE template_id = $id AND meta_template_id IS NOT NULL AND meta_template_id <> ''");
    while ($q && $row = $q->fetch_assoc()) $rows[] = $row;

    if (!$rows) {
        api_error('This template has no Meta id on any account yet — use "Sync from WhatsApp" to match it up, or submit it to Meta.');
    }

    $results = [];
    foreach ($rows as $row) {
        /*
         * rejected_reason is asked for alongside the status, because "rejected" on its own is the
         * least actionable word Meta can send: the template has to be changed, and nothing here says
         * what to change. category is asked for because it is the whole point of this call now —
         * a template silently moved from UTILITY to MARKETING reports APPROVED either way.
         */
        $url = WA_GRAPH_BASE . WA_GRAPH_VERSION . '/' . rawurlencode((string)$row['meta_template_id'])
             . '?fields=status,category,rejected_reason';
        $res = wa_graph('GET', $url, $token);

        if (!$res['ok']) {
            wa_template_waba_upsert($id, (string)$row['waba_id'], [
                'last_error' => mb_substr((string)$res['error'], 0, 490), 'last_synced_at' => date('Y-m-d H:i:s'),
            ]);
            $results[] = ['waba_id' => $row['waba_id'], 'ok' => false, 'error' => $res['error']];
            continue;
        }

        $status = strtolower((string)($res['data']['status'] ?? 'unknown'));
        $status = in_array($status, ['approved', 'pending', 'rejected'], true) ? $status : 'unknown';
        $cat    = strtolower(trim((string)($res['data']['category'] ?? '')));
        $reason = (string)($res['data']['rejected_reason'] ?? '');
        // NONE is what Meta returns for a template it hasn't rejected — not a reason worth showing.
        if (strtoupper($reason) === 'NONE') $reason = '';

        wa_template_waba_upsert($id, (string)$row['waba_id'], [
            'approval_status' => $status,
            'meta_category'   => $cat !== '' ? $cat : null,
            'rejected_reason' => $reason !== '' ? $reason : null,
            'last_error'      => null,
            'last_synced_at'  => date('Y-m-d H:i:s'),
        ]);

        $results[] = [
            'waba_id'          => $row['waba_id'],
            'ok'               => true,
            'approval_status'  => $status,
            'category'         => $cat,
            'rejected_reason'  => $reason,
            'rejected_message' => $reason === '' ? '' : wa_rejection_explanation($reason),
        ];
    }

    $conn->query("UPDATE wa_templates SET category_checked_at = NOW() WHERE id = $id");
    $summary = wa_template_recompute($id);

    api_success($summary + [
        'results' => $results,
        'wabas'   => wa_template_waba_rows($id),
        // Kept for the older editor, which reads these two keys directly.
        'rejected_reason'  => $results[0]['rejected_reason'] ?? '',
        'rejected_message' => $results[0]['rejected_message'] ?? '',
    ]);
}

/** Meta's rejection slugs, turned into a sentence. Its vocabulary, so it belongs next to the
 *  call that produced it rather than in the UI. */
function wa_rejection_explanation(string $reason): string {
    return [
        'INVALID_FORMAT'           => 'Formatting problem — usually a variable at the start or end of the body, non-consecutive {{n}}, or a missing sample value.',
        'ABUSIVE_CONTENT'          => 'Meta considered the wording abusive or misleading.',
        'SCAM'                     => 'Flagged as a possible scam. A whole URL inside a variable is a common trigger — put the domain in the fixed text and leave only the query string dynamic.',
        'PROMOTIONAL'              => 'Marketing wording in a Utility template. Either soften the copy or submit it as Marketing.',
        'TAG_CONTENT_MISMATCH'     => 'The content does not match the category chosen.',
        'INCORRECT_CATEGORY'       => 'Wrong category for this content — change the category and resubmit.',
        'INVALID_BUTTON_URL'       => 'A button URL was rejected. A fully dynamic link is the usual cause.',
        'INVALID_BUTTON_PHONE_NUMBER' => 'The button phone number was rejected.',
    ][strtoupper($reason)] ?? ('Meta reported: ' . $reason);
}

/*
 * Re-enable a template that was auto-disabled by category drift.
 *
 * Two honest ways out, and the caller says which:
 *
 *   accept   the template really is what Meta says it is. Its category here is changed to
 *            match, and it becomes selectable again — as a MARKETING template, which is the
 *            point: everything downstream now treats it correctly rather than continuing to
 *            believe it is a utility message.
 *   override the admin has looked and wants it usable as-is anyway. Allowed, because
 *            sometimes the reclassification is being appealed and the messages still have to
 *            go out — but recorded as a deliberate override rather than by clearing the flag
 *            and losing the fact that it ever drifted.
 *
 * Deliberately no "ignore quietly": the next sweep re-reads Meta, so an override that simply
 * cleared the flag would be undone within the hour and look like a bug.
 */
if ($action === 'resolve_category') {
    $id   = (int)jin('id', 0);
    $mode = (string)jin('mode', 'accept');

    $r = $conn->query("SELECT * FROM wa_templates WHERE id=$id LIMIT 1");
    $t = $r ? $r->fetch_assoc() : null;
    if (!$t) api_error('Not found', 404);

    $metaCat = strtolower(trim((string)($t['meta_category'] ?? '')));

    if ($mode === 'accept') {
        if ($metaCat === '' || !in_array($metaCat, ['marketing', 'utility', 'authentication'], true)) {
            api_error('Meta has not reported a category for this template yet, so there is nothing to accept.');
        }
        $conn->query("UPDATE wa_templates SET category = '" . $conn->real_escape_string($metaCat) . "' WHERE id = $id");
        $summary = wa_template_recompute($id);
        api_success($summary + ['category' => $metaCat, 'mode' => 'accept']);
    }

    if ($mode === 'override') {
        $note = 'Kept usable by an admin on ' . date('Y-m-d H:i') . ' even though Meta has it as '
              . strtoupper($metaCat ?: 'a different category') . '. It is being sent as '
              . strtoupper((string)$t['category']) . ' in this panel and as ' . strtoupper($metaCat ?: '?')
              . ' by Meta — the billing and opt-in rules that apply are Meta\'s.';
        $note = wa_clip($note, WA_DISABLED_REASON_MAX);
        $conn->query("UPDATE wa_templates SET auto_disabled = 0,
                             disabled_reason = '" . $conn->real_escape_string($note) . "'
                       WHERE id = $id");
        api_success(['auto_disabled' => 0, 'disabled_reason' => $note, 'mode' => 'override']);
    }

    api_error('Unknown mode — use accept or override.');
}

api_error('Invalid action');

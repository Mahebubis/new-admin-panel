<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/MergeTags.php';
require_once __DIR__ . '/TrackingRewriter.php';
require_once __DIR__ . '/TransportFactory.php';
require_once __DIR__ . '/ParallelSender.php';
// MUST be required here, at top level — not lazily inside materialize_campaign_recipients()
// like it used to be. AudienceResolver.php pulls in netcore/lib/segment_sql.php, whose
// $EVENT_SOURCE/$PAYLOAD_COLUMNS arrays are plain top-level variables. Loading that file for
// the first time from inside a function traps those arrays in that function's LOCAL scope, so
// every OTHER function reading them via `global $EVENT_SOURCE` (buildConditionSql, etc.) sees
// them as empty and silently treats every condition as unrecognized — buildSegmentSql() then
// returns null for every real segment, even though the segment's condition is completely valid.
// This was the actual cause of "audience resolves to 0 recipients" for every segment-based send.
require_once __DIR__ . '/AudienceResolver.php';
require_once __DIR__ . '/EmailVerifier.php';
require_once __DIR__ . '/Unsubscribe.php';
require_once __DIR__ . '/Alerts.php';
require_once __DIR__ . '/ProviderFailover.php';
require_once __DIR__ . '/../../lib/S3Uploader.php';
require_once __DIR__ . '/AttributeResolver.php';

/** Appends one timestamped line to worker.log — every tick, every campaign, every
 *  audience-resolve, so "did cron run" and "how many recipients did it find" are
 *  answerable just by opening the file, with no DB/SSH access needed. */
/**
 * Make sure the database is still there, and reconnect when it is not.
 *
 * Verifying an audience can take half a minute of pure waiting on someone else's API, and MySQL
 * closes a connection that has been idle past wait_timeout. The next query then dies with "MySQL
 * server has gone away" — which is how campaign #113 crashed AFTER its audience was resolved and
 * BEFORE its recipients were written, every minute for an hour, leaving it stuck on Running with
 * nothing queued. Cheap: one round trip, and only where a long pause has just happened.
 */
function campaign_db_alive(): void {
    global $conn;
    try {
        $r = @$conn->query('SELECT 1');
        if ($r) return;
    } catch (\Throwable $e) { /* fall through and reconnect */ }
    try {
        $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
        $conn->set_charset('utf8mb4');
        campaign_log('database connection was dropped during a long wait — reconnected');
    } catch (\Throwable $e) {
        campaign_log('database reconnect FAILED — ' . $e->getMessage());
    }
}

function campaign_log(string $msg): void {
    $line = '[' . date('Y-m-d H:i:s') . '] ' . $msg . "\n";
    @file_put_contents(WORKER_LOG_PATH, $line, FILE_APPEND | LOCK_EX);
}

/** Flip due `scheduled` campaigns to `running` so the batch loop below picks them up. */
function campaigns_activate_due_scheduled() {
    global $conn;
    // Uses PHP's own current time (Asia/Kolkata — see config/database.php's
    // date_default_timezone_set call) instead of MySQL's NOW(). MySQL's own clock/timezone
    // setting can be completely different from PHP's (commonly UTC on shared hosting), while
    // `scheduled_at` was stored via PHP's date() in campaigns.php's `schedule` action — comparing
    // NOW() against a value written in a different timezone silently delays (or could even
    // advance) exactly when a scheduled campaign fires, without ever raising an error.
    $now = $conn->real_escape_string(date('Y-m-d H:i:s'));
    $dueR = $conn->query("SELECT id, name, scheduled_at FROM email_campaigns WHERE status='scheduled' AND scheduled_at <= '$now'");
    $due = [];
    while ($dueR && $row = $dueR->fetch_assoc()) $due[] = "#{$row['id']} \"{$row['name']}\" (was due {$row['scheduled_at']})";

    // The worker now loops over many batches per run, so this would otherwise write the same
    // "none due" line dozens of times per invocation and bury the throughput numbers. Log the
    // first check of a run (which is what proves cron actually fired) and anything eventful.
    static $loggedOnce = false;
    if (!$loggedOnce || $due) {
        campaign_log('checking for due scheduled campaigns at server-time ' . $now . ' -> ' . (count($due) ? implode(', ', $due) : 'none due'));
        $loggedOnce = true;
    }

    $conn->query("UPDATE email_campaigns SET status='running', started_at=IFNULL(started_at, '$now')
                  WHERE status='scheduled' AND scheduled_at <= '$now'");
}

/**
 * Processes one chunk of pending recipients (per running campaign, or a single
 * $campaignId if given — used by the instant "Send Now" kick). Safe to call
 * repeatedly/concurrently-guarded by the caller's flock() (see campaign-send-worker.php).
 */
function campaigns_process_batch(int $limit = 50, ?int $campaignId = null): array {
    global $conn;
    campaigns_activate_due_scheduled();

    $campaignIds = [];
    $filter = $campaignId ? "id = " . (int)$campaignId : "status = 'running'";
    $res = $conn->query("SELECT id FROM email_campaigns WHERE $filter");
    while ($res && $row = $res->fetch_assoc()) $campaignIds[] = (int)$row['id'];

    // Same reasoning as the log in campaigns_activate_due_scheduled(): once per run, not once
    // per batch round. The per-batch throughput lines below are the useful signal after this.
    static $tickLogged = false;
    if (!$tickLogged) {
        campaign_log('tick: ' . count($campaignIds) . ' running campaign(s) to check'
            . ($campaignId ? " (instant kick for campaign #$campaignId)" : ' (cron sweep)'));
        $tickLogged = true;
    }

    $processed = 0; $sent = 0; $failed = 0;

    foreach ($campaignIds as $cid) {
        $campRes = $conn->query("SELECT * FROM email_campaigns WHERE id=$cid LIMIT 1");
        $campaign = $campRes ? $campRes->fetch_assoc() : null;
        if (!$campaign || !in_array($campaign['status'], ['running'], true)) continue;

        // First time the worker picks up this campaign: resolve the audience and insert
        // recipient rows now, in this background cron run (no web-request time limit here) —
        // NOT synchronously when the admin clicked Send Now/Schedule. This is what keeps that
        // click instant even for 20k-40k recipient audiences on modest hosting.
        if (empty($campaign['materialized_at'])) {
            campaign_log("campaign #$cid \"{$campaign['name']}\": resolving audience (type={$campaign['audience_type']}, segments={$campaign['segment_ids']}, lists=" . ($campaign['list_ids'] ?? 'NULL/column-missing') . ")...");
            /*
             * A crash in here used to take the whole worker run down with it — and since this runs
             * before materialized_at is stamped, the next tick started again from nothing and
             * crashed at the same place. Campaign #113 did that once a minute for an hour while
             * showing Running, and no other campaign got looked at either. Caught, reported, and
             * the run carries on with the campaigns behind it.
             */
            try {
                $n = materialize_campaign_recipients($cid);
            } catch (Throwable $e) {
                campaign_log("campaign #$cid: FAILED while resolving the audience — " . $e->getMessage());
                alert_notify("campaign-materialize-failed:$cid", 'Email campaign could not build its audience',
                    'Campaign #' . $cid . ' could not resolve its recipients, so nothing has been queued. It stays on '
                    . 'Running and the next worker run tries again.',
                    ['Campaign id' => (string)$cid, 'Error' => mb_substr($e->getMessage(), 0, 300)], 'critical');
                continue;
            }
            campaign_log("campaign #$cid \"{$campaign['name']}\": audience resolved -> $n recipient(s) found");
            if ($n === 0) {
                campaign_log("campaign #$cid \"{$campaign['name']}\": 0 recipients -> marking FAILED (never reached SendGrid)");
                $conn->query("UPDATE email_campaigns SET status='failed' WHERE id=$cid");
                // Nothing could even be queued — an empty audience, or a resolve that failed.
                alert_notify("campaign-nothing-queued:$cid",
                    'Email campaign could not queue any recipients',
                    "Campaign #$cid was started but resolving its audience produced nobody to send to, so it has "
                    . 'been marked failed without sending.',
                    ['Campaign id' => (string)$cid,
                     'What to check' => 'The segments or lists on the Audience step, and whether the blocklist has removed everyone.'],
                    'critical');
                continue;
            }
        }

        // Re-check the campaign's live status right before claiming anything — a Suspend
        // click can land in the moment between the fetch at the top of this loop and here
        // (this worker tick may have already spent real time waiting on slow/failing API
        // calls for an earlier batch). Without this, Suspend could silently fail to stop a
        // campaign that a tick was already mid-way through.
        $liveStatus = $conn->query("SELECT status FROM email_campaigns WHERE id=$cid LIMIT 1");
        $liveRow = $liveStatus ? $liveStatus->fetch_assoc() : null;
        if (!$liveRow || $liveRow['status'] !== 'running') continue;

        /*
         * CLAIM THE CHUNK UNDER A TOKEN THAT ONLY THIS RUN KNOWS.
         *
         * This used to mark rows 'processing' and then SELECT any 'processing' rows, on the
         * stated grounds that flock() in campaign-send-worker.php guarantees a single worker.
         * It does not. flock takes a lock on a file in the local temp directory, and this worker
         * runs on TWO machines: a cron every minute on the monitoring box, and an HTTP kick to
         * cit3 from trigger_worker_async() the moment Send Now is pressed. Two machines, two
         * temp directories, two locks that know nothing of each other, one database.
         *
         * So both would run, and the second one's SELECT would pick up the rows the first had
         * just marked and was at that moment sending. Campaign #91 is what that costs: 14,236
         * recipients, 22,972 sends, 8,736 people mailed twice and paid for twice.
         *
         * The token closes it for good. The UPDATE stamps the rows it claims — a single atomic
         * statement, so two workers racing it claim disjoint sets — and the SELECT then asks for
         * this token and nothing else. A row another worker is holding is invisible here, on any
         * machine, whatever the locks did.
         */
        $claimToken = bin2hex(random_bytes(16));
        $tokE = $conn->real_escape_string($claimToken);
        $conn->query("UPDATE email_campaign_recipients
                         SET status='processing', claim_token='$tokE', claimed_at=NOW()
                       WHERE campaign_id=$cid AND status='pending'
                       ORDER BY id LIMIT " . (int)$limit);
        $claimedRows = [];
        if ($conn->affected_rows > 0) {
            $claimed = $conn->query("SELECT * FROM email_campaign_recipients
                                      WHERE campaign_id=$cid AND claim_token='$tokE' ORDER BY id");
            while ($claimed && $row = $claimed->fetch_assoc()) $claimedRows[] = $row;
        }

        $transport = TransportFactory::forCampaign($campaign);
        // An unusable transport is settled here rather than discovered 500 times over the
        // network: with a placeholder API key every one of those requests is a guaranteed 401,
        // so checking once saves a batch's worth of pointless round-trips.
        if ($transport && !$transport->isConfigured()) {
            campaign_log("campaign #$cid: ESP transport '{$campaign['esp_transport']}' has no API key set — paste a real key in Settings");
            $transport = null;
        }
        if (!$transport) campaign_log("campaign #$cid: ESP transport '{$campaign['esp_transport']}' not configured — every recipient in this batch will be marked failed");
        // Read attachment files from disk + base64-encode ONCE per campaign per tick, not
        // once per recipient — reused for every send in this batch.
        $attachments = load_campaign_attachments($campaign);

        // Customer Attributes resolved ONCE for this whole tick's recipients (one query per
        // attribute, not one per recipient) — see AttributeResolver.php.
        $attributes = load_all_attributes();
        $attributeTokensByEmail = $attributes ? resolve_attribute_values_batch($attributes, $claimedRows) : [];

        // ---- Phase 1: render every message in this batch (no network yet) ----
        // Rendering is pure CPU and fast; doing it up front means the whole batch can then go
        // out with many requests in flight at once instead of render-send-wait, one at a time.
        $jobs = [];
        $rowsById = [];
        foreach ($claimedRows as $recipient) {
            $processed++;
            $rowsById[$recipient['id']] = $recipient;

            if (!$transport) continue; // handled as a batch failure below

            // Only relevant when the campaign was tied to a specific exam in the Content step —
            // most campaigns (e.g. a purchase-segment promo) have exam_cit_version = NULL, and
            // resolve_exam_data() short-circuits instantly in that case (see its own null-guard).
            if (!empty($campaign['exam_cit_version'])) {
                $examData = resolve_exam_data((int)($recipient['user_id'] ?? 0), $campaign['exam_cit_version']);
                if ($examData) $recipient = array_merge($recipient, $examData);
            }

            $attrTokens  = $attributeTokensByEmail[strtolower($recipient['email'])] ?? [];
            $subject     = substitute_merge_tags((string)$campaign['subject'], $recipient, $attrTokens);
            $senderName  = substitute_merge_tags((string)$campaign['sender_name'], $recipient, $attrTokens);
            $preheader   = substitute_merge_tags((string)$campaign['preheader'], $recipient, $attrTokens);
            $html        = substitute_merge_tags((string)$campaign['content_html'], $recipient, $attrTokens);
            $html        = inject_preheader($html, $preheader);
            $html        = inject_tracking($html, $recipient['rid']);
            /*
             * AFTER the click tracker, never before.
             *
             * inject_tracking rewrites every href to go through track-click.php. Putting the
             * unsubscribe link in first would send somebody who is leaving through the click
             * tracker, logging a click on the campaign they are opting out of — which inflates the
             * click rate with exactly the people it should not count, and adds a redirect between
             * them and the door.
             */
            $html        = inject_unsubscribe($html, (string)$recipient['email']);

            $jobs[] = [
                'key' => $recipient['id'],
                'rid' => $recipient['rid'],
                'req' => $transport->buildRequest(
                    $recipient['email'], $subject, $html,
                    $senderName !== '' ? $senderName : (string)$campaign['sender_name'],
                    (string)$campaign['sender_email'],
                    $campaign['reply_to'] ?: null,
                    $recipient['rid'],
                    $attachments
                ),
            ];
        }

        // ---- Phase 2: send them all concurrently ----
        if (!$transport) {
            $results = [];
            foreach ($rowsById as $id => $_) {
                $results[$id] = ['ok' => false, 'message_id' => null, 'error' => 'No ESP transport configured', 'retryable' => false];
            }
        } else {
            $startedAt = microtime(true);
            // Per-provider, not the bare constant: Amazon SES enforces a hard sends-per-second
            // ceiling and rejects the overflow outright, so it gets a lower cap than the ESPs
            // that merely queue. See TransportFactory::concurrencyFor().
            $concurrency = TransportFactory::concurrencyFor((string)$campaign['esp_transport']);
            $limiter = TransportFactory::rateLimiterFor($transport);
            $results = esp_send_parallel($transport, $jobs, $concurrency, 20, $limiter);
            $elapsed = max(0.001, microtime(true) - $startedAt);
            // The throughput line is the number to watch when tuning CAMPAIGN_SEND_CONCURRENCY.
            // Skipped for an empty round so a drained campaign doesn't log a meaningless "0/s".
            if ($jobs) {
                campaign_log(sprintf('campaign #%d: %d sends in %.1fs (%.0f/s, concurrency %d%s)',
                    $cid, count($jobs), $elapsed, count($jobs) / $elapsed, $concurrency,
                    $limiter ? sprintf(', paced at %d/s', $limiter->rate()) : ''));
            }
        }

        // ---- Phase 3: write the outcomes back in a handful of queries, not two per recipient ----
        // At 500 recipients a batch the old per-recipient UPDATE pair was 1000 round-trips to
        // MySQL, which became its own bottleneck the moment the sending stopped being the slow
        // part. Grouped writes keep the database cost roughly constant per batch.
        $sentIds = [];
        $messageIds = [];
        $failures = [];      // id => error, permanent
        $retryables = [];    // id => error, provider was busy — must NOT burn an attempt
        foreach ($results as $id => $res) {
            if (!empty($res['ok'])) {
                $sentIds[] = (int)$id;
                $messageIds[(int)$id] = (string)($res['message_id'] ?? '');
            } elseif (!empty($res['retryable'])) {
                $retryables[(int)$id] = $res['error'] ?? 'Provider busy';
            } else {
                $failures[(int)$id] = $res['error'] ?? 'Unknown send error';
            }
        }

        if ($sentIds) {
            $cases = '';
            foreach ($messageIds as $id => $msgId) {
                $cases .= " WHEN $id THEN '" . $conn->real_escape_string($msgId) . "'";
            }
            /*
             * A bounce that already arrived is kept.
             *
             * The provider's webhook can report a bounce before this batch finishes — SES does it in
             * seconds, and a paced SES batch of 500 takes about 45. Writing 'sent' over it hid the
             * bounce: campaign #102 counted 12 bounces while its Bounced filter showed none, because
             * the filter reads this status. bounced_at is set only by those webhooks.
             */
            $conn->query("UPDATE email_campaign_recipients
                             SET status = IF(status = 'bounced' AND bounced_at IS NOT NULL, 'bounced', 'sent'),
                                 sent_at=NOW(), esp_message_id = CASE id$cases ELSE esp_message_id END
                           WHERE id IN (" . implode(',', $sentIds) . ")");
            // delivered_count is NOT bumped here — "sent" only means the ESP accepted the API
            // call, not that a mailbox actually received it. Real delivery confirmation comes
            // later, asynchronously, via the provider's webhook ('delivered' / 'Sent').
            /*
             * COUNTED, not incremented.
             *
             * "sent_count = sent_count + n" is only correct while nothing can send a row twice,
             * and when that assumption broke it recorded 22,972 against 14,236 recipients — a
             * number with no row behind it, which is why the list showed Sent exceeding Published
             * and nobody could tell whether the extra sends were real. They were.
             *
             * The row's own status is the record of what happened to it, and a row can only be
             * 'sent' once however many times it was attempted. Counting is one indexed query per
             * batch against the same table just written, which is not a cost worth trading
             * correctness for.
             */
            $c = $conn->query("SELECT COUNT(*) AS c FROM email_campaign_recipients
                                WHERE campaign_id=$cid AND is_test=0 AND status IN ('sent','bounced')");
            $conn->query("UPDATE email_campaigns SET sent_count = " . (int)($c ? $c->fetch_assoc()['c'] : 0) . " WHERE id=$cid");
            $sent += count($sentIds);
        }

        if ($failures) {
            mark_recipients_failed_batch($failures, $rowsById);
            $failed += count($failures);
            // Log a sample rather than every line — a whole batch failing for one reason
            // (bad API key, suspended account) would otherwise write 500 identical lines.
            $sampleId = array_key_first($failures);
            campaign_log("campaign #$cid: " . count($failures) . " permanent rejection(s), e.g. "
                . ($rowsById[$sampleId]['email'] ?? '?') . " -> " . $failures[$sampleId]);
        }

        if ($retryables) {
            // Straight back to 'pending' with attempts untouched: the provider said "not now",
            // not "never". Without this, one rate-limit burst at high concurrency would eat an
            // attempt from every recipient in the batch and, after three bursts, permanently
            // fail thousands of perfectly good addresses.
            // claim_token cleared with the status: the row is free again, and a stale token on a
            // pending row would make the stale-claim sweep below read it as still held.
            $conn->query("UPDATE email_campaign_recipients SET status='pending', claim_token=NULL, claimed_at=NULL
                           WHERE id IN (" . implode(',', array_keys($retryables)) . ")");
            $sampleId = array_key_first($retryables);
            // Names the constant that actually governs this campaign — SES is capped separately,
            // so pointing an SES run at CAMPAIGN_SEND_CONCURRENCY would send someone to tune a
            // number that is not the binding one.
            $lever = ($campaign['esp_transport'] ?? '') === 'ses' ? 'SES_MAX_CONCURRENCY' : 'CAMPAIGN_SEND_CONCURRENCY';
            campaign_log("campaign #$cid: " . count($retryables) . " rate-limited/retryable, requeued (attempts NOT consumed), e.g. "
                . $retryables[$sampleId] . " — consider lowering $lever if this is constant");
            // Let the provider's window reset before the next batch hits it just as hard.
            sleep(CAMPAIGN_RATE_LIMIT_BACKOFF_SECONDS);
        }

        if ($processed > 0) {
            campaign_log("campaign #$cid: this tick sent=$sent failed=$failed (out of $processed attempted)");
        }

        /*
         * DID THIS BATCH FAIL FOR A REASON THE WHOLE AUDIENCE SHARES?
         *
         * Checked per batch, between batches, so a provider that has hit its quota costs a fraction
         * of one batch rather than the rest of the campaign. Both the permanent failures and the
         * retryables are scanned: a rate limit arrives as retryable and is right to retry once, but
         * a sustained one is the provider saying no for the day and retrying is just a slower way
         * of failing.
         */
        $scan = failover_scan(array_merge($failures, $retryables));
        if ($scan['code'] !== null && $scan['count'] >= FAILOVER_THRESHOLD) {
            $from = (string)$campaign['esp_transport'];

            /*
             * THE PROVIDER WILL NOT SEND FROM THIS ADDRESS.
             *
             * Every recipient gets the same refusal, so carrying on only burns the audience —
             * campaign #100 marked 1,515 people failed in forty seconds on "From email address not
             * allowed". Nor is it a reason to change provider: the address is the campaign's own
             * setting and the fix is a person's. So the send stops, the recipients refused for
             * this reason go back in the queue, and someone is told. Resume carries on.
             */
            if (!failover_code_switches($scan['code'])) {
                $requeued = failover_requeue_campaign_failures($cid, $scan['code']);
                $conn->query("UPDATE email_campaigns SET status='suspended' WHERE id=$cid AND status='running'");
                campaign_log("campaign #$cid: SUSPENDED — " . failover_reason_text($scan['code'])
                    . " ({$scan['count']} refused, $requeued put back in the queue) — " . mb_substr($scan['sample'], 0, 200));
                failover_alert_sender_rejected($cid, (string)$campaign['name'], $from,
                    (string)$campaign['sender_email'], $scan['sample'], $scan['count'], $requeued);
                continue;
            }

            $moved = failover_switch_campaign($cid, $from, $scan['code'], $scan['sample'], $scan['count']);
            if ($moved !== null) {
                // Next batch picks up the new provider, because the loop re-reads the campaign row.
                campaign_log("campaign #$cid: continuing on $moved");
                continue;
            }
            /*
             * Nowhere to move. Suspend rather than grind through the rest of the audience failing
             * every one of them — those recipients stay pending and Resume picks them up once the
             * provider recovers, instead of being burnt as failures.
             */
            campaign_log("campaign #$cid: SUSPENDED — " . failover_reason_text($scan['code'])
                . ' and no usable second provider');
            $conn->query("UPDATE email_campaigns SET status='suspended' WHERE id=$cid");
            continue;
        }

        $remain = $conn->query("SELECT COUNT(*) AS c FROM email_campaign_recipients WHERE campaign_id=$cid AND status IN ('pending','processing')");
        $remainCount = $remain ? (int)$remain->fetch_assoc()['c'] : 0;
        if ($remainCount === 0) {
            // "Nothing left in the queue" is NOT the same as "everyone got sent" — a recipient
            // that fails 3 times also leaves the pending/processing queue, ending up 'failed'
            // instead. Check whether anything actually succeeded before declaring victory —
            // this is what let a campaign show SENT even when every single send failed (e.g.
            // an unpaid/suspended SendGrid account rejecting every request).
            $sentCheck = $conn->query("SELECT COUNT(*) AS c FROM email_campaign_recipients WHERE campaign_id=$cid AND status='sent'");
            $sentCount = $sentCheck ? (int)$sentCheck->fetch_assoc()['c'] : 0;
            $finalStatus = $sentCount > 0 ? 'sent' : 'failed';
            $conn->query("UPDATE email_campaigns SET status='$finalStatus', completed_at=NOW() WHERE id=$cid AND status='running'");
            campaign_log("campaign #$cid: COMPLETED -> status=$finalStatus ($sentCount sent successfully)");

            /*
             * A campaign that reached the end having sent NOTHING.
             *
             * The loudest possible failure and, before this, the quietest: the run finishes, the
             * status says failed, and nobody finds out until somebody opens the screen. At the
             * sizes this handles the send window has usually passed by then.
             */
            if ($finalStatus === 'failed') {
                $fr = $conn->query("SELECT error_message, COUNT(*) c FROM email_campaign_recipients
                                     WHERE campaign_id=$cid AND is_test=0 AND status='failed'
                                     GROUP BY error_message ORDER BY c DESC LIMIT 3");
                $why = [];
                while ($fr && $frow = $fr->fetch_assoc()) {
                    $why[] = $frow['c'] . ' x ' . mb_substr((string)$frow['error_message'], 0, 200);
                }
                $nr = $conn->query("SELECT name, esp_transport, total_recipients FROM email_campaigns WHERE id=$cid LIMIT 1");
                $nrow = $nr ? $nr->fetch_assoc() : [];
                alert_notify(
                    "campaign-failed:$cid",
                    'Email campaign finished without sending anything',
                    '*' . ($nrow['name'] ?? ('#' . $cid)) . '* ran to completion and not one recipient was sent to. '
                    . 'The audience has not been consumed — the recipients are on the campaign as failed and can be retried '
                    . 'once the cause is fixed.',
                    [
                        'Campaign'   => ($nrow['name'] ?? '?') . ' (id ' . $cid . ')',
                        'Provider'   => failover_label((string)($nrow['esp_transport'] ?? '')),
                        'Audience'   => (string)($nrow['total_recipients'] ?? 0),
                        'Top reasons'=> $why ? implode("\n", $why) : 'No error text was recorded.',
                    ],
                    'critical'
                );
            }
        }
    }

    return ['processed' => $processed, 'sent' => $sent, 'failed' => $failed, 'campaigns' => count($campaignIds)];
}

/** Fetches a campaign's uploaded attachments from S3 and base64-encodes them, ready to
 *  hand to an EspTransport::sendEmail() call. Called once per batch tick (not per
 *  recipient), so fetching over HTTPS instead of a local file read is not a performance
 *  concern. Missing/unreachable files are silently skipped. */
function load_campaign_attachments(array $campaign): array {
    $list = json_decode($campaign['attachments'] ?? '[]', true) ?: [];
    $out = [];
    foreach ($list as $a) {
        $url = $a['s3_url'] ?? '';
        if ($url === '') continue;
        $bytes = s3_fetch_bytes($url);
        if ($bytes === null) continue;
        $out[] = [
            'filename' => $a['filename'] ?? basename($url),
            'content'  => base64_encode($bytes),
            'type'     => $a['mime'] ?? 'application/octet-stream',
        ];
    }
    return $out;
}

/**
 * Applies the send-failure rule to a whole batch: three strikes and the recipient is
 * 'failed', otherwise back to 'pending' for another go — in two queries rather than one
 * per recipient. (This replaced a per-recipient mark_recipient_failed(); at 500 recipients
 * a batch, that was 500 separate round-trips to MySQL.)
 *
 * Only ever called with PERMANENT failures. Provider-busy responses take the separate
 * requeue path in campaigns_process_batch(), which deliberately does not touch `attempts`.
 *
 * @param array $errors   recipient id => error message
 * @param array $rowsById recipient id => the claimed row (for its current `attempts`)
 */
function mark_recipients_failed_batch(array $errors, array $rowsById): void {
    global $conn;
    if (!$errors) return;

    $byStatus = ['failed' => [], 'pending' => []];
    $errorCases = '';
    foreach ($errors as $id => $error) {
        $id = (int)$id;
        $attempts = (int)($rowsById[$id]['attempts'] ?? 0) + 1;
        $byStatus[$attempts >= 3 ? 'failed' : 'pending'][] = $id;
        $errorCases .= " WHEN $id THEN '" . $conn->real_escape_string(substr((string)$error, 0, 480)) . "'";
    }

    // attempts is incremented with `attempts + 1` rather than a computed literal so a
    // concurrent write can't be silently overwritten with a stale value.
    foreach ($byStatus as $status => $ids) {
        if (!$ids) continue;
        $conn->query("UPDATE email_campaign_recipients
                         SET status='$status', attempts = attempts + 1,
                             error_message = CASE id$errorCases ELSE error_message END
                       WHERE id IN (" . implode(',', $ids) . ")");
    }
}

/**
 * Materializes recipient rows for a campaign from its Audience-step config —
 * called once by send_now/schedule (not re-resolved per worker tick), batched
 * in chunks of 500 inserts. Returns the number of recipients queued.
 */
/**
 * The two columns the claim needs, and the recovery of anything a dead worker left behind.
 *
 * A row marked 'processing' by a run that was then killed — a deploy, an OOM, a cron overlapping a
 * 10-minute campaign — belongs to nobody and would otherwise sit there for ever, because only
 * 'pending' rows are ever claimed. It goes back to 'pending' once it is old enough that it cannot
 * still be in flight.
 *
 * CAMPAIGN_CLAIM_STALE_MINUTES is deliberately generous. Requeueing a row that is merely SLOW is
 * exactly the double-send this whole change exists to stop, so the sweep waits far longer than any
 * healthy batch could take rather than risk racing one.
 */
if (!defined('CAMPAIGN_CLAIM_STALE_MINUTES')) define('CAMPAIGN_CLAIM_STALE_MINUTES', 15);

function campaign_claim_ensure_schema(): void {
    global $conn;
    static $done = false;
    if ($done) return;
    $done = true;

    foreach ([
        'claim_token' => "ADD COLUMN claim_token CHAR(32) DEFAULT NULL",
        'claimed_at'  => "ADD COLUMN claimed_at DATETIME DEFAULT NULL",
    ] as $col => $ddl) {
        $c = @$conn->query("SHOW COLUMNS FROM email_campaign_recipients LIKE '$col'");
        if ($c && $c->num_rows === 0) @$conn->query("ALTER TABLE email_campaign_recipients $ddl");
    }
    /*
     * The claim's SELECT is by token; without this it is a full scan of every recipient ever.
     *
     * Existence is checked rather than letting a duplicate CREATE fail quietly: mysqli runs in
     * exception mode here, so "@" does NOT swallow it — it throws, and this function is called on
     * every single worker run. The first version of this fataled the entire send worker the second
     * time it ran.
     */
    $ix = $conn->query("SELECT COUNT(*) c FROM INFORMATION_SCHEMA.STATISTICS
                          WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'email_campaign_recipients'
                            AND INDEX_NAME = 'idx_claim'");
    if ($ix && (int)$ix->fetch_assoc()['c'] === 0) {
        try { $conn->query("CREATE INDEX idx_claim ON email_campaign_recipients (claim_token)"); }
        catch (Throwable $e) { campaign_log('could not create idx_claim: ' . $e->getMessage()); }
    }
}

/** Frees rows abandoned by a worker that died mid-batch. Returns how many. */
function campaign_requeue_stale_claims(): int {
    global $conn;
    campaign_claim_ensure_schema();
    $conn->query("UPDATE email_campaign_recipients
                     SET status='pending', claim_token=NULL, claimed_at=NULL
                   WHERE status='processing'
                     AND (claimed_at IS NULL OR claimed_at < DATE_SUB(NOW(), INTERVAL " . (int)CAMPAIGN_CLAIM_STALE_MINUTES . " MINUTE))");
    $n = $conn->affected_rows;
    if ($n > 0) campaign_log("requeued $n recipient(s) left in 'processing' by a worker that did not finish");
    return $n;
}

function materialize_campaign_recipients(int $campaignId): int {
    global $conn;

    $campRes = $conn->query("SELECT audience_type, segment_ids, exclude_segment_ids, exclude_list_ids, list_ids, domain_filter, verify_before_send FROM email_campaigns WHERE id=$campaignId LIMIT 1");
    if (!$campRes) {
        // The query itself failed (e.g. "Unknown column 'list_ids'" if the additive ALTER in
        // schema.php never actually ran on this DB) — mysqli doesn't throw by default, it just
        // returns false silently, which used to be indistinguishable from "campaign not found".
        campaign_log("campaign #$campaignId: FATAL — the campaign-row SELECT itself failed: " . $conn->error);
        return 0;
    }
    $campaign = $campRes->fetch_assoc();
    if (!$campaign) return 0;

    $config = [
        'audience_type'       => $campaign['audience_type'],
        'segment_ids'         => json_decode($campaign['segment_ids'] ?? '[]', true) ?: [],
        'exclude_segment_ids' => json_decode($campaign['exclude_segment_ids'] ?? '[]', true) ?: [],
        'exclude_list_ids'    => json_decode($campaign['exclude_list_ids'] ?? '[]', true) ?: [],
        'list_ids'            => json_decode($campaign['list_ids'] ?? '[]', true) ?: [],
        'domain_filter'       => $campaign['domain_filter'],
    ];

    // Clear any previous (non-test) queued rows before re-materializing (e.g. re-scheduling a draft).
    $conn->query("DELETE FROM email_campaign_recipients WHERE campaign_id=$campaignId AND is_test=0");

    $users = resolve_audience_users($config);

    /*
     * VERIFY BEFORE WRITING THE AUDIENCE, not before sending each message.
     *
     * Here is the one moment the whole audience exists as a list, which is what makes the checks
     * batchable — several thousand in parallel, rather than one blocking round trip per recipient
     * in the send loop. It is also before a single row is written, so an address that does not
     * exist is never queued, never attempted, and never counted as sent.
     *
     * Addresses that fail go on the blocklist, which is the list resolve_audience_users() already
     * consults — so the cost is paid once and every later campaign skips them for nothing. Off
     * unless it has been switched on in Settings, and it can only ever REMOVE people: a failure to
     * verify leaves the address in the audience (see EmailVerifier.php).
     */
    $verificationSkipped = 0;
    if (function_exists('email_verify_and_block') && $users) {
        // This campaign's own choice. NULL means it never made one and the Settings default applies.
        $wantsVerify = $campaign['verify_before_send'] === null ? null : ((int)$campaign['verify_before_send'] === 1);
        $blocked = email_verify_and_block(
            array_column($users, 'email'),
            fn($line) => campaign_log("campaign #$campaignId: $line"),
            $wantsVerify
        );
        // Verification just spent minutes waiting on an external service; the connection below
        // has to still be usable, or the insert dies and nothing is ever queued.
        campaign_db_alive();
        if ($blocked) {
            $before = count($users);
            $users = array_values(array_filter($users, fn($u) => !isset($blocked[strtolower((string)$u['email'])])));
            $verificationSkipped = $before - count($users);
            campaign_log("campaign #$campaignId: verification removed $verificationSkipped"
                . ' undeliverable address(es) from the audience before queueing');
        }
    }

    $total = count($users);

    if ($total > 0) {
        $chunks = array_chunk($users, 500);
        foreach ($chunks as $chunk) {
            $values = [];
            foreach ($chunk as $u) {
                $rid    = bin2hex(random_bytes(16));
                // List-only contacts (no matching registered user) carry user_id => null —
                // (int)null would silently coerce to 0, an invalid/misleading value, so emit
                // literal SQL NULL instead. email_campaign_recipients.user_id is already nullable.
                $uid    = $u['user_id'] !== null ? (int)$u['user_id'] : 'NULL';
                $email  = $conn->real_escape_string($u['email']);
                $fname  = $conn->real_escape_string((string)($u['first_name'] ?? ''));
                $lname  = $conn->real_escape_string((string)($u['last_name'] ?? ''));
                $phone  = $conn->real_escape_string((string)($u['phone'] ?? ''));
                $values[] = "($campaignId, $uid, '$email', '$fname', '$lname', '$phone', 0, 'pending', '$rid')";
            }
            $conn->query("INSERT INTO email_campaign_recipients
                (campaign_id, user_id, email, first_name, last_name, phone, is_test, status, rid)
                VALUES " . implode(',', $values));
        }
    }

    // Stamp materialized_at regardless of outcome (even $total=0) so the worker doesn't
    // keep retrying an empty-audience campaign on every future tick.
    // Written even when it is zero, so a re-materialised campaign cannot keep a count from a
    // previous run that no longer describes the audience now queued.
    $conn->query("UPDATE email_campaigns SET total_recipients=$total, verification_skipped=" . (int)$verificationSkipped
        . ", materialized_at=NOW() WHERE id=$campaignId");
    return $total;
}

/**
 * Non-blocking "fire and forget" kick so Send Now doesn't wait for the next
 * cron minute — the save/send_now request returns instantly, and this opens
 * a raw socket to the worker endpoint without waiting for a response. Cron
 * (campaign-send-worker.php on a crontab) remains the reliable safety-net
 * that finishes anything this instant kick didn't get to.
 */
function trigger_worker_async(int $campaignId) {
    $host = 'cit3.internshipstudio.com';
    $path = '/admin/react-api/api/campaigns/campaign-send-worker.php?cron_secret=' . urlencode(CRON_SECRET) . '&campaign_id=' . $campaignId;
    $fp = @fsockopen('ssl://' . $host, 443, $errno, $errstr, 1);
    if (!$fp) return;
    stream_set_timeout($fp, 1);
    fwrite($fp, "GET $path HTTP/1.1\r\nHost: $host\r\nConnection: Close\r\n\r\n");
    fclose($fp);
}

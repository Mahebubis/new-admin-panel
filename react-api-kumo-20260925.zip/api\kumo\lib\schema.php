<?php
/*
 * kumo_ensure_schema() — idempotent CREATE TABLE IF NOT EXISTS for every table
 * behind the KumoMTA module. Called at the top of every entrypoint, mirroring
 * campaigns/lib/schema.php.
 *
 * SAFETY CONTRACT FOR THIS WHOLE MODULE
 * ─────────────────────────────────────
 *  • Every table created here is prefixed `kumo_` and is NEW. This file never
 *    issues ALTER / DROP / TRUNCATE / DELETE / UPDATE / INSERT against any
 *    pre-existing table of this database.
 *  • The only contact this module has with existing data (users, campaign_*,
 *    netcore_*) is read-only SELECTs, used when importing an audience.
 *  • CREATE TABLE IF NOT EXISTS is metadata-only and safe to run per request.
 *
 * Doc mirror of this SQL: ../kumo_schema.sql (kept in sync by hand).
 */

require_once __DIR__ . '/config.php';

function kumo_ensure_schema(): void {
    global $conn;
    if (!$conn) return;

    static $done = false;
    if ($done) return;           // once per request is plenty
    $done = true;

    try {
        /* ── Sending IPs ──────────────────────────────────────────────────── */
        $conn->query("CREATE TABLE IF NOT EXISTS kumo_ips (
            id              INT AUTO_INCREMENT PRIMARY KEY,
            ip              VARCHAR(45)  NOT NULL,
            hostname        VARCHAR(190) NOT NULL DEFAULT '',
            tenant          VARCHAR(64)  NOT NULL,
            label           VARCHAR(120) NOT NULL DEFAULT '',
            status          ENUM('active','paused','retired') NOT NULL DEFAULT 'active',
            health          ENUM('green','yellow','red','unknown') NOT NULL DEFAULT 'unknown',
            health_reason   TEXT DEFAULT NULL,
            warmup_enabled  TINYINT(1) NOT NULL DEFAULT 1,
            warmup_day      INT NOT NULL DEFAULT 1,
            warmup_started_at DATE DEFAULT NULL,
            manual_cap      INT DEFAULT NULL,
            good_hours      INT NOT NULL DEFAULT 0,
            ptr_ok          TINYINT(1) NOT NULL DEFAULT 0,
            ptr_value       VARCHAR(190) DEFAULT NULL,
            blocklisted     TINYINT(1) NOT NULL DEFAULT 0,
            blocklist_note  VARCHAR(255) DEFAULT NULL,
            paused_reason   VARCHAR(255) DEFAULT NULL,
            paused_by       VARCHAR(120) DEFAULT NULL,
            paused_at       DATETIME DEFAULT NULL,
            last_health_at  DATETIME DEFAULT NULL,
            last_send_at    DATETIME DEFAULT NULL,
            batch_no        INT NOT NULL DEFAULT 1,
            batch_size      INT NOT NULL DEFAULT 0,
            batch_index     INT NOT NULL DEFAULT 0,
            purchased_at    DATE DEFAULT NULL,
            sort_order      INT NOT NULL DEFAULT 0,
            created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            UNIQUE KEY uq_ip (ip),
            UNIQUE KEY uq_tenant (tenant),
            KEY idx_status (status, health)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

        /* Per-IP per-day quota ledger: the warmup engine writes `cap`, the
           sender checks it before claiming more work. */
        $conn->query("CREATE TABLE IF NOT EXISTS kumo_ip_daily (
            id        INT AUTO_INCREMENT PRIMARY KEY,
            ip_id     INT NOT NULL,
            day       DATE NOT NULL,
            cap       INT NOT NULL DEFAULT 0,
            sent      INT NOT NULL DEFAULT 0,
            warmup_day INT NOT NULL DEFAULT 0,
            UNIQUE KEY uq_ip_day (ip_id, day),
            KEY idx_day (day)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

        /* Hourly rollup per IP per mailbox provider — the dashboard's charts. */
        $conn->query("CREATE TABLE IF NOT EXISTS kumo_ip_stats (
            id         BIGINT AUTO_INCREMENT PRIMARY KEY,
            ip_id      INT NOT NULL,
            bucket     DATETIME NOT NULL,
            provider   VARCHAR(32) NOT NULL DEFAULT 'other',
            sent       INT NOT NULL DEFAULT 0,
            delivered  INT NOT NULL DEFAULT 0,
            deferred   INT NOT NULL DEFAULT 0,
            bounced    INT NOT NULL DEFAULT 0,
            complaints INT NOT NULL DEFAULT 0,
            opens      INT NOT NULL DEFAULT 0,
            clicks     INT NOT NULL DEFAULT 0,
            unsubs     INT NOT NULL DEFAULT 0,
            UNIQUE KEY uq_bucket (ip_id, bucket, provider),
            KEY idx_bucket (bucket)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

        /* Health history — one row per IP per scoring run. */
        $conn->query("CREATE TABLE IF NOT EXISTS kumo_ip_health (
            id             BIGINT AUTO_INCREMENT PRIMARY KEY,
            ip_id          INT NOT NULL,
            checked_at     DATETIME NOT NULL,
            color          ENUM('green','yellow','red','unknown') NOT NULL,
            sent_24h       INT NOT NULL DEFAULT 0,
            bounce_rate    DECIMAL(6,3) NOT NULL DEFAULT 0,
            complaint_rate DECIMAL(6,3) NOT NULL DEFAULT 0,
            deferral_rate  DECIMAL(6,3) NOT NULL DEFAULT 0,
            delivery_rate  DECIMAL(6,3) NOT NULL DEFAULT 0,
            reasons        TEXT DEFAULT NULL,
            KEY idx_ip_time (ip_id, checked_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

        /* Warmup ladder (editable in Settings). */
        $conn->query("CREATE TABLE IF NOT EXISTS kumo_warmup_plan (
            id        INT AUTO_INCREMENT PRIMARY KEY,
            day_from  INT NOT NULL,
            day_to    INT NOT NULL,
            daily_cap INT NOT NULL,
            UNIQUE KEY uq_from (day_from)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

        /* DNSBL results per IP / domain. */
        $conn->query("CREATE TABLE IF NOT EXISTS kumo_blocklist_checks (
            id         INT AUTO_INCREMENT PRIMARY KEY,
            target     VARCHAR(190) NOT NULL,
            kind       ENUM('ip','domain') NOT NULL DEFAULT 'ip',
            zone       VARCHAR(64) NOT NULL,
            listed     TINYINT(1) NOT NULL DEFAULT 0,
            response   VARCHAR(64) DEFAULT NULL,
            checked_at DATETIME NOT NULL,
            UNIQUE KEY uq_target_zone (target, zone)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

        /* ── Audience ─────────────────────────────────────────────────────── */
        $conn->query("CREATE TABLE IF NOT EXISTS kumo_contacts (
            id            BIGINT AUTO_INCREMENT PRIMARY KEY,
            email         VARCHAR(255) NOT NULL,
            first_name    VARCHAR(120) DEFAULT NULL,
            last_name     VARCHAR(120) DEFAULT NULL,
            phone         VARCHAR(32)  DEFAULT NULL,
            attrs         JSON DEFAULT NULL,
            source        VARCHAR(64) NOT NULL DEFAULT 'manual',
            consent_at    DATETIME DEFAULT NULL,
            status        ENUM('active','unsubscribed','bounced','complained') NOT NULL DEFAULT 'active',
            engagement    ENUM('new','hot','warm','cold','dormant') NOT NULL DEFAULT 'new',
            last_open_at  DATETIME DEFAULT NULL,
            last_click_at DATETIME DEFAULT NULL,
            last_send_at  DATETIME DEFAULT NULL,
            created_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            UNIQUE KEY uq_email (email),
            KEY idx_status (status),
            KEY idx_engagement (engagement)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

        $conn->query("CREATE TABLE IF NOT EXISTS kumo_lists (
            id            INT AUTO_INCREMENT PRIMARY KEY,
            name          VARCHAR(190) NOT NULL,
            description   VARCHAR(500) DEFAULT NULL,
            kind          ENUM('list','import') NOT NULL DEFAULT 'list',
            contact_count INT NOT NULL DEFAULT 0,
            created_by    VARCHAR(120) DEFAULT NULL,
            created_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

        $conn->query("CREATE TABLE IF NOT EXISTS kumo_list_members (
            id         BIGINT AUTO_INCREMENT PRIMARY KEY,
            list_id    INT NOT NULL,
            contact_id BIGINT NOT NULL,
            added_at   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            UNIQUE KEY uq_member (list_id, contact_id),
            KEY idx_contact (contact_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

        /* A segment is a saved rule set. `source` decides how it resolves:
             kumo_list  → members of one or more kumo lists
             engagement → kumo_contacts filtered by engagement / activity window
             netcore    → REUSES an existing netcore_segments row, READ-ONLY */
        $conn->query("CREATE TABLE IF NOT EXISTS kumo_segments (
            id            INT AUTO_INCREMENT PRIMARY KEY,
            name          VARCHAR(190) NOT NULL,
            description   VARCHAR(500) DEFAULT NULL,
            source        ENUM('kumo_list','engagement','netcore','rules') NOT NULL DEFAULT 'engagement',
            config        JSON DEFAULT NULL,
            cached_count  INT NOT NULL DEFAULT 0,
            counted_at    DATETIME DEFAULT NULL,
            created_by    VARCHAR(120) DEFAULT NULL,
            created_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

        /* This module's OWN suppression list. Never shared with campaign_lists. */
        $conn->query("CREATE TABLE IF NOT EXISTS kumo_blocklist (
            id          BIGINT AUTO_INCREMENT PRIMARY KEY,
            email       VARCHAR(255) NOT NULL,
            reason      ENUM('hard_bounce','complaint','unsubscribe','manual','imported','invalid') NOT NULL DEFAULT 'manual',
            detail      VARCHAR(500) DEFAULT NULL,
            campaign_id INT DEFAULT NULL,
            created_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            UNIQUE KEY uq_email (email),
            KEY idx_reason (reason),
            KEY idx_created (created_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

        /* ── Content ──────────────────────────────────────────────────────── */
        $conn->query("CREATE TABLE IF NOT EXISTS kumo_templates (
            id            INT AUTO_INCREMENT PRIMARY KEY,
            name          VARCHAR(190) NOT NULL,
            category      VARCHAR(64) DEFAULT NULL,
            subject       VARCHAR(500) DEFAULT NULL,
            preheader     VARCHAR(500) DEFAULT NULL,
            body_html     LONGTEXT,
            body_text     LONGTEXT,
            status        ENUM('active','archived') NOT NULL DEFAULT 'active',
            created_by    VARCHAR(120) DEFAULT NULL,
            created_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            KEY idx_status (status)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

        /* ── Campaigns ────────────────────────────────────────────────────── */
        $conn->query("CREATE TABLE IF NOT EXISTS kumo_campaigns (
            id                INT AUTO_INCREMENT PRIMARY KEY,
            name              VARCHAR(190) NOT NULL,
            status            ENUM('draft','scheduled','running','paused','sent','failed') NOT NULL DEFAULT 'draft',
            template_id       INT DEFAULT NULL,
            subject           VARCHAR(500) DEFAULT NULL,
            preheader         VARCHAR(500) DEFAULT NULL,
            from_name         VARCHAR(190) DEFAULT NULL,
            from_email        VARCHAR(190) DEFAULT NULL,
            reply_to          VARCHAR(190) DEFAULT NULL,
            body_html         LONGTEXT,
            body_text         LONGTEXT,
            audience_type     ENUM('list','segment','all_contacts') NOT NULL DEFAULT 'list',
            list_ids          JSON DEFAULT NULL,
            segment_ids       JSON DEFAULT NULL,
            exclude_list_ids  JSON DEFAULT NULL,
            ip_mode           ENUM('auto','fixed') NOT NULL DEFAULT 'auto',
            ip_ids            JSON DEFAULT NULL,
            schedule_type     ENUM('now','later') NOT NULL DEFAULT 'now',
            scheduled_at      DATETIME DEFAULT NULL,
            throttle_per_hour INT DEFAULT NULL,
            track_opens       TINYINT(1) NOT NULL DEFAULT 1,
            track_clicks      TINYINT(1) NOT NULL DEFAULT 1,
            total_recipients  INT NOT NULL DEFAULT 0,
            queued_count      INT NOT NULL DEFAULT 0,
            sent_count        INT NOT NULL DEFAULT 0,
            delivered_count   INT NOT NULL DEFAULT 0,
            deferred_count    INT NOT NULL DEFAULT 0,
            bounced_count     INT NOT NULL DEFAULT 0,
            complaint_count   INT NOT NULL DEFAULT 0,
            open_count        INT NOT NULL DEFAULT 0,
            unique_open_count INT NOT NULL DEFAULT 0,
            click_count       INT NOT NULL DEFAULT 0,
            unique_click_count INT NOT NULL DEFAULT 0,
            unsub_count       INT NOT NULL DEFAULT 0,
            skipped_count     INT NOT NULL DEFAULT 0,
            error_message     VARCHAR(500) DEFAULT NULL,
            materialized_at   DATETIME DEFAULT NULL,
            started_at        DATETIME DEFAULT NULL,
            completed_at      DATETIME DEFAULT NULL,
            created_by        VARCHAR(120) DEFAULT NULL,
            created_at        DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at        DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            KEY idx_status (status, scheduled_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

        $conn->query("CREATE TABLE IF NOT EXISTS kumo_campaign_recipients (
            id           BIGINT AUTO_INCREMENT PRIMARY KEY,
            campaign_id  INT NOT NULL,
            contact_id   BIGINT DEFAULT NULL,
            email        VARCHAR(255) NOT NULL,
            first_name   VARCHAR(120) DEFAULT NULL,
            last_name    VARCHAR(120) DEFAULT NULL,
            rid          CHAR(32) NOT NULL,
            status       ENUM('pending','processing','sent','delivered','bounced','failed','skipped') NOT NULL DEFAULT 'pending',
            ip_id        INT DEFAULT NULL,
            provider     VARCHAR(32) DEFAULT NULL,
            attempts     TINYINT NOT NULL DEFAULT 0,
            error        VARCHAR(500) DEFAULT NULL,
            smtp_code    VARCHAR(16) DEFAULT NULL,
            bounce_type  ENUM('hard','soft') DEFAULT NULL,
            is_test      TINYINT(1) NOT NULL DEFAULT 0,
            open_count   INT NOT NULL DEFAULT 0,
            click_count  INT NOT NULL DEFAULT 0,
            claim_token  CHAR(32) DEFAULT NULL,
            claimed_at   DATETIME DEFAULT NULL,
            queued_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            sent_at      DATETIME DEFAULT NULL,
            delivered_at DATETIME DEFAULT NULL,
            bounced_at   DATETIME DEFAULT NULL,
            opened_at    DATETIME DEFAULT NULL,
            clicked_at   DATETIME DEFAULT NULL,
            UNIQUE KEY uq_rid (rid),
            KEY idx_campaign_status (campaign_id, status),
            KEY idx_claim (status, claim_token),
            KEY idx_email (email),
            KEY idx_ip (ip_id, sent_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

        $conn->query("CREATE TABLE IF NOT EXISTS kumo_campaign_events (
            id           BIGINT AUTO_INCREMENT PRIMARY KEY,
            campaign_id  INT DEFAULT NULL,
            recipient_id BIGINT DEFAULT NULL,
            rid          CHAR(32) DEFAULT NULL,
            ip_id        INT DEFAULT NULL,
            type         ENUM('reception','delivery','deferred','bounce','complaint','open','click','unsub','admin_bounce') NOT NULL,
            provider     VARCHAR(32) DEFAULT NULL,
            code         VARCHAR(16) DEFAULT NULL,
            response     TEXT DEFAULT NULL,
            url          VARCHAR(1000) DEFAULT NULL,
            ip_address   VARCHAR(45) DEFAULT NULL,
            user_agent   VARCHAR(500) DEFAULT NULL,
            meta         JSON DEFAULT NULL,
            created_at   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            KEY idx_campaign_type (campaign_id, type),
            KEY idx_rid (rid),
            KEY idx_created (created_at),
            KEY idx_ip_type (ip_id, type, created_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

        /*
         * Contact attributes for THIS module. The panel's existing
         * campaign_attributes rows are read (never written) and shown alongside
         * these, so the screen lists everything while creation stays inside our
         * own table.
         */
        $conn->query("CREATE TABLE IF NOT EXISTS kumo_attributes (
            id              INT AUTO_INCREMENT PRIMARY KEY,
            name            VARCHAR(100) NOT NULL,
            category        ENUM('custom','system','linked') NOT NULL DEFAULT 'custom',
            data_type       ENUM('text','number','date','url','boolean') NOT NULL DEFAULT 'text',
            date_format     VARCHAR(40)  DEFAULT NULL,
            mapped_db       VARCHAR(64)  DEFAULT NULL,
            mapped_table    VARCHAR(128) DEFAULT NULL,
            mapped_column   VARCHAR(128) DEFAULT NULL,
            mapped_join_col VARCHAR(32)  DEFAULT NULL,
            resolver_json   TEXT         DEFAULT NULL,
            default_value   VARCHAR(500) DEFAULT NULL,
            created_by      VARCHAR(120) DEFAULT NULL,
            created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            UNIQUE KEY uq_name (name)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

        /* One row per CSV import run, so Contact logs can show Kumo's own history
           instead of Netcore's campaign_contact_uploads. Written at the end of an
           import, which is synchronous here — there is no pending/processing state. */
        $conn->query("CREATE TABLE IF NOT EXISTS kumo_imports (
            id            INT AUTO_INCREMENT PRIMARY KEY,
            list_id       INT          DEFAULT NULL,
            file_name     VARCHAR(255) DEFAULT NULL,
            total_rows    INT NOT NULL DEFAULT 0,
            imported      INT NOT NULL DEFAULT 0,
            invalid       INT NOT NULL DEFAULT 0,
            suppressed    INT NOT NULL DEFAULT 0,
            duplicate     INT NOT NULL DEFAULT 0,
            as_blocklist  TINYINT(1) NOT NULL DEFAULT 0,
            status        ENUM('processed','failed') NOT NULL DEFAULT 'processed',
            created_by    VARCHAR(120) DEFAULT NULL,
            created_at    DATETIME NOT NULL,
            KEY idx_created (created_at),
            KEY idx_list (list_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

        /* ── Ops ──────────────────────────────────────────────────────────── */
        $conn->query("CREATE TABLE IF NOT EXISTS kumo_settings (
            k          VARCHAR(64) NOT NULL PRIMARY KEY,
            v          TEXT,
            updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

        $conn->query("CREATE TABLE IF NOT EXISTS kumo_alerts (
            id              BIGINT AUTO_INCREMENT PRIMARY KEY,
            level           ENUM('info','warn','critical') NOT NULL DEFAULT 'info',
            ip_id           INT DEFAULT NULL,
            campaign_id     INT DEFAULT NULL,
            title           VARCHAR(255) NOT NULL,
            body            TEXT DEFAULT NULL,
            acknowledged_by VARCHAR(120) DEFAULT NULL,
            acknowledged_at DATETIME DEFAULT NULL,
            created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            KEY idx_open (acknowledged_at, created_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

        /* Probe log for the KumoMTA bridge — powers the API-health widget. */
        $conn->query("CREATE TABLE IF NOT EXISTS kumo_api_health (
            id         BIGINT AUTO_INCREMENT PRIMARY KEY,
            checked_at DATETIME NOT NULL,
            ok         TINYINT(1) NOT NULL DEFAULT 0,
            latency_ms INT NOT NULL DEFAULT 0,
            queue_size INT NOT NULL DEFAULT 0,
            scheduled  INT NOT NULL DEFAULT 0,
            error      VARCHAR(255) DEFAULT NULL,
            KEY idx_time (checked_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    } catch (\Throwable $e) {
        error_log('kumo_ensure_schema: ' . $e->getMessage());
        return;
    }

    /* Additive column migrations — ONLY for this module's own kumo_* tables, so
       an installation created before the batch-naming feature picks the new
       columns up on the next request. Never touches any other table. */
    kumo_add_column('kumo_ips', 'batch_no',     "INT NOT NULL DEFAULT 1");
    kumo_add_column('kumo_ips', 'batch_size',   "INT NOT NULL DEFAULT 0");
    kumo_add_column('kumo_ips', 'batch_index',  "INT NOT NULL DEFAULT 0");
    kumo_add_column('kumo_ips', 'purchased_at', "DATE DEFAULT NULL");
    /* JSON array of {filename, s3_key, s3_url, size, mime} — the files every
       message of the campaign carries. Bytes live in S3, never in the row. */
    kumo_add_column('kumo_campaigns', 'attachments', "TEXT DEFAULT NULL");

    /* 'rules' segments (the Netcore-style condition builder) were added after
       the first install, so widen the ENUM on our own table if needed. */
    kumo_widen_enum('kumo_segments', 'source', "ENUM('kumo_list','engagement','netcore','rules') NOT NULL DEFAULT 'engagement'", 'rules');

    kumo_seed_defaults();
    kumo_seed_ips();
}

/** Adds a column to one of OUR tables if it is not there yet. Refuses anything
 *  that is not prefixed kumo_, so this can never alter an existing product table. */
function kumo_add_column(string $table, string $column, string $definition): void {
    global $conn;
    if (strpos($table, 'kumo_') !== 0) return;          // hard guard
    try {
        $t = $conn->real_escape_string($table);
        $c = $conn->real_escape_string($column);
        $r = $conn->query("SHOW COLUMNS FROM `$t` LIKE '$c'");
        if ($r && $r->num_rows > 0) return;
        $conn->query("ALTER TABLE `$t` ADD COLUMN `$c` $definition");
    } catch (\Throwable $e) {
        error_log("kumo_add_column($table.$column): " . $e->getMessage());
    }
}

/** Widens an ENUM on one of OUR tables when a new value is missing. Same hard
 *  guard as kumo_add_column(): kumo_* tables only. */
function kumo_widen_enum(string $table, string $column, string $definition, string $needle): void {
    global $conn;
    if (strpos($table, 'kumo_') !== 0) return;
    try {
        $t = $conn->real_escape_string($table);
        $c = $conn->real_escape_string($column);
        $r = $conn->query("SHOW COLUMNS FROM `$t` LIKE '$c'");
        $row = $r ? $r->fetch_assoc() : null;
        if (!$row) return;
        if (strpos((string)$row['Type'], $needle) !== false) return;   // already there
        $conn->query("ALTER TABLE `$t` MODIFY `$c` $definition");
    } catch (\Throwable $e) {
        error_log("kumo_widen_enum($table.$column): " . $e->getMessage());
    }
}

/*
 * Seeds the five OVH sending IPs on a fresh install so the panel is usable
 * immediately. Runs ONLY when kumo_ips is completely empty, so it can never
 * overwrite or duplicate anything an admin has already entered.
 *
 * Naming: label = "<batch>-<size>-<index>", e.g. 1-5-3 means
 *   batch 1 (the first purchase) · 5 IPs bought in that batch · IP #3 of them.
 * `tenant` is a different thing and must keep matching the KumoMTA pool name
 * (ip1 … ip5) — that is what routes the message to the right IP.
 */
function kumo_seed_ips(): void {
    global $conn;
    try {
        $r = $conn->query("SELECT COUNT(*) c FROM kumo_ips");
        if (!$r || (int)$r->fetch_assoc()['c'] > 0) return;

        $batch     = 1;
        $ips       = ['54.36.13.79', '54.36.13.83', '54.36.13.84', '54.36.13.86', '54.36.13.88'];
        $purchased = '2026-09-24';
        $size      = count($ips);

        foreach ($ips as $i => $ip) {
            $idx    = $i + 1;
            $tenant = 'ip' . $idx;
            $host   = 'mail' . $idx . '.nitrocampus.com';
            $label  = $batch . '-' . $size . '-' . $idx;
            $conn->query(sprintf(
                "INSERT IGNORE INTO kumo_ips
                    (ip, hostname, tenant, label, batch_no, batch_size, batch_index, purchased_at,
                     status, health, warmup_enabled, warmup_day, warmup_started_at, sort_order)
                 VALUES ('%s','%s','%s','%s',%d,%d,%d,'%s','active','unknown',1,1,CURDATE(),%d)",
                $conn->real_escape_string($ip), $conn->real_escape_string($host),
                $conn->real_escape_string($tenant), $conn->real_escape_string($label),
                $batch, $size, $idx, $purchased, $idx * 10
            ));
        }
    } catch (\Throwable $e) {
        error_log('kumo_seed_ips: ' . $e->getMessage());
    }
}

/** The label a batch position produces: 1-5-3 = batch 1, 5 bought, IP #3. */
function kumo_batch_label(int $batch, int $size, int $index): string {
    return sprintf('%d-%d-%d', max(1, $batch), max(0, $size), max(0, $index));
}

/*
 * Seeds rows ONLY into this module's own (brand-new) tables, and only when
 * they are empty. Guarded separately from the CREATEs because these are real
 * row writes that concurrent requests could collide on.
 */
function kumo_seed_defaults(): void {
    global $conn;
    try {
        $r = $conn->query("SELECT COUNT(*) c FROM kumo_warmup_plan");
        $c = $r ? (int)($r->fetch_assoc()['c'] ?? 0) : 1;
        if ($c === 0) {
            foreach (kumo_default_warmup_plan() as $row) {
                $conn->query(sprintf(
                    "INSERT IGNORE INTO kumo_warmup_plan (day_from, day_to, daily_cap) VALUES (%d,%d,%d)",
                    (int)$row['day_from'], (int)$row['day_to'], (int)$row['daily_cap']
                ));
            }
        }

        $defaults = [
            'bridge_url'        => KUMO_BRIDGE_URL,
            'bridge_token'      => '',
            'from_name'         => 'Internship Studio',
            'from_email'        => 'hello@mail.nitrocampus.com',
            'reply_to'          => '',
            'bounce_domain'     => 'bounce.nitrocampus.com',
            'tracking_domain'   => 'click.nitrocampus.com',
            'th_bounce_yellow'  => (string)KUMO_TH_BOUNCE_YELLOW,
            'th_bounce_red'     => (string)KUMO_TH_BOUNCE_RED,
            'th_complaint_yellow'=> (string)KUMO_TH_COMPLAINT_YELLOW,
            'th_complaint_red'  => (string)KUMO_TH_COMPLAINT_RED,
            'th_deferral_yellow'=> (string)KUMO_TH_DEFERRAL_YELLOW,
            'th_deferral_red'   => (string)KUMO_TH_DEFERRAL_RED,
            'recovery_hours'    => (string)KUMO_RECOVERY_HOURS,
            'send_window_start' => (string)KUMO_SEND_WINDOW_START,
            'send_window_end'   => (string)KUMO_SEND_WINDOW_END,
            'spamhaus_dqs_key'  => '',
            'alert_emails'      => '',
            'warmup_auto'       => '1',
            /* Honour the panel's existing Netcore blocklist at send time. On by
               default — someone who unsubscribed there must not start receiving
               mail again just because this platform is new. Read-only. */
            'honour_netcore_blocklist' => '1',
        ];
        foreach ($defaults as $k => $v) {
            $ks = $conn->real_escape_string($k);
            $vs = $conn->real_escape_string($v);
            $conn->query("INSERT IGNORE INTO kumo_settings (k, v) VALUES ('$ks', '$vs')");
        }
    } catch (\Throwable $e) {
        error_log('kumo_seed_defaults: ' . $e->getMessage());
    }
}

/* ── Small helpers used everywhere in this module ────────────────────────── */

function kumo_setting(string $key, $default = null) {
    global $conn;
    static $cache = null;
    if ($cache === null) {
        $cache = [];
        try {
            $r = $conn->query("SELECT k, v FROM kumo_settings");
            while ($r && $row = $r->fetch_assoc()) $cache[$row['k']] = $row['v'];
        } catch (\Throwable $e) { /* table not there yet */ }
    }
    $v = $cache[$key] ?? null;
    return ($v === null || $v === '') ? $default : $v;
}

function kumo_set_setting(string $key, string $val): void {
    global $conn;
    $k = $conn->real_escape_string($key);
    $v = $conn->real_escape_string($val);
    $conn->query("INSERT INTO kumo_settings (k, v) VALUES ('$k','$v') ON DUPLICATE KEY UPDATE v=VALUES(v)");
}

/** Mailbox provider bucket for a recipient address — used for per-provider stats. */
function kumo_provider_of(string $email): string {
    $d = strtolower(substr(strrchr($email, '@') ?: '', 1));
    if ($d === '') return 'other';
    if (preg_match('/(^|\.)(gmail|googlemail)\.com$/', $d))                 return 'gmail';
    if (preg_match('/(^|\.)(outlook|hotmail|live|msn)\./', $d) || $d === 'outlook.com' || $d === 'hotmail.com' || $d === 'live.com') return 'outlook';
    if (preg_match('/(^|\.)(yahoo|ymail|rocketmail)\./', $d) || strpos($d, 'yahoo.') === 0) return 'yahoo';
    if (preg_match('/(^|\.)(icloud|me|mac)\.com$/', $d))                    return 'apple';
    if (preg_match('/(^|\.)(rediffmail|rediff)\.com$/', $d))                return 'rediff';
    return 'other';
}

/** 32-hex correlation id carried end-to-end (X-Message-Ref → webhook → events). */
function kumo_rid(): string {
    return bin2hex(random_bytes(16));
}

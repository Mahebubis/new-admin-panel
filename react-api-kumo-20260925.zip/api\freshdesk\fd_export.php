<?php
/*
 * /api/freshdesk/fd_export.php
 *
 * "How much mail do we actually hold, and can I have all of it as a sheet?"
 *
 *   action=coverage            -> what this desk HAS: first/last email, totals,
 *                                 a month-by-month and year-by-year histogram
 *   action=mailbox  [&years=6] -> what the IMAP MAILBOX has, counted over IMAP
 *                                 without importing anything (slow: it talks to
 *                                 the mail server, so it is never auto-loaded)
 *   action=range    &from &to  -> paged list + counts of every email in a window
 *   action=csv      &from &to  -> the same window streamed as a CSV download
 *
 * WHY THIS IS A SEPARATE FILE FROM fd_stats.php
 * fd_stats answers "how is the desk doing right now" and is polled. This answers
 * "what is in the archive" -- unbounded scans and a download that must not be
 * wrapped in the {success,data} envelope. Mixing the two means one careless
 * ob_start() in the stats path corrupts a 40MB CSV.
 *
 * THE DISTINCTION THAT MATTERS WHEN READING THESE NUMBERS
 * `coverage` counts rows in fd_messages -- mail this desk IMPORTED. `mailbox`
 * counts messages sitting in contact@internshipstudio.com over IMAP. They are
 * not the same number and are not supposed to be: fd_sync.php baselines a fresh
 * mailbox with SYNC_INITIAL_DAYS (7 by default) and only ever walks FORWARD from
 * its watermark, so anything older than the day the desk went live was never
 * imported. Showing both side by side is the point -- it is the only way to see
 * that gap instead of guessing at it.
 */

require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../middleware/auth.php';
require_once __DIR__ . '/lib/config.php';
require_once __DIR__ . '/lib/Helpers.php';
require_once __DIR__ . '/lib/schema.php';

$jwt = require_jwt();
require_permission('freshdesk', $jwt);
fd_install_error_handlers();
fd_ensure_schema();

/*
 * The canonical date of an email.
 *
 * message_date is the Date: header -- when the human actually sent it. It is
 * NULL on the rare message with no Date: header and on rows this desk created
 * itself, so created_at is the fallback. Ordering or bucketing on created_at
 * alone would date every imported message to the day of the import, which is
 * exactly the question this endpoint exists to answer honestly.
 */
define('FD_EXP_DATE', 'COALESCE(m.message_date, m.created_at)');

/* A CSV nobody can open is not a safer CSV. This is a guard against a runaway
   scan, not a product limit; the UI reports when it is reached. */
if (!defined('FD_EXPORT_MAX_ROWS')) define('FD_EXPORT_MAX_ROWS', 200000);
/* Rows pulled per round trip while streaming. Keyset-paged, so this is a memory
   ceiling and nothing else. */
if (!defined('FD_EXPORT_CHUNK')) define('FD_EXPORT_CHUNK', 1000);

$action = fd_str('action', 'coverage');
$GLOBALS['FD_ACTION'] = $action;

/* ========================================================== filter build == */

/**
 * Turn the request's filters into a WHERE fragment over fd_messages m
 * (joined to fd_tickets t), plus its bind types and params.
 *
 * Spam and trash are EXCLUDED by default and includable by flag: an archive
 * export that silently drops 400 messages is worse than one that labels them.
 */
function fd_exp_filters()
{
    $from   = fd_str('from', '');
    $to     = fd_str('to', '');
    $dir    = fd_str('direction', 'all');
    $search = fd_str('search', '');
    $withSpam  = fd_bool('include_spam', false);
    $withTrash = fd_bool('include_trash', false);

    $where  = array('1=1');
    $types  = '';
    $params = array();

    // Dates arrive as YYYY-MM-DD and are treated as whole days in server time:
    // `to` is inclusive, which is what "1 Jan to 31 Jan" means to everyone who
    // is not writing the query.
    if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $from)) {
        $where[] = FD_EXP_DATE . ' >= ?';
        $types  .= 's';
        $params[] = $from . ' 00:00:00';
    }
    if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $to)) {
        $where[] = FD_EXP_DATE . ' < ?';
        $types  .= 's';
        $params[] = date('Y-m-d 00:00:00', strtotime($to . ' +1 day'));
    }

    if (in_array($dir, array('inbound', 'outbound', 'note'), true)) {
        $where[] = 'm.direction = ?';
        $types  .= 's';
        $params[] = $dir;
    }

    if ($search !== '') {
        // Subject / address / sender name only. Deliberately NOT the bodies:
        // a LIKE over two LONGTEXT columns across the whole archive is a table
        // scan that reads every megabyte of every email ever received.
        $where[] = '(m.subject LIKE ? OR m.from_email LIKE ? OR m.from_name LIKE ? OR m.to_emails LIKE ?)';
        $like = '%' . $search . '%';
        $types .= 'ssss';
        $params[] = $like; $params[] = $like; $params[] = $like; $params[] = $like;
    }

    if (!$withSpam)  $where[] = 't.is_spam = 0';
    if (!$withTrash) $where[] = 't.is_trash = 0';

    return array(
        'sql'    => implode(' AND ', $where),
        'types'  => $types,
        'params' => $params,
        'meta'   => array('from' => $from, 'to' => $to, 'direction' => $dir, 'search' => $search),
    );
}

/** FROM + JOIN shared by every query here, so they cannot drift apart. */
function fd_exp_from()
{
    return ' FROM fd_messages m LEFT JOIN fd_tickets t ON t.id = m.ticket_id ';
}

/* ============================================================== coverage == */
/*
 * Everything needed to answer "do we have a year of history, or a week?" in one
 * round trip. The month histogram is the honest version of that answer: a
 * single first/last pair cannot show that the middle is empty.
 */
if ($action === 'coverage') {

    $totals = fd_query_one(
        "SELECT COUNT(*) AS total,
                SUM(m.direction = 'inbound')  AS inbound,
                SUM(m.direction = 'outbound') AS outbound,
                SUM(m.direction = 'note')     AS notes,
                SUM(m.has_attachments = 1)    AS with_attachments,
                MIN(" . FD_EXP_DATE . ")      AS first_at,
                MAX(" . FD_EXP_DATE . ")      AS last_at,
                COUNT(DISTINCT m.ticket_id)   AS tickets,
                COUNT(DISTINCT LOWER(m.from_email)) AS senders"
        . fd_exp_from() . " WHERE t.is_trash = 0 AND t.is_spam = 0"
    );

    // Counted separately rather than filtered out above: "and 312 of them are
    // spam" is information, not noise.
    $hidden = fd_query_one(
        "SELECT SUM(t.is_spam = 1) AS spam, SUM(t.is_trash = 1) AS trash"
        . fd_exp_from() . " WHERE t.is_spam = 1 OR t.is_trash = 1"
    );

    $months = fd_query(
        "SELECT DATE_FORMAT(" . FD_EXP_DATE . ", '%Y-%m') AS ym,
                COUNT(*) AS total,
                SUM(m.direction = 'inbound')  AS inbound,
                SUM(m.direction = 'outbound') AS outbound"
        . fd_exp_from() . " WHERE t.is_trash = 0 AND t.is_spam = 0
         GROUP BY ym ORDER BY ym ASC"
    );

    $out = array();
    foreach ($months as $r) {
        $ts = strtotime($r['ym'] . '-01');
        $out[] = array(
            'month'    => $r['ym'],
            'label'    => date('M Y', $ts),
            'total'    => (int)$r['total'],
            'inbound'  => (int)$r['inbound'],
            'outbound' => (int)$r['outbound'],
        );
    }

    $years = array();
    foreach ($out as $m) {
        $y = substr($m['month'], 0, 4);
        if (!isset($years[$y])) $years[$y] = 0;
        $years[$y] += $m['total'];
    }
    $yearRows = array();
    foreach ($years as $y => $c) $yearRows[] = array('year' => (int)$y, 'total' => $c);

    $tickets = fd_query_one(
        "SELECT COUNT(*) AS total, MIN(created_at) AS first_at, MAX(created_at) AS last_at
         FROM fd_tickets WHERE is_trash = 0 AND is_spam = 0 AND merged_into IS NULL"
    );

    $folder = fd_cfg('IMAP_FOLDER', FD_IMAP_FOLDER);
    $state = fd_query_one("SELECT mailbox, last_uid, uidvalidity, last_sync_at, last_success_at,
                                  last_status, imported_total, consecutive_fails
                           FROM fd_mailbox_state WHERE mailbox = ?", 's', array($folder));

    $firstAt = $totals ? $totals['first_at'] : null;
    $lastAt  = $totals ? $totals['last_at']  : null;

    api_success(array(
        'mailbox'  => fd_cfg('IMAP_USER', FD_IMAP_USER),
        'folder'   => $folder,
        'messages' => array(
            'total'            => $totals ? (int)$totals['total'] : 0,
            'inbound'          => $totals ? (int)$totals['inbound'] : 0,
            'outbound'         => $totals ? (int)$totals['outbound'] : 0,
            'notes'            => $totals ? (int)$totals['notes'] : 0,
            'with_attachments' => $totals ? (int)$totals['with_attachments'] : 0,
            'senders'          => $totals ? (int)$totals['senders'] : 0,
            'first_at'         => $firstAt,
            'last_at'          => $lastAt,
            // The span the archive actually covers, in days. This is the number
            // the "1 year or less?" question is really asking for.
            'span_days'        => ($firstAt && $lastAt)
                                  ? (int)floor((strtotime($lastAt) - strtotime($firstAt)) / 86400) + 1 : 0,
        ),
        'hidden'   => array(
            'spam'  => $hidden ? (int)$hidden['spam'] : 0,
            'trash' => $hidden ? (int)$hidden['trash'] : 0,
        ),
        'tickets'  => array(
            'total'    => $tickets ? (int)$tickets['total'] : 0,
            'first_at' => $tickets ? $tickets['first_at'] : null,
            'last_at'  => $tickets ? $tickets['last_at'] : null,
        ),
        'months'   => $out,
        'years'    => $yearRows,
        'sync'     => $state ? array(
            'last_uid'        => (int)$state['last_uid'],
            'last_sync_at'    => $state['last_sync_at'],
            'last_success_at' => $state['last_success_at'],
            'last_status'     => $state['last_status'],
            'imported_total'  => (int)$state['imported_total'],
        ) : null,
        // Surfaced so the UI can explain the gap rather than leave the operator
        // to discover the baseline window by reading PHP.
        'initial_days' => (int)fd_cfg_int('SYNC_INITIAL_DAYS', 7),
    ));
}

/* =============================================================== mailbox == */
/*
 * What the MAIL SERVER holds, counted over IMAP, importing nothing.
 *
 * One `UID SEARCH SINCE x BEFORE y` per year plus one open-ended `BEFORE` for
 * everything older. SEARCH returns UIDs, not bodies, so even a 40k-message
 * mailbox is a handful of short round trips -- but they are round trips to a
 * shared cPanel mail server, so this runs only when an operator asks for it.
 */
if ($action === 'mailbox') {
    require_once __DIR__ . '/lib/ImapClient.php';

    $years  = max(1, min(15, fd_int('years', 6)));
    $folder = fd_str('folder', fd_cfg('IMAP_FOLDER', FD_IMAP_FOLDER));

    $imap = null;
    try {
        $imap = new ImapClient();
        $imap->login();
        $info = $imap->selectFolder($folder, true);

        $thisYear = (int)date('Y');
        $oldest   = $thisYear - $years + 1;

        $buckets = array();
        for ($y = $oldest; $y <= $thisYear; $y++) {
            $uids = $imap->searchDateRange('01-Jan-' . $y, '01-Jan-' . ($y + 1));
            $buckets[] = array('year' => $y, 'total' => count($uids));
        }

        // Everything older than the window we itemised, as one number.
        $older = count($imap->searchDateRange(null, '01-Jan-' . $oldest));

        $total   = (int)$info['exists'];
        $counted = $older;
        foreach ($buckets as $b) $counted += $b['total'];

        $imap->close();

        api_success(array(
            'mailbox' => fd_cfg('IMAP_USER', FD_IMAP_USER),
            'folder'  => $folder,
            'exists'  => $total,
            'years'   => $buckets,
            'older'   => array('before' => $oldest, 'total' => $older),
            /*
             * EXISTS and the sum of the date buckets can legitimately disagree:
             * SEARCH matches on INTERNALDATE, and a message whose internal date
             * falls outside the itemised years still counts towards EXISTS.
             * Reported rather than reconciled, so a mismatch stays visible.
             */
            'counted' => $counted,
            'note'    => ($counted === $total) ? ''
                         : 'IMAP reports ' . $total . ' message(s) in the folder; the date buckets account for '
                           . $counted . '.',
        ), 'Mailbox scanned');
    } catch (Exception $e) {
        if ($imap) { try { $imap->close(); } catch (Exception $e2) { /* already gone */ } }
        api_error('Could not read the mailbox over IMAP: ' . $e->getMessage(), 502);
    }
}

/* ================================================================= range == */
/*
 * The date-range list: counts first, then one page of rows.
 *
 * Counts are a separate query on purpose. The UI shows "4,812 emails" above a
 * 50-row page, and deriving that from the page would be a lie that looks right.
 */
if ($action === 'range') {
    $f = fd_exp_filters();
    $page    = max(1, fd_int('page', 1));
    $perPage = max(1, min(200, fd_int('per_page', 50)));
    $offset  = ($page - 1) * $perPage;

    $summary = fd_query_one(
        "SELECT COUNT(*) AS total,
                SUM(m.direction = 'inbound')  AS inbound,
                SUM(m.direction = 'outbound') AS outbound,
                SUM(m.direction = 'note')     AS notes,
                SUM(m.has_attachments = 1)    AS with_attachments,
                COUNT(DISTINCT m.ticket_id)   AS tickets,
                COUNT(DISTINCT LOWER(m.from_email)) AS senders,
                MIN(" . FD_EXP_DATE . ") AS first_at,
                MAX(" . FD_EXP_DATE . ") AS last_at"
        . fd_exp_from() . " WHERE " . $f['sql'],
        $f['types'], $f['params']
    );

    $total = $summary ? (int)$summary['total'] : 0;

    $rows = fd_query(
        "SELECT m.id, m.ticket_id, m.direction, m.msg_type, m.from_name, m.from_email,
                m.to_emails, m.subject, m.snippet, m.has_attachments, m.attachment_count,
                m.delivery_status, m.sent_by_name, " . FD_EXP_DATE . " AS sent_at,
                t.status AS ticket_status, t.priority, t.category, t.agent_name,
                t.is_spam, t.is_trash"
        . fd_exp_from() . " WHERE " . $f['sql'] . "
         ORDER BY sent_at DESC, m.id DESC LIMIT ? OFFSET ?",
        $f['types'] . 'ii', array_merge($f['params'], array($perPage, $offset))
    );

    $out = array();
    foreach ($rows as $r) {
        $to = json_decode($r['to_emails'] ? $r['to_emails'] : '[]', true);
        if (!is_array($to)) $to = array();
        $out[] = array(
            'id'          => (int)$r['id'],
            'ticket_id'   => (int)$r['ticket_id'],
            'direction'   => $r['direction'],
            'type'        => $r['msg_type'],
            'from_name'   => $r['from_name'],
            'from_email'  => $r['from_email'],
            'to'          => implode(', ', $to),
            'subject'     => $r['subject'],
            'snippet'     => $r['snippet'],
            'sent_at'     => $r['sent_at'],
            'ago'         => fd_relative_time($r['sent_at']),
            'attachments' => (int)$r['attachment_count'],
            'delivery'    => $r['delivery_status'],
            'agent'       => $r['direction'] === 'inbound'
                             ? $r['agent_name']
                             : ($r['sent_by_name'] ? $r['sent_by_name'] : $r['agent_name']),
            'status'      => $r['ticket_status'],
            'priority'    => $r['priority'],
            'category'    => $r['category'],
            'spam'        => (int)$r['is_spam'] === 1,
            'trash'       => (int)$r['is_trash'] === 1,
        );
    }

    api_success(array(
        'rows'     => $out,
        'page'     => $page,
        'per_page' => $perPage,
        'total'    => $total,
        'pages'    => (int)ceil($total / $perPage),
        'summary'  => array(
            'total'            => $total,
            'inbound'          => $summary ? (int)$summary['inbound'] : 0,
            'outbound'         => $summary ? (int)$summary['outbound'] : 0,
            'notes'            => $summary ? (int)$summary['notes'] : 0,
            'with_attachments' => $summary ? (int)$summary['with_attachments'] : 0,
            'tickets'          => $summary ? (int)$summary['tickets'] : 0,
            'senders'          => $summary ? (int)$summary['senders'] : 0,
            'first_at'         => $summary ? $summary['first_at'] : null,
            'last_at'          => $summary ? $summary['last_at'] : null,
        ),
        'filters'  => $f['meta'],
    ));
}

/* =================================================================== csv == */
/*
 * The whole selection as one sheet.
 *
 * Streamed in keyset-paged chunks (WHERE id > last), never with one big SELECT:
 * a 40k-row export built in PHP memory first is how an export endpoint turns
 * into a 500 with no body. Keyset rather than LIMIT/OFFSET because the offset
 * walk re-reads everything it already skipped, and because the primary key
 * needs no filesort at all.
 *
 * Row order is therefore fd_messages.id ascending -- the order the desk recorded
 * them, which for IMAP import is ascending arrival. The sheet carries a real
 * Date column, so re-sorting in Excel is one click for anyone who wants strict
 * Date: header order.
 */
if ($action === 'csv') {
    $f    = fd_exp_filters();
    $what = fd_str('format', 'emails');

    // Downloads must not inherit a JSON buffer, an ob_gzhandler, or the
    // Content-Type the rest of the API sets.
    while (ob_get_level() > 0) { ob_end_clean(); }
    header_remove('Content-Type');
    @set_time_limit(300);

    $stamp = date('Y-m-d');
    $span  = ($f['meta']['from'] !== '' || $f['meta']['to'] !== '')
             ? ($f['meta']['from'] !== '' ? $f['meta']['from'] : 'start')
               . '_to_' . ($f['meta']['to'] !== '' ? $f['meta']['to'] : $stamp)
             : 'all-time';

    header('Content-Type: text/csv; charset=UTF-8');
    header('Content-Disposition: attachment; filename="internshipstudio-' . $what . '-' . $span . '.csv"');
    header('Cache-Control: no-store');
    header('X-Accel-Buffering: no');   // nginx in front of PHP-FPM buffers otherwise

    // Excel reads a UTF-8 CSV as the system codepage unless it sees a BOM, which
    // turns every non-ASCII name and subject into mojibake on the most common
    // consumer of this file.
    echo "\xEF\xBB\xBF";
    $out = fopen('php://output', 'w');

    if ($what === 'tickets') {
        fputcsv($out, array('Ticket', 'Subject', 'Customer', 'Email', 'Phone', 'Status', 'Priority',
                            'Category', 'Department', 'Source', 'Agent', 'Messages', 'Attachments',
                            'SLA', 'Created', 'Last Message', 'First Response', 'Resolved', 'Closed'));

        // The ticket sheet filters on the ticket's own created_at -- fd_exp_filters()
        // is written against fd_messages and does not apply here.
        $tWhere = array('1=1'); $tTypes = ''; $tParams = array();
        if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $f['meta']['from'])) {
            $tWhere[] = 'created_at >= ?'; $tTypes .= 's'; $tParams[] = $f['meta']['from'] . ' 00:00:00';
        }
        if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $f['meta']['to'])) {
            $tWhere[] = 'created_at < ?'; $tTypes .= 's';
            $tParams[] = date('Y-m-d 00:00:00', strtotime($f['meta']['to'] . ' +1 day'));
        }
        if (!fd_bool('include_spam', false))  $tWhere[] = 'is_spam = 0';
        if (!fd_bool('include_trash', false)) $tWhere[] = 'is_trash = 0';
        $tSql = implode(' AND ', $tWhere);

        $lastId = 0; $written = 0;
        while ($written < FD_EXPORT_MAX_ROWS) {
            $rows = fd_query(
                "SELECT id, subject, requester_name, requester_email, requester_phone, status, priority,
                        category, department, source, agent_name, message_count, attachment_count,
                        sla_status, created_at, last_message_at, first_response_at, resolved_at, closed_at
                 FROM fd_tickets WHERE $tSql AND id > ? ORDER BY id ASC LIMIT " . FD_EXPORT_CHUNK,
                $tTypes . 'i', array_merge($tParams, array($lastId))
            );
            if (empty($rows)) break;
            foreach ($rows as $r) {
                fputcsv($out, array(
                    $r['id'], $r['subject'], $r['requester_name'], $r['requester_email'], $r['requester_phone'],
                    $r['status'], $r['priority'], $r['category'], $r['department'], $r['source'], $r['agent_name'],
                    $r['message_count'], $r['attachment_count'], $r['sla_status'],
                    $r['created_at'], $r['last_message_at'], $r['first_response_at'], $r['resolved_at'], $r['closed_at'],
                ));
                $lastId = (int)$r['id'];
                $written++;
            }
            fflush($out);
            flush();
        }
    } else {
        fputcsv($out, array('Date', 'Time', 'Direction', 'Type', 'Ticket', 'Subject',
                            'From Name', 'From Email', 'To', 'Cc', 'Ticket Status', 'Priority',
                            'Category', 'Agent', 'Delivery', 'Attachments', 'Message ID', 'Preview'));

        $lastId = 0; $written = 0;
        while ($written < FD_EXPORT_MAX_ROWS) {
            $rows = fd_query(
                "SELECT m.id, m.ticket_id, m.direction, m.msg_type, m.from_name, m.from_email,
                        m.to_emails, m.cc_emails, m.subject, m.snippet, m.attachment_count,
                        m.delivery_status, m.sent_by_name, m.message_id, " . FD_EXP_DATE . " AS sent_at,
                        t.status AS ticket_status, t.priority, t.category, t.agent_name"
                . fd_exp_from() . " WHERE " . $f['sql'] . " AND m.id > ?
                 ORDER BY m.id ASC LIMIT " . FD_EXPORT_CHUNK,
                $f['types'] . 'i', array_merge($f['params'], array($lastId))
            );
            if (empty($rows)) break;
            foreach ($rows as $r) {
                $to = json_decode($r['to_emails'] ? $r['to_emails'] : '[]', true);
                $cc = json_decode($r['cc_emails'] ? $r['cc_emails'] : '[]', true);
                $ts = $r['sent_at'] ? strtotime($r['sent_at']) : 0;
                fputcsv($out, array(
                    $ts ? date('Y-m-d', $ts) : '',
                    $ts ? date('H:i:s', $ts) : '',
                    $r['direction'], $r['msg_type'], $r['ticket_id'], $r['subject'],
                    $r['from_name'], $r['from_email'],
                    is_array($to) ? implode('; ', $to) : '',
                    is_array($cc) ? implode('; ', $cc) : '',
                    $r['ticket_status'], $r['priority'], $r['category'],
                    $r['direction'] === 'inbound' ? $r['agent_name'] : ($r['sent_by_name'] ? $r['sent_by_name'] : $r['agent_name']),
                    $r['delivery_status'], $r['attachment_count'], $r['message_id'],
                    // Newlines inside a CSV cell are legal and quoted correctly by
                    // fputcsv, but they make the sheet unreadable one row at a time.
                    trim(preg_replace('/\s+/u', ' ', (string)$r['snippet'])),
                ));
                $lastId = (int)$r['id'];
                $written++;
            }
            fflush($out);
            flush();
        }
    }

    fclose($out);
    exit;
}

api_error('Unknown action: ' . $action, 400);

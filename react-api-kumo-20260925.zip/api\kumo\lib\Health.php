<?php
/*
 * Health — the red / yellow / green engine, the warmup ladder and the
 * blocklist / reverse-DNS probes.
 *
 * Rules (all thresholds live in kumo_settings and are editable in the UI):
 *   • An IP is scored on its WORST signal over the last 24 hours.
 *   • Moving UP a colour needs `recovery_hours` consecutive healthy scoring
 *     runs — this stops an IP flapping green/yellow every hour.
 *   • RED pauses the IP immediately and raises a critical alert. A red IP is
 *     never resumed automatically; a human clicks Resume (KUMO_RED_NEEDS_MANUAL).
 *   • Warmup only advances a day when the IP finished yesterday green.
 */

require_once __DIR__ . '/schema.php';
require_once __DIR__ . '/Stats.php';
require_once __DIR__ . '/KumoClient.php';

function kumo_thresholds(): array {
    return [
        'bounce_yellow'    => (float)kumo_setting('th_bounce_yellow',    KUMO_TH_BOUNCE_YELLOW),
        'bounce_red'       => (float)kumo_setting('th_bounce_red',       KUMO_TH_BOUNCE_RED),
        'complaint_yellow' => (float)kumo_setting('th_complaint_yellow', KUMO_TH_COMPLAINT_YELLOW),
        'complaint_red'    => (float)kumo_setting('th_complaint_red',    KUMO_TH_COMPLAINT_RED),
        'deferral_yellow'  => (float)kumo_setting('th_deferral_yellow',  KUMO_TH_DEFERRAL_YELLOW),
        'deferral_red'     => (float)kumo_setting('th_deferral_red',     KUMO_TH_DEFERRAL_RED),
        'recovery_hours'   => (int)  kumo_setting('recovery_hours',      KUMO_RECOVERY_HOURS),
    ];
}

/** Raise an operational alert (dedup: same title for the same IP within an hour). */
function kumo_alert(string $level, string $title, string $body = '', ?int $ipId = null, ?int $campaignId = null): void {
    global $conn;
    try {
        $tE = $conn->real_escape_string($title);
        $where = "title = '$tE' AND created_at >= DATE_SUB(NOW(), INTERVAL 1 HOUR)";
        if ($ipId) $where .= ' AND ip_id = ' . (int)$ipId;
        $r = $conn->query("SELECT id FROM kumo_alerts WHERE $where LIMIT 1");
        if ($r && $r->fetch_assoc()) return;

        $conn->query(sprintf(
            "INSERT INTO kumo_alerts (level, ip_id, campaign_id, title, body) VALUES ('%s', %s, %s, '%s', '%s')",
            in_array($level, ['info','warn','critical'], true) ? $level : 'info',
            $ipId ? (int)$ipId : 'NULL',
            $campaignId ? (int)$campaignId : 'NULL',
            $tE, $conn->real_escape_string($body)
        ));
    } catch (\Throwable $e) { error_log('kumo_alert: ' . $e->getMessage()); }
}

/** Last-24h counters for one IP, straight off the hourly rollup. */
function kumo_ip_last24(int $ipId): array {
    global $conn;
    $row = ['sent'=>0,'delivered'=>0,'deferred'=>0,'bounced'=>0,'complaints'=>0,'opens'=>0,'clicks'=>0,'unsubs'=>0];
    try {
        $r = $conn->query("SELECT COALESCE(SUM(sent),0) sent, COALESCE(SUM(delivered),0) delivered,
                COALESCE(SUM(deferred),0) deferred, COALESCE(SUM(bounced),0) bounced,
                COALESCE(SUM(complaints),0) complaints, COALESCE(SUM(opens),0) opens,
                COALESCE(SUM(clicks),0) clicks, COALESCE(SUM(unsubs),0) unsubs
            FROM kumo_ip_stats WHERE ip_id = " . (int)$ipId . " AND bucket >= DATE_SUB(NOW(), INTERVAL 24 HOUR)");
        if ($r && $x = $r->fetch_assoc()) $row = array_map('intval', $x);
    } catch (\Throwable $e) { error_log('kumo_ip_last24: ' . $e->getMessage()); }
    return kumo_with_ratios($row);
}

/**
 * Score one IP. Returns [color, reasons[], metrics].
 * `unknown` (not green) is used while an IP has sent too little to judge —
 * the UI shows it grey and warmup still runs.
 */
function kumo_score_ip(array $ip): array {
    $th = kumo_thresholds();
    $m  = kumo_ip_last24((int)$ip['id']);
    $reasons = [];
    $color   = 'green';

    $worse = function (string $c) use (&$color) {
        $rank = ['green' => 0, 'yellow' => 1, 'red' => 2];
        if ($rank[$c] > $rank[$color]) $color = $c;
    };

    if ((int)$ip['blocklisted'] === 1) { $worse('red'); $reasons[] = 'Listed on a blocklist: ' . ($ip['blocklist_note'] ?: 'see IP detail'); }
    if ((int)$ip['ptr_ok'] !== 1)      { $worse('yellow'); $reasons[] = 'Reverse DNS does not match ' . ($ip['hostname'] ?: 'its hostname'); }

    $sent = (int)$m['sent'];
    if ($sent < 50) {
        /*
         * Not enough traffic to judge the rates. If nothing structural is wrong
         * (reverse DNS resolves, no blocklist), report 'unknown' — grey, "no
         * data" — rather than carrying yesterday's colour forward. An earlier
         * version kept the previous colour here, which meant an IP that went
         * yellow for a missing PTR record stayed yellow for ever once the PTR
         * was fixed, because with no sends the rate checks never ran again.
         */
        if ($color === 'green' && (int)$ip['blocklisted'] !== 1 && (int)$ip['ptr_ok'] === 1) {
            return ['color' => 'unknown', 'reasons' => ['Too few sends in the last 24h to score (' . $sent . ')'], 'metrics' => $m];
        }
        $reasons[] = 'Only ' . $sent . ' sends in the last 24h';
    } else {
        if ($m['bounce_rate'] >= $th['bounce_red'])          { $worse('red');    $reasons[] = 'Hard bounce rate ' . $m['bounce_rate'] . '% (red ≥ ' . $th['bounce_red'] . '%)'; }
        elseif ($m['bounce_rate'] >= $th['bounce_yellow'])   { $worse('yellow'); $reasons[] = 'Hard bounce rate ' . $m['bounce_rate'] . '%'; }

        if ($m['complaint_rate'] >= $th['complaint_red'])        { $worse('red');    $reasons[] = 'Complaint rate ' . $m['complaint_rate'] . '% (red ≥ ' . $th['complaint_red'] . '%)'; }
        elseif ($m['complaint_rate'] >= $th['complaint_yellow']) { $worse('yellow'); $reasons[] = 'Complaint rate ' . $m['complaint_rate'] . '%'; }

        if ($m['deferral_rate'] >= $th['deferral_red'])        { $worse('red');    $reasons[] = 'Deferral rate ' . $m['deferral_rate'] . '% (red ≥ ' . $th['deferral_red'] . '%)'; }
        elseif ($m['deferral_rate'] >= $th['deferral_yellow']) { $worse('yellow'); $reasons[] = 'Deferral rate ' . $m['deferral_rate'] . '%'; }
    }

    if (!$reasons) $reasons[] = 'All signals within limits';
    return ['color' => $color, 'reasons' => $reasons, 'metrics' => $m];
}

/**
 * Score every IP, apply hysteresis, auto-pause reds, write history + alerts.
 * Called by the health worker (hourly) and by the dashboard's Refresh button.
 */
function kumo_health_tick(): array {
    global $conn;
    $th      = kumo_thresholds();
    $summary = ['scored' => 0, 'green' => 0, 'yellow' => 0, 'red' => 0, 'unknown' => 0, 'paused' => []];

    $ips = [];
    try {
        $r = $conn->query("SELECT * FROM kumo_ips WHERE status <> 'retired'");
        while ($r && $x = $r->fetch_assoc()) $ips[] = $x;
    } catch (\Throwable $e) { error_log('kumo_health_tick: ' . $e->getMessage()); return $summary; }

    $rank = ['unknown' => 0, 'red' => 1, 'yellow' => 2, 'green' => 3];

    foreach ($ips as $ip) {
        $id      = (int)$ip['id'];
        $scored  = kumo_score_ip($ip);
        $target  = $scored['color'];
        $current = $ip['health'] ?: 'unknown';
        $good    = (int)$ip['good_hours'];

        /* Hysteresis: dropping is immediate, climbing needs N consecutive good runs. */
        $final = $target;
        if (isset($rank[$target], $rank[$current]) && $rank[$target] > $rank[$current] && $current !== 'unknown') {
            $good++;
            if ($good < max(1, $th['recovery_hours'])) $final = $current;   // hold
            else $good = 0;
        } else {
            $good = 0;
        }

        /* A red IP stops sending straight away. */
        $status       = $ip['status'];
        $pausedReason = $ip['paused_reason'];
        if ($final === 'red' && $status === 'active') {
            $status       = 'paused';
            $pausedReason = 'Auto-paused: ' . implode(' · ', $scored['reasons']);
            $summary['paused'][] = $ip['ip'];
            kumo_alert('critical', 'IP ' . $ip['ip'] . ' turned RED and was paused', implode("\n", $scored['reasons']), $id);
        } elseif ($final === 'yellow' && $current !== 'yellow') {
            kumo_alert('warn', 'IP ' . $ip['ip'] . ' is YELLOW', implode("\n", $scored['reasons']), $id);
        }

        $m = $scored['metrics'];
        try {
            $conn->query(sprintf(
                "UPDATE kumo_ips SET health='%s', health_reason='%s', good_hours=%d, status='%s',
                    paused_reason=%s, paused_at=%s, paused_by=%s, last_health_at=NOW() WHERE id=%d",
                $conn->real_escape_string($final),
                $conn->real_escape_string(implode(' · ', $scored['reasons'])),
                $good,
                $conn->real_escape_string($status),
                $pausedReason === null ? 'NULL' : "'" . $conn->real_escape_string($pausedReason) . "'",
                ($status === 'paused' && $ip['status'] !== 'paused') ? 'NOW()' : ($ip['paused_at'] ? "'" . $conn->real_escape_string($ip['paused_at']) . "'" : 'NULL'),
                ($status === 'paused' && $ip['status'] !== 'paused') ? "'system'" : ($ip['paused_by'] ? "'" . $conn->real_escape_string($ip['paused_by']) . "'" : 'NULL'),
                $id
            ));
            $conn->query(sprintf(
                "INSERT INTO kumo_ip_health (ip_id, checked_at, color, sent_24h, bounce_rate, complaint_rate, deferral_rate, delivery_rate, reasons)
                 VALUES (%d, NOW(), '%s', %d, %.3f, %.3f, %.3f, %.3f, '%s')",
                $id, $conn->real_escape_string($final), (int)$m['sent'],
                (float)$m['bounce_rate'], (float)$m['complaint_rate'], (float)$m['deferral_rate'], (float)$m['delivery_rate'],
                $conn->real_escape_string(implode(' · ', $scored['reasons']))
            ));
        } catch (\Throwable $e) { error_log('kumo_health_tick update: ' . $e->getMessage()); }

        $summary['scored']++;
        $summary[$final] = ($summary[$final] ?? 0) + 1;
    }

    /* Everything red at once means stop the world. */
    if ($summary['scored'] > 0 && $summary['red'] === $summary['scored']) {
        kumo_alert('critical', 'All sending IPs are RED', 'Every IP failed its health check — all campaigns are effectively stopped.');
    }
    return $summary;
}

/* ── Warmup ────────────────────────────────────────────────────────────────── */

function kumo_warmup_cap_for_day(int $day): int {
    global $conn;
    try {
        $r = $conn->query("SELECT daily_cap FROM kumo_warmup_plan WHERE $day BETWEEN day_from AND day_to ORDER BY day_from DESC LIMIT 1");
        if ($r && $x = $r->fetch_assoc()) return (int)$x['daily_cap'];
    } catch (\Throwable $e) { error_log('kumo_warmup_cap_for_day: ' . $e->getMessage()); }
    return 500;
}

/**
 * Sets today's cap for every IP. Called once a day (and harmlessly again on
 * every worker tick, because it is an upsert of the same value).
 *
 *   green yesterday  → advance one warmup day
 *   yellow yesterday → hold the day, and halve today's cap
 *   red              → the IP is paused anyway; its cap is 0
 */
function kumo_warmup_tick(): array {
    global $conn;
    $today  = date('Y-m-d');
    $out    = ['updated' => 0, 'rows' => []];
    $auto   = kumo_setting('warmup_auto', '1') === '1';

    try {
        $r = $conn->query("SELECT * FROM kumo_ips WHERE status <> 'retired'");
        $ips = [];
        while ($r && $x = $r->fetch_assoc()) $ips[] = $x;

        foreach ($ips as $ip) {
            $id = (int)$ip['id'];

            /* Already written today? Then only refresh the cap, never the day. */
            $have = null;
            $q = $conn->query("SELECT * FROM kumo_ip_daily WHERE ip_id=$id AND day='$today' LIMIT 1");
            if ($q && $x = $q->fetch_assoc()) $have = $x;

            $day = max(1, (int)$ip['warmup_day']);
            if ($auto && (int)$ip['warmup_enabled'] === 1 && !$have) {
                /* Yesterday's colour decides whether we move up a rung. */
                $yesterdayColor = null;
                $q2 = $conn->query("SELECT color FROM kumo_ip_health WHERE ip_id=$id AND checked_at >= DATE_SUB(CURDATE(), INTERVAL 1 DAY) AND checked_at < CURDATE() ORDER BY id DESC LIMIT 1");
                if ($q2 && $x2 = $q2->fetch_assoc()) $yesterdayColor = $x2['color'];

                if ($ip['warmup_started_at'] === null) {
                    $day = 1;
                    $conn->query("UPDATE kumo_ips SET warmup_started_at='$today', warmup_day=1 WHERE id=$id");
                } elseif ($yesterdayColor === 'green' || $yesterdayColor === null) {
                    $day = $day + 1;
                    $conn->query("UPDATE kumo_ips SET warmup_day=$day WHERE id=$id");
                } elseif ($yesterdayColor === 'red') {
                    $day = max(1, $day - 1);
                    $conn->query("UPDATE kumo_ips SET warmup_day=$day WHERE id=$id");
                }
                /* yellow → hold the same day */
            }

            $cap = $ip['manual_cap'] !== null && $ip['manual_cap'] !== ''
                 ? (int)$ip['manual_cap']
                 : ((int)$ip['warmup_enabled'] === 1 ? kumo_warmup_cap_for_day($day) : 1000000);

            if ($ip['health'] === 'yellow') $cap = (int)floor($cap / 2);
            if ($ip['health'] === 'red' || $ip['status'] !== 'active') $cap = 0;

            $conn->query("INSERT INTO kumo_ip_daily (ip_id, day, cap, sent, warmup_day)
                          VALUES ($id, '$today', $cap, 0, $day)
                          ON DUPLICATE KEY UPDATE cap = VALUES(cap), warmup_day = VALUES(warmup_day)");
            $out['updated']++;
            $out['rows'][] = ['ip' => $ip['ip'], 'day' => $day, 'cap' => $cap];
        }
    } catch (\Throwable $e) { error_log('kumo_warmup_tick: ' . $e->getMessage()); }
    return $out;
}

/** Remaining quota for one IP today (cap 0 = cannot send). */
function kumo_remaining_today(int $ipId): int {
    global $conn;
    $today = date('Y-m-d');
    try {
        $r = $conn->query("SELECT cap, sent FROM kumo_ip_daily WHERE ip_id=" . (int)$ipId . " AND day='$today' LIMIT 1");
        if ($r && $x = $r->fetch_assoc()) return max(0, (int)$x['cap'] - (int)$x['sent']);
    } catch (\Throwable $e) { error_log('kumo_remaining_today: ' . $e->getMessage()); }
    return 0;
}

/** Records N sends against today's quota. */
function kumo_consume_quota(int $ipId, int $n): void {
    global $conn;
    if ($n <= 0) return;
    $today = date('Y-m-d');
    try {
        $conn->query("INSERT INTO kumo_ip_daily (ip_id, day, cap, sent) VALUES (" . (int)$ipId . ", '$today', 0, " . (int)$n . ")
                      ON DUPLICATE KEY UPDATE sent = sent + " . (int)$n);
        $conn->query("UPDATE kumo_ips SET last_send_at = NOW() WHERE id = " . (int)$ipId);
    } catch (\Throwable $e) { error_log('kumo_consume_quota: ' . $e->getMessage()); }
}

/* ── Blocklist + reverse DNS probes ────────────────────────────────────────── */

/**
 * Checks every active IP against the DNSBLs and verifies reverse DNS.
 * Run hourly by the health worker; also available as a button in the UI.
 */
function kumo_blocklist_tick(): array {
    global $conn;
    $out = ['checked' => 0, 'listed' => []];
    $zones = kumo_dnsbl_zones();
    $dqs   = (string)kumo_setting('spamhaus_dqs_key', '');
    if ($dqs !== '') $zones[$dqs . '.zen.dq.spamhaus.net'] = 'Spamhaus (DQS)';

    try {
        $r = $conn->query("SELECT id, ip, hostname FROM kumo_ips WHERE status <> 'retired'");
        $ips = [];
        while ($r && $x = $r->fetch_assoc()) $ips[] = $x;

        foreach ($ips as $ip) {
            $id   = (int)$ip['id'];
            $addr = $ip['ip'];
            $hits = [];

            foreach ($zones as $zone => $label) {
                $res = KumoClient::dnsblCheck($addr, $zone);
                $conn->query(sprintf(
                    "INSERT INTO kumo_blocklist_checks (target, kind, zone, listed, response, checked_at)
                     VALUES ('%s','ip','%s',%d,%s,NOW())
                     ON DUPLICATE KEY UPDATE listed=VALUES(listed), response=VALUES(response), checked_at=NOW()",
                    $conn->real_escape_string($addr), $conn->real_escape_string($zone),
                    $res['listed'] ? 1 : 0,
                    $res['response'] === null ? 'NULL' : "'" . $conn->real_escape_string($res['response']) . "'"
                ));
                if ($res['listed']) $hits[] = $label;
            }

            $ptr = KumoClient::ptrCheck($addr, $ip['hostname'] ?: '');
            $conn->query(sprintf(
                "UPDATE kumo_ips SET blocklisted=%d, blocklist_note=%s, ptr_ok=%d, ptr_value=%s WHERE id=%d",
                $hits ? 1 : 0,
                $hits ? "'" . $conn->real_escape_string(implode(', ', $hits)) . "'" : 'NULL',
                $ptr['ok'] ? 1 : 0,
                $ptr['ptr'] ? "'" . $conn->real_escape_string($ptr['ptr']) . "'" : 'NULL',
                $id
            ));

            if ($hits) {
                $out['listed'][] = ['ip' => $addr, 'zones' => $hits];
                kumo_alert('critical', 'IP ' . $addr . ' is blocklisted', 'Listed on: ' . implode(', ', $hits), $id);
            }
            $out['checked']++;
        }
    } catch (\Throwable $e) { error_log('kumo_blocklist_tick: ' . $e->getMessage()); }
    return $out;
}

/** Probes the bridge and records the result (API-health widget). */
function kumo_api_probe(): array {
    global $conn;
    $c = new KumoClient();
    $h = $c->health();
    try {
        $conn->query(sprintf(
            "INSERT INTO kumo_api_health (checked_at, ok, latency_ms, queue_size, scheduled, error)
             VALUES (NOW(), %d, %d, %d, %d, %s)",
            $h['ok'] ? 1 : 0, (int)$h['latency_ms'], (int)$h['queue_size'], (int)$h['scheduled'],
            $h['error'] ? "'" . $conn->real_escape_string(substr((string)$h['error'], 0, 240)) . "'" : 'NULL'
        ));
        if (!$h['ok']) kumo_alert('critical', 'KumoMTA bridge unreachable', (string)$h['error']);
    } catch (\Throwable $e) { error_log('kumo_api_probe: ' . $e->getMessage()); }
    return $h;
}

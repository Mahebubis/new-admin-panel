<?php
ini_set('display_errors', 0);
error_reporting(E_ALL);
ob_start();
chdir('/home/istudio/public_html/cit/common');
include '/home/istudio/public_html/cit/common/helper.php';
ob_clean();
header('Content-Type: application/json');

function logErr($ctx, $msg) {
    $trace = debug_backtrace(DEBUG_BACKTRACE_IGNORE_ARGS, 1);
    file_put_contents('/home/istudio/logs/search-result.log',
        '[' . date('Y-m-d H:i:s') . '] [' . $ctx . '] line ' . ($trace[0]['line']??'?') . ': ' . $msg . PHP_EOL,
        FILE_APPEND | LOCK_EX);
}

register_shutdown_function(function () {
    $error = error_get_last();
    if ($error && in_array($error['type'], [E_ERROR, E_PARSE, E_CORE_ERROR])) {
        ob_clean(); header('Content-Type: application/json');
        $msg = 'PHP Fatal: ' . $error['message'] . ' line ' . $error['line'];
        file_put_contents('/home/istudio/logs/search-result.log',
            '[' . date('Y-m-d H:i:s') . '] [FATAL] ' . $msg . PHP_EOL, FILE_APPEND | LOCK_EX);
        echo json_encode(['success' => false, 'message' => $msg]);
    }
});

global $conn;
if (!$conn) { echo json_encode(['success'=>false,'message'=>'DB failed']); exit; }

// Performance session vars — same as search_result.php
mysqli_query($conn, "SET SESSION tmp_table_size = 268435456");
mysqli_query($conn, "SET SESSION max_heap_table_size = 268435456");
mysqli_query($conn, "SET SESSION sort_buffer_size = 67108864");

$action = $_POST['action'] ?? $_GET['action'] ?? '';

/* ════════════════════════════════════════
   SEARCH — exact same query as search_result.php
   Searches: user_id, email (LIKE), phone (LIKE)
   Returns multiple users if > 1 match
════════════════════════════════════════ */
if ($action === 'search') {
    $q = trim($_POST['query'] ?? '');
    if (empty($q)) {
        echo json_encode(['success'=>false,'message'=>'Search query is required']);
        exit;
    }

    $qEsc = mysqli_real_escape_string($conn, $q);

    // Use exact match on all three columns — fully uses indexes, no LIKE
    // Run 3 small exact-match queries and merge (faster than OR on large tables)
    $rows = [];
    $seen = [];

    // 1. Exact user_id
    if (is_numeric($q)) {
        $r1 = mysqli_query($conn, "SELECT user_id, email, phone, name FROM users WHERE user_id = '$qEsc' LIMIT 1");
        if ($r1) while ($r = mysqli_fetch_assoc($r1)) { if (!isset($seen[$r['user_id']])) { $rows[] = $r; $seen[$r['user_id']] = 1; } }
    }

    // 2. Exact email
    if (empty($rows)) {
        $r2 = mysqli_query($conn, "SELECT user_id, email, phone, name FROM users WHERE email = '$qEsc' LIMIT 5");
        if ($r2) while ($r = mysqli_fetch_assoc($r2)) { if (!isset($seen[$r['user_id']])) { $rows[] = $r; $seen[$r['user_id']] = 1; } }
    }

    // 3. Exact phone
    if (empty($rows)) {
        $r3 = mysqli_query($conn, "SELECT user_id, email, phone, name FROM users WHERE phone = '$qEsc' LIMIT 5");
        if ($r3) while ($r = mysqli_fetch_assoc($r3)) { if (!isset($seen[$r['user_id']])) { $rows[] = $r; $seen[$r['user_id']] = 1; } }
    }

    if (count($rows) === 0) {
        echo json_encode(['success'=>false,'message'=>'User not found']);
        exit;
    }

    if (count($rows) > 1) {
        echo json_encode(['success'=>true,'multiple'=>true,'users'=>$rows]);
        exit;
    }

    // Single user — fetch full data
    $user_id = (int)$rows[0]['user_id'];
    $data    = fetchFullUserData($user_id);
    echo json_encode(array_merge(['success'=>true,'multiple'=>false], $data));
    exit;
}

/* ════════════════════════════════════════
   FETCH BY USER ID (direct)
════════════════════════════════════════ */
if ($action === 'fetch_by_id') {
    $user_id = (int)($_POST['user_id'] ?? 0);
    if (!$user_id) {
        echo json_encode(['success'=>false,'message'=>'user_id required']);
        exit;
    }
    $data = fetchFullUserData($user_id);
    echo json_encode(array_merge(['success'=>true], $data));
    exit;
}

/* ════════════════════════════════════════
   HELPER: fetch all data for a user
   Exact same queries as search_result.php
════════════════════════════════════════ */
function fetchFullUserData($user_id) {
    global $conn;

    /* ── 1. USER DATA — no DATE() function, all index-friendly ── */
    $sql = "
        SELECT u.*, ad.*,
            us.cit_whatsapp_community AS wa_community_added,
            ec.password AS exam_password,
            r.rank, r.rightans, r.wrongans, r.total,
            ucm.medium, ucm.campaign, ucm.adset, ucm.ad
        FROM users u
        LEFT JOIN additional_details ad  ON u.user_id = ad.user_id
        LEFT JOIN user_steps us          ON u.user_id = us.user_id
        LEFT JOIN exam_credentials ec    ON u.user_id = ec.user_id
        LEFT JOIN result r               ON u.user_id = r.user_id
        LEFT JOIN user_campaign ucm      ON u.user_id = ucm.user_id
        WHERE u.user_id = $user_id
        LIMIT 1
    ";
    $res  = mysqli_query($conn, $sql);
    $user = $res ? mysqli_fetch_assoc($res) : [];
    if ($user) unset($user['password']);

    // CIT version — separate query, cast registered_at to DATE so index on from_date/to_date is used
    if (!empty($user['registered_at'])) {
        $regDate = mysqli_real_escape_string($conn, substr($user['registered_at'], 0, 10));
        $vRes = mysqli_query($conn, "SELECT REPLACE(exam_name, 'CIT ', '') AS cit_version_name
                                     FROM exam_batch_for_reports
                                     WHERE '$regDate' BETWEEN from_date AND to_date LIMIT 1");
        $user['cit_version_name'] = ($vRes && mysqli_num_rows($vRes) > 0)
            ? mysqli_fetch_assoc($vRes)['cit_version_name'] : '-';
    }

    /* ── 2. INTERNSHIPS — single JOIN query, no per-row loops ──
       project_submission is pinned to the LATEST submission row per
       (user, internship) via `ps_sub.id = (SELECT … LIMIT 1)`. The old
       `ON user_id = … AND internship_id = …` join duplicated the internship
       once per submission whenever a student re-submitted, and
       payment_status is read the same way so a repeated payment_id cannot
       duplicate the row either. */
    $internships = [];
    $sql = "
        SELECT ip.*,
            il.id                AS internship_list_id,
            il.internship_name   AS internship_title,
            ps_sub.status        AS project_status,
            ps_sub.reject_reason AS project_reject_reason,
            ps_sub.file_link     AS project_file_link,
            ps_sub.created_at    AS project_submission_date,
            COALESCE((SELECT pst.amount FROM payment_status pst
                      WHERE pst.payment_id COLLATE utf8mb4_unicode_ci = ip.payment_id COLLATE utf8mb4_unicode_ci
                      LIMIT 1), 0) AS charge_amount
        FROM internship_payment ip
        LEFT JOIN internship_list il
            ON ip.internship COLLATE utf8mb4_unicode_ci = il.internship_name COLLATE utf8mb4_unicode_ci
        LEFT JOIN project_submission ps_sub
            ON ps_sub.id = (
                SELECT p2.id FROM project_submission p2
                WHERE p2.user_id = ip.user_id AND p2.internship_id = il.id
                ORDER BY p2.created_at DESC, p2.id DESC
                LIMIT 1
            )
        WHERE ip.user_id = $user_id
        ORDER BY ip.paid_at DESC
    ";
    $has_refund = false;
    $res = mysqli_query($conn, $sql);
    if (!$res) logErr('internships', 'Query failed: ' . mysqli_error($conn));
    if ($res) while ($row = mysqli_fetch_assoc($res)) {
        if (!empty($row['refund']) && ($row['refund'] === 'yes' || $row['refund'] == 1)) {
            $has_refund = true;
        }

        /* Normalise the project state so the panel never shows a bare
           "Pending" for an internship that has no submission row at all:
             approved | rejected | pending  -> the real project_submission.status
             not_submitted                  -> internship matched, no submission yet
             unknown                        -> ip.internship has no internship_list
                                               match, so no submission can be found */
        $raw = strtolower(trim((string)($row['project_status'] ?? '')));
        if ($raw !== '')                            $state = $raw;   // approved | rejected | pending
        elseif (empty($row['internship_list_id']))  $state = 'unknown';
        else                                        $state = 'not_submitted';

        $row['project_status'] = ($raw !== '') ? $raw : null;
        $row['project_state']  = $state;

        $internships[] = $row;
    }

    /* ── 3. EXAM — try cit_results first, fallback to result ── */
    $exam = null;
    $sql  = "
        SELECT u.user_id, u.name, u.email,
            cr.correct_answers AS rightans,
            cr.wrong_answers   AS wrongans,
            cr.timestamp       AS exam_taken_date,
            r.rank, u.phone, 'new' AS source
        FROM cit_results cr
        INNER JOIN users u ON u.user_id = cr.user_id
        LEFT JOIN result r ON r.user_id = u.user_id
        WHERE cr.user_id = $user_id AND cr.exam_id = 1
        LIMIT 1
    ";
    $res = mysqli_query($conn, $sql);
    if ($res && mysqli_num_rows($res) > 0) {
        $exam = mysqli_fetch_assoc($res);
    }

    if (!$exam) {
        $sql = "
            SELECT u.user_id, u.name, u.email,
                r.rightans, r.wrongans, r.total, r.rank,
                u.phone, 'old' AS source
            FROM result r
            INNER JOIN users u ON u.user_id = r.user_id
            WHERE r.user_id = $user_id
            LIMIT 1
        ";
        $res  = mysqli_query($conn, $sql);
        $exam = ($res && mysqli_num_rows($res) > 0) ? mysqli_fetch_assoc($res) : null;
    }

    /* ── 4. SUPPORT TICKETS ── */
    $tickets = [];
    $sql = "SELECT ticket_id, subject, status, created_at
            FROM support_tickets
            WHERE user_id = $user_id
            ORDER BY created_at DESC
            LIMIT 10";
    $res = mysqli_query($conn, $sql);
    if ($res) while ($r = mysqli_fetch_assoc($res)) $tickets[] = $r;

    /* ── 5. PAYMENT HISTORY ── same as search_result.php ── */
    $payments = [];
    $email    = mysqli_real_escape_string($conn, $user['email'] ?? '');
    $sql = "
        SELECT ip.payment_id, ip.internship, ip.batch,
            ip.total_duration, ip.internship_level, ip.paid_at
        FROM internship_payment ip
        INNER JOIN users u ON ip.user_id = u.user_id
        WHERE u.email = '$email'
        ORDER BY ip.paid_at DESC
    ";
    $res = mysqli_query($conn, $sql);
    if ($res) {
        while ($row = mysqli_fetch_assoc($res)) {
            $pid       = mysqli_real_escape_string($conn, $row['payment_id']);
            $sr        = mysqli_query($conn, "SELECT amount, status, remark FROM payment_status WHERE payment_id = '$pid' LIMIT 1");
            $row['amount'] = '0'; $row['status'] = 'pending'; $row['remark'] = '-';
            if ($sr && mysqli_num_rows($sr) > 0) {
                $srow = mysqli_fetch_assoc($sr);
                $row['amount'] = $srow['amount'] ?? '0';
                $row['status'] = $srow['status'] ?? 'pending';
                $row['remark'] = $srow['remark'] ?? '-';
            }
            $payments[] = $row;
        }
    }

    /* ── 6. STARTER KIT (99 Store) ORDERS ──
       `ninety_nine_store_orders` is a guest checkout table — it has no
       user_id, so the buyer is matched on the details captured at checkout:
       email, or the phone with/without a country-code prefix. One order can
       carry several courses (`courses` is a JSON array). */
    $starter_kits = [];
    $phoneRaw = preg_replace('/\D+/', '', (string)($user['phone'] ?? ''));
    $phone10  = strlen($phoneRaw) > 10 ? substr($phoneRaw, -10) : $phoneRaw;

    $where = [];
    if ($email !== '')   $where[] = "email = '$email'";
    if ($phoneRaw !== '') {
        $pEsc = mysqli_real_escape_string($conn, $phoneRaw);
        $where[] = "phone_number = '$pEsc'";
    }
    if ($phone10 !== '' && $phone10 !== $phoneRaw) {
        $p10Esc = mysqli_real_escape_string($conn, $phone10);
        $where[] = "phone_number = '$p10Esc'";
        $where[] = "phone_number = '91$p10Esc'";
        $where[] = "phone_number = '+91$p10Esc'";
    }

    if ($where) {
        $sql = "SELECT id, first_name, last_name, email, phone_number, state,
                       course_slug, course_name, courses, course_count, batch,
                       order_id, razorpay_order_id, payment_id, provider,
                       amount, status, created_at, updated_at
                FROM ninety_nine_store_orders
                WHERE " . implode(' OR ', $where) . "
                ORDER BY id DESC";
        $res = mysqli_query($conn, $sql);
        if (!$res) {
            logErr('starter_kits', 'Query failed: ' . mysqli_error($conn));
        } else {
            while ($row = mysqli_fetch_assoc($res)) {
                /* courses -> always a [{name, slug, price}, …] array, including
                   for the older single-course rows where `courses` is NULL */
                $list = [];
                if (!empty($row['courses'])) {
                    $decoded = json_decode($row['courses'], true);
                    if (is_array($decoded)) foreach ($decoded as $c) {
                        if (is_string($c)) {
                            $list[] = ['name' => $c, 'slug' => '', 'price' => null];
                        } elseif (is_array($c)) {
                            $list[] = [
                                'name'  => $c['name'] ?? $c['course_name'] ?? $c['title'] ?? ($c['slug'] ?? ''),
                                'slug'  => $c['slug'] ?? $c['course_slug'] ?? '',
                                'price' => isset($c['price']) ? (float)$c['price'] : null,
                            ];
                        }
                    }
                }
                if (!$list && (($row['course_name'] ?? '') !== '' || ($row['course_slug'] ?? '') !== '')) {
                    $list[] = ['name' => $row['course_name'] ?? '', 'slug' => $row['course_slug'] ?? '', 'price' => null];
                }

                $row['courses']       = $list;
                $row['course_count']  = (int)($row['course_count'] ?? 0) ?: count($list);
                $row['course_label']  = $list
                    ? implode(', ', array_filter(array_column($list, 'name')))
                    : ($row['course_name'] ?? '-');
                $row['name']          = trim(($row['first_name'] ?? '') . ' ' . ($row['last_name'] ?? ''));
                $row['phone']         = $row['phone_number'] ?? '';
                /* an order is only "paid at" its updated_at once it succeeded */
                $row['paid_at']       = ($row['status'] === 'success') ? $row['updated_at'] : $row['created_at'];

                $starter_kits[] = $row;
            }
        }
    }

    return [
        'user'         => $user,
        'internships'  => $internships,
        'exam'         => $exam,
        'tickets'      => $tickets,
        'payments'     => $payments,
        'has_refund'   => $has_refund,
        'starter_kits' => $starter_kits,
    ];
}

/* ── fallback ── */
logErr('fallback', "Unknown action='$action'");
echo json_encode(['success'=>false,'message'=>'Invalid action: '.$action]);
exit;
?>
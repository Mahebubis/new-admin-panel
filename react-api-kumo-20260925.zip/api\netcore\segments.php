<?php
/*
 * /api/netcore/segments.php
 *
 * Body actions (form-urlencoded or JSON):
 *   action=list            → list segments (id, name, counts, refreshed)
 *   action=get      &id    → fetch one segment + its config JSON
 *   action=save     [&id]  &name &contact_type &config(json) → create/update
 *   action=delete   &id
 *   action=duplicate&id
 *   action=refresh  &id    → recompute user_count
 *   action=count           &config(json) → preview count without saving
 *   action=engagement_options → campaigns / journeys / tags / lists / segments for the builder pickers
 *   action=download &id    → CSV of resulting users (email, fname, lname, phone, registered_at)
 */
header('Cache-Control: no-cache, no-store, must-revalidate');
ini_set('display_errors', 0);
ob_start();

chdir('/home/istudio/public_html/cit/common');
include '/home/istudio/public_html/cit/common/helper.php';
ob_clean();

global $conn;
if (!$conn) { header('Content-Type: application/json'); echo json_encode(['status'=>'error','message'=>'DB connection missing']); exit; }

/* helpers */
function jin($k, $d = null) { $v = $_REQUEST[$k] ?? null; return $v === null ? $d : $v; }
function ok($a)   { header('Content-Type: application/json'); echo json_encode(['status'=>'success'] + $a); exit; }
function fail($m, $code = 400) { http_response_code($code); header('Content-Type: application/json'); echo json_encode(['status'=>'error','message'=>$m]); exit; }
function esc($s) { global $conn; return mysqli_real_escape_string($conn, $s); }

/* Engagement (email / WhatsApp / list activity) and Contacts (list / segment membership)
   conditions — buildConditionSql() below dispatches to it on cond.kind. Functions only; it uses
   esc(), resolveDay() and buildSegmentSql() defined in this file. */
require_once __DIR__ . '/lib/segment_engagement.php';

/* ════════════════════════════════════════
   Event-table mapping (mirrors behaviour.php)
   Each entry is an assoc array:
     - table     : source table
     - user_col  : column yielding user_id (qualified if it lives in a joined table, e.g. u_link.user_id)
     - date_col  : column used for the day-window filter (qualify if ambiguous, e.g. instant_exam_reminder_logs.created_at)
     - where     : optional extra SQL constraint
     - join      : optional JOIN clause(s) baked into the source — used when the
                   source table doesn't have user_id directly (email-keyed reminder logs,
                   employer-keyed company tables) and we need to resolve to users.user_id
═══════════════════════════════════════ */
$EVENT_SOURCE = [
    'register'                 => ['table' => 'users',                   'user_col' => 'user_id', 'date_col' => 'registered_at',  'where' => ''],
    'signin'                   => ['table' => 'signin_log',              'user_col' => 'user_id', 'date_col' => 'created_at',     'where' => ''],
    'exam_success'             => ['table' => 'cit_results',             'user_col' => 'user_id', 'date_col' => '`timestamp`',    'where' => ''],
    'course_purchase'          => ['table' => 'payment_status',          'user_col' => 'user_id', 'date_col' => '`timestamp`',    'where' => "status='initiated'"],
    'payment_success'          => ['table' => 'payment_status',          'user_col' => 'user_id', 'date_col' => '`timestamp`',    'where' => "status='success'"],
    'preferred_domain'         => ['table' => 'user_slected_domain_new', 'user_col' => 'user_id', 'date_col' => 'created_at',     'where' => ''],
    'visited_iap'              => ['table' => 'user_iap_visits',         'user_col' => 'user_id', 'date_col' => 'visited_at',     'where' => ''],
    'result_view'              => ['table' => 'cit_results',             'user_col' => 'user_id', 'date_col' => '`timestamp`',    'where' => 'user_id IN (SELECT user_id FROM users WHERE score_viewed=1)'],
    'placement_community_link' => ['table' => 'assigned_links',          'user_col' => 'user_id', 'date_col' => 'assigned_at',    'where' => ''],
    'instantexam_reminder'     => ['table' => 'set_reminder',            'user_col' => 'user_id', 'date_col' => 'created_at',     'where' => ''],
    'course_edit'              => ['table' => 'internship_edit_logs',    'user_col' => 'user_id', 'date_col' => 'created_at',     'where' => ''],

    /* user_id present directly in the source — fits the simple pattern */
    'mark_attendance'   => ['table' => 'attendance_log',      'user_col' => 'user_id', 'date_col' => 'marked_at',  'where' => ''],
    'came_on_dashboard' => ['table' => 'user_login_activity', 'user_col' => 'user_id', 'date_col' => 'login_date', 'where' => ''],
    'link_assigned'     => ['table' => 'assigned_links',      'user_col' => 'user_id', 'date_col' => 'assigned_at','where' => ''],

    /* reminder log tables — user_id column is present, use it directly.
       Rows with NULL user_id (e.g. reminders fired before user resolution) won't be segmentable. */
    'exam_reminder'               => ['table' => 'instant_exam_reminder_logs',     'user_col' => 'user_id', 'date_col' => 'created_at', 'where' => 'user_id IS NOT NULL'],
    'project_submission_reminder' => ['table' => 'project_submission_reminder_logs','user_col' => 'user_id', 'date_col' => 'created_at', 'where' => 'user_id IS NOT NULL'],
    'one_day_before_batch_start'  => ['table' => 'one_day_before_batch_start_logs', 'user_col' => 'user_id', 'date_col' => 'created_at', 'where' => 'user_id IS NOT NULL'],
    'batch_end_reminder'          => ['table' => 'same_day_batch_end_logs',        'user_col' => 'user_id', 'date_col' => 'created_at', 'where' => 'user_id IS NOT NULL'],

    /* company/employer events → employer_email → users.email join.
       Employers without a matching user account won't show up. */
    'register_company' => [
        'table' => 'hiring_employer', 'user_col' => 'u_link.user_id',
        'date_col' => 'hiring_employer.registered_at', 'where' => '',
        'join' => 'INNER JOIN users u_link ON u_link.email = hiring_employer.employer_email',
    ],
    'company_signin' => [
        'table' => 'employer_login_logs', 'user_col' => 'u_link.user_id',
        'date_col' => 'employer_login_logs.login_time', 'where' => '',
        'join' => 'INNER JOIN hiring_employer he ON he.employer_id = employer_login_logs.employer_id '
                . 'INNER JOIN users u_link ON u_link.email = he.employer_email',
    ],
    'company_vacancy_post' => [
        'table' => 'job_list', 'user_col' => 'u_link.user_id',
        'date_col' => 'job_list.created_at', 'where' => '',
        'join' => 'INNER JOIN hiring_employer he ON he.employer_id = job_list.employer_id '
                . 'INNER JOIN users u_link ON u_link.email = he.employer_email',
    ],
];

/* (event, payloadKey) → fully-qualified column to filter on.
   • Columns starting with `users.` trigger an automatic LEFT JOIN to users when
     the source table doesn't already bring users in via its `join` field.
   • For events whose `join` already aliases helper tables (e.g. `he` for hiring_employer
     in company_signin / company_vacancy_post), payload columns can reference those aliases. */
$PAYLOAD_COLUMNS = [
    'register' => [
        'country'        => 'users.country',
        'mobile'         => 'users.phone',
        'last_name'      => 'users.lname',
        'state'          => 'users.state',
        'first_name'     => 'users.fname',
        'email'          => 'users.email',
        'instantexam'    => 'users.instant_exam',
        'instantresult'  => 'users.instant_result',
        'is_from_refund' => 'users.is_from_refund',
        'method'         => "(CASE WHEN users.is_signup_by_google='yes' THEN 'Google' ELSE 'Manual' END)",
        /* values mirror PAYLOAD_VALUES in eventsConfig.js — yes/no for booleans, raw enum for the rest */
        'referral'       => "(CASE WHEN users.is_from_referral=1 THEN 'yes' ELSE 'no' END)",
        'express'        => "(CASE WHEN users.organic_user=1 THEN 'yes' ELSE 'no' END)",
        'setreminder'    => "(CASE WHEN EXISTS(SELECT 1 FROM set_reminder sr WHERE sr.user_id = users.user_id) THEN 'yes' ELSE 'no' END)",
        'source'         => "(SELECT uc.source   FROM user_campaign uc WHERE uc.user_id = users.user_id LIMIT 1)",
        'campaign'       => "(SELECT uc.campaign FROM user_campaign uc WHERE uc.user_id = users.user_id LIMIT 1)",
        'adset'          => "(SELECT uc.adset    FROM user_campaign uc WHERE uc.user_id = users.user_id LIMIT 1)",
        'ad'             => "(SELECT uc.ad       FROM user_campaign uc WHERE uc.user_id = users.user_id LIMIT 1)",
        'medium'         => "(SELECT uc.medium   FROM user_campaign uc WHERE uc.user_id = users.user_id LIMIT 1)",
        'full_url'       => "(SELECT sfu.full_url      FROM store_full_url sfu WHERE sfu.user_id = users.user_id LIMIT 1)",
        'register_type'  => "(SELECT sfu.register_type FROM store_full_url sfu WHERE sfu.user_id = users.user_id LIMIT 1)",
        'device'         => "(SELECT sfu.device        FROM store_full_url sfu WHERE sfu.user_id = users.user_id LIMIT 1)",
    ],
    'signin'           => [ 'email' => 'users.email' ],
    'exam_success'     => [ 'result_score' => 'cit_results.score', 'status' => "'Completed'" ],
    'course_purchase'  => [
        'amount'          => 'payment_status.amount',
        'internship_name' => 'payment_status.internship_name',
        'batch_date'      => 'payment_status.batch_date',
        'coupon_applied'  => "(CASE WHEN payment_status.coupon_code IS NOT NULL AND payment_status.coupon_code <> '' THEN 'yes' ELSE 'no' END)",
        'initiated_at'    => 'payment_status.timestamp',
    ],
    'payment_success'  => [
        'paid_amount'            => 'payment_status.amount',
        'paid_internship_name'   => 'payment_status.internship_name',
        'paid_batch_date'        => 'payment_status.batch_date',
        'coupon_applied_success' => "(CASE WHEN payment_status.coupon_code IS NOT NULL AND payment_status.coupon_code <> '' THEN 'yes' ELSE 'no' END)",
        'order_id'               => 'payment_status.order_id',
        'paid_at'                => 'payment_status.timestamp',
    ],
    'preferred_domain' => [ 'preferred_domain' => 'user_slected_domain_new.domain_name' ],
    'visited_iap'      => [ 'visited' => "'yes'", 'visited_time' => 'user_iap_visits.visited_at' ],
    'result_view'      => [ 'score' => 'cit_results.score' ],
    'placement_community_link' => [
        /* assigned_links is the non-refund variant; the refund variant is a separate event source */
        'refund_non_refund' => "'Non Refund'",
        'assigned_links'    => 'assigned_links.assigned_id',
    ],
    'instantexam_reminder' => [
        'time_slot' => 'set_reminder.time_slot',
        'date_time' => 'set_reminder.created_at',
    ],
    'course_edit' => [
        'edit_internship_name' => 'internship_edit_logs.new_internship_name',
        'edit_page_url'        => 'internship_edit_logs.page_url',
        'edit_batch_date'      => 'internship_edit_logs.new_batch',
        'edit_type'            => 'internship_edit_logs.action_type',
    ],

    'register_company' => [
        'company_logo'   => "(CASE WHEN hiring_employer.employer_logo IS NOT NULL AND hiring_employer.employer_logo <> '' THEN 'Has Logo' ELSE 'No Logo' END)",
        'company_mobile' => 'hiring_employer.employer_phone',
        'company_name'   => 'hiring_employer.employer_name',
        'company_email'  => 'hiring_employer.employer_email',
    ],
    'company_signin' => [
        /* `he` alias is provided by the event source's join */
        'company_signin_email'      => 'he.employer_email',
        'company_signin_status'     => 'employer_login_logs.status',
        'company_signin_ip'         => 'employer_login_logs.ip_address',
        'company_signin_user_agent' => 'employer_login_logs.user_agent',
    ],
    'company_vacancy_post' => [
        'vp_email'       => 'he.employer_email',
        'vp_job_type'    => 'job_list.job_type',
        'vp_job_title'   => 'job_list.job_title',
        'vp_mode'        => 'job_list.job_mode',
        'vp_openings'    => 'job_list.openings',
        'vp_start_date'  => 'job_list.start_date',
        'vp_duration'    => 'job_list.job_duration',
        'vp_salary'      => 'job_list.compensation_amount',
        'vp_comp_amount' => 'job_list.compensation_amount',
        'vp_comp_min'    => 'job_list.compensation_min_amount',
        'vp_comp_max'    => 'job_list.compensation_max_amount',
        'vp_comp_type'   => 'job_list.compensation_type',
        'vp_comp_period' => 'job_list.compensation_period',
        'vp_experience'  => 'job_list.min_experience',
        'vp_method'      => 'job_list.job_nature',
        'vp_source'      => 'job_list.source',
    ],

    'mark_attendance' => [
        'internship_id'   => 'attendance_log.internship_id',
        'attendance_date' => 'attendance_log.attendance_date',
        'note'            => 'attendance_log.note',
        'character_count' => 'attendance_log.character_count',
        'marked_at'       => 'attendance_log.marked_at',
        'ip_address'      => 'attendance_log.ip_address',
        'user_agent'      => 'attendance_log.user_agent',
    ],
    'came_on_dashboard' => [
        'login_date'     => 'user_login_activity.login_date',
        'activity_level' => 'user_login_activity.activity_level',
    ],
    'link_assigned' => [
        /* wa_link/wa_community/link_user_type require a join to whatsapp_placement_club_link
           and to the refund variant table — keep payload filtering simple for now */
        'la_assigned_at' => 'assigned_links.assigned_at',
    ],

    'exam_reminder' => [
        'er_exam_date'   => 'instant_exam_reminder_logs.exam_date',
        'er_time_slot'   => 'instant_exam_reminder_logs.time_slot',
        /* `status` is also a column on the wrapping users table — qualify to avoid ambiguity */
        'er_status'      => 'instant_exam_reminder_logs.status',
        'er_email'       => 'instant_exam_reminder_logs.email',
        'er_cron_run_id' => 'instant_exam_reminder_logs.cron_run_id',
    ],
    'project_submission_reminder' => [
        'psr_internship_name' => 'project_submission_reminder_logs.internship_name',
        'psr_batch'           => 'project_submission_reminder_logs.batch',
        'psr_duration_label'  => 'project_submission_reminder_logs.duration_label',
        'psr_status'          => 'project_submission_reminder_logs.status',
        'psr_email'           => 'project_submission_reminder_logs.email',
        'psr_cron_run_id'     => 'project_submission_reminder_logs.cron_run_id',
    ],
    'one_day_before_batch_start' => [
        'odb_internship_name' => 'one_day_before_batch_start_logs.internship_name',
        'odb_batch'           => 'one_day_before_batch_start_logs.batch',
        'odb_duration_label'  => 'one_day_before_batch_start_logs.duration_label',
        'odb_status'          => 'one_day_before_batch_start_logs.status',
        'odb_email'           => 'one_day_before_batch_start_logs.email',
        'odb_cron_run_id'     => 'one_day_before_batch_start_logs.cron_run_id',
    ],
    'batch_end_reminder' => [
        'ber_internship_name' => 'same_day_batch_end_logs.internship_name',
        'ber_batch'           => 'same_day_batch_end_logs.batch',
        'ber_end_date'        => 'same_day_batch_end_logs.end_date',
        'ber_project_status'  => 'same_day_batch_end_logs.project_status',
        'ber_resubmitted'     => 'same_day_batch_end_logs.resubmitted',
        'ber_status'          => 'same_day_batch_end_logs.status',
        'ber_email'           => 'same_day_batch_end_logs.email',
        'ber_cron_run_id'     => 'same_day_batch_end_logs.cron_run_id',
    ],
];

/* day filter — { type:'any'|'between'|'in_past'|'exactly_before', from, to, n, unit } → [start,end] dates or null */
function resolveDay($day) {
    if (!$day || ($day['type'] ?? 'any') === 'any') return [null, null];
    $t = $day['type'];
    $today = date('Y-m-d');
    if ($t === 'between') return [$day['from'] ?? $today, $day['to'] ?? $today];
    if ($t === 'in_past') {
        $n = max(1, (int)($day['n'] ?? 7));
        $unit = $day['unit'] ?? 'days';
        $sec = ['hours'=>3600,'days'=>86400,'weeks'=>604800,'months'=>2592000][$unit] ?? 86400;
        return [date('Y-m-d', time() - $n * $sec), $today];
    }
    if ($t === 'exactly_before') {
        $n = max(1, (int)($day['n'] ?? 7));
        $d = date('Y-m-d', time() - $n * 86400);
        return [$d, $d];
    }
    return [null, null];
}

/* Build a SELECT user_id subquery from a single condition. Returns SQL string or null on bad input. */
function buildConditionSql($cond, $isExclude = false) {
    global $EVENT_SOURCE, $PAYLOAD_COLUMNS, $conn;

    /* Engagement / Contacts tabs live in lib/segment_engagement.php; no kind = Behaviour (below) */
    $kind = $cond['kind'] ?? 'behaviour';
    if ($kind === 'engagement') return buildEngagementConditionSql($cond);
    if ($kind === 'contacts')   return buildContactsConditionSql($cond);

    $event = $cond['event'] ?? '';
    if (!isset($EVENT_SOURCE[$event])) return null;
    $src     = $EVENT_SOURCE[$event];
    $tbl     = $src['table'];
    $userCol = $src['user_col'];
    $dateCol = $src['date_col'];
    $where   = $src['where'] ?? '';
    $srcJoin = $src['join']  ?? '';

    /* When user_col is unqualified (e.g. 'user_id'), qualify it as `$tbl.user_id`
       to disambiguate when extra joins are added. Already-qualified values pass through. */
    $userColQ = (strpos($userCol, '.') === false) ? "$tbl.$userCol" : $userCol;

    $op    = $cond['operator'] ?? '>=';
    $count = max(0, (int)($cond['count'] ?? 1));
    $opMap = ['>='=>'>=', '>'=>'>', '<='=>'<=', '<'=>'<', '='=>'='];
    if (!isset($opMap[$op])) $op = '>=';

    /* day window */
    [$ds, $de] = resolveDay($cond['day'] ?? null);
    $whereParts = [];
    if ($where !== '') $whereParts[] = $where;
    if ($ds && $de)    $whereParts[] = "$dateCol BETWEEN '" . esc($ds) . " 00:00:00' AND '" . esc($de) . " 23:59:59'";

    /* payload filter — single filter per condition (legacy `filters[]` still supported) */
    $allFilters = !empty($cond['filter']) ? [$cond['filter']] : ($cond['filters'] ?? []);
    foreach ($allFilters as $f) {
        if (!$f) continue;
        $pkey = $f['payload'] ?? '';
        $pop  = $f['op']      ?? 'is';
        $pval = $f['value']   ?? '';
        $col  = $PAYLOAD_COLUMNS[$event][$pkey] ?? null;
        if (!$col) continue;
        $valE = esc($pval);
        switch ($pop) {
            case 'exists':         $whereParts[] = "$col IS NOT NULL AND $col <> ''"; break;
            case 'does not exist': $whereParts[] = "($col IS NULL OR $col = '')";     break;
            case 'is':             $whereParts[] = "$col = '$valE'";                  break;
            case 'is not':         $whereParts[] = "$col <> '$valE'";                 break;
            case 'contains':       $whereParts[] = "$col LIKE '%$valE%'";             break;
            case 'does not contain': $whereParts[] = "$col NOT LIKE '%$valE%'";       break;
        }
    }

    $whereSql = $whereParts ? 'WHERE ' . implode(' AND ', $whereParts) : '';

    /* If the source brings in users via its own `join`, no extra users-join is needed.
       Otherwise, when a payload column references users.* and the source isn't users,
       LEFT-JOIN users on user_id. */
    $extraJoin = '';
    if ($srcJoin === '' && $tbl !== 'users') {
        $needsUsersJoin = false;
        foreach (($cond['filters'] ?? []) as $f) {
            $col = $PAYLOAD_COLUMNS[$event][$f['payload'] ?? ''] ?? '';
            if (strpos($col, 'users.') === 0) { $needsUsersJoin = true; break; }
        }
        if (!$needsUsersJoin && !empty($cond['filter']['payload'])) {
            $col = $PAYLOAD_COLUMNS[$event][$cond['filter']['payload']] ?? '';
            if (strpos($col, 'users.') === 0) $needsUsersJoin = true;
        }
        if ($needsUsersJoin) $extraJoin = "LEFT JOIN users ON users.user_id = $userColQ";
    }

    /* Group + count comparison */
    $sql = "SELECT $userColQ AS user_id FROM $tbl $srcJoin $extraJoin $whereSql GROUP BY $userColQ HAVING COUNT(*) $op $count";

    /* did_not_do → invert: users NOT IN (the above).
       NOT IN against a set holding a NULL matches nobody, so NULL user_ids are dropped first. */
    if (($cond['did'] ?? 'did') === 'did_not_do') {
        $sql = "SELECT u.user_id FROM users u WHERE u.user_id NOT IN (SELECT nd.user_id FROM ($sql) AS nd WHERE nd.user_id IS NOT NULL)";
    }
    return $sql;
}

/* Combine sub-queries (each yielding user_ids) by walking left-to-right with AND/OR.
   AND → IN (next), OR → UNION. */
function combineByConnector($items) {
    if (!$items) return null;
    $current = $items[0]['sql'];
    for ($i = 1; $i < count($items); $i++) {
        $next = $items[$i]['sql'];
        if (($items[$i]['connector'] ?? 'AND') === 'OR') {
            $current = "($current) UNION ($next)";
        } else {
            $current = "SELECT user_id FROM ($current) AS a WHERE user_id IN ($next)";
        }
    }
    return $current;
}

function combineConditions($conds) {
    $items = [];
    foreach ($conds as $i => $c) {
        $s = buildConditionSql($c);
        if (!$s) continue;
        $items[] = ['connector' => $i === 0 ? null : ($c['condConnector'] ?? 'AND'), 'sql' => $s];
    }
    return combineByConnector($items);
}

function combineBlocks($blocks) {
    $items = [];
    foreach ($blocks as $i => $b) {
        $s = combineConditions($b['conditions'] ?? []);
        if (!$s) continue;
        $items[] = ['connector' => $i === 0 ? null : ($b['blockConnector'] ?? 'AND'), 'sql' => $s];
    }
    $merged = combineByConnector($items);
    return $merged ? "SELECT DISTINCT user_id FROM ($merged) AS final_set" : null;
}

/* Build full SQL: include MINUS exclude. Final result excludes users whose users.active = 0. */
function buildSegmentSql($config) {
    $inc = combineBlocks($config['include']['blocks'] ?? []);
    if (!$inc) return null;
    $exc = combineBlocks($config['exclude']['blocks'] ?? []);
    $base = $exc
        ? "SELECT user_id FROM ($inc) AS inc WHERE user_id NOT IN (SELECT user_id FROM ($exc) AS exc WHERE user_id IS NOT NULL)"
        : $inc;

    /* drop inactive users from the final segment (active = 0 → excluded; NULL/missing → kept) */
    return "SELECT s.user_id
            FROM ($base) AS s
            INNER JOIN users u ON u.user_id = s.user_id
            WHERE COALESCE(u.active, 1) <> 0";
}

function countSegment($config) {
    global $conn;
    $sql = buildSegmentSql($config);
    if (!$sql) return 0;
    $r = mysqli_query($conn, "SELECT COUNT(*) AS c FROM ($sql) AS s");
    if (!$r) return 0;
    return (int)mysqli_fetch_assoc($r)['c'];
}

/* counts: total, with email, with phone */
function channelCounts($config) {
    global $conn;
    $sql = buildSegmentSql($config);
    if (!$sql) return ['total' => 0, 'email' => 0, 'phone' => 0];
    $q = "SELECT
            COUNT(*) AS total,
            SUM(CASE WHEN u.email IS NOT NULL AND u.email <> '' THEN 1 ELSE 0 END) AS email_c,
            SUM(CASE WHEN u.phone IS NOT NULL AND u.phone <> '' THEN 1 ELSE 0 END) AS phone_c
          FROM ($sql) AS s INNER JOIN users u ON u.user_id = s.user_id";
    $r = mysqli_query($conn, $q);
    if (!$r) return ['total' => 0, 'email' => 0, 'phone' => 0];
    $row = mysqli_fetch_assoc($r);
    return [
        'total' => (int)$row['total'],
        'email' => (int)$row['email_c'],
        'phone' => (int)$row['phone_c'],
    ];
}

/* idempotent: add columns to netcore_segments if not present */
function ensureSchema() {
    global $conn;
    $r = mysqli_query($conn, "SHOW COLUMNS FROM netcore_segments LIKE 'email_count'");
    if (!$r || mysqli_num_rows($r) === 0) {
        mysqli_query($conn, "ALTER TABLE netcore_segments
                             ADD COLUMN email_count INT NOT NULL DEFAULT 0,
                             ADD COLUMN phone_count INT NOT NULL DEFAULT 0");
    }
}
ensureSchema();

/* ════════════════════════════════════════
   ROUTING
═══════════════════════════════════════ */
$action = jin('action', '');

if ($action === 'list') {
    $page    = max(1, (int)jin('page', 1));
    $perPage = max(1, min(100, (int)jin('per_page', 10)));
    $search  = trim((string)jin('search', ''));
    $sort    = jin('sort', '');     /* '' | 'created_at' | 'refreshed' */
    $order   = strtolower(jin('order', 'desc')) === 'asc' ? 'ASC' : 'DESC';
    $offset  = ($page - 1) * $perPage;

    $where = '';
    if ($search !== '') {
        $s = esc($search);
        $where = "WHERE name LIKE '%$s%'";
    }

    $orderBy = "ORDER BY id DESC";
    if ($sort === 'created_at') $orderBy = "ORDER BY created_at $order";
    if ($sort === 'refreshed')  $orderBy = "ORDER BY user_count_refreshed_at $order";

    $tr = mysqli_query($conn, "SELECT COUNT(*) AS c FROM netcore_segments $where");
    $total = $tr ? (int)mysqli_fetch_assoc($tr)['c'] : 0;

    $r = mysqli_query($conn, "SELECT id, name, contact_type, user_count, email_count, phone_count,
                                     user_count_refreshed_at, created_at, updated_at
                              FROM netcore_segments
                              $where
                              $orderBy LIMIT $perPage OFFSET $offset");
    $rows = [];
    while ($r && $row = mysqli_fetch_assoc($r)) $rows[] = $row;
    ok([
        'segments' => $rows,
        'total'    => $total,
        'page'     => $page,
        'per_page' => $perPage,
        'pages'    => $total > 0 ? (int)ceil($total / $perPage) : 1,
    ]);
}

if ($action === 'get') {
    $id = (int)jin('id', 0);
    $r = mysqli_query($conn, "SELECT * FROM netcore_segments WHERE id=$id LIMIT 1");
    $row = $r ? mysqli_fetch_assoc($r) : null;
    if (!$row) fail('Not found', 404);
    $row['config'] = json_decode($row['config'], true);
    ok(['segment' => $row]);
}

if ($action === 'engagement_options') {
    /* campaigns / journeys / tags / lists / segments for the Engagement + Contacts pickers */
    ok(seg_engagement_options());
}

if ($action === 'count') {
    $config = json_decode(jin('config', ''), true);
    if (!is_array($config)) fail('Invalid config');
    /* Same membership SQL as countSegment(), but a failed query is reported instead of coming
       back as a confident "0 users", and the email / phone reach is returned alongside. */
    $sql = buildSegmentSql($config);
    if (!$sql) ok(['count' => 0, 'email_count' => 0, 'phone_count' => 0]);
    try {
        $r = mysqli_query($conn, "SELECT COUNT(*) AS total,
                                         SUM(CASE WHEN u.email IS NOT NULL AND u.email <> '' THEN 1 ELSE 0 END) AS email_c,
                                         SUM(CASE WHEN u.phone IS NOT NULL AND u.phone <> '' THEN 1 ELSE 0 END) AS phone_c
                                  FROM ($sql) AS s INNER JOIN users u ON u.user_id = s.user_id");
    } catch (\Throwable $e) {
        fail('Count failed: ' . $e->getMessage(), 422);
    }
    if (!$r) fail('Count failed: ' . mysqli_error($conn), 422);
    $row = mysqli_fetch_assoc($r);
    ok(['count' => (int)$row['total'], 'email_count' => (int)$row['email_c'], 'phone_count' => (int)$row['phone_c']]);
}

if ($action === 'save') {
    $id          = (int)jin('id', 0);
    $name        = trim((string)jin('name', ''));
    $contactType = trim((string)jin('contact_type', 'all_identified'));
    $config      = jin('config', '');
    if ($name === '')       fail('Name required');
    $cfgArr = json_decode($config, true);
    if (!$cfgArr) fail('Invalid config JSON');
    if ($id > 0 && seg_config_creates_cycle($cfgArr, $id)) {
        fail('This segment cannot include itself (directly or through another segment).');
    }

    try { $ch = channelCounts($cfgArr); }
    catch (\Throwable $e) { fail('Could not compute the segment: ' . $e->getMessage(), 422); }
    $nameE = esc($name); $ctE = esc($contactType); $cfgE = esc($config);
    $now   = date('Y-m-d H:i:s');

    if ($id > 0) {
        mysqli_query($conn, "UPDATE netcore_segments
                             SET name='$nameE', contact_type='$ctE', config='$cfgE',
                                 user_count={$ch['total']}, email_count={$ch['email']}, phone_count={$ch['phone']},
                                 user_count_refreshed_at='$now'
                             WHERE id=$id");
    } else {
        mysqli_query($conn, "INSERT INTO netcore_segments (name, contact_type, config, user_count, email_count, phone_count, user_count_refreshed_at)
                             VALUES ('$nameE', '$ctE', '$cfgE', {$ch['total']}, {$ch['email']}, {$ch['phone']}, '$now')");
        $id = mysqli_insert_id($conn);
    }
    ok(['id' => $id, 'count' => $ch['total'], 'email_count' => $ch['email'], 'phone_count' => $ch['phone'], 'refreshed_at' => $now]);
}

if ($action === 'delete') {
    $id = (int)jin('id', 0);
    if (!$id) fail('id required');
    mysqli_query($conn, "DELETE FROM netcore_segments WHERE id=$id");
    ok([]);
}

if ($action === 'duplicate') {
    $id = (int)jin('id', 0);
    $r = mysqli_query($conn, "SELECT name, contact_type, config FROM netcore_segments WHERE id=$id LIMIT 1");
    $row = $r ? mysqli_fetch_assoc($r) : null;
    if (!$row) fail('Not found', 404);
    $name = esc($row['name'] . ' (Copy)');
    $ct   = esc($row['contact_type']);
    $cfg  = esc($row['config']);
    mysqli_query($conn, "INSERT INTO netcore_segments (name, contact_type, config) VALUES ('$name','$ct','$cfg')");
    ok(['id' => mysqli_insert_id($conn)]);
}

if ($action === 'refresh') {
    $id = (int)jin('id', 0);
    $r = mysqli_query($conn, "SELECT config FROM netcore_segments WHERE id=$id LIMIT 1");
    $row = $r ? mysqli_fetch_assoc($r) : null;
    if (!$row) fail('Not found', 404);
    try { $ch = channelCounts(json_decode($row['config'], true)); }
    catch (\Throwable $e) { fail('Could not compute the segment: ' . $e->getMessage(), 422); }
    $now = date('Y-m-d H:i:s');
    mysqli_query($conn, "UPDATE netcore_segments
                         SET user_count={$ch['total']}, email_count={$ch['email']}, phone_count={$ch['phone']},
                             user_count_refreshed_at='$now'
                         WHERE id=$id");
    ok(['count' => $ch['total'], 'email_count' => $ch['email'], 'phone_count' => $ch['phone'], 'refreshed_at' => $now]);
}

if ($action === 'users') {
    /* paginated users for a segment, optionally filtered to a channel (email/sms/whatsapp) */
    $id      = (int)jin('id', 0);
    $page    = max(1, (int)jin('page', 1));
    $perPage = max(1, min(200, (int)jin('per_page', 25)));
    $channel = jin('channel', '');   /* '', 'email', 'sms', 'whatsapp' */
    $search  = trim((string)jin('search', ''));
    $offset  = ($page - 1) * $perPage;

    $r = mysqli_query($conn, "SELECT name, config FROM netcore_segments WHERE id=$id LIMIT 1");
    $seg = $r ? mysqli_fetch_assoc($r) : null;
    if (!$seg) fail('Not found', 404);
    $sql = buildSegmentSql(json_decode($seg['config'], true));
    if (!$sql) ok(['total' => 0, 'page' => 1, 'pages' => 1, 'users' => [], 'name' => $seg['name']]);

    $whereExtra = '';
    if ($channel === 'email') {
        $whereExtra = "AND u.email IS NOT NULL AND u.email <> ''";
    } elseif ($channel === 'sms' || $channel === 'whatsapp') {
        $whereExtra = "AND u.phone IS NOT NULL AND u.phone <> ''";
    }
    if ($search !== '') {
        $s = esc($search);
        if (strpos($search, '@') !== false)        $whereExtra .= " AND u.email = '$s'";
        elseif (preg_match('/^\d+$/', $search))    $whereExtra .= strlen($search) >= 10 ? " AND u.phone = '$s'" : " AND u.user_id = '$s'";
        else                                       $whereExtra .= " AND (u.fname LIKE '$s%' OR u.lname LIKE '$s%')";
    }

    $base = "FROM ($sql) AS s INNER JOIN users u ON u.user_id = s.user_id WHERE 1=1 $whereExtra";

    $tr = mysqli_query($conn, "SELECT COUNT(*) AS c $base");
    $total = $tr ? (int)mysqli_fetch_assoc($tr)['c'] : 0;

    $listSql = "SELECT u.user_id, u.email, u.phone AS mobile, u.fname AS first_name, u.lname AS last_name,
                       u.state, u.country, u.registered_at AS register_date
                $base
                ORDER BY u.registered_at DESC
                LIMIT $perPage OFFSET $offset";
    $lr = mysqli_query($conn, $listSql);
    $users = [];
    while ($lr && $row = mysqli_fetch_assoc($lr)) {
        if (!empty($row['register_date'])) $row['register_date'] = substr($row['register_date'], 0, 10);
        $users[] = $row;
    }

    ok([
        'name'  => $seg['name'],
        'total' => $total,
        'page'  => $page,
        'per_page' => $perPage,
        'pages' => $total > 0 ? (int)ceil($total / $perPage) : 1,
        'users' => $users,
    ]);
}

if ($action === 'users_csv') {
    /* full CSV export of a segment's users (optionally per channel) */
    $id      = (int)jin('id', 0);
    $channel = jin('channel', '');
    $r = mysqli_query($conn, "SELECT name, config FROM netcore_segments WHERE id=$id LIMIT 1");
    $seg = $r ? mysqli_fetch_assoc($r) : null;
    if (!$seg) fail('Not found', 404);
    $sql = buildSegmentSql(json_decode($seg['config'], true));
    if (!$sql) fail('Empty segment');
    $whereExtra = '';
    if ($channel === 'email')                       $whereExtra = "AND u.email IS NOT NULL AND u.email <> ''";
    elseif ($channel === 'sms' || $channel === 'whatsapp') $whereExtra = "AND u.phone IS NOT NULL AND u.phone <> ''";

    $filename = preg_replace('/[^a-zA-Z0-9_]+/', '_', $seg['name']) . ($channel ? "_$channel" : '') . '.csv';
    header('Content-Type: text/csv; charset=utf-8');
    header("Content-Disposition: attachment; filename=\"$filename\"");
    $out = fopen('php://output', 'w');
    fputcsv($out, ['user_id','email','mobile','first_name','last_name','state','country','register_date']);
    $q = "SELECT u.user_id, u.email, u.phone, u.fname, u.lname, u.state, u.country, u.registered_at
          FROM ($sql) AS s INNER JOIN users u ON u.user_id = s.user_id WHERE 1=1 $whereExtra";
    $res = mysqli_query($conn, $q);
    while ($res && $row = mysqli_fetch_assoc($res)) fputcsv($out, $row);
    fclose($out);
    exit;
}

if ($action === 'download') {
    $id = (int)jin('id', 0);
    $r = mysqli_query($conn, "SELECT name, config FROM netcore_segments WHERE id=$id LIMIT 1");
    $row = $r ? mysqli_fetch_assoc($r) : null;
    if (!$row) fail('Not found', 404);
    $sql = buildSegmentSql(json_decode($row['config'], true));
    if (!$sql) fail('Empty segment');

    /* stream as CSV */
    $filename = preg_replace('/[^a-zA-Z0-9_]+/', '_', $row['name']) . '.csv';
    header('Content-Type: text/csv; charset=utf-8');
    header("Content-Disposition: attachment; filename=\"$filename\"");
    $out = fopen('php://output', 'w');
    fputcsv($out, ['user_id', 'email', 'fname', 'lname', 'phone', 'registered_at']);

    $q = "SELECT u.user_id, u.email, u.fname, u.lname, u.phone, u.registered_at
          FROM users u INNER JOIN ($sql) AS s ON s.user_id = u.user_id";
    $res = mysqli_query($conn, $q);
    if ($res) while ($r = mysqli_fetch_assoc($res)) fputcsv($out, $r);
    fclose($out);
    exit;
}

fail('Invalid action');
?>

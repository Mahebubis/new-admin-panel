<?php
/*
 * /api/journeys/lib/JourneyDispatch.php
 *
 * Everything between "the engine decided to send" and "the provider answered".
 *
 * Message nodes never call a transport directly. They call journey_dispatch(),
 * which runs the same five gates in the same order every time:
 *
 *   1. control group   — held-out students walk the graph but receive nothing
 *   2. address         — no email / no phone is a suppression, not a crash
 *   3. frequency cap   — SKIP the message, keep the student (see below)
 *   4. DND             — HOLD the message to the end of the quiet window
 *   5. idempotency     — one row per (entry, node, attempt), inserted before the send
 *
 * ── Two deliberate departures from Netcore ───────────────────────────────────
 *
 * Frequency cap: Netcore REMOVES a user from the journey when a message is
 * capped. A student who hits their daily cap at step 3 of a 7-step onboarding
 * silently loses the remaining four. We skip the message, log
 * suppress_reason='frequency_cap', and continue to the next node. Per-journey
 * ignore_fc / counts_toward_fc (MoEngage's model) let operational journeys —
 * exam-day, payment failure — bypass the cap while still counting toward it for
 * marketing ones.
 *
 * DND: messages are HELD, not dropped, exactly as Netcore does. A send that
 * lands inside a quiet window is rescheduled to the moment the window ends, so a
 * Saturday-night trigger goes out Monday morning rather than vanishing.
 * Evaluated in the journey's timezone (default Asia/Kolkata), not the student's —
 * a single-country student base does not justify per-user timezones.
 */

require_once __DIR__ . '/../../../config/database.php';
require_once __DIR__ . '/JourneyGraph.php';
require_once __DIR__ . '/JourneyConditions.php';
// Explicit, not left to load order: journey_attr_campaign_id() and JOURNEY_ATTR_MEDIUM are used
// in the WhatsApp send below, and today they happen to be loaded first only because JourneyEngine
// requires them a line later. That is a fatal waiting for the day something loads this file alone.
require_once __DIR__ . '/JourneyWebhookSink.php';

require_once __DIR__ . '/../../campaigns/lib/config.php';
require_once __DIR__ . '/../../campaigns/lib/MergeTags.php';
require_once __DIR__ . '/../../campaigns/lib/TrackingRewriter.php';
require_once __DIR__ . '/../../campaigns/lib/EspTransport.php';
require_once __DIR__ . '/../../campaigns/lib/TransportFactory.php';
require_once __DIR__ . '/../../campaigns/lib/AudienceResolver.php';
require_once __DIR__ . '/../../campaigns/lib/EmailVerifier.php';
require_once __DIR__ . '/../../campaigns/lib/Unsubscribe.php';
require_once __DIR__ . '/../../campaigns/lib/Alerts.php';
require_once __DIR__ . '/../../campaigns/lib/ProviderFailover.php';

if (!defined('JOURNEYS_PUBLIC_BASE_URL')) {
    define('JOURNEYS_PUBLIC_BASE_URL', 'https://cit3.internshipstudio.com/admin/react-api/api/journeys');
}
/** Sends are attempted at most this many times before the message is marked failed. */
if (!defined('JOURNEY_MAX_SEND_ATTEMPTS')) define('JOURNEY_MAX_SEND_ATTEMPTS', 3);

/* ════════════════════════════════════════════════════════════════════════════
   Result shape
   Every function here returns one of these, and the engine branches on 'outcome':
     sent       → take the node's Sent / Called branch
     failed     → take the Failed branch
     suppressed → take the Sent branch anyway (the student continues; only the
                  message was withheld) and record why
     hold       → do not advance; re-queue the same node at 'retry_at' (DND)
   ═══════════════════════════════════════════════════════════════════════════ */
function journey_result(string $outcome, string $detail = '', array $extra = []): array {
    return array_merge(['outcome' => $outcome, 'detail' => $detail], $extra);
}

/* ════════════════════════════════════════════════════════════════════════════
   Gate 3 — frequency capping
   ═══════════════════════════════════════════════════════════════════════════ */

/**
 * How many journey messages this student has already been SENT today, counting
 * only journeys whose counts_toward_fc is on. Deliberately counts across all
 * journeys, not just this one: a cap that only looks at its own journey is not a
 * cap, it is a per-journey quota.
 */
function journey_messages_today(int $userId, string $channel, string $scope = 'channel'): int {
    global $conn;
    if ($userId <= 0) return 0;
    // 'channel' scope counts only sends on the same channel, so a WhatsApp step cannot
    // consume the allowance an email step was relying on.
    $chWhere = $scope === 'all' ? '' : " AND m.channel = '" . $conn->real_escape_string($channel) . "'";
    $r = @$conn->query("SELECT COUNT(*) c
                          FROM journey_messages m
                          INNER JOIN journeys j ON j.id = m.journey_id
                         WHERE m.user_id = " . (int)$userId . "
                           AND m.status = 'sent'
                           AND m.sent_at >= CURDATE()
                           AND j.counts_toward_fc = 1"
                         . $chWhere);
    $row = $r ? $r->fetch_assoc() : null;
    return (int)($row['c'] ?? 0);
}

/* ════════════════════════════════════════════════════════════════════════════
   Gate 4 — Do Not Disturb
   ═══════════════════════════════════════════════════════════════════════════ */

/** The single account-level DND row, or null. Read once per request. */
function journey_dnd_account(): ?array {
    global $conn;
    static $row = null, $loaded = false;
    if ($loaded) return $row;
    $loaded = true;
    $r = @$conn->query("SELECT * FROM journey_account_dnd WHERE id = 1 LIMIT 1");
    $row = $r ? ($r->fetch_assoc() ?: null) : null;
    return $row;
}

/**
 * Which schedules actually govern this journey, and in which timezone.
 *
 * ── What changed, and why it was wrong before ────────────────────────────────
 * The account schedule used to apply ONLY when enforce_all was also on. Anything else —
 * an account schedule switched on, enforce left off, journeys that had never had their
 * own quiet hours configured — held nothing, at any hour, on any journey. That is the
 * whole of "global DND is not working": the screen said quiet hours were on, and the
 * only setting that made them do anything was a second checkbox described as an override.
 *
 * A global setting has to be the FLOOR, not an opt-in. So:
 *
 *   1. The account schedule applies to every journey that has not explicitly opted out
 *      (ignore_dnd). Switching it on is enough; nothing else has to be touched.
 *   2. enforce_all now means what the word says — even an ignore_dnd journey obeys it.
 *      That is the setting you turn on to be able to state, without checking forty
 *      journeys, that students are never messaged overnight.
 *   3. A journey's own schedule applies on top of the account's, not instead of it.
 *
 * Point 3 is why this returns a LIST. Two schedules that both apply are a UNION of quiet
 * windows, not a contest one of them wins: if either says "not now", the answer is not
 * now. Letting the journey's schedule REPLACE the account's would mean a journey could
 * open up an hour the account had closed, which is the one thing a global quiet-hours
 * rule must never allow.
 *
 * The timezone is the journey's, because a window is meaningless without one and the
 * journey is the thing that has a timezone. The account row carries one only so the
 * settings screen can show which clock the windows will be read against.
 *
 * @return array{0: array<int,array>, 1: string} [list of config arrays, timezone name]
 */
function journey_dnd_effective_config(array $journey): array {
    $tz = (string)($journey['timezone'] ?: 'Asia/Kolkata');
    $acct = journey_dnd_account();

    $decode = static function ($json): array {
        $v = json_decode((string)($json ?? '[]'), true);
        return is_array($v) ? $v : [];
    };
    /** A config of seven all-disabled days is the same as no config — don't return it. */
    $hasWindow = static function (array $cfg): bool {
        foreach ($cfg as $row) if (!empty($row['enabled'])) return true;
        return false;
    };

    $schedules = [];

    $acctOn      = $acct && !empty($acct['enabled']);
    $acctEnforce = $acctOn && !empty($acct['enforce_all']);
    $journeyOptsOut = !empty($journey['ignore_dnd']);

    if ($acctOn && (!$journeyOptsOut || $acctEnforce)) {
        $cfg = $decode($acct['config']);
        if ($hasWindow($cfg)) $schedules[] = $cfg;
    }

    if (!empty($journey['dnd_enabled']) && !$journeyOptsOut) {
        $cfg = $decode($journey['dnd_config'] ?? '[]');
        if ($hasWindow($cfg)) $schedules[] = $cfg;
    }

    return [$schedules, $tz];
}

/**
 * If $whenTs falls inside a blocking window, returns the timestamp the message may go
 * out. Returns null when the send is allowed now.
 *
 * With two schedules in play the answer is the LATEST end among the windows that are
 * currently blocking — releasing at the earlier of the two would let a message out while
 * the other schedule was still quiet.
 *
 * The config is [{day:0..6 (Sun..Sat), enabled, from:'HH:MM', to:'HH:MM'}], and the days
 * listed are the days DND APPLIES on — the window is the period messages are held back,
 * not the period they are allowed. Unselected days have no restriction at all. (This is
 * the part everyone reads backwards, including the reference product's own field label.)
 *
 * A window whose `to` is earlier than its `from` spans midnight and is checked as two
 * intervals — [from, 24:00) today and [00:00, to) tomorrow — which is the case the naive
 * implementation always gets wrong.
 */
function journey_dnd_hold_until(array $journey, int $whenTs): ?int {
    [$schedules, $tzName] = journey_dnd_effective_config($journey);
    if (!$schedules) return null;

    $latest = null;
    foreach ($schedules as $cfg) {
        $end = journey_dnd_window_end($cfg, $tzName, $whenTs);
        if ($end !== null && ($latest === null || $end > $latest)) $latest = $end;
    }
    return $latest;
}

/** One schedule, one instant: the end of the blocking window it is inside, or null. */
function journey_dnd_window_end(array $cfg, string $tzName, int $whenTs): ?int {
    if (!$cfg) return null;

    $tz  = new DateTimeZone($tzName);
    $now = (new DateTime('@' . $whenTs))->setTimezone($tz);

    $byDay = [];
    foreach ($cfg as $row) $byDay[(int)($row['day'] ?? -1)] = $row;

    $mins = fn(string $hm) => (int)substr($hm, 0, 2) * 60 + (int)substr($hm, 3, 2);

    // Check today's window, and yesterday's if it crossed midnight into today.
    for ($back = 0; $back <= 1; $back++) {
        $day  = (clone $now)->modify("-$back day");
        $dow  = (int)$day->format('w');
        $row  = $byDay[$dow] ?? null;
        if (!$row || empty($row['enabled'])) continue;

        $from = $mins((string)($row['from'] ?? '21:00'));
        $to   = $mins((string)($row['to']   ?? '09:30'));
        $cur  = (int)$now->format('G') * 60 + (int)$now->format('i');

        if ($from === $to) continue;                     // zero-length window blocks nothing

        if ($from < $to) {
            if ($back > 0) continue;                     // same-day window, yesterday is irrelevant
            if ($cur >= $from && $cur < $to) {
                $end = (clone $now)->setTime(intdiv($to, 60), $to % 60, 0);
                return $end->getTimestamp();
            }
        } else {
            // Spans midnight.
            if ($back === 0 && $cur >= $from) {          // evening portion → ends tomorrow morning
                $end = (clone $now)->modify('+1 day')->setTime(intdiv($to, 60), $to % 60, 0);
                return $end->getTimestamp();
            }
            if ($back === 1 && $cur < $to) {             // morning portion of yesterday's window
                $end = (clone $now)->setTime(intdiv($to, 60), $to % 60, 0);
                return $end->getTimestamp();
            }
        }
    }
    return null;
}

/**
 * Release — or re-time — everyone currently held by quiet hours.
 *
 * THIS IS THE HALF THAT WAS MISSING, and the reason turning DND off appeared to do
 * nothing. A held student is a journey_waits row with a wake_at set to the end of the
 * window that was in force WHEN THEY WERE HELD. Change the schedule — shorten it, switch
 * the journey's off, switch the account's off entirely — and every one of those rows
 * still sits there until its original wake_at, so the change takes effect somewhere
 * between an hour and a day later, for nobody's benefit and with nothing on screen to
 * explain the delay.
 *
 * So the schedule is re-evaluated against every dnd_hold row:
 *
 *   no longer inside any window → wake_at = NOW(). They go out on the very next tick,
 *                                 which is what "turn DND off and the queue drains" means.
 *   still held, different end   → wake_at moves to the new end, so a schedule that was
 *                                 extended holds them for the whole of the new window
 *                                 rather than releasing them mid-way through it.
 *
 * Called on every worker tick (so the release happens within a minute of a window
 * closing, without anybody pressing anything) and directly from the two save paths, so
 * pressing Save on the quiet-hours screen has a visible, immediate effect.
 *
 * @param int|null $onlyJourneyId limit to one journey, for the per-journey settings save
 * @return array{released:int, retimed:int}
 */
function journey_dnd_release_holds(?int $onlyJourneyId = null): array {
    global $conn;

    $where = "w.status = 'pending' AND w.reason = 'dnd_hold'";
    if ($onlyJourneyId) $where .= ' AND w.journey_id = ' . (int)$onlyJourneyId;

    $q = @$conn->query("SELECT w.id, w.journey_id, w.wake_at,
                               j.timezone, j.dnd_enabled, j.dnd_config, j.ignore_dnd
                          FROM journey_waits w
                          INNER JOIN journeys j ON j.id = w.journey_id
                         WHERE $where
                         LIMIT 5000");
    if (!$q) return ['released' => 0, 'retimed' => 0];

    $now = time();
    $released = 0; $retimed = 0;
    while ($row = $q->fetch_assoc()) {
        $journey = [
            'timezone'    => $row['timezone'],
            'dnd_enabled' => $row['dnd_enabled'],
            'dnd_config'  => $row['dnd_config'],
            'ignore_dnd'  => $row['ignore_dnd'],
        ];
        $holdUntil = journey_dnd_hold_until($journey, $now);

        if ($holdUntil === null) {
            @$conn->query("UPDATE journey_waits SET wake_at = NOW() WHERE id = " . (int)$row['id']
                          . " AND status = 'pending'");
            $released++;
            continue;
        }
        $newWake = date('Y-m-d H:i:s', $holdUntil);
        if ($newWake !== (string)$row['wake_at']) {
            @$conn->query("UPDATE journey_waits SET wake_at = '" . $conn->real_escape_string($newWake) . "'
                            WHERE id = " . (int)$row['id'] . " AND status = 'pending'");
            $retimed++;
        }
    }

    if ($released || $retimed) {
        journey_dnd_log("quiet-hours sweep: released $released, re-timed $retimed"
            . ($onlyJourneyId ? " (journey #$onlyJourneyId)" : ''));
    }
    return ['released' => $released, 'retimed' => $retimed];
}

/** How many students are being held right now, and by which journey — the Outbox reads this. */
function journey_dnd_held_summary(?int $onlyJourneyId = null): array {
    global $conn;
    $where = "status = 'pending' AND reason = 'dnd_hold'";
    if ($onlyJourneyId) $where .= ' AND journey_id = ' . (int)$onlyJourneyId;
    $r = @$conn->query("SELECT COUNT(*) c, MIN(wake_at) next_release FROM journey_waits WHERE $where");
    $row = $r ? $r->fetch_assoc() : null;
    return ['held' => (int)($row['c'] ?? 0), 'next_release' => $row['next_release'] ?? null];
}

function journey_dnd_log(string $msg): void {
    if (function_exists('journey_log')) { journey_log('[dnd] ' . $msg); return; }
    error_log('[journey/dnd] ' . $msg);
}

/* ════════════════════════════════════════════════════════════════════════════
   Message row bookkeeping
   ═══════════════════════════════════════════════════════════════════════════ */

/**
 * Claim the right to send. The UNIQUE index on idem_key is the actual guard: two
 * worker ticks racing on the same entry both try this INSERT and exactly one wins.
 * The loser gets null and skips the send entirely — which is what stops the
 * duplicate-message failure Netcore documents (A9.2) from ever being possible here.
 */
function journey_claim_message(array $ctx, string $channel, ?string $toAddr): ?array {
    global $conn;

    $idem = $ctx['entry_id'] . ':' . $ctx['node_id'] . ':' . (int)($ctx['attempt'] ?? 1);
    $rid  = bin2hex(random_bytes(16));

    $stmt = $conn->prepare(
        "INSERT INTO journey_messages (journey_id, entry_id, node_id, user_id, channel, to_addr, rid, idem_key, status, variant)
         VALUES (?,?,?,?,?,?,?,?, 'queued', ?)"
    );
    if (!$stmt) return null;

    $jid = (int)$ctx['journey_id']; $eid = (int)$ctx['entry_id'];
    $nid = (string)$ctx['node_id']; $uid = (int)($ctx['user_id'] ?? 0);
    $to  = (string)($toAddr ?? '');
    $var = (string)($ctx['variant'] ?? '');
    $stmt->bind_param('iisisssss', $jid, $eid, $nid, $uid, $channel, $to, $rid, $idem, $var);

    $ok = @$stmt->execute();
    $id = $ok ? (int)$conn->insert_id : 0;
    $stmt->close();

    if (!$ok || !$id) return null;                    // duplicate idem_key → someone else owns this send
    return ['id' => $id, 'rid' => $rid];
}

function journey_message_suppress(array $ctx, string $channel, ?string $toAddr, string $reason, string $detail = ''): array {
    global $conn;
    $claim = journey_claim_message($ctx, $channel, $toAddr);
    if ($claim) {
        $r = $conn->real_escape_string($reason);
        $d = $conn->real_escape_string(mb_substr($detail, 0, 480));
        @$conn->query("UPDATE journey_messages
                          SET status='suppressed', suppress_reason='$r', error_message='$d'
                        WHERE id=" . (int)$claim['id']);
        @$conn->query("UPDATE journeys SET suppressed_count = suppressed_count + 1 WHERE id=" . (int)$ctx['journey_id']);
    }
    return journey_result('suppressed', $detail !== '' ? $detail : $reason, ['reason' => $reason]);
}

// bounce vs rejection, shared with the webhook sink so both roads classify the same event alike.
require_once __DIR__ . '/JourneyFailureKind.php';

function journey_message_mark(int $messageId, string $status, array $fields = []): void {
    global $conn;
    $sets = ["status='" . $conn->real_escape_string($status) . "'"];
    if ($status === 'sent') $sets[] = 'sent_at = NOW()';
    // A failure that means "this address/number cannot receive" is stamped as a bounce, so the
    // report can tell it apart from a provider rejection without re-reading error strings.
    if ($status === 'failed' && journey_failure_is_bounce((string)($fields['error_message'] ?? ''))) {
        $sets[] = 'bounced_at = IFNULL(bounced_at, NOW())';
    }
    $sets[] = 'attempts = attempts + 1';
    foreach ($fields as $k => $v) {
        if ($v === null) { $sets[] = "`$k` = NULL"; continue; }
        $sets[] = "`$k` = '" . $conn->real_escape_string(mb_substr((string)$v, 0, 480)) . "'";
    }
    @$conn->query("UPDATE journey_messages SET " . implode(', ', $sets) . " WHERE id = " . (int)$messageId);
}

/* ════════════════════════════════════════════════════════════════════════════
   The gate runner
   ═══════════════════════════════════════════════════════════════════════════ */

/**
 * @param array $journey  the journeys row (typed columns, not the settings blob)
 * @param array $entry    the journey_entries row
 * @param array $node     the graph node
 * @param array $ctx      ['journey_id','entry_id','node_id','user_id','attempt','variant']
 */
function journey_dispatch(array $journey, array $entry, array $node, array $ctx): array {
    // The one-per-student gate below queries directly, so the connection has to be in
    // scope. Without this it is null and every dispatch dies with "Call to a member
    // function query() on null" — which stops the entry before any message is attempted.
    global $conn;

    $T = journey_node_types();
    $channel = $T[$node['key']]['channel'] ?? null;
    if (!$channel) return journey_result('failed', 'Node ' . $node['key'] . ' is not a message node.');

    $cfg = $node['cfg'] ?? [];

    /* ── 1. control group ── */
    if (!empty($entry['is_control'])) {
        return journey_message_suppress($ctx, $channel, null, 'control_group',
            'Held out for incrementality measurement.');
    }

    /* ── 2. address ── */
    $to = $channel === 'email' ? trim((string)($entry['email'] ?? ''))
        : ($channel === 'whatsapp' ? trim((string)($entry['phone'] ?? '')) : null);

    if ($channel !== 'webhook') {
        if ($to === '' || $to === null) {
            return journey_message_suppress($ctx, $channel, null, 'no_address',
                'Student has no ' . ($channel === 'email' ? 'email address' : 'phone number') . ' on file.');
        }
        if ($channel === 'email' && journey_is_blocklisted($to)) {
            return journey_message_suppress($ctx, $channel, $to, 'blocklisted', 'Address is on the blocklist.');
        }

        /*
         * And if nobody has ever checked whether this mailbox exists, check now.
         *
         * A journey reaches addresses a campaign never touched — it is triggered by the student's
         * own activity, so it sends to whoever signed up this morning, and a registration form is
         * exactly where a mistyped address enters the system. Left alone those become hard bounces,
         * and enough of them takes the sending domain down for every other message.
         *
         * One address, so there is nothing to batch — but the verdict cache is shared with the
         * campaign path, so a student any campaign has already verified costs nothing here, and one
         * verified here is free for every campaign afterwards. A failed check is not a block: it
         * returns false and the mail goes out (see EmailVerifier.php).
         *
         * The address is blocklisted by the verifier itself, so this suppression happens once per
         * student and the ordinary blocklist gate above catches every later step.
         */
        /*
         * THE STEP decides, not the journey.
         *
         * Two email steps in one journey are two different sends with two different audiences in
         * practice: the first goes to whoever just registered, where a mistyped address is most
         * likely and checking is worth it, and the third goes a week later to people who by then
         * have already received two emails and been proved reachable. A journey-wide switch forced
         * the same answer on both and spent credits re-asking a question already answered.
         *
         * Absent means the step has never been asked — a step built before this existed — and the
         * account default in Settings applies. That is deliberately different from a step that
         * was asked and said no.
         */
        $stepWantsVerify = array_key_exists('verifyEmail', $cfg)
            ? !empty($cfg['verifyEmail'])
            : null;
        if ($channel === 'email' && function_exists('email_verify_blocks_one')
            && email_verify_blocks_one($to, $stepWantsVerify)) {
            /*
             * Its own reason rather than 'blocklisted', which it technically now is. The report
             * groups by this value, and folding the two together would hide the number that
             * actually answers "is verification worth what it costs" behind the count of people
             * who unsubscribed or bounced months ago. Every LATER step for this student reports
             * 'blocklisted' through the gate above, which is correct: by then it is simply a
             * blocklisted address like any other.
             */
            return journey_message_suppress($ctx, $channel, $to, 'unverified',
                'The address failed verification — the mailbox does not exist. It has been blocklisted.');
        }
        /*
         * The WhatsApp half of the same gate, which was simply missing: a journey would happily
         * message someone who had replied STOP, because the only opt-out check in the journey
         * engine sat inside the Reachable-on condition — a node most journeys never use. The
         * channels now suppress on the same footing, and for the same reason: consent is a
         * property of the person, not of the graph they happen to be walking.
         */
        if ($channel === 'whatsapp' && journey_wa_opted_out($to)) {
            return journey_message_suppress($ctx, $channel, $to, 'blocklisted',
                'This number replied STOP (or was opted out at the provider), so WhatsApp is blocked for them. '
                . 'They continue to the next step.');
        }
    }

    /* ── 2b. one message per student, if this journey is set that way ──
       A journey normally messages someone at every message step it walks them
       through — that IS the follow-up. This switch collapses it to a single
       message per student for the whole journey, for the case where the graph
       exists to pick ONE channel per person rather than to run a sequence. */
    if ($channel !== 'webhook' && !empty($journey['one_per_student'])) {
        $uid = (int)($entry['user_id'] ?? 0);
        if ($uid > 0) {
            $r = $conn->query("SELECT id FROM journey_messages
                                WHERE journey_id = " . (int)$journey['id'] . "
                                  AND user_id = $uid AND status = 'sent' LIMIT 1");
            if ($r && $r->num_rows > 0) {
                return journey_message_suppress($ctx, $channel, $to, 'already_messaged',
                    'This journey is set to send at most one message per student, and this student '
                    . 'already received one. They continue to the next step.');
            }
        }
    }

    /* ── 3. frequency cap ── */
    if ($channel !== 'webhook' && !empty($journey['fc_enabled']) && empty($journey['ignore_fc'])) {
        $capN  = max(1, (int)$journey['fc_max_per_day']);
        $scope = ($journey['fc_scope'] ?? 'channel') === 'all' ? 'all' : 'channel';
        $used  = journey_messages_today((int)($entry['user_id'] ?? 0), $channel, $scope);
        if ($used >= $capN) {
            // NOT an exit. The student stays in the journey and continues.
            // The reason names the scope, because "capped" without saying WHAT was
            // counted is the single most confusing message this engine can produce —
            // the cap spans every journey, so the culprit is usually somewhere else.
            $what = $scope === 'all' ? 'messages on any channel' : ucfirst($channel) . ' messages';
            return journey_message_suppress($ctx, $channel, $to, 'frequency_cap',
                "Already had $used/$capN $what today across all journeys, so this one was skipped. "
                . 'The student continues to the next step.');
        }
    }

    /* ── 4. DND ── */
    if ($channel !== 'webhook') {
        $holdUntil = journey_dnd_hold_until($journey, time());
        if ($holdUntil !== null) {
            return journey_result('hold', 'Quiet hours — held until ' . date('Y-m-d H:i', $holdUntil) . '.',
                                  ['retry_at' => $holdUntil]);
        }
    }

    /* ── 5. claim + send ── */
    $claim = journey_claim_message($ctx, $channel, $to);
    if (!$claim) {
        // Another tick already owns this exact (entry, node, attempt).
        return journey_result('suppressed', 'Already dispatched by a concurrent run.', ['reason' => 'duplicate']);
    }

    try {
        switch ($channel) {
            case 'email':    return journey_send_email($journey, $entry, $cfg, $claim, $ctx);
            case 'whatsapp': return journey_send_whatsapp($journey, $entry, $cfg, $claim, $ctx);
            case 'webhook':  return journey_call_webhook($journey, $entry, $cfg, $claim, $ctx);
        }
        journey_message_mark($claim['id'], 'suppressed', ['suppress_reason' => 'not_configured']);
        return journey_result('suppressed', ucfirst($channel) . ' has no sending provider on this server.',
                              ['reason' => 'not_configured']);
    } catch (Throwable $e) {
        journey_message_mark($claim['id'], 'failed', ['error_message' => $e->getMessage()]);
        return journey_result('failed', $e->getMessage());
    }
}

/* ════════════════════════════════════════════════════════════════════════════
   Email
   ═══════════════════════════════════════════════════════════════════════════ */

/**
 * Which ESP this ONE email step sends through, most specific answer first.
 *
 *   1. The step's own choice (cfg.provider). A journey routinely sends the welcome mail from
 *      one sender identity and the exam reminder from another, and those identities are not
 *      always verified with the same provider — so the provider belongs to the STEP, next to
 *      the sender address it goes with, not to the journey. A step pinned here keeps its
 *      provider no matter which one is flagged active in Settings, and no matter what the
 *      other email steps in the same journey are pinned to.
 *
 *   2. The route the journey was PUBLISHED against (journeys.esp_transport), for every step
 *      that has not pinned one. Reading the live setting instead meant switching the account's
 *      ESP re-routed every running journey mid-flight: a journey built and verified on SendGrid
 *      would start going out through SES with no edit and nothing on screen to say so.
 *
 *   3. Whatever is active in Settings, for journeys published before either column existed.
 *
 * An unrecognized value at any level falls through to the next rather than being handed to
 * TransportFactory, which would quietly treat it as SendGrid.
 */
function journey_email_provider(array $journey, array $cfg): string {
    $valid = fn($p) => $p !== '' && $p !== 'auto' && in_array($p, TransportFactory::PROVIDERS, true);

    $step = strtolower(trim((string)($cfg['provider'] ?? '')));
    if ($valid($step)) return $step;

    $pinned = strtolower(trim((string)($journey['esp_transport'] ?? '')));
    if ($valid($pinned)) return $pinned;

    return TransportFactory::activeProvider();
}

function journey_send_email(array $journey, array $entry, array $cfg, array $claim, array $ctx): array {
    global $conn;

    $tplRef = (string)($cfg['template'] ?? '');
    $tpl = journey_lookup_email_template($tplRef);
    if (!$tpl) {
        journey_message_mark($claim['id'], 'failed', ['error_message' => "Email template '$tplRef' not found"]);
        return journey_result('failed', "Email template '$tplRef' no longer exists.");
    }

    $provider  = journey_email_provider($journey, $cfg);
    $transport = TransportFactory::forProvider($provider);
    if (!$transport || !$transport->isConfigured()) {
        journey_message_mark($claim['id'], 'suppressed',
            ['suppress_reason' => 'not_configured', 'error_message' => "ESP '$provider' is not configured"]);
        return journey_result('suppressed', "Email provider '$provider' is not configured in Settings.",
                              ['reason' => 'not_configured']);
    }

    /*
     * Sender identity, in the same shape the campaign wizard's Content step uses:
     * a name, a local part, and a sending domain picked separately. Each piece falls
     * back to the ESP settings default when the node leaves it blank, so an existing
     * step configured before these fields existed keeps sending exactly as it did.
     */
    $sr = $conn->query("SELECT * FROM email_esp_settings WHERE provider = '" . $conn->real_escape_string($provider) . "' LIMIT 1");
    $esp = $sr ? $sr->fetch_assoc() : [];

    $defaultFrom = (string)($esp['default_sender_email'] ?? '');
    $defaultLocal = strpos($defaultFrom, '@') !== false ? substr($defaultFrom, 0, strpos($defaultFrom, '@')) : $defaultFrom;

    $fromName = trim((string)($cfg['senderName'] ?? '')) !== ''
        ? (string)$cfg['senderName'] : (string)($esp['default_sender_name'] ?? 'Internship Studio');

    $local  = trim((string)($cfg['senderLocal'] ?? '')) !== '' ? trim((string)$cfg['senderLocal']) : $defaultLocal;
    $domain = trim((string)($cfg['from'] ?? '')) !== ''
        ? trim((string)$cfg['from']) : (string)($esp['default_sending_domain'] ?? '');
    $fromEmail = ($local !== '' && $domain !== '') ? ($local . '@' . $domain) : $defaultFrom;

    $replyTo = trim((string)($cfg['replyTo'] ?? ''));
    if ($replyTo !== '' && !filter_var($replyTo, FILTER_VALIDATE_EMAIL)) $replyTo = '';

    if ($fromEmail === '') {
        journey_message_mark($claim['id'], 'suppressed',
            ['suppress_reason' => 'not_configured', 'error_message' => 'No sender address configured']);
        return journey_result('suppressed', 'No sender address is configured for email.', ['reason' => 'not_configured']);
    }

    $recipient = [
        'first_name' => $entry['first_name'] ?? '',
        'last_name'  => $entry['last_name'] ?? '',
        'email'      => $entry['email'] ?? '',
        'phone'      => $entry['phone'] ?? '',
        'user_id'    => $entry['user_id'] ?? null,
    ];

    /*
     * Customer Attributes, WITHOUT which every [NAME] token reaches the student as literal
     * text. This is the whole difference between a campaign email and a journey email: the
     * campaign senders have always passed a resolved token map as substitute_merge_tags()'s
     * third argument (see campaigns.php and SendWorker.php), and these three calls passed
     * none. The XX_..._XX identity tags were built in and worked; [FIRST_NAME], [RESULT_DATE]
     * and every other attribute rendered as their own names.
     */
    $attrTokens = journey_attribute_tokens((string)($entry['email'] ?? ''), (int)($entry['user_id'] ?? 0));

    $subject = trim((string)($cfg['subject'] ?? '')) !== ''
        ? (string)$cfg['subject'] : (string)($tpl['subject_default'] ?? $tpl['name']);
    $subject = substitute_merge_tags($subject, $recipient, $attrTokens);
    $html    = substitute_merge_tags((string)$tpl['body_html'], $recipient, $attrTokens);

    // The hidden pre-header is the text most inboxes show next to the subject line, so
    // it has to be spliced into the HTML itself — storing it on the node is not enough.
    $preheader = trim((string)($cfg['preheader'] ?? ''));
    if ($preheader !== '') $html = inject_preheader($html, substitute_merge_tags($preheader, $recipient, $attrTokens));

    // Same open-pixel + click-rewrite pipeline the campaigns use, pointed at this
    // feature's own endpoints so a rid resolves against journey_messages.
    $html = inject_tracking($html, $claim['rid'], JOURNEYS_PUBLIC_BASE_URL);
    // Same ordering rule as the campaign sender: after the click tracker, so a person leaving is
    // not counted as having clicked the message they are leaving.
    if (function_exists('inject_unsubscribe')) $html = inject_unsubscribe($html, (string)$recipient['email']);

    $res = $transport->sendEmail((string)$entry['email'], $subject, $html, $fromName, $fromEmail,
                                 $replyTo !== '' ? $replyTo : null, $claim['rid'],
                                 journey_load_attachments($cfg));

    $conn->query("UPDATE journey_messages SET subject = '" . $conn->real_escape_string(mb_substr($subject, 0, 990)) . "',
                         provider = '" . $conn->real_escape_string($provider) . "'
                   WHERE id = " . (int)$claim['id']);

    // The transport contract is ['ok' => bool, ...] — see EspTransport's docblock and
    // SendWorker.php, which both read 'ok'. This checked 'success', which no transport
    // ever sets, so EVERY email was recorded as failed with a null error ("Unknown ESP
    // error") even when SendGrid had accepted it.
    if (!empty($res['ok'])) {
        journey_message_mark($claim['id'], 'sent', ['provider_message_id' => $res['message_id'] ?? null]);
        return journey_result('sent', 'Email sent to ' . $entry['email']);
    }

    $err = (string)($res['error'] ?? 'The email provider rejected the send without giving a reason.');
    journey_message_mark($claim['id'], 'failed', ['error_message' => $err]);

    /*
     * ACCOUNT-LEVEL FAILURE ON A JOURNEY STEP.
     *
     * A journey sends one message at a time, so unlike a campaign there is no batch to count. The
     * evidence is gathered from the step's own recent history instead: how many of ITS messages
     * failed for this same account-level reason inside the window. One student hitting a quota
     * proves nothing; thirty in half an hour is the provider saying no.
     *
     * Counted from journey_messages rather than held in memory because the worker is a cron — it
     * exits between ticks, and anything kept in a variable would reset every minute and never
     * reach a threshold.
     */
    failover_consider_journey_step($journey, $cfg, $ctx, $provider, $err);

    return journey_result('failed', 'Email failed: ' . $err);
}

/**
 * Pulls a step's attachments from S3 and base64-encodes them for the transport.
 *
 * Cached per node for the life of the worker run: a journey step with a 2MB PDF
 * would otherwise re-download it from S3 once per student, which at a few hundred
 * entries a tick is minutes of pointless transfer. Campaigns solve the same problem
 * by loading once per batch (see load_campaign_attachments); this is the per-node
 * equivalent. A file that has gone missing is skipped rather than failing the send —
 * a deleted attachment must not stop a student's journey.
 */
function journey_load_attachments(array $cfg): array {
    static $cache = [];
    $list = $cfg['attachments'] ?? [];
    if (!is_array($list) || !$list) return [];

    $ck = md5(json_encode($list));
    if (isset($cache[$ck])) return $cache[$ck];

    require_once __DIR__ . '/../../lib/S3Uploader.php';
    $out = [];
    foreach ($list as $a) {
        $url = $a['s3_url'] ?? '';
        if ($url === '') continue;
        $bytes = s3_fetch_bytes($url);
        if ($bytes === null) { journey_cond_log('attachment unreachable, skipped: ' . $url); continue; }
        $out[] = [
            'filename' => $a['filename'] ?? basename($url),
            'content'  => base64_encode($bytes),
            'type'     => $a['mime'] ?? 'application/octet-stream',
        ];
    }
    if (count($cache) > 20) $cache = [];
    $cache[$ck] = $out;
    return $out;
}

/** Accepts a template id or a name — the builder stored names before it had real data. */
function journey_lookup_email_template(string $ref): ?array {
    global $conn;
    if ($ref === '') return null;
    if (is_numeric($ref)) {
        $r = $conn->query("SELECT * FROM campaign_templates WHERE id = " . (int)$ref . " LIMIT 1");
        $row = $r ? $r->fetch_assoc() : null;
        if ($row) return $row;
    }
    $esc = $conn->real_escape_string($ref);
    $r = $conn->query("SELECT * FROM campaign_templates WHERE name = '$esc' AND status = 'active' LIMIT 1");
    return $r ? ($r->fetch_assoc() ?: null) : null;
}

/* ════════════════════════════════════════════════════════════════════════════
   WhatsApp
   ═══════════════════════════════════════════════════════════════════════════ */

/**
 * Reuses the campaign renderer rather than reimplementing template rendering:
 * wa_render_for_recipient() takes an array shaped like a wa_campaigns row, so we
 * synthesise one from the wa_templates row plus the node's variable mapping. That
 * keeps journeys on exactly the same Meta/Netcore component-building code the
 * WhatsApp campaigns already send through — one renderer, one place for bugs.
 */
function journey_send_whatsapp(array $journey, array $entry, array $cfg, array $claim, array $ctx): array {
    global $conn;

    require_once __DIR__ . '/../../whatsapp/lib/schema.php';
    require_once __DIR__ . '/../../whatsapp/lib/WaHelpers.php';
    require_once __DIR__ . '/../../whatsapp/lib/WaSendWorker.php';

    $tplRef = (string)($cfg['template'] ?? '');
    $tpl = journey_lookup_wa_template($tplRef);
    if (!$tpl) {
        journey_message_mark($claim['id'], 'failed', ['error_message' => "WhatsApp template '$tplRef' not found"]);
        return journey_result('failed', "WhatsApp template '$tplRef' no longer exists.");
    }
    if (($tpl['approval_status'] ?? '') === 'rejected') {
        journey_message_mark($claim['id'], 'suppressed',
            ['suppress_reason' => 'not_configured', 'error_message' => 'Template is rejected by Meta']);
        return journey_result('suppressed', "WhatsApp template '{$tpl['name']}' is rejected by Meta.",
                              ['reason' => 'not_configured']);
    }
    /*
     * Category drift, enforced at the last possible moment.
     *
     * A template Meta has re-filed from UTILITY to MARKETING is auto-disabled in the library
     * (see whatsapp/lib/WaTemplateWabas.php), which stops anyone PICKING it — but a journey
     * published a month ago already picked it, and would keep sending it as if nothing had
     * changed: at marketing prices, to marketing opt-ins only, under a marketing frequency
     * cap that drops it for anyone over their limit. Suppressing here is the only thing that
     * stops that, and the student continues to the next step rather than being stranded.
     */
    if (!empty($tpl['auto_disabled'])) {
        journey_message_mark($claim['id'], 'suppressed',
            ['suppress_reason' => 'not_configured',
             'error_message'   => mb_substr((string)($tpl['disabled_reason'] ?? 'Template disabled'), 0, 490)]);
        return journey_result('suppressed',
            "WhatsApp template '{$tpl['name']}' has been disabled because Meta re-classified it. "
            . (string)($tpl['disabled_reason'] ?? '')
            . ' Resolve it under Content → WhatsApp templates, then this step will send again.',
            ['reason' => 'not_configured']);
    }

    // config.php is required explicitly: WaAudienceResolver uses WA_DEFAULT_COUNTRY_CODE
    // as a default parameter value but does not include its own config, so it only works
    // when something loaded it first. Relying on that ordering is a fatal waiting to happen.
    require_once __DIR__ . '/../../whatsapp/lib/config.php';
    require_once __DIR__ . '/../../whatsapp/lib/WaAudienceResolver.php';
    require_once __DIR__ . '/../../whatsapp/lib/WaLinks.php';

    /*
     * Claim the template's tracked link for THIS journey, exactly as the campaign worker claims
     * it for a campaign.
     *
     * The link id is frozen inside the Meta-approved template, so a template used by both a
     * campaign and this journey hands out the identical /login/<id> to both audiences. Whoever
     * writes this row last owns an anonymous tap. Until journeys could write it, every journey
     * tap was credited to the last campaign that used the template — which is why the journey's
     * Clicked column stayed at 0 while that campaign's kept rising long after it finished.
     *
     * Cheap and idempotent (one UPDATE), so it runs per send rather than needing a separate
     * "journey started" hook that a resumed or retried send could miss.
     */
    $linkId = (int)($tpl['link_id'] ?? 0);
    if ($linkId > 0) {
        $goalDaysForLink = max(1, (int)ceil(((int)($journey['goal_window_hours'] ?: 72)) / 24));
        wa_link_bind_journey($linkId, (int)$journey['id'],
                             (string)($journey['goal_event'] ?? ''), $goalDaysForLink);
    }

    /*
     * Numbers must carry the country code. `users.phone` holds bare 10-digit Indian
     * mobiles, and sending "9421898233" makes the BSP read it as international and
     * drop it — "Netcore 8006: Messages Dropped - Intl Messages Blocked", which is
     * exactly what the first live journey produced.
     *
     * wa_normalize_phone() is the same function the WhatsApp campaigns normalise with,
     * so journeys and campaigns treat a given contact identically: it prefixes the
     * configured country code, and returns null for anything that isn't a dialable
     * mobile — which is a suppression (no usable number), not a provider failure.
     */
    $phone = wa_normalize_phone((string)($entry['phone'] ?? ''), wa_default_cc());
    if ($phone === null) {
        journey_message_mark($claim['id'], 'suppressed',
            ['suppress_reason' => 'no_address', 'error_message' => 'Not a dialable mobile number: ' . $entry['phone']]);
        return journey_result('suppressed',
            "'{$entry['phone']}' is not a valid mobile number, so nothing was sent.", ['reason' => 'no_address']);
    }

    $settings = function_exists('wa_settings_row') ? (wa_settings_row() ?: []) : [];
    $sender   = journey_wa_sender((string)($cfg['sender'] ?? ''));
    if (!$sender) {
        journey_message_mark($claim['id'], 'suppressed',
            ['suppress_reason' => 'not_configured', 'error_message' => 'No WhatsApp sending number configured']);
        return journey_result('suppressed', 'No WhatsApp sending number is configured.', ['reason' => 'not_configured']);
    }

    /*
     * Template variables. The node stores rows of {a: '{{1}}', v: 'FIRST_NAME'} — the
     * NAME of an attribute, not its value. Passing that straight through sent students a
     * WhatsApp message reading "Hello FIRST_NAME", because substitute_merge_tags() only
     * understands XX_..._XX and [BRACKET] tokens, not a bare column name.
     *
     * journey_attribute_values() already resolves users columns plus the Customer
     * Attributes store into one flat upper-cased map, so the value is looked up there.
     * A row that matches no attribute is treated as literal text, which is what lets you
     * hard-code a word into a variable slot.
     *
     * Anything still empty falls back to the template's own sample value: Meta rejects a
     * template parameter that is blank (#132000), so an empty string would fail the send
     * outright rather than just looking odd.
     */
    /*
     * sample_values is stored as {header:[…], body:[…]}, which is how the editor writes it and
     * how wa_templates.php reads it back when submitting to Meta. Reading it as a FLAT list here
     * meant [0] never existed, so the fallback that exists to stop #132000 produced the
     * empty string it was written to prevent — and a step with no variable rows at all handed
     * the whole map to the transport, which stringified it to 'Array'. The legacy flat shape is
     * still accepted so a template saved before the editor gained the two lists keeps working.
     */
    $samplesRaw = json_decode((string)($tpl['sample_values'] ?? '[]'), true);
    $samples = is_array($samplesRaw['body'] ?? null)
        ? array_values($samplesRaw['body'])
        : array_values(array_filter((array)$samplesRaw, 'is_scalar'));
    $attrVals = journey_attribute_values((int)($entry['user_id'] ?? 0), $entry);

    /*
     * TRACKED_LINK — this student's OWN link, and the only way a WhatsApp tap can be
     * credited to a person who never signs in.
     *
     * The approved button URL is byte-identical in every copy of the message (Meta refused
     * every variable-bearing version, so it is frozen as …/login/<link id>), and Netcore
     * will not deliver a dynamic button parameter either — see the note below on
     * goal_event_name. So the button physically cannot carry who it was sent to.
     *
     * A BODY variable can. `attributes` is the one part of Netcore's payload that is proven
     * to work, WhatsApp auto-links whatever text arrives in it, and the URL is identical to
     * the one the button would have carried:
     *
     *     …/login?campaign_id=1000027&medium=journey&phone=919…&goal=…&attr_window=3&wa_rid=<32 hex>
     *
     * The dashboard already knows what to do with that: attribution.js reads medium+wa_rid
     * and posts the tap to whatsapp/click.php, which stamps this exact journey_messages row.
     * No session required — the rid IS the identity.
     *
     * Written as XX_WA_ATTR_XX here and expanded by wa_render_for_recipient(), because the
     * rid and the phone belong to the SEND, not to the student profile this loop resolves
     * against.
     */
    $trackedLink = journey_wa_tracked_link($linkId);

    /*
     * Every slot the APPROVED template has, filled from the best source available.
     *
     * This used to iterate the step's own variable rows and, when there were none, hand Meta the
     * template's SAMPLE values wholesale — which are the attribute names. That is why a journey
     * WhatsApp arrived reading "Hi FIRST_NAME, Name: LAST_NAME, Email: EMAIL": every recipient got
     * the placeholder text the template was approved with, not their own details.
     *
     * The template now answers for itself. It records which attribute fills each {{n}}
     * (var_defaults, the same map the campaign builder reads), so a step that configures nothing
     * still personalises correctly. Precedence, per slot:
     *
     *   1. the step's own row, for a journey that deliberately overrides one variable
     *   2. the template's nominated attribute, resolved for this student
     *   3. the sample, so a slot nobody has answered for still sends
     *   4. "-", because Meta rejects a blank or whitespace-only parameter (#132000)
     */
    $waDefaultsForBody = json_decode((string)($tpl['var_defaults'] ?? ''), true) ?: [];

    $slotCount = 0;
    if (preg_match_all('/\{\{\s*(\d+)\s*\}\}/', (string)($tpl['body_text'] ?? ''), $m)) {
        $slotCount = max(array_map('intval', $m[1]));
    }
    $stepParams = array_values((array)($cfg['params'] ?? []));
    $slotCount = max($slotCount, count($stepParams));

    /**
     * Turns a reference — "[PC_LINK]", "PC_LINK" or literal text — into this student's value.
     *
     * A BRACKETED reference that resolves to nothing returns empty, never the token itself. The
     * attribute map deliberately omits an attribute with no value (a condition has to tell "does
     * not exist" from "is empty"), so returning the reference unchanged is how "Preferred Domain:
     * [PREFERRED_DOMAIN]" reached a handset. Brackets mean it was chosen from the picker and is
     * unambiguously an attribute; a bare word may well be literal copy and is left alone.
     */
    $resolveRef = function (string $ref) use ($attrVals, $trackedLink) {
        $isToken = (bool)preg_match('/^\s*\[[A-Z0-9_]+\]\s*$/i', $ref);
        $name = strtoupper(trim($ref, " \t[]"));
        if ($name === '') return '';
        if ($name === 'TRACKED_LINK' || $name === 'WA_TRACKED_LINK') return $trackedLink;
        if (array_key_exists($name, $attrVals)) return (string)$attrVals[$name];
        return $isToken ? '' : $ref;
    };

    $bodyVars = [];
    for ($i = 0; $i < $slotCount; $i++) {
        $val = '';
        $stepRef = trim((string)($stepParams[$i]['v'] ?? $stepParams[$i]['value'] ?? ''));
        if ($stepRef !== '') $val = $resolveRef($stepRef);
        if (trim($val) === '') {
            $tplRef = trim((string)($waDefaultsForBody[(string)($i + 1)] ?? ''));
            if ($tplRef !== '') $val = $resolveRef($tplRef);
        }
        if (trim($val) === '') $val = (string)($samples[$i] ?? '');
        if (trim($val) === '') $val = '-';
        $bodyVars[] = $val;
    }

    /*
     * The pseudo-campaign is filled out COMPLETELY, not just with the template fields.
     *
     * wa_render_for_recipient() does more than merge text: when a template has a dynamic
     * URL button it defaults that button's value to the XX_WA_ATTR_XX attribution token,
     * because Meta rejects the whole send with "131008: Button at index 0 of type Url
     * requires a parameter" if the value is missing — which is exactly what every journey
     * WhatsApp was failing with. That defaulting only happens when the renderer can see
     * an id, a goal and the template's buttons, so leaving those blank turned the
     * behaviour off and produced the rejection.
     *
     * Filling them makes a journey send byte-identical to a campaign send: same renderer,
     * same attribution query string, same click.php landing, same conversion plumbing.
     */
    $goalDays = max(1, (int)ceil(((int)($journey['goal_window_hours'] ?: 72)) / 24));

    /*
     * An attribute-backed button works in a journey exactly as it does in a campaign.
     *
     * The template nominates the attribute (var_defaults.button_destination_attr) and its approved
     * URL ends in {{1}}. The value that fills {{1}} is this message's own id, so the tap reaches
     * c.php identifiable; c.php then forwards to whatever the attribute resolved to for this
     * person. Filling the suffix from the template rather than only from a typed step value is
     * what makes "each student's own group link" reachable from a journey at all.
     *
     * A value typed into the step still wins — that is the explicit choice the note below is
     * about, and it stays the only thing that can turn the button block on for a template with no
     * nominated attribute, because Netcore silently drops a button parameter (131008).
     */
    $waDefaults = $waDefaultsForBody;   // decoded once above, where the body slots are filled
    $waBtnDestAttr = trim((string)($waDefaults['button_destination_attr'] ?? ''));
    $waBtnSuffix = trim((string)($cfg['buttonUrl'] ?? ''));
    if ($waBtnSuffix === '' && $waBtnDestAttr !== '') $waBtnSuffix = 'XX_WA_CLICK_TOKEN_XX';

    $pseudoCampaign = [
        'id'                => (int)$journey['id'],
        /*
         * What this send calls itself in the attribution query string, when the template carries
         * a per-recipient link (XX_WA_ATTR_XX in a button or a body variable).
         *
         * That link is the only way a WhatsApp tap can name the person WITHOUT a sign-in: it
         * arrives carrying their phone number and this message's own rid, so the landing page can
         * report the click immediately. The static /login/<id> form cannot — it is identical in
         * every message ever sent.
         *
         * The offset id and 'journey' medium have to travel here for the same reason they do
         * everywhere else: a bare 21 would be indistinguishable from campaign 21 in the shared
         * attribution ledger.
         */
        'attr_campaign_id'  => journey_attr_campaign_id((int)$journey['id']),
        'attr_medium'       => JOURNEY_ATTR_MEDIUM,
        'message_type'      => 'template',
        'template_name'     => $tpl['name'],
        'template_language' => $tpl['language'],
        'header_type'       => $tpl['header_type'],
        'header_text'       => $tpl['header_text'],
        'header_media_url'  => $tpl['header_media_url'],
        'body_text'         => $tpl['body_text'],
        'buttons'           => $tpl['buttons'],
        'variables'         => json_encode([
            'header' => [],
            'body'   => $bodyVars,
            // Explicit value from the step wins; blank lets the renderer default it to
            // the attribution token when the template needs one.
            'button_url_suffix' => $waBtnSuffix,
            /*
             * Which attribute the button's destination resolves to, carried through from the
             * template exactly as a campaign carries it.
             *
             * Without this a journey could deliver an attribute-backed button and then send every
             * tap to the campaign-level fallback, because nothing downstream knew the button was
             * supposed to mean "this student's own link". The template states it once; both
             * senders now read the same statement.
             */
            'button_destination_attr' => $waBtnDestAttr,
        ]),
        /*
         * goal_event_name is deliberately blank unless this step opted into button
         * tracking, and that is what makes a journey send match a working campaign.
         *
         * wa_render_for_recipient() reads it as "auto-fill a dynamic URL button with the
         * attribution token". netcore_build_buttons() then emits a `buttons` key — and
         * Netcore does not deliver that value, so WhatsApp rejects the whole message with
         * 131008. A campaign with no goal never sets a suffix, emits no `buttons` key at
         * all, and sends fine with this very template.
         *
         * Passing the goal unconditionally is what turned a working template into a
         * failing one for journeys only. Now the button block is emitted only when the
         * step's "Button link value" is filled in — an explicit choice, not a default.
         */
        'goal_event_name'   => (string)($journey['goal_event'] ?: 'journey'),
        /*
         * …but the goal must NOT switch the button auto-fill back on.
         *
         * The renderer treats "has a goal + dynamic url button + nothing typed" as consent to
         * fill that button with the attribution token. For a campaign that is right. For a
         * journey it is what produced 131008 on every send: Netcore accepts the buttons block
         * and does not pass the value on, so WhatsApp refuses the whole message for a missing
         * button parameter. The goal still has to travel — it is what puts `goal=` in the
         * TRACKED_LINK query string — so the two are separated instead of tangled together.
         *
         * An explicitly typed "Button link value" is untouched by this and still goes out, for
         * the day the Meta route is connected and can carry it.
         */
        'auto_button_attr'  => false,
        'goal_window_days'  => $goalDays,
        'text_content'      => '',
        'preview_url'       => 0,
    ];
    $recipient = [
        'first_name' => $entry['first_name'] ?? '', 'last_name' => $entry['last_name'] ?? '',
        'email'      => $entry['email'] ?? '',
        // The normalised number, so the attribution query string carries the same value
        // the message was actually sent to.
        'phone'      => $phone,
        'rid'        => $claim['rid'],
    ];

    /*
     * The recipient's Customer Attributes, which this call used to pass as an empty array.
     *
     * Body variables are resolved earlier by name, so nothing obvious broke — but the button's
     * destination is resolved HERE, by substituting [PC_LINK] against this map. With nothing in
     * it the token could never resolve, so an attribute-backed button silently produced no
     * per-recipient destination and every tap fell through to the campaign default.
     */
    $waAttrTokens = journey_attribute_tokens((string)($entry['email'] ?? ''), (int)($entry['user_id'] ?? 0));
    $rendered = wa_render_for_recipient($pseudoCampaign, $recipient, $waAttrTokens);

    /*
     * Which route this step sends through. Blank (the default) follows whatever the
     * sending number is configured for in WhatsApp Settings — which today is Netcore,
     * because the Meta app is not connected to the WABA and a direct Cloud API send
     * fails with "#200 permissions". The dropdown exists so a step can be pinned
     * explicitly rather than silently changing route the day someone edits Settings.
     */
    $providerOverride = strtolower(trim((string)($cfg['provider'] ?? '')));
    $providerOverride = in_array($providerOverride, ['netcore', 'meta'], true) ? $providerOverride : null;

    /*
     * With no per-step choice, fall back to the route pinned when this journey was PUBLISHED
     * rather than to whatever the number is set to right now. Same reasoning as the email side:
     * flipping a number from Netcore to Meta in Settings must not re-route journeys that are
     * already running. The step's own dropdown still wins when it is set, and a journey published
     * before wa_provider existed still follows the number's current setting.
     */
    if ($providerOverride === null) {
        $pinned = strtolower(trim((string)($journey['wa_provider'] ?? '')));
        if (in_array($pinned, ['netcore', 'meta'], true)) $providerOverride = $pinned;
    }

    $transport = wa_transport_for_sender($settings, $sender, $providerOverride);
    if (!$transport || !$transport->isConfigured()) {
        journey_message_mark($claim['id'], 'suppressed',
            ['suppress_reason' => 'not_configured', 'error_message' => 'WhatsApp transport not configured']);
        return journey_result('suppressed', 'The WhatsApp transport is not configured.', ['reason' => 'not_configured']);
    }

    $res = $transport->sendMessage($phone, $rendered['content'], $claim['rid']);

    // Record the number actually dialled, not the raw profile value — otherwise the
    // message log shows a bare 10-digit number that was never what we sent to.
    /*
     * The destination this person's button tap should land on, stored on their own message row.
     *
     * c.php reads it back when the tap arrives. It has to be written now rather than looked up
     * then, for the same reason a campaign stores it: a group link re-assigned tomorrow must not
     * change where a message sent today goes.
     */
    $clickTargetSql = !empty($rendered['click_target'])
        ? ", click_target_url = '" . $conn->real_escape_string(mb_substr((string)$rendered['click_target'], 0, 1000)) . "'"
        : '';
    /*
     * And which tracked link the button carried, so a tap on it can be traced back to this row.
     *
     * The template's static link is the same string for everyone, so the tap arrives anonymous.
     * Recording the link here is what lets link.php find the message again — see the note on the
     * column in schema.php. Only written when the template actually has one.
     */
    $linkIdSql = $linkId > 0 ? ", link_id = " . (int)$linkId : '';
    $conn->query("UPDATE journey_messages
                     SET preview = '" . $conn->real_escape_string(mb_substr((string)($rendered['preview'] ?? ''), 0, 2000)) . "',
                         to_addr = '" . $conn->real_escape_string($phone) . "',
                         provider = 'whatsapp'$clickTargetSql$linkIdSql
                   WHERE id = " . (int)$claim['id']);

    // Same contract as the email transports: 'ok', not 'success'.
    if (!empty($res['ok'])) {
        journey_message_mark($claim['id'], 'sent', ['provider_message_id' => $res['message_id'] ?? null]);
        $conn->query("UPDATE journey_messages SET provider = '"
            . $conn->real_escape_string(wa_resolve_provider($sender, $providerOverride))
            . "' WHERE id = " . (int)$claim['id']);
        return journey_result('sent', 'WhatsApp sent to ' . $phone);
    }
    $err = (string)($res['error'] ?? 'The WhatsApp provider rejected the send without giving a reason.');
    journey_message_mark($claim['id'], 'failed', ['error_message' => $err]);
    return journey_result('failed', 'WhatsApp failed: ' . $err);
}

/**
 * The template's destination with the attribution token appended, or '' when the template has
 * no link configured.
 *
 *     https://dashboard.internshipstudio.com/login?XX_WA_ATTR_XX
 *
 * NO /<link id> PATH SEGMENT, deliberately, even though wa_tracked_link() would add one and the
 * approved BUTTON carries it. The id exists to give a static link something to look up, and the
 * dashboard resolves it by calling whatsapp/link.php — which logs its own anonymous tap row. A
 * URL carrying both would therefore be counted twice for one tap: once anonymously by link.php
 * and once, by name, by click.php. This link needs no lookup: everything link.php would return
 * is already in the query string, and the rid names the person the id never could.
 *
 * A destination that already has a query string keeps it — the token is appended with '&'.
 */
function journey_wa_tracked_link(int $linkId): string {
    global $conn;
    if ($linkId <= 0) return '';

    $r   = $conn->query("SELECT target_url FROM wa_links WHERE id = " . (int)$linkId . " LIMIT 1");
    $row = $r ? $r->fetch_assoc() : null;
    $target = trim((string)($row['target_url'] ?? ''));
    if ($target === '') return '';

    return $target . (strpos($target, '?') === false ? '?' : '&') . 'XX_WA_ATTR_XX';
}

function journey_lookup_wa_template(string $ref): ?array {
    global $conn;
    if ($ref === '') return null;
    if (is_numeric($ref)) {
        $r = $conn->query("SELECT * FROM wa_templates WHERE id = " . (int)$ref . " LIMIT 1");
        $row = $r ? $r->fetch_assoc() : null;
        if ($row) return $row;
    }
    $esc = $conn->real_escape_string($ref);
    $r = $conn->query("SELECT * FROM wa_templates WHERE name = '$esc' AND status = 'active' ORDER BY id DESC LIMIT 1");
    return $r ? ($r->fetch_assoc() ?: null) : null;
}

/** The node stores a display label like "+91 90000 11111 (iStudio)" — match on digits. */
function journey_wa_sender(string $ref): ?array {
    global $conn;
    $digits = preg_replace('/\D+/', '', $ref);
    if ($digits !== '') {
        $esc = $conn->real_escape_string($digits);
        $r = $conn->query("SELECT * FROM wa_senders
                            WHERE REPLACE(REPLACE(business_number,'+',''),' ','') = '$esc'
                              AND is_active = 1 LIMIT 1");
        $row = $r ? $r->fetch_assoc() : null;
        if ($row) return $row;
    }
    $r = $conn->query("SELECT * FROM wa_senders WHERE is_active = 1 ORDER BY is_default DESC, id ASC LIMIT 1");
    return $r ? ($r->fetch_assoc() ?: null) : null;
}

/* ════════════════════════════════════════════════════════════════════════════
   Call a service (webhook)
   ═══════════════════════════════════════════════════════════════════════════ */

/**
 * The node Netcore does not have and your own research flags as a MUST for us:
 * unlock the hiring portal, issue a certificate, sync a CRM.
 *
 * Locked to https and to a host allowlist. A journey step that can POST anywhere
 * is an SSRF primitive handed to whoever can edit a journey, so the allowlist is
 * the feature, not a formality.
 */
function journey_call_webhook(array $journey, array $entry, array $cfg, array $claim, array $ctx): array {
    $url    = trim((string)($cfg['url'] ?? ''));
    $method = strtoupper((string)($cfg['method'] ?? 'POST'));
    if (!in_array($method, ['GET', 'POST', 'PUT'], true)) $method = 'POST';

    $host = parse_url($url, PHP_URL_HOST);
    $scheme = parse_url($url, PHP_URL_SCHEME);
    if ($scheme !== 'https' || !$host) {
        journey_message_mark($claim['id'], 'failed', ['error_message' => 'Endpoint must be an https URL']);
        return journey_result('failed', 'The endpoint must be an https:// URL.');
    }
    if (!journey_host_allowed($host)) {
        journey_message_mark($claim['id'], 'failed', ['error_message' => "Host '$host' is not allowlisted"]);
        return journey_result('failed', "Host '$host' is not on the webhook allowlist (see JOURNEY_WEBHOOK_HOSTS).");
    }

    $payload = ['user_id' => (int)($entry['user_id'] ?? 0), 'email' => $entry['email'] ?? '',
                'phone' => $entry['phone'] ?? '', 'journey_id' => (int)$ctx['journey_id'],
                'entry_id' => (int)$ctx['entry_id'], 'node_id' => (string)$ctx['node_id']];
    foreach (array_filter(array_map('trim', explode(',', (string)($cfg['body'] ?? '')))) as $k) {
        if (!isset($payload[$k])) $payload[$k] = $entry[$k] ?? null;
    }

    $ch = curl_init();
    $target = $url;
    if ($method === 'GET') $target .= (strpos($url, '?') === false ? '?' : '&') . http_build_query($payload);
    curl_setopt_array($ch, [
        CURLOPT_URL => $target,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => 15,
        CURLOPT_CONNECTTIMEOUT => 8,
        CURLOPT_FOLLOWLOCATION => false,     // a redirect could walk out of the allowlist
        CURLOPT_CUSTOMREQUEST => $method,
    ]);
    if ($method !== 'GET') {
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
        curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
    }
    $body = curl_exec($ch);
    $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $err  = curl_error($ch);
    curl_close($ch);

    if ($err !== '' || $code < 200 || $code >= 300) {
        $msg = $err !== '' ? $err : "HTTP $code";
        journey_message_mark($claim['id'], 'failed', ['error_message' => $msg]);
        return journey_result('failed', 'Service call failed: ' . $msg);
    }
    journey_message_mark($claim['id'], 'sent', ['provider_message_id' => "HTTP $code"]);
    return journey_result('sent', "Service call returned HTTP $code");
}

function journey_host_allowed(string $host): bool {
    $allow = defined('JOURNEY_WEBHOOK_HOSTS') ? JOURNEY_WEBHOOK_HOSTS
           : ['internshipstudio.com', 'offcampusly.com', 'skilluniverse.com'];
    $host = strtolower($host);
    foreach ($allow as $a) {
        $a = strtolower($a);
        if ($host === $a || substr($host, -strlen('.' . $a)) === '.' . $a) return true;
    }
    return false;
}

/*
 * Deliberately NOT incrementing journeys.sent_count here.
 *
 * journey_rollup_node_stats() recomputes every counter from journey_messages at the end
 * of each tick — it is the single source of truth. Incrementing as well meant the number
 * was inflated between the send and the rollup, and any future change to what counts as
 * "sent" would have had to be made in two places that could disagree. Counting rows once,
 * in one place, is what makes the report reconcile with the message log.
 */

<?php
/*
 * /api/freshdesk/fd_settings.php
 *
 *   action=get             -> current settings (secrets masked)
 *   action=save            -> write settings
 *   action=test_imap       -> connect, log in, open the folder, count messages
 *   action=test_smtp &to   -> send a real test email
 *   action=test_pusher     -> publish a test event
 *   action=folders         -> list IMAP folders (to pick the Sent folder)
 *   action=diagnostics     -> one call that checks everything and says what is wrong
 *   action=reset_sync      -> forget the watermark and re-baseline the mailbox
 *
 * SECRETS NEVER LEAVE. `get` returns passwords as a fixed mask, and `save`
 * treats that mask as "unchanged" -- so the Settings form can be saved without
 * retyping the mailbox password, and the password cannot be read back out of
 * the API by anyone who gets an agent session.
 */

require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../middleware/auth.php';
require_once __DIR__ . '/lib/config.php';
require_once __DIR__ . '/lib/Helpers.php';
require_once __DIR__ . '/lib/schema.php';
require_once __DIR__ . '/lib/Pusher.php';
require_once __DIR__ . '/lib/ImapClient.php';
require_once __DIR__ . '/lib/MimeParser.php';
require_once __DIR__ . '/lib/Storage.php';
require_once __DIR__ . '/lib/TicketStore.php';
require_once __DIR__ . '/lib/Sla.php';
require_once __DIR__ . '/lib/Mailer.php';

$jwt = require_jwt();
require_permission('freshdesk', $jwt);
fd_install_error_handlers();
fd_ensure_schema();

define('FD_SECRET_MASK', '********');

/** Keys the Settings screen may write. Anything not listed here is ignored. */
function fd_settings_schema()
{
    return array(
        // key                => array(type, isSecret)
        'IMAP_HOST'           => array('string', false),
        'IMAP_PORT'           => array('int',    false),
        'IMAP_SECURITY'       => array('enum:ssl,tls,plain', false),
        'IMAP_USER'           => array('string', false),
        'IMAP_PASS'           => array('string', true),
        'IMAP_FOLDER'         => array('string', false),
        'IMAP_SENT_FOLDER'    => array('string', false),
        'IMAP_VERIFY_PEER'    => array('bool',   false),

        'SMTP_HOST'           => array('string', false),
        'SMTP_PORT'           => array('int',    false),
        'SMTP_SECURITY'       => array('enum:tls,ssl,', false),
        'SMTP_USER'           => array('string', false),
        'SMTP_PASS'           => array('string', true),
        'FROM_EMAIL'          => array('email',  false),
        'FROM_NAME'           => array('string', false),
        'REPLY_TO'            => array('email',  false),
        'EMAIL_SIGNATURE'     => array('text',   false),

        'PUSHER_APP_ID'       => array('string', false),
        'PUSHER_KEY'          => array('string', false),
        'PUSHER_SECRET'       => array('string', true),
        'PUSHER_CLUSTER'      => array('string', false),
        'PUSHER_CHANNEL'      => array('string', false),

        'AUTO_ACK'            => array('bool',   false),
        'SKIP_ORPHAN_AUTOREPLIES' => array('bool', false),
        'AUTO_CLOSE_DAYS'     => array('int',    false),
        'AUTO_ACK_BODY'       => array('text',   false),
        'SYNC_BATCH'          => array('int',    false),
        'SYNC_INITIAL_DAYS'   => array('int',    false),
        'SOUND_ENABLED'       => array('bool',   false),
        'SOUND_VOLUME'        => array('float',  false),
        'SLA_POLICY'          => array('json',   false),
        'SLA_RISK_RATIO'      => array('float',  false),

        'UI_PREFS'            => array('json',   false),
    );
}

$action = fd_str('action', 'get');
$GLOBALS['FD_ACTION'] = $action;

/* ------------------------------------------------------------------- get -- */
if ($action === 'get') {
    $out = array();
    foreach (fd_settings_schema() as $key => $def) {
        $val = fd_cfg($key, '');
        $out[$key] = $def[1] ? (($val === '' || $val === null) ? '' : FD_SECRET_MASK) : $val;
    }
    // Tell the UI which knobs are still on their shipped defaults vs actually
    // configured -- "Pusher: not configured yet" is far more useful than a
    // field silently full of a placeholder that looks real.
    $out['_meta'] = array(
        'pusherConfigured' => fd_pusher_enabled(),
        'mailerReady'      => (new FdMailer())->isReady(),
        'attachDir'        => FD_ATTACH_DIR,
        'attachWritable'   => is_dir(FD_ATTACH_DIR) && is_writable(FD_ATTACH_DIR),
        'logPath'          => FD_LOG_PATH,
        'cronCommand'      => 'php ' . realpath(__DIR__) . '/fd_sync.php',
        'cronUrl'          => 'fd_sync.php?secret=' . fd_cfg('CRON_SECRET', FD_CRON_SECRET),
        'maxAttachMb'      => round(FD_ATTACH_MAX_FILE_BYTES / 1048576),
        'allowedExt'       => explode(',', (string)fd_cfg('ATTACH_ALLOWED_EXT', FD_ATTACH_ALLOWED_EXT)),
    );
    api_success(array('settings' => $out), 'OK');
}

/* ------------------------------------------------------------------ save -- */
if ($action === 'save') {
    $input  = fd_input();
    $schema = fd_settings_schema();
    $saved = array(); $errors = array();

    foreach ($schema as $key => $def) {
        if (!array_key_exists($key, $input)) continue;
        $raw = $input[$key];

        // The mask coming back means "leave it alone" -- the form was submitted
        // without retyping the password. Writing the mask would lock the desk
        // out of its own mailbox.
        if ($def[1] && ($raw === FD_SECRET_MASK || $raw === '')) continue;

        list($type) = $def;
        if (strpos($type, 'enum:') === 0) {
            $allowed = explode(',', substr($type, 5));
            if (!in_array((string)$raw, $allowed, true)) {
                $errors[$key] = 'Must be one of: ' . implode(', ', array_filter($allowed));
                continue;
            }
            $val = (string)$raw;
        } elseif ($type === 'int') {
            $val = (string)(int)$raw;
        } elseif ($type === 'float') {
            $val = (string)(float)$raw;
        } elseif ($type === 'bool') {
            $val = (!empty($raw) && $raw !== 'false' && $raw !== '0') ? '1' : '0';
        } elseif ($type === 'email') {
            $raw = trim((string)$raw);
            if ($raw !== '' && !filter_var($raw, FILTER_VALIDATE_EMAIL)) {
                $errors[$key] = 'Not a valid email address.';
                continue;
            }
            $val = $raw;
        } elseif ($type === 'json') {
            $decoded = is_array($raw) ? $raw : json_decode((string)$raw, true);
            if (!is_array($decoded)) { $errors[$key] = 'Not valid JSON.'; continue; }
            $val = json_encode($decoded);
        } else {
            $val = is_scalar($raw) ? trim((string)$raw) : '';
        }

        fd_cfg_set($key, $val);
        $saved[] = $key;
    }

    /*
     * Changing the mailbox means the stored UID watermark points into a
     * different mailbox entirely -- keeping it would make the desk skip
     * everything already numbered below it and go silently deaf. Reset it so
     * the next sync re-baselines.
     */
    if (in_array('IMAP_HOST', $saved, true) || in_array('IMAP_USER', $saved, true) || in_array('IMAP_FOLDER', $saved, true)) {
        fd_exec("UPDATE fd_mailbox_state SET last_uid = 0, uidvalidity = NULL, last_status = 'reset'");
        $saved[] = '(sync watermark reset)';
    }

    if (!empty($errors)) {
        api_error('Some settings were not saved: ' . json_encode($errors), 400);
    }
    api_success(array('saved' => $saved), count($saved) . ' setting(s) saved');
}

/* ------------------------------------------------------------- test_imap -- */
if ($action === 'test_imap') {
    $t0 = microtime(true);
    $steps = array();
    try {
        $imap = new ImapClient(array('trace' => true));
        $steps[] = array('step' => 'Connect', 'ok' => true, 'detail' => fd_cfg('IMAP_HOST') . ':' . fd_cfg_int('IMAP_PORT', 993) . ' (' . fd_cfg('IMAP_SECURITY') . ')');
        $imap->login();
        $steps[] = array('step' => 'Log in', 'ok' => true, 'detail' => 'Authenticated as ' . fd_cfg('IMAP_USER'));

        $folder = (string)fd_cfg('IMAP_FOLDER', 'INBOX');
        $info = $imap->selectFolder($folder, true);
        $steps[] = array('step' => 'Open folder', 'ok' => true,
                         'detail' => $folder . ' -- ' . $info['exists'] . ' messages, UIDVALIDITY ' . $info['uidvalidity']);

        $recent = $imap->searchSinceDays(3);
        $steps[] = array('step' => 'Search', 'ok' => true, 'detail' => count($recent) . ' message(s) in the last 3 days');

        $preview = array();
        if (!empty($recent)) {
            $lastFew = array_slice($recent, -3);
            $msgs = $imap->fetchMessages($lastFew);
            foreach ($msgs as $uid => $m) {
                $p = MimeParser::parse($m['raw']);
                $preview[] = array(
                    'uid' => $uid, 'from' => $p['from_email'], 'name' => $p['from_name'],
                    'subject' => fd_snippet($p['subject'], 90), 'date' => $p['date'],
                    'attachments' => count($p['attachments']),
                );
            }
            $steps[] = array('step' => 'Fetch + parse', 'ok' => true, 'detail' => count($preview) . ' message(s) read and decoded');
        }

        $sent = trim((string)fd_cfg('IMAP_SENT_FOLDER', ''));
        if ($sent !== '') {
            try {
                $imap->selectFolder($sent, true);
                $steps[] = array('step' => 'Sent folder', 'ok' => true, 'detail' => $sent . ' exists');
            } catch (Throwable $e) {
                // Non-fatal: only the "file a copy in Sent" nicety depends on it.
                $steps[] = array('step' => 'Sent folder', 'ok' => false,
                                 'detail' => $sent . ' could not be opened. Replies will still send; they just will not appear in webmail Sent. Use action=folders to see the real names.');
            }
        }

        $imap->close();
        api_success(array(
            'ok' => true, 'steps' => $steps, 'preview' => $preview,
            'took_ms' => (int)round((microtime(true) - $t0) * 1000),
        ), 'Mailbox connection is working.');

    } catch (Throwable $e) {
        $steps[] = array('step' => 'Failed', 'ok' => false, 'detail' => $e->getMessage());
        fd_log('error', 'IMAP test failed: ' . $e->getMessage());
        api_success(array(
            'ok' => false, 'steps' => $steps, 'error' => $e->getMessage(),
            'took_ms' => (int)round((microtime(true) - $t0) * 1000),
        ), $e->getMessage());
    }
}

/* --------------------------------------------------------------- folders -- */
if ($action === 'folders') {
    try {
        $imap = new ImapClient();
        $imap->login();
        $folders = $imap->listFolders();
        $imap->close();
        api_success(array('folders' => $folders), count($folders) . ' folder(s)');
    } catch (Throwable $e) {
        api_error($e->getMessage(), 500);
    }
}

/* ------------------------------------------------------------- test_smtp -- */
if ($action === 'test_smtp') {
    $to = fd_str('to', (string)fd_cfg('FROM_EMAIL', ''));
    if ($to === '' || !filter_var($to, FILTER_VALIDATE_EMAIL)) api_error('Enter a valid address to send the test to.', 400);

    $mailer = new FdMailer();
    if (!$mailer->isReady()) api_error($mailer->loadError(), 500);

    $r = $mailer->sendTest($to);
    // Reported as a 200 with ok:false so the UI can show the SMTP transcript,
    // which is the only thing that explains most SMTP failures.
    api_success(array('ok' => $r['ok'], 'debug' => $r['debug']), $r['message']);
}

/* ----------------------------------------------------------- test_pusher -- */
if ($action === 'test_pusher') {
    $pusher = new FdPusher();
    if (!$pusher->isConfigured()) {
        api_success(array(
            'ok' => false, 'configured' => false,
            'hint' => 'Pusher still has the placeholder credentials. Create a free app at pusher.com, then paste App ID, Key, Secret and Cluster above. Until then the desk uses polling, which works -- new email just takes a few seconds longer to appear.',
        ), 'Pusher is not configured yet (polling is active).');
    }
    $ok = $pusher->trigger('test-event', array(
        'subject' => 'Pusher test', 'preview' => 'Connection verified at ' . date('H:i:s'),
        'notify' => 1, 'sound' => 'new-reply',
    ));
    api_success(array('ok' => $ok, 'configured' => true, 'channel' => fd_cfg('PUSHER_CHANNEL')),
                $ok ? 'Event published. Any open Freshdesk tab should chime.'
                    : 'Pusher rejected the publish -- see freshdesk.log for the HTTP status and reason.');
}

/* ----------------------------------------------------------- diagnostics -- */
if ($action === 'diagnostics') {
    /*
     * One button that answers "why is this not working?". Each check is
     * independent and non-fatal so a single failure still lets the rest report,
     * which is what turns "it's broken" into "SMTP is fine, IMAP cannot
     * connect, and cron has not run in 3 hours".
     */
    $checks = array();

    $checks[] = array('name' => 'PHP version', 'ok' => version_compare(PHP_VERSION, '7.0', '>='),
                      'detail' => PHP_VERSION);
    $checks[] = array('name' => 'OpenSSL (needed for IMAP/SMTP TLS)', 'ok' => extension_loaded('openssl'),
                      'detail' => extension_loaded('openssl') ? 'loaded' : 'MISSING -- secure mail connections are impossible without it');
    $checks[] = array('name' => 'mbstring (charset decoding)', 'ok' => extension_loaded('mbstring'),
                      'detail' => extension_loaded('mbstring') ? 'loaded' : 'missing -- non-English subjects may be garbled');
    $checks[] = array('name' => 'iconv', 'ok' => function_exists('iconv'),
                      'detail' => function_exists('iconv') ? 'available' : 'missing (mbstring will be used instead)');
    $checks[] = array('name' => 'cURL (needed for Pusher)', 'ok' => function_exists('curl_init'),
                      'detail' => function_exists('curl_init') ? 'available' : 'MISSING -- realtime push cannot work, polling only');

    $mailer = new FdMailer();
    $checks[] = array('name' => 'PHPMailer', 'ok' => $mailer->isReady(),
                      'detail' => $mailer->isReady() ? 'loaded' : $mailer->loadError());

    /*
     * Attachments belong in S3. The local folder is only the fallback used when
     * S3 is unreachable, so this reports which one is actually in play -- a desk
     * quietly filling the cPanel disk because the AWS SDK went missing is
     * exactly the kind of thing nobody notices until the account is full.
     */
    $s3 = fd_s3_available();
    $checks[] = array('name' => 'Attachment storage (S3)', 'ok' => $s3,
                      'detail' => $s3
                          ? 'S3 is available -- files go to the bucket and only the URL is stored'
                          : 'S3 UNAVAILABLE (' . fd_s3_error() . ') -- attachments are falling back to local disk');

    $localRows = fd_query_one("SELECT COUNT(*) AS c FROM fd_attachments WHERE storage = 'local'");
    $localCount = $localRows ? (int)$localRows['c'] : 0;
    $checks[] = array('name' => 'Attachments still on local disk', 'ok' => $localCount === 0,
                      'detail' => $localCount === 0
                          ? 'none -- everything is in S3'
                          : $localCount . ' file(s) were stored locally while S3 was down. They still work; re-upload or migrate them when convenient.');

    $writable = is_dir(FD_ATTACH_DIR) && is_writable(FD_ATTACH_DIR);
    $checks[] = array('name' => 'Local fallback folder writable', 'ok' => $writable,
                      'detail' => FD_ATTACH_DIR . ($writable ? ' (ok)' : ' -- not writable; there is no fallback if S3 fails'));

    $ht = file_exists(FD_ATTACH_DIR . '/.htaccess');
    $checks[] = array('name' => 'Fallback folder is non-executable', 'ok' => $ht,
                      'detail' => $ht ? '.htaccess present' : 'MISSING .htaccess -- a locally-stored .php could be executed. Reload any Freshdesk page to regenerate it.');

    // Tables
    $tablesOk = true; $missing = array();
    foreach (array('fd_tickets','fd_messages','fd_attachments','fd_contacts','fd_mailbox_state','fd_activity','fd_settings') as $tb) {
        $r = fd_query_one("SHOW TABLES LIKE '" . $tb . "'");
        if (!$r) { $tablesOk = false; $missing[] = $tb; }
    }
    $checks[] = array('name' => 'Database tables', 'ok' => $tablesOk,
                      'detail' => $tablesOk ? 'all 7 present' : 'missing: ' . implode(', ', $missing));

    // IMAP
    try {
        $imap = new ImapClient();
        $imap->login();
        $info = $imap->selectFolder((string)fd_cfg('IMAP_FOLDER', 'INBOX'), true);
        $imap->close();
        $checks[] = array('name' => 'IMAP mailbox', 'ok' => true,
                          'detail' => fd_cfg('IMAP_USER') . ' -- ' . $info['exists'] . ' messages');
    } catch (Throwable $e) {
        $checks[] = array('name' => 'IMAP mailbox', 'ok' => false, 'detail' => $e->getMessage());
    }

    // Sync freshness
    $st = fd_query_one("SELECT * FROM fd_mailbox_state WHERE mailbox = ?", 's', array((string)fd_cfg('IMAP_FOLDER', 'INBOX')));
    $fresh = $st && $st['last_sync_at'] && strtotime($st['last_sync_at']) > time() - 600;
    $checks[] = array('name' => 'Sync has run recently', 'ok' => (bool)$fresh,
                      'detail' => $st && $st['last_sync_at']
                          ? ('last run ' . fd_relative_time($st['last_sync_at']) . ' -- status ' . $st['last_status']
                             . ($st['last_error'] ? ' -- ' . fd_snippet($st['last_error'], 200) : ''))
                          : 'never run. Add the cron: * * * * * php ' . realpath(__DIR__) . '/fd_sync.php');

    $checks[] = array('name' => 'Realtime transport', 'ok' => true,
                      'detail' => fd_pusher_enabled()
                          ? 'Pusher (cluster ' . fd_cfg('PUSHER_CLUSTER') . ', channel ' . fd_cfg('PUSHER_CHANNEL') . ')'
                          : 'Polling -- Pusher credentials are still the placeholders. This works; it is just a few seconds slower.');

    $counts = fd_query_one("SELECT (SELECT COUNT(*) FROM fd_tickets) AS tickets,
                                   (SELECT COUNT(*) FROM fd_messages) AS messages,
                                   (SELECT COUNT(*) FROM fd_attachments) AS attachments,
                                   (SELECT COUNT(*) FROM fd_contacts) AS contacts");

    $failed = array_values(array_filter($checks, function ($c) { return !$c['ok']; }));
    api_success(array(
        'checks' => $checks,
        'failed' => count($failed),
        'data'   => $counts,
        'log'    => fd_tail_log(40),
    ), count($failed) === 0 ? 'Everything checks out.' : count($failed) . ' check(s) need attention.');
}

/* ------------------------------------------------------------ reset_sync -- */
if ($action === 'reset_sync') {
    /*
     * Forget the watermark so the next run re-reads the recent window. Safe by
     * construction: every message that comes back is matched on its Message-ID
     * and skipped as a duplicate, so this re-imports gaps without duplicating
     * anything already in the thread.
     */
    fd_exec("UPDATE fd_mailbox_state SET last_uid = 0, uidvalidity = NULL, last_status = 'reset', last_error = NULL, consecutive_fails = 0");
    fd_log('info', 'Sync watermark reset by an agent');
    api_success(array('reset' => true), 'Watermark cleared. The next sync will re-read the recent window; duplicates are skipped automatically.');
}

/* ---------------------------------------------------------- skip_backlog -- */
/*
 * "Start from now."
 *
 * THE PROBLEM THIS SOLVES. On its first run the worker baselines against
 * SYNC_INITIAL_DAYS (7) and imports everything newer. On a quiet mailbox that
 * is a handful of messages. On a busy support inbox -- especially one carrying
 * a lot of Mail-Delivery-System traffic -- it is thousands, and since the
 * worker only takes SYNC_BATCH per run it keeps trickling years-old mail in as
 * brand new tickets, run after run. The queue grows every minute and closing
 * tickets never catches up, because the import is still going.
 *
 * This moves the watermark to the TOP of the mailbox (UIDNEXT-1), so nothing
 * that already exists is ever imported and only mail that ARRIVES FROM NOW ON
 * becomes a ticket.
 *
 * Nothing is deleted and no mail is touched -- this only moves a number. The
 * messages stay in the mailbox exactly as they are; the desk simply stops
 * treating history as new work.
 */
if ($action === 'skip_backlog') {
    $mailbox = (string)fd_cfg('IMAP_FOLDER', 'INBOX');
    $confirm = fd_bool('confirm', false);

    try {
        $imap = new ImapClient();
        $imap->login();
        $info = $imap->selectFolder($mailbox, true);
        $imap->close();
    } catch (Throwable $e) {
        api_error('Could not read the mailbox: ' . $e->getMessage(), 500);
    }

    $uidnext  = (int)$info['uidnext'];
    $validity = (int)$info['uidvalidity'];
    // UIDNEXT is the id the NEXT message will get, so the newest existing one
    // is UIDNEXT-1. Parking the watermark there means "everything currently in
    // this mailbox is already accounted for".
    $target = max(0, $uidnext - 1);

    $state = fd_query_one("SELECT last_uid FROM fd_mailbox_state WHERE mailbox = ?", 's', array($mailbox));
    $current = $state ? (int)$state['last_uid'] : 0;

    if (!$confirm) {
        api_success(array(
            'dry_run' => true, 'mailbox' => $mailbox,
            'current_watermark' => $current, 'new_watermark' => $target,
            'messages_in_folder' => (int)$info['exists'],
            'would_skip' => max(0, $target - $current),
        ), 'Would skip ' . max(0, $target - $current) . ' older message(s) and start from the next new email. Re-run with confirm=1.');
    }

    fd_exec("INSERT INTO fd_mailbox_state (mailbox, last_uid, uidvalidity, last_status)
             VALUES (?,?,?,'baselined')
             ON DUPLICATE KEY UPDATE last_uid = VALUES(last_uid), uidvalidity = VALUES(uidvalidity),
                                     last_status = 'baselined', last_error = NULL, consecutive_fails = 0",
            'sii', array($mailbox, $target, $validity));

    fd_log('info', 'Backlog skipped: watermark ' . $current . ' -> ' . $target, array('mailbox' => $mailbox));

    api_success(array('skipped' => max(0, $target - $current), 'watermark' => $target),
        'Done. The desk will now only create tickets for mail that arrives from this point on. '
        . 'Nothing was deleted -- every message is still in the mailbox.');
}

/* ------------------------------------------------------- cleanup_bounces -- */
/*
 * Retro-fix for mailboxes imported before orphan bounces were filtered out.
 *
 * Early builds created a ticket for every "Mail Delivery System" delay/bounce
 * notice in the mailbox, which on a long-lived INBOX is hundreds of tickets
 * that no human ever needs to see. Ingest no longer does that; this cleans up
 * the ones already in the table.
 *
 * It moves them to Trash rather than deleting: the messages are real, the
 * classification is a heuristic, and an agent can look before anything is
 * destroyed. Pass confirm=1 to apply, otherwise it only reports what it WOULD
 * do -- a dry run is the difference between a maintenance tool and a footgun.
 */
if ($action === 'cleanup_bounces') {
    $confirm = fd_bool('confirm', false);

    /*
     * A ticket is machine noise when EVERY message on it is a bounce or an
     * auto-reply and no agent has ever replied. The "no agent reply" clause is
     * what stops this touching a real conversation that merely happens to have
     * collected a bounce along the way.
     */
    $sql = "SELECT t.id, t.subject, t.requester_email, t.created_at
            FROM fd_tickets t
            WHERE t.is_trash = 0
              AND t.message_count > 0
              AND NOT EXISTS (
                    SELECT 1 FROM fd_messages m
                    WHERE m.ticket_id = t.id
                      AND m.direction = 'outbound'
                      AND m.msg_type <> 'auto_ack'
              )
              AND NOT EXISTS (
                    SELECT 1 FROM fd_messages m
                    WHERE m.ticket_id = t.id
                      AND m.direction = 'inbound'
                      AND m.msg_type <> 'bounce'
                      AND m.is_auto_reply = 0
              )
            ORDER BY t.id ASC
            LIMIT 5000";
    $rows = fd_query($sql);

    if (!$confirm) {
        $sample = array();
        foreach (array_slice($rows, 0, 20) as $r) {
            $sample[] = array('id' => (int)$r['id'], 'subject' => fd_snippet($r['subject'], 90),
                              'from' => $r['requester_email'], 'created' => $r['created_at']);
        }
        api_success(array(
            'dry_run' => true, 'matched' => count($rows), 'sample' => $sample,
        ), count($rows) . ' ticket(s) look like bounce/auto-reply noise. Re-run with confirm=1 to move them to Trash.');
    }

    $moved = 0;
    foreach (array_chunk(array_map(function ($r) { return (int)$r['id']; }, $rows), 200) as $chunk) {
        if (empty($chunk)) continue;
        $place = implode(',', array_fill(0, count($chunk), '?'));
        $moved += fd_exec("UPDATE fd_tickets SET is_trash = 1, updated_at = NOW() WHERE id IN ($place)",
                          str_repeat('i', count($chunk)), $chunk);
    }
    fd_log('info', 'Bounce cleanup moved ' . $moved . ' ticket(s) to Trash');
    api_success(array('moved' => $moved), $moved . ' noise ticket(s) moved to Trash. Review them there, then empty Trash to delete.');
}

/* ---------------------------------------------------------- prune_activity -- */
/*
 * Collapse a flood of repeated events already in fd_activity.
 *
 * Earlier builds wrote one 'sla-breach' row per breached ticket, so a single
 * sweep over an imported backlog could add hundreds. Ingest no longer does that
 * (lib/Sla.php aggregates), but the rows already written still bury everything
 * else in Recent Activities.
 *
 * Keeps the most recent few of the noisy type and deletes the rest. Nothing
 * else is touched -- real events (replies, assignments, new mail) are never
 * candidates. Dry run unless confirm=1.
 */
if ($action === 'prune_activity') {
    $confirm = fd_bool('confirm', false);
    $keep    = max(0, min(50, fd_int('keep', 5)));
    // Only ever the machine-generated, repeatable kinds.
    $noisy   = array('sla-breach', 'test-event');

    $place = implode(',', array_fill(0, count($noisy), '?'));
    $types = str_repeat('s', count($noisy));

    $cnt = fd_query_one("SELECT COUNT(*) AS c FROM fd_activity WHERE event IN ($place)", $types, $noisy);
    $total = $cnt ? (int)$cnt['c'] : 0;

    // The newest $keep of that type survive, so the feed still shows that it
    // happened without repeating it hundreds of times.
    $keepRows = fd_query("SELECT id FROM fd_activity WHERE event IN ($place) ORDER BY id DESC LIMIT $keep",
                         $types, $noisy);
    $keepIds = array_map(function ($r) { return (int)$r['id']; }, $keepRows);
    $removable = max(0, $total - count($keepIds));

    if (!$confirm) {
        api_success(array('dry_run' => true, 'matched' => $total, 'would_delete' => $removable, 'keeping' => count($keepIds)),
            $removable . ' repeated activity row(s) would be removed (keeping the newest ' . count($keepIds) . '). Re-run with confirm=1.');
    }

    if ($removable === 0) api_success(array('deleted' => 0), 'Nothing to prune.');

    $sql = "DELETE FROM fd_activity WHERE event IN ($place)";
    $p = $noisy; $t = $types;
    if (!empty($keepIds)) {
        $kp = implode(',', array_fill(0, count($keepIds), '?'));
        $sql .= " AND id NOT IN ($kp)";
        $t .= str_repeat('i', count($keepIds));
        $p = array_merge($p, $keepIds);
    }
    $deleted = fd_exec($sql, $t, $p);

    fd_log('info', 'Pruned ' . $deleted . ' repeated activity row(s)');
    api_success(array('deleted' => $deleted), $deleted . ' repeated activity row(s) removed.');
}

/* ------------------------------------------------------------------- log -- */
/*
 * The audit trail, read from fd_activity -- the same rows the dashboard feed
 * and the ticket timelines are built from. Every write path already records
 * here through fd_emit(), so this is a view of real history rather than a
 * separate log that could disagree with it.
 */
if ($action === 'audit') {
    $limit  = max(1, min(500, fd_int('limit', 200)));
    $q      = trim(fd_str('q', ''));
    $module = fd_str('module', '');

    $where = array();
    $types = '';
    $args  = array();

    /*
     * "Module" is a grouping of event names, not a column. Tickets, mail and
     * automation each write several event types, and an agent looking for
     * "what happened to tickets" does not know their names.
     */
    $groups = array(
        'Tickets'    => array('ticket-created', 'ticket-updated', 'new-ticket', 'tickets-merged',
                              'tickets-deleted', 'tickets-auto-closed', 'tickets-bulk-closed',
                              'tickets-bulk-updated', 'tickets-spam', 'tickets-trash'),
        'Mail'       => array('new-message', 'message-sent', 'note-added', 'mailbox-down'),
        'Automation' => array('automation-notify'),
        'Customers'  => array('contact-blocked', 'contact-unblocked'),
        'SLA'        => array('sla-breach'),
    );
    if ($module !== '' && isset($groups[$module])) {
        $in = implode(',', array_fill(0, count($groups[$module]), '?'));
        $where[] = "event IN ($in)";
        $types  .= str_repeat('s', count($groups[$module]));
        foreach ($groups[$module] as $e) $args[] = $e;
    }
    if ($q !== '') {
        $where[] = "(summary LIKE ? OR actor_name LIKE ? OR event LIKE ?)";
        $types  .= 'sss';
        $like = '%' . $q . '%';
        $args[] = $like; $args[] = $like; $args[] = $like;
    }
    $sql = "SELECT id, event, actor_type, actor_name, summary, ticket_id, created_at
            FROM fd_activity"
         . (empty($where) ? '' : ' WHERE ' . implode(' AND ', $where))
         . " ORDER BY id DESC LIMIT $limit";

    $rows = empty($args) ? fd_query($sql) : fd_query($sql, $types, $args);

    // Map each event back to the group it came from, so the UI can label a row
    // without repeating the grouping table.
    $moduleOf = array();
    foreach ($groups as $name => $events) {
        foreach ($events as $e) $moduleOf[$e] = $name;
    }
    foreach ($rows as &$r) {
        $r['module'] = isset($moduleOf[$r['event']]) ? $moduleOf[$r['event']] : 'System';
        $r['ago']    = fd_relative_time($r['created_at']);
        $r['dt']     = date('j M Y, h:i a', strtotime($r['created_at']));
        $r['actor_name'] = $r['actor_name'] !== null && $r['actor_name'] !== ''
            ? $r['actor_name']
            : ($r['actor_type'] === 'system' ? 'System' : 'Unknown');
    }
    unset($r);

    api_success(array('rows' => $rows, 'modules' => array_keys($groups)), 'OK');
}

if ($action === 'log') {
    api_success(array('lines' => fd_tail_log(fd_int('lines', 200))), 'OK');
}

api_error('Unknown action: ' . $action, 400);

/** Last N lines of freshdesk.log, newest last. */
function fd_tail_log($n = 100)
{
    $path = FD_LOG_PATH;
    if (!@file_exists($path)) return array();
    $size = @filesize($path);
    if (!$size) return array();
    // Read only the tail: the log can be 5MB and nobody wants that in a JSON body.
    $bytes = min($size, 200000);
    $fp = @fopen($path, 'rb');
    if (!$fp) return array();
    @fseek($fp, -$bytes, SEEK_END);
    $data = @fread($fp, $bytes);
    @fclose($fp);
    $lines = array_values(array_filter(array_map('rtrim', explode("\n", (string)$data))));
    return array_slice($lines, -max(1, (int)$n));
}

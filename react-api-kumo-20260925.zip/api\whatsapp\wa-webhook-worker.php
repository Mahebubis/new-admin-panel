<?php
/*
 * Cron / instant-kick entrypoint for the WhatsApp webhook DRAINER.
 *
 * webhook.php now only writes raw callback bodies to wa_webhook_queue and answers 'ok'. This is
 * what actually applies them — correlating each delivery receipt to a recipient row, moving the
 * row's status, and refreshing the campaign's counters.
 *
 * Cron (the reliable safety net — one line, alongside the send worker's):
 *   * * * * * /usr/local/bin/php /home/istudio/public_html/admin/react-api/api/whatsapp/wa-webhook-worker.php >> /home/istudio/logs/wa-webhook.log 2>&1
 *
 * HTTP fallback (used by wa_wq_kick() so a receipt is applied the moment it arrives rather than
 * at the next cron minute — requires the shared secret, NOT a public endpoint):
 *   GET .../wa-webhook-worker.php?cron_secret=...
 *
 * WHY BOTH: the run below stays alive for WA_WEBHOOK_WORKER_SECONDS polling five times a second,
 * so while it is running a receipt is applied within about 200 ms. Cron guarantees one is always
 * running; the kick covers the gap at a minute boundary and restarts things if a run died.
 */
ini_set('display_errors', 0);
error_reporting(E_ALL & ~E_WARNING & ~E_NOTICE & ~E_DEPRECATED);
$_SERVER['REQUEST_METHOD'] = $_SERVER['REQUEST_METHOD'] ?? 'CLI';

// PHP 8.1+ makes mysqli THROW on connection failure instead of setting ->connect_error, and with
// display_errors off an uncaught exception here would vanish without a trace.
try {
    require_once __DIR__ . '/../../config/database.php';
} catch (\Throwable $e) {
    @file_put_contents(__DIR__ . '/wa-webhook.log', '[' . date('Y-m-d H:i:s') . '] FATAL — could not connect to the database: '
        . '[' . get_class($e) . '] ' . $e->getMessage() . "\n", FILE_APPEND);
    exit;
}

require_once __DIR__ . '/lib/config.php';
require_once __DIR__ . '/lib/schema.php';
require_once __DIR__ . '/lib/WaWebhookQueue.php';
require_once __DIR__ . '/lib/WaWebhookProcessor.php';

whatsapp_ensure_schema();
wa_inbox_ensure_schema();
wa_wq_ensure_schema();

$isCli = (php_sapi_name() === 'cli');
$isAuthorizedHttp = !$isCli && ($_GET['cron_secret'] ?? '') === WA_CRON_SECRET;
if (!$isCli && !$isAuthorizedHttp) {
    http_response_code(403);
    echo "forbidden\n";
    exit;
}

/*
 * Exclusive lock, with its own file so this never blocks the SEND worker — the two run at the
 * same time by design: one is pushing messages out while the other is taking receipts in.
 *
 * A failed lock is a completely normal outcome here, not an error: cron fires every minute while
 * a run lasts ~55 seconds, and every kick from webhook.php tries too. Silent exit, no log line —
 * logging it would write thousands of "already running" lines an hour.
 */
$lockFp = fopen(sys_get_temp_dir() . '/wa_webhook_drainer.lock', 'c');
if (!$lockFp || !flock($lockFp, LOCK_EX | LOCK_NB)) {
    exit;
}

// The HTTP kick path arrives with the default 30s ceiling, which would kill the loop mid-chunk
// and strand rows in 'processing' until the next run requeues them.
@set_time_limit(0);
ignore_user_abort(true);

$startedAt = microtime(true);
$deadline  = $startedAt + WA_WEBHOOK_WORKER_SECONDS;

try {
    $totals = wa_wq_drain_loop($deadline);
} catch (\Throwable $e) {
    wa_wq_log('drainer ABORTED — [' . get_class($e) . '] ' . $e->getMessage()
        . ' (rows stay queued; the next run retries them)');
    flock($lockFp, LOCK_UN);
    fclose($lockFp);
    exit;
}

/*
 * One summary line per run, and only when there was something to say. An idle minute writes
 * nothing at all — this endpoint runs 1,440 times a day and a heartbeat per run would bury the
 * lines that matter.
 *
 * worstLag is the number to watch: it is how long the OLDEST receipt in any chunk waited between
 * arriving and being applied. Single digits means the pipeline is keeping up. If it climbs into
 * the minutes during a large campaign, raise WA_WEBHOOK_CHUNK before anything else.
 */
if ($totals['claimed'] > 0) {
    wa_wq_log(sprintf('drain run: %d callback(s) in %d chunk(s), %d event(s), %d applied, worst lag %ds, %.1fs elapsed',
        $totals['claimed'], $totals['chunks'], $totals['events'], $totals['applied'],
        $totals['worstLag'], microtime(true) - $startedAt));
}

/*
 * Housekeeping, once an hour rather than once a run: park anything that has been stuck in
 * 'processing' far longer than a chunk could possibly take (a run killed mid-flight), and drop
 * parked error rows old enough that nobody is going to read them.
 */
if ((int)date('i') === 0) {
    $conn->query("UPDATE wa_webhook_queue SET status='pending', claim_token=NULL
                   WHERE status='processing'
                     AND (claimed_at IS NULL OR claimed_at < DATE_SUB(NOW(), INTERVAL 10 MINUTE))
                     AND attempts < " . (int)WA_WEBHOOK_MAX_ATTEMPTS);
    $conn->query("DELETE FROM wa_webhook_queue WHERE status='error' AND received_at < DATE_SUB(NOW(), INTERVAL 7 DAY)");
}

flock($lockFp, LOCK_UN);
fclose($lockFp);

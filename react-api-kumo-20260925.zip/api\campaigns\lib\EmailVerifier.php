<?php
/*
 * lib/EmailVerifier.php — "does this address actually exist?", asked before we send to it.
 *
 * WHY THIS EXISTS
 * A bulk verification of one 2,303-contact segment came back 87% INVALID. Sending to those is not
 * merely wasted: every send to a dead mailbox is a hard bounce, and a bounce rate in that region
 * is what gets a sending domain throttled and then blocked by the receiving networks. One bad
 * campaign poisons the deliverability of every good one after it, including the transactional mail
 * that has nothing to do with marketing.
 *
 * So the audience is checked BEFORE the send, and anything that does not exist goes on the
 * blocklist — the same list a hard bounce already writes to (see ElasticEmailEventSink). That is
 * the whole design: this does not add a second exclusion mechanism, it feeds the one that is
 * already enforced everywhere. resolve_audience_users() drops blocklisted addresses for every
 * campaign, and journey dispatch checks journey_is_blocklisted() before every email. Once an
 * address is written there, it costs nothing to skip it for ever afterwards.
 *
 * ── HOW IT STAYS CHEAP ────────────────────────────────────────────────────────
 * Verification is a paid, rate-limited API call, and the audiences here overlap heavily — the same
 * students appear in campaign after campaign. Four things keep the bill down, in order of how much
 * they save:
 *
 *   1. A VERDICT IS STORED FOR EVER (email_verifications). The second campaign to include an
 *      address pays nothing for it. Across a few sends this is the difference between thousands of
 *      calls and a handful.
 *   2. ALREADY-BLOCKLISTED ADDRESSES ARE NEVER SENT. They are excluded from the audience anyway,
 *      so verifying them would be paying to learn something already acted on.
 *   3. OBVIOUS RUBBISH IS REJECTED LOCALLY. A malformed address needs no API call to disqualify.
 *   4. THE REST GO OUT IN PARALLEL, through the same curl_multi machinery the send path uses, so
 *      a few thousand checks are a matter of seconds rather than one round trip each.
 *
 * ── WHAT IT REFUSES TO DO ─────────────────────────────────────────────────────
 * It never blocks a send because verification itself failed. A missing API key, a network error, a
 * rate-limit — all of those leave the address unverified and the send proceeds. Treating "we could
 * not check" as "it is bad" would let an outage at the verification provider silently empty an
 * audience, which is a far worse failure than the bounces it was trying to prevent.
 *
 * It also never caches a failure. An address we could not reach a verdict on is simply not stored,
 * so the next campaign tries it again rather than inheriting a guess.
 */

require_once __DIR__ . '/ParallelSender.php';

/** Elastic Email's single-address verification. POST, address on the path, no body. */
if (!defined('EMAIL_VERIFY_ENDPOINT')) define('EMAIL_VERIFY_ENDPOINT', 'https://api.elasticemail.com/v4/verifications/');

/*
 * How long a verdict is trusted.
 *
 * A mailbox that existed six months ago may be closed today, so a verdict is not permanent. But
 * re-checking on a shorter cycle costs real money for an answer that almost never changes, and the
 * genuinely useful signal for an address that dies later is the hard bounce — which already
 * blocklists it. Six months is the point where the two considerations meet.
 */
if (!defined('EMAIL_VERIFY_TTL_DAYS')) define('EMAIL_VERIFY_TTL_DAYS', 180);

/** In-flight checks at once. Matches the send path's default; the API is not the bottleneck. */
if (!defined('EMAIL_VERIFY_CONCURRENCY')) define('EMAIL_VERIFY_CONCURRENCY', 24);

/*
 * The most addresses one materialisation will verify.
 *
 * A ceiling, not a target. It exists so that the first send after switching this on cannot turn
 * into a half-hour of API calls against an audience nobody has ever verified — the run does what it
 * can, logs how many it left, and the next campaign picks up where it stopped because every verdict
 * it did reach is now cached. Anything left unverified is simply sent to, exactly as before.
 */
if (!defined('EMAIL_VERIFY_MAX_PER_RUN')) define('EMAIL_VERIFY_MAX_PER_RUN', 5000);

/** Per-request timeout. Verification is a DNS/SMTP probe on their side, so it is not instant. */
if (!defined('EMAIL_VERIFY_TIMEOUT')) define('EMAIL_VERIFY_TIMEOUT', 20);

/* ════════════════════════════════════════════════════════════════════════════
   Schema
   ═══════════════════════════════════════════════════════════════════════════ */

/**
 * The verdict cache. Created on first use, like every other table in this feature.
 *
 * Keyed on the address itself rather than a surrogate id: every read is "what do we know about
 * this address", and a UNIQUE on the email is what makes the bulk INSERT ... ON DUPLICATE KEY
 * UPDATE below a single statement instead of a select-then-write per row.
 */
function email_verify_ensure_schema(): void {
    global $conn;
    static $done = false;
    if ($done) return;
    $done = true;

    @$conn->query("CREATE TABLE IF NOT EXISTS email_verifications (
        email        VARCHAR(190) NOT NULL PRIMARY KEY,
        -- Elastic Email returns two judgements and they answer different questions:
        --   result     what it could establish        None|Valid|Unknown|Risky|Invalid
        --   predicted  what its model expects         None|Valid|LowRisk|HighRisk|Invalid
        -- Both are stored because the blocking rule reads them together, and because a change to
        -- that rule must not require re-verifying the whole audience to apply.
        result       VARCHAR(16)  NOT NULL DEFAULT 'None',
        predicted    VARCHAR(16)  NOT NULL DEFAULT 'None',
        score        DECIMAL(6,3) DEFAULT NULL,
        reason       VARCHAR(255) DEFAULT NULL,
        disposable   TINYINT(1)   NOT NULL DEFAULT 0,
        role_address TINYINT(1)   NOT NULL DEFAULT 0,
        blocked      TINYINT(1)   NOT NULL DEFAULT 0,
        verified_at  DATETIME     NOT NULL,
        INDEX idx_result (result),
        INDEX idx_verified (verified_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    /*
     * How many addresses verification removed from a campaign's audience.
     *
     * On the campaign row rather than derived, because the evidence is gone by the time anyone
     * asks: the whole point is that those addresses are never written as recipients, so there is
     * no row to count later. Without this the audience simply comes out smaller than the segment
     * and nothing on screen says why — which reads as a bug in the segment.
     */
    $c = @$conn->query("SHOW COLUMNS FROM email_campaigns LIKE 'verification_skipped'");
    if ($c && $c->num_rows === 0) {
        @$conn->query("ALTER TABLE email_campaigns ADD COLUMN verification_skipped INT NOT NULL DEFAULT 0 AFTER reachable_count");
    }

    /*
     * THIS campaign's own answer to "verify first?".
     *
     * NULL, not 0, for anything that has not been asked — which is every campaign created before
     * the choice existed. Those follow the Settings default, and a campaign that has genuinely
     * chosen "no" is a different thing from one that was never offered the question. Collapsing
     * the two would mean turning the default on could never reach an old draft.
     */
    $c = @$conn->query("SHOW COLUMNS FROM email_campaigns LIKE 'verify_before_send'");
    if ($c && $c->num_rows === 0) {
        @$conn->query("ALTER TABLE email_campaigns ADD COLUMN verify_before_send TINYINT(1) DEFAULT NULL AFTER verification_skipped");
    }

    // The journey's own answer. Same reasoning, and NULL means the same thing.
    $c = @$conn->query("SHOW COLUMNS FROM journeys LIKE 'verify_before_send'");
    if ($c && $c->num_rows === 0) {
        @$conn->query("ALTER TABLE journeys ADD COLUMN verify_before_send TINYINT(1) DEFAULT NULL");
    }

    // The two controls, kept on the Elastic Email row because that is whose API key does the work.
    // They govern EVERY sender though — a dead mailbox is dead whoever is delivering to it.
    foreach ([
        'verify_before_send'  => "ADD COLUMN verify_before_send TINYINT(1) NOT NULL DEFAULT 0",
        'verify_block_risky'  => "ADD COLUMN verify_block_risky TINYINT(1) NOT NULL DEFAULT 0",
    ] as $col => $ddl) {
        $c = @$conn->query("SHOW COLUMNS FROM email_esp_settings LIKE '$col'");
        if ($c && $c->num_rows === 0) @$conn->query("ALTER TABLE email_esp_settings $ddl");
    }
}

/* ════════════════════════════════════════════════════════════════════════════
   Settings
   ═══════════════════════════════════════════════════════════════════════════ */

/**
 * The API key, and the DEFAULT for anything that has not made its own choice.
 *
 * Verification is decided per campaign and per journey — see email_verify_enabled(). What lives in
 * Settings is only what a NEW campaign or journey starts out as, plus the key that does the work,
 * because a global switch turned out to be the wrong shape: one campaign to a freshly imported
 * list wants every address checked, and the next one to a segment of paying students has nothing
 * to gain from spending credits on people who have been mailed for a year.
 *
 * @return array{on: bool, blockRisky: bool, apiKey: string}
 */
function email_verify_settings(): array {
    global $conn;
    static $cached = null;
    if ($cached !== null) return $cached;

    email_verify_ensure_schema();
    $r = @$conn->query("SELECT api_key, verify_before_send, verify_block_risky
                          FROM email_esp_settings WHERE provider='elasticemail' LIMIT 1");
    $row = $r ? $r->fetch_assoc() : null;

    $key = trim((string)($row['api_key'] ?? ''));
    return $cached = [
        // No key means no verification, whatever the switch says: the switch is an intention and
        // the key is the capability, and a send must never stall on the difference.
        'on'         => $key !== '' && (int)($row['verify_before_send'] ?? 0) === 1,
        'blockRisky' => (int)($row['verify_block_risky'] ?? 0) === 1,
        'apiKey'     => $key,
    ];
}

/* ════════════════════════════════════════════════════════════════════════════
   The verdict
   ═══════════════════════════════════════════════════════════════════════════ */

/**
 * The single word this address earned. Valid | LowRisk | HighRisk | Invalid | Unknown.
 *
 * Elastic Email answers twice — what it could establish (result) and what its model expects
 * (predicted) — and the two disagree often enough to matter: a dead mailbox at a catch-all domain
 * comes back Unknown with a predicted HighRisk. The worse of the two is the honest summary, and it
 * is what the blocklist entry and the report both quote.
 */
function email_verify_label(array $v): string {
    $result    = (string)($v['result'] ?? 'None');
    $predicted = (string)($v['predicted'] ?? 'None');

    if ($result === 'Invalid' || $predicted === 'Invalid') return 'Invalid';
    if ($result === 'Risky'   || $predicted === 'HighRisk') return 'HighRisk';
    if ($predicted === 'LowRisk') return 'LowRisk';
    if ($result === 'Valid'   || $predicted === 'Valid')    return 'Valid';
    return 'Unknown';
}

/**
 * Should this verdict keep the address out of the send?
 *
 * INVALID and HIGH RISK. Invalid is the provider saying the mailbox does not exist. High risk is
 * a disposable address, a role account, or a domain that accepts everything and delivers what it
 * feels like — the bucket that produces most of the bounces that are not outright invalid, and
 * bounces are what cost a sending domain its reputation.
 *
 * LOW RISK and VALID send. So does UNKNOWN, which is the provider being honest that it could not
 * reach a conclusion rather than evidence against the address — a real Gmail mailbox and a dead
 * one both come back Unknown, because Gmail does not confirm mailboxes to verifiers.
 */
function email_verify_is_blocking(array $v): bool {
    $label = email_verify_label($v);
    return $label === 'Invalid' || $label === 'HighRisk';
}

/** A one-line reason for the blocklist entry, so the row says why it is there months later. */
function email_verify_reason(array $v): string {
    // The bucket first, because that is the word the report and the settings screen use, and a
    // blocklist row read six months later has to be traceable to the decision that put it there.
    $bits = [email_verify_label($v)];
    if (!empty($v['disposable'])) $bits[] = 'disposable';
    if (!empty($v['role_address'])) $bits[] = 'role address';
    $why = trim((string)($v['reason'] ?? ''));
    if ($why !== '') $bits[] = $why;
    return 'Verification: ' . implode(', ', $bits);
}

/**
 * Obviously unusable before any money is spent.
 *
 * Only shapes no mail server could ever accept. Deliberately not clever: this decides to blocklist
 * somebody, and a regex that is too strict about what a legal address looks like removes real
 * people. Anything that gets past this is the API's question to answer.
 */
function email_verify_locally_dead(string $email): bool {
    if ($email === '' || strlen($email) > 190) return true;
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) return true;
    $domain = substr(strrchr($email, '@') ?: '', 1);
    return $domain === '' || strpos($domain, '.') === false;
}

/* ════════════════════════════════════════════════════════════════════════════
   The API
   ═══════════════════════════════════════════════════════════════════════════ */

/** One verification request, in the shape ParallelSender's curl_multi loop consumes. */
function email_verify_request(string $email, string $apiKey): array {
    return [
        'url'     => EMAIL_VERIFY_ENDPOINT . rawurlencode($email),
        'headers' => ['X-ElasticEmail-ApiKey: ' . $apiKey, 'Content-Type: application/json'],
        // The address is on the path and the body is empty, but it is still a POST — so the
        // options are spelled out rather than borrowed from the send path's default builder.
        'curlopts' => [
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS    => '',
            CURLOPT_HTTPHEADER    => ['X-ElasticEmail-ApiKey: ' . $apiKey, 'Content-Type: application/json'],
        ],
    ];
}

/**
 * One response, normalised — or null when no verdict was reached.
 *
 * Null is the important return. A 401, a 429, a timeout and a malformed body all mean "we do not
 * know", and none of them may be recorded or acted on: a cached non-answer would be re-read as a
 * verdict on every later campaign, and this is a function whose output removes people from
 * audiences.
 */
function email_verify_parse(int $status, ?string $body): ?array {
    if ($status < 200 || $status >= 300) return null;
    $d = json_decode((string)$body, true);
    if (!is_array($d)) return null;

    // The SDK's model is snake_case; the REST payload is PascalCase. Both spellings are read so a
    // change of shape at their end degrades to "unknown" rather than to a wrong verdict.
    $pick = function (array $keys) use ($d) {
        foreach ($keys as $k) if (array_key_exists($k, $d)) return $d[$k];
        return null;
    };
    $result    = (string)($pick(['Result', 'result']) ?? 'None');
    $predicted = (string)($pick(['PredictedStatus', 'predicted_status']) ?? 'None');
    if ($result === '' && $predicted === '') return null;

    return [
        'result'       => $result !== '' ? $result : 'None',
        'predicted'    => $predicted !== '' ? $predicted : 'None',
        'score'        => is_numeric($pick(['PredictedScore', 'predicted_score'])) ? (float)$pick(['PredictedScore', 'predicted_score']) : null,
        'reason'       => mb_substr((string)($pick(['Reason', 'reason']) ?? ''), 0, 250),
        'disposable'   => !empty($pick(['Disposable', 'disposable'])) ? 1 : 0,
        'role_address' => !empty($pick(['Role', 'role'])) ? 1 : 0,
    ];
}

/* ════════════════════════════════════════════════════════════════════════════
   The cache
   ═══════════════════════════════════════════════════════════════════════════ */

/**
 * Verdicts already held for these addresses, still inside their TTL.
 *
 * @param string[] $emails already lowercased
 * @return array<string, array> email => verdict
 */
function email_verify_cached(array $emails): array {
    global $conn;
    if (!$emails) return [];

    $out = [];
    foreach (array_chunk($emails, 500) as $chunk) {
        $in = "'" . implode("','", array_map([$conn, 'real_escape_string'], $chunk)) . "'";
        $r = @$conn->query("SELECT email, result, predicted, score, reason, disposable, role_address
                              FROM email_verifications
                             WHERE email IN ($in)
                               AND verified_at >= DATE_SUB(NOW(), INTERVAL " . (int)EMAIL_VERIFY_TTL_DAYS . " DAY)");
        while ($r && $row = $r->fetch_assoc()) $out[(string)$row['email']] = $row;
    }
    return $out;
}

/** Writes verdicts back, in one statement per chunk rather than one per address. */
function email_verify_store(array $verdicts): void {
    global $conn;
    if (!$verdicts) return;

    $rows = [];
    foreach ($verdicts as $email => $v) {
        $rows[] = "('" . $conn->real_escape_string($email) . "','"
            . $conn->real_escape_string((string)$v['result']) . "','"
            . $conn->real_escape_string((string)$v['predicted']) . "',"
            . ($v['score'] === null ? 'NULL' : (float)$v['score']) . ",'"
            . $conn->real_escape_string((string)$v['reason']) . "',"
            . (int)$v['disposable'] . ',' . (int)$v['role_address'] . ','
            . (email_verify_is_blocking($v) ? 1 : 0) . ", NOW())";
    }
    foreach (array_chunk($rows, 300) as $chunk) {
        @$conn->query("INSERT INTO email_verifications
            (email, result, predicted, score, reason, disposable, role_address, blocked, verified_at)
            VALUES " . implode(',', $chunk) . "
            ON DUPLICATE KEY UPDATE
                result = VALUES(result), predicted = VALUES(predicted), score = VALUES(score),
                reason = VALUES(reason), disposable = VALUES(disposable),
                role_address = VALUES(role_address), blocked = VALUES(blocked),
                verified_at = VALUES(verified_at)");
    }
}

/* ════════════════════════════════════════════════════════════════════════════
   The entry point
   ═══════════════════════════════════════════════════════════════════════════ */

/**
 * Is verification on for THIS send?
 *
 * The caller's own answer wins. A campaign and a journey each carry their own choice, and null
 * means they have not made one — a record created before this existed — in which case the Settings
 * default applies. The API key is the veto either way: an intention to verify with nothing to
 * verify through is not a reason to hold up a send.
 */
function email_verify_enabled(?bool $callerWants): bool {
    $cfg = email_verify_settings();
    if ($cfg['apiKey'] === '') return false;
    return $callerWants === null ? $cfg['on'] : $callerWants;
}

/**
 * Verifies a set of addresses and blocklists the ones that do not exist.
 *
 * @param string[] $emails      raw addresses; case and duplicates are handled here
 * @param callable|null $log    optional line logger, so the caller's own log carries the summary
 * @param bool|null $enabled    this campaign's or journey's own choice; null uses the default
 * @return array<string, true>  the addresses that must NOT be sent to, lowercased
 */
function email_verify_and_block(array $emails, ?callable $log = null, ?bool $enabled = null): array {
    global $conn;

    $say = $log ?: function () {};
    $cfg = email_verify_settings();
    if (!email_verify_enabled($enabled)) return [];

    email_verify_ensure_schema();

    // ── 1. normalise, and drop what needs no call ────────────────────────────
    $wanted = [];
    foreach ($emails as $e) {
        $e = strtolower(trim((string)$e));
        if ($e !== '') $wanted[$e] = true;
    }
    if (!$wanted) return [];

    $blocked = [];
    /*
     * Already on the blocklist. Not verified and not re-added: the audience resolver has already
     * removed them, so a call here would be paying to confirm a decision that is in force.
     */
    $already = function_exists('blocklisted_emails') ? blocklisted_emails() : [];
    foreach (array_keys($wanted) as $e) {
        if (isset($already[$e])) { unset($wanted[$e]); $blocked[$e] = true; }
    }

    $malformed = [];
    foreach (array_keys($wanted) as $e) {
        if (email_verify_locally_dead($e)) { unset($wanted[$e]); $malformed[] = $e; $blocked[$e] = true; }
    }

    // ── 2. what we already know ──────────────────────────────────────────────
    /*
     * ALREADY VERIFIED — the whole reason this stays affordable.
     *
     * A verdict is kept for ever, so an address that appeared in last week's campaign is decided
     * here with no API call at all. On overlapping audiences, which is what a student list is,
     * this is the difference between paying for every send and paying once per person.
     */
    $cached = email_verify_cached(array_keys($wanted));
    foreach ($cached as $e => $v) {
        unset($wanted[$e]);
        if (email_verify_is_blocking($v)) $blocked[$e] = true;
    }

    // ── 3. everything left is a real call ────────────────────────────────────
    $toCheck = array_keys($wanted);
    $skipped = 0;
    if (count($toCheck) > EMAIL_VERIFY_MAX_PER_RUN) {
        $skipped = count($toCheck) - EMAIL_VERIFY_MAX_PER_RUN;
        $toCheck = array_slice($toCheck, 0, EMAIL_VERIFY_MAX_PER_RUN);
    }

    $fresh = [];
    $failed = 0;
    if ($toCheck && !email_verify_service_down()) {
        /*
         * A PROBE FIRST, then the rest.
         *
         * The service can refuse the whole account at once — "Your contacts limit is too low.
         * Please upgrade your plan." is what it answers today, to every single address. Sending
         * the full run at it then costs five thousand pointless requests and about half a minute
         * per attempt, and campaign #113 spent an hour repeating exactly that: each cron tick
         * re-resolved 23,216 addresses, failed 5,000 checks, lost its database connection during
         * the wait and died before a single recipient row was written.
         *
         * So a small batch goes first. If not one address in it gets a verdict, the account is
         * being refused rather than a few addresses being unlucky, and the run stops there and
         * mails the audience unverified — which is the right trade: verification protects the
         * sending domain, but it must never become the reason nothing is sent at all.
         */
        /*
         * Worked through in small chunks, and every chunk is SAVED AS SOON AS IT ARRIVES.
         *
         * The old code checked up to five thousand addresses and stored the lot at the end. A crash
         * anywhere in between — and a run this long is exactly where the database connection times
         * out — threw away every verdict that had just been paid for, so the next attempt bought
         * the same answers again. That is how one campaign span through 380,000 checks in an hour
         * against the same five thousand people.
         */
        $probeSize = min(count($toCheck), (int)EMAIL_VERIFY_PROBE_SIZE);
        $chunks = array_merge([array_slice($toCheck, 0, $probeSize)],
                              array_chunk(array_slice($toCheck, $probeSize), (int)EMAIL_VERIFY_STORE_CHUNK));
        $done = 0;
        foreach ($chunks as $i => $slice) {
            if (!$slice) continue;

            // Claimed before the calls, so the hour's ceiling holds even with two workers running.
            $allowed = email_verify_budget_take(count($slice));
            if ($allowed < count($slice)) {
                $skipped += count($toCheck) - $done - $allowed;
                if ($allowed === 0) {
                    $say('verification: this hour\'s limit of ' . EMAIL_VERIFY_MAX_PER_HOUR
                       . ' checks is used up — the rest of this audience is sent unverified.');
                    email_verify_budget_alert();
                    break;
                }
                $slice = array_slice($slice, 0, $allowed);
            }

            $jobs = [];
            foreach ($slice as $e) $jobs[] = ['key' => $e, 'rid' => null, 'req' => email_verify_request($e, $cfg['apiKey'])];
            $sliceFresh = []; $sliceFailed = 0; $lastBody = '';
            foreach (email_verify_run($jobs) as $e => [$status, $body]) {
                $v = email_verify_parse((int)$status, $body);
                if ($v === null) { $failed++; $sliceFailed++; $lastBody = (string)$body; continue; }
                $sliceFresh[$e] = $v;
                $fresh[$e] = $v;
                if (email_verify_is_blocking($v)) $blocked[$e] = true;
            }
            // Kept now, not at the end: what has been paid for is never bought twice.
            if ($sliceFresh) { email_verify_store($sliceFresh); campaign_verify_db_alive(); }
            $done += count($slice);

            if ($i === 0 && $sliceFailed === count($slice)) {
                $skipped += max(0, count($toCheck) - $done);
                email_verify_mark_down($lastBody);
                $say('verification: the service refused every check — ' . email_verify_reason_text($lastBody)
                   . '. Skipped for this send and paused for ' . EMAIL_VERIFY_COOLDOWN_MINUTES . ' minutes; the send continues unverified.');
                break;
            }
        }
    } elseif ($toCheck) {
        $skipped += count($toCheck);
        $say('verification: paused because the service is refusing checks — the send continues unverified.');
    }

    // ── 4. the blocklist, which is what every later send actually reads ──────
    /*
     * Written in bulk, and without the per-address provider fan-out.
     *
     * contact_upsert() suppresses the address at every configured ESP as a side effect, which is
     * right when an address earned its block by bouncing. Here it would be three outbound HTTP
     * calls for each of what can be thousands of addresses — on the segment that prompted this
     * feature, 1,993 of 2,303 were invalid, so roughly six thousand sequential requests inside
     * the send worker. contact_upsert_many() does the same writes as two statements per chunk.
     */
    $added = 0;
    $toWrite = [];
    foreach (array_keys($blocked) as $e) {
        if (isset($already[$e])) continue;   // it was already there; nothing to write
        $v = $fresh[$e] ?? $cached[$e] ?? null;
        $toWrite[] = ['email' => $e, 'reason' => $v ? email_verify_reason($v) : 'Verification: not a usable address'];
    }
    if ($toWrite && function_exists('lists_get_or_create_blocklist_id') && function_exists('contact_upsert_many')) {
        $listId = lists_get_or_create_blocklist_id();
        foreach (array_chunk($toWrite, 500) as $chunk) {
            @contact_upsert_many($chunk, $listId, false);
            $added += count($chunk);
        }
    }

    $say(sprintf(
        'verification: %d address(es) in, %d cached, %d checked, %d unreachable verdict(s), %d malformed, %d skipped over the per-run cap, %d blocklisted (%d newly)',
        count($emails), count($cached), count($toCheck), $failed, count($malformed), $skipped, count($blocked), $added
    ));

    return $blocked;
}

/**
 * Runs the checks, at most EMAIL_VERIFY_CONCURRENCY in flight.
 *
 * Its own loop rather than esp_send_parallel(), which is bound to an EspTransport and folds every
 * response through that transport's send-result parser. The mechanics below are the same ones, and
 * the same reason applies: several thousand sequential round trips would take longer than the send
 * they are protecting.
 *
 * @return array<string, array{0:int,1:?string}> email => [http status, body]
 */
/* How many addresses are tried before deciding the service itself is refusing us. */
if (!defined('EMAIL_VERIFY_PROBE_SIZE')) define('EMAIL_VERIFY_PROBE_SIZE', 25);
/* How long verification stays paused after that, so every tick does not re-discover it. */
if (!defined('EMAIL_VERIFY_COOLDOWN_MINUTES')) define('EMAIL_VERIFY_COOLDOWN_MINUTES', 30);

/*
 * THE MOST CHECKS THIS ACCOUNT MAY BUY IN AN HOUR.
 *
 * Verification is paid per address, and on 23 September a stuck campaign spent an entire 200,000
 * allowance in about forty minutes: it re-checked the same five thousand addresses once a minute,
 * seventy-six times, because the results were never saved and the campaign never finished. Nobody
 * asked for 380,000 checks and nothing on screen said they were happening.
 *
 * A ceiling cannot make the system correct, and the real repairs are elsewhere in this file (keep
 * what was paid for, stop when the provider refuses). This is the seatbelt: whatever goes wrong
 * next, it cannot cost more than one hour's worth before somebody is told.
 */
if (!defined('EMAIL_VERIFY_MAX_PER_HOUR')) define('EMAIL_VERIFY_MAX_PER_HOUR', 10000);

/** Verdicts are written in chunks this size, so a crash never throws away checks already paid for. */
if (!defined('EMAIL_VERIFY_STORE_CHUNK')) define('EMAIL_VERIFY_STORE_CHUNK', 250);

function email_verify_state_ensure_schema(): void {
    global $conn;
    static $done = false;
    if ($done) return;
    $done = true;
    @$conn->query("CREATE TABLE IF NOT EXISTS email_verify_state (
        id           TINYINT UNSIGNED NOT NULL PRIMARY KEY,
        paused_until DATETIME     DEFAULT NULL,
        last_error   VARCHAR(500) DEFAULT NULL,
        window_start DATETIME     DEFAULT NULL,
        used_count   INT UNSIGNED NOT NULL DEFAULT 0,
        updated_at   DATETIME     DEFAULT NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    /*
     * Installs that already have the table from the first version of this file.
     *
     * Wrapped, because mysqli throws on PHP 8.1+ and '@' does not stop an exception: a column that
     * is already there would otherwise throw out of here, and the caller's catch would hand back
     * "spend whatever you asked for" — the spending limit quietly disabled by a schema no-op.
     */
    foreach (['window_start DATETIME DEFAULT NULL', 'used_count INT UNSIGNED NOT NULL DEFAULT 0'] as $ddl) {
        $col = strtok($ddl, ' ');
        try {
            $r = @$conn->query("SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = DATABASE()
                                 AND TABLE_NAME = 'email_verify_state' AND COLUMN_NAME = '$col' LIMIT 1");
            if (!$r || $r->num_rows === 0) @$conn->query("ALTER TABLE email_verify_state ADD COLUMN $ddl");
        } catch (\Throwable $e) { /* already there, or added by another worker a moment ago */ }
    }
}

/**
 * Claims up to $want checks against this hour's allowance, and returns how many may actually be
 * made. Claimed before the calls go out, not after, so two workers cannot both spend the last of it.
 *
 * @return int 0 means the hour is spent
 */
function email_verify_budget_take(int $want): int {
    global $conn;
    if ($want < 1) return 0;
    try {
        email_verify_state_ensure_schema();
        $now = date('Y-m-d H:i:s');
        @$conn->query("INSERT IGNORE INTO email_verify_state (id, window_start, used_count, updated_at)
                       VALUES (1, '$now', 0, '$now')");
        // A window older than an hour is over; start a fresh one.
        @$conn->query("UPDATE email_verify_state
                          SET window_start = '$now', used_count = 0
                        WHERE id = 1 AND (window_start IS NULL OR window_start < DATE_SUB(NOW(), INTERVAL 1 HOUR))");
        $r = @$conn->query("SELECT used_count FROM email_verify_state WHERE id = 1 LIMIT 1");
        $used = $r ? (int)($r->fetch_assoc()['used_count'] ?? 0) : 0;
        $left = max(0, (int)EMAIL_VERIFY_MAX_PER_HOUR - $used);
        $take = min($want, $left);
        if ($take > 0) @$conn->query("UPDATE email_verify_state SET used_count = used_count + $take, updated_at = '$now' WHERE id = 1");
        return $take;
    } catch (\Throwable $e) {
        // Bookkeeping must never stop a send; without a counter, fall back to the per-run cap.
        return $want;
    }
}

/** Is verification paused because the provider was refusing every call? */
function email_verify_service_down(): bool {
    global $conn;
    try {
        email_verify_state_ensure_schema();
        $r = @$conn->query("SELECT paused_until FROM email_verify_state WHERE id = 1 AND paused_until > NOW() LIMIT 1");
        return (bool)($r && $r->num_rows > 0);
    } catch (\Throwable $e) { return false; }
}

/** Says once per hour that the ceiling was reached — a runaway is loud instead of expensive. */
function email_verify_budget_alert(): void {
    if (!function_exists('alert_notify')) return;
    alert_notify('email-verify-budget', 'Address verification hit its hourly limit',
        'Verification stopped after ' . EMAIL_VERIFY_MAX_PER_HOUR . ' checks in one hour, and the rest of the '
        . 'audience is being sent unverified. That many checks in an hour is not normal traffic — it usually '
        . 'means something is repeating work.',
        ['Limit'  => EMAIL_VERIFY_MAX_PER_HOUR . ' checks per hour (EMAIL_VERIFY_MAX_PER_HOUR)',
         'Check'  => 'worker.log for a campaign resolving its audience over and over'],
        'error');
}

/**
 * The database after a long wait on someone else's API.
 *
 * Same job as campaign_db_alive() in SendWorker.php, which is not loaded on every path that
 * verifies — the journey engine verifies one address at a time without it.
 */
function campaign_verify_db_alive(): void {
    global $conn;
    if (function_exists('campaign_db_alive')) { campaign_db_alive(); return; }
    try {
        if (@$conn->query('SELECT 1')) return;
    } catch (\Throwable $e) { /* fall through */ }
    try {
        $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
        $conn->set_charset('utf8mb4');
    } catch (\Throwable $e) { /* the caller's next query will report it */ }
}

/** The provider's own words, trimmed to something a log line can carry. */
function email_verify_reason_text(string $body): string {
    $d = json_decode($body, true);
    $why = is_array($d) ? trim((string)($d['Error'] ?? $d['error'] ?? '')) : '';
    if ($why === '') $why = trim(mb_substr($body, 0, 160));
    return $why !== '' ? $why : 'no answer from the verification service';
}

/**
 * Pause verification, and tell somebody once.
 *
 * Silence here is expensive in a different way from a failed send: nothing breaks, the mail goes
 * out, and the protection everyone believes is on has quietly been off for however long it takes
 * for a bounce rate to climb enough to notice.
 */
function email_verify_mark_down(string $body): void {
    global $conn;
    try {
        email_verify_state_ensure_schema();
        $why = $conn->real_escape_string(mb_substr(email_verify_reason_text($body), 0, 480));
        $until = date('Y-m-d H:i:s', time() + (int)EMAIL_VERIFY_COOLDOWN_MINUTES * 60);
        $now = date('Y-m-d H:i:s');
        @$conn->query("INSERT INTO email_verify_state (id, paused_until, last_error, updated_at)
                       VALUES (1, '$until', '$why', '$now')
                       ON DUPLICATE KEY UPDATE paused_until = VALUES(paused_until),
                                               last_error   = VALUES(last_error),
                                               updated_at   = VALUES(updated_at)");
        if (function_exists('alert_notify')) {
            alert_notify('email-verify-down', 'Address verification is not running',
                'The verification service refused every check, so sends are going out unverified. '
                . 'Nothing is blocked and nothing is stuck — but bad addresses are no longer being caught.',
                ['Provider said' => email_verify_reason_text($body),
                 'Paused for'    => EMAIL_VERIFY_COOLDOWN_MINUTES . ' minutes, then it is tried again',
                 'Fix'           => 'Check the Elastic Email plan — verification is billed separately from sending.'],
                'error');
        }
    } catch (\Throwable $e) { /* never block a send over bookkeeping */ }
}

function email_verify_run(array $jobs): array {
    $out = [];
    if (!$jobs) return $out;

    if (count($jobs) === 1) {
        [$status, $body] = esp_http_exec($jobs[0]['req'], EMAIL_VERIFY_TIMEOUT);
        $out[$jobs[0]['key']] = [$status, $body];
        return $out;
    }

    $mh = curl_multi_init();
    $inFlight = [];
    $next = 0;
    $total = count($jobs);

    $launch = function () use (&$next, &$inFlight, $jobs, $mh, $total) {
        while ($next < $total && count($inFlight) < EMAIL_VERIFY_CONCURRENCY) {
            $job = $jobs[$next++];
            $ch = curl_init($job['req']['url']);
            curl_setopt_array($ch, esp_curl_options($job['req'], EMAIL_VERIFY_TIMEOUT));
            curl_multi_add_handle($mh, $ch);
            $inFlight[(int)$ch] = $job['key'];
        }
    };
    $launch();

    do {
        curl_multi_exec($mh, $running);
        if ($running > 0) curl_multi_select($mh, 1.0);
        while ($done = curl_multi_info_read($mh)) {
            $ch  = $done['handle'];
            $key = $inFlight[(int)$ch] ?? null;
            if ($key !== null) {
                $out[$key] = [(int)curl_getinfo($ch, CURLINFO_HTTP_CODE), curl_multi_getcontent($ch)];
                unset($inFlight[(int)$ch]);
            }
            curl_multi_remove_handle($mh, $ch);
            curl_close($ch);
            $launch();
        }
    } while ($running > 0 || $inFlight || $next < $total);

    curl_multi_close($mh);
    return $out;
}

/**
 * The single-address form, for the journey engine.
 *
 * A journey sends one message at a time, so there is nothing to parallelise — but the cache is
 * shared with the campaign path, so a student already verified by any campaign costs nothing here,
 * and a student verified here is free for every campaign afterwards.
 *
 * @return bool true when the address must NOT be sent to
 */
function email_verify_blocks_one(string $email, ?bool $enabled = null): bool {
    $blocked = email_verify_and_block([$email], null, $enabled);
    return isset($blocked[strtolower(trim($email))]);
}

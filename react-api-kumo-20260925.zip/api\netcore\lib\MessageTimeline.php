<?php
/*
 * lib/MessageTimeline.php — everything this panel has SENT to one person, as timeline events.
 *
 * The profile timeline already showed what the student did: signed in, sat an exam, paid. It showed
 * nothing about what we did to them. So the one question anybody actually opens this page to answer
 * — "we keep emailing this person, are they getting them, are they opening them?" — could not be
 * answered here at all, and the reader had to go and find the campaign, then find the person inside
 * it, once per campaign.
 *
 * This adds the other half: every send, delivery, open, read, click and bounce, from email campaigns,
 * WhatsApp campaigns and journeys alike, on the same clock as their own activity.
 *
 * ── WHY IT IS NOT PART OF THE BIG UNION ──────────────────────────────────────
 * The activity timeline is one UNION ALL over eighteen tables keyed on user_id, and every branch is
 * a cheap indexed lookup. These are not: they need a join to the campaign or journey to get a name,
 * they expand one row into up to five events, and two of them are keyed by email rather than user
 * id. Bolting them onto that union would turn one fast query into one slow one, and any single
 * missing table would take the whole timeline down rather than one section of it.
 *
 * So they are gathered separately, merged in PHP, and every query is wrapped — a server without the
 * WhatsApp tables shows the email half rather than an error.
 *
 * ── ONE ROW, SEVERAL EVENTS ──────────────────────────────────────────────────
 * A recipient row is not an event. It carries sent_at, delivered_at, opened_at and first_clicked_at
 * on the SAME row, and each of those is a separate thing that happened at a separate time. They are
 * expanded here rather than in SQL because the alternative is four UNION branches per source and
 * twenty over the whole file, all reading the same rows.
 */

/** Never let one person's timeline turn into an unbounded scan. Merged with the activity events,
 *  sorted, and cut to the caller's own limit afterwards. */
if (!defined('MSG_TIMELINE_ROW_CAP')) define('MSG_TIMELINE_ROW_CAP', 400);

/**
 * Messaging events for one person, newest first.
 *
 * @param int    $userId  the student, when known
 * @param string $email   their address; some sources are keyed on it rather than the id
 * @return array<int, array{event:string, timestamp:string, channel:string, source:string,
 *                          title:string, detail:string, ref_id:?int, ref_kind:?string}>
 */
function message_timeline_events(int $userId, string $email = ''): array {
    global $conn;
    $out = [];
    $email = strtolower(trim($email));
    $emailE = $conn->real_escape_string($email);
    $cap = (int)MSG_TIMELINE_ROW_CAP;

    /*
     * Matched on user_id OR email, not one or the other.
     *
     * A list-sourced campaign carries recipients with no user_id at all — they were uploaded as a
     * CSV and never matched to an account — and a student who registered later has rows of both
     * shapes. Keying on the id alone silently hides everything sent before they signed up, which is
     * exactly the period somebody is looking at when they ask why a contact never converted.
     */
    if ($userId <= 0 && $email === '') return [];

    /* ── email campaigns ──────────────────────────────────────────────────── */
    $q = message_timeline_rows($conn,
        "r.sent_at, r.delivered_at, r.opened_at, r.first_clicked_at, r.bounced_at,
         r.open_count, r.click_count, r.status, r.error_message, r.bounce_type,
         c.id AS cid, c.name AS cname, c.subject",
        "email_campaign_recipients r JOIN email_campaigns c ON c.id = r.campaign_id",
        'r.user_id', 'r.email', $userId, $emailE, 'AND r.is_test = 0', $cap);
    while ($q && $row = $q->fetch_assoc()) {
        $title = (string)($row['cname'] ?? '');
        $subj  = trim((string)($row['subject'] ?? ''));
        message_timeline_expand($out, 'email', 'campaign', $title, $subj, (int)$row['cid'], 'campaign', $row);
    }

    /* ── WhatsApp campaigns ───────────────────────────────────────────────── */
    $q = message_timeline_rows($conn,
        "r.sent_at, r.delivered_at, r.read_at AS opened_at, r.first_clicked_at,
         r.failed_at AS bounced_at, r.click_count, r.status, r.error_message,
         c.id AS cid, c.name AS cname, c.template_name AS subject",
        "wa_campaign_recipients r JOIN wa_campaigns c ON c.id = r.campaign_id",
        'r.user_id', 'r.email', $userId, $emailE, 'AND r.is_test = 0', $cap);
    while ($q && $row = $q->fetch_assoc()) {
        message_timeline_expand($out, 'whatsapp', 'campaign', (string)($row['cname'] ?? ''),
            trim((string)($row['subject'] ?? '')), (int)$row['cid'], 'campaign', $row);
    }

    /* ── journeys, both channels ──────────────────────────────────────────── */
    /* queued_at comes along because a message that was never sent has no other clock: a send the
       provider refused outright, or one the daily cap held back, still happened at a knowable
       moment and still belongs on this person's timeline. */
    $q = message_timeline_rows($conn,
        "m.channel, m.queued_at, m.sent_at, m.delivered_at, m.opened_at, m.first_clicked_at,
         m.status, m.suppress_reason, m.error_message, m.subject, m.node_id,
         m.open_count, m.click_count, j.id AS jid, j.name AS jname",
        "journey_messages m JOIN journeys j ON j.id = m.journey_id",
        'm.user_id', 'm.to_addr', $userId, $emailE, '', $cap);
    while ($q && $row = $q->fetch_assoc()) {
        $ch = (string)$row['channel'] === 'whatsapp' ? 'whatsapp' : 'email';
        // The step is what makes a journey row readable: a journey sends several messages and
        // "opened something from the nurture journey" is never the thing anyone wants to know.
        $detail = trim((string)($row['subject'] ?? ''));
        if ($detail === '') $detail = 'step ' . (string)$row['node_id'];
        message_timeline_expand($out, $ch, 'journey', (string)($row['jname'] ?? ''), $detail,
            (int)$row['jid'], 'journey', $row);
    }

    /* ── the opt-out, which is the end of the story and belongs on it ─────── */
    if ($email !== '') {
        $q = @$conn->query("SELECT created_at, reason_key, reason_text FROM email_unsubscribes
                             WHERE email = '$emailE' ORDER BY id DESC LIMIT 20");
        while ($q && $row = $q->fetch_assoc()) {
            $out[] = [
                'event' => 'email_unsubscribed', 'timestamp' => (string)$row['created_at'],
                'channel' => 'email', 'source' => 'unsubscribe',
                'title' => 'Unsubscribed',
                'detail' => trim((string)($row['reason_text'] ?? '')) !== ''
                    ? (string)$row['reason_text'] : str_replace('_', ' ', (string)$row['reason_key']),
                'ref_id' => null, 'ref_kind' => null,
            ];
        }
    }

    /*
     * Newest first, and a stable tie-break.
     *
     * A send and its delivery routinely share a second, and without the second comparison their
     * order flips between requests — which on screen looks like the message was delivered before it
     * was sent. Ordered by the stage each event belongs to when the clock cannot separate them.
     */
    $rank = ['sent' => 0, 'delivered' => 1, 'opened' => 2, 'read' => 2, 'clicked' => 3];
    usort($out, function ($a, $b) use ($rank) {
        $c = strcmp((string)$b['timestamp'], (string)$a['timestamp']);
        if ($c !== 0) return $c;
        $ra = $rank[substr((string)$a['event'], strrpos((string)$a['event'], '_') + 1)] ?? 9;
        $rb = $rank[substr((string)$b['event'], strrpos((string)$b['event'], '_') + 1)] ?? 9;
        return $rb <=> $ra;
    });
    return $out;
}

/**
 * One person's rows from a send table, matched on user_id OR email, newest first.
 *
 * Written as a UNION of two lookups, not `user_id = X OR LOWER(email) = 'e'`: LOWER() on the column
 * and the OR both stop MySQL using an index, which made every timeline scan the whole recipients
 * table. The columns are utf8mb4_unicode_ci, so a plain `=` is already case-insensitive. Needs the
 * user_id/email indexes from api/netcore/sql/timeline_indexes.sql.
 */
function message_timeline_rows(mysqli $conn, string $select, string $from, string $userCol,
                               string $emailCol, int $userId, string $emailE, string $extra, int $cap) {
    $alias = strtok($userCol, '.');
    $parts = [];
    if ($userId > 0) {
        $parts[] = "(SELECT $select, $alias.id AS _rid FROM $from WHERE $userCol = $userId $extra ORDER BY $alias.id DESC LIMIT $cap)";
    }
    if ($emailE !== '') {
        $parts[] = "(SELECT $select, $alias.id AS _rid FROM $from WHERE $emailCol = '$emailE' $extra ORDER BY $alias.id DESC LIMIT $cap)";
    }
    if (!$parts) return false;
    try {
        return $conn->query(implode(' UNION ', $parts) . " ORDER BY _rid DESC LIMIT $cap");
    } catch (Throwable $e) {
        // A stripped-down install without these tables loses this channel, not the timeline.
        return false;
    }
}

/**
 * Turns one recipient row into the separate things that happened to it.
 *
 * Only stages that actually have a timestamp become events. A message that was sent and never
 * opened contributes one event, not one plus three empty ones — the absence is the information, and
 * an "Opened: never" row would be noise on a timeline that may hold hundreds of real ones.
 */
function message_timeline_expand(array &$out, string $channel, string $source, string $title,
                                 string $detail, int $refId, string $refKind, array $row): void {
    /* MySQL hands back NULL, '' and the zero date for "never", and all three have to mean the
       same thing here — an event with an empty timestamp sorts to the bottom and renders blank. */
    $stamp = function ($ts): string {
        $ts = trim((string)$ts);
        return ($ts === '' || $ts === '0000-00-00 00:00:00') ? '' : $ts;
    };

    $add = function (string $stage, ?string $ts, string $extra = '') use (&$out, $stamp, $channel, $source, $title, $detail, $refId, $refKind) {
        $ts = $stamp($ts);
        if ($ts === '') return;
        $out[] = [
            'event'     => $channel . '_' . $stage,
            'timestamp' => $ts,
            'channel'   => $channel,
            'source'    => $source,
            'title'     => $title,
            'detail'    => $extra !== '' ? $extra : $detail,
            'ref_id'    => $refId ?: null,
            'ref_kind'  => $refKind,
        ];
    };

    $add('sent', $row['sent_at'] ?? null);
    $add('delivered', $row['delivered_at'] ?? null);

    // "Opened" on email, "Read" on WhatsApp — the same column, two different words, because a blue
    // tick is not an open and calling both "opened" makes the WhatsApp report read wrongly.
    $opens = (int)($row['open_count'] ?? 0);
    $add($channel === 'whatsapp' ? 'read' : 'opened', $row['opened_at'] ?? null,
        $opens > 1 ? $detail . ' · ' . $opens . ' times' : '');

    $clicks = (int)($row['click_count'] ?? 0);
    $add('clicked', $row['first_clicked_at'] ?? null,
        $clicks > 1 ? $detail . ' · ' . $clicks . ' taps' : '');

    // A bounce or a rejection carries its reason, which is the only part anybody reads.
    $err = trim((string)($row['error_message'] ?? ''));
    if (!empty($row['bounced_at'])) {
        $add('bounced', $row['bounced_at'], trim($detail . ($err !== '' ? ' · ' . $err : '')));
    } elseif (($row['status'] ?? '') === 'failed') {
        /*
         * A FAILURE THAT NEVER GOT AS FAR AS A SEND IS STILL THE THING THE READER NEEDS.
         *
         * This used to require sent_at, on the reasoning that the send is when the attempt was
         * made. But the failures that matter most never reach that point: a provider that refuses
         * the call outright — "You can not send above your plan limit" took 2,697 messages on one
         * journey — leaves a row with a status, a reason, and no send timestamp at all. Requiring
         * one meant those people had a completely empty timeline, and the single most useful fact
         * about them, that we tried to write and could not, was the one thing not shown.
         *
         * So it is filed at the send when there is one, and at the moment it was queued when there
         * is not. Only a row with neither is skipped, because there is nowhere to put it.
         */
        $when = $stamp($row['sent_at'] ?? null) ?: $stamp($row['queued_at'] ?? null);
        if ($when !== '') {
            $out[] = [
                'event' => $channel . '_failed', 'timestamp' => $when,
                'channel' => $channel, 'source' => $source, 'title' => $title,
                'detail' => trim($detail . ($err !== '' ? ' · ' . $err : '')),
                'ref_id' => $refId ?: null, 'ref_kind' => $refKind,
            ];
        }
    } elseif (($row['status'] ?? '') === 'suppressed') {
        $why  = trim((string)($row['suppress_reason'] ?? ''));
        // Held back before it was ever sent, so queued_at is normally the only clock it has.
        $when = $stamp($row['sent_at'] ?? null) ?: $stamp($row['queued_at'] ?? null);
        if ($when !== '') {
            $out[] = [
                'event' => $channel . '_held_back', 'timestamp' => $when,
                'channel' => $channel, 'source' => $source, 'title' => $title,
                'detail' => trim($detail . ($why !== '' ? ' · ' . str_replace('_', ' ', $why) : '')),
                'ref_id' => $refId ?: null, 'ref_kind' => $refKind,
            ];
        }
    }
}

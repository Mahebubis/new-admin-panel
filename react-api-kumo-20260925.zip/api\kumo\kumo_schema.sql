-- ============================================================================
-- KumoMTA module — schema mirror (documentation only).
--
-- The runtime truth is kumo_ensure_schema() in lib/schema.php, which runs these
-- same statements with CREATE TABLE IF NOT EXISTS on every request. This file
-- exists so the schema can be reviewed without reading PHP, and is kept in sync
-- by hand (same convention as campaigns_schema.sql).
--
-- SAFETY: every table here is NEW and prefixed `kumo_`. This module never
-- alters, drops or writes to any pre-existing table of istudio_cit.
-- ============================================================================

CREATE TABLE IF NOT EXISTS kumo_ips (
  id INT AUTO_INCREMENT PRIMARY KEY,
  ip VARCHAR(45) NOT NULL,
  hostname VARCHAR(190) NOT NULL DEFAULT '',
  tenant VARCHAR(64) NOT NULL,                       -- must match the KumoMTA pool (ip1…ip5)
  label VARCHAR(120) NOT NULL DEFAULT '',
  status ENUM('active','paused','retired') NOT NULL DEFAULT 'active',
  health ENUM('green','yellow','red','unknown') NOT NULL DEFAULT 'unknown',
  health_reason TEXT NULL,
  warmup_enabled TINYINT(1) NOT NULL DEFAULT 1,
  warmup_day INT NOT NULL DEFAULT 1,
  warmup_started_at DATE NULL,
  manual_cap INT NULL,                               -- overrides the warmup ladder
  good_hours INT NOT NULL DEFAULT 0,                 -- hysteresis counter
  ptr_ok TINYINT(1) NOT NULL DEFAULT 0,
  ptr_value VARCHAR(190) NULL,
  blocklisted TINYINT(1) NOT NULL DEFAULT 0,
  blocklist_note VARCHAR(255) NULL,
  paused_reason VARCHAR(255) NULL,
  paused_by VARCHAR(120) NULL,
  paused_at DATETIME NULL,
  last_health_at DATETIME NULL,
  last_send_at DATETIME NULL,
  sort_order INT NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_ip (ip), UNIQUE KEY uq_tenant (tenant), KEY idx_status (status, health)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS kumo_ip_daily (
  id INT AUTO_INCREMENT PRIMARY KEY,
  ip_id INT NOT NULL, day DATE NOT NULL,
  cap INT NOT NULL DEFAULT 0, sent INT NOT NULL DEFAULT 0, warmup_day INT NOT NULL DEFAULT 0,
  UNIQUE KEY uq_ip_day (ip_id, day), KEY idx_day (day)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS kumo_ip_stats (            -- hourly rollup, per provider
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  ip_id INT NOT NULL, bucket DATETIME NOT NULL, provider VARCHAR(32) NOT NULL DEFAULT 'other',
  sent INT NOT NULL DEFAULT 0, delivered INT NOT NULL DEFAULT 0, deferred INT NOT NULL DEFAULT 0,
  bounced INT NOT NULL DEFAULT 0, complaints INT NOT NULL DEFAULT 0, opens INT NOT NULL DEFAULT 0,
  clicks INT NOT NULL DEFAULT 0, unsubs INT NOT NULL DEFAULT 0,
  UNIQUE KEY uq_bucket (ip_id, bucket, provider), KEY idx_bucket (bucket)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS kumo_ip_health (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  ip_id INT NOT NULL, checked_at DATETIME NOT NULL,
  color ENUM('green','yellow','red','unknown') NOT NULL,
  sent_24h INT NOT NULL DEFAULT 0,
  bounce_rate DECIMAL(6,3) NOT NULL DEFAULT 0, complaint_rate DECIMAL(6,3) NOT NULL DEFAULT 0,
  deferral_rate DECIMAL(6,3) NOT NULL DEFAULT 0, delivery_rate DECIMAL(6,3) NOT NULL DEFAULT 0,
  reasons TEXT NULL, KEY idx_ip_time (ip_id, checked_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS kumo_warmup_plan (
  id INT AUTO_INCREMENT PRIMARY KEY,
  day_from INT NOT NULL, day_to INT NOT NULL, daily_cap INT NOT NULL,
  UNIQUE KEY uq_from (day_from)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS kumo_blocklist_checks (
  id INT AUTO_INCREMENT PRIMARY KEY,
  target VARCHAR(190) NOT NULL, kind ENUM('ip','domain') NOT NULL DEFAULT 'ip',
  zone VARCHAR(64) NOT NULL, listed TINYINT(1) NOT NULL DEFAULT 0,
  response VARCHAR(64) NULL, checked_at DATETIME NOT NULL,
  UNIQUE KEY uq_target_zone (target, zone)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS kumo_contacts (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  email VARCHAR(255) NOT NULL, first_name VARCHAR(120) NULL, last_name VARCHAR(120) NULL,
  phone VARCHAR(32) NULL, attrs JSON NULL, source VARCHAR(64) NOT NULL DEFAULT 'manual',
  consent_at DATETIME NULL,
  status ENUM('active','unsubscribed','bounced','complained') NOT NULL DEFAULT 'active',
  engagement ENUM('new','hot','warm','cold','dormant') NOT NULL DEFAULT 'new',
  last_open_at DATETIME NULL, last_click_at DATETIME NULL, last_send_at DATETIME NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_email (email), KEY idx_status (status), KEY idx_engagement (engagement)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS kumo_lists (
  id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(190) NOT NULL, description VARCHAR(500) NULL,
  kind ENUM('list','import') NOT NULL DEFAULT 'list', contact_count INT NOT NULL DEFAULT 0,
  created_by VARCHAR(120) NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS kumo_list_members (
  id BIGINT AUTO_INCREMENT PRIMARY KEY, list_id INT NOT NULL, contact_id BIGINT NOT NULL,
  added_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_member (list_id, contact_id), KEY idx_contact (contact_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS kumo_segments (
  id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(190) NOT NULL, description VARCHAR(500) NULL,
  source ENUM('kumo_list','engagement','netcore') NOT NULL DEFAULT 'engagement',
  config JSON NULL, cached_count INT NOT NULL DEFAULT 0, counted_at DATETIME NULL,
  created_by VARCHAR(120) NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS kumo_blocklist (           -- this module's own suppression list
  id BIGINT AUTO_INCREMENT PRIMARY KEY, email VARCHAR(255) NOT NULL,
  reason ENUM('hard_bounce','complaint','unsubscribe','manual','imported','invalid') NOT NULL DEFAULT 'manual',
  detail VARCHAR(500) NULL, campaign_id INT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_email (email), KEY idx_reason (reason), KEY idx_created (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS kumo_templates (
  id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(190) NOT NULL, category VARCHAR(64) NULL,
  subject VARCHAR(500) NULL, preheader VARCHAR(500) NULL, body_html LONGTEXT, body_text LONGTEXT,
  status ENUM('active','archived') NOT NULL DEFAULT 'active', created_by VARCHAR(120) NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  KEY idx_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS kumo_campaigns (
  id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(190) NOT NULL,
  status ENUM('draft','scheduled','running','paused','sent','failed') NOT NULL DEFAULT 'draft',
  template_id INT NULL, subject VARCHAR(500) NULL, preheader VARCHAR(500) NULL,
  from_name VARCHAR(190) NULL, from_email VARCHAR(190) NULL, reply_to VARCHAR(190) NULL,
  body_html LONGTEXT, body_text LONGTEXT,
  audience_type ENUM('list','segment','all_contacts') NOT NULL DEFAULT 'list',
  list_ids JSON NULL, segment_ids JSON NULL, exclude_list_ids JSON NULL,
  ip_mode ENUM('auto','fixed') NOT NULL DEFAULT 'auto', ip_ids JSON NULL,
  schedule_type ENUM('now','later') NOT NULL DEFAULT 'now', scheduled_at DATETIME NULL,
  throttle_per_hour INT NULL, track_opens TINYINT(1) NOT NULL DEFAULT 1, track_clicks TINYINT(1) NOT NULL DEFAULT 1,
  total_recipients INT NOT NULL DEFAULT 0, queued_count INT NOT NULL DEFAULT 0,
  sent_count INT NOT NULL DEFAULT 0, delivered_count INT NOT NULL DEFAULT 0,
  deferred_count INT NOT NULL DEFAULT 0, bounced_count INT NOT NULL DEFAULT 0,
  complaint_count INT NOT NULL DEFAULT 0, open_count INT NOT NULL DEFAULT 0,
  unique_open_count INT NOT NULL DEFAULT 0, click_count INT NOT NULL DEFAULT 0,
  unique_click_count INT NOT NULL DEFAULT 0, unsub_count INT NOT NULL DEFAULT 0,
  skipped_count INT NOT NULL DEFAULT 0, error_message VARCHAR(500) NULL,
  materialized_at DATETIME NULL, started_at DATETIME NULL, completed_at DATETIME NULL,
  created_by VARCHAR(120) NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  KEY idx_status (status, scheduled_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS kumo_campaign_recipients (
  id BIGINT AUTO_INCREMENT PRIMARY KEY, campaign_id INT NOT NULL, contact_id BIGINT NULL,
  email VARCHAR(255) NOT NULL, first_name VARCHAR(120) NULL, last_name VARCHAR(120) NULL,
  rid CHAR(32) NOT NULL,                              -- end-to-end correlation id
  status ENUM('pending','processing','sent','delivered','bounced','failed','skipped') NOT NULL DEFAULT 'pending',
  ip_id INT NULL, provider VARCHAR(32) NULL, attempts TINYINT NOT NULL DEFAULT 0,
  error VARCHAR(500) NULL, smtp_code VARCHAR(16) NULL, bounce_type ENUM('hard','soft') NULL,
  is_test TINYINT(1) NOT NULL DEFAULT 0,
  open_count INT NOT NULL DEFAULT 0, click_count INT NOT NULL DEFAULT 0,
  claim_token CHAR(32) NULL, claimed_at DATETIME NULL,
  queued_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, sent_at DATETIME NULL,
  delivered_at DATETIME NULL, bounced_at DATETIME NULL, opened_at DATETIME NULL, clicked_at DATETIME NULL,
  UNIQUE KEY uq_rid (rid), KEY idx_campaign_status (campaign_id, status),
  KEY idx_claim (status, claim_token), KEY idx_email (email), KEY idx_ip (ip_id, sent_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS kumo_campaign_events (
  id BIGINT AUTO_INCREMENT PRIMARY KEY, campaign_id INT NULL, recipient_id BIGINT NULL,
  rid CHAR(32) NULL, ip_id INT NULL,
  type ENUM('reception','delivery','deferred','bounce','complaint','open','click','unsub','admin_bounce') NOT NULL,
  provider VARCHAR(32) NULL, code VARCHAR(16) NULL, response TEXT NULL, url VARCHAR(1000) NULL,
  ip_address VARCHAR(45) NULL, user_agent VARCHAR(500) NULL, meta JSON NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY idx_campaign_type (campaign_id, type), KEY idx_rid (rid), KEY idx_created (created_at),
  KEY idx_ip_type (ip_id, type, created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS kumo_settings (
  k VARCHAR(64) NOT NULL PRIMARY KEY, v TEXT,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS kumo_alerts (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  level ENUM('info','warn','critical') NOT NULL DEFAULT 'info',
  ip_id INT NULL, campaign_id INT NULL, title VARCHAR(255) NOT NULL, body TEXT NULL,
  acknowledged_by VARCHAR(120) NULL, acknowledged_at DATETIME NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY idx_open (acknowledged_at, created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS kumo_api_health (
  id BIGINT AUTO_INCREMENT PRIMARY KEY, checked_at DATETIME NOT NULL,
  ok TINYINT(1) NOT NULL DEFAULT 0, latency_ms INT NOT NULL DEFAULT 0,
  queue_size INT NOT NULL DEFAULT 0, scheduled INT NOT NULL DEFAULT 0,
  error VARCHAR(255) NULL, KEY idx_time (checked_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

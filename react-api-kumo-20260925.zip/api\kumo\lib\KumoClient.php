<?php
/*
 * KumoClient — the only place that talks to the KumoMTA box.
 *
 * KumoMTA's HTTP API listens on 127.0.0.1:8000 on the mail server and is never
 * exposed publicly. The mail server runs a tiny nginx vhost (SETUP.md) that
 * terminates TLS, checks a bearer token, allow-lists this panel's IP and
 * proxies to that local port:
 *
 *     POST  {bridge}/kumo/inject   →  127.0.0.1:8000/api/inject/v1
 *     GET   {bridge}/kumo/metrics  →  127.0.0.1:8000/metrics.json
 *     POST  {bridge}/kumo/bounce   →  127.0.0.1:8000/api/admin/bounce/v1
 *     GET   {bridge}/kumo/ping     →  nginx-local 200 (cheap liveness)
 *
 * Every method returns a plain array and never throws: a mail server being
 * unreachable must degrade the dashboard, not 500 the panel.
 */

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/schema.php';

class KumoClient
{
    private string $base;
    private string $token;
    private int $timeout;

    public function __construct(?string $base = null, ?string $token = null) {
        $this->base    = rtrim((string)($base  ?? kumo_setting('bridge_url',   KUMO_BRIDGE_URL)),   '/');
        $this->token   = (string)($token ?? kumo_setting('bridge_token', KUMO_BRIDGE_TOKEN));
        $this->timeout = KUMO_BRIDGE_TIMEOUT;
    }

    public function isConfigured(): bool {
        return $this->base !== '' && $this->token !== '';
    }

    /* ── Low-level ─────────────────────────────────────────────────────────── */

    private function request(string $method, string $path, ?array $json = null, int $timeout = 0): array {
        $t0  = microtime(true);
        $url = $this->base . $path;

        if (!$this->isConfigured()) {
            return ['ok' => false, 'status' => 0, 'error' => 'KumoMTA bridge is not configured (Settings → Connection)', 'ms' => 0, 'body' => null];
        }

        $ch = curl_init($url);
        $headers = [
            'Authorization: Bearer ' . $this->token,
            'Accept: application/json',
        ];
        if ($json !== null) $headers[] = 'Content-Type: application/json';

        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_CUSTOMREQUEST  => $method,
            CURLOPT_HTTPHEADER     => $headers,
            CURLOPT_TIMEOUT        => $timeout > 0 ? $timeout : $this->timeout,
            CURLOPT_CONNECTTIMEOUT => 8,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_SSL_VERIFYHOST => 2,
        ]);
        if ($json !== null) {
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($json, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE));
        }

        $body   = curl_exec($ch);
        $status = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $cerr   = curl_error($ch);
        curl_close($ch);

        $ms      = (int)round((microtime(true) - $t0) * 1000);
        $decoded = is_string($body) ? json_decode($body, true) : null;

        return [
            'ok'     => $cerr === '' && $status >= 200 && $status < 300,
            'status' => $status,
            'error'  => $cerr !== '' ? $cerr : ($status >= 300 ? ('HTTP ' . $status . ' ' . substr((string)$body, 0, 200)) : null),
            'ms'     => $ms,
            'body'   => $decoded !== null ? $decoded : $body,
        ];
    }

    /* ── Injection ─────────────────────────────────────────────────────────── */

    /**
     * Hand one batch of ready-to-send messages to KumoMTA.
     *
     * KumoMTA's inject API takes ONE envelope sender + content + a recipients
     * array, so a batch here means "same body, many recipients". Personalised
     * bodies are injected one call per recipient by the worker (it groups by
     * identical content hash first, which for a campaign is almost always one
     * group after merge-tag substitution is done per recipient — see the
     * worker's comment on why we still batch by IP).
     *
     * @param string $envelopeSender  bounce address (Return-Path)
     * @param string $content         full RFC822 message (headers + body)
     * @param array  $recipients      [['email'=>..], ..]
     */
    public function inject(string $envelopeSender, string $content, array $recipients): array {
        $res = $this->request('POST', '/kumo/inject', [
            'envelope_sender' => $envelopeSender,
            'content'         => $content,
            'recipients'      => array_values($recipients),
        ]);

        // KumoMTA answers {"success_count":N,"fail_count":M,"failed_recipients":[],"errors":[]}
        $b = is_array($res['body']) ? $res['body'] : [];
        $res['success_count']     = (int)($b['success_count'] ?? ($res['ok'] ? count($recipients) : 0));
        $res['fail_count']        = (int)($b['fail_count'] ?? ($res['ok'] ? 0 : count($recipients)));
        $res['failed_recipients'] = $b['failed_recipients'] ?? [];
        $res['errors']            = $b['errors'] ?? ($res['error'] ? [$res['error']] : []);

        /* A rejection by KumoMTA comes back as HTTP 200 with fail_count and an
           errors[] — the transport-level 'error' stays empty, so callers that
           report $inj['error'] showed a blank reason. Carry the first real
           error into it so the failure always says what happened. */
        if (($res['error'] ?? '') === '' && !empty($res['errors'][0])) {
            $res['error'] = (string)$res['errors'][0];
        }
        return $res;
    }

    /* ── Health / metrics ──────────────────────────────────────────────────── */

    /**
     * Liveness + queue depth. Used by the dashboard's "API health" tile and
     * logged to kumo_api_health by the health worker.
     */
    public function health(): array {
        $res = $this->request('GET', '/kumo/metrics', null, 10);
        $out = [
            'ok'         => (bool)$res['ok'],
            'latency_ms' => (int)$res['ms'],
            'error'      => $res['error'],
            'queue_size' => 0,
            'scheduled'  => 0,
            'ready'      => 0,
            'raw'        => null,
        ];
        if (!$res['ok']) return $out;

        $b = $res['body'];
        if (is_array($b)) {
            $out['raw'] = $b;
            // KumoMTA's metrics.json shape varies by version; sum whatever queue
            // gauges are present rather than assuming one key.
            $scheduled = self::pluckNumber($b, ['scheduled_count', 'scheduled', 'queued_count']);
            $ready     = self::pluckNumber($b, ['ready_count', 'ready']);
            $out['scheduled']  = $scheduled;
            $out['ready']      = $ready;
            $out['queue_size'] = $scheduled + $ready;
        } elseif (is_string($b)) {
            // Prometheus text fallback
            if (preg_match('/^scheduled_count\S*\s+(\d+)/m', $b, $m)) $out['scheduled'] = (int)$m[1];
            if (preg_match('/^ready_count\S*\s+(\d+)/m', $b, $m))     $out['ready']     = (int)$m[1];
            $out['queue_size'] = $out['scheduled'] + $out['ready'];
        }
        return $out;
    }

    /** Recursively sums every numeric leaf whose key matches one of $keys. */
    private static function pluckNumber($node, array $keys): int {
        $sum = 0;
        if (!is_array($node)) return 0;
        foreach ($node as $k => $v) {
            if (in_array((string)$k, $keys, true)) {
                if (is_numeric($v)) $sum += (int)$v;
                elseif (is_array($v)) foreach ($v as $vv) if (is_numeric($vv)) $sum += (int)$vv;
            } elseif (is_array($v)) {
                $sum += self::pluckNumber($v, $keys);
            }
        }
        return $sum;
    }

    /**
     * Cancel everything still queued for one campaign (used by "Pause" /
     * "Cancel"): KumoMTA admin-bounce by campaign header.
     */
    public function adminBounce(string $reason, array $filter = []): array {
        return $this->request('POST', '/kumo/bounce', array_merge(['reason' => $reason], $filter));
    }

    /* ── DNS helpers (run on the panel host, no bridge needed) ─────────────── */

    /** Forward + reverse DNS agreement for one sending IP. */
    public static function ptrCheck(string $ip, string $expectedHost = ''): array {
        $ptr = @gethostbyaddr($ip);
        $ok  = false;
        if ($ptr && $ptr !== $ip) {
            $fwd = @gethostbynamel($ptr) ?: [];
            $ok  = in_array($ip, $fwd, true);
            if ($expectedHost !== '') $ok = $ok && (strcasecmp(rtrim($ptr, '.'), rtrim($expectedHost, '.')) === 0);
        }
        return ['ptr' => $ptr ?: null, 'ok' => $ok];
    }

    /**
     * DNSBL lookup. Returns ['listed'=>bool,'response'=>?string] per zone.
     * Spamhaus is only queried when a DQS key is configured, because queries
     * from public resolvers are refused and would produce false "clean".
     */
    public static function dnsblCheck(string $ip, string $zone): array {
        $parts = explode('.', $ip);
        if (count($parts) !== 4) return ['listed' => false, 'response' => null];
        $q = implode('.', array_reverse($parts)) . '.' . $zone;

        $rec = @dns_get_record($q, DNS_A);
        if (!is_array($rec) || !count($rec)) return ['listed' => false, 'response' => null];
        $ips = array_values(array_filter(array_map(fn($r) => $r['ip'] ?? null, $rec)));
        return ['listed' => count($ips) > 0, 'response' => $ips ? implode(',', $ips) : null];
    }
}

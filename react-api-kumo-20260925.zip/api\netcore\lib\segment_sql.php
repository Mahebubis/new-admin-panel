<?php
/*
 * /api/netcore/lib/segment_sql.php
 *
 * Shared segment-resolution SQL builder. Originally lived inline in
 * segments.php; extracted so the new campaigns feature (AudienceResolver.php)
 * can resolve "which users belong to segment X" without duplicating this
 * logic. Both segments.php and campaigns/lib/AudienceResolver.php require
 * this file.
 *
 * Exposes: esc(), $EVENT_SOURCE, $PAYLOAD_COLUMNS, resolveDay(),
 *          buildConditionSql(), combineByConnector(), combineConditions(),
 *          combineBlocks(), buildSegmentSql(), countSegment(), channelCounts()
 */

if (!function_exists('esc')) {
    function esc($s) { global $conn; return mysqli_real_escape_string($conn, $s); }
}

/* Engagement (email / WhatsApp / list activity) and Contacts (list / segment membership)
   conditions — buildConditionSql() below dispatches to it on cond.kind. */
require_once __DIR__ . '/segment_engagement.php';

/* ════════════════════════════════════════
   Event-table mapping (mirrors behaviour.php)
   Each entry is an assoc array:
     - table     : source table
     - user_col  : column yielding user_id (qualified if it lives in a joined table, e.g. u_link.user_id)
     - date_col  : column used for the day-window filter (qualify if ambiguous, e.g. instant_exam_reminder_logs.created_at)
     - where     : optional extra SQL constraint
     - join      : optional JOIN clause(s) baked into the source — used when the
                   source table doesn't have user_id directly (email-keyed reminder logs,
                   employer-keyed company tables) and we need to resolve to users.user_id
═══════════════════════════════════════ */
$EVENT_SOURCE = [
    'register'                 => ['table' => 'users',                   'user_col' => 'user_id', 'date_col' => 'registered_at',  'where' => ''],
    'signin'                   => ['table' => 'signin_log',              'user_col' => 'user_id', 'date_col' => 'created_at',     'where' => ''],
    'exam_success'             => ['table' => 'cit_results',             'user_col' => 'user_id', 'date_col' => '`timestamp`',    'where' => ''],
    /* course_purchase / payment_success are a UNION of two order sources —
       the main payment_status table AND the ₹99 store's ninety_nine_store_orders
       (which has no user_id, only email, hence the join-through-email inside
       the second branch). Folding both into one derived table means every other
       mechanism that reads $EVENT_SOURCE (segment builder, ConversionTracker's
       click-window recompute) just sees one "table" and needs no changes.

       The `COLLATE utf8mb4_general_ci` on nno.email is required, not cosmetic:
       `users` is an older table (utf8mb4_general_ci) while ninety_nine_store_orders
       was created under MySQL 8's default (utf8mb4_0900_ai_ci), and comparing two
       IMPLICIT-collation columns across that boundary raises error #1267. An
       EXPLICIT collation on either side settles it. It goes on the ₹99 side on
       purpose — that table is tiny, so losing its index there costs nothing,
       while users.email keeps its index for the lookup. */
    /* "Reached checkout" — deliberately includes 'success', not just
       'initiated'. Paying does not add a row, it UPDATEs the existing one
       (payment_api's UpdatePaymentStatusSuccess), so filtering on 'initiated'
       alone would silently drop every customer who actually completed payment
       — i.e. a course purchase would vanish from the course-purchase figure at
       the moment it became real. */
    'course_purchase' => [
        'table' => "(SELECT user_id, amount, internship_name, batch_date, coupon_code, `timestamp` AS event_at
                       FROM payment_status WHERE status IN ('initiated','success')
                     UNION ALL
                     SELECT u_link.user_id, nno.amount, nno.course_name AS internship_name, NULL AS batch_date, NULL AS coupon_code, nno.created_at AS event_at
                       FROM ninety_nine_store_orders nno
                       INNER JOIN users u_link ON u_link.email = nno.email COLLATE utf8mb4_general_ci
                      WHERE nno.status IN ('initiated','success')
                    ) AS course_purchase_src",
        'user_col' => 'course_purchase_src.user_id',
        'date_col' => 'course_purchase_src.event_at',
        'where' => '',
    ],
    'payment_success' => [
        'table' => "(SELECT user_id, amount, internship_name, batch_date, coupon_code, order_id, `timestamp` AS event_at
                       FROM payment_status WHERE status='success'
                     UNION ALL
                     SELECT u_link.user_id, nno.amount, nno.course_name AS internship_name, NULL AS batch_date, NULL AS coupon_code, nno.order_id, nno.created_at AS event_at
                       FROM ninety_nine_store_orders nno
                       INNER JOIN users u_link ON u_link.email = nno.email COLLATE utf8mb4_general_ci
                      WHERE nno.status='success'
                    ) AS payment_success_src",
        'user_col' => 'payment_success_src.user_id',
        'date_col' => 'payment_success_src.event_at',
        'where' => '',
    ],
    'preferred_domain'         => ['table' => 'user_slected_domain_new', 'user_col' => 'user_id', 'date_col' => 'created_at',     'where' => ''],
    'visited_iap'              => ['table' => 'user_iap_visits',         'user_col' => 'user_id', 'date_col' => 'visited_at',     'where' => ''],
    'result_view'              => ['table' => 'cit_results',             'user_col' => 'user_id', 'date_col' => '`timestamp`',    'where' => 'user_id IN (SELECT user_id FROM users WHERE score_viewed=1)'],
    'placement_community_link' => ['table' => 'assigned_links',          'user_col' => 'user_id', 'date_col' => 'assigned_at',    'where' => ''],
    'instantexam_reminder'     => ['table' => 'set_reminder',            'user_col' => 'user_id', 'date_col' => 'created_at',     'where' => ''],
    'course_edit'              => ['table' => 'internship_edit_logs',    'user_col' => 'user_id', 'date_col' => 'created_at',     'where' => ''],

    /* user_id present directly in the source — fits the simple pattern */
    'mark_attendance'   => ['table' => 'attendance_log',      'user_col' => 'user_id', 'date_col' => 'marked_at',  'where' => ''],
    'came_on_dashboard' => ['table' => 'user_login_activity', 'user_col' => 'user_id', 'date_col' => 'login_date', 'where' => ''],
    'link_assigned'     => ['table' => 'assigned_links',      'user_col' => 'user_id', 'date_col' => 'assigned_at','where' => ''],

    /* reminder log tables — user_id column is present, use it directly.
       Rows with NULL user_id (e.g. reminders fired before user resolution) won't be segmentable. */
    'exam_reminder'               => ['table' => 'instant_exam_reminder_logs',     'user_col' => 'user_id', 'date_col' => 'created_at', 'where' => 'user_id IS NOT NULL'],
    'project_submission_reminder' => ['table' => 'project_submission_reminder_logs','user_col' => 'user_id', 'date_col' => 'created_at', 'where' => 'user_id IS NOT NULL'],
    'one_day_before_batch_start'  => ['table' => 'one_day_before_batch_start_logs', 'user_col' => 'user_id', 'date_col' => 'created_at', 'where' => 'user_id IS NOT NULL'],
    'batch_end_reminder'          => ['table' => 'same_day_batch_end_logs',        'user_col' => 'user_id', 'date_col' => 'created_at', 'where' => 'user_id IS NOT NULL'],

    /* company/employer events → employer_email → users.email join.
       Employers without a matching user account won't show up. */
    'register_company' => [
        'table' => 'hiring_employer', 'user_col' => 'u_link.user_id',
        'date_col' => 'hiring_employer.registered_at', 'where' => '',
        'join' => 'INNER JOIN users u_link ON u_link.email = hiring_employer.employer_email',
    ],
    'company_signin' => [
        'table' => 'employer_login_logs', 'user_col' => 'u_link.user_id',
        'date_col' => 'employer_login_logs.login_time', 'where' => '',
        'join' => 'INNER JOIN hiring_employer he ON he.employer_id = employer_login_logs.employer_id '
                . 'INNER JOIN users u_link ON u_link.email = he.employer_email',
    ],
    'company_vacancy_post' => [
        'table' => 'job_list', 'user_col' => 'u_link.user_id',
        'date_col' => 'job_list.created_at', 'where' => '',
        'join' => 'INNER JOIN hiring_employer he ON he.employer_id = job_list.employer_id '
                . 'INNER JOIN users u_link ON u_link.email = he.employer_email',
    ],
];

/* (event, payloadKey) → fully-qualified column to filter on.
   • Columns starting with `users.` trigger an automatic LEFT JOIN to users when
     the source table doesn't already bring users in via its `join` field.
   • For events whose `join` already aliases helper tables (e.g. `he` for hiring_employer
     in company_signin / company_vacancy_post), payload columns can reference those aliases. */
$PAYLOAD_COLUMNS = [
    'register' => [
        'country'        => 'users.country',
        'mobile'         => 'users.phone',
        'last_name'      => 'users.lname',
        'state'          => 'users.state',
        'first_name'     => 'users.fname',
        'email'          => 'users.email',
        'instantexam'    => 'users.instant_exam',
        'instantresult'  => 'users.instant_result',
        'is_from_refund' => 'users.is_from_refund',
        'method'         => "(CASE WHEN users.is_signup_by_google='yes' THEN 'Google' ELSE 'Manual' END)",
        'referral'       => "(CASE WHEN users.is_from_referral=1 THEN 'yes' ELSE 'no' END)",
        'express'        => "(CASE WHEN users.organic_user=1 THEN 'yes' ELSE 'no' END)",
        'setreminder'    => "(CASE WHEN EXISTS(SELECT 1 FROM set_reminder sr WHERE sr.user_id = users.user_id) THEN 'yes' ELSE 'no' END)",
        'source'         => "(SELECT uc.source   FROM user_campaign uc WHERE uc.user_id = users.user_id LIMIT 1)",
        'campaign'       => "(SELECT uc.campaign FROM user_campaign uc WHERE uc.user_id = users.user_id LIMIT 1)",
        'adset'          => "(SELECT uc.adset    FROM user_campaign uc WHERE uc.user_id = users.user_id LIMIT 1)",
        'ad'             => "(SELECT uc.ad       FROM user_campaign uc WHERE uc.user_id = users.user_id LIMIT 1)",
        'medium'         => "(SELECT uc.medium   FROM user_campaign uc WHERE uc.user_id = users.user_id LIMIT 1)",
        'full_url'       => "(SELECT sfu.full_url      FROM store_full_url sfu WHERE sfu.user_id = users.user_id LIMIT 1)",
        'register_type'  => "(SELECT sfu.register_type FROM store_full_url sfu WHERE sfu.user_id = users.user_id LIMIT 1)",
        'device'         => "(SELECT sfu.device        FROM store_full_url sfu WHERE sfu.user_id = users.user_id LIMIT 1)",
    ],
    'signin'           => [ 'email' => 'users.email' ],
    'exam_success'     => [ 'result_score' => 'cit_results.score', 'status' => "'Completed'" ],
    'course_purchase'  => [
        'amount'          => 'course_purchase_src.amount',
        'internship_name' => 'course_purchase_src.internship_name',
        'batch_date'      => 'course_purchase_src.batch_date',
        'coupon_applied'  => "(CASE WHEN course_purchase_src.coupon_code IS NOT NULL AND course_purchase_src.coupon_code <> '' THEN 'yes' ELSE 'no' END)",
        'initiated_at'    => 'course_purchase_src.event_at',
    ],
    'payment_success'  => [
        'paid_amount'            => 'payment_success_src.amount',
        'paid_internship_name'   => 'payment_success_src.internship_name',
        'paid_batch_date'        => 'payment_success_src.batch_date',
        'coupon_applied_success' => "(CASE WHEN payment_success_src.coupon_code IS NOT NULL AND payment_success_src.coupon_code <> '' THEN 'yes' ELSE 'no' END)",
        'order_id'               => 'payment_success_src.order_id',
        'paid_at'                => 'payment_success_src.event_at',
    ],
    'preferred_domain' => [ 'preferred_domain' => 'user_slected_domain_new.domain_name' ],
    'visited_iap'      => [ 'visited' => "'yes'", 'visited_time' => 'user_iap_visits.visited_at' ],
    'result_view'      => [ 'score' => 'cit_results.score' ],
    'placement_community_link' => [
        'refund_non_refund' => "'Non Refund'",
        'assigned_links'    => 'assigned_links.assigned_id',
    ],
    'instantexam_reminder' => [
        'time_slot' => 'set_reminder.time_slot',
        'date_time' => 'set_reminder.created_at',
    ],
    'course_edit' => [
        'edit_internship_name' => 'internship_edit_logs.new_internship_name',
        'edit_page_url'        => 'internship_edit_logs.page_url',
        'edit_batch_date'      => 'internship_edit_logs.new_batch',
        'edit_type'            => 'internship_edit_logs.action_type',
    ],

    'register_company' => [
        'company_logo'   => "(CASE WHEN hiring_employer.employer_logo IS NOT NULL AND hiring_employer.employer_logo <> '' THEN 'Has Logo' ELSE 'No Logo' END)",
        'company_mobile' => 'hiring_employer.employer_phone',
        'company_name'   => 'hiring_employer.employer_name',
        'company_email'  => 'hiring_employer.employer_email',
    ],
    'company_signin' => [
        'company_signin_email'      => 'he.employer_email',
        'company_signin_status'     => 'employer_login_logs.status',
        'company_signin_ip'         => 'employer_login_logs.ip_address',
        'company_signin_user_agent' => 'employer_login_logs.user_agent',
    ],
    'company_vacancy_post' => [
        'vp_email'       => 'he.employer_email',
        'vp_job_type'    => 'job_list.job_type',
        'vp_job_title'   => 'job_list.job_title',
        'vp_mode'        => 'job_list.job_mode',
        'vp_openings'    => 'job_list.openings',
        'vp_start_date'  => 'job_list.start_date',
        'vp_duration'    => 'job_list.job_duration',
        'vp_salary'      => 'job_list.compensation_amount',
        'vp_comp_amount' => 'job_list.compensation_amount',
        'vp_comp_min'    => 'job_list.compensation_min_amount',
        'vp_comp_max'    => 'job_list.compensation_max_amount',
        'vp_comp_type'   => 'job_list.compensation_type',
        'vp_comp_period' => 'job_list.compensation_period',
        'vp_experience'  => 'job_list.min_experience',
        'vp_method'      => 'job_list.job_nature',
        'vp_source'      => 'job_list.source',
    ],

    'mark_attendance' => [
        'internship_id'   => 'attendance_log.internship_id',
        'attendance_date' => 'attendance_log.attendance_date',
        'note'            => 'attendance_log.note',
        'character_count' => 'attendance_log.character_count',
        'marked_at'       => 'attendance_log.marked_at',
        'ip_address'      => 'attendance_log.ip_address',
        'user_agent'      => 'attendance_log.user_agent',
    ],
    'came_on_dashboard' => [
        'login_date'     => 'user_login_activity.login_date',
        'activity_level' => 'user_login_activity.activity_level',
    ],
    'link_assigned' => [
        'la_assigned_at' => 'assigned_links.assigned_at',
    ],

    'exam_reminder' => [
        'er_exam_date'   => 'instant_exam_reminder_logs.exam_date',
        'er_time_slot'   => 'instant_exam_reminder_logs.time_slot',
        'er_status'      => 'instant_exam_reminder_logs.status',
        'er_email'       => 'instant_exam_reminder_logs.email',
        'er_cron_run_id' => 'instant_exam_reminder_logs.cron_run_id',
    ],
    'project_submission_reminder' => [
        'psr_internship_name' => 'project_submission_reminder_logs.internship_name',
        'psr_batch'           => 'project_submission_reminder_logs.batch',
        'psr_duration_label'  => 'project_submission_reminder_logs.duration_label',
        'psr_status'          => 'project_submission_reminder_logs.status',
        'psr_email'           => 'project_submission_reminder_logs.email',
        'psr_cron_run_id'     => 'project_submission_reminder_logs.cron_run_id',
    ],
    'one_day_before_batch_start' => [
        'odb_internship_name' => 'one_day_before_batch_start_logs.internship_name',
        'odb_batch'           => 'one_day_before_batch_start_logs.batch',
        'odb_duration_label'  => 'one_day_before_batch_start_logs.duration_label',
        'odb_status'          => 'one_day_before_batch_start_logs.status',
        'odb_email'           => 'one_day_before_batch_start_logs.email',
        'odb_cron_run_id'     => 'one_day_before_batch_start_logs.cron_run_id',
    ],
    'batch_end_reminder' => [
        'ber_internship_name' => 'same_day_batch_end_logs.internship_name',
        'ber_batch'           => 'same_day_batch_end_logs.batch',
        'ber_end_date'        => 'same_day_batch_end_logs.end_date',
        'ber_project_status'  => 'same_day_batch_end_logs.project_status',
        'ber_resubmitted'     => 'same_day_batch_end_logs.resubmitted',
        'ber_status'          => 'same_day_batch_end_logs.status',
        'ber_email'           => 'same_day_batch_end_logs.email',
        'ber_cron_run_id'     => 'same_day_batch_end_logs.cron_run_id',
    ],
];

/* day filter — { type:'any'|'between'|'in_past'|'exactly_before', from, to, n, unit } → [start,end] dates or null */
function resolveDay($day) {
    if (!$day || ($day['type'] ?? 'any') === 'any') return [null, null];
    $t = $day['type'];
    $today = date('Y-m-d');
    if ($t === 'between') return [$day['from'] ?? $today, $day['to'] ?? $today];
    if ($t === 'in_past') {
        $n = max(1, (int)($day['n'] ?? 7));
        $unit = $day['unit'] ?? 'days';
        $sec = ['hours'=>3600,'days'=>86400,'weeks'=>604800,'months'=>2592000][$unit] ?? 86400;
        return [date('Y-m-d', time() - $n * $sec), $today];
    }
    if ($t === 'exactly_before') {
        $n = max(1, (int)($day['n'] ?? 7));
        $d = date('Y-m-d', time() - $n * 86400);
        return [$d, $d];
    }
    return [null, null];
}

/* Build a SELECT user_id subquery from a single condition. Returns SQL string or null on bad input. */
function buildConditionSql($cond, $isExclude = false) {
    global $EVENT_SOURCE, $PAYLOAD_COLUMNS, $conn;

    $kind = $cond['kind'] ?? 'behaviour';
    if ($kind === 'engagement') return buildEngagementConditionSql($cond);
    if ($kind === 'contacts')   return buildContactsConditionSql($cond);

    $event = $cond['event'] ?? '';
    if (!isset($EVENT_SOURCE[$event])) return null;
    $src     = $EVENT_SOURCE[$event];
    $tbl     = $src['table'];
    $userCol = $src['user_col'];
    $dateCol = $src['date_col'];
    $where   = $src['where'] ?? '';
    $srcJoin = $src['join']  ?? '';

    $userColQ = (strpos($userCol, '.') === false) ? "$tbl.$userCol" : $userCol;

    $op    = $cond['operator'] ?? '>=';
    $count = max(0, (int)($cond['count'] ?? 1));
    $opMap = ['>='=>'>=', '>'=>'>', '<='=>'<=', '<'=>'<', '='=>'='];
    if (!isset($opMap[$op])) $op = '>=';

    [$ds, $de] = resolveDay($cond['day'] ?? null);
    $whereParts = [];
    if ($where !== '') $whereParts[] = $where;
    if ($ds && $de)    $whereParts[] = "$dateCol BETWEEN '" . esc($ds) . " 00:00:00' AND '" . esc($de) . " 23:59:59'";

    $allFilters = !empty($cond['filter']) ? [$cond['filter']] : ($cond['filters'] ?? []);
    foreach ($allFilters as $f) {
        if (!$f) continue;
        $pkey = $f['payload'] ?? '';
        $pop  = $f['op']      ?? 'is';
        $pval = $f['value']   ?? '';
        $col  = $PAYLOAD_COLUMNS[$event][$pkey] ?? null;
        if (!$col) continue;
        $valE = esc($pval);
        switch ($pop) {
            case 'exists':         $whereParts[] = "$col IS NOT NULL AND $col <> ''"; break;
            case 'does not exist': $whereParts[] = "($col IS NULL OR $col = '')";     break;
            case 'is':             $whereParts[] = "$col = '$valE'";                  break;
            case 'is not':         $whereParts[] = "$col <> '$valE'";                 break;
            case 'contains':       $whereParts[] = "$col LIKE '%$valE%'";             break;
            case 'does not contain': $whereParts[] = "$col NOT LIKE '%$valE%'";       break;
        }
    }

    $whereSql = $whereParts ? 'WHERE ' . implode(' AND ', $whereParts) : '';

    $extraJoin = '';
    if ($srcJoin === '' && $tbl !== 'users') {
        $needsUsersJoin = false;
        foreach (($cond['filters'] ?? []) as $f) {
            $col = $PAYLOAD_COLUMNS[$event][$f['payload'] ?? ''] ?? '';
            if (strpos($col, 'users.') === 0) { $needsUsersJoin = true; break; }
        }
        if (!$needsUsersJoin && !empty($cond['filter']['payload'])) {
            $col = $PAYLOAD_COLUMNS[$event][$cond['filter']['payload']] ?? '';
            if (strpos($col, 'users.') === 0) $needsUsersJoin = true;
        }
        if ($needsUsersJoin) $extraJoin = "LEFT JOIN users ON users.user_id = $userColQ";
    }

    $sql = "SELECT $userColQ AS user_id FROM $tbl $srcJoin $extraJoin $whereSql GROUP BY $userColQ HAVING COUNT(*) $op $count";

    if (($cond['did'] ?? 'did') === 'did_not_do') {
        /* NOT IN against a set holding a NULL matches nobody, so NULL user_ids are dropped first */
        $sql = "SELECT u.user_id FROM users u WHERE u.user_id NOT IN (SELECT nd.user_id FROM ($sql) AS nd WHERE nd.user_id IS NOT NULL)";
    }
    return $sql;
}

/* Combine sub-queries (each yielding user_ids) by walking left-to-right with AND/OR.
   AND → IN (next), OR → UNION. */
function combineByConnector($items) {
    if (!$items) return null;
    $current = $items[0]['sql'];
    for ($i = 1; $i < count($items); $i++) {
        $next = $items[$i]['sql'];
        if (($items[$i]['connector'] ?? 'AND') === 'OR') {
            $current = "($current) UNION ($next)";
        } else {
            $current = "SELECT user_id FROM ($current) AS a WHERE user_id IN ($next)";
        }
    }
    return $current;
}

function combineConditions($conds) {
    $items = [];
    foreach ($conds as $i => $c) {
        $s = buildConditionSql($c);
        if (!$s) continue;
        $items[] = ['connector' => $i === 0 ? null : ($c['condConnector'] ?? 'AND'), 'sql' => $s];
    }
    return combineByConnector($items);
}

function combineBlocks($blocks) {
    $items = [];
    foreach ($blocks as $i => $b) {
        $s = combineConditions($b['conditions'] ?? []);
        if (!$s) continue;
        $items[] = ['connector' => $i === 0 ? null : ($b['blockConnector'] ?? 'AND'), 'sql' => $s];
    }
    $merged = combineByConnector($items);
    return $merged ? "SELECT DISTINCT user_id FROM ($merged) AS final_set" : null;
}

/* Build full SQL: include MINUS exclude. Final result excludes users whose users.active = 0. */
function buildSegmentSql($config) {
    $inc = combineBlocks($config['include']['blocks'] ?? []);
    if (!$inc) return null;
    $exc = combineBlocks($config['exclude']['blocks'] ?? []);
    $base = $exc
        ? "SELECT user_id FROM ($inc) AS inc WHERE user_id NOT IN (SELECT user_id FROM ($exc) AS exc WHERE user_id IS NOT NULL)"
        : $inc;

    return "SELECT s.user_id
            FROM ($base) AS s
            INNER JOIN users u ON u.user_id = s.user_id
            WHERE COALESCE(u.active, 1) <> 0";
}

function countSegment($config) {
    global $conn;
    $sql = buildSegmentSql($config);
    if (!$sql) return 0;
    $r = mysqli_query($conn, "SELECT COUNT(*) AS c FROM ($sql) AS s");
    if (!$r) return 0;
    return (int)mysqli_fetch_assoc($r)['c'];
}

/* counts: total, with email, with phone */
function channelCounts($config) {
    global $conn;
    $sql = buildSegmentSql($config);
    if (!$sql) return ['total' => 0, 'email' => 0, 'phone' => 0];
    $q = "SELECT
            COUNT(*) AS total,
            SUM(CASE WHEN u.email IS NOT NULL AND u.email <> '' THEN 1 ELSE 0 END) AS email_c,
            SUM(CASE WHEN u.phone IS NOT NULL AND u.phone <> '' THEN 1 ELSE 0 END) AS phone_c
          FROM ($sql) AS s INNER JOIN users u ON u.user_id = s.user_id";
    $r = mysqli_query($conn, $q);
    if (!$r) return ['total' => 0, 'email' => 0, 'phone' => 0];
    $row = mysqli_fetch_assoc($r);
    return [
        'total' => (int)$row['total'],
        'email' => (int)$row['email_c'],
        'phone' => (int)$row['phone_c'],
    ];
}

<?php
/*
 * /api/freshdesk/lib/MimeParser.php
 *
 * Turns a raw RFC 5322 message into the structure the helpdesk stores:
 * decoded headers, an HTML body, a text body, and a list of attachments
 * (including inline images referenced by cid:).
 *
 * Written from scratch because mailparse (a PECL extension) is not installed on
 * shared hosting and pulling in a Composer MIME library is not an option in
 * this deployment (no vendor/ under react-api).
 *
 * The four things real-world mail does that naive parsers get wrong, all
 * handled below:
 *   1. Headers fold across lines and are RFC 2047 encoded per-word, sometimes
 *      splitting a single UTF-8 character across two encoded-words.
 *   2. Bodies arrive in any charset (ISO-8859-1, windows-1252, Shift_JIS,
 *      GB2312) and MUST be transcoded to UTF-8 before touching a utf8mb4 column
 *      or the INSERT truncates the row at the first bad byte.
 *   3. multipart/* nests arbitrarily -- mixed(alternative(text,html), related(html,image), pdf).
 *   4. Filenames use RFC 2231 continuations (filename*0*=utf-8''..., filename*1*=...)
 *      which look nothing like the simple filename="x.pdf" form.
 */

class MimeParser
{
    /**
     * Parse a raw message.
     *
     * @return array {
     *   headers, subject, from_name, from_email, to[], cc[], bcc[], reply_to,
     *   message_id, in_reply_to, references[], date (Y-m-d H:i:s), is_auto_reply,
     *   is_bounce, body_html, body_text, attachments[]
     * }
     */
    public static function parse($raw)
    {
        $raw = str_replace("\r\n", "\n", (string)$raw);
        list($headerBlock, $bodyBlock) = self::splitHeaderBody($raw);
        $headers = self::parseHeaders($headerBlock);

        $out = array(
            'headers'       => $headers,
            'subject'       => self::decodeWords(self::header($headers, 'subject', '')),
            'from_name'     => '',
            'from_email'    => '',
            'to'            => self::parseAddressList(self::header($headers, 'to', '')),
            'cc'            => self::parseAddressList(self::header($headers, 'cc', '')),
            'bcc'           => self::parseAddressList(self::header($headers, 'bcc', '')),
            'reply_to'      => '',
            'message_id'    => trim(self::header($headers, 'message-id', '')),
            'in_reply_to'   => trim(self::header($headers, 'in-reply-to', '')),
            'references'    => array(),
            'date'          => null,
            'is_auto_reply' => false,
            'is_bounce'     => false,
            'body_html'     => '',
            'body_text'     => '',
            'attachments'   => array(),
        );

        $from = self::parseAddressList(self::header($headers, 'from', ''));
        if (!empty($from)) {
            $out['from_name']  = $from[0]['name'];
            $out['from_email'] = $from[0]['email'];
        }
        $rt = self::parseAddressList(self::header($headers, 'reply-to', ''));
        if (!empty($rt)) $out['reply_to'] = $rt[0]['email'];

        // Message-IDs are angle-bracketed tokens; keep them exactly as sent
        // (they are compared byte-for-byte when threading) but drop stray text.
        if ($out['message_id'] !== '' && preg_match('/<[^>]+>/', $out['message_id'], $m)) $out['message_id'] = $m[0];
        if ($out['in_reply_to'] !== '' && preg_match('/<[^>]+>/', $out['in_reply_to'], $m)) $out['in_reply_to'] = $m[0];
        if (preg_match_all('/<[^>]+>/', self::header($headers, 'references', ''), $ms)) {
            $out['references'] = $ms[0];
        }

        $dateHdr = self::header($headers, 'date', '');
        $ts = $dateHdr !== '' ? strtotime($dateHdr) : false;
        $out['date'] = $ts ? date('Y-m-d H:i:s', $ts) : date('Y-m-d H:i:s');

        /*
         * Auto-responder detection. This is not cosmetic: without it, our
         * auto-acknowledgement and the customer's out-of-office reply each
         * answer the other forever, and the mailbox melts down in minutes.
         * Any positive here means "never auto-reply to this message".
         */
        $out['is_auto_reply'] = self::detectAutoReply($headers);
        $out['is_bounce']     = self::detectBounce($headers, $out['from_email']);

        $ctype = self::header($headers, 'content-type', 'text/plain');
        $parts = self::parseBody($bodyBlock, $ctype, self::header($headers, 'content-transfer-encoding', '7bit'), $headers);

        foreach ($parts as $p) {
            if ($p['kind'] === 'html' && $out['body_html'] === '')      $out['body_html'] = $p['content'];
            elseif ($p['kind'] === 'html')                              $out['body_html'] .= "\n<hr>\n" . $p['content'];
            elseif ($p['kind'] === 'text' && $out['body_text'] === '')  $out['body_text'] = $p['content'];
            elseif ($p['kind'] === 'text')                              $out['body_text'] .= "\n\n" . $p['content'];
            elseif ($p['kind'] === 'attachment')                        $out['attachments'][] = $p;
        }

        // Always end up with both representations -- the list view needs text,
        // the reader needs HTML, and neither should have to care what arrived.
        if ($out['body_html'] === '' && $out['body_text'] !== '') {
            $out['body_html'] = '<div style="white-space:pre-wrap;font-family:inherit">'
                . htmlspecialchars($out['body_text'], ENT_QUOTES, 'UTF-8') . '</div>';
        }
        if ($out['body_text'] === '' && $out['body_html'] !== '') {
            $out['body_text'] = fd_html_to_text($out['body_html']);
        }

        $out['attachments'] = self::reconcileInline($out['attachments'], $out['body_html']);

        return $out;
    }

    /**
     * An "inline" part the body never shows is a normal attachment.
     *
     * The leaf parser only sees one MIME part at a time, so it cannot know
     * whether anything points at a given Content-ID -- it has to guess from the
     * headers. This runs once the whole message is assembled, when the HTML is
     * available, and corrects the guess: if nothing in the body references
     * cid:<id>, the part is something the sender attached, not something they
     * embedded, and it belongs in the file strip where an agent can see it.
     *
     * Deliberately one-way. A part the HTML DOES reference is left alone, and a
     * part already classified as a normal attachment is never promoted to
     * inline -- that direction would hide files, which is the bug this whole
     * pass exists to prevent.
     */
    private static function reconcileInline($attachments, $html)
    {
        if (empty($attachments)) return $attachments;

        foreach ($attachments as $i => $a) {
            if (empty($a['is_inline'])) continue;
            $cid = isset($a['content_id']) ? trim((string)$a['content_id'], " <>\t") : '';
            /* Inline with no Content-ID cannot be addressed by the HTML at all,
               so there is nothing it could be embedded as. */
            if ($cid === '' || $html === '' || stripos($html, 'cid:' . $cid) === false) {
                $attachments[$i]['is_inline'] = 0;
            }
        }
        return $attachments;
    }

    /* ---------------------------------------------------------- headers -- */

    private static function splitHeaderBody($raw)
    {
        $pos = strpos($raw, "\n\n");
        if ($pos === false) return array($raw, '');
        return array(substr($raw, 0, $pos), substr($raw, $pos + 2));
    }

    /**
     * Parse a header block into ['name-lowercased' => value | [values]].
     * Unfolds continuation lines (a line starting with space/tab belongs to the
     * previous header) BEFORE splitting on ':' -- a long Subject or References
     * is routinely folded across five lines and reading it line-wise loses most
     * of it.
     */
    public static function parseHeaders($block)
    {
        $headers = array();
        $lines = explode("\n", str_replace("\r", '', $block));
        $current = null; $buf = '';
        foreach ($lines as $line) {
            if ($line === '') continue;
            if (preg_match('/^[ \t]/', $line)) {
                if ($current !== null) $buf .= ' ' . trim($line);
                continue;
            }
            if ($current !== null) self::pushHeader($headers, $current, $buf);
            $p = strpos($line, ':');
            if ($p === false) { $current = null; $buf = ''; continue; }
            $current = strtolower(trim(substr($line, 0, $p)));
            $buf = trim(substr($line, $p + 1));
        }
        if ($current !== null) self::pushHeader($headers, $current, $buf);
        return $headers;
    }

    private static function pushHeader(&$headers, $name, $value)
    {
        if (!isset($headers[$name])) { $headers[$name] = $value; return; }
        if (is_array($headers[$name])) $headers[$name][] = $value;
        else $headers[$name] = array($headers[$name], $value);
    }

    /** Read a header, collapsing repeats to the first occurrence. */
    public static function header($headers, $name, $default = '')
    {
        $name = strtolower($name);
        if (!isset($headers[$name])) return $default;
        $v = $headers[$name];
        return is_array($v) ? (isset($v[0]) ? $v[0] : $default) : $v;
    }

    /**
     * Decode RFC 2047 encoded-words: =?UTF-8?B?...?= / =?ISO-8859-1?Q?...?=
     *
     * Adjacent encoded-words are joined BEFORE decoding when they share a
     * charset, because a multi-byte character is allowed to be split across two
     * words; decoding them separately produces two invalid fragments and a
     * mojibake subject line.
     */
    public static function decodeWords($str)
    {
        if ($str === null || $str === '') return '';
        $str = (string)$str;
        if (strpos($str, '=?') === false) return self::toUtf8($str, 'UTF-8');

        // Whitespace between two encoded-words is not content -- remove it.
        $str = preg_replace('/(\?=)[ \t]+(=\?)/', '$1$2', $str);

        $out = preg_replace_callback(
            '/=\?([^?]+)\?([BbQq])\?([^?]*)\?=/',
            function ($m) {
                $charset = $m[1];
                $enc     = strtoupper($m[2]);
                $data    = $m[3];
                if ($enc === 'B') {
                    $decoded = base64_decode($data, false);
                } else {
                    // Q encoding: '_' is a space, =XX is a hex byte.
                    $decoded = quoted_printable_decode(str_replace('_', ' ', $data));
                }
                if ($decoded === false) return $m[0];
                return self::toUtf8($decoded, $charset);
            },
            $str
        );
        return $out === null ? $str : $out;
    }

    /**
     * Transcode to UTF-8 from whatever the message claims (or looks like).
     * Falls through iconv -> mbstring -> a lossy scrub, because a body we cannot
     * transcode must still be stored -- losing a customer's email because their
     * client used a charset PHP does not know is not an acceptable outcome.
     */
    public static function toUtf8($str, $charset = 'UTF-8')
    {
        if ($str === '' || $str === null) return '';
        $charset = trim(strtoupper(str_replace('"', '', (string)$charset)));
        if ($charset === '' || $charset === 'US-ASCII' || $charset === 'ASCII') $charset = 'UTF-8';
        // Windows clients mislabel windows-1252 as ISO-8859-1 constantly; 1252 is
        // a strict superset, so decoding as 1252 is right in both cases.
        if ($charset === 'ISO-8859-1' || $charset === 'LATIN1') $charset = 'WINDOWS-1252';
        if ($charset === 'UTF8') $charset = 'UTF-8';

        if ($charset === 'UTF-8') {
            if (self::isValidUtf8($str)) return $str;
            // Claimed UTF-8 but isn't -- almost always 1252 in disguise.
            $charset = 'WINDOWS-1252';
        }

        if (function_exists('iconv')) {
            // //TRANSLIT+//IGNORE: never abort the whole body over one bad byte.
            $r = @iconv($charset, 'UTF-8//TRANSLIT//IGNORE', $str);
            if ($r !== false && $r !== '') return $r;
        }
        if (function_exists('mb_convert_encoding')) {
            $r = @mb_convert_encoding($str, 'UTF-8', $charset);
            if ($r !== false && $r !== '') return $r;
        }
        // Last resort: drop anything that is not valid UTF-8.
        return self::scrubUtf8($str);
    }

    private static function isValidUtf8($s)
    {
        if (function_exists('mb_check_encoding')) return mb_check_encoding($s, 'UTF-8');
        return (bool)preg_match('//u', $s);
    }

    private static function scrubUtf8($s)
    {
        $out = @preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F]/', '', $s);
        if (function_exists('mb_convert_encoding')) {
            $out = @mb_convert_encoding($out, 'UTF-8', 'UTF-8');
        }
        return $out === null ? '' : $out;
    }

    /**
     * Parse "Name <a@b.com>, other@c.com, \"Last, First\" <d@e.com>".
     * Splits on commas that are NOT inside quotes or angle brackets -- a
     * display name of "Sharma, Ananya" is extremely common and a naive
     * explode(',') turns one person into two broken addresses.
     */
    public static function parseAddressList($str)
    {
        $str = self::decodeWords((string)$str);
        if (trim($str) === '') return array();

        $parts = array(); $buf = ''; $inQuote = false; $depth = 0;
        $len = strlen($str);
        for ($i = 0; $i < $len; $i++) {
            $c = $str[$i];
            if ($c === '"' && ($i === 0 || $str[$i - 1] !== '\\')) $inQuote = !$inQuote;
            elseif ($c === '<' && !$inQuote) $depth++;
            elseif ($c === '>' && !$inQuote) $depth = max(0, $depth - 1);
            if ($c === ',' && !$inQuote && $depth === 0) { $parts[] = $buf; $buf = ''; continue; }
            $buf .= $c;
        }
        if (trim($buf) !== '') $parts[] = $buf;

        $out = array();
        foreach ($parts as $p) {
            $p = trim($p);
            if ($p === '') continue;
            $name = ''; $email = '';
            if (preg_match('/^(.*?)<([^>]*)>\s*$/s', $p, $m)) {
                $name  = trim($m[1]);
                $email = trim($m[2]);
            } else {
                $email = trim($p);
            }
            $name = trim($name, " \t\"'");
            $email = trim($email, " \t<>");
            // Groups ("undisclosed-recipients:;") and empty slots produce no address.
            if ($email === '' || strpos($email, '@') === false) continue;
            $out[] = array('name' => $name, 'email' => strtolower($email));
        }
        return $out;
    }

    /* ------------------------------------------------------------- body -- */

    /**
     * Walk a (possibly nested) MIME tree and flatten it into
     * [['kind'=>'html'|'text'|'attachment', ...], ...].
     */
    private static function parseBody($body, $contentType, $encoding, $headers, $depth = 0)
    {
        // A deliberately deep nest is a cheap DoS; 20 levels is far beyond
        // anything a real mail client produces.
        if ($depth > 20) return array();

        $ct       = self::parseContentType($contentType);
        $mime     = strtolower($ct['type']);
        $boundary = isset($ct['params']['boundary']) ? $ct['params']['boundary'] : null;

        if (strpos($mime, 'multipart/') === 0 && $boundary) {
            $sub = self::splitMultipart($body, $boundary);
            $collected = array();

            if ($mime === 'multipart/alternative') {
                /*
                 * alternative = the SAME content in several formats, richest
                 * last. Taking all of them duplicates the message in the
                 * thread (once as text, once as HTML), so pick the best one:
                 * HTML if present, else text. Any non-text sibling (an inline
                 * image some clients tuck in here) is still kept.
                 */
                $best = null; $bestRank = -1;
                foreach ($sub as $s) {
                    $sh   = self::parseHeaders($s['headers']);
                    $sct  = self::parseContentType(self::header($sh, 'content-type', 'text/plain'));
                    $smime = strtolower($sct['type']);
                    $rank = ($smime === 'text/html') ? 2 : (($smime === 'text/plain') ? 1 : 0);
                    if ($rank === 0) {
                        $collected = array_merge($collected, self::parseBody($s['body'], self::header($sh, 'content-type', ''), self::header($sh, 'content-transfer-encoding', '7bit'), $sh, $depth + 1));
                        continue;
                    }
                    if ($rank > $bestRank) { $bestRank = $rank; $best = array($s, $sh); }
                }
                if ($best) {
                    $collected = array_merge($collected, self::parseBody(
                        $best[0]['body'],
                        self::header($best[1], 'content-type', 'text/plain'),
                        self::header($best[1], 'content-transfer-encoding', '7bit'),
                        $best[1], $depth + 1
                    ));
                }
                return $collected;
            }

            foreach ($sub as $s) {
                $sh = self::parseHeaders($s['headers']);
                $collected = array_merge($collected, self::parseBody(
                    $s['body'],
                    self::header($sh, 'content-type', 'text/plain'),
                    self::header($sh, 'content-transfer-encoding', '7bit'),
                    $sh, $depth + 1
                ));
            }
            return $collected;
        }

        // ---- leaf part ----
        $disposition = strtolower(trim(self::parseContentType(self::header($headers, 'content-disposition', ''))['type']));
        $filename    = self::extractFilename($headers, $ct);
        $contentId   = trim(self::header($headers, 'content-id', ''), " <>\t");

        $isAttachment = ($disposition === 'attachment')
            || ($filename !== '' && strpos($mime, 'text/') !== 0)
            || ($disposition === 'inline' && strpos($mime, 'text/') !== 0)
            || ($contentId !== '' && strpos($mime, 'text/') !== 0)
            || (strpos($mime, 'text/') !== 0 && $mime !== 'message/rfc822' && $mime !== '');

        // A forwarded .eml: keep it as a downloadable attachment rather than
        // splicing its contents into this ticket's conversation.
        if ($mime === 'message/rfc822' && $disposition === 'attachment') {
            $isAttachment = true;
            if ($filename === '') $filename = 'forwarded-message.eml';
        }

        $decoded = self::decodeContent($body, $encoding);

        if ($isAttachment) {
            if ($filename === '') {
                $ext = self::extensionForMime($mime);
                $filename = ($contentId !== '' ? 'inline-' : 'attachment-') . substr(md5($decoded), 0, 8) . $ext;
            }
            return array(array(
                'kind'       => 'attachment',
                'filename'   => self::sanitizeFilename($filename),
                'mime'       => $mime ?: 'application/octet-stream',
                'content'    => $decoded,
                'size'       => strlen($decoded),
                'content_id' => $contentId,
                /*
                 * A Content-ID ALONE does not make a part inline.
                 *
                 * This used to read ($contentId !== '' || $disposition ===
                 * 'inline'), and it silently hid real attachments. Outlook --
                 * and Apple Mail, and anything built on Exchange -- stamps a
                 * Content-ID on EVERY MIME part it emits, including a PDF sent
                 * with an explicit "Content-Disposition: attachment". Those
                 * landed with is_inline = 1, and from there they were invisible
                 * twice over: the reader filters the file strip on !inline, and
                 * fd_recount_ticket() counts attachment_count WHERE is_inline =
                 * 0, so the paperclip did not appear either. The file was in S3
                 * and indexed in the DB the whole time; nothing in the UI would
                 * show it.
                 *
                 * RFC 2183 is explicit that the disposition decides, so an
                 * explicit "attachment" now always wins. A part with a
                 * Content-ID and NO disposition is still provisionally inline
                 * -- that is the shape a genuine embedded image usually takes
                 * -- and reconcileInline() downgrades it after parsing if the
                 * HTML never actually references its cid.
                 */
                'is_inline'  => $disposition === 'attachment'
                    ? 0
                    : (($contentId !== '' || $disposition === 'inline') ? 1 : 0),
            ));
        }

        $charset = isset($ct['params']['charset']) ? $ct['params']['charset'] : 'UTF-8';
        $text = self::toUtf8($decoded, $charset);

        if ($mime === 'text/html') return array(array('kind' => 'html', 'content' => $text));
        if ($mime === 'text/plain' || $mime === '' || strpos($mime, 'text/') === 0) {
            return array(array('kind' => 'text', 'content' => $text));
        }
        return array();
    }

    /**
     * Split a multipart body on its boundary.
     * Boundary lines are "--<boundary>"; the terminator is "--<boundary>--".
     * The preamble before the first boundary and the epilogue after the
     * terminator are not parts and are discarded.
     */
    private static function splitMultipart($body, $boundary)
    {
        $out = array();
        $delim = '--' . $boundary;
        $lines = explode("\n", $body);

        $inPart = false; $cur = array(); $parts = array();
        foreach ($lines as $line) {
            $trimmed = rtrim($line, "\r");
            if ($trimmed === $delim || $trimmed === $delim . '--') {
                if ($inPart) $parts[] = implode("\n", $cur);
                $cur = array();
                $inPart = ($trimmed === $delim);
                if ($trimmed === $delim . '--') break;   // final boundary
                continue;
            }
            if ($inPart) $cur[] = $line;
        }
        if ($inPart && !empty($cur)) $parts[] = implode("\n", $cur);

        foreach ($parts as $p) {
            $pos = strpos($p, "\n\n");
            if ($pos === false) {
                // Headerless part -- treat the whole thing as body.
                $out[] = array('headers' => '', 'body' => $p);
            } else {
                $out[] = array('headers' => substr($p, 0, $pos), 'body' => substr($p, $pos + 2));
            }
        }
        return $out;
    }

    /** Parse "text/html; charset=utf-8; boundary=xyz" into type + params. */
    public static function parseContentType($value)
    {
        $value = (string)$value;
        $out = array('type' => '', 'params' => array());
        if (trim($value) === '') return $out;

        $semi = strpos($value, ';');
        $out['type'] = trim($semi === false ? $value : substr($value, 0, $semi));
        if ($semi === false) return $out;

        $rest = substr($value, $semi + 1);
        // name="a;b.pdf" is legal, so params cannot be split on a bare ';'.
        if (preg_match_all('/([\w\-\*]+)\s*=\s*("([^"]*)"|([^;]*))/', $rest, $ms, PREG_SET_ORDER)) {
            foreach ($ms as $m) {
                $k = strtolower(trim($m[1]));
                $v = isset($m[3]) && $m[3] !== '' ? $m[3] : trim($m[4]);
                $out['params'][$k] = trim($v);
            }
        }
        return $out;
    }

    /**
     * Get the filename, handling all three spellings in the wild:
     *   filename="report.pdf"                        (plain)
     *   filename*=utf-8''report%20%E2%9C%93.pdf      (RFC 2231 single)
     *   filename*0*=utf-8''long; filename*1*=name    (RFC 2231 continuations)
     * plus name= on Content-Type, which older clients use instead.
     */
    private static function extractFilename($headers, $ct)
    {
        $cd = self::parseContentType(self::header($headers, 'content-disposition', ''));
        $sources = array($cd['params'], $ct['params']);

        foreach ($sources as $params) {
            // RFC 2231 continuations first -- they hold the full name.
            $chunks = array(); $ext = false;
            foreach ($params as $k => $v) {
                if (preg_match('/^(filename|name)\*(\d+)(\*)?$/i', $k, $m)) {
                    $chunks[(int)$m[2]] = $v;
                    if (!empty($m[3])) $ext = true;
                }
            }
            if (!empty($chunks)) {
                ksort($chunks);
                $joined = implode('', $chunks);
                return $ext ? self::decode2231($joined) : self::decodeWords($joined);
            }
            foreach (array('filename*', 'name*') as $k) {
                if (isset($params[$k]) && $params[$k] !== '') return self::decode2231($params[$k]);
            }
            foreach (array('filename', 'name') as $k) {
                if (isset($params[$k]) && $params[$k] !== '') return self::decodeWords($params[$k]);
            }
        }
        return '';
    }

    /** Decode "utf-8''Na%C3%AFve%20file.pdf". */
    private static function decode2231($value)
    {
        $value = (string)$value;
        if (preg_match("/^([^']*)'([^']*)'(.*)$/s", $value, $m)) {
            return self::toUtf8(rawurldecode($m[3]), $m[1] !== '' ? $m[1] : 'UTF-8');
        }
        return self::toUtf8(rawurldecode($value), 'UTF-8');
    }

    /** Undo Content-Transfer-Encoding. */
    public static function decodeContent($body, $encoding)
    {
        $encoding = strtolower(trim((string)$encoding));
        if ($encoding === 'base64') {
            // strict=false: a stray character from a line-wrap glitch must not
            // discard an entire 4MB attachment.
            $d = base64_decode(preg_replace('/\s+/', '', $body), false);
            return $d === false ? '' : $d;
        }
        if ($encoding === 'quoted-printable') {
            return quoted_printable_decode($body);
        }
        // 7bit / 8bit / binary / unknown: as-is.
        return $body;
    }

    /* -------------------------------------------------------- detection -- */

    private static function detectAutoReply($headers)
    {
        $checks = array(
            'auto-submitted'    => '/auto-(replied|generated|notified)/i',
            'x-auto-response-suppress' => '/./',
            'precedence'        => '/(bulk|auto_reply|junk|list)/i',
            'x-autoreply'       => '/./',
            'x-autorespond'     => '/./',
            'x-mailer-daemon'   => '/./',
        );
        foreach ($checks as $h => $re) {
            $v = self::header($headers, $h, '');
            if ($v !== '' && preg_match($re, $v)) return true;
        }
        $subject = strtolower(self::decodeWords(self::header($headers, 'subject', '')));
        $phrases = array('out of office', 'auto-reply', 'auto reply', 'automatic reply', 'autoreply',
                         'away from my desk', 'on vacation', 'ooo:', 'abwesenheitsnotiz');
        foreach ($phrases as $p) {
            if (strpos($subject, $p) !== false) return true;
        }
        // list-* headers mean a mailing list, which must never receive a reply.
        if (self::header($headers, 'list-unsubscribe', '') !== '' && self::header($headers, 'list-id', '') !== '') return true;
        return false;
    }

    private static function detectBounce($headers, $fromEmail)
    {
        $from = strtolower((string)$fromEmail);
        if ($from === '' || $from === '<>') return true;
        foreach (array('mailer-daemon@', 'postmaster@', 'noreply-dmarc', 'bounce') as $needle) {
            if (strpos($from, $needle) === 0 || strpos($from, $needle) !== false) {
                if (strpos($from, 'bounce') !== false && strpos($from, 'bounces.') === false && strpos($from, 'mailer-daemon') === false && strpos($from, 'postmaster') === false) {
                    continue; // a person called "bouncer@" is not a bounce
                }
                return true;
            }
        }
        $ct = strtolower(self::header($headers, 'content-type', ''));
        if (strpos($ct, 'multipart/report') !== false && strpos($ct, 'delivery-status') !== false) return true;
        if (self::header($headers, 'x-failed-recipients', '') !== '') return true;
        $subject = strtolower(self::decodeWords(self::header($headers, 'subject', '')));
        foreach (array('undelivered mail', 'delivery status notification', 'mail delivery failed',
                       'returned mail', 'undeliverable', 'delivery has failed', 'failure notice') as $p) {
            if (strpos($subject, $p) !== false) return true;
        }
        return false;
    }

    /* ------------------------------------------------------------ utils -- */

    /**
     * Reduce an incoming filename to something that cannot escape the uploads
     * directory or trick a browser. Directory separators, null bytes, leading
     * dots and control characters all go; this is the filename we SHOW, while
     * the name on disk is randomised separately.
     */
    public static function sanitizeFilename($name)
    {
        $name = (string)$name;
        $name = str_replace(array("\0", "\r", "\n", "\t"), '', $name);
        $name = str_replace(array('\\', '/'), '_', $name);
        $name = preg_replace('/[\x00-\x1F\x7F]/', '', $name);
        $name = preg_replace('/^\.+/', '', $name);
        $name = trim($name);
        if ($name === '') $name = 'attachment';
        if (function_exists('mb_strlen') && mb_strlen($name, 'UTF-8') > 180) {
            $name = mb_substr($name, 0, 180, 'UTF-8');
        } elseif (strlen($name) > 180) {
            $name = substr($name, 0, 180);
        }
        return $name;
    }

    private static function extensionForMime($mime)
    {
        $map = array(
            'image/jpeg' => '.jpg', 'image/png' => '.png', 'image/gif' => '.gif',
            'image/webp' => '.webp', 'image/bmp' => '.bmp', 'image/svg+xml' => '.svg',
            'application/pdf' => '.pdf', 'application/zip' => '.zip',
            'application/msword' => '.doc', 'text/csv' => '.csv', 'text/plain' => '.txt',
            'application/vnd.openxmlformats-officedocument.wordprocessingml.document' => '.docx',
            'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' => '.xlsx',
            'message/rfc822' => '.eml',
        );
        $m = strtolower($mime);
        return isset($map[$m]) ? $map[$m] : '.bin';
    }
}

<?php
/*
 * Live Chat — the two-way half of the WhatsApp channel.
 *
 * Campaigns are one-way: we send a template and count what comes back as a number. This file
 * backs the other direction — when someone REPLIES to one of those campaign messages, that reply
 * has to land somewhere a human can answer it. That "somewhere" is a conversation.
 *
 * Two concepts do all the work:
 *
 *   wa_conversations   one row per (sending number, contact number). Carries the denormalized
 *                      last-message preview so the inbox list is a single indexed SELECT with no
 *                      joins — with thousands of threads that is the difference between an inbox
 *                      that opens instantly and one that doesn't.
 *
 *   wa_messages        the free-form traffic: every inbound message, and every manual reply an
 *                      admin types here. Campaign sends are deliberately NOT copied in — the
 *                      thread view merges them straight out of wa_campaign_recipients, so there
 *                      is exactly one copy of a campaign message in the database and its
 *                      delivered/read state stays the campaign's own.
 *
 * THE 24-HOUR RULE, because it explains most of this UI:
 * WhatsApp only allows free-form messages inside 24 hours of the contact's last message
 * ("customer service window"). Outside it, Meta rejects anything but an approved template. So
 * every conversation tracks window_expires_at, the composer disables itself when it lapses, and
 * the template picker takes over. Getting this wrong doesn't produce an error an admin would
 * understand — it produces a message that simply never arrives.
 */
// require_once __DIR__ . '/config.php';
// require_once __DIR__ . '/schema.php';
// require_once __DIR__ . '/WaHelpers.php';
// require_once __DIR__ . '/WaAudienceResolver.php';
// // wa_log() and wa_record_event() live here. webhook.php already pulls it in before this file,
// // but the dependency is stated explicitly so including WaInbox.php on its own (a future cron,
// // a one-off script) can't fatal on an undefined function.
// require_once __DIR__ . '/WaSendWorker.php';

// /** Where inbound media is cached after its first fetch. Outside the web root's reach on purpose:
//  *  everything is served back through wa_inbox.php so the JWT gate still applies to an image. */
// if (!defined('WA_MEDIA_DIR')) define('WA_MEDIA_DIR', __DIR__ . '/../media');

// /** Meta keeps inbound media for 30 days; after that the media id 404s and only our cache has it. */
// if (!defined('WA_MEDIA_RETENTION_DAYS')) define('WA_MEDIA_RETENTION_DAYS', 30);

// /** Bump alongside any change to wa_inbox_ensure_schema(), exactly as with WA_SCHEMA_VERSION. */
// if (!defined('WA_INBOX_SCHEMA_VERSION')) define('WA_INBOX_SCHEMA_VERSION', 1);

// /** Backstop for forgetting the bump above, for the same reason and in the same way as
//  *  WA_SCHEMA_FINGERPRINT in schema.php — see the note there. A missed bump on that constant is
//  *  what made creating a WhatsApp campaign fatal on a missing exclude_list_ids column. */
// if (!defined('WA_INBOX_SCHEMA_FINGERPRINT')) {
//     define('WA_INBOX_SCHEMA_FINGERPRINT', substr((string)@md5_file(__FILE__), 0, 10));
// }

// /** Stamped and skipped for the same reason as whatsapp_ensure_schema() — webhook.php calls both
//  *  on every inbound delivery receipt, and this one creates the conversation/message tables the
//  *  live chat needs, which no receipt has ever changed. See the long note over that function. */
// function wa_inbox_ensure_schema(bool $force = false): void {
//     global $conn;
//     if (!$conn) return;

//     static $done = false;
//     if ($done && !$force) return;

//     $stamp = sys_get_temp_dir() . '/wa_inbox_schema_v' . WA_INBOX_SCHEMA_VERSION . '_' . WA_INBOX_SCHEMA_FINGERPRINT . '.ok';
//     if (!$force && @is_file($stamp)) { $done = true; return; }

//     $done = true;

//     try {
//         $conn->query("CREATE TABLE IF NOT EXISTS wa_conversations (
//             id               BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
//             phone            VARCHAR(24) NOT NULL,
//             phone_number_id  VARCHAR(32) NOT NULL DEFAULT '',
//             sender_id        INT DEFAULT NULL,
//             waba_id          VARCHAR(64) DEFAULT NULL,

//             -- Identity. profile_name is what WhatsApp reports the contact calls themselves;
//             -- the rest is matched out of our own records so the panel can show a real person
//             -- rather than a bare number.
//             profile_name     VARCHAR(255) DEFAULT NULL,
//             user_id          BIGINT UNSIGNED DEFAULT NULL,
//             first_name       VARCHAR(255) DEFAULT NULL,
//             last_name        VARCHAR(255) DEFAULT NULL,
//             email            VARCHAR(255) DEFAULT NULL,

//             -- Denormalized preview for the list pane.
//             last_message_at        DATETIME DEFAULT NULL,
//             last_message_text      VARCHAR(500) DEFAULT NULL,
//             last_message_direction ENUM('in','out') DEFAULT NULL,
//             last_message_type      VARCHAR(24) DEFAULT NULL,
//             unread_count           INT NOT NULL DEFAULT 0,

//             -- End of the free-form window: last inbound + 24h. NULL means never messaged us.
//             window_expires_at DATETIME DEFAULT NULL,
//             last_inbound_at   DATETIME DEFAULT NULL,

//             -- Which campaign brought this person in — the first one whose message they answered.
//             origin_campaign_id INT DEFAULT NULL,

//             status      ENUM('open','resolved') NOT NULL DEFAULT 'open',
//             is_archived TINYINT(1) NOT NULL DEFAULT 0,
//             assigned_to BIGINT UNSIGNED DEFAULT NULL,
//             note        VARCHAR(1000) DEFAULT NULL,

//             created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
//             updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

//             UNIQUE INDEX uq_number_phone (phone_number_id, phone),
//             -- The inbox list's only ORDER BY. Archived rows are filtered first so the index
//             -- stays useful for the default view.
//             INDEX idx_recent (is_archived, last_message_at),
//             INDEX idx_unread (unread_count),
//             INDEX idx_phone (phone)
//         ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

//         $conn->query("CREATE TABLE IF NOT EXISTS wa_messages (
//             id              BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
//             conversation_id BIGINT UNSIGNED NOT NULL,
//             direction       ENUM('in','out') NOT NULL,
//             wa_message_id   VARCHAR(120) DEFAULT NULL,
//             -- Echoed to Meta as nothing; kept so a send can be correlated before the id arrives.
//             rid             CHAR(32) DEFAULT NULL,

//             msg_type   VARCHAR(24) NOT NULL DEFAULT 'text',
//             body       TEXT DEFAULT NULL,
//             caption    VARCHAR(1000) DEFAULT NULL,

//             -- Media. media_id is Meta's handle (valid ~30 days). The bytes themselves live in
//             -- S3 — media_s3_key/media_s3_url — and are the only copy that survives Meta's
//             -- retention window. local_path is the pre-S3 disk cache, kept so older messages
//             -- still open; nothing writes to it any more (see wa_media_fetch()).
//             media_id       VARCHAR(190) DEFAULT NULL,
//             media_mime     VARCHAR(120) DEFAULT NULL,
//             media_filename VARCHAR(255) DEFAULT NULL,
//             media_size     INT DEFAULT NULL,
//             local_path     VARCHAR(255) DEFAULT NULL,
//             media_s3_key   VARCHAR(400) DEFAULT NULL,
//             media_s3_url   VARCHAR(700) DEFAULT NULL,

//             template_name VARCHAR(255) DEFAULT NULL,
//             -- The message being replied to, when the contact used WhatsApp's reply-quote.
//             context_wamid VARCHAR(120) DEFAULT NULL,

//             status        ENUM('received','pending','sent','delivered','read','failed') NOT NULL DEFAULT 'received',
//             error_code    VARCHAR(64) DEFAULT NULL,
//             error_message VARCHAR(500) DEFAULT NULL,

//             sent_by    BIGINT UNSIGNED DEFAULT NULL,
//             created_at DATETIME NOT NULL,
//             delivered_at DATETIME DEFAULT NULL,
//             read_at      DATETIME DEFAULT NULL,

//             -- Meta re-delivers a webhook it didn't get a 200 for, so the same inbound message
//             -- can legitimately arrive several times. This key is what makes ingestion idempotent.
//             UNIQUE INDEX uq_wamid (wa_message_id),
//             INDEX idx_thread (conversation_id, id),
//             INDEX idx_created (created_at)
//         ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

//         // Only a clean pass stamps — a half-finished run must be retried, not skipped forever.
//         @file_put_contents($stamp, date('c') . " ok\n", LOCK_EX);

//         // Clear the stamps earlier builds left behind, so one dead file per deploy doesn't pile up.
//         foreach ((array)@glob(sys_get_temp_dir() . '/wa_inbox_schema_v*.ok') as $old) {
//             if ($old !== $stamp) @unlink($old);
//         }
//     } catch (\Throwable $e) {
//         error_log('wa_inbox_ensure_schema: ' . $e->getMessage());
//     }
// }

// /* ── identity ─────────────────────────────────────────────────────────────────────────── */

// /**
//  * Everything we already know about this number, pulled from campaign history.
//  *
//  * A person who replies to a campaign is by definition someone we messaged, so their name and
//  * email are already sitting on the recipient row — no extra lookup against `users` needed, and
//  * it works for list-sourced contacts that have no user record at all.
//  */
// function wa_identity_for_phone(string $phone): array {
//     global $conn;
//     $p = $conn->real_escape_string($phone);
//     $r = $conn->query("SELECT user_id, email, first_name, last_name, campaign_id
//                          FROM wa_campaign_recipients
//                         WHERE phone='$p'
//                         ORDER BY (user_id IS NULL) ASC, id DESC
//                         LIMIT 1");
//     $row = $r ? $r->fetch_assoc() : null;
//     return $row ?: [];
// }

// /**
//  * The conversation for a (sending number, contact) pair, created on first contact.
//  *
//  * INSERT … ON DUPLICATE KEY is deliberate over SELECT-then-INSERT: webhook deliveries for the
//  * same person can arrive concurrently, and the race would otherwise produce two threads for one
//  * contact — which looks to an admin like messages randomly going missing.
//  */
// function wa_conversation_upsert(string $phone, string $phoneNumberId, ?string $profileName = null): ?array {
//     global $conn;

//     $p   = $conn->real_escape_string($phone);
//     $pni = $conn->real_escape_string($phoneNumberId);

//     $r = $conn->query("SELECT * FROM wa_conversations WHERE phone_number_id='$pni' AND phone='$p' LIMIT 1");
//     $existing = $r ? $r->fetch_assoc() : null;

//     if ($existing) {
//         // A profile name can change (people rename themselves); keep the latest.
//         if ($profileName !== null && $profileName !== '' && $profileName !== $existing['profile_name']) {
//             $conn->query("UPDATE wa_conversations SET profile_name='" . $conn->real_escape_string($profileName) . "'
//                            WHERE id=" . (int)$existing['id']);
//             $existing['profile_name'] = $profileName;
//         }
//         return $existing;
//     }

//     $ident = wa_identity_for_phone($phone);
//     $sender = null;
//     if ($phoneNumberId !== '') {
//         $sr = $conn->query("SELECT id, waba_id FROM wa_senders WHERE phone_number_id='$pni' LIMIT 1");
//         $sender = $sr ? $sr->fetch_assoc() : null;
//     }

//     $esc = fn($v) => "'" . $conn->real_escape_string((string)$v) . "'";
//     $conn->query("INSERT INTO wa_conversations
//         (phone, phone_number_id, sender_id, waba_id, profile_name, user_id, first_name, last_name, email, origin_campaign_id)
//         VALUES (" . $esc($phone) . ", " . $esc($phoneNumberId) . ", "
//         . (isset($sender['id']) ? (int)$sender['id'] : 'NULL') . ", "
//         . $esc($sender['waba_id'] ?? '') . ", " . $esc((string)$profileName) . ", "
//         . (!empty($ident['user_id']) ? (int)$ident['user_id'] : 'NULL') . ", "
//         . $esc($ident['first_name'] ?? '') . ", " . $esc($ident['last_name'] ?? '') . ", "
//         . $esc($ident['email'] ?? '') . ", "
//         . (!empty($ident['campaign_id']) ? (int)$ident['campaign_id'] : 'NULL') . ")
//         ON DUPLICATE KEY UPDATE updated_at = NOW()");

//     $r2 = $conn->query("SELECT * FROM wa_conversations WHERE phone_number_id='$pni' AND phone='$p' LIMIT 1");
//     $row = $r2 ? $r2->fetch_assoc() : null;
//     return $row ?: null;
// }

// /** Refreshes the list-pane preview after a message lands. One UPDATE, never a recount. */
// function wa_conversation_touch(int $conversationId, array $msg, bool $inbound): void {
//     global $conn;

//     $preview = wa_message_preview($msg);
//     $at      = $msg['created_at'] ?? date('Y-m-d H:i:s');

//     $sets = [
//         "last_message_at='"        . $conn->real_escape_string($at) . "'",
//         "last_message_text='"      . $conn->real_escape_string(mb_substr($preview, 0, 480)) . "'",
//         "last_message_direction='" . ($inbound ? 'in' : 'out') . "'",
//         "last_message_type='"      . $conn->real_escape_string((string)($msg['msg_type'] ?? 'text')) . "'",
//     ];
//     if ($inbound) {
//         // Every inbound message restarts the 24-hour free-form window, and un-resolves a thread
//         // someone had closed — a new question on an old thread is still a new question.
//         $sets[] = "unread_count = unread_count + 1";
//         $sets[] = "last_inbound_at='" . $conn->real_escape_string($at) . "'";
//         $sets[] = "window_expires_at = DATE_ADD('" . $conn->real_escape_string($at) . "', INTERVAL 24 HOUR)";
//         $sets[] = "status='open'";
//         $sets[] = "is_archived=0";
//     }
//     $conn->query("UPDATE wa_conversations SET " . implode(', ', $sets) . ' WHERE id=' . (int)$conversationId);
// }

// /** One line of text for the list pane, whatever the message actually was. */
// function wa_message_preview(array $msg): string {
//     $type = (string)($msg['msg_type'] ?? 'text');
//     $body = trim((string)($msg['body'] ?? ''));
//     $cap  = trim((string)($msg['caption'] ?? ''));
//     switch ($type) {
//         case 'image':    return $cap !== '' ? "📷 $cap" : '📷 Photo';
//         case 'video':    return $cap !== '' ? "🎥 $cap" : '🎥 Video';
//         case 'audio':    return '🎤 Voice message';
//         case 'document': return '📄 ' . ($msg['media_filename'] ?: 'Document');
//         case 'sticker':  return 'Sticker';
//         case 'location': return '📍 Location';
//         case 'contacts': return '👤 Contact card';
//         case 'template': return $body !== '' ? $body : 'Template message';
//         default:         return $body !== '' ? $body : ucfirst($type);
//     }
// }

// /* ── webhook ingestion ────────────────────────────────────────────────────────────────── */

// /**
//  * Pulls inbound messages, and status updates for OUR replies, out of a Meta webhook payload.
//  *
//  * Only Meta's documented Cloud API shape is walked here — entry[].changes[].value — rather than
//  * the tolerant recursive search webhook.php uses for campaign statuses. Inbound messages carry
//  * real content that has to be stored exactly, and a fuzzy walker that guessed wrong would write
//  * a garbled conversation rather than simply miss a counter.
//  *
//  * @return array{messages:int, statuses:int, clicks:int}
//  */
// function wa_ingest_webhook(array $payload): array {
//     global $conn;
//     $messages = 0; $statuses = 0; $clicks = 0; $clickEvents = 0;

//     foreach (($payload['entry'] ?? []) as $entry) {
//         foreach (($entry['changes'] ?? []) as $change) {
//             if (($change['field'] ?? '') !== 'messages') continue;
//             $value = $change['value'] ?? [];
//             if (!is_array($value)) continue;

//             $phoneNumberId = (string)($value['metadata']['phone_number_id'] ?? '');

//             // contacts[] runs parallel to messages[]: wa_id → the name the contact set on their
//             // own WhatsApp profile.
//             $names = [];
//             foreach (($value['contacts'] ?? []) as $c) {
//                 $wid = (string)($c['wa_id'] ?? '');
//                 if ($wid !== '') $names[$wid] = (string)($c['profile']['name'] ?? '');
//             }

//             foreach (($value['messages'] ?? []) as $m) {
//                 if (wa_store_inbound_message($m, $phoneNumberId, $names)) $messages++;
//             }

//             foreach (($value['statuses'] ?? []) as $st) {
//                 if (wa_apply_message_status($st)) $statuses++;
//             }

//             // `seen` is tracked separately from `applied` so the caller can tell "recognized but
//             // not ours" from "unparseable" — otherwise a click we deliberately declined to credit
//             // still counts as an unknown payload and gets dumped into the log in full.
//             $ua = wa_apply_user_actions($value);
//             $clicks     += $ua['applied'];
//             $clickEvents += $ua['seen'];
//         }
//     }
//     return ['messages' => $messages, 'statuses' => $statuses, 'clicks' => $clicks, 'click_events' => $clickEvents];
// }

// /**
//  * Link taps inside a marketing message, which Meta reports as `user_actions` on the change
//  * rather than as a status:
//  *
//  *   value.user_actions[] = { timestamp, action_type: "marketing_messages_link_click",
//  *                            marketing_messages_link_click_data: { tracking_token } }
//  *
//  * Worth handling for two reasons. It is the ONLY signal Meta gives for a URL button being
//  * clicked — quick-reply taps arrive as inbound messages, URL taps arrive only here. And left
//  * unparsed it was falling through to the "no recognizable events" branch, which dumps 400
//  * characters of raw JSON into the log on every single click.
//  *
//  * Attribution is best-effort: the payload identifies the tap by a tracking_token, not by a
//  * message id or a phone number, so a click can only be credited when the payload happens to
//  * carry a recipient. Uncreditable clicks are counted and logged rather than guessed at — a
//  * click column that silently invents numbers is worse than one that undercounts.
//  */
// function wa_apply_user_actions(array $value): array {
//     global $conn;
//     $actions = $value['user_actions'] ?? [];
//     if (!is_array($actions) || !$actions) return ['applied' => 0, 'seen' => 0];

//     $applied = 0;
//     $seen = 0;

//     foreach ($actions as $a) {
//         if (!is_array($a)) continue;
//         if (($a['action_type'] ?? '') !== 'marketing_messages_link_click') continue;
//         $seen++;

//         // Whichever identifier this payload version happens to carry.
//         $who = null;
//         foreach (['recipient_id', 'wa_id', 'from', 'phone_number', 'recipient'] as $k) {
//             if (!empty($a[$k]) && (is_string($a[$k]) || is_numeric($a[$k]))) { $who = (string)$a[$k]; break; }
//         }
//         if ($who === null) continue;

//         $phone = wa_normalize_phone($who, wa_default_cc());
//         if ($phone === null) continue;

//         // Only OUR campaigns, and only recently — a tap on a message some other app on this WABA
//         // sent must never inflate one of our campaigns.
//         $r = $conn->query("SELECT id, campaign_id FROM wa_campaign_recipients
//                             WHERE phone='" . $conn->real_escape_string($phone) . "'
//                               AND is_test=0 AND sent_at IS NOT NULL
//                               AND sent_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)
//                             ORDER BY sent_at DESC LIMIT 1");
//         $rec = $r ? $r->fetch_assoc() : null;
//         if (!$rec) continue;

//         $rid = (int)$rec['id']; $cid = (int)$rec['campaign_id'];
//         $conn->query("UPDATE wa_campaign_recipients SET click_count = click_count + 1 WHERE id=$rid");
//         $conn->query("UPDATE wa_campaigns SET click_count = click_count + 1 WHERE id=$cid");
//         wa_record_event($cid, $rid, 'button_click', null, 'marketing message link click');
//         $applied++;
//     }

//     if ($seen > 0 && $applied === 0) {
//         // One short line instead of a 400-character JSON dump. Almost always another app's
//         // traffic on a shared WABA, which is expected and uninteresting.
//         $num = (string)($value['metadata']['display_phone_number'] ?? 'unknown number');
//         wa_log("webhook: $seen marketing link click(s) on $num — not matched to any of our campaigns");
//     }
//     return ['applied' => $applied, 'seen' => $seen];
// }

// /** One inbound message → one wa_messages row. Returns false when it was a duplicate re-delivery. */
// function wa_store_inbound_message(array $m, string $phoneNumberId, array $names): bool {
//     global $conn;

//     $wamid = (string)($m['id'] ?? '');
//     $from  = (string)($m['from'] ?? '');
//     if ($from === '') return false;

//     $phone = wa_normalize_phone($from, wa_default_cc()) ?: preg_replace('/\D+/', '', $from);
//     $conv  = wa_conversation_upsert($phone, $phoneNumberId, $names[$from] ?? null);
//     if (!$conv) return false;

//     $type = (string)($m['type'] ?? 'text');
//     $ts   = isset($m['timestamp']) ? date('Y-m-d H:i:s', (int)$m['timestamp']) : date('Y-m-d H:i:s');

//     $row = [
//         'msg_type'   => $type,
//         'body'       => null,
//         'caption'    => null,
//         'media_id'   => null,
//         'media_mime' => null,
//         'media_filename' => null,
//         'media_size' => null,
//         'created_at' => $ts,
//     ];

//     switch ($type) {
//         case 'text':
//             $row['body'] = (string)($m['text']['body'] ?? '');
//             break;
//         case 'image': case 'video': case 'audio': case 'document': case 'sticker':
//             $node = $m[$type] ?? [];
//             $row['media_id']       = (string)($node['id'] ?? '');
//             $row['media_mime']     = (string)($node['mime_type'] ?? '');
//             $row['media_filename'] = (string)($node['filename'] ?? '');
//             $row['caption']        = (string)($node['caption'] ?? '');
//             break;
//         case 'button':
//             // Tapping a quick-reply button on a template arrives as its own message.
//             $row['body'] = (string)($m['button']['text'] ?? '');
//             break;
//         case 'interactive':
//             $i = $m['interactive'] ?? [];
//             $row['body'] = (string)($i['button_reply']['title'] ?? ($i['list_reply']['title'] ?? ''));
//             break;
//         case 'location':
//             $l = $m['location'] ?? [];
//             $row['body'] = trim(($l['name'] ?? '') . ' ' . ($l['address'] ?? '')) ?: (($l['latitude'] ?? '') . ',' . ($l['longitude'] ?? ''));
//             break;
//         case 'contacts':
//             $row['body'] = (string)($m['contacts'][0]['name']['formatted_name'] ?? 'Contact');
//             break;
//         default:
//             // Reactions, orders, system messages, anything Meta adds later. Stored as a
//             // placeholder rather than dropped, so the thread doesn't develop silent gaps.
//             $row['body'] = (string)($m[$type]['body'] ?? ucfirst($type) . ' message');
//     }

//     $esc = fn($v) => $v === null || $v === '' ? 'NULL' : "'" . $GLOBALS['conn']->real_escape_string((string)$v) . "'";
//     $ctx = (string)($m['context']['id'] ?? '');

//     $conn->query("INSERT INTO wa_messages
//         (conversation_id, direction, wa_message_id, msg_type, body, caption, media_id, media_mime,
//          media_filename, context_wamid, status, created_at)
//         VALUES (" . (int)$conv['id'] . ", 'in', " . $esc($wamid) . ", " . $esc($row['msg_type']) . ", "
//         . $esc($row['body']) . ", " . $esc($row['caption']) . ", " . $esc($row['media_id']) . ", "
//         . $esc($row['media_mime']) . ", " . $esc($row['media_filename']) . ", " . $esc($ctx) . ", "
//         . "'received', '" . $conn->real_escape_string($row['created_at']) . "')
//         ON DUPLICATE KEY UPDATE wa_message_id = wa_message_id");

//     // affected_rows is 0 when the ON DUPLICATE branch fired — i.e. Meta re-delivered a webhook
//     // we already stored. Nothing further should happen, or the unread badge would climb on
//     // every retry.
//     if ($conn->affected_rows === 0) return false;

//     wa_conversation_touch((int)$conv['id'], $row, true);

//     /*
//      * A reply is also a campaign signal.
//      *
//      * Tapping a QUICK-REPLY button on a template arrives here as an ordinary inbound message of
//      * type 'button' (or 'interactive' for a list/button reply) — there is no separate click
//      * webhook. So this is the only place a click can be counted, and without it the campaign
//      * report's click column stays at zero forever.
//      *
//      * URL buttons are a different story: Meta does not report taps on them at all, through any
//      * webhook field. If click-through on a link matters, the link has to carry its own tracking
//      * (a redirect through the panel), not rely on WhatsApp.
//      */
//     $isTap = in_array($type, ['button', 'interactive'], true);
//     wa_credit_reply_to_campaign($phone, (string)($m['context']['id'] ?? ''), $isTap);

//     // A keyword reply is a consent instruction, not conversation. Handled last so the message is
//     // already stored and visible in the thread — an admin has to be able to see WHY someone
//     // stopped receiving messages, not just that they did.
//     wa_apply_keyword_consent($phone, (string)($row['body'] ?? ''));
//     return true;
// }

// /*
//  * The opt-out keywords WhatsApp users actually type.
//  *
//  * Anchored to the start and required to be the whole message (give or take punctuation): a reply
//  * of "stop" is an instruction, but "please don't stop the batch" is not, and blocking that person
//  * would be both wrong and invisible. Meta's own recommended set is STOP/UNSUBSCRIBE/CANCEL/END/
//  * QUIT, and Indian users very commonly send the Hindi equivalents, so those are here too.
//  */
// const WA_STOP_KEYWORDS  = ['stop', 'unsubscribe', 'unsub', 'optout', 'opt out', 'opt-out', 'cancel',
//                            'end', 'quit', 'remove me', 'do not message', 'dont message', 'band karo',
//                            'band karo message', 'mat bhejo', 'rok do'];
// /** The way back in. Without this an opt-out is permanent and only an admin can undo it. */
// const WA_START_KEYWORDS = ['start', 'unstop', 'resume', 'subscribe', 'optin', 'opt in', 'opt-in', 'yes'];

// /**
//  * Applies STOP / START keywords found in an inbound message.
//  *
//  * The suppression itself is wa_optins — the same table campaign sending already consults
//  * (wa_optin_map in WaSendWorker), so a STOP takes effect on the very next campaign without any
//  * other code needing to know this happened. `reason` and `blocked_at` are written alongside so
//  * the Blocklist screen can show what the person actually said and when.
//  */
// function wa_apply_keyword_consent(string $phone, string $body): void {
//     $norm = strtolower(trim(preg_replace('/[\s\p{P}]+/u', ' ', $body) ?? ''));
//     if ($norm === '') return;

//     foreach (WA_STOP_KEYWORDS as $kw) {
//         if ($norm === $kw) {
//             wa_record_optin($phone, 'optout', 'REPLY', 'Replied "' . mb_substr(trim($body), 0, 120) . '" on WhatsApp');
//             wa_log("inbox: $phone opted out via keyword reply — blocklisted for WhatsApp");
//             return;
//         }
//     }
//     foreach (WA_START_KEYWORDS as $kw) {
//         if ($norm === $kw) {
//             wa_record_optin($phone, 'optin', 'REPLY', 'Replied "' . mb_substr(trim($body), 0, 120) . '" on WhatsApp');
//             wa_log("inbox: $phone opted back in via keyword reply");
//             return;
//         }
//     }
// }

// /**
//  * Counts an inbound message as a reply against the campaign that prompted it.
//  *
//  * When WhatsApp gives us a context id (the contact used the reply-quote), that identifies the
//  * exact campaign message. Otherwise the most recent campaign message to that number inside the
//  * last 24 hours is the only reasonable attribution — beyond that window the connection is a
//  * guess, so nothing is credited rather than inflating a campaign's reply count.
//  */
// function wa_credit_reply_to_campaign(string $phone, string $contextWamid, bool $isButtonTap = false): void {
//     global $conn;
//     $p = $conn->real_escape_string($phone);

//     $rec = null;
//     if ($contextWamid !== '') {
//         $r = $conn->query("SELECT id, campaign_id FROM wa_campaign_recipients
//                             WHERE wa_message_id='" . $conn->real_escape_string($contextWamid) . "' LIMIT 1");
//         $rec = $r ? $r->fetch_assoc() : null;
//     }
//     if (!$rec) {
//         $r = $conn->query("SELECT id, campaign_id FROM wa_campaign_recipients
//                             WHERE phone='$p' AND is_test=0 AND sent_at IS NOT NULL
//                               AND sent_at >= DATE_SUB(NOW(), INTERVAL 24 HOUR)
//                             ORDER BY sent_at DESC LIMIT 1");
//         $rec = $r ? $r->fetch_assoc() : null;
//     }
//     if (!$rec) return;

//     $cid = (int)$rec['campaign_id'];
//     $rid = (int)$rec['id'];

//     $conn->query("UPDATE wa_campaigns SET reply_count = reply_count + 1 WHERE id=$cid");
//     wa_record_event($cid, $rid, 'replied');

//     if ($isButtonTap) {
//         $conn->query("UPDATE wa_campaign_recipients SET click_count = click_count + 1 WHERE id=$rid");
//         $conn->query("UPDATE wa_campaigns SET click_count = click_count + 1 WHERE id=$cid");
//         wa_record_event($cid, $rid, 'button_click');
//     }
// }

// /**
//  * Applies a Meta status webhook to a manual reply we sent from this inbox.
//  *
//  * Campaign messages are handled by webhook.php's own correlation pass; this one only ever
//  * touches wa_messages, and returns false for an id it doesn't own so the two never fight over
//  * the same row.
//  */
// function wa_apply_message_status(array $st): bool {
//     global $conn;
//     $id     = (string)($st['id'] ?? '');
//     $status = strtolower((string)($st['status'] ?? ''));
//     if ($id === '' || $status === '') return false;

//     $r = $conn->query("SELECT id, status FROM wa_messages
//                         WHERE wa_message_id='" . $conn->real_escape_string($id) . "' AND direction='out' LIMIT 1");
//     $row = $r ? $r->fetch_assoc() : null;
//     if (!$row) return false;

//     // Same forward-only rule as the campaign path: WhatsApp does not order its webhooks, and a
//     // late "delivered" must never demote a "read" that already landed.
//     $rank = ['pending' => 0, 'sent' => 1, 'delivered' => 2, 'read' => 3];
//     $mid  = (int)$row['id'];

//     if ($status === 'failed') {
//         $e = $st['errors'][0] ?? [];
//         $msg = $e['error_data']['details'] ?? ($e['title'] ?? 'Failed');
//         $conn->query("UPDATE wa_messages SET status='failed',
//                              error_code='" . $conn->real_escape_string((string)($e['code'] ?? '')) . "',
//                              error_message='" . $conn->real_escape_string(mb_substr((string)$msg, 0, 480)) . "'
//                        WHERE id=$mid");
//         return true;
//     }
//     if (!isset($rank[$status])) return false;
//     if (($rank[$status] ?? 0) <= ($rank[$row['status']] ?? 0)) return false;

//     $col = $status === 'read' ? ", read_at=NOW()" : ($status === 'delivered' ? ", delivered_at=NOW()" : '');
//     $conn->query("UPDATE wa_messages SET status='$status'$col WHERE id=$mid");
//     return true;
// }

// /* ── outbound ─────────────────────────────────────────────────────────────────────────── */

// /** The sending number a conversation replies through: the one it arrived on, else the default. */
// function wa_conversation_sender(array $conv): ?array {
//     global $conn;
//     if (!empty($conv['phone_number_id'])) {
//         $r = $conn->query("SELECT * FROM wa_senders
//                             WHERE phone_number_id='" . $conn->real_escape_string($conv['phone_number_id']) . "' LIMIT 1");
//         $row = $r ? $r->fetch_assoc() : null;
//         if ($row) return $row;
//     }
//     return wa_sender_by_id(isset($conv['sender_id']) ? (int)$conv['sender_id'] : null) ?: wa_default_sender();
// }

// /** Is the free-form window still open? Everything outside it must be a template. */
// function wa_window_open(array $conv): bool {
//     $exp = $conv['window_expires_at'] ?? null;
//     return $exp !== null && strtotime((string)$exp) > time();
// }

// /**
//  * Translates a Meta-shaped message object into the transport-neutral `content` shape that
//  * NetcoreTransport::buildRequest() understands.
//  *
//  * The inbox was written against Meta's Cloud API and speaks its message objects everywhere
//  * (`['type'=>'text','text'=>['body'=>…]]`). Netcore wants a flatter shape and disagrees on the
//  * name of nearly every field. Rather than rewrite every caller, the translation happens once
//  * here — callers keep building Meta objects, and this decides what the BSP is handed.
//  *
//  * `error` is non-null when the message cannot cross to Netcore at all, so the caller can say why
//  * instead of sending something the BSP will quietly drop.
//  *
//  * @return array{content: array, error: ?string}
//  */
// function wa_netcore_content_from_meta(array $content, array $local): array {
//     $type = (string)($content['type'] ?? 'text');

//     if ($type === 'text') {
//         return ['content' => [
//             'type'        => 'text',
//             'body'        => (string)($content['text']['body'] ?? ''),
//             'preview_url' => !empty($content['text']['preview_url']),
//         ], 'error' => null];
//     }

//     if ($type === 'template') {
//         $t    = $content['template'] ?? [];
//         $comp = $t['components'] ?? [];
//         return ['content' => [
//             'type'     => 'template',
//             'name'     => (string)($t['name'] ?? ''),
//             'language' => (string)($t['language']['code'] ?? 'en'),
//             // Netcore takes the body's parameters as one flat list in template order; the
//             // components[] Meta was given carry the same values nested one level deeper.
//             'attributes'       => wa_flatten_components_to_attributes($comp),
//             'buttons'          => wa_flatten_components_to_buttons($comp),
//             'header_type'      => (string)($local['header_type'] ?? 'none'),
//             'header_media_url' => (string)($local['header_media_url'] ?? ''),
//         ], 'error' => null];
//     }

//     /*
//      * Media. The two routes address a file in completely different ways: Meta takes a media id
//      * that was uploaded to the sending number, Netcore fetches a URL itself. A Meta media id is
//      * meaningless to Netcore, so the local copy is published under a signed, expiring URL and
//      * that is what goes out.
//      */
//     if (in_array($type, ['image', 'video', 'document', 'audio'], true)) {
//         $url = wa_public_media_url($local);
//         if ($url === null) {
//             return ['content' => [], 'error' =>
//                 'This number sends through Netcore, which fetches attachments by URL — but the local '
//                 . 'copy of this file could not be published. Send the file as a link in a text message instead.'];
//         }
//         $block = ['type' => $type, 'url' => $url];
//         $cap   = trim((string)($local['caption'] ?? ''));
//         // Audio carries no caption; sending one is rejected.
//         if ($cap !== '' && $type !== 'audio') $block['caption'] = $cap;
//         if ($type === 'document' && !empty($local['media_filename'])) $block['filename'] = (string)$local['media_filename'];
//         return ['content' => ['type' => 'media', 'media' => $block], 'error' => null];
//     }

//     return ['content' => [], 'error' => "Message type '$type' cannot be sent through Netcore."];
// }

// /** components[] → the flat body-parameter list Netcore calls `attributes`. */
// function wa_flatten_components_to_attributes(array $components): array {
//     $out = [];
//     foreach ($components as $c) {
//         if (strtolower((string)($c['type'] ?? '')) !== 'body') continue;
//         foreach (($c['parameters'] ?? []) as $p) {
//             if (($p['type'] ?? '') === 'text') $out[] = (string)($p['text'] ?? '');
//         }
//     }
//     return $out;
// }

// /** components[] → Netcore's separate `buttons` block. Mixing these into attributes is error 132000. */
// function wa_flatten_components_to_buttons(array $components): array {
//     $out = [];
//     foreach ($components as $c) {
//         if (strtolower((string)($c['type'] ?? '')) !== 'button') continue;
//         $vals = [];
//         foreach (($c['parameters'] ?? []) as $p) $vals[] = (string)($p['text'] ?? ($p['payload'] ?? ''));
//         $out[] = [
//             'index'      => (string)($c['index'] ?? '0'),
//             'sub_type'   => (string)($c['sub_type'] ?? 'url'),
//             'attributes' => $vals,
//         ];
//     }
//     return $out;
// }

// /**
//  * A URL Netcore's servers can fetch this attachment from.
//  *
//  * Netcore pulls the file itself, with no session, so it has to be reachable without the panel's
//  * JWT. Two shapes, depending on where the bytes are:
//  *
//  *   S3 (everything since the move)  the object URL, handed over directly. Publishing a file the
//  *                                   panel is deliberately sending out is the point of the call,
//  *                                   and it saves this server proxying every attachment byte to
//  *                                   a BSP that is only going to fetch it once.
//  *   local (pre-move files)          the old signed, expiring proxy link, kept so a conversation
//  *                                   with older media still sends. The HMAC covers the filename
//  *                                   and an expiry, so the cache directory stays un-enumerable
//  *                                   and a leaked link is dead within the hour.
//  *
//  * Takes the whole message row rather than a filename, because "where is this file" is now a
//  * question only the row can answer.
//  */
// function wa_public_media_url(array $msg): ?string {
//     $s3 = trim((string)($msg['media_s3_url'] ?? ''));
//     if ($s3 !== '') return $s3;

//     $localName = basename(trim((string)($msg['local_path'] ?? '')));
//     if ($localName === '' || !is_file(wa_media_dir() . '/' . $localName)) return null;

//     $exp = time() + 3600;
//     $sig = hash_hmac('sha256', $localName . '|' . $exp, WA_CRON_SECRET);
//     return 'https://' . WA_WORKER_HOST . rtrim(dirname(WA_WORKER_PATH), '/') . '/media-public.php'
//          . '?f=' . rawurlencode($localName) . '&e=' . $exp . '&s=' . $sig;
// }

// /**
//  * Sends one message on whichever route this conversation's number actually uses, and records it.
//  *
//  * This was Meta-only, which meant every reply typed into Live Chat failed on a Netcore-routed
//  * number: it demanded a Meta access token and a phone_number_id, neither of which a BSP number
//  * has, so the composer answered "No Meta access token configured" no matter what was typed —
//  * and since our WABA is reachable only through Netcore's app, that was every number. Campaigns
//  * had always picked their transport per sending number (wa_transport_for_sender); the inbox now
//  * does the same, so both halves of the channel agree on how a given number sends.
//  *
//  * @param array $content Meta's message object minus the envelope, e.g.
//  *                       ['type'=>'text','text'=>['body'=>'hi']]
//  * @return array{ok:bool, error:?string, message:?array}
//  */
// function wa_inbox_send(array $conv, array $content, array $local, ?int $sentBy): array {
//     $sender   = wa_conversation_sender($conv);
//     $settings = wa_settings_row() ?: [];

//     // Every early return records the attempt too — a reply that vanished with only a toast to
//     // show for it is unauditable, and the thread is the one place anyone looks for what was said.
//     $fail = function (string $err, ?string $code = 'unconfigured') use ($conv, $local, $sentBy): array {
//         wa_inbox_record_out($conv, $local, $sentBy, null, 'failed', $code, $err);
//         return ['ok' => false, 'error' => $err, 'message' => null];
//     };

//     if (!$sender) return $fail('This conversation has no sending number configured — add one in WhatsApp → Settings.');

//     $provider  = wa_resolve_provider($sender);
//     $transport = wa_transport_for_sender($settings, $sender, null);
//     if (!$transport->isConfigured()) {
//         return $fail($provider === 'netcore'
//             ? 'This number sends through Netcore but has no API key — add it in WhatsApp → Settings → Sending numbers → Edit.'
//             : 'This number sends through Meta but is missing its access token or phone number ID — check WhatsApp → Settings.');
//     }

//     $outbound = $content;
//     if ($provider === 'netcore') {
//         $t = wa_netcore_content_from_meta($content, $local);
//         if ($t['error'] !== null) return $fail($t['error'], 'unsupported');
//         $outbound = $t['content'];
//     }

//     // The correlation id. Netcore echoes it as x-apiheader on webhooks; Meta ignores it and
//     // returns a wamid instead, which is what gets stored when it comes back.
//     $rid = 'inbox' . $conv['id'] . '_' . bin2hex(random_bytes(6));
//     $res = $transport->sendMessage((string)$conv['phone'], $outbound, $rid);

//     if (empty($res['ok'])) {
//         wa_inbox_record_out($conv, $local, $sentBy, null, 'failed',
//             (string)($res['code'] ?? ''), (string)($res['error'] ?? 'Send failed'));
//         wa_log('inbox: reply to ' . $conv['phone'] . ' via ' . strtoupper($provider) . ' FAILED — ' . ($res['error'] ?? '?'));
//         return ['ok' => false, 'error' => $res['error'] ?: 'Could not send', 'message' => null];
//     }

//     $msg = wa_inbox_record_out($conv, $local, $sentBy, (string)($res['message_id'] ?? $rid), 'sent', null, null);
//     wa_conversation_touch((int)$conv['id'], array_merge($local, ['created_at' => date('Y-m-d H:i:s')]), false);
//     return ['ok' => true, 'error' => null, 'message' => $msg];
// }

// /** Writes the outbound row — one INSERT shared by the success and failure paths. */
// function wa_inbox_record_out(array $conv, array $local, ?int $sentBy, ?string $wamid,
//                              string $status, ?string $errCode, ?string $errMsg): ?array {
//     global $conn;
//     $esc = fn($v) => $v === null || $v === '' ? 'NULL' : "'" . $GLOBALS['conn']->real_escape_string((string)$v) . "'";
//     $now = date('Y-m-d H:i:s');

//     $conn->query("INSERT INTO wa_messages
//         (conversation_id, direction, wa_message_id, msg_type, body, caption, media_id, media_mime,
//          media_filename, local_path, template_name, status, error_code, error_message, sent_by, created_at)
//         VALUES (" . (int)$conv['id'] . ", 'out', " . $esc($wamid) . ", " . $esc($local['msg_type'] ?? 'text') . ", "
//         . $esc($local['body'] ?? null) . ", " . $esc($local['caption'] ?? null) . ", "
//         . $esc($local['media_id'] ?? null) . ", " . $esc($local['media_mime'] ?? null) . ", "
//         . $esc($local['media_filename'] ?? null) . ", " . $esc($local['local_path'] ?? null) . ", "
//         . $esc($local['template_name'] ?? null) . ", " . $esc($status) . ", "
//         . $esc($errCode) . ", " . $esc($errMsg === null ? null : mb_substr($errMsg, 0, 480)) . ", "
//         . ($sentBy ? (int)$sentBy : 'NULL') . ", '$now')");

//     $newId = (int)$conn->insert_id;
//     if (!$newId) return null;
//     $r = $conn->query("SELECT * FROM wa_messages WHERE id=$newId LIMIT 1");
//     return $r ? $r->fetch_assoc() : null;
// }

// /**
//  * Tells WhatsApp the contact's messages have been seen, so THEY see the blue ticks.
//  *
//  * Best-effort by design: an admin opening a thread must not be blocked, or shown an error, over
//  * a read receipt. A stale wamid (older than 30 days) is the normal failure and is uninteresting.
//  */
// function wa_mark_read_upstream(array $conv): void {
//     global $conn;
//     $sender = wa_conversation_sender($conv);
//     $pni    = trim((string)($sender['phone_number_id'] ?? ''));
//     $token  = wa_meta_token();
//     if ($pni === '' || $token === '') return;

//     $r = $conn->query("SELECT wa_message_id FROM wa_messages
//                         WHERE conversation_id=" . (int)$conv['id'] . " AND direction='in' AND wa_message_id IS NOT NULL
//                         ORDER BY id DESC LIMIT 1");
//     $row = $r ? $r->fetch_assoc() : null;
//     if (!$row) return;

//     wa_graph_call('POST', WA_GRAPH_BASE . WA_GRAPH_VERSION . "/$pni/messages", $token, [
//         'messaging_product' => 'whatsapp',
//         'status'            => 'read',
//         'message_id'        => $row['wa_message_id'],
//     ], 8);
// }

// /* ── media ────────────────────────────────────────────────────────────────────────────── */

// /*
//  * ── Where WhatsApp media lives, and why it moved ──────────────────────────────────────
//  *
//  * It used to live on this server, in api/whatsapp/media/, one file per attachment, forever.
//  * That is a cPanel disk quota filling up with student photographs at 500 KB apiece and never
//  * being emptied — and the same host also serves the panel, so when it fills, everything stops.
//  * Media is also the one thing here that genuinely cannot be regenerated: Meta deletes it after
//  * 30 days, so our copy is the only copy, and "the only copy" does not belong on the box most
//  * likely to run out of room.
//  *
//  * So the bytes go to S3 — the same bucket the contact-import CSVs and campaign attachments
//  * already use — and the database keeps only the key and the URL. Nothing is written to local
//  * disk permanently: the download from Meta lands in the system temp directory, is uploaded,
//  * and is deleted in the same request.
//  *
//  * ── The one thing that did NOT change ────────────────────────────────────────────────
//  * Panel viewing still goes through the authenticated proxy (wa_inbox.php?action=media), which
//  * now streams from S3 instead of from disk. It would have been cheaper to redirect the browser
//  * to the S3 URL, and that is deliberately not done: inbound media is whatever a student chose
//  * to send — ID cards, fee receipts, screenshots of their own documents — and a redirect hands
//  * out a permanent, unauthenticated URL to it. The proxy costs bandwidth; handing out that URL
//  * costs a good deal more.
//  *
//  * The Netcore send path is the exception, and has to be: their servers fetch the attachment
//  * themselves, with no session, so an outbound file's S3 URL is what goes out. That is a file
//  * this panel is deliberately publishing, which is a different thing from one a student sent in.
//  */

// require_once __DIR__ . '/../../lib/S3Uploader.php';

// /** Where in the bucket WhatsApp media lives. */
// if (!defined('WA_S3_PREFIX')) define('WA_S3_PREFIX', 'whatsapp_media');

// /**
//  * Legacy local cache directory.
//  *
//  * Kept only so media downloaded before the move to S3 still opens. Nothing writes here any
//  * more — wa_media_fetch() uploads and stores a reference instead — and once the old files have
//  * aged out the directory and this function can go.
//  */
// function wa_media_dir(): string {
//     if (!is_dir(WA_MEDIA_DIR)) @mkdir(WA_MEDIA_DIR, 0775, true);
//     $ht = WA_MEDIA_DIR . '/.htaccess';
//     if (!file_exists($ht)) @file_put_contents($ht, "Deny from all\n");
//     return WA_MEDIA_DIR;
// }

// /** True when wa_media_fetch() handed back an S3 URL rather than a path on this disk. */
// function wa_media_is_remote(?string $source): bool {
//     return $source !== null && str_starts_with($source, 'http');
// }

// /**
//  * Returns [source, mime, error] for a message's media, fetching it from Meta on first use.
//  *
//  * `source` is an S3 URL for anything stored since the move, and an absolute local path for the
//  * files that predate it. Callers decide what to do with each — see wa_media_is_remote().
//  *
//  * Two round trips are required against Meta and both need the token: GET /{media_id} returns a
//  * short-lived (~5 min) signed URL, and that URL still refuses an unauthenticated fetch. The
//  * result is stored because the download is the slow part and because Meta drops the media after
//  * 30 days — after which our copy is the only one there is.
//  *
//  * @return array{0:?string,1:string,2:?string} source, mime, error
//  */
// function wa_media_fetch(array $msg): array {
//     global $conn;

//     // Already on S3 — the normal case after the first view.
//     $s3Url = trim((string)($msg['media_s3_url'] ?? ''));
//     if ($s3Url !== '') return [$s3Url, (string)($msg['media_mime'] ?: 'application/octet-stream'), null];

//     // Downloaded before the move. Served from disk, and not re-uploaded: migrating old files is
//     // a one-off job, not something to do inside a request somebody is waiting on.
//     $cached = trim((string)($msg['local_path'] ?? ''));
//     if ($cached !== '') {
//         $abs = wa_media_dir() . '/' . basename($cached);
//         if (is_file($abs)) return [$abs, (string)($msg['media_mime'] ?: 'application/octet-stream'), null];
//     }

//     $mediaId = trim((string)($msg['media_id'] ?? ''));
//     if ($mediaId === '') return [null, '', 'This message has no media'];

//     $token = wa_meta_token();
//     if ($token === '') return [null, '', 'No Meta access token configured'];

//     $meta = wa_graph_call('GET', WA_GRAPH_BASE . WA_GRAPH_VERSION . '/' . rawurlencode($mediaId), $token, null, 15);
//     if (!$meta['ok']) {
//         return [null, '', 'Meta would not return this media: ' . $meta['error']
//             . ' (media is deleted after ' . WA_MEDIA_RETENTION_DAYS . ' days)'];
//     }

//     $url  = (string)($meta['data']['url'] ?? '');
//     $mime = (string)($meta['data']['mime_type'] ?? ($msg['media_mime'] ?: 'application/octet-stream'));
//     if ($url === '') return [null, '', 'Meta returned no download URL'];

//     /*
//      * Straight to a temp file rather than into memory: a 16 MB video read into a PHP string
//      * would blow past memory_limit on shared hosting, and s3_upload_file() wants a path anyway.
//      */
//     $tmp = tempnam(sys_get_temp_dir(), 'wamedia_');
//     if ($tmp === false) return [null, $mime, 'Could not open a temporary file for the download'];

//     $fh = @fopen($tmp, 'wb');
//     if (!$fh) { @unlink($tmp); return [null, $mime, 'Could not open a temporary file for the download']; }

//     $ch = curl_init($url);
//     curl_setopt_array($ch, [
//         CURLOPT_FILE           => $fh,
//         CURLOPT_HTTPHEADER     => ['Authorization: Bearer ' . $token],
//         CURLOPT_TIMEOUT        => 60,
//         CURLOPT_FOLLOWLOCATION => true,
//     ]);
//     $ok     = curl_exec($ch);
//     $status = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
//     curl_close($ch);
//     fclose($fh);

//     if ($ok === false || $status < 200 || $status >= 300) {
//         @unlink($tmp);
//         return [null, $mime, "Download failed (HTTP $status)"];
//     }

//     $size = (int)@filesize($tmp);
//     $ext  = wa_ext_for_mime($mime, (string)($msg['media_filename'] ?? ''));
//     // The message id keeps it traceable; the hash keeps it unguessable, which matters because
//     // the bucket serves over plain HTTPS with no per-object authorisation.
//     $key  = WA_S3_PREFIX . '/' . (int)$msg['id'] . '_' . bin2hex(random_bytes(8)) . $ext;

//     $publicUrl = s3_upload_file($tmp, $key, $mime);
//     @unlink($tmp);   // nothing survives on local disk, which is the entire point of this change

//     if ($publicUrl === null) {
//         // Serving still works without a stored copy — the next view pays for the download again.
//         return [null, $mime, 'Could not upload the media to storage'];
//     }

//     $conn->query("UPDATE wa_messages
//                      SET media_s3_key='" . $conn->real_escape_string($key) . "',
//                          media_s3_url='" . $conn->real_escape_string($publicUrl) . "',
//                          media_mime='"   . $conn->real_escape_string($mime) . "',
//                          media_size=" . $size . "
//                    WHERE id=" . (int)$msg['id']);

//     return [$publicUrl, $mime, null];
// }

// /**
//  * Streams a media source to the browser, from S3 or from the legacy disk cache.
//  *
//  * Kept in one place because the two sources need different plumbing and the caller should not
//  * care: both are read in chunks rather than into a string, so a large video costs the same
//  * memory as a small photo.
//  */
// function wa_media_stream(string $source): bool {
//     $fh = @fopen($source, 'rb');
//     if (!$fh) return false;
//     while (!feof($fh)) {
//         echo fread($fh, 8192);
//         if (connection_aborted()) break;
//         @ob_flush();
//         flush();
//     }
//     fclose($fh);
//     return true;
// }

// /** Content-Length when it can be known cheaply — a local file always, S3 via a HEAD. */
// function wa_media_size(string $source, array $msg): ?int {
//     $known = (int)($msg['media_size'] ?? 0);
//     if ($known > 0) return $known;
//     if (!wa_media_is_remote($source)) {
//         $n = @filesize($source);
//         return $n === false ? null : (int)$n;
//     }
//     return null;
// }

// function wa_ext_for_mime(string $mime, string $filename = ''): string {
//     $known = [
//         'image/jpeg' => '.jpg', 'image/png' => '.png', 'image/webp' => '.webp', 'image/gif' => '.gif',
//         'video/mp4' => '.mp4', 'video/3gpp' => '.3gp',
//         'audio/ogg' => '.ogg', 'audio/mpeg' => '.mp3', 'audio/mp4' => '.m4a', 'audio/amr' => '.amr',
//         'application/pdf' => '.pdf',
//     ];
//     $base = strtok($mime, ';');
//     if (isset($known[$base])) return $known[$base];
//     if ($filename !== '' && preg_match('/(\.[A-Za-z0-9]{1,6})$/', $filename, $m)) return strtolower($m[1]);
//     return '.bin';
// }

// /**
//  * Uploads a local file to Meta and returns its media id.
//  *
//  * Multipart, so it can't go through wa_graph_call() (JSON only). CURLFile is used rather than a
//  * hand-built body because Meta rejects a mismatched boundary with an unhelpful generic error.
//  *
//  * @return array{ok:bool, id:?string, error:?string}
//  */
// function wa_graph_upload_media(string $phoneNumberId, string $path, string $mime, string $filename): array {
//     $token = wa_meta_token();
//     if ($token === '') return ['ok' => false, 'id' => null, 'error' => 'No Meta access token configured'];

//     $ch = curl_init(WA_GRAPH_BASE . WA_GRAPH_VERSION . "/$phoneNumberId/media");
//     curl_setopt_array($ch, [
//         CURLOPT_RETURNTRANSFER => true,
//         CURLOPT_POST           => true,
//         CURLOPT_HTTPHEADER     => ['Authorization: Bearer ' . $token],
//         CURLOPT_TIMEOUT        => 120,
//         CURLOPT_POSTFIELDS     => [
//             'messaging_product' => 'whatsapp',
//             'type'              => $mime,
//             'file'              => new CURLFile($path, $mime, $filename),
//         ],
//     ]);
//     $body   = curl_exec($ch);
//     $status = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
//     $err    = curl_error($ch);
//     curl_close($ch);

//     if ($err !== '') return ['ok' => false, 'id' => null, 'error' => "Upload failed: $err"];
//     $decoded = json_decode((string)$body, true);
//     if ($status < 200 || $status >= 300 || empty($decoded['id'])) {
//         $e = $decoded['error'] ?? [];
//         return ['ok' => false, 'id' => null, 'error' => $e['error_user_msg'] ?? ($e['message'] ?? "Upload failed (HTTP $status)")];
//     }
//     return ['ok' => true, 'id' => (string)$decoded['id'], 'error' => null];
// }

// /**
//  * What WhatsApp accepts, per message type.
//  *
//  * The caps are Meta's own and are enforced here rather than left to the API: a rejected upload
//  * costs a 120-second round trip and returns a generic error, while a local check is instant and
//  * can say exactly which limit was hit.
//  */
// function wa_media_kind(string $mime): array {
//     $mime = strtolower(strtok($mime, ';') ?: '');
//     $sets = [
//         'image'    => ['mimes' => ['image/jpeg', 'image/png'],                          'max' => 5  * 1024 * 1024],
//         'video'    => ['mimes' => ['video/mp4', 'video/3gpp'],                          'max' => 16 * 1024 * 1024],
//         'audio'    => ['mimes' => ['audio/aac', 'audio/mp4', 'audio/mpeg', 'audio/amr', 'audio/ogg'], 'max' => 16 * 1024 * 1024],
//     ];
//     foreach ($sets as $kind => $spec) {
//         if (in_array($mime, $spec['mimes'], true)) return ['kind' => $kind, 'max' => $spec['max'], 'mime' => $mime];
//     }
//     // Everything else rides as a document, which is the broadest type WhatsApp accepts.
//     return ['kind' => 'document', 'max' => 100 * 1024 * 1024, 'mime' => $mime ?: 'application/octet-stream'];
// }























/*
 * Live Chat — the two-way half of the WhatsApp channel.
 *
 * Campaigns are one-way: we send a template and count what comes back as a number. This file
 * backs the other direction — when someone REPLIES to one of those campaign messages, that reply
 * has to land somewhere a human can answer it. That "somewhere" is a conversation.
 *
 * Two concepts do all the work:
 *
 *   wa_conversations   one row per (sending number, contact number). Carries the denormalized
 *                      last-message preview so the inbox list is a single indexed SELECT with no
 *                      joins — with thousands of threads that is the difference between an inbox
 *                      that opens instantly and one that doesn't.
 *
 *   wa_messages        the free-form traffic: every inbound message, and every manual reply an
 *                      admin types here. Campaign sends are deliberately NOT copied in — the
 *                      thread view merges them straight out of wa_campaign_recipients, so there
 *                      is exactly one copy of a campaign message in the database and its
 *                      delivered/read state stays the campaign's own.
 *
 * THE 24-HOUR RULE, because it explains most of this UI:
 * WhatsApp only allows free-form messages inside 24 hours of the contact's last message
 * ("customer service window"). Outside it, Meta rejects anything but an approved template. So
 * every conversation tracks window_expires_at, the composer disables itself when it lapses, and
 * the template picker takes over. Getting this wrong doesn't produce an error an admin would
 * understand — it produces a message that simply never arrives.
 */
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/schema.php';
require_once __DIR__ . '/WaHelpers.php';
require_once __DIR__ . '/WaAudienceResolver.php';
// wa_log() and wa_record_event() live here. webhook.php already pulls it in before this file,
// but the dependency is stated explicitly so including WaInbox.php on its own (a future cron,
// a one-off script) can't fatal on an undefined function.
require_once __DIR__ . '/WaSendWorker.php';

/** Where inbound media is cached after its first fetch. Outside the web root's reach on purpose:
 *  everything is served back through wa_inbox.php so the JWT gate still applies to an image. */
if (!defined('WA_MEDIA_DIR')) define('WA_MEDIA_DIR', __DIR__ . '/../media');

/** Meta keeps inbound media for 30 days; after that the media id 404s and only our cache has it. */
if (!defined('WA_MEDIA_RETENTION_DAYS')) define('WA_MEDIA_RETENTION_DAYS', 30);

/** Bump alongside any change to wa_inbox_ensure_schema(), exactly as with WA_SCHEMA_VERSION. */
if (!defined('WA_INBOX_SCHEMA_VERSION')) define('WA_INBOX_SCHEMA_VERSION', 1);

/** Backstop for forgetting the bump above, for the same reason and in the same way as
 *  WA_SCHEMA_FINGERPRINT in schema.php — see the note there. A missed bump on that constant is
 *  what made creating a WhatsApp campaign fatal on a missing exclude_list_ids column. */
if (!defined('WA_INBOX_SCHEMA_FINGERPRINT')) {
    define('WA_INBOX_SCHEMA_FINGERPRINT', substr((string)@md5_file(__FILE__), 0, 10));
}

/** Stamped and skipped for the same reason as whatsapp_ensure_schema() — webhook.php calls both
 *  on every inbound delivery receipt, and this one creates the conversation/message tables the
 *  live chat needs, which no receipt has ever changed. See the long note over that function. */
function wa_inbox_ensure_schema(bool $force = false): void {
    global $conn;
    if (!$conn) return;

    static $done = false;
    if ($done && !$force) return;

    $stamp = sys_get_temp_dir() . '/wa_inbox_schema_v' . WA_INBOX_SCHEMA_VERSION . '_' . WA_INBOX_SCHEMA_FINGERPRINT . '.ok';
    if (!$force && @is_file($stamp)) { $done = true; return; }

    $done = true;

    try {
        $conn->query("CREATE TABLE IF NOT EXISTS wa_conversations (
            id               BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            phone            VARCHAR(24) NOT NULL,
            phone_number_id  VARCHAR(32) NOT NULL DEFAULT '',
            sender_id        INT DEFAULT NULL,
            waba_id          VARCHAR(64) DEFAULT NULL,

            -- Identity. profile_name is what WhatsApp reports the contact calls themselves;
            -- the rest is matched out of our own records so the panel can show a real person
            -- rather than a bare number.
            profile_name     VARCHAR(255) DEFAULT NULL,
            user_id          BIGINT UNSIGNED DEFAULT NULL,
            first_name       VARCHAR(255) DEFAULT NULL,
            last_name        VARCHAR(255) DEFAULT NULL,
            email            VARCHAR(255) DEFAULT NULL,

            -- Denormalized preview for the list pane.
            last_message_at        DATETIME DEFAULT NULL,
            last_message_text      VARCHAR(500) DEFAULT NULL,
            last_message_direction ENUM('in','out') DEFAULT NULL,
            last_message_type      VARCHAR(24) DEFAULT NULL,
            unread_count           INT NOT NULL DEFAULT 0,

            -- End of the free-form window: last inbound + 24h. NULL means never messaged us.
            window_expires_at DATETIME DEFAULT NULL,
            last_inbound_at   DATETIME DEFAULT NULL,

            -- Which campaign brought this person in — the first one whose message they answered.
            origin_campaign_id INT DEFAULT NULL,

            status      ENUM('open','resolved') NOT NULL DEFAULT 'open',
            is_archived TINYINT(1) NOT NULL DEFAULT 0,
            assigned_to BIGINT UNSIGNED DEFAULT NULL,
            note        VARCHAR(1000) DEFAULT NULL,

            created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

            UNIQUE INDEX uq_number_phone (phone_number_id, phone),
            -- The inbox list's only ORDER BY. Archived rows are filtered first so the index
            -- stays useful for the default view.
            INDEX idx_recent (is_archived, last_message_at),
            INDEX idx_unread (unread_count),
            INDEX idx_phone (phone)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

        $conn->query("CREATE TABLE IF NOT EXISTS wa_messages (
            id              BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            conversation_id BIGINT UNSIGNED NOT NULL,
            direction       ENUM('in','out') NOT NULL,
            wa_message_id   VARCHAR(120) DEFAULT NULL,
            -- Echoed to Meta as nothing; kept so a send can be correlated before the id arrives.
            rid             CHAR(32) DEFAULT NULL,

            msg_type   VARCHAR(24) NOT NULL DEFAULT 'text',
            body       TEXT DEFAULT NULL,
            caption    VARCHAR(1000) DEFAULT NULL,

            -- Media. media_id is Meta's handle (valid ~30 days). The bytes themselves live in
            -- S3 — media_s3_key/media_s3_url — and are the only copy that survives Meta's
            -- retention window. local_path is the pre-S3 disk cache, kept so older messages
            -- still open; nothing writes to it any more (see wa_media_fetch()).
            media_id       VARCHAR(190) DEFAULT NULL,
            media_mime     VARCHAR(120) DEFAULT NULL,
            media_filename VARCHAR(255) DEFAULT NULL,
            media_size     INT DEFAULT NULL,
            local_path     VARCHAR(255) DEFAULT NULL,
            media_s3_key   VARCHAR(400) DEFAULT NULL,
            media_s3_url   VARCHAR(700) DEFAULT NULL,

            template_name VARCHAR(255) DEFAULT NULL,
            -- The message being replied to, when the contact used WhatsApp's reply-quote.
            context_wamid VARCHAR(120) DEFAULT NULL,

            status        ENUM('received','pending','sent','delivered','read','failed') NOT NULL DEFAULT 'received',
            error_code    VARCHAR(64) DEFAULT NULL,
            error_message VARCHAR(500) DEFAULT NULL,

            sent_by    BIGINT UNSIGNED DEFAULT NULL,
            created_at DATETIME NOT NULL,
            delivered_at DATETIME DEFAULT NULL,
            read_at      DATETIME DEFAULT NULL,

            -- Meta re-delivers a webhook it didn't get a 200 for, so the same inbound message
            -- can legitimately arrive several times. This key is what makes ingestion idempotent.
            UNIQUE INDEX uq_wamid (wa_message_id),
            INDEX idx_thread (conversation_id, id),
            INDEX idx_created (created_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

        // Only a clean pass stamps — a half-finished run must be retried, not skipped forever.
        @file_put_contents($stamp, date('c') . " ok\n", LOCK_EX);

        // Clear the stamps earlier builds left behind, so one dead file per deploy doesn't pile up.
        foreach ((array)@glob(sys_get_temp_dir() . '/wa_inbox_schema_v*.ok') as $old) {
            if ($old !== $stamp) @unlink($old);
        }
    } catch (\Throwable $e) {
        error_log('wa_inbox_ensure_schema: ' . $e->getMessage());
    }
}

/* ── identity ─────────────────────────────────────────────────────────────────────────── */

/**
 * Everything we already know about this number, pulled from campaign history.
 *
 * A person who replies to a campaign is by definition someone we messaged, so their name and
 * email are already sitting on the recipient row — no extra lookup against `users` needed, and
 * it works for list-sourced contacts that have no user record at all.
 */
function wa_identity_for_phone(string $phone): array {
    global $conn;
    $p = $conn->real_escape_string($phone);
    $r = $conn->query("SELECT user_id, email, first_name, last_name, campaign_id
                         FROM wa_campaign_recipients
                        WHERE phone='$p'
                        ORDER BY (user_id IS NULL) ASC, id DESC
                        LIMIT 1");
    $row = $r ? $r->fetch_assoc() : null;
    return $row ?: [];
}

/**
 * The conversation for a (sending number, contact) pair, created on first contact.
 *
 * INSERT … ON DUPLICATE KEY is deliberate over SELECT-then-INSERT: webhook deliveries for the
 * same person can arrive concurrently, and the race would otherwise produce two threads for one
 * contact — which looks to an admin like messages randomly going missing.
 */
function wa_conversation_upsert(string $phone, string $phoneNumberId, ?string $profileName = null): ?array {
    global $conn;

    $p   = $conn->real_escape_string($phone);
    $pni = $conn->real_escape_string($phoneNumberId);

    $r = $conn->query("SELECT * FROM wa_conversations WHERE phone_number_id='$pni' AND phone='$p' LIMIT 1");
    $existing = $r ? $r->fetch_assoc() : null;

    if ($existing) {
        // A profile name can change (people rename themselves); keep the latest.
        if ($profileName !== null && $profileName !== '' && $profileName !== $existing['profile_name']) {
            $conn->query("UPDATE wa_conversations SET profile_name='" . $conn->real_escape_string($profileName) . "'
                           WHERE id=" . (int)$existing['id']);
            $existing['profile_name'] = $profileName;
        }
        return $existing;
    }

    $ident = wa_identity_for_phone($phone);
    $sender = null;
    if ($phoneNumberId !== '') {
        $sr = $conn->query("SELECT id, waba_id FROM wa_senders WHERE phone_number_id='$pni' LIMIT 1");
        $sender = $sr ? $sr->fetch_assoc() : null;
    }

    $esc = fn($v) => "'" . $conn->real_escape_string((string)$v) . "'";
    $conn->query("INSERT INTO wa_conversations
        (phone, phone_number_id, sender_id, waba_id, profile_name, user_id, first_name, last_name, email, origin_campaign_id)
        VALUES (" . $esc($phone) . ", " . $esc($phoneNumberId) . ", "
        . (isset($sender['id']) ? (int)$sender['id'] : 'NULL') . ", "
        . $esc($sender['waba_id'] ?? '') . ", " . $esc((string)$profileName) . ", "
        . (!empty($ident['user_id']) ? (int)$ident['user_id'] : 'NULL') . ", "
        . $esc($ident['first_name'] ?? '') . ", " . $esc($ident['last_name'] ?? '') . ", "
        . $esc($ident['email'] ?? '') . ", "
        . (!empty($ident['campaign_id']) ? (int)$ident['campaign_id'] : 'NULL') . ")
        ON DUPLICATE KEY UPDATE updated_at = NOW()");

    $r2 = $conn->query("SELECT * FROM wa_conversations WHERE phone_number_id='$pni' AND phone='$p' LIMIT 1");
    $row = $r2 ? $r2->fetch_assoc() : null;
    return $row ?: null;
}

/** Refreshes the list-pane preview after a message lands. One UPDATE, never a recount. */
function wa_conversation_touch(int $conversationId, array $msg, bool $inbound): void {
    global $conn;

    $preview = wa_message_preview($msg);
    $at      = $msg['created_at'] ?? date('Y-m-d H:i:s');

    $sets = [
        "last_message_at='"        . $conn->real_escape_string($at) . "'",
        "last_message_text='"      . $conn->real_escape_string(mb_substr($preview, 0, 480)) . "'",
        "last_message_direction='" . ($inbound ? 'in' : 'out') . "'",
        "last_message_type='"      . $conn->real_escape_string((string)($msg['msg_type'] ?? 'text')) . "'",
    ];
    if ($inbound) {
        // Every inbound message restarts the 24-hour free-form window, and un-resolves a thread
        // someone had closed — a new question on an old thread is still a new question.
        $sets[] = "unread_count = unread_count + 1";
        $sets[] = "last_inbound_at='" . $conn->real_escape_string($at) . "'";
        $sets[] = "window_expires_at = DATE_ADD('" . $conn->real_escape_string($at) . "', INTERVAL 24 HOUR)";
        $sets[] = "status='open'";
        $sets[] = "is_archived=0";
    }
    $conn->query("UPDATE wa_conversations SET " . implode(', ', $sets) . ' WHERE id=' . (int)$conversationId);
}

/** One line of text for the list pane, whatever the message actually was. */
function wa_message_preview(array $msg): string {
    $type = (string)($msg['msg_type'] ?? 'text');
    $body = trim((string)($msg['body'] ?? ''));
    $cap  = trim((string)($msg['caption'] ?? ''));
    switch ($type) {
        case 'image':    return $cap !== '' ? "📷 $cap" : '📷 Photo';
        case 'video':    return $cap !== '' ? "🎥 $cap" : '🎥 Video';
        case 'audio':    return '🎤 Voice message';
        case 'document': return '📄 ' . ($msg['media_filename'] ?: 'Document');
        case 'sticker':  return 'Sticker';
        case 'location': return '📍 Location';
        case 'contacts': return '👤 Contact card';
        case 'template': return $body !== '' ? $body : 'Template message';
        default:         return $body !== '' ? $body : ucfirst($type);
    }
}

/* ── webhook ingestion ────────────────────────────────────────────────────────────────── */

/**
 * Pulls inbound messages, and status updates for OUR replies, out of a Meta webhook payload.
 *
 * Only Meta's documented Cloud API shape is walked here — entry[].changes[].value — rather than
 * the tolerant recursive search webhook.php uses for campaign statuses. Inbound messages carry
 * real content that has to be stored exactly, and a fuzzy walker that guessed wrong would write
 * a garbled conversation rather than simply miss a counter.
 *
 * @return array{messages:int, statuses:int, clicks:int}
 */
function wa_ingest_webhook(array $payload): array {
    global $conn;
    $messages = 0; $statuses = 0; $clicks = 0; $clickEvents = 0;

    foreach (($payload['entry'] ?? []) as $entry) {
        foreach (($entry['changes'] ?? []) as $change) {
            if (($change['field'] ?? '') !== 'messages') continue;
            $value = $change['value'] ?? [];
            if (!is_array($value)) continue;

            $phoneNumberId = (string)($value['metadata']['phone_number_id'] ?? '');

            // contacts[] runs parallel to messages[]: wa_id → the name the contact set on their
            // own WhatsApp profile.
            $names = [];
            foreach (($value['contacts'] ?? []) as $c) {
                $wid = (string)($c['wa_id'] ?? '');
                if ($wid !== '') $names[$wid] = (string)($c['profile']['name'] ?? '');
            }

            foreach (($value['messages'] ?? []) as $m) {
                if (wa_store_inbound_message($m, $phoneNumberId, $names)) $messages++;
            }

            foreach (($value['statuses'] ?? []) as $st) {
                if (wa_apply_message_status($st)) $statuses++;
            }

            // `seen` is tracked separately from `applied` so the caller can tell "recognized but
            // not ours" from "unparseable" — otherwise a click we deliberately declined to credit
            // still counts as an unknown payload and gets dumped into the log in full.
            $ua = wa_apply_user_actions($value);
            $clicks     += $ua['applied'];
            $clickEvents += $ua['seen'];
        }
    }
    return ['messages' => $messages, 'statuses' => $statuses, 'clicks' => $clicks, 'click_events' => $clickEvents];
}

/**
 * Link taps inside a marketing message, which Meta reports as `user_actions` on the change
 * rather than as a status:
 *
 *   value.user_actions[] = { timestamp, action_type: "marketing_messages_link_click",
 *                            marketing_messages_link_click_data: { tracking_token } }
 *
 * Worth handling for two reasons. It is the ONLY signal Meta gives for a URL button being
 * clicked — quick-reply taps arrive as inbound messages, URL taps arrive only here. And left
 * unparsed it was falling through to the "no recognizable events" branch, which dumps 400
 * characters of raw JSON into the log on every single click.
 *
 * Attribution is best-effort: the payload identifies the tap by a tracking_token, not by a
 * message id or a phone number, so a click can only be credited when the payload happens to
 * carry a recipient. Uncreditable clicks are counted and logged rather than guessed at — a
 * click column that silently invents numbers is worse than one that undercounts.
 */
function wa_apply_user_actions(array $value): array {
    global $conn;
    $actions = $value['user_actions'] ?? [];
    if (!is_array($actions) || !$actions) return ['applied' => 0, 'seen' => 0];

    $applied = 0;
    $seen = 0;

    foreach ($actions as $a) {
        if (!is_array($a)) continue;
        if (($a['action_type'] ?? '') !== 'marketing_messages_link_click') continue;
        $seen++;

        // Whichever identifier this payload version happens to carry.
        $who = null;
        foreach (['recipient_id', 'wa_id', 'from', 'phone_number', 'recipient'] as $k) {
            if (!empty($a[$k]) && (is_string($a[$k]) || is_numeric($a[$k]))) { $who = (string)$a[$k]; break; }
        }
        if ($who === null) continue;

        $phone = wa_normalize_phone($who, wa_default_cc());
        if ($phone === null) continue;

        // Only OUR campaigns, and only recently — a tap on a message some other app on this WABA
        // sent must never inflate one of our campaigns.
        $r = $conn->query("SELECT id, campaign_id FROM wa_campaign_recipients
                            WHERE phone='" . $conn->real_escape_string($phone) . "'
                              AND is_test=0 AND sent_at IS NOT NULL
                              AND sent_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)
                            ORDER BY sent_at DESC LIMIT 1");
        $rec = $r ? $r->fetch_assoc() : null;
        if (!$rec) continue;

        $rid = (int)$rec['id']; $cid = (int)$rec['campaign_id'];
        $conn->query("UPDATE wa_campaign_recipients SET click_count = click_count + 1 WHERE id=$rid");
        $conn->query("UPDATE wa_campaigns SET click_count = click_count + 1 WHERE id=$cid");
        wa_record_event($cid, $rid, 'button_click', null, 'marketing message link click');
        $applied++;
    }

    if ($seen > 0 && $applied === 0) {
        // One short line instead of a 400-character JSON dump. Almost always another app's
        // traffic on a shared WABA, which is expected and uninteresting.
        $num = (string)($value['metadata']['display_phone_number'] ?? 'unknown number');
        wa_log("webhook: $seen marketing link click(s) on $num — not matched to any of our campaigns");
    }
    return ['applied' => $applied, 'seen' => $seen];
}

/** One inbound message → one wa_messages row. Returns false when it was a duplicate re-delivery. */
function wa_store_inbound_message(array $m, string $phoneNumberId, array $names): bool {
    global $conn;

    $wamid = (string)($m['id'] ?? '');
    $from  = (string)($m['from'] ?? '');
    if ($from === '') return false;

    $phone = wa_normalize_phone($from, wa_default_cc()) ?: preg_replace('/\D+/', '', $from);
    $conv  = wa_conversation_upsert($phone, $phoneNumberId, $names[$from] ?? null);
    if (!$conv) return false;

    $type = (string)($m['type'] ?? 'text');
    $ts   = isset($m['timestamp']) ? date('Y-m-d H:i:s', (int)$m['timestamp']) : date('Y-m-d H:i:s');

    $row = [
        'msg_type'   => $type,
        'body'       => null,
        'caption'    => null,
        'media_id'   => null,
        'media_mime' => null,
        'media_filename' => null,
        'media_size' => null,
        'created_at' => $ts,
    ];

    switch ($type) {
        case 'text':
            $row['body'] = (string)($m['text']['body'] ?? '');
            break;
        case 'image': case 'video': case 'audio': case 'document': case 'sticker':
            $node = $m[$type] ?? [];
            $row['media_id']       = (string)($node['id'] ?? '');
            $row['media_mime']     = (string)($node['mime_type'] ?? '');
            $row['media_filename'] = (string)($node['filename'] ?? '');
            $row['caption']        = (string)($node['caption'] ?? '');
            break;
        case 'button':
            // Tapping a quick-reply button on a template arrives as its own message.
            $row['body'] = (string)($m['button']['text'] ?? '');
            break;
        case 'interactive':
            $i = $m['interactive'] ?? [];
            $row['body'] = (string)($i['button_reply']['title'] ?? ($i['list_reply']['title'] ?? ''));
            break;
        case 'location':
            $l = $m['location'] ?? [];
            $row['body'] = trim(($l['name'] ?? '') . ' ' . ($l['address'] ?? '')) ?: (($l['latitude'] ?? '') . ',' . ($l['longitude'] ?? ''));
            break;
        case 'contacts':
            $row['body'] = (string)($m['contacts'][0]['name']['formatted_name'] ?? 'Contact');
            break;
        default:
            // Reactions, orders, system messages, anything Meta adds later. Stored as a
            // placeholder rather than dropped, so the thread doesn't develop silent gaps.
            $row['body'] = (string)($m[$type]['body'] ?? ucfirst($type) . ' message');
    }

    $esc = fn($v) => $v === null || $v === '' ? 'NULL' : "'" . $GLOBALS['conn']->real_escape_string((string)$v) . "'";
    $ctx = (string)($m['context']['id'] ?? '');

    $conn->query("INSERT INTO wa_messages
        (conversation_id, direction, wa_message_id, msg_type, body, caption, media_id, media_mime,
         media_filename, context_wamid, status, created_at)
        VALUES (" . (int)$conv['id'] . ", 'in', " . $esc($wamid) . ", " . $esc($row['msg_type']) . ", "
        . $esc($row['body']) . ", " . $esc($row['caption']) . ", " . $esc($row['media_id']) . ", "
        . $esc($row['media_mime']) . ", " . $esc($row['media_filename']) . ", " . $esc($ctx) . ", "
        . "'received', '" . $conn->real_escape_string($row['created_at']) . "')
        ON DUPLICATE KEY UPDATE wa_message_id = wa_message_id");

    // affected_rows is 0 when the ON DUPLICATE branch fired — i.e. Meta re-delivered a webhook
    // we already stored. Nothing further should happen, or the unread badge would climb on
    // every retry.
    if ($conn->affected_rows === 0) return false;

    wa_conversation_touch((int)$conv['id'], $row, true);

    /*
     * A reply is also a campaign signal.
     *
     * Tapping a QUICK-REPLY button on a template arrives here as an ordinary inbound message of
     * type 'button' (or 'interactive' for a list/button reply) — there is no separate click
     * webhook. So this is the only place a click can be counted, and without it the campaign
     * report's click column stays at zero forever.
     *
     * URL buttons are a different story: Meta does not report taps on them at all, through any
     * webhook field. If click-through on a link matters, the link has to carry its own tracking
     * (a redirect through the panel), not rely on WhatsApp.
     */
    $isTap = in_array($type, ['button', 'interactive'], true);
    wa_credit_reply_to_campaign($phone, (string)($m['context']['id'] ?? ''), $isTap);

    // A keyword reply is a consent instruction, not conversation. Handled last so the message is
    // already stored and visible in the thread — an admin has to be able to see WHY someone
    // stopped receiving messages, not just that they did.
    wa_apply_keyword_consent($phone, (string)($row['body'] ?? ''));
    return true;
}

/*
 * The opt-out keywords WhatsApp users actually type.
 *
 * Anchored to the start and required to be the whole message (give or take punctuation): a reply
 * of "stop" is an instruction, but "please don't stop the batch" is not, and blocking that person
 * would be both wrong and invisible. Meta's own recommended set is STOP/UNSUBSCRIBE/CANCEL/END/
 * QUIT, and Indian users very commonly send the Hindi equivalents, so those are here too.
 */
const WA_STOP_KEYWORDS  = ['stop', 'unsubscribe', 'unsub', 'optout', 'opt out', 'opt-out', 'cancel',
                           'end', 'quit', 'remove me', 'do not message', 'dont message', 'band karo',
                           'band karo message', 'mat bhejo', 'rok do'];
/** The way back in. Without this an opt-out is permanent and only an admin can undo it. */
const WA_START_KEYWORDS = ['start', 'unstop', 'resume', 'subscribe', 'optin', 'opt in', 'opt-in', 'yes'];

/**
 * Applies STOP / START keywords found in an inbound message.
 *
 * The suppression itself is wa_optins — the same table campaign sending already consults
 * (wa_optin_map in WaSendWorker), so a STOP takes effect on the very next campaign without any
 * other code needing to know this happened. `reason` and `blocked_at` are written alongside so
 * the Blocklist screen can show what the person actually said and when.
 */
function wa_apply_keyword_consent(string $phone, string $body): void {
    $norm = strtolower(trim(preg_replace('/[\s\p{P}]+/u', ' ', $body) ?? ''));
    if ($norm === '') return;

    foreach (WA_STOP_KEYWORDS as $kw) {
        if ($norm === $kw) {
            wa_record_optin($phone, 'optout', 'REPLY', 'Replied "' . mb_substr(trim($body), 0, 120) . '" on WhatsApp');
            wa_log("inbox: $phone opted out via keyword reply — blocklisted for WhatsApp");
            return;
        }
    }
    foreach (WA_START_KEYWORDS as $kw) {
        if ($norm === $kw) {
            wa_record_optin($phone, 'optin', 'REPLY', 'Replied "' . mb_substr(trim($body), 0, 120) . '" on WhatsApp');
            wa_log("inbox: $phone opted back in via keyword reply");
            return;
        }
    }
}

/**
 * Counts an inbound message as a reply against the campaign that prompted it.
 *
 * When WhatsApp gives us a context id (the contact used the reply-quote), that identifies the
 * exact campaign message. Otherwise the most recent campaign message to that number inside the
 * last 24 hours is the only reasonable attribution — beyond that window the connection is a
 * guess, so nothing is credited rather than inflating a campaign's reply count.
 */
function wa_credit_reply_to_campaign(string $phone, string $contextWamid, bool $isButtonTap = false): void {
    global $conn;
    $p = $conn->real_escape_string($phone);

    $rec = null;
    if ($contextWamid !== '') {
        $r = $conn->query("SELECT id, campaign_id FROM wa_campaign_recipients
                            WHERE wa_message_id='" . $conn->real_escape_string($contextWamid) . "' LIMIT 1");
        $rec = $r ? $r->fetch_assoc() : null;
    }
    if (!$rec) {
        $r = $conn->query("SELECT id, campaign_id FROM wa_campaign_recipients
                            WHERE phone='$p' AND is_test=0 AND sent_at IS NOT NULL
                              AND sent_at >= DATE_SUB(NOW(), INTERVAL 24 HOUR)
                            ORDER BY sent_at DESC LIMIT 1");
        $rec = $r ? $r->fetch_assoc() : null;
    }
    if (!$rec) return;

    $cid = (int)$rec['campaign_id'];
    $rid = (int)$rec['id'];

    $conn->query("UPDATE wa_campaigns SET reply_count = reply_count + 1 WHERE id=$cid");
    wa_record_event($cid, $rid, 'replied');

    if ($isButtonTap) {
        $conn->query("UPDATE wa_campaign_recipients SET click_count = click_count + 1 WHERE id=$rid");
        $conn->query("UPDATE wa_campaigns SET click_count = click_count + 1 WHERE id=$cid");
        wa_record_event($cid, $rid, 'button_click');
    }
}

/**
 * Applies a Meta status webhook to a manual reply we sent from this inbox.
 *
 * Campaign messages are handled by webhook.php's own correlation pass; this one only ever
 * touches wa_messages, and returns false for an id it doesn't own so the two never fight over
 * the same row.
 */
function wa_apply_message_status(array $st): bool {
    global $conn;
    $id     = (string)($st['id'] ?? '');
    $status = strtolower((string)($st['status'] ?? ''));
    if ($id === '' || $status === '') return false;

    $r = $conn->query("SELECT id, status FROM wa_messages
                        WHERE wa_message_id='" . $conn->real_escape_string($id) . "' AND direction='out' LIMIT 1");
    $row = $r ? $r->fetch_assoc() : null;
    if (!$row) return false;

    // Same forward-only rule as the campaign path: WhatsApp does not order its webhooks, and a
    // late "delivered" must never demote a "read" that already landed.
    $rank = ['pending' => 0, 'sent' => 1, 'delivered' => 2, 'read' => 3];
    $mid  = (int)$row['id'];

    if ($status === 'failed') {
        $e = $st['errors'][0] ?? [];
        $msg = $e['error_data']['details'] ?? ($e['title'] ?? 'Failed');
        $conn->query("UPDATE wa_messages SET status='failed',
                             error_code='" . $conn->real_escape_string((string)($e['code'] ?? '')) . "',
                             error_message='" . $conn->real_escape_string(mb_substr((string)$msg, 0, 480)) . "'
                       WHERE id=$mid");
        return true;
    }
    if (!isset($rank[$status])) return false;
    if (($rank[$status] ?? 0) <= ($rank[$row['status']] ?? 0)) return false;

    $col = $status === 'read' ? ", read_at=NOW()" : ($status === 'delivered' ? ", delivered_at=NOW()" : '');
    $conn->query("UPDATE wa_messages SET status='$status'$col WHERE id=$mid");
    return true;
}

/* ── outbound ─────────────────────────────────────────────────────────────────────────── */

/** The sending number a conversation replies through: the one it arrived on, else the default. */
function wa_conversation_sender(array $conv): ?array {
    global $conn;
    if (!empty($conv['phone_number_id'])) {
        $r = $conn->query("SELECT * FROM wa_senders
                            WHERE phone_number_id='" . $conn->real_escape_string($conv['phone_number_id']) . "' LIMIT 1");
        $row = $r ? $r->fetch_assoc() : null;
        if ($row) return $row;
    }
    return wa_sender_by_id(isset($conv['sender_id']) ? (int)$conv['sender_id'] : null) ?: wa_default_sender();
}

/** Is the free-form window still open? Everything outside it must be a template. */
function wa_window_open(array $conv): bool {
    $exp = $conv['window_expires_at'] ?? null;
    return $exp !== null && strtotime((string)$exp) > time();
}

/**
 * Translates a Meta-shaped message object into the transport-neutral `content` shape that
 * NetcoreTransport::buildRequest() understands.
 *
 * The inbox was written against Meta's Cloud API and speaks its message objects everywhere
 * (`['type'=>'text','text'=>['body'=>…]]`). Netcore wants a flatter shape and disagrees on the
 * name of nearly every field. Rather than rewrite every caller, the translation happens once
 * here — callers keep building Meta objects, and this decides what the BSP is handed.
 *
 * `error` is non-null when the message cannot cross to Netcore at all, so the caller can say why
 * instead of sending something the BSP will quietly drop.
 *
 * @return array{content: array, error: ?string}
 */
function wa_netcore_content_from_meta(array $content, array $local): array {
    $type = (string)($content['type'] ?? 'text');

    if ($type === 'text') {
        return ['content' => [
            'type'        => 'text',
            'body'        => (string)($content['text']['body'] ?? ''),
            'preview_url' => !empty($content['text']['preview_url']),
        ], 'error' => null];
    }

    if ($type === 'template') {
        $t    = $content['template'] ?? [];
        $comp = $t['components'] ?? [];
        return ['content' => [
            'type'     => 'template',
            'name'     => (string)($t['name'] ?? ''),
            'language' => (string)($t['language']['code'] ?? 'en'),
            // Netcore takes the body's parameters as one flat list in template order; the
            // components[] Meta was given carry the same values nested one level deeper.
            'attributes'       => wa_flatten_components_to_attributes($comp),
            'buttons'          => wa_flatten_components_to_buttons($comp),
            'header_type'      => (string)($local['header_type'] ?? 'none'),
            'header_media_url' => (string)($local['header_media_url'] ?? ''),
        ], 'error' => null];
    }

    /*
     * Media. The two routes address a file in completely different ways: Meta takes a media id
     * that was uploaded to the sending number, Netcore fetches a URL itself. A Meta media id is
     * meaningless to Netcore, so the local copy is published under a signed, expiring URL and
     * that is what goes out.
     */
    if (in_array($type, ['image', 'video', 'document', 'audio'], true)) {
        $url = wa_public_media_url($local);
        if ($url === null) {
            return ['content' => [], 'error' =>
                'This number sends through Netcore, which fetches attachments by URL — but the local '
                . 'copy of this file could not be published. Send the file as a link in a text message instead.'];
        }
        $block = ['type' => $type, 'url' => $url];
        $cap   = trim((string)($local['caption'] ?? ''));
        // Audio carries no caption; sending one is rejected.
        if ($cap !== '' && $type !== 'audio') $block['caption'] = $cap;
        if ($type === 'document' && !empty($local['media_filename'])) $block['filename'] = (string)$local['media_filename'];
        return ['content' => ['type' => 'media', 'media' => $block], 'error' => null];
    }

    return ['content' => [], 'error' => "Message type '$type' cannot be sent through Netcore."];
}

/** components[] → the flat body-parameter list Netcore calls `attributes`. */
function wa_flatten_components_to_attributes(array $components): array {
    $out = [];
    foreach ($components as $c) {
        if (strtolower((string)($c['type'] ?? '')) !== 'body') continue;
        foreach (($c['parameters'] ?? []) as $p) {
            if (($p['type'] ?? '') === 'text') $out[] = (string)($p['text'] ?? '');
        }
    }
    return $out;
}

/** components[] → Netcore's separate `buttons` block. Mixing these into attributes is error 132000. */
function wa_flatten_components_to_buttons(array $components): array {
    $out = [];
    foreach ($components as $c) {
        if (strtolower((string)($c['type'] ?? '')) !== 'button') continue;
        $vals = [];
        foreach (($c['parameters'] ?? []) as $p) $vals[] = (string)($p['text'] ?? ($p['payload'] ?? ''));
        $out[] = [
            'index'      => (string)($c['index'] ?? '0'),
            'sub_type'   => (string)($c['sub_type'] ?? 'url'),
            'attributes' => $vals,
        ];
    }
    return $out;
}

/**
 * A URL Netcore's servers can fetch this attachment from.
 *
 * Netcore pulls the file itself, with no session, so it has to be reachable without the panel's
 * JWT. Two shapes, depending on where the bytes are:
 *
 *   S3 (everything since the move)  the object URL, handed over directly. Publishing a file the
 *                                   panel is deliberately sending out is the point of the call,
 *                                   and it saves this server proxying every attachment byte to
 *                                   a BSP that is only going to fetch it once.
 *   local (pre-move files)          the old signed, expiring proxy link, kept so a conversation
 *                                   with older media still sends. The HMAC covers the filename
 *                                   and an expiry, so the cache directory stays un-enumerable
 *                                   and a leaked link is dead within the hour.
 *
 * Takes the whole message row rather than a filename, because "where is this file" is now a
 * question only the row can answer.
 */
function wa_public_media_url(array $msg): ?string {
    $s3 = trim((string)($msg['media_s3_url'] ?? ''));
    if ($s3 !== '') return $s3;

    $localName = basename(trim((string)($msg['local_path'] ?? '')));
    if ($localName === '' || !is_file(wa_media_dir() . '/' . $localName)) return null;

    $exp = time() + 3600;
    $sig = hash_hmac('sha256', $localName . '|' . $exp, WA_CRON_SECRET);
    return 'https://' . WA_WORKER_HOST . rtrim(dirname(WA_WORKER_PATH), '/') . '/media-public.php'
         . '?f=' . rawurlencode($localName) . '&e=' . $exp . '&s=' . $sig;
}

/**
 * Sends one message on whichever route this conversation's number actually uses, and records it.
 *
 * This was Meta-only, which meant every reply typed into Live Chat failed on a Netcore-routed
 * number: it demanded a Meta access token and a phone_number_id, neither of which a BSP number
 * has, so the composer answered "No Meta access token configured" no matter what was typed —
 * and since our WABA is reachable only through Netcore's app, that was every number. Campaigns
 * had always picked their transport per sending number (wa_transport_for_sender); the inbox now
 * does the same, so both halves of the channel agree on how a given number sends.
 *
 * @param array $content Meta's message object minus the envelope, e.g.
 *                       ['type'=>'text','text'=>['body'=>'hi']]
 * @return array{ok:bool, error:?string, message:?array}
 */
function wa_inbox_send(array $conv, array $content, array $local, ?int $sentBy): array {
    $sender   = wa_conversation_sender($conv);
    $settings = wa_settings_row() ?: [];

    // Every early return records the attempt too — a reply that vanished with only a toast to
    // show for it is unauditable, and the thread is the one place anyone looks for what was said.
    $fail = function (string $err, ?string $code = 'unconfigured') use ($conv, $local, $sentBy): array {
        wa_inbox_record_out($conv, $local, $sentBy, null, 'failed', $code, $err);
        return ['ok' => false, 'error' => $err, 'message' => null];
    };

    if (!$sender) return $fail('This conversation has no sending number configured — add one in WhatsApp → Settings.');

    $provider  = wa_resolve_provider($sender);
    $transport = wa_transport_for_sender($settings, $sender, null);
    if (!$transport->isConfigured()) {
        return $fail($provider === 'netcore'
            ? 'This number sends through Netcore but has no API key — add it in WhatsApp → Settings → Sending numbers → Edit.'
            : 'This number sends through Meta but is missing its access token or phone number ID — check WhatsApp → Settings.');
    }

    $outbound = $content;
    if ($provider === 'netcore') {
        $t = wa_netcore_content_from_meta($content, $local);
        if ($t['error'] !== null) return $fail($t['error'], 'unsupported');
        $outbound = $t['content'];
    }

    // The correlation id. Netcore echoes it as x-apiheader on webhooks; Meta ignores it and
    // returns a wamid instead, which is what gets stored when it comes back.
    $rid = 'inbox' . $conv['id'] . '_' . bin2hex(random_bytes(6));
    $res = $transport->sendMessage((string)$conv['phone'], $outbound, $rid);

    if (empty($res['ok'])) {
        wa_inbox_record_out($conv, $local, $sentBy, null, 'failed',
            (string)($res['code'] ?? ''), (string)($res['error'] ?? 'Send failed'));
        wa_log('inbox: reply to ' . $conv['phone'] . ' via ' . strtoupper($provider) . ' FAILED — ' . ($res['error'] ?? '?'));
        return ['ok' => false, 'error' => $res['error'] ?: 'Could not send', 'message' => null];
    }

    $msg = wa_inbox_record_out($conv, $local, $sentBy, (string)($res['message_id'] ?? $rid), 'sent', null, null);
    wa_conversation_touch((int)$conv['id'], array_merge($local, ['created_at' => date('Y-m-d H:i:s')]), false);
    return ['ok' => true, 'error' => null, 'message' => $msg];
}

/** Writes the outbound row — one INSERT shared by the success and failure paths. */
function wa_inbox_record_out(array $conv, array $local, ?int $sentBy, ?string $wamid,
                             string $status, ?string $errCode, ?string $errMsg): ?array {
    global $conn;
    $esc = fn($v) => $v === null || $v === '' ? 'NULL' : "'" . $GLOBALS['conn']->real_escape_string((string)$v) . "'";
    $now = date('Y-m-d H:i:s');

    $conn->query("INSERT INTO wa_messages
        (conversation_id, direction, wa_message_id, msg_type, body, caption, media_id, media_mime,
         media_filename, local_path, template_name, status, error_code, error_message, sent_by, created_at)
        VALUES (" . (int)$conv['id'] . ", 'out', " . $esc($wamid) . ", " . $esc($local['msg_type'] ?? 'text') . ", "
        . $esc($local['body'] ?? null) . ", " . $esc($local['caption'] ?? null) . ", "
        . $esc($local['media_id'] ?? null) . ", " . $esc($local['media_mime'] ?? null) . ", "
        . $esc($local['media_filename'] ?? null) . ", " . $esc($local['local_path'] ?? null) . ", "
        . $esc($local['template_name'] ?? null) . ", " . $esc($status) . ", "
        . $esc($errCode) . ", " . $esc($errMsg === null ? null : mb_substr($errMsg, 0, 480)) . ", "
        . ($sentBy ? (int)$sentBy : 'NULL') . ", '$now')");

    $newId = (int)$conn->insert_id;
    if (!$newId) return null;
    $r = $conn->query("SELECT * FROM wa_messages WHERE id=$newId LIMIT 1");
    return $r ? $r->fetch_assoc() : null;
}

/**
 * Tells WhatsApp the contact's messages have been seen, so THEY see the blue ticks.
 *
 * Best-effort by design: an admin opening a thread must not be blocked, or shown an error, over
 * a read receipt. A stale wamid (older than 30 days) is the normal failure and is uninteresting.
 */
function wa_mark_read_upstream(array $conv): void {
    global $conn;
    $sender = wa_conversation_sender($conv);
    $pni    = trim((string)($sender['phone_number_id'] ?? ''));
    $token  = wa_meta_token();
    if ($pni === '' || $token === '') return;

    $r = $conn->query("SELECT wa_message_id FROM wa_messages
                        WHERE conversation_id=" . (int)$conv['id'] . " AND direction='in' AND wa_message_id IS NOT NULL
                        ORDER BY id DESC LIMIT 1");
    $row = $r ? $r->fetch_assoc() : null;
    if (!$row) return;

    wa_graph_call('POST', WA_GRAPH_BASE . WA_GRAPH_VERSION . "/$pni/messages", $token, [
        'messaging_product' => 'whatsapp',
        'status'            => 'read',
        'message_id'        => $row['wa_message_id'],
    ], 8);
}

/* ── media ────────────────────────────────────────────────────────────────────────────── */

/*
 * ── Where WhatsApp media lives, and why it moved ──────────────────────────────────────
 *
 * It used to live on this server, in api/whatsapp/media/, one file per attachment, forever.
 * That is a cPanel disk quota filling up with student photographs at 500 KB apiece and never
 * being emptied — and the same host also serves the panel, so when it fills, everything stops.
 * Media is also the one thing here that genuinely cannot be regenerated: Meta deletes it after
 * 30 days, so our copy is the only copy, and "the only copy" does not belong on the box most
 * likely to run out of room.
 *
 * So the bytes go to S3 — the same bucket the contact-import CSVs and campaign attachments
 * already use — and the database keeps only the key and the URL. Nothing is written to local
 * disk permanently: the download from Meta lands in the system temp directory, is uploaded,
 * and is deleted in the same request.
 *
 * ── The one thing that did NOT change ────────────────────────────────────────────────
 * Panel viewing still goes through the authenticated proxy (wa_inbox.php?action=media), which
 * now streams from S3 instead of from disk. It would have been cheaper to redirect the browser
 * to the S3 URL, and that is deliberately not done: inbound media is whatever a student chose
 * to send — ID cards, fee receipts, screenshots of their own documents — and a redirect hands
 * out a permanent, unauthenticated URL to it. The proxy costs bandwidth; handing out that URL
 * costs a good deal more.
 *
 * The Netcore send path is the exception, and has to be: their servers fetch the attachment
 * themselves, with no session, so an outbound file's S3 URL is what goes out. That is a file
 * this panel is deliberately publishing, which is a different thing from one a student sent in.
 */

/*
 * S3 is loaded ON DEMAND, not at file scope — see wa_s3_ready() below.
 *
 * lib/S3Uploader.php opens with an ABSOLUTE require of the AWS SDK autoloader under
 * /home/istudio/public_html/..., which exists only on the cPanel web server. Requiring it here
 * made this whole file unloadable anywhere else, and that stopped being a theoretical problem
 * the moment the webhook drainer moved to the monitoring box: WaWebhookProcessor.php needs
 * wa_ingest_webhook() from this file, and the require chain killed the worker on startup with
 *   Failed opening required '.../lib/S3Uploader.php'
 * before a single delivery receipt was read.
 *
 * S3 is used in exactly ONE place in this file (the media download below). Everything else —
 * inbound message ingestion, delivery statuses, link clicks, the whole reason the drainer loads
 * this file — needs nothing from AWS. So the dependency now costs only the code path that
 * actually uses it, and a machine without the SDK loses inbound MEDIA while still handling
 * every other event correctly, instead of losing all of it.
 */

/**
 * Loads the S3 helper if this machine actually has the AWS SDK, once per process.
 *
 * Checks the autoloader itself rather than trying and catching: a failed require is a FATAL in
 * PHP, not an exception, so there is nothing to catch — it has to be looked at before the
 * attempt.
 */
function wa_s3_ready(): bool {
    static $ready = null;
    if ($ready !== null) return $ready;

    if (function_exists('s3_upload_file')) return $ready = true;

    $autoload = '/home/istudio/public_html/istudio_dashboard/api/vendor/autoload.php';
    if (!@is_file($autoload)) {
        if (function_exists('wa_log')) {
            wa_log('inbox: AWS SDK not present on this machine — inbound media cannot be stored here '
                 . '(delivery receipts and inbound text are unaffected)');
        }
        return $ready = false;
    }

    require_once __DIR__ . '/../../lib/S3Uploader.php';
    return $ready = function_exists('s3_upload_file');
}

/** Where in the bucket WhatsApp media lives. */
if (!defined('WA_S3_PREFIX')) define('WA_S3_PREFIX', 'whatsapp_media');

/**
 * Legacy local cache directory.
 *
 * Kept only so media downloaded before the move to S3 still opens. Nothing writes here any
 * more — wa_media_fetch() uploads and stores a reference instead — and once the old files have
 * aged out the directory and this function can go.
 */
function wa_media_dir(): string {
    if (!is_dir(WA_MEDIA_DIR)) @mkdir(WA_MEDIA_DIR, 0775, true);
    $ht = WA_MEDIA_DIR . '/.htaccess';
    if (!file_exists($ht)) @file_put_contents($ht, "Deny from all\n");
    return WA_MEDIA_DIR;
}

/** True when wa_media_fetch() handed back an S3 URL rather than a path on this disk. */
function wa_media_is_remote(?string $source): bool {
    return $source !== null && str_starts_with($source, 'http');
}

/**
 * Returns [source, mime, error] for a message's media, fetching it from Meta on first use.
 *
 * `source` is an S3 URL for anything stored since the move, and an absolute local path for the
 * files that predate it. Callers decide what to do with each — see wa_media_is_remote().
 *
 * Two round trips are required against Meta and both need the token: GET /{media_id} returns a
 * short-lived (~5 min) signed URL, and that URL still refuses an unauthenticated fetch. The
 * result is stored because the download is the slow part and because Meta drops the media after
 * 30 days — after which our copy is the only one there is.
 *
 * @return array{0:?string,1:string,2:?string} source, mime, error
 */
function wa_media_fetch(array $msg): array {
    global $conn;

    // Already on S3 — the normal case after the first view.
    $s3Url = trim((string)($msg['media_s3_url'] ?? ''));
    if ($s3Url !== '') return [$s3Url, (string)($msg['media_mime'] ?: 'application/octet-stream'), null];

    // Downloaded before the move. Served from disk, and not re-uploaded: migrating old files is
    // a one-off job, not something to do inside a request somebody is waiting on.
    $cached = trim((string)($msg['local_path'] ?? ''));
    if ($cached !== '') {
        $abs = wa_media_dir() . '/' . basename($cached);
        if (is_file($abs)) return [$abs, (string)($msg['media_mime'] ?: 'application/octet-stream'), null];
    }

    $mediaId = trim((string)($msg['media_id'] ?? ''));
    if ($mediaId === '') return [null, '', 'This message has no media'];

    $token = wa_meta_token();
    if ($token === '') return [null, '', 'No Meta access token configured'];

    $meta = wa_graph_call('GET', WA_GRAPH_BASE . WA_GRAPH_VERSION . '/' . rawurlencode($mediaId), $token, null, 15);
    if (!$meta['ok']) {
        return [null, '', 'Meta would not return this media: ' . $meta['error']
            . ' (media is deleted after ' . WA_MEDIA_RETENTION_DAYS . ' days)'];
    }

    $url  = (string)($meta['data']['url'] ?? '');
    $mime = (string)($meta['data']['mime_type'] ?? ($msg['media_mime'] ?: 'application/octet-stream'));
    if ($url === '') return [null, '', 'Meta returned no download URL'];

    /*
     * Straight to a temp file rather than into memory: a 16 MB video read into a PHP string
     * would blow past memory_limit on shared hosting, and s3_upload_file() wants a path anyway.
     */
    $tmp = tempnam(sys_get_temp_dir(), 'wamedia_');
    if ($tmp === false) return [null, $mime, 'Could not open a temporary file for the download'];

    $fh = @fopen($tmp, 'wb');
    if (!$fh) { @unlink($tmp); return [null, $mime, 'Could not open a temporary file for the download']; }

    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_FILE           => $fh,
        CURLOPT_HTTPHEADER     => ['Authorization: Bearer ' . $token],
        CURLOPT_TIMEOUT        => 60,
        CURLOPT_FOLLOWLOCATION => true,
    ]);
    $ok     = curl_exec($ch);
    $status = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    fclose($fh);

    if ($ok === false || $status < 200 || $status >= 300) {
        @unlink($tmp);
        return [null, $mime, "Download failed (HTTP $status)"];
    }

    $size = (int)@filesize($tmp);
    $ext  = wa_ext_for_mime($mime, (string)($msg['media_filename'] ?? ''));
    // The message id keeps it traceable; the hash keeps it unguessable, which matters because
    // the bucket serves over plain HTTPS with no per-object authorisation.
    $key  = WA_S3_PREFIX . '/' . (int)$msg['id'] . '_' . bin2hex(random_bytes(8)) . $ext;

    if (!wa_s3_ready()) {
        @unlink($tmp);
        return [null, $mime, 'Media storage is not available on this server'];
    }

    $publicUrl = s3_upload_file($tmp, $key, $mime);
    @unlink($tmp);   // nothing survives on local disk, which is the entire point of this change

    if ($publicUrl === null) {
        // Serving still works without a stored copy — the next view pays for the download again.
        return [null, $mime, 'Could not upload the media to storage'];
    }

    $conn->query("UPDATE wa_messages
                     SET media_s3_key='" . $conn->real_escape_string($key) . "',
                         media_s3_url='" . $conn->real_escape_string($publicUrl) . "',
                         media_mime='"   . $conn->real_escape_string($mime) . "',
                         media_size=" . $size . "
                   WHERE id=" . (int)$msg['id']);

    return [$publicUrl, $mime, null];
}

/**
 * Streams a media source to the browser, from S3 or from the legacy disk cache.
 *
 * Kept in one place because the two sources need different plumbing and the caller should not
 * care: both are read in chunks rather than into a string, so a large video costs the same
 * memory as a small photo.
 */
function wa_media_stream(string $source): bool {
    $fh = @fopen($source, 'rb');
    if (!$fh) return false;
    while (!feof($fh)) {
        echo fread($fh, 8192);
        if (connection_aborted()) break;
        @ob_flush();
        flush();
    }
    fclose($fh);
    return true;
}

/** Content-Length when it can be known cheaply — a local file always, S3 via a HEAD. */
function wa_media_size(string $source, array $msg): ?int {
    $known = (int)($msg['media_size'] ?? 0);
    if ($known > 0) return $known;
    if (!wa_media_is_remote($source)) {
        $n = @filesize($source);
        return $n === false ? null : (int)$n;
    }
    return null;
}

function wa_ext_for_mime(string $mime, string $filename = ''): string {
    $known = [
        'image/jpeg' => '.jpg', 'image/png' => '.png', 'image/webp' => '.webp', 'image/gif' => '.gif',
        'video/mp4' => '.mp4', 'video/3gpp' => '.3gp',
        'audio/ogg' => '.ogg', 'audio/mpeg' => '.mp3', 'audio/mp4' => '.m4a', 'audio/amr' => '.amr',
        'application/pdf' => '.pdf',
    ];
    $base = strtok($mime, ';');
    if (isset($known[$base])) return $known[$base];
    if ($filename !== '' && preg_match('/(\.[A-Za-z0-9]{1,6})$/', $filename, $m)) return strtolower($m[1]);
    return '.bin';
}

/**
 * Uploads a local file to Meta and returns its media id.
 *
 * Multipart, so it can't go through wa_graph_call() (JSON only). CURLFile is used rather than a
 * hand-built body because Meta rejects a mismatched boundary with an unhelpful generic error.
 *
 * @return array{ok:bool, id:?string, error:?string}
 */
function wa_graph_upload_media(string $phoneNumberId, string $path, string $mime, string $filename): array {
    $token = wa_meta_token();
    if ($token === '') return ['ok' => false, 'id' => null, 'error' => 'No Meta access token configured'];

    $ch = curl_init(WA_GRAPH_BASE . WA_GRAPH_VERSION . "/$phoneNumberId/media");
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST           => true,
        CURLOPT_HTTPHEADER     => ['Authorization: Bearer ' . $token],
        CURLOPT_TIMEOUT        => 120,
        CURLOPT_POSTFIELDS     => [
            'messaging_product' => 'whatsapp',
            'type'              => $mime,
            'file'              => new CURLFile($path, $mime, $filename),
        ],
    ]);
    $body   = curl_exec($ch);
    $status = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $err    = curl_error($ch);
    curl_close($ch);

    if ($err !== '') return ['ok' => false, 'id' => null, 'error' => "Upload failed: $err"];
    $decoded = json_decode((string)$body, true);
    if ($status < 200 || $status >= 300 || empty($decoded['id'])) {
        $e = $decoded['error'] ?? [];
        return ['ok' => false, 'id' => null, 'error' => $e['error_user_msg'] ?? ($e['message'] ?? "Upload failed (HTTP $status)")];
    }
    return ['ok' => true, 'id' => (string)$decoded['id'], 'error' => null];
}

/**
 * What WhatsApp accepts, per message type.
 *
 * The caps are Meta's own and are enforced here rather than left to the API: a rejected upload
 * costs a 120-second round trip and returns a generic error, while a local check is instant and
 * can say exactly which limit was hit.
 */
function wa_media_kind(string $mime): array {
    $mime = strtolower(strtok($mime, ';') ?: '');
    $sets = [
        'image'    => ['mimes' => ['image/jpeg', 'image/png'],                          'max' => 5  * 1024 * 1024],
        'video'    => ['mimes' => ['video/mp4', 'video/3gpp'],                          'max' => 16 * 1024 * 1024],
        'audio'    => ['mimes' => ['audio/aac', 'audio/mp4', 'audio/mpeg', 'audio/amr', 'audio/ogg'], 'max' => 16 * 1024 * 1024],
    ];
    foreach ($sets as $kind => $spec) {
        if (in_array($mime, $spec['mimes'], true)) return ['kind' => $kind, 'max' => $spec['max'], 'mime' => $mime];
    }
    // Everything else rides as a document, which is the broadest type WhatsApp accepts.
    return ['kind' => 'document', 'max' => 100 * 1024 * 1024, 'mime' => $mime ?: 'application/octet-stream'];
}


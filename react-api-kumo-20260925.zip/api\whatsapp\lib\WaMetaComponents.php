<?php
/*
 * lib/WaMetaComponents.php — turning a stored template into the shape Meta accepts, and talking
 * to the Graph API.
 *
 * These lived in wa_templates.php, which is an endpoint: including it from anywhere else runs its
 * action dispatch and answers the wrong request. They moved here the moment a second caller
 * appeared — attributes.php resubmits a template when the value it carries changes, and it needs
 * exactly the same rendering the button does.
 *
 * Nothing about the behaviour changed in the move.
 */

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/WaHelpers.php';

/**
 * Turns one of our wa_templates rows into Meta's `components` array.
 *
 * Meta requires an `example` for every placeholder — a template with {{1}} and no sample is
 * rejected outright — which is exactly what the editor's "Sample values" section is for.
 */
function wa_build_meta_components(array $t): array {
    $components = [];
    $samples = json_decode($t['sample_values'] ?? '{}', true) ?: [];

    $headerVars = $t['header_type'] === 'text' ? wa_placeholder_count((string)$t['header_text']) : 0;
    if ($t['header_type'] === 'text' && trim((string)$t['header_text']) !== '') {
        $header = ['type' => 'HEADER', 'format' => 'TEXT', 'text' => (string)$t['header_text']];
        if ($headerVars > 0) {
            $header['example'] = ['header_text' => array_map(
                fn($i) => (string)($samples['header'][$i] ?? 'Sample'),
                range(0, $headerVars - 1)
            )];
        }
        $components[] = $header;
    } elseif (in_array($t['header_type'], ['image', 'video', 'document'], true) && trim((string)$t['header_media_url']) !== '') {
        $components[] = [
            'type' => 'HEADER', 'format' => strtoupper($t['header_type']),
            'example' => ['header_handle' => [(string)$t['header_media_url']]],
        ];
    }

    $bodyVars = wa_placeholder_count((string)$t['body_text']);
    $body = ['type' => 'BODY', 'text' => (string)$t['body_text']];
    if ($bodyVars > 0) {
        // body_text example is an array OF arrays — one inner array per variable set.
        $body['example'] = ['body_text' => [array_map(
            fn($i) => (string)($samples['body'][$i] ?? 'Sample'),
            range(0, $bodyVars - 1)
        )]];
    }
    $components[] = $body;

    if (trim((string)$t['footer_text']) !== '') {
        $components[] = ['type' => 'FOOTER', 'text' => (string)$t['footer_text']];
    }

    $buttons = json_decode($t['buttons'] ?? '[]', true) ?: [];
    $metaButtons = [];
    foreach ($buttons as $b) {
        $text = (string)($b['text'] ?? '');
        if ($text === '') continue;
        if (($b['type'] ?? '') === 'url') {
            $url = trim((string)($b['url'] ?? ''));
            $btn = ['type' => 'URL', 'text' => $text, 'url' => $url];

            /*
             * A TRACKED LINK IS STATIC, and that is the entire point of it.
             *
             * When the template has a link_id, its URL already ends in that id ("…/login/23") and
             * carries the campaign by itself. Appending a variable on top would recreate exactly
             * the URL shape Meta refused to approve — every submission of the {{1}} form came back
             * INCORRECT_CATEGORY, under UTILITY and MARKETING alike — so the dynamic branch below
             * is skipped entirely and Meta sees a plain link with no placeholder and no example.
             *
             * Templates set up before wa_links existed have no link_id and still take the old
             * path, so nothing about them changes until they are re-saved.
             */
            $hasTrackedLink = (int)($t['link_id'] ?? 0) > 0;

            if (!empty($b['dynamic']) && !$hasTrackedLink) {
                /*
                 * WHERE {{1}} GOES, and why it is not simply appended.
                 *
                 * This used to do  rtrim($url,'/') . '/{{1}}'  unconditionally, which produced a
                 * PATH segment:  https://dashboard…/login/{{1}}. Filled with attribution
                 * parameters that becomes  …/login/campaign_id=14&medium=whatsapp…  — a nonsense
                 * path, and window.location.search is empty, so the landing page reads no
                 * campaign at all. It also double-appended on any template whose url already
                 * carried {{1}} (everything imported from Meta does), giving  …/{{1}}/{{1}}.
                 *
                 * So: a placeholder the admin already typed is respected exactly as written —
                 * that is the only way to choose between the query form (…/login?{{1}}, one page
                 * per template) and the path form (…/{{1}}, one template serving many pages).
                 * Only when there is no placeholder at all is one added, in QUERY form, because
                 * that is what the attribution parameters need to be readable.
                 */
                if (strpos($btn['url'], '{{') === false) {
                    $btn['url'] .= (strpos($btn['url'], '?') === false ? '?{{1}}' : '&{{1}}');
                }
                // Meta requires a fully-formed example. A realistic one also shows the reviewer
                // what the variable is for, which makes a URL button far less likely to be
                // rejected than the literal word "sample".
                $btn['example'] = [str_replace('{{1}}', 'campaign_id=1&medium=whatsapp&attr_window=2', $btn['url'])];
            }
            $metaButtons[] = $btn;
        } elseif (($b['type'] ?? '') === 'phone') {
            /*
             * Attributes are resolved to the number they hold, then normalised — templates saved
             * before either check existed still carry whatever was typed into them.
             */
            $missing = [];
            $resolved = wa_button_phone_resolved((string)($b['phone'] ?? ''), $missing);
            if ($missing) {
                /* Thrown rather than answered: this file is loaded by the template endpoint AND by
                   the attribute editor, and only the endpoint has api_error(). Throwing lets each
                   caller phrase the refusal in its own terms without this code knowing which it is. */
                throw new RuntimeException('The Call button' . ($text !== '' ? ' "' . $text . '"' : '') . ' uses '
                    . implode(' and ', array_map(fn($m) => '[' . $m . ']', array_unique($missing)))
                    . ', which has no value saved. Give the attribute a default number under '
                    . 'Audience → Attributes, or type the number into the button.');
            }
            $metaButtons[] = ['type' => 'PHONE_NUMBER', 'text' => $text,
                              'phone_number' => wa_button_phone_e164($resolved)];
        } else {
            $metaButtons[] = ['type' => 'QUICK_REPLY', 'text' => $text];
        }
    }
    if ($metaButtons) $components[] = ['type' => 'BUTTONS', 'buttons' => $metaButtons];

    return $components;
}

/** One Graph API call. Meta's error bodies are genuinely descriptive, so they're returned intact
 *  rather than being reduced to a status code. */
function wa_graph(string $method, string $url, string $token, ?array $payload = null): array {
    $ch = curl_init($url);
    $opts = [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HTTPHEADER     => ['Content-Type: application/json', 'Authorization: Bearer ' . $token],
        CURLOPT_TIMEOUT        => 25,
    ];
    if ($method !== 'GET') {
        $opts[CURLOPT_CUSTOMREQUEST] = $method;
        if ($payload !== null) $opts[CURLOPT_POSTFIELDS] = json_encode($payload);
    }
    curl_setopt_array($ch, $opts);
    $body   = curl_exec($ch);
    $status = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $err    = curl_error($ch);
    curl_close($ch);

    if ($err !== '') return ['ok' => false, 'error' => "Could not reach Meta: $err", 'data' => null];
    $decoded = json_decode((string)$body, true);
    if ($status < 200 || $status >= 300 || !is_array($decoded)) {
        $e = $decoded['error'] ?? [];
        $msg = $e['error_user_msg'] ?? ($e['message'] ?? (is_string($body) ? mb_substr($body, 0, 300) : "HTTP $status"));
        $code = $e['code'] ?? $status;
        return ['ok' => false, 'error' => "Meta rejected this (code $code): $msg", 'data' => $decoded];
    }
    return ['ok' => true, 'error' => null, 'data' => $decoded];
}

/**
 * A Call button's number with any attribute token replaced by the value it holds.
 *
 * @param string   $raw      what the editor stored, e.g. "[SUPPORT_NUMBER]"
 * @param string[] $unresolved  filled with the names that had no value
 */
function wa_button_phone_resolved(string $raw, array &$unresolved = []): string {
    $out = preg_replace_callback('~\[([A-Za-z0-9_]+)\]~', function ($m) use (&$unresolved) {
        $v = wa_attribute_default($m[1]);
        if ($v === '') { $unresolved[] = $m[1]; return $m[0]; }
        return $v;
    }, $raw);
    return (string)$out;
}

/**
 * The value an attribute holds, for a Call button that was filled in by picking one.
 *
 * WhatsApp does not support a variable in a Call button — the button is approved once and dials the
 * stored value for everyone — so a token submitted as written comes back as
 * "(#192) phone_number is not a valid phone number". That is a real constraint of Meta's and no
 * amount of formatting gets around it.
 *
 * What CAN be done is resolve the token here, at submission, to the number the attribute actually
 * holds. Meta then receives a literal number and approves it, and the template carries whatever
 * [SUPPORT_NUMBER] was set to. The practical difference from typing the number in is the part
 * worth having: the number lives in one place, and changing the attribute and resubmitting moves
 * every template that uses it.
 *
 * Returns '' when the attribute is unknown or has no value, so the caller can say which one rather
 * than letting Meta answer with an array index.
 */
function wa_attribute_default(string $name): string {
    global $conn;
    $n = $conn->real_escape_string(trim($name));
    if ($n === '') return '';
    $r = @$conn->query("SELECT default_value FROM campaign_attributes WHERE name = '$n' LIMIT 1");
    $row = $r ? $r->fetch_assoc() : null;
    return $row ? trim((string)$row['default_value']) : '';
}

/*
 * A Call button number in the form Meta accepts, or '' when it cannot be put in that form.
 *
 * Meta wants E.164: a country code followed by the national number, no spaces, no dashes, no
 * brackets, no leading zero. Anything else comes back as
 *
 *   (#192) Param components[N]['buttons'][M]['phone_number'] is not a valid phone number
 *
 * which is what a template with a plain ten-digit Indian mobile in it produces, and the reason a
 * submission could be refused by all three business accounts in a row: the number was wrong before
 * it left this building, so every account gave the same answer.
 *
 * WHY IT GUESSES A COUNTRY CODE RATHER THAN REFUSING.
 * A ten-digit number with no country code is not ambiguous in practice — it belongs to the country
 * this account sends from, and typing the code is the step people forget, not a decision they were
 * making. WA_BUTTON_DEFAULT_CC is applied only when the number is clearly national: the right
 * length for a local mobile and no + of its own. Anything else is returned empty, and the caller
 * refuses the save with a message, rather than letting Meta decide.
 */
if (!defined('WA_BUTTON_DEFAULT_CC')) define('WA_BUTTON_DEFAULT_CC', '91');

function wa_button_phone_e164(string $raw): string {
    $raw = trim($raw);
    if ($raw === '') return '';

    /*
     * An attribute or a {{n}} placeholder is passed through untouched.
     *
     * It cannot work — a Call button is approved once and dials the stored value for everyone, so
     * Meta answers "(#192) ... is not a valid phone number" — and the editor says so beside the
     * field. But whether to submit it anyway is the author's call, not this function's, and
     * stripping the punctuation out of a token would turn a deliberate choice into a number nobody
     * typed.
     */
    if (strpbrk($raw, '[{') !== false) return $raw;

    $plus = strpos($raw, '+') === 0;
    $d = preg_replace('~[^0-9]+~', '', $raw);
    if ($d === '') return '';

    // 00 is the other way of writing +, and every dialling guide in the world prints it.
    if (!$plus && strpos($d, '00') === 0) { $d = substr($d, 2); $plus = true; }

    if (!$plus) {
        // A single leading zero is the national trunk prefix and is never part of E.164.
        $d = ltrim($d, '0');
        $cc = WA_BUTTON_DEFAULT_CC;
        if (strlen($d) === 10) {
            $d = $cc . $d;                       // a bare national mobile
        } elseif (strpos($d, $cc) === 0 && strlen($d) === strlen($cc) + 10) {
            // already carries the country code, just without the +
        }
    }

    // E.164 allows at most 15 digits, and nothing real is shorter than 8.
    if (strlen($d) < 8 || strlen($d) > 15) return '';
    return '+' . $d;
}

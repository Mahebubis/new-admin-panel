<?php
/*
 * /api/freshdesk/lib/Mailer.php
 *
 * Outbound side of the desk: replies, forwards and auto-acknowledgements, sent
 * through the same SMTP account the mailbox receives on
 * (contact@internshipstudio.com) via PHPMailer.
 *
 * Three things here are not obvious and all three matter:
 *
 *  1. THREADING. Every outgoing message sets its own Message-ID, an In-Reply-To
 *     pointing at the customer's last mail, and a References chain. Together
 *     with the [#IS-nnnnnn] token in the Subject, that is what makes the
 *     customer's reply come back into the SAME ticket instead of opening a new
 *     one. Remove any one of them and threading degrades; remove the token and
 *     it breaks outright for Outlook users.
 *
 *  2. THE SENT COPY. SMTP delivers to the customer but puts nothing in our own
 *     mailbox, so a reply sent from the panel would be invisible in Roundcube.
 *     After a successful send the raw MIME is IMAP-APPENDed to the Sent folder.
 *     This is best-effort by design -- the mail is already delivered, so a
 *     failure to file a copy is logged and ignored, never surfaced as a send
 *     failure.
 *
 *  3. FAILURE IS A STATE, NOT AN EXCEPTION. A failed send is written to
 *     fd_messages with delivery_status='failed' and the SMTP error kept, so the
 *     agent sees their message in the thread marked "not delivered" with a
 *     Retry button -- instead of the text they just typed vanishing.
 */

class FdMailerException extends Exception {}

class FdMailer
{
    private $loaded = false;
    private $loadError = '';

    public function __construct()
    {
        $this->loaded = $this->loadPhpMailer();
    }

    /**
     * PHPMailer is not installed via Composer here; it sits beside the main
     * CIT3 project. Same search order as api/auth/send-otp.php, plus this
     * feature's own vendor dir, so the desk keeps working if the shared copy
     * ever moves.
     */
    private function loadPhpMailer()
    {
        if (class_exists('PHPMailer\\PHPMailer\\PHPMailer')) return true;
        // Same search order as api/auth/send-otp.php, widened by two levels:
        // that file sits one directory shallower than this one, so its relative
        // path resolves elsewhere from here. The absolute path is the one that
        // actually hits in production; the rest keep this working in staging
        // copies and on a future move.
        $paths = array(
            '/home/istudio/public_html/cit3/PHPMailer/src/',
            dirname(__DIR__, 5) . '/PHPMailer/src/',
            dirname(__DIR__, 4) . '/PHPMailer/src/',
            dirname(__DIR__, 3) . '/PHPMailer/src/',
            __DIR__ . '/../vendor/PHPMailer/src/',
        );
        foreach ($paths as $dir) {
            if (@file_exists($dir . 'PHPMailer.php')) {
                require_once $dir . 'Exception.php';
                require_once $dir . 'PHPMailer.php';
                require_once $dir . 'SMTP.php';
                return true;
            }
        }
        $this->loadError = 'PHPMailer not found. Looked in: ' . implode(', ', $paths);
        fd_log('error', $this->loadError);
        return false;
    }

    public function isReady() { return $this->loaded; }
    public function loadError() { return $this->loadError; }

    /**
     * Build a configured PHPMailer instance.
     * @param bool $debug capture the SMTP conversation (Settings > Test connection)
     */
    private function newMailer($debug = false, &$debugLines = null)
    {
        if (!$this->loaded) throw new FdMailerException($this->loadError);

        $mail = new \PHPMailer\PHPMailer\PHPMailer(true);   // true => throw on error
        $mail->isSMTP();
        $mail->Host       = (string)fd_cfg('SMTP_HOST');
        $mail->Port       = fd_cfg_int('SMTP_PORT', 587);
        $mail->SMTPAuth   = true;
        $mail->Username   = (string)fd_cfg('SMTP_USER');
        $mail->Password   = (string)fd_cfg('SMTP_PASS');

        $sec = strtolower((string)fd_cfg('SMTP_SECURITY', 'tls'));
        if ($sec === 'ssl')      $mail->SMTPSecure = 'ssl';
        elseif ($sec === 'tls')  $mail->SMTPSecure = 'tls';
        else                     $mail->SMTPSecure = false;

        $mail->CharSet  = 'UTF-8';
        $mail->Encoding = 'base64';
        $mail->Timeout  = 25;

        /*
         * Shared cPanel mailhosts routinely present a certificate for the
         * server hostname rather than mail.<domain>, which makes PHPMailer's
         * default verification fail with an opaque "stream_socket_enable_crypto
         * failed". Verification is relaxed only when the operator has said the
         * cert cannot be trusted (IMAP_VERIFY_PEER=0), matching the IMAP side.
         */
        if (!fd_cfg_int('IMAP_VERIFY_PEER', 0)) {
            $mail->SMTPOptions = array('ssl' => array(
                'verify_peer'       => false,
                'verify_peer_name'  => false,
                'allow_self_signed' => true,
            ));
        }

        if ($debug) {
            $mail->SMTPDebug = 2;
            if (!is_array($debugLines)) $debugLines = array();
            // The closure appends into the caller's array through the reference
            // parameter directly. Assigning a NEW array to $debugLines here
            // would silently detach it from the caller and the trace would come
            // back empty -- which is exactly when you need it most.
            $mail->Debugoutput = function ($str, $level) use (&$debugLines) {
                // The AUTH exchange contains the base64 password. Never keep it.
                $line = preg_replace('/((?:AUTH|PASS|USER)\b[^\r\n]*)/i', 'AUTH ***', trim($str));
                $debugLines[] = $line;
            };
        }

        $mail->setFrom((string)fd_cfg('FROM_EMAIL'), (string)fd_cfg('FROM_NAME'));
        $replyTo = (string)fd_cfg('REPLY_TO', '');
        if ($replyTo !== '') $mail->addReplyTo($replyTo, (string)fd_cfg('FROM_NAME'));

        return $mail;
    }

    /**
     * Send a reply / forward / new mail on a ticket and record it.
     *
     * @param array $opts
     *   ticket_id   (int, required)
     *   type        'reply' | 'forward' | 'new' | 'auto_ack'
     *   body_html   (string)  agent's message, already sanitised upstream
     *   to          (array|string) recipients; defaults to the ticket requester
     *   cc, bcc     (array|string)
     *   subject     (string)  optional override
     *   attachment_ids (array) ids in fd_attachments staged by fd_attachments.php
     *   agent       ['id'=>, 'name'=>]
     *   include_signature (bool, default true)
     *   quote_history     (bool, default true for replies)
     *
     * @return array ['message_id'=>int,'sent'=>bool,'error'=>string|null]
     */
    public function sendTicketMessage($opts)
    {
        $ticketId = (int)$opts['ticket_id'];
        $ticket = fd_query_one("SELECT * FROM fd_tickets WHERE id = ?", 'i', array($ticketId));
        if (!$ticket) throw new FdMailerException('Ticket #' . $ticketId . ' not found.');

        $type   = isset($opts['type']) ? $opts['type'] : 'reply';
        $agent  = isset($opts['agent']) ? $opts['agent'] : array('id' => null, 'name' => 'Agent');
        $bodyIn = isset($opts['body_html']) ? (string)$opts['body_html'] : '';

        // ---- recipients ---------------------------------------------------
        $to  = $this->normalizeAddressList(isset($opts['to']) ? $opts['to'] : $ticket['requester_email']);
        $cc  = $this->normalizeAddressList(isset($opts['cc']) ? $opts['cc'] : array());
        $bcc = $this->normalizeAddressList(isset($opts['bcc']) ? $opts['bcc'] : array());
        if (empty($to)) throw new FdMailerException('No valid recipient address.');

        // Never mail a contact who has been blocked -- that is the whole point
        // of blocking them, and a stray auto-reply would undo it.
        $blocked = fd_query_one("SELECT email FROM fd_contacts WHERE email = ? AND is_blocked = 1", 's', array($to[0]));
        if ($blocked && $type === 'auto_ack') {
            throw new FdMailerException('Recipient is blocked; auto-reply suppressed.');
        }

        // ---- subject with the threading token ------------------------------
        $subject = isset($opts['subject']) && trim($opts['subject']) !== ''
            ? trim($opts['subject'])
            : (($type === 'forward' ? 'Fwd: ' : 'Re: ') . fd_normalize_subject($ticket['subject']));
        if (fd_parse_ticket_token($subject) === null) {
            $subject .= ' ' . fd_ticket_token($ticketId);
        }

        // ---- threading headers ---------------------------------------------
        $last = fd_query_one(
            "SELECT message_id, references_hdr FROM fd_messages
             WHERE ticket_id = ? AND message_id IS NOT NULL AND direction <> 'note'
             ORDER BY id DESC LIMIT 1",
            'i', array($ticketId)
        );
        $ourMessageId = fd_generate_message_id();
        $inReplyTo = $last && !empty($last['message_id']) ? $last['message_id'] : null;
        $references = array();
        if ($last && !empty($last['references_hdr'])) {
            $references = preg_split('/\s+/', trim($last['references_hdr']));
        }
        if ($inReplyTo) $references[] = $inReplyTo;
        // References can grow without bound on a long thread; the tail is what
        // clients actually use for matching.
        $references = array_values(array_unique(array_filter($references)));
        if (count($references) > 20) $references = array_slice($references, -20);

        // ---- body ------------------------------------------------------------
        $includeSig = !isset($opts['include_signature']) || $opts['include_signature'];
        $bodyHtml = $bodyIn;
        if ($includeSig) {
            $sig = (string)fd_cfg('EMAIL_SIGNATURE', '');
            if ($sig !== '') {
                $bodyHtml .= '<br><br><div class="fd-signature">' . nl2br(htmlspecialchars($sig, ENT_QUOTES, 'UTF-8')) . '</div>';
            }
        }
        $quote = !isset($opts['quote_history']) ? ($type !== 'auto_ack') : (bool)$opts['quote_history'];
        if ($quote) {
            $bodyHtml .= $this->buildQuotedHistory($ticketId);
        }
        $bodyText = fd_html_to_text($bodyHtml);

        // ---- attachments -----------------------------------------------------
        $attachmentIds = isset($opts['attachment_ids']) ? (array)$opts['attachment_ids'] : array();
        $attachments = array();
        if (!empty($attachmentIds)) {
            $ids = array_map('intval', $attachmentIds);
            $place = implode(',', array_fill(0, count($ids), '?'));
            $attachments = fd_query(
                "SELECT * FROM fd_attachments WHERE id IN ($place) AND ticket_id = ?",
                str_repeat('i', count($ids)) . 'i', array_merge($ids, array($ticketId))
            );
        }

        // ---- record BEFORE sending ------------------------------------------
        /*
         * The row is written as 'queued' first, on purpose. If SMTP hangs and
         * PHP is killed mid-send, the agent's text still exists and the thread
         * shows a message stuck in "Sending" -- recoverable. Writing it only
         * after a successful send means a timeout silently destroys whatever
         * they typed, which is the single most infuriating helpdesk bug there
         * is.
         */
        $dbMessageId = fd_exec(
            "INSERT INTO fd_messages
                (ticket_id, direction, msg_type, from_name, from_email, to_emails, cc_emails, bcc_emails,
                 subject, body_html, body_text, snippet, message_id, in_reply_to, references_hdr,
                 has_attachments, attachment_count, delivery_status, sent_by_user_id, sent_by_name,
                 message_date, is_auto_reply, created_at)
             VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?, 'queued', ?,?, NOW(), ?, NOW())",
            'issssssssssssssiiisi',
            array(
                $ticketId, 'outbound', $type,
                (string)fd_cfg('FROM_NAME'), (string)fd_cfg('FROM_EMAIL'),
                json_encode($to), json_encode($cc), json_encode($bcc),
                fd_snippet($subject, 490), $bodyIn, fd_html_to_text($bodyIn), fd_snippet(fd_html_to_text($bodyIn), 250),
                $ourMessageId, $inReplyTo,
                !empty($references) ? implode(' ', $references) : null,
                !empty($attachments) ? 1 : 0, count($attachments),
                isset($agent['id']) ? (int)$agent['id'] : null,
                isset($agent['name']) ? $agent['name'] : 'Agent',
                $type === 'auto_ack' ? 1 : 0,
            ),
            true
        );

        // Re-point staged attachments at the message they were actually sent on.
        if (!empty($attachments)) {
            $ids = array_map('intval', $attachmentIds);
            $place = implode(',', array_fill(0, count($ids), '?'));
            fd_exec("UPDATE fd_attachments SET message_id = ? WHERE id IN ($place)",
                    'i' . str_repeat('i', count($ids)), array_merge(array((int)$dbMessageId), $ids));
        }

        // ---- send -------------------------------------------------------------
        $error = null; $sent = false; $rawMime = null;
        try {
            $mail = $this->newMailer();
            foreach ($to as $addr)  $mail->addAddress($addr);
            foreach ($cc as $addr)  $mail->addCC($addr);
            foreach ($bcc as $addr) $mail->addBCC($addr);

            $mail->Subject = $subject;
            $mail->MessageID = $ourMessageId;
            if ($inReplyTo)          $mail->addCustomHeader('In-Reply-To', $inReplyTo);
            if (!empty($references)) $mail->addCustomHeader('References', implode(' ', $references));
            // Tells well-behaved auto-responders not to answer this message,
            // which is half of the auto-reply loop protection (the other half
            // is MimeParser::detectAutoReply on the way in).
            $mail->addCustomHeader('X-Auto-Response-Suppress', 'All');
            $mail->addCustomHeader('X-Freshdesk-Ticket', (string)$ticketId);
            if ($type === 'auto_ack') $mail->addCustomHeader('Auto-Submitted', 'auto-replied');

            /*
             * Attachments live in S3, so the bytes are fetched and added with
             * addStringAttachment rather than addAttachment(path). A file that
             * cannot be retrieved is logged and SKIPPED, never fatal: sending
             * the reply without one attachment is far better than failing the
             * send and leaving the customer with no answer at all. The agent
             * sees the warning in freshdesk.log and the thread shows what went.
             */
            foreach ($attachments as $a) {
                $bytes = fd_storage_get_bytes($a);
                if ($bytes === null || $bytes === '') {
                    fd_log('warn', 'Attachment could not be read, not sent', array(
                        'id' => $a['id'], 'storage' => isset($a['storage']) ? $a['storage'] : 'local',
                    ));
                    continue;
                }
                $mail->addStringAttachment($bytes, $a['filename'], 'base64',
                                           $a['mime_type'] ?: 'application/octet-stream');
            }

            $mail->isHTML(true);
            $mail->Body    = $bodyHtml;
            // A plain-text alternative is not decoration: without it many spam
            // filters score an HTML-only mail from a support desk as bulk.
            $mail->AltBody = $bodyText;

            // preSend() builds the MIME without transmitting, so the exact bytes
            // can be captured for the Sent-folder copy.
            if (!$mail->preSend()) {
                throw new FdMailerException($mail->ErrorInfo ?: 'Message could not be assembled.');
            }
            $rawMime = $mail->getSentMIMEMessage();

            if (!$mail->postSend()) {
                throw new FdMailerException($mail->ErrorInfo ?: 'SMTP refused the message.');
            }
            $sent = true;
        } catch (Throwable $e) {
            $error = $this->friendlySmtpError($e->getMessage());
            fd_log('error', 'Send failed on ticket #' . $ticketId . ': ' . $e->getMessage());
        }

        // ---- record the outcome -----------------------------------------------
        if ($sent) {
            fd_exec("UPDATE fd_messages SET delivery_status = 'sent', delivery_error = NULL WHERE id = ?",
                    'i', array((int)$dbMessageId));
            $this->afterSend($ticket, (int)$dbMessageId, $type, $agent);
            if ($rawMime) $this->fileInSentFolder($rawMime);
        } else {
            fd_exec("UPDATE fd_messages SET delivery_status = 'failed', delivery_error = ?, retry_count = retry_count + 1 WHERE id = ?",
                    'si', array($error, (int)$dbMessageId));
        }

        fd_recount_ticket($ticketId);

        return array('message_id' => (int)$dbMessageId, 'sent' => $sent, 'error' => $error,
                     'rfc_message_id' => $ourMessageId, 'subject' => $subject);
    }

    /**
     * Ticket bookkeeping after a successful outbound message: stop the
     * first-response clock, flip the response status, clear the unread badge.
     */
    private function afterSend($ticket, $dbMessageId, $type, $agent)
    {
        $ticketId = (int)$ticket['id'];

        // The first-response clock stops on the first genuine agent reply.
        // An auto-acknowledgement must NOT stop it -- counting a robot as the
        // first response is how a desk reports a perfect SLA while every
        // customer waits two days for a human.
        $stopsClock = ($type !== 'auto_ack') && empty($ticket['first_response_at']);

        $status = $ticket['status'];
        if ($status === 'New') $status = 'Open';
        if ($type !== 'auto_ack' && in_array($status, array('Open', 'New'), true)) $status = 'Pending';

        if ($stopsClock) {
            fd_exec("UPDATE fd_tickets
                     SET first_response_at = NOW(), status = ?, response_status = 'Agent responded',
                         customer_replied = 0, unread_count = 0,
                         last_message_at = NOW(), last_agent_at = NOW(), updated_at = NOW()
                     WHERE id = ?",
                    'si', array($status, $ticketId));
        } else {
            fd_exec("UPDATE fd_tickets
                     SET status = ?, response_status = ?, customer_replied = 0, unread_count = 0,
                         last_message_at = NOW(), last_agent_at = NOW(), updated_at = NOW()
                     WHERE id = ?",
                    'ssi', array($status, $type === 'auto_ack' ? $ticket['response_status'] : 'Agent responded', $ticketId));
        }

        fd_sla_refresh($ticketId);

        fd_emit('message-sent', array(
            'ticket_id'  => $ticketId,
            'message_id' => $dbMessageId,
            'type'       => $type,
        ), array(
            'ticket_id'  => $ticketId,
            'message_id' => $dbMessageId,
            'actor_type' => 'agent',
            'actor_id'   => isset($agent['id']) ? (int)$agent['id'] : null,
            'actor_name' => isset($agent['name']) ? $agent['name'] : 'Agent',
            'summary'    => ($type === 'forward' ? 'Forwarded' : 'Replied') . ' on #' . $ticketId,
        ));
    }

    /**
     * APPEND the sent message to the mailbox's Sent folder.
     * Best-effort: the customer already has the mail, so nothing here may throw
     * back into the send path.
     */
    private function fileInSentFolder($rawMime)
    {
        $folder = trim((string)fd_cfg('IMAP_SENT_FOLDER', ''));
        if ($folder === '') return;
        try {
            $imap = new ImapClient();
            $imap->login();
            $ok = $imap->appendMessage($folder, $rawMime, '\\Seen');
            $imap->close();
            if (!$ok) fd_log('warn', 'Sent-folder APPEND was rejected', array('folder' => $folder));
        } catch (Throwable $e) {
            fd_log('warn', 'Could not file a copy in ' . $folder . ': ' . $e->getMessage());
        }
    }

    /** The collapsed "On <date>, <name> wrote:" block appended to replies. */
    /*
     * Quote ONE previous message, and only the part its sender actually wrote.
     *
     * This used to embed the last three messages verbatim -- and each of those
     * already carried its own three, so every reply multiplied the thread.
     * After a handful of exchanges the stored body, the outgoing mail and the
     * panel's rendering of it were all enormous. Gmail and Freshdesk quote
     * exactly one message; so do we now, with its own quoted chain stripped
     * first by fd_split_quoted_html().
     */
    private function buildQuotedHistory($ticketId, $limit = 1)
    {
        $rows = fd_query(
            "SELECT direction, from_name, from_email, body_html, body_text, message_date, created_at
             FROM fd_messages
             WHERE ticket_id = ? AND direction <> 'note'
             ORDER BY id DESC LIMIT ?",
            'ii', array((int)$ticketId, (int)$limit)
        );
        if (empty($rows)) return '';
        $rows = array_reverse($rows);

        // The class is what fd_split_quoted_html() looks for when this comes
        // back to us on the next reply -- an explicit marker beats a heuristic.
        $html = '<br><br><div class="fd-quoted-history" style="border-left:2px solid #d0d7de;padding-left:12px;color:#57606a;font-size:13px">';
        foreach ($rows as $r) {
            $when = !empty($r['message_date']) ? $r['message_date'] : $r['created_at'];
            $who  = $r['from_name'] ? $r['from_name'] : $r['from_email'];
            $split = fd_split_quoted_html((string)$r['body_html']);
            $body = $split['visible'] !== ''
                  ? $split['visible']
                  : '<div style="white-space:pre-wrap">' . htmlspecialchars(fd_strip_quoted_text((string)$r['body_text']), ENT_QUOTES, 'UTF-8') . '</div>';
            $html .= '<p style="margin:10px 0 4px"><b>On ' . htmlspecialchars(date('D, j M Y \a\t g:i a', strtotime($when)), ENT_QUOTES, 'UTF-8')
                   . ', ' . htmlspecialchars((string)$who, ENT_QUOTES, 'UTF-8') . ' wrote:</b></p>'
                   // No campaign tracking in what we forward: the recipient's
                   // clicks would be counted as the original student's.
                   . fd_sanitize_html(fd_untrack_own_links($body), false);
        }
        return $html . '</div>';
    }

    /** Accept a string, comma list, or array; return unique valid addresses. */
    private function normalizeAddressList($value)
    {
        if ($value === null || $value === '') return array();
        $items = is_array($value) ? $value : preg_split('/[,;\s]+/', (string)$value);
        $out = array();
        foreach ($items as $item) {
            if (is_array($item) && isset($item['email'])) $item = $item['email'];
            $item = trim((string)$item, " \t<>\"'");
            if ($item === '') continue;
            if (!filter_var($item, FILTER_VALIDATE_EMAIL)) {
                // Tolerate "Name <a@b.com>" pasted straight into the To field.
                if (preg_match('/<([^>]+)>/', $item, $m) && filter_var(trim($m[1]), FILTER_VALIDATE_EMAIL)) {
                    $item = trim($m[1]);
                } else {
                    continue;
                }
            }
            $out[strtolower($item)] = strtolower($item);
        }
        return array_values($out);
    }

    /**
     * SMTP errors are famously unhelpful ("SMTP connect() failed"). Translate the
     * ones that actually happen into something an admin can act on, and keep the
     * original text appended so nothing is lost.
     */
    private function friendlySmtpError($raw)
    {
        $r = strtolower($raw);
        if (strpos($r, 'could not authenticate') !== false || strpos($r, '535') !== false) {
            return 'SMTP rejected the username/password. Check Settings > Email (this must be the mailbox password). Original: ' . $raw;
        }
        if (strpos($r, 'smtp connect() failed') !== false || strpos($r, 'connection refused') !== false) {
            return 'Could not connect to ' . fd_cfg('SMTP_HOST') . ':' . fd_cfg_int('SMTP_PORT', 587)
                 . '. Shared hosts often block outbound SMTP -- ask the provider to open the port. Original: ' . $raw;
        }
        if (strpos($r, 'certificate') !== false || strpos($r, 'enable_crypto') !== false) {
            return 'TLS handshake with the mail server failed. Try port 465 with security=ssl, or 587 with tls. Original: ' . $raw;
        }
        if (strpos($r, 'relay') !== false || strpos($r, '550') !== false) {
            return 'The mail server refused to relay this message -- the From address must match the authenticated mailbox. Original: ' . $raw;
        }
        if (strpos($r, 'quota') !== false || strpos($r, '452') !== false || strpos($r, 'rate') !== false) {
            return 'The mail server is rate-limiting or the mailbox is over quota. The message stays queued and can be retried. Original: ' . $raw;
        }
        if (strpos($r, 'phpmailer not found') !== false) {
            return $raw . ' -- upload PHPMailer to /home/istudio/public_html/cit3/PHPMailer/src/.';
        }
        return $raw;
    }

    /* ------------------------------------------------------------- testing -- */

    /** Settings > Send Test Email. Returns [ok, message, debug[]]. */
    /**
     * A plain outbound email that is NOT part of a ticket conversation.
     *
     * Tagged notifications go to your own staff, so they must not be threaded
     * into the customer's ticket, stored as a message on it, or filed in the
     * Sent folder as though the customer had been written to. Everything
     * sendTicketMessage() does deliberately is wrong here.
     *
     * @return array{ok:bool,message:string}
     */
    public function sendPlain($to, $subject, $html, $cc = array(), $bcc = array())
    {
        try {
            $to  = $this->normalizeAddressList($to);
            $cc  = $this->normalizeAddressList($cc);
            $bcc = $this->normalizeAddressList($bcc);
            if (empty($to)) return array('ok' => false, 'message' => 'No valid recipient address.');

            $mail = $this->newMailer();
            foreach ($to as $a)  $mail->addAddress($a);
            foreach ($cc as $a)  $mail->addCC($a);
            foreach ($bcc as $a) $mail->addBCC($a);
            $mail->Subject = $subject;
            $mail->isHTML(true);
            $mail->Body    = $html;
            $mail->AltBody = trim(html_entity_decode(strip_tags($html), ENT_QUOTES, 'UTF-8'));
            $mail->send();
            return array('ok' => true, 'message' => 'Sent to ' . implode(', ', $to));
        } catch (Throwable $e) {
            return array('ok' => false, 'message' => $this->friendlySmtpError($e->getMessage()));
        }
    }

    public function sendTest($toEmail)
    {
        $debug = array();
        try {
            $mail = $this->newMailer(true, $debug);
            $mail->addAddress($toEmail);
            $mail->Subject = 'Freshdesk test email ' . date('H:i:s');
            $mail->isHTML(true);
            $mail->Body = '<p>This is a test from the Internship Studio helpdesk.</p>'
                        . '<p>If you are reading this, outbound mail is working: host <b>'
                        . htmlspecialchars((string)fd_cfg('SMTP_HOST'), ENT_QUOTES, 'UTF-8') . '</b>, port '
                        . fd_cfg_int('SMTP_PORT', 587) . '.</p>';
            $mail->AltBody = 'Test from the Internship Studio helpdesk.';
            $mail->send();
            return array('ok' => true, 'message' => 'Test email delivered to ' . $toEmail, 'debug' => $debug);
        } catch (Throwable $e) {
            return array('ok' => false, 'message' => $this->friendlySmtpError($e->getMessage()), 'debug' => $debug);
        }
    }
}

/**
 * Auto-acknowledgement on a brand-new ticket.
 *
 * Guarded three ways, because an auto-responder that answers the wrong thing is
 * far worse than no auto-responder:
 *   - off unless FD_AUTO_ACK is on,
 *   - never in reply to another robot (out-of-office, mailing list, bounce),
 *   - never twice on the same ticket.
 */
function fd_send_auto_ack($ticketId, $parsed)
{
    if (!fd_cfg_int('AUTO_ACK', 0)) return false;
    if (!empty($parsed['is_auto_reply']) || !empty($parsed['is_bounce'])) {
        fd_log('debug', 'Auto-ack suppressed (robot sender)', array('ticket' => $ticketId));
        return false;
    }
    $already = fd_query_one("SELECT id FROM fd_messages WHERE ticket_id = ? AND is_auto_reply = 1 LIMIT 1",
                            'i', array((int)$ticketId));
    if ($already) return false;

    $ticket = fd_query_one("SELECT * FROM fd_tickets WHERE id = ?", 'i', array((int)$ticketId));
    if (!$ticket) return false;

    $template = (string)fd_cfg('AUTO_ACK_BODY', '');
    if ($template === '') {
        $template = '<p>Hi {{name}},</p>'
            . '<p>Thanks for writing in. We have received your message and created ticket <b>{{ticket}}</b> for it. '
            . 'Our team will get back to you shortly.</p>'
            . '<p>You can simply reply to this email to add more details -- it will reach the same ticket.</p>'
            . '<p>-- Internship Studio Support</p>';
    }
    $body = str_replace(
        array('{{name}}', '{{ticket}}', '{{subject}}'),
        array(htmlspecialchars(explode(' ', $ticket['requester_name'])[0], ENT_QUOTES, 'UTF-8'),
              '#' . $ticketId,
              htmlspecialchars($ticket['subject'], ENT_QUOTES, 'UTF-8')),
        $template
    );

    try {
        $mailer = new FdMailer();
        $r = $mailer->sendTicketMessage(array(
            'ticket_id'         => (int)$ticketId,
            'type'              => 'auto_ack',
            'body_html'         => $body,
            'quote_history'     => false,
            'include_signature' => false,
            'agent'             => array('id' => null, 'name' => 'Auto-reply'),
        ));
        return !empty($r['sent']);
    } catch (Throwable $e) {
        fd_log('warn', 'Auto-ack failed: ' . $e->getMessage(), array('ticket' => $ticketId));
        return false;
    }
}

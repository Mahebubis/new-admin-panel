<?php
/*
 * /api/freshdesk/fd_contacts.php
 *
 *   action=list    &page &per_page &search &sort   -> Customers page
 *   action=get     &id | &email                    -> one customer + their tickets
 *   action=update  &id  &name &phone &notes &college &program &enroll_id
 *   action=block   &id &value=1|0                  -> stop mail from this sender
 *   action=merge   &primary_id &ids[]              -> same person, two addresses
 *   action=export  &search                         -> CSV of the current filter
 *
 * A contact is created automatically the first time an address writes in, so
 * this endpoint is mostly about enriching and correcting those rows rather than
 * creating them.
 */

require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../middleware/auth.php';
require_once __DIR__ . '/lib/config.php';
require_once __DIR__ . '/lib/Helpers.php';
require_once __DIR__ . '/lib/schema.php';
require_once __DIR__ . '/lib/Sla.php';
require_once __DIR__ . '/lib/Pusher.php';
require_once __DIR__ . '/lib/TicketStore.php';

$jwt = require_jwt();
require_permission('freshdesk', $jwt);
fd_install_error_handlers();
fd_ensure_schema();

$ME = array('id' => isset($jwt['user_id']) ? (int)$jwt['user_id'] : null,
            'name' => isset($jwt['name']) ? $jwt['name'] : 'Agent');

function fd_shape_contact($c, $extra = array())
{
    $meta = json_decode((string)$c['meta'], true);
    return array_merge(array(
        'id'           => (int)$c['id'],
        'name'         => $c['name'] ?: fd_display_name('', $c['email']),
        'email'        => $c['email'],
        'phone'        => $c['phone'],
        'userId'       => $c['user_id'] !== null ? (int)$c['user_id'] : null,
        'registered'   => (bool)$c['is_registered'],
        'blocked'      => (bool)$c['is_blocked'],
        'college'      => $c['college'],
        'program'      => $c['program'],
        'enrollId'     => $c['enroll_id'],
        'totalTickets' => (int)$c['tickets_count'],
        'firstSeen'    => $c['first_seen_at'],
        'lastSeen'     => $c['last_seen_at'],
        'joined'       => $c['first_seen_at'] ? fd_relative_time($c['first_seen_at']) : '',
        'lastSeenAgo'  => $c['last_seen_at'] ? fd_relative_time($c['last_seen_at']) : '',
        'notes'        => $c['notes'],
        'meta'         => is_array($meta) ? $meta : array(),
    ), $extra);
}

$action = fd_str('action', 'list');
$GLOBALS['FD_ACTION'] = $action;

/* ------------------------------------------------------------------ list -- */
if ($action === 'list') {
    $page    = max(1, fd_int('page', 1));
    $perPage = max(1, min(100, fd_int('per_page', 25)));
    $search  = fd_str('search', '');
    $sort    = fd_str('sort', 'recent');

    $where = array('1=1'); $types = ''; $params = array();
    if ($search !== '') {
        $where[] = "(c.name LIKE ? OR c.email LIKE ? OR c.phone LIKE ? OR c.enroll_id LIKE ?)";
        $like = '%' . $search . '%';
        $types .= 'ssss';
        for ($i = 0; $i < 4; $i++) $params[] = $like;
    }
    if (fd_bool('registered_only', false)) $where[] = 'c.is_registered = 1';
    if (fd_bool('blocked_only', false))    $where[] = 'c.is_blocked = 1';

    $whereSql = 'WHERE ' . implode(' AND ', $where);
    $orderMap = array(
        'recent'  => 'c.last_seen_at DESC',
        'name'    => 'c.name ASC',
        'tickets' => 'c.tickets_count DESC',
        'oldest'  => 'c.first_seen_at ASC',
    );
    $order = isset($orderMap[$sort]) ? $orderMap[$sort] : $orderMap['recent'];

    $cnt = fd_query_one("SELECT COUNT(*) AS c FROM fd_contacts c $whereSql", $types, $params);
    $total = $cnt ? (int)$cnt['c'] : 0;
    $offset = ($page - 1) * $perPage;

    $rows = fd_query("SELECT c.* FROM fd_contacts c $whereSql ORDER BY $order, c.id DESC LIMIT $perPage OFFSET $offset",
                     $types, $params);

    // Open-ticket count per contact, in one query rather than one per row.
    $openMap = array();
    if (!empty($rows)) {
        $emails = array_map(function ($r) { return $r['email']; }, $rows);
        $place = implode(',', array_fill(0, count($emails), '?'));
        $op = fd_query("SELECT requester_email, COUNT(*) AS c FROM fd_tickets
                        WHERE requester_email IN ($place) AND status NOT IN ('Resolved','Closed')
                          AND is_trash = 0 AND is_spam = 0
                        GROUP BY requester_email", str_repeat('s', count($emails)), $emails);
        foreach ($op as $o) $openMap[$o['requester_email']] = (int)$o['c'];
    }

    $out = array();
    foreach ($rows as $c) {
        $out[] = fd_shape_contact($c, array('openTickets' => isset($openMap[$c['email']]) ? $openMap[$c['email']] : 0));
    }

    api_success(array(
        'contacts' => $out, 'total' => $total, 'page' => $page,
        'per_page' => $perPage, 'pages' => (int)ceil($total / $perPage),
    ), 'OK');
}

/* ------------------------------------------------------------ recipients -- */
/*
 * Address suggestions for the To / Cc / Bcc fields.
 *
 * Sourced from fd_contacts -- every address that has ever written in or been
 * written to -- so an agent typing three letters gets the real address instead
 * of retyping it and risking a typo that bounces.
 *
 * Deliberately NOT the platform's whole user table: this is a mail field, and
 * the right suggestions are people this desk actually corresponds with. Blocked
 * contacts are excluded; suggesting someone you have blocked is a trap.
 */
if ($action === 'recipients') {
    $q = fd_str('q', '');
    if (strlen($q) < 2) api_success(array('recipients' => array()), 'OK');

    $like = '%' . $q . '%';
    $rows = fd_query(
        "SELECT email, name, tickets_count
         FROM fd_contacts
         WHERE is_blocked = 0 AND email <> '' AND (email LIKE ? OR name LIKE ?)
         ORDER BY
           -- A prefix match is what the agent almost always meant.
           CASE WHEN email LIKE ? THEN 0 WHEN name LIKE ? THEN 1 ELSE 2 END,
           tickets_count DESC,
           last_seen_at DESC
         LIMIT 8",
        'ssss', array($like, $like, $q . '%', $q . '%')
    );

    $out = array();
    foreach ($rows as $r) {
        $out[] = array(
            'email' => $r['email'],
            'name'  => $r['name'] !== null && $r['name'] !== '' ? $r['name'] : fd_display_name('', $r['email']),
            'tickets' => (int)$r['tickets_count'],
        );
    }
    api_success(array('recipients' => $out), 'OK');
}

/* ------------------------------------------------------------------- get -- */
if ($action === 'get') {
    $id = fd_int('id', 0);
    $email = fd_str('email', '');
    $c = $id > 0
        ? fd_query_one("SELECT * FROM fd_contacts WHERE id = ?", 'i', array($id))
        : fd_query_one("SELECT * FROM fd_contacts WHERE email = ?", 's', array(fd_norm_email($email)));
    if (!$c) api_error('Customer not found', 404);

    $tickets = fd_query("SELECT id, subject, status, priority, category, sla_status, created_at, last_message_at, unread_count
                         FROM fd_tickets WHERE requester_email = ? AND is_trash = 0
                         ORDER BY last_message_at DESC LIMIT 100", 's', array($c['email']));
    foreach ($tickets as &$t) {
        $t['id'] = (int)$t['id'];
        $t['created'] = fd_relative_time($t['created_at']);
        $t['lastActivity'] = fd_relative_time($t['last_message_at'] ?: $t['created_at']);
        $t['newReplies'] = (int)$t['unread_count'];
    }
    unset($t);

    $stats = fd_query_one("SELECT
            COUNT(*) AS total,
            SUM(CASE WHEN status IN ('Resolved','Closed') THEN 1 ELSE 0 END) AS resolved,
            SUM(CASE WHEN status NOT IN ('Resolved','Closed') THEN 1 ELSE 0 END) AS openCount,
            MIN(created_at) AS firstTicket, MAX(last_message_at) AS lastTicket
        FROM fd_tickets WHERE requester_email = ? AND is_trash = 0", 's', array($c['email']));

    $activity = fd_query("SELECT a.id, a.event, a.actor_name, a.summary, a.ticket_id, a.created_at
                          FROM fd_activity a
                          INNER JOIN fd_tickets t ON t.id = a.ticket_id
                          WHERE t.requester_email = ? ORDER BY a.id DESC LIMIT 25", 's', array($c['email']));
    foreach ($activity as &$a) { $a['ago'] = fd_relative_time($a['created_at']); }
    unset($a);

    api_success(array(
        'contact'  => fd_shape_contact($c),
        'tickets'  => $tickets,
        'stats'    => $stats,
        'activity' => $activity,
    ), 'OK');
}

/* ---------------------------------------------------------------- update -- */
if ($action === 'update') {
    $id = fd_int('id', 0);
    if ($id <= 0) api_error('Customer id is required', 400);
    $c = fd_query_one("SELECT * FROM fd_contacts WHERE id = ?", 'i', array($id));
    if (!$c) api_error('Customer not found', 404);

    $fields = array('name' => 'name', 'phone' => 'phone', 'notes' => 'notes',
                    'college' => 'college', 'program' => 'program', 'enroll_id' => 'enroll_id');
    $sets = array(); $types = ''; $params = array();
    $input = fd_input();
    foreach ($fields as $in => $col) {
        if (!array_key_exists($in, $input)) continue;
        $sets[] = "$col = ?"; $types .= 's'; $params[] = is_scalar($input[$in]) ? trim((string)$input[$in]) : null;
    }
    if (array_key_exists('meta', $input)) {
        $meta = is_array($input['meta']) ? $input['meta'] : json_decode((string)$input['meta'], true);
        if (is_array($meta)) { $sets[] = 'meta = ?'; $types .= 's'; $params[] = json_encode($meta); }
    }
    if (empty($sets)) api_error('Nothing to update', 400);

    $params[] = $id; $types .= 'i';
    fd_exec("UPDATE fd_contacts SET " . implode(', ', $sets) . " WHERE id = ?", $types, $params);

    // Name/phone are denormalised onto tickets for the list view; keep them in
    // step or the list keeps showing the old name after an agent fixes it.
    if (array_key_exists('name', $input) || array_key_exists('phone', $input)) {
        $fresh = fd_query_one("SELECT name, phone, email FROM fd_contacts WHERE id = ?", 'i', array($id));
        fd_exec("UPDATE fd_tickets SET requester_name = ?, requester_phone = ? WHERE requester_email = ?",
                'sss', array($fresh['name'], $fresh['phone'], $fresh['email']));
    }

    api_success(array('contact' => fd_shape_contact(fd_query_one("SELECT * FROM fd_contacts WHERE id = ?", 'i', array($id)))),
                'Customer updated');
}

/* ----------------------------------------------------------------- block -- */
if ($action === 'block') {
    $id = fd_int('id', 0);
    $value = fd_bool('value', true) ? 1 : 0;
    $c = fd_query_one("SELECT * FROM fd_contacts WHERE id = ?", 'i', array($id));
    if (!$c) api_error('Customer not found', 404);

    fd_exec("UPDATE fd_contacts SET is_blocked = ? WHERE id = ?", 'ii', array($value, $id));

    /*
     * Blocking is enforced on the OUTBOUND side (FdMailer refuses auto-replies)
     * and by moving their existing open tickets to spam. Inbound mail still
     * arrives -- we cannot stop a stranger sending email -- but it stops
     * consuming an agent's attention and stops the desk answering back.
     */
    if ($value) {
        fd_exec("UPDATE fd_tickets SET is_spam = 1, updated_at = NOW()
                 WHERE requester_email = ? AND status NOT IN ('Resolved','Closed')", 's', array($c['email']));
    }

    fd_emit($value ? 'contact-blocked' : 'contact-unblocked', array('contact_id' => $id, 'email' => $c['email']),
            array('actor_type' => 'agent', 'actor_id' => $ME['id'], 'actor_name' => $ME['name'],
                  'summary' => $ME['name'] . ($value ? ' blocked ' : ' unblocked ') . $c['email']));

    api_success(array('blocked' => (bool)$value), $value ? 'Sender blocked' : 'Sender unblocked');
}

/* ----------------------------------------------------------------- merge -- */
if ($action === 'merge') {
    $primaryId = fd_int('primary_id', 0);
    $ids = array_values(array_diff(array_map('intval', fd_arr('ids', array())), array($primaryId)));
    if ($primaryId <= 0 || empty($ids)) api_error('Pick a primary customer and at least one duplicate', 400);

    $p = fd_query_one("SELECT * FROM fd_contacts WHERE id = ?", 'i', array($primaryId));
    if (!$p) api_error('Primary customer not found', 404);

    $moved = 0;
    foreach ($ids as $id) {
        $c = fd_query_one("SELECT * FROM fd_contacts WHERE id = ?", 'i', array($id));
        if (!$c) continue;
        /*
         * Tickets keep their ORIGINAL requester_email -- that is the address the
         * customer actually wrote from and the address a reply must go back to.
         * Only the contact_id is repointed, so both addresses now resolve to one
         * customer record without breaking any thread's reply-to.
         */
        fd_exec("UPDATE fd_tickets SET contact_id = ? WHERE contact_id = ?", 'ii', array($primaryId, $id));
        fd_exec("DELETE FROM fd_contacts WHERE id = ?", 'i', array($id));
        $moved++;
    }

    $cnt = fd_query_one("SELECT COUNT(*) AS c FROM fd_tickets WHERE contact_id = ?", 'i', array($primaryId));
    fd_exec("UPDATE fd_contacts SET tickets_count = ? WHERE id = ?", 'ii', array($cnt ? (int)$cnt['c'] : 0, $primaryId));

    api_success(array('merged' => $moved), $moved . ' customer record(s) merged');
}

/* ---------------------------------------------------------------- export -- */
if ($action === 'export') {
    $search = fd_str('search', '');
    $where = '1=1'; $types = ''; $params = array();
    if ($search !== '') {
        $where = "(name LIKE ? OR email LIKE ? OR phone LIKE ?)";
        $like = '%' . $search . '%';
        $types = 'sss'; $params = array($like, $like, $like);
    }
    $rows = fd_query("SELECT name, email, phone, college, program, enroll_id, is_registered, is_blocked,
                             tickets_count, first_seen_at, last_seen_at
                      FROM fd_contacts WHERE $where ORDER BY last_seen_at DESC LIMIT 10000", $types, $params);

    while (ob_get_level() > 0) { ob_end_clean(); }
    header_remove('Content-Type');
    header('Content-Type: text/csv; charset=UTF-8');
    header('Content-Disposition: attachment; filename="freshdesk-customers-' . date('Y-m-d') . '.csv"');
    // Excel reads a UTF-8 CSV as the system codepage unless it sees a BOM, which
    // turns every non-ASCII name into mojibake on the most common consumer.
    echo "\xEF\xBB\xBF";
    $out = fopen('php://output', 'w');
    fputcsv($out, array('Name', 'Email', 'Phone', 'College', 'Program', 'Enrollment ID',
                        'Registered', 'Blocked', 'Tickets', 'First Seen', 'Last Seen'));
    foreach ($rows as $r) {
        fputcsv($out, array($r['name'], $r['email'], $r['phone'], $r['college'], $r['program'], $r['enroll_id'],
                            $r['is_registered'] ? 'Yes' : 'No', $r['is_blocked'] ? 'Yes' : 'No',
                            $r['tickets_count'], $r['first_seen_at'], $r['last_seen_at']));
    }
    fclose($out);
    exit;
}

api_error('Unknown action: ' . $action, 400);

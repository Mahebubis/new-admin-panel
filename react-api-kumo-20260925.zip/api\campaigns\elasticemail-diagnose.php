<?php
/*
 * /api/campaigns/elasticemail-diagnose.php — CLI-only Elastic Email health check.
 *
 * Answers the question "is Elastic Email actually able to send right now, and if not
 * what exactly did it say?" WITHOUT having to queue a campaign and read failure rows
 * back out of email_campaign_recipients one at a time.
 *
 * It deliberately builds its send through the real ElasticEmailTransport rather than
 * hand-rolling a payload, so what it exercises is the same bytes a campaign sends. A
 * hand-rolled probe would have passed happily while campaigns kept failing — the
 * original bug lived in buildRequest()'s payload, not in the credentials.
 *
 * Usage (from the server, not the browser):
 *   php elasticemail-diagnose.php                      # checks only, sends nothing
 *   php elasticemail-diagnose.php you@example.com      # also sends one real test email
 *
 * The key is read from email_esp_settings (provider='elasticemail') — the same row the
 * campaign sender reads — so this verifies the key that is actually deployed, not one
 * pasted into a terminal. Override for a key you have not saved yet:
 *   EE_API_KEY=... php elasticemail-diagnose.php
 *
 * Exit code is 0 only when every check passed, so it can be used as a smoke test.
 */

if (PHP_SAPI !== 'cli') {
    http_response_code(403);
    exit("elasticemail-diagnose.php is CLI-only — it prints unmasked API responses.\n");
}

require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/lib/config.php';
require_once __DIR__ . '/lib/schema.php';
require_once __DIR__ . '/lib/TransportFactory.php';

campaigns_ensure_schema();

$failures = 0;

function step(string $title): void { echo "\n=== $title ===\n"; }
function pass(string $msg): void { echo "  [PASS] $msg\n"; }
function fail(string $msg): void { global $failures; $failures++; echo "  [FAIL] $msg\n"; }
function info(string $msg): void { echo "         $msg\n"; }

/** Bare GET against the v4 API with the key under test. */
function ee_get(string $key, string $path): array {
    $ch = curl_init('https://api.elasticemail.com/v4/' . ltrim($path, '/'));
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT        => 20,
        CURLOPT_HTTPHEADER     => ['X-ElasticEmail-ApiKey: ' . $key],
    ]);
    $body   = curl_exec($ch);
    $status = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $err    = curl_error($ch);
    curl_close($ch);
    return [$status, $body === false ? null : $body, $err];
}

/* ------------------------------------------------------------------ *
 * 1. The key the sender will actually use
 * ------------------------------------------------------------------ */
step('1. Stored credentials (email_esp_settings)');

$key = getenv('EE_API_KEY') ?: null;
$row = null;
if ($key) {
    info('Using EE_API_KEY from the environment (overriding the stored key).');
} else {
    $r   = $conn->query("SELECT * FROM email_esp_settings WHERE provider = 'elasticemail' LIMIT 1");
    $row = $r ? $r->fetch_assoc() : null;
    if (!$row) {
        fail("No row for provider='elasticemail'. Open Settings → ESP and save the provider once.");
        exit(1);
    }
    $key = (string)($row['api_key'] ?? '');
}

if ($key === '' || $key === 'DUMMY_ELASTICEMAIL_API_KEY') {
    fail('API key is empty or still the seeded placeholder DUMMY_ELASTICEMAIL_API_KEY.');
    exit(1);
}
pass(sprintf('Key present: %s…%s (%d chars)', substr($key, 0, 4), substr($key, -4), strlen($key)));
// A key that still carries the mask character never left settings.php's UI — it means the
// masked placeholder was written to the DB instead of being skipped on save.
if (strpos($key, '•') !== false) fail('Stored key contains the mask character "•" — a masked placeholder was saved over the real key.');
if (trim($key) !== $key)         fail('Stored key has leading/trailing whitespace — it will be sent verbatim in the header and rejected.');
if ($row) {
    info('is_active            : ' . ($row['is_active'] ? '1 (default for new campaigns)' : '0'));
    info('default_sender_email : ' . ($row['default_sender_email'] ?: '(unset)'));
    info('updated_at           : ' . ($row['updated_at'] ?? '?'));
}

/* ------------------------------------------------------------------ *
 * 2. Does the key authenticate, and may it send?
 * ------------------------------------------------------------------ */
step('2. Authentication and key permissions (GET /v4/security/apikeys)');

[$st, $body, $err] = ee_get($key, 'security/apikeys');
if ($err !== '')      fail("Network error: $err");
elseif ($st === 401)  fail("401 Unauthorized — the key is wrong, revoked, or regenerated in the dashboard without being re-saved here.\n         Response: $body");
elseif ($st !== 200)  fail("HTTP $st — $body");
else {
    pass('Key authenticates (HTTP 200).');
    // SendHttp is the one permission that matters: a key can read every report in the
    // account and still be unable to send, which fails only at send time.
    $keys  = json_decode((string)$body, true) ?: [];
    $mine  = null;
    foreach ($keys as $k) {
        // The listing does not echo the key itself, so match on the one whose name/expiry
        // we can see; with a single key on the account this is unambiguous.
        if (count($keys) === 1) { $mine = $k; break; }
        $mine = $mine ?? $k;
    }
    if ($mine) {
        $levels = $mine['AccessLevel'] ?? [];
        info('Key name : ' . ($mine['Name'] ?? '?'));
        info('Expires  : ' . ($mine['Expires'] ?? 'never'));
        info('Last use : ' . ($mine['LastUse'] ?? 'never'));
        info('IP range : ' . ($mine['RestrictAccessToIPRange'] ?? 'unrestricted'));
        if (in_array('SendHttp', $levels, true)) pass('Key has the SendHttp permission.');
        else fail('Key is MISSING the SendHttp permission — it can read the account but not send. Regenerate it with "Send" access.');
        if (!empty($mine['Expires']) && strtotime($mine['Expires']) < time()) fail('Key expiry date is in the past.');
        if (!empty($mine['RestrictAccessToIPRange'])) info('NOTE: this key is IP-restricted; the sending server must be inside that range.');
    }
}

/* ------------------------------------------------------------------ *
 * 3. Is the From domain able to send?
 * ------------------------------------------------------------------ */
step('3. Sender domains (GET /v4/domains)');

[$st, $body, $err] = ee_get($key, 'domains');
if ($st !== 200) fail("HTTP $st — $body");
else {
    $domains = json_decode((string)$body, true) ?: [];
    if (!$domains) fail('No sender domains on the account — every send will be rejected.');
    foreach ($domains as $d) {
        $name = $d['Domain'] ?? '?';
        $ok   = !empty($d['Verify']);
        echo '  ' . ($ok ? '[PASS]' : '[FAIL]') . " $name\n";
        if (!$ok) $failures++;
        info(sprintf('SPF=%s DKIM=%s MX=%s DMARC=%s Verified=%s',
            var_export((bool)($d['Spf'] ?? false), true),
            var_export((bool)($d['Dkim'] ?? false), true),
            var_export((bool)($d['MX'] ?? false), true),
            var_export((bool)($d['DMARC'] ?? false), true),
            var_export($ok, true)));
        // Not fatal, but it is the reason the transport can safely omit tracking options:
        // without a valid rewrite domain Elastic Email cannot rewrite our tracked links.
        info(sprintf('TrackingStatus=%s RewriteDomainValid=%s',
            $d['TrackingStatus'] ?? '?',
            var_export((bool)($d['IsRewriteDomainValid'] ?? false), true)));
        if (empty($d['Dkim'])) info('NOTE: DKIM is not signed for this domain — sends work, but inbox placement suffers.');
    }
}

/* ------------------------------------------------------------------ *
 * 4. The real send, through the real transport
 * ------------------------------------------------------------------ */
step('4. Live send (POST /v4/emails/transactional via ElasticEmailTransport)');

$to = $argv[1] ?? null;
if (!$to) {
    info('No recipient given — skipping. Re-run as: php elasticemail-diagnose.php you@example.com');
} else {
    $transport = new ElasticEmailTransport(['api_key' => $key]);
    $fromEmail = $row['default_sender_email'] ?? 'alert@alert.internshipstudio.com';
    $fromName  = $row['default_sender_name']  ?? 'Internship Studio';

    // Print the exact bytes first: when this fails, the payload is the evidence, and the
    // whole point of the script is that it is the campaign's payload and not a stand-in.
    $req = $transport->buildRequest($to, 'Elastic Email diagnostic', '<p>Elastic Email diagnostic send.</p>', $fromName, $fromEmail, null, 'diag-' . time());
    info('POST ' . $req['url']);
    info('Payload: ' . $req['body']);

    [$st, $body, $err] = esp_http_exec($req);
    $res = $transport->parseResponse($st, $body, $err, null);

    info("HTTP $st");
    info('Raw response: ' . ($body ?? '(none)'));
    if ($res['ok']) {
        pass('Accepted by Elastic Email. MessageID: ' . ($res['message_id'] ?? '?'));
        info('Delivery is asynchronous — confirm the inbox, then check Activity in the dashboard.');
    } else {
        fail($res['error'] . '  (retryable=' . var_export($res['retryable'], true) . ')');
        // The one failure mode whose message does not say what to do about it.
        if (stripos((string)$body, 'cannot change the tracking options') !== false) {
            info('CAUSE: the payload carried Options.TrackOpens/TrackClicks and this account forbids');
            info('       per-message tracking overrides. Remove the Options block from');
            info('       lib/ElasticEmailTransport.php::buildRequest().');
        }
    }
}

/* ------------------------------------------------------------------ *
 * 5. The delivery-receipt feed the poller reads
 * ------------------------------------------------------------------ */
step('5. Delivery receipts (GET /v4/events — what elasticemail-events-poll.php consumes)');

// Deliberately checked even on accounts that DO have webhooks: this is the feed that fills
// delivered_count where "Manage webhooks" is padlocked, so a 403/404 here is the difference
// between "delivered_count will populate" and "it never can".
[$st, $body, $err] = ee_get($key, 'events?from=' . rawurlencode(gmdate('Y-m-d\TH:i:s', time() - 86400))
                                . '&eventTypes=Sent,Error,Bounce&limit=50');
if ($err !== '')     fail("Network error: $err");
elseif ($st !== 200) fail("HTTP $st — $body  (without this feed delivered_count cannot be populated without webhooks)");
else {
    $evts = json_decode((string)$body, true) ?: [];
    pass('Events feed readable (HTTP 200) — ' . count($evts) . ' event(s) in the last 24h.');
    $byType = [];
    foreach ($evts as $e) {
        $t = (string)($e['EventType'] ?? '?');
        $byType[$t] = ($byType[$t] ?? 0) + 1;
    }
    foreach ($byType as $t => $n) info("$t: $n");

    // The whole correlation chain in one check: an event's MsgID is the same string the send
    // response returned as MessageID, which the transport stored in esp_message_id. If these
    // never match, the poller will fetch receipts happily and attribute none of them.
    $matched = 0;
    foreach ($evts as $e) {
        $mid = (string)($e['MsgID'] ?? '');
        if ($mid === '') continue;
        $stmt = $conn->prepare("SELECT id FROM email_campaign_recipients WHERE esp_message_id = ? LIMIT 1");
        $stmt->bind_param('s', $mid);
        $stmt->execute();
        if ($stmt->get_result()->fetch_assoc()) $matched++;
        $stmt->close();
    }
    if ($matched > 0) pass("$matched event(s) matched a campaign recipient by esp_message_id.");
    else info('No events matched a campaign recipient — expected if the only recent sends were '
            . 'test sends or journey emails, but a concern if a real campaign ran in the last 24h.');
}

// Where the poller has got to. A cursor far behind now means cron is not running (or is
// failing), which matters because events age out — see the retention note in the poller.
$cr = $conn->query("SELECT extra_config FROM email_esp_settings WHERE provider='elasticemail' LIMIT 1");
$cfg = $cr ? json_decode((string)($cr->fetch_assoc()['extra_config'] ?? ''), true) : null;
$cursor = is_array($cfg) ? ($cfg['events_cursor'] ?? null) : null;
info('Poller cursor: ' . ($cursor ?: 'not set yet (the poller has never completed a run)'));

step('Result');
echo $failures === 0
    ? "All checks passed.\n"
    : "$failures check(s) failed — see [FAIL] lines above.\n";
exit($failures === 0 ? 0 : 1);

<?php
/*
 * Unsubscribe landing page + Gmail/Yahoo one-click endpoint. Public (no JWT).
 *
 *   POST  → List-Unsubscribe-Post one-click. Must suppress immediately and
 *           answer 200 with no body. Gmail requires this to work within 2 days;
 *           we do it in the same request.
 *   GET   → a human clicked the footer link: show a confirmation page.
 */
ini_set('display_errors', 0);
error_reporting(0);

require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/lib/config.php';
require_once __DIR__ . '/lib/schema.php';
require_once __DIR__ . '/lib/Stats.php';
require_once __DIR__ . '/lib/Audience.php';
require_once __DIR__ . '/lib/Mailer.php';

kumo_ensure_schema();

$token  = (string)($_REQUEST['t'] ?? '');
$isPost = ($_SERVER['REQUEST_METHOD'] === 'POST');
$tok    = $token !== '' ? kumo_token_verify($token) : null;

$email = '';
$ok    = false;

if ($tok && $tok['kind'] === 'u') {
    try {
        $rid = $conn->real_escape_string($tok['rid']);
        $r = $conn->query("SELECT * FROM kumo_campaign_recipients WHERE rid='$rid' LIMIT 1");
        $rcpt = $r ? $r->fetch_assoc() : null;
        if ($rcpt) {
            $email = (string)$rcpt['email'];
            $reason = substr((string)($_POST['reason'] ?? ($_GET['reason'] ?? '')), 0, 200);

            kumo_suppress($email, 'unsubscribe', $reason, (int)$rcpt['campaign_id']);
            $conn->query(sprintf(
                "INSERT INTO kumo_campaign_events (campaign_id, recipient_id, rid, ip_id, type, provider, response, ip_address, user_agent, created_at)
                 VALUES (%d, %d, '%s', %s, 'unsub', '%s', %s, '%s', '%s', NOW())",
                (int)$rcpt['campaign_id'], (int)$rcpt['id'], $rid,
                $rcpt['ip_id'] ? (int)$rcpt['ip_id'] : 'NULL',
                $conn->real_escape_string((string)$rcpt['provider']),
                $reason !== '' ? "'" . $conn->real_escape_string($reason) . "'" : 'NULL',
                $conn->real_escape_string(trim(explode(',', (string)($_SERVER['HTTP_X_FORWARDED_FOR'] ?? $_SERVER['REMOTE_ADDR'] ?? ''))[0])),
                $conn->real_escape_string(substr((string)($_SERVER['HTTP_USER_AGENT'] ?? ''), 0, 480))
            ));
            $conn->query("UPDATE kumo_campaigns SET unsub_count=unsub_count+1 WHERE id=" . (int)$rcpt['campaign_id']);
            kumo_stats_bump((int)$rcpt['ip_id'], (string)$rcpt['provider'], ['unsubs' => 1]);
            $ok = true;
        }
    } catch (\Throwable $e) {
        error_log('kumo unsubscribe: ' . $e->getMessage());
    }
}

if ($isPost) {
    /* One-click: no HTML, just an acknowledgement. */
    header('Content-Type: text/plain; charset=utf-8');
    http_response_code(200);
    echo $ok ? 'unsubscribed' : 'ok';
    exit;
}

header('Content-Type: text/html; charset=utf-8');
header('Cache-Control: no-store');
$shown = $email !== '' ? htmlspecialchars($email, ENT_QUOTES) : '';
?><!doctype html>
<html lang="en"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= $ok ? 'You are unsubscribed' : 'Unsubscribe' ?></title>
<style>
  :root{ --ink:#0f172a; --muted:#64748b; --line:#e2e8f0; --brand:#4f46e5; }
  *{box-sizing:border-box} body{margin:0;min-height:100vh;display:flex;align-items:center;justify-content:center;
    font-family:'Plus Jakarta Sans',system-ui,-apple-system,Segoe UI,Arial,sans-serif;color:var(--ink);
    background:linear-gradient(135deg,#eef2ff 0%,#f8fafc 45%,#ecfeff 100%);padding:24px}
  .card{max-width:520px;width:100%;background:rgba(255,255,255,.86);backdrop-filter:blur(14px);
    border:1px solid rgba(255,255,255,.7);border-radius:20px;padding:34px 30px;
    box-shadow:0 22px 60px -22px rgba(15,23,42,.35)}
  h1{margin:0 0 8px;font-size:22px;letter-spacing:-.3px}
  p{margin:6px 0;color:var(--muted);font-size:14.5px;line-height:1.6}
  .em{color:var(--ink);font-weight:600}
  .tick{width:52px;height:52px;border-radius:50%;display:flex;align-items:center;justify-content:center;
    background:linear-gradient(140deg,#34d399,#059669);color:#fff;font-size:26px;margin-bottom:16px;
    box-shadow:0 10px 26px -10px rgba(5,150,105,.8)}
  .warn{background:linear-gradient(140deg,#fbbf24,#d97706);box-shadow:0 10px 26px -10px rgba(217,119,6,.8)}
  a.btn{display:inline-block;margin-top:18px;padding:11px 18px;border-radius:11px;background:var(--brand);
    color:#fff;text-decoration:none;font-weight:600;font-size:14px;box-shadow:0 10px 24px -12px rgba(79,70,229,.9)}
</style></head>
<body>
  <div class="card">
    <div class="tick <?= $ok ? '' : 'warn' ?>"><?= $ok ? '&#10003;' : '!' ?></div>
    <?php if ($ok): ?>
      <h1>You have been unsubscribed</h1>
      <p><span class="em"><?= $shown ?></span> will not receive any more marketing emails from us.</p>
      <p>Changed your mind? Write to us and we will add you back.</p>
    <?php else: ?>
      <h1>This link is no longer valid</h1>
      <p>We could not confirm this unsubscribe link. It may have expired or already been used.</p>
      <p>If you keep receiving emails, reply to any of them and we will remove you.</p>
    <?php endif; ?>
    <a class="btn" href="https://internshipstudio.com/">Back to Internship Studio</a>
  </div>
</body></html>

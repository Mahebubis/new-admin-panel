<?php
/*
 * /api/freshdesk/lib/Storage.php
 *
 * Attachment storage. Files go to S3 and only the KEY + URL are kept in the
 * database -- nothing accumulates on the cPanel disk.
 *
 * WHY A WRAPPER RATHER THAN CALLING s3_upload_file() DIRECTLY
 *
 * api/lib/S3Uploader.php starts with a hard require of
 *   /home/istudio/public_html/istudio_dashboard/api/vendor/autoload.php
 * which is a fatal error anywhere that path does not exist -- a staging box, a
 * local checkout, or the day someone moves the dashboard. A helpdesk that stops
 * accepting a customer's screenshot because the AWS SDK moved is not acceptable,
 * so:
 *
 *   1. the SDK is loaded defensively, and its absence is a reportable state
 *      rather than a white screen;
 *   2. if S3 is unavailable, the file is written to the local uploads folder
 *      instead and the row records storage='local'.
 *
 * Both storage modes are readable forever: fd_attachment_read() and the
 * download endpoint look at the `storage` column and do the right thing, so an
 * install that ran on local disk before S3 was configured keeps working, and no
 * migration is needed.
 */

$GLOBALS['FD_S3_READY'] = null;
$GLOBALS['FD_S3_ERROR']  = '';

/** True when the AWS SDK loaded and s3_upload_file() is callable. */
function fd_s3_available()
{
    if ($GLOBALS['FD_S3_READY'] !== null) return $GLOBALS['FD_S3_READY'];

    if (function_exists('s3_upload_file')) {
        $GLOBALS['FD_S3_READY'] = true;
        return true;
    }

    $candidates = array(
        __DIR__ . '/../../lib/S3Uploader.php',
        '/home/istudio/public_html/cit3/admin/react-api/api/lib/S3Uploader.php',
    );
    foreach ($candidates as $file) {
        if (!@file_exists($file)) continue;
        try {
            // S3Uploader.php require()s the AWS autoloader at the top, so a
            // missing SDK surfaces here as a Throwable rather than taking the
            // whole request down.
            require_once $file;
            if (function_exists('s3_upload_file')) {
                $GLOBALS['FD_S3_READY'] = true;
                return true;
            }
        } catch (Throwable $e) {
            $GLOBALS['FD_S3_ERROR'] = $e->getMessage();
            fd_log('warn', 'S3 unavailable, falling back to local storage: ' . $e->getMessage());
            break;
        }
    }

    if ($GLOBALS['FD_S3_ERROR'] === '') {
        $GLOBALS['FD_S3_ERROR'] = 'S3Uploader.php not found in any known location.';
    }
    $GLOBALS['FD_S3_READY'] = false;
    return false;
}

function fd_s3_error() { return $GLOBALS['FD_S3_ERROR']; }

/**
 * The S3 object key for one attachment.
 *
 * Layout: freshdesk/attachments/<ticket>/<random>.<ext>
 *
 * The name is random rather than the customer's filename. The original name is
 * data in a column and is what the agent sees; keeping it out of the key means
 * an attachment called "../../index.php" or one with a 300-character unicode
 * name cannot influence where the object lands, and two customers sending
 * "screenshot.png" never collide.
 */
function fd_storage_key($ticketId, $originalName)
{
    $ext = strtolower(pathinfo((string)$originalName, PATHINFO_EXTENSION));
    $ext = preg_replace('/[^a-z0-9]/', '', $ext);
    if ($ext === '' || strlen($ext) > 10) $ext = 'bin';
    return 'freshdesk/attachments/' . (int)$ticketId . '/' . bin2hex(random_bytes(12)) . '.' . $ext;
}

/**
 * Store raw bytes.
 *
 * @return array ['ok','storage','key','url','rel_path','error']
 *   storage 's3'    -> url is the permanent public S3 URL, rel_path is ''
 *   storage 'local' -> rel_path is relative to FD_ATTACH_DIR, url is ''
 */
function fd_storage_put_bytes($ticketId, $originalName, $bytes, $contentType = 'application/octet-stream')
{
    $key = fd_storage_key($ticketId, $originalName);

    // S3's PHP client wants a file or a stream, and writing a temp file first
    // also gives us the local fallback for free if the upload is rejected.
    $tmp = @tempnam(sys_get_temp_dir(), 'fdatt');
    if ($tmp === false || @file_put_contents($tmp, $bytes) === false) {
        if ($tmp) @unlink($tmp);
        return array('ok' => false, 'error' => 'Could not buffer the file on the server (temp folder not writable).');
    }

    $res = fd_storage_put_file($ticketId, $originalName, $tmp, $contentType, $key);
    @unlink($tmp);
    return $res;
}

/**
 * Store a file that is already on disk (an upload's tmp_name, typically).
 * The source file is NOT deleted -- the caller owns it.
 */
function fd_storage_put_file($ticketId, $originalName, $localPath, $contentType = 'application/octet-stream', $key = null)
{
    if (!@is_file($localPath)) {
        return array('ok' => false, 'error' => 'The file to store does not exist on disk.');
    }
    if ($key === null) $key = fd_storage_key($ticketId, $originalName);

    if (fd_s3_available()) {
        try {
            $url = s3_upload_file($localPath, $key, $contentType ?: 'application/octet-stream');
            if ($url) {
                return array('ok' => true, 'storage' => 's3', 'key' => $key, 'url' => $url, 'rel_path' => '', 'error' => null);
            }
            // s3_upload_file() logs the AwsException itself and returns null.
            fd_log('warn', 'S3 upload returned null, falling back to local', array('key' => $key));
        } catch (Throwable $e) {
            fd_log('warn', 'S3 upload threw, falling back to local: ' . $e->getMessage(), array('key' => $key));
        }
    }

    /*
     * Local fallback. This is a degraded mode, not the design: it exists so a
     * broken AWS config loses nothing while it is being fixed. fd_diagnostics
     * reports it, and these rows can be migrated to S3 later using the key
     * already recorded on them.
     */
    fd_ensure_uploads_dir();
    $dir = FD_ATTACH_DIR . '/' . (int)$ticketId;
    if (!is_dir($dir) && !@mkdir($dir, 0755, true)) {
        return array('ok' => false, 'error' => 'S3 is unavailable and the local uploads folder could not be created.');
    }
    $stored  = basename($key);
    $dest    = $dir . '/' . $stored;
    if (!@copy($localPath, $dest)) {
        return array('ok' => false, 'error' => 'S3 is unavailable and the file could not be written locally either.');
    }
    @chmod($dest, 0644);
    return array('ok' => true, 'storage' => 'local', 'key' => $key, 'url' => '',
                 'rel_path' => (int)$ticketId . '/' . $stored, 'error' => null);
}

/**
 * Read one attachment's bytes back, wherever it lives.
 * Used when re-attaching a stored file to an outgoing email.
 */
function fd_storage_get_bytes($attachment)
{
    $storage = isset($attachment['storage']) ? $attachment['storage'] : 'local';

    if ($storage === 's3') {
        if (empty($attachment['s3_url'])) return null;
        if (fd_s3_available() && function_exists('s3_fetch_bytes')) {
            $bytes = s3_fetch_bytes($attachment['s3_url']);
            if ($bytes !== null) return $bytes;
        }
        // Plain HTTPS GET works too -- the bucket serves these publicly, and
        // this keeps sending replies possible even if the SDK is missing.
        $ctx = stream_context_create(array('http' => array('timeout' => 20)));
        $bytes = @file_get_contents($attachment['s3_url'], false, $ctx);
        return $bytes === false ? null : $bytes;
    }

    if (empty($attachment['rel_path'])) return null;
    $path = FD_ATTACH_DIR . '/' . $attachment['rel_path'];
    $real = @realpath($path);
    $base = @realpath(FD_ATTACH_DIR);
    if (!$real || !$base || strpos($real, $base) !== 0 || !is_file($real)) return null;
    $bytes = @file_get_contents($real);
    return $bytes === false ? null : $bytes;
}

/** Remove the stored object. Best-effort: a failed delete must not fail a request. */
function fd_storage_delete($attachment)
{
    $storage = isset($attachment['storage']) ? $attachment['storage'] : 'local';
    if ($storage === 's3') {
        if (!empty($attachment['s3_key']) && fd_s3_available() && function_exists('s3_delete_key')) {
            try { s3_delete_key($attachment['s3_key']); } catch (Throwable $e) {
                fd_log('warn', 'S3 delete failed: ' . $e->getMessage(), array('key' => $attachment['s3_key']));
            }
        }
        return;
    }
    if (!empty($attachment['rel_path'])) {
        @unlink(FD_ATTACH_DIR . '/' . $attachment['rel_path']);
    }
}

/**
 * The URL the panel should use for one attachment.
 *
 * Always OUR endpoint, never the raw S3 URL, even though the object is publicly
 * readable: routing through fd_attachments.php is what lets the panel force a
 * download filename, apply nosniff, and keeps a single place to add real access
 * control later without having to re-write every stored body and message row.
 */
function fd_storage_url($attachmentId, $action = 'download')
{
    return fd_attachment_url($attachmentId, $action);
}

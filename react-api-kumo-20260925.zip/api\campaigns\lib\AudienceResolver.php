<?php
/*
 * Resolves a campaign's Audience-step config into actual recipient rows /
 * counts. Reuses netcore/segments.php's buildSegmentSql() (shared via
 * netcore/lib/segment_sql.php) rather than re-implementing segment
 * membership resolution — campaigns select whole *segments* by id, so this
 * just UNIONs each selected segment's subquery.
 *
 * $config shape: { audience_type: 'all_contacts'|'segments', segment_ids: [..],
 *                   exclude_segment_ids: [..], exclude_list_ids: [..],
 *                   domain_filter: 'gmail.com' }
 */
require_once __DIR__ . '/../../netcore/lib/segment_sql.php';
require_once __DIR__ . '/../../lists/lib/schema.php';

/*
 * The two halves of an audience keep their emails in tables created years apart, and on the
 * live database they do NOT share a collation — one is utf8mb4_general_ci, the other
 * utf8mb4_unicode_ci. MySQL refuses to compare or UNION the two without being told which one
 * wins ("Illegal mix of collations ... for operation '='"), so every email column taking part
 * in a UNION or a join below is stamped with this one explicitly. general_ci because that is
 * what already worked here (see the users LEFT JOIN in resolve_audience_users()).
 *
 * Both columns are utf8mb4, which is what makes a plain COLLATE legal here — a COLLATE naming
 * a collation from a different character set would be an error in itself.
 */
if (!defined('AUDIENCE_EMAIL_COLLATION')) define('AUDIENCE_EMAIL_COLLATION', 'utf8mb4_general_ci');

/**
 * Emails on the single global Blocklist — excluded from every campaign send
 * regardless of whether the recipient was matched via a Segment or a List.
 * Returns a lowercase-email => true map for O(1) lookups against the merged
 * recipient set built in resolve_audience_users(); resolve_audience_count()
 * instead folds this straight into its SQL as a subquery (see below).
 */
function blocklisted_emails(): array {
    global $conn;
    $blocklistId = lists_get_or_create_blocklist_id();
    $r = $conn->query("SELECT c.email FROM campaign_contacts c
                        INNER JOIN campaign_list_members m ON m.contact_id = c.id
                        WHERE m.list_id = " . (int)$blocklistId);
    $out = [];
    while ($r && $row = $r->fetch_assoc()) $out[strtolower($row['email'])] = true;
    return $out;
}

function audience_base_sql(array $config): ?string {
    global $conn;
    $type = $config['audience_type'] ?? 'segments';

    if ($type === 'all_contacts') {
        $inc = "SELECT user_id FROM users WHERE COALESCE(active,1) <> 0";
    } else {
        $segIds = array_values(array_filter(array_map('intval', $config['segment_ids'] ?? [])));
        if (!$segIds) return null;
        $subs = [];
        foreach ($segIds as $id) {
            $r = $conn->query("SELECT config FROM netcore_segments WHERE id=" . (int)$id . " LIMIT 1");
            $row = $r ? $r->fetch_assoc() : null;
            if (!$row) continue;
            $sql = buildSegmentSql(json_decode($row['config'], true));
            if ($sql) $subs[] = $sql;
        }
        if (!$subs) return null;
        $inc = "SELECT DISTINCT user_id FROM (" . implode(' UNION ', $subs) . ") AS inc_u";
    }

    // NOTE: this is the INCLUDE half only. "Exclude contacts" used to be subtracted here, by
    // user_id, which quietly meant it only ever applied to the segment-sourced half of an
    // audience — an excluded contact still went out if a selected List had pulled them in.
    // Exclusion now happens once, by email, in audience_exclude_emails_sql(), which covers both
    // halves and lets the Audience step report how many contacts it actually removed.
    return $inc;
}

/**
 * Emails removed by the Audience step's "Exclude contacts" picker, as a SELECT of
 * one `email` column (or null when nothing is excluded).
 *
 * Exclusion is resolved by EMAIL, not by user_id, because it has to cover both halves of
 * an audience: Segments resolve against `users` while Lists resolve against
 * `campaign_contacts`, and the same person can arrive through either. audience_base_sql()
 * below still subtracts excluded segments on the segment side by user_id (cheaper, and it
 * shrinks the set before the join) — this is what additionally keeps an excluded contact
 * out when they were pulled in by a selected List.
 */
function audience_exclude_emails_sql(array $config): ?string {
    global $conn;
    $parts = [];

    $segIds = array_values(array_filter(array_map('intval', $config['exclude_segment_ids'] ?? [])));
    foreach ($segIds as $id) {
        $r = $conn->query("SELECT config FROM netcore_segments WHERE id=" . (int)$id . " LIMIT 1");
        $row = $r ? $r->fetch_assoc() : null;
        if (!$row) continue;
        $sql = buildSegmentSql(json_decode($row['config'], true));
        if (!$sql) continue;
        $parts[] = "SELECT u.email COLLATE " . AUDIENCE_EMAIL_COLLATION . " AS email FROM ($sql) AS ex_s
                    INNER JOIN users u ON u.user_id = ex_s.user_id
                    WHERE u.email IS NOT NULL AND u.email <> ''";
    }

    $listIds = array_values(array_filter(array_map('intval', $config['exclude_list_ids'] ?? [])));
    if ($listIds) {
        $ids = implode(',', $listIds);
        $parts[] = "SELECT c.email COLLATE " . AUDIENCE_EMAIL_COLLATION . " AS email FROM campaign_contacts c
                    INNER JOIN campaign_list_members m ON m.contact_id = c.id
                    WHERE m.list_id IN ($ids) AND c.email IS NOT NULL AND c.email <> ''";
    }

    return $parts ? implode(' UNION ', $parts) : null;
}

/** Same set as audience_exclude_emails_sql(), as a lowercase-email => true map. */
function audience_excluded_emails(array $config): array {
    global $conn;
    $sql = audience_exclude_emails_sql($config);
    if (!$sql) return [];
    /*
     * Deliberately NOT wrapped in a try/catch the way the count query is. This runs inside a
     * send, and an empty result here does not mean "nobody was excluded" — it means the
     * exclusion could not be resolved. Swallowing that would message the very people an admin
     * asked to leave out, which is worse than the send failing loudly and being retried.
     */
    $r = $conn->query("SELECT DISTINCT email FROM ($sql) AS ex");
    if (!$r) {
        // Same reason, for the hosts where mysqli still returns false instead of throwing.
        if (function_exists('campaign_log')) campaign_log('audience_excluded_emails: query FAILED — ' . $conn->error);
        throw new RuntimeException('Could not resolve the campaign exclusions: ' . $conn->error);
    }
    $out = [];
    while ($r && $row = $r->fetch_assoc()) $out[strtolower($row['email'])] = true;
    return $out;
}

function domain_where_clause(array $config): string {
    $domain = trim((string)($config['domain_filter'] ?? ''));
    return $domain !== '' ? " AND u.email LIKE '%@" . esc($domain) . "'" : '';
}

/** Same domain filter, applied to the campaign_contacts-sourced (Lists) half of the audience. */
function domain_where_clause_contacts(array $config): string {
    $domain = trim((string)($config['domain_filter'] ?? ''));
    return $domain !== '' ? " AND c.email LIKE '%@" . esc($domain) . "'" : '';
}

/**
 * Live "reachable contacts" count for the Audience step — a campaign's real
 * audience is the UNION of Segments (dynamic rules over `users`) and Lists
 * (static imported contacts in `campaign_contacts`), de-duped by email. Plain
 * SQL UNION is enough here since only a COUNT is needed.
 */
function resolve_audience_count(array $config): int {
    return resolve_audience_breakdown($config)['count'];
}

/**
 * The same figure, itemized: how many contacts the audience matched, how many the
 * "Exclude contacts" picker then removed, and what is left. The Audience step shows all
 * three, so the number that drops has a stated reason instead of just shrinking.
 *
 * One query, not two: the exclusion is counted with a CASE over the merged set rather than
 * resolved twice with and without it.
 *
 * @return array{matched:int, excluded:int, count:int}   matched is already blocklist-free
 */
function resolve_audience_breakdown(array $config): array {
    global $conn;
    $parts = [];

    // Every email below is collated explicitly — the two halves come from tables that disagree,
    // and the UNION and the exclusion join both compare them. See AUDIENCE_EMAIL_COLLATION.
    $coll = ' COLLATE ' . AUDIENCE_EMAIL_COLLATION;

    $base = audience_base_sql($config);
    if ($base) {
        $parts[] = "SELECT u.email$coll AS email FROM ($base) AS s
                    INNER JOIN users u ON u.user_id = s.user_id
                    WHERE u.email IS NOT NULL AND u.email <> ''" . domain_where_clause($config);
    }

    $listIds = array_values(array_filter(array_map('intval', $config['list_ids'] ?? [])));
    if ($listIds) {
        $ids = implode(',', $listIds);
        $parts[] = "SELECT c.email$coll AS email FROM campaign_contacts c
                    INNER JOIN campaign_list_members m ON m.contact_id = c.id
                    WHERE m.list_id IN ($ids) AND c.email IS NOT NULL AND c.email <> ''" . domain_where_clause_contacts($config);
    }

    $empty = ['matched' => 0, 'excluded' => 0, 'count' => 0];
    if (!$parts) return $empty;
    $blocklistId = lists_get_or_create_blocklist_id();

    /*
     * Excluded segments/lists, counted over the merged (segments + lists) set by email — so the
     * "reachable" number here matches what resolve_audience_users() will really queue.
     *
     * A LEFT JOIN against a DISTINCT derived table rather than "email IN (SELECT ...)": the
     * excluded set is built once and hash-joined, where the IN form re-runs the union for every
     * row of the audience. DISTINCT is what keeps the join from multiplying rows when the same
     * address sits in two excluded lists.
     */
    $excSql  = audience_exclude_emails_sql($config);
    $excJoin = $excSql ? "LEFT JOIN (SELECT DISTINCT email FROM ($excSql) AS ex_all) AS ex
                          ON ex.email = combined.email$coll" : '';
    $excExpr = $excSql ? 'SUM(ex.email IS NOT NULL)' : '0';

    $sql = "SELECT COUNT(*) AS matched, $excExpr AS excluded
            FROM (" . implode(' UNION ', $parts) . ") AS combined
            $excJoin
            WHERE combined.email NOT IN (
                SELECT c.email$coll FROM campaign_contacts c
                INNER JOIN campaign_list_members m ON m.contact_id = c.id
                WHERE m.list_id = $blocklistId
            )";
    /*
     * try/catch as well as the return check: PHP 8.1 made mysqli THROW on a query error instead
     * of returning false, so a bad query here used to leave the browser looking at a raw fatal
     * error page — from a debounced count that fires on every keystroke in the Audience step.
     * A count that cannot be computed is worth a zero and a log line, never a dead screen.
     */
    try {
        $r = $conn->query($sql);
    } catch (Throwable $e) {
        if (function_exists('campaign_log')) campaign_log('resolve_audience_breakdown: query THREW — ' . $e->getMessage());
        return $empty;
    }
    if (!$r) {
        if (function_exists('campaign_log')) campaign_log('resolve_audience_breakdown: query FAILED — ' . $conn->error);
        return $empty;
    }
    $row      = $r->fetch_assoc();
    $matched  = (int)$row['matched'];
    $excluded = (int)$row['excluded'];
    return ['matched' => $matched, 'excluded' => $excluded, 'count' => max(0, $matched - $excluded)];
}

/**
 * Materializes recipient rows (email + merge-tag fields) for queueing into
 * email_campaign_recipients — merged in PHP, not SQL, because a plain UNION
 * only de-dupes rows that are byte-identical across every column, and a
 * contact matched by both a segment and a list could have differing name
 * data between the two sources. Segment-sourced rows win on an email
 * collision (checked first) since they carry a real user_id, which is what
 * unlocks exam-merge-tag data downstream (see MergeTags.php's resolve_exam_data()) —
 * list-only contacts get their user_id looked up too (a List/Blocklist contact can
 * still be an already-registered student), and only fall back to user_id => null
 * when their email genuinely isn't a registered account.
 */
function resolve_audience_users(array $config, int $limit = 0, int $offset = 0, ?array &$stats = null): array {
    global $conn;
    $byEmail = [];

    $base = audience_base_sql($config);
    if ($base) {
        $sql = "SELECT u.user_id, u.email, u.fname AS first_name, u.lname AS last_name, u.phone
                FROM ($base) AS s
                INNER JOIN users u ON u.user_id = s.user_id
                WHERE u.email IS NOT NULL AND u.email <> ''" . domain_where_clause($config);
        $r = $conn->query($sql);
        if (!$r && function_exists('campaign_log')) campaign_log('resolve_audience_users: segment-side query FAILED — ' . $conn->error);
        while ($r && $row = $r->fetch_assoc()) $byEmail[strtolower($row['email'])] = $row;
    }

    $listIds = array_values(array_filter(array_map('intval', $config['list_ids'] ?? [])));
    if ($listIds) {
        $ids = implode(',', $listIds);
        // LEFT JOIN users — a list/contact-only recipient with no name of its own (e.g. a
        // CSV that only had an EMAIL column) may still be an already-registered student;
        // fall back to their real users.fname/lname/phone AND their real user_id so
        // XX_USER_FNAME_XX, exam merge tags, and mapped Customer Attributes (all keyed by
        // user_id) aren't left blank/defaulted when we could've had the real value all
        // along — a List/Blocklist contact is only "no user_id" when their email genuinely
        // isn't a registered account.
        $sql = "SELECT DISTINCT c.email, u.user_id AS matched_user_id,
                       COALESCE(c.first_name, u.fname) AS first_name,
                       COALESCE(c.last_name, u.lname) AS last_name,
                       COALESCE(c.phone, u.phone) AS phone
                FROM campaign_contacts c
                INNER JOIN campaign_list_members m ON m.contact_id = c.id
                LEFT JOIN users u ON u.email = c.email COLLATE utf8mb4_general_ci
                WHERE m.list_id IN ($ids) AND c.email IS NOT NULL AND c.email <> ''" . domain_where_clause_contacts($config);
        $r = $conn->query($sql);
        if (!$r && function_exists('campaign_log')) campaign_log('resolve_audience_users: list-side query FAILED — ' . $conn->error);
        while ($r && $row = $r->fetch_assoc()) {
            $key = strtolower($row['email']);
            if (!isset($byEmail[$key])) {
                $uid = $row['matched_user_id'] !== null ? (int)$row['matched_user_id'] : null;
                unset($row['matched_user_id']);
                $byEmail[$key] = ['user_id' => $uid] + $row;
            }
        }
    }

    /*
     * Campaign-level exclusions (the Audience step's "Exclude contacts") and the global
     * Blocklist, both applied last, after the segment+list merge — an excluded contact is
     * dropped no matter which half of the audience pulled them in.
     *
     * Counted separately rather than merged into one map: the Audience step states a reason
     * next to every contact it removes, and "you excluded them" is not the same fact as
     * "they are blocklisted".
     */
    $excluded = audience_excluded_emails($config);
    $blocked  = blocklisted_emails();
    $stats    = ['matched' => 0, 'excluded' => 0, 'blocklisted' => 0];
    // Blocklist first, then exclusions — the same order resolve_audience_breakdown() counts in,
    // so a contact who is both does not land in one tally here and the other there.
    foreach (array_keys($byEmail) as $email) {
        if (isset($blocked[$email]))  { unset($byEmail[$email]); $stats['blocklisted']++; continue; }
        if (isset($excluded[$email])) { unset($byEmail[$email]); $stats['excluded']++; }
    }
    $stats['matched'] = count($byEmail) + $stats['excluded']; // blocklist-free, before exclusions

    $rows = array_values($byEmail);
    return $limit > 0 ? array_slice($rows, $offset, $limit) : $rows;
}

<?php
/**
 * /api/caller-iq/ciq_lib.php  —  Caller IQ shared schema + helpers
 * ---------------------------------------------------------------------------
 * Caller IQ is the Android app in caller-IQ-project/. After every call ends it
 * reads the phone's call log and a WorkManager job POSTs each call, one JSON
 * object per request, to log_call.php:
 *
 *   { number, call_type, duration, sim_id, timestamp (ms), idempotency_key,
 *     outcome?,                                   ← when a counselor tags it
 *     device_id?, device_model?, app_version?,    ← added in app v1.1
 *     sim_slot?, sim_label?, carrier? }
 *
 * The original build sends none of the device fields, so every phone running it
 * lands under device_id '' ("Unidentified phone"). It still works end to end —
 * the panel simply cannot tell those phones apart until they update.
 *
 * WorkManager retries any non-2xx forever with exponential backoff, so the
 * ingest answers 200 for a payload that can never succeed (it would otherwise
 * retry it for the life of the install) and 503 only for our own failures.
 * ---------------------------------------------------------------------------
 */

/* Optional shared secret. Leave empty to accept any device (the shipped app sends
   no key). When set, the app must send it as the X-CallIQ-Key header or `key`. */
if (!defined('CALLER_IQ_INGEST_KEY')) define('CALLER_IQ_INGEST_KEY', '');

const CIQ_TYPES = ['INCOMING', 'OUTGOING', 'MISSED', 'REJECTED', 'BLOCKED', 'VOICEMAIL', 'UNKNOWN'];

function ciq_ensure_schema(mysqli $conn): void
{
    static $done = false;
    if ($done) return;
    $done = true;

    /* call_at is written by PHP (Asia/Kolkata), never DEFAULT CURRENT_TIMESTAMP —
       MySQL runs a different clock on this host. */
    $conn->query("CREATE TABLE IF NOT EXISTS caller_iq_calls (
        id               BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        device_id        VARCHAR(64)  NOT NULL DEFAULT '',
        idempotency_key  VARCHAR(120) NOT NULL,
        number           VARCHAR(40)  NOT NULL,
        number_norm      VARCHAR(20)  NOT NULL DEFAULT '',
        call_type        VARCHAR(16)  NOT NULL,
        raw_call_type    VARCHAR(40)  NOT NULL DEFAULT '',
        duration_sec     INT UNSIGNED NOT NULL DEFAULT 0,
        ring_sec         INT UNSIGNED NULL,   -- how long a never-answered call rang (never talk time)
        call_ts_ms       BIGINT       NOT NULL,
        call_at          DATETIME     NOT NULL,
        sim_id           VARCHAR(64)  NOT NULL DEFAULT '',
        sim_slot         TINYINT      NULL,
        sim_label        VARCHAR(120) NOT NULL DEFAULT '',
        carrier          VARCHAR(80)  NOT NULL DEFAULT '',
        sim_source       VARCHAR(16)  NOT NULL DEFAULT '',
        tagged_via       VARCHAR(16)  NOT NULL DEFAULT '',
        outcome          VARCHAR(60)  NULL,
        outcome_at       DATETIME     NULL,
        outcome_source   VARCHAR(20)  NULL,
        notes            TEXT         NULL,
        first_synced_at  DATETIME     NOT NULL,
        last_synced_at   DATETIME     NOT NULL,
        sync_count       INT UNSIGNED NOT NULL DEFAULT 1,
        PRIMARY KEY (id),
        UNIQUE KEY uq_call (device_id, idempotency_key),
        KEY k_at (call_at),
        KEY k_num (number_norm, call_at),
        KEY k_dev (device_id, call_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    /* Added with app v1.2 (real SIM detection + post-call popup). Existing installs already have
       the table, so the columns are added here rather than only in CREATE TABLE. */
    $have = [];
    if ($res = $conn->query("SHOW COLUMNS FROM caller_iq_calls")) {
        while ($r = $res->fetch_assoc()) $have[$r['Field']] = true;
    }
    if ($have && !isset($have['sim_source'])) {
        $conn->query("ALTER TABLE caller_iq_calls ADD COLUMN sim_source VARCHAR(16) NOT NULL DEFAULT '' AFTER carrier");
    }
    if ($have && !isset($have['tagged_via'])) {
        $conn->query("ALTER TABLE caller_iq_calls ADD COLUMN tagged_via VARCHAR(16) NOT NULL DEFAULT '' AFTER sim_source");
    }
    /* A missed, declined or blocked call was never talked on — but Xiaomi and some MediaTek phones
       write how long it RANG into the call log's duration. Stored as talk time, that made missed
       calls count as "connected" and inflated talk time. The ring time moves to its own column;
       the one-off UPDATE runs only in the request that adds the column, repairing earlier rows. */
    if ($have && !isset($have['ring_sec'])) {
        if ($conn->query("ALTER TABLE caller_iq_calls ADD COLUMN ring_sec INT UNSIGNED NULL AFTER duration_sec")) {
            $conn->query("UPDATE caller_iq_calls SET ring_sec = duration_sec, duration_sec = 0
                          WHERE call_type IN ('MISSED','REJECTED','BLOCKED') AND duration_sec > 0");
        }
    }
    $haveDev = [];
    if ($res = $conn->query("SHOW COLUMNS FROM caller_iq_devices")) {
        while ($r = $res->fetch_assoc()) $haveDev[$r['Field']] = true;
    }
    if ($haveDev && !isset($haveDev['popup_ok'])) {
        $conn->query("ALTER TABLE caller_iq_devices ADD COLUMN popup_ok TINYINT NULL AFTER is_hidden");
    }
    /* What each phone reports about its own setup (see checkin.php). last_seen_at keeps meaning
       "last call uploaded"; a check-in is tracked on its own so the two are never confused. */
    if ($haveDev && !isset($haveDev['health_json'])) {
        $conn->query("ALTER TABLE caller_iq_devices
            ADD COLUMN manufacturer    VARCHAR(40) NOT NULL DEFAULT '',
            ADD COLUMN os_release      VARCHAR(16) NOT NULL DEFAULT '',
            ADD COLUMN sdk_int         SMALLINT NULL,
            ADD COLUMN app_build       INT NULL,
            ADD COLUMN health_json     TEXT NULL,
            ADD COLUMN last_checkin_at DATETIME NULL");
    }
    $haveSim = [];
    if ($res = $conn->query("SHOW COLUMNS FROM caller_iq_sims")) {
        while ($r = $res->fetch_assoc()) $haveSim[$r['Field']] = true;
    }
    if ($haveSim && !isset($haveSim['auto_valid_till'])) {
        $conn->query("ALTER TABLE caller_iq_sims
            ADD COLUMN auto_valid_till DATE NULL,
            ADD COLUMN auto_balance VARCHAR(20) NOT NULL DEFAULT '',
            ADD COLUMN auto_text VARCHAR(500) NOT NULL DEFAULT '',
            ADD COLUMN auto_code VARCHAR(20) NOT NULL DEFAULT '',
            ADD COLUMN auto_ok TINYINT NULL,
            ADD COLUMN auto_checked_at DATETIME NULL");
    }

    $haveLive = [];
    if ($res = $conn->query("SHOW COLUMNS FROM caller_iq_live")) {
        while ($r = $res->fetch_assoc()) $haveLive[$r['Field']] = true;
    }
    if ($haveLive && !isset($haveLive['duration_sec'])) {
        $conn->query("ALTER TABLE caller_iq_live ADD COLUMN duration_sec INT NULL AFTER ended_at");
    }
    // Whatever the ALTERs above did or did not manage, read the real shape back before anything
    // builds a query from it.
    ciq_forget_columns();

    /*
     * Calls happening right now. One row per phone: Android tells an ordinary app about one call
     * at a time, so a second row would be invented rather than observed. The row is overwritten on
     * every event and aged out by the reader, so nothing here needs cleaning up on a schedule.
     */
    $conn->query("CREATE TABLE IF NOT EXISTS caller_iq_live (
        device_id     VARCHAR(64)  NOT NULL,
        state         VARCHAR(12)  NOT NULL,           -- ringing | connected | ended
        direction     VARCHAR(10)  NOT NULL DEFAULT '',-- incoming | outgoing | unknown
        number        VARCHAR(40)  NOT NULL DEFAULT '',
        number_norm   VARCHAR(20)  NOT NULL DEFAULT '',
        sim_slot      TINYINT      NULL,
        sim_label     VARCHAR(120) NOT NULL DEFAULT '',
        carrier       VARCHAR(80)  NOT NULL DEFAULT '',
        started_ms    BIGINT       NOT NULL DEFAULT 0, -- phone clock, kept for the call key
        started_at    DATETIME     NOT NULL,           -- server clock: what the panel counts from
        answered_at   DATETIME     NULL,
        ended_at      DATETIME     NULL,
        duration_sec  INT          NULL,               -- the real talk time, known only once the call log exists
        updated_at    DATETIME     NOT NULL,
        PRIMARY KEY (device_id),
        KEY k_updated (updated_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    /*
     * Outcomes tagged on the popup before the call itself had synced. The popup opens the instant
     * a call ends — seconds before the call reaches us — so a tap in that window has no call to
     * attach to yet. It waits here, keyed on when the call started, and ciq_apply_pending_tags()
     * attaches it the moment that call arrives. Nothing is lost and no phantom call is invented.
     */
    $conn->query("CREATE TABLE IF NOT EXISTS caller_iq_pending_tags (
        id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        device_id   VARCHAR(64)  NOT NULL DEFAULT '',
        number_norm VARCHAR(20)  NOT NULL DEFAULT '',
        started_ms  BIGINT       NOT NULL,
        outcome     VARCHAR(60)  NOT NULL,
        tagged_via  VARCHAR(16)  NOT NULL DEFAULT 'popup',
        created_at  DATETIME     NOT NULL,
        PRIMARY KEY (id),
        KEY k_dev (device_id, started_ms)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    /*
     * One row per SIM, per phone — the recharge register.
     *
     * Android exposes NOTHING about a prepaid balance or a plan's validity: no API, on any version.
     * Carriers keep that behind USSD codes, their own apps and SMS. So the rows here are discovered
     * automatically (a call names its phone, slot, carrier and sometimes the SIM's own number) and
     * the plan itself — what was paid, when, and until when it runs — is recorded by whoever tops
     * the SIM up. The dashboard then does the part a person cannot: watch every SIM's expiry at
     * once and say which ones are about to lapse.
     */
    $conn->query("CREATE TABLE IF NOT EXISTS caller_iq_sims (
        device_id     VARCHAR(64)  NOT NULL DEFAULT '',
        slot          TINYINT      NOT NULL DEFAULT 0,
        msisdn        VARCHAR(20)  NOT NULL DEFAULT '',   -- the SIM's own number
        carrier       VARCHAR(80)  NOT NULL DEFAULT '',
        label         VARCHAR(120) NOT NULL DEFAULT '',
        plan_name     VARCHAR(120) NOT NULL DEFAULT '',
        amount        DECIMAL(10,2) NULL,
        recharged_on  DATE         NULL,
        valid_till    DATE         NULL,
        notes         TEXT         NULL,
        first_seen_at DATETIME     NOT NULL,
        updated_at    DATETIME     NOT NULL,
        updated_by    VARCHAR(40)  NOT NULL DEFAULT '',
        /* What the operator itself said, via a USSD check on the phone. Kept apart from the
           columns above so an automatic reading can never overwrite what a person recorded. */
        auto_valid_till DATE        NULL,
        auto_balance    VARCHAR(20) NOT NULL DEFAULT '',
        auto_text       VARCHAR(500) NOT NULL DEFAULT '',
        auto_code       VARCHAR(20) NOT NULL DEFAULT '',
        auto_ok         TINYINT     NULL,
        auto_checked_at DATETIME    NULL,
        PRIMARY KEY (device_id, slot)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $conn->query("CREATE TABLE IF NOT EXISTS caller_iq_devices (
        device_id      VARCHAR(64)  NOT NULL,
        agent_name     VARCHAR(120) NOT NULL DEFAULT '',
        team           VARCHAR(80)  NOT NULL DEFAULT '',
        device_model   VARCHAR(120) NOT NULL DEFAULT '',
        app_version    VARCHAR(20)  NOT NULL DEFAULT '',
        last_ip        VARCHAR(64)  NOT NULL DEFAULT '',
        is_hidden      TINYINT      NOT NULL DEFAULT 0,
        popup_ok       TINYINT      NULL,          -- can this phone show the post-call popup?
        first_seen_at  DATETIME     NOT NULL,
        last_seen_at   DATETIME     NOT NULL,
        last_call_at   DATETIME     NULL,
        manufacturer    VARCHAR(40) NOT NULL DEFAULT '',
        os_release      VARCHAR(16) NOT NULL DEFAULT '',
        sdk_int         SMALLINT    NULL,
        app_build       INT         NULL,
        health_json     TEXT        NULL,          -- the phone's own setup report (checkin.php)
        last_checkin_at DATETIME    NULL,
        PRIMARY KEY (device_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
}

/**
 * Which columns a table actually has, cached per request.
 *
 * Columns added after the first release (sim_source, tagged_via, popup_ok) are created by
 * ciq_ensure_schema(), but that only runs if THIS file is deployed — and a half-finished deploy,
 * or a database user without ALTER rights, must not take the whole page down with
 * "Unknown column in field list". Callers ask before they select.
 */
function ciq_columns(mysqli $conn, string $table): array
{
    if (isset($GLOBALS['__ciq_cols'][$table])) return $GLOBALS['__ciq_cols'][$table];
    $cols = [];
    if ($res = $conn->query("SHOW COLUMNS FROM `" . str_replace('`', '', $table) . "`")) {
        while ($r = $res->fetch_assoc()) $cols[$r['Field']] = true;
    }
    $GLOBALS['__ciq_cols'][$table] = $cols;
    return $cols;
}

function ciq_has_col(mysqli $conn, string $table, string $col): bool
{
    $cols = ciq_columns($conn, $table);
    return $cols === [] ? true : isset($cols[$col]);   // unknown table → assume fine, let SQL speak
}

/** Forget a cached column list — called right after an ALTER adds one. */
function ciq_forget_columns(?string $table = null): void
{
    if ($table === null) $GLOBALS['__ciq_cols'] = [];
    else unset($GLOBALS['__ciq_cols'][$table]);
}

/** The last 10 digits — how the same person matches across +91 / 0 / bare dialling. */
function ciq_norm_number(string $n): string
{
    $d = preg_replace('/\D+/', '', $n);
    if ($d === '' || strlen($d) < 5) return ''; // "UNKNOWN", "-1" (private), short codes
    return strlen($d) > 10 ? substr($d, -10) : $d;
}

/** The app sends INCOMING/OUTGOING/MISSED/REJECTED, or UNKNOWN_TYPE_<n> for the rest of CallLog.Calls.TYPE. */
function ciq_norm_type(string $t): string
{
    $t = strtoupper(trim($t));
    if (in_array($t, CIQ_TYPES, true)) return $t;
    if (preg_match('/(\d+)$/', $t, $m)) {
        switch ((int)$m[1]) {
            case 1: case 7: return 'INCOMING';   // 7 = answered on another device
            case 2: return 'OUTGOING';
            case 3: return 'MISSED';
            case 4: return 'VOICEMAIL';
            case 5: return 'REJECTED';
            case 6: return 'BLOCKED';
        }
    }
    return 'UNKNOWN';
}

function ciq_str($v, int $max): string
{
    return mb_substr(trim(is_scalar($v) ? (string)$v : ''), 0, $max);
}

const CIQ_LIVE_RANK = ['ringing' => 1, 'connected' => 2, 'ended' => 3];

/**
 * Record what a phone is doing right now. Returns ['ok'=>bool, 'reason'=>?].
 *
 * Events can arrive late, out of order, or twice (the direct send and its worker backup both
 * land), and phone clocks are not to be trusted, so:
 *  - the elapsed time comes from the phone (event_at − started_at) but is applied to the SERVER
 *    clock, so a phone set to the wrong date cannot show a call that started "yesterday";
 *  - an event for an older call than the one on file is ignored;
 *  - the state never moves backwards (a delayed "ringing" cannot undo "connected").
 */
function ciq_live_update(mysqli $conn, array $c): array
{
    $device = substr(preg_replace('/[^A-Za-z0-9_\-:.]/', '', (string)($c['device_id'] ?? '')), 0, 64);
    $state  = ciq_str($c['state'] ?? '', 12);
    if (!isset(CIQ_LIVE_RANK[$state])) return ['ok' => false, 'reason' => 'unknown state'];

    $dir = ciq_str($c['direction'] ?? '', 10);
    if (!in_array($dir, ['incoming', 'outgoing', 'unknown'], true)) $dir = 'unknown';

    $number = ciq_str($c['number'] ?? '', 40);
    $norm   = $number === '' ? '' : ciq_norm_number($number);

    $startedMs = (int)round((float)($c['started_at'] ?? 0));
    $eventMs   = (int)round((float)($c['event_at'] ?? 0));
    if ($eventMs <= 0) $eventMs = $startedMs;
    $elapsed = ($startedMs > 0 && $eventMs >= $startedMs) ? (int)floor(($eventMs - $startedMs) / 1000) : 0;
    $elapsed = max(0, min(6 * 3600, $elapsed));           // a 6-hour call is a stuck row, not a call

    $now       = time();
    $startedAt = date('Y-m-d H:i:s', $now - $elapsed);
    $nowStr    = date('Y-m-d H:i:s', $now);

    $answeredMs = (int)round((float)($c['answered_at'] ?? 0));
    $answeredAt = null;
    /* Only an incoming call has a knowable answer time (ringing → off hook). For an outgoing one
       Android reports dialling and talking as the same state, so builds up to 1.4 sent the DIAL
       time as "answered" — which the panel then counted as talk time. Refused here, so an old app
       cannot show a figure that is really "time since dialled". */
    if ($dir !== 'outgoing' && $answeredMs > 0 && $startedMs > 0 && $answeredMs >= $startedMs) {
        $answeredAt = date('Y-m-d H:i:s', $now - max(0, min(6 * 3600, (int)floor(($eventMs - $answeredMs) / 1000))));
    }

    $slot = (isset($c['sim_slot']) && is_numeric($c['sim_slot'])) ? (int)$c['sim_slot'] : null;
    if ($slot !== null && ($slot < 1 || $slot > 9)) $slot = null;
    $simLabel = ciq_str($c['sim_label'] ?? '', 120);
    $carrier  = ciq_str($c['carrier'] ?? '', 80);

    /* The real talk time, sent once the call log exists. For an outgoing call this is the only
       evidence that it was ever answered — Android reports dialling and talking identically. */
    $durSec = (isset($c['duration_sec']) && is_numeric($c['duration_sec']))
        ? max(0, min(6 * 3600, (int)$c['duration_sec'])) : null;

    /*
     * One row per phone, reused for every call — so the row must be told, explicitly, whether
     * this event belongs to the call already in it or to a NEW call.
     *
     * The old version left that to ON DUPLICATE KEY UPDATE:
     *     started_ms = VALUES(started_ms),
     *     started_at = IF(VALUES(started_ms) = started_ms, started_at, VALUES(started_at))
     * MySQL applies those left to right, so by the time started_at was decided started_ms had
     * already been overwritten, the test was always true, and started_at stayed frozen at the
     * phone's FIRST call ever. The live list keeps a connected call only while started_at is
     * under 6 hours old — so every outgoing call (only ever "connected") and every answered call
     * vanished, and only ringing (aged by updated_at instead) ever showed. The same pattern also
     * carried the previous call's answer time and talk time into the next one.
     *
     * Now every value is settled here in PHP and written as-is.
     */
    $prev = null;
    if ($st = $conn->prepare("SELECT state, direction, number, sim_slot, sim_label, carrier, started_ms,
                                     started_at, answered_at, duration_sec
                              FROM caller_iq_live WHERE device_id = ? LIMIT 1")) {
        $st->bind_param('s', $device);
        $st->execute();
        $prev = $st->get_result()->fetch_assoc() ?: null;
        $st->close();
    }

    if ($prev) {
        $prevStarted = (int)$prev['started_ms'];
        /* The final "ended + real talk time" update is timed from the CALL LOG's start, which sits
           a second or so either side of the live start the phone recorded at the first broadcast.
           Within two minutes, and carrying a talk time, it is this same call — not an older one to
           discard (which is what used to happen, losing the real duration). */
        // Only onto a call already marked ended: the phone always sends "ended" first, so a row still
        // ringing or connected is a NEWER call (a quick redial) that this late update must not touch.
        $finalForThisCall = $state === 'ended' && $prev['state'] === 'ended' && $durSec !== null
            && $startedMs > 0 && abs($prevStarted - $startedMs) <= 30000;
        if (!$finalForThisCall && $startedMs > 0 && $prevStarted > $startedMs) {
            return ['ok' => true, 'reason' => 'older event ignored'];     // a late event from a finished call
        }
        /* The same call: identical phone start time, an event that carries none, or its final update. */
        $sameCall = $startedMs <= 0 || $prevStarted === $startedMs || $finalForThisCall;
        if ($finalForThisCall) $startedMs = $prevStarted;
        if ($sameCall) {
            if (CIQ_LIVE_RANK[$state] < CIQ_LIVE_RANK[$prev['state']]) {
                return ['ok' => true, 'reason' => 'state would go backwards'];
            }
            // Keep what this call already established; later events only add to it.
            if ($startedMs <= 0) $startedMs = $prevStarted;
            $startedAt = $prev['started_at'];
            // The final update is authoritative about the talk time, even over an earlier guess.
            if ($answeredAt === null && !empty($prev['answered_at'])) $answeredAt = $prev['answered_at'];
            if ($durSec === null && $prev['duration_sec'] !== null) $durSec = (int)$prev['duration_sec'];
            if ($dir === 'unknown' && $prev['direction'] !== '') $dir = $prev['direction'];
            if ($number === '' && $prev['number'] !== '') { $number = $prev['number']; $norm = ciq_norm_number($number); }
            if ($slot === null && $prev['sim_slot'] !== null) $slot = (int)$prev['sim_slot'];
            if ($simLabel === '') $simLabel = (string)$prev['sim_label'];
            if ($carrier === '') $carrier = (string)$prev['carrier'];
        }
        // A new call starts clean: nothing of the previous call's is carried over.
    }

    $endedAt = $state === 'ended' ? $nowStr : null;

    $sql = "INSERT INTO caller_iq_live
              (device_id, state, direction, number, number_norm, sim_slot, sim_label, carrier,
               started_ms, started_at, answered_at, ended_at, duration_sec, updated_at)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)
            ON DUPLICATE KEY UPDATE
              state = VALUES(state), direction = VALUES(direction), number = VALUES(number),
              number_norm = VALUES(number_norm), sim_slot = VALUES(sim_slot), sim_label = VALUES(sim_label),
              carrier = VALUES(carrier), started_ms = VALUES(started_ms), started_at = VALUES(started_at),
              answered_at = VALUES(answered_at), ended_at = VALUES(ended_at), duration_sec = VALUES(duration_sec),
              updated_at = VALUES(updated_at)";
    $stmt = $conn->prepare($sql);
    if (!$stmt) return ['ok' => false, 'reason' => 'prepare failed: ' . $conn->error];
    $stmt->bind_param('sssssississsis',
        $device, $state, $dir, $number, $norm, $slot, $simLabel, $carrier,
        $startedMs, $startedAt, $answeredAt, $endedAt, $durSec, $nowStr);
    $ok = $stmt->execute();
    $err = $stmt->error;
    $stmt->close();
    return $ok ? ['ok' => true] : ['ok' => false, 'reason' => $err];
}

/** How far either side of a call's start a tag may be matched to it. */
const CIQ_TAG_WINDOW_MS = 180000;

/**
 * Attach an outcome to the call it belongs to.
 *
 * Returns ['matched' => bool, 'id' => ?int]. When nothing matches — the usual case for a tag
 * tapped a second after hang-up — the caller stores it as pending instead.
 */
function ciq_apply_tag(mysqli $conn, string $device, string $key, string $numberNorm, int $startedMs, string $outcome, string $via): array
{
    $now = date('Y-m-d H:i:s');
    $src = $via !== '' ? $via : 'popup';

    $id = null;
    // The exact call, when the phone already knew its call-log key.
    if ($key !== '') {
        if ($st = $conn->prepare("SELECT id FROM caller_iq_calls WHERE device_id = ? AND idempotency_key = ? LIMIT 1")) {
            $st->bind_param('ss', $device, $key);
            $st->execute();
            $row = $st->get_result()->fetch_assoc();
            $st->close();
            if ($row) $id = (int)$row['id'];
        }
    }

    /* Otherwise the nearest call from this phone around that moment. Same number wins over a
       closer one, so two calls in quick succession cannot swap tags. */
    if ($id === null && $startedMs > 0) {
        $lo = $startedMs - CIQ_TAG_WINDOW_MS;
        $hi = $startedMs + CIQ_TAG_WINDOW_MS;
        $sql = "SELECT id FROM caller_iq_calls
                WHERE device_id = ? AND call_ts_ms BETWEEN ? AND ?" .
               ($numberNorm !== '' ? " AND number_norm = ?" : '') . "
                ORDER BY ABS(call_ts_ms - ?) ASC LIMIT 1";
        if ($st = $conn->prepare($sql)) {
            if ($numberNorm !== '') $st->bind_param('siisi', $device, $lo, $hi, $numberNorm, $startedMs);
            else                    $st->bind_param('siii', $device, $lo, $hi, $startedMs);
            $st->execute();
            $row = $st->get_result()->fetch_assoc();
            $st->close();
            if ($row) $id = (int)$row['id'];
        }
    }

    if ($id === null) return ['matched' => false, 'id' => null];

    /* tagged_via arrived after the first release; on a database that has not been altered yet the
       tag still lands, it simply does not record which prompt it came from. */
    if (ciq_has_col($conn, 'caller_iq_calls', 'tagged_via')) {
        if ($st = $conn->prepare("UPDATE caller_iq_calls
                                  SET outcome = ?, outcome_at = ?, outcome_source = ?, tagged_via = ?
                                  WHERE id = ?")) {
            $st->bind_param('ssssi', $outcome, $now, $src, $src, $id);
            $st->execute();
            $st->close();
        }
    } elseif ($st = $conn->prepare("UPDATE caller_iq_calls
                                    SET outcome = ?, outcome_at = ?, outcome_source = ?
                                    WHERE id = ?")) {
        $st->bind_param('sssi', $outcome, $now, $src, $id);
        $st->execute();
        $st->close();
    }
    return ['matched' => true, 'id' => $id];
}

/** Park a tag until its call turns up. */
function ciq_store_pending_tag(mysqli $conn, string $device, string $numberNorm, int $startedMs, string $outcome, string $via): void
{
    $now = date('Y-m-d H:i:s');
    // Re-tagging the same call before it syncs replaces the earlier choice.
    if ($st = $conn->prepare("DELETE FROM caller_iq_pending_tags WHERE device_id = ? AND ABS(started_ms - ?) < 2000")) {
        $st->bind_param('si', $device, $startedMs);
        $st->execute();
        $st->close();
    }
    if ($st = $conn->prepare("INSERT INTO caller_iq_pending_tags (device_id, number_norm, started_ms, outcome, tagged_via, created_at)
                              VALUES (?,?,?,?,?,?)")) {
        $st->bind_param('ssisss', $device, $numberNorm, $startedMs, $outcome, $via, $now);
        $st->execute();
        $st->close();
    }
}

/** Called as each call arrives: hand it any tag that was waiting for it. */
function ciq_apply_pending_tags(mysqli $conn, string $device, int $callMs, string $numberNorm): void
{
    $lo = $callMs - CIQ_TAG_WINDOW_MS;
    $hi = $callMs + CIQ_TAG_WINDOW_MS;
    $sql = "SELECT id, outcome, tagged_via, number_norm FROM caller_iq_pending_tags
            WHERE device_id = ? AND started_ms BETWEEN ? AND ?
            ORDER BY ABS(started_ms - ?) ASC LIMIT 5";
    $st = $conn->prepare($sql);
    if (!$st) return;
    $st->bind_param('siii', $device, $lo, $hi, $callMs);
    $st->execute();
    $rows = $st->get_result()->fetch_all(MYSQLI_ASSOC);
    $st->close();

    foreach ($rows as $p) {
        // A pending tag that named a number only belongs to that number's call.
        if ($p['number_norm'] !== '' && $numberNorm !== '' && $p['number_norm'] !== $numberNorm) continue;
        $r = ciq_apply_tag($conn, $device, '', $numberNorm, $callMs, $p['outcome'], $p['tagged_via']);
        if ($r['matched']) {
            if ($d = $conn->prepare("DELETE FROM caller_iq_pending_tags WHERE id = ?")) {
                $d->bind_param('i', $p['id']);
                $d->execute();
                $d->close();
            }
        }
    }

    /* Anything still unclaimed after a day never will be. The cut-off is PHP's clock, not
       MySQL's NOW() — the two differ on this host, and created_at is written by PHP. */
    $cutoff = $conn->real_escape_string(date('Y-m-d H:i:s', time() - 86400));
    $conn->query("DELETE FROM caller_iq_pending_tags WHERE created_at < '$cutoff'");
}

/**
 * Note that a SIM exists, from the evidence a call carries. Only ever fills blanks: the carrier,
 * the label and the SIM's own number are refreshed, and the plan a person recorded is left alone.
 */
function ciq_touch_sim(mysqli $conn, string $device, int $slot, string $carrier, string $label, string $msisdn): void
{
    if ($slot < 1) return;
    $now = date('Y-m-d H:i:s');
    $st = $conn->prepare("INSERT INTO caller_iq_sims (device_id, slot, msisdn, carrier, label, first_seen_at, updated_at)
        VALUES (?,?,?,?,?,?,?)
        ON DUPLICATE KEY UPDATE
          msisdn  = IF(VALUES(msisdn) = '', msisdn, VALUES(msisdn)),
          carrier = IF(VALUES(carrier) = '', carrier, VALUES(carrier)),
          label   = IF(VALUES(label) = '', label, VALUES(label))");
    if (!$st) return;
    $st->bind_param('sisssss', $device, $slot, $msisdn, $carrier, $label, $now, $now);
    $st->execute();
    $st->close();
}

/**
 * Store what the operator replied to a USSD balance check.
 *
 * Only the auto_* columns are written: whatever a person typed into the register stays exactly as
 * they left it, and the panel shows the human record first, falling back to this. The raw reply is
 * always kept — even when no date could be picked out of it, a person reads "Validity 25-Sep-26"
 * at a glance, which is the whole point of asking.
 */
function ciq_sim_status(mysqli $conn, array $in): array
{
    $device = substr(preg_replace('/[^A-Za-z0-9_\-:.]/', '', (string)($in['device_id'] ?? '')), 0, 64);
    $slot   = (int)($in['slot'] ?? 0);
    if ($slot < 1 || $slot > 9) return ['ok' => false, 'reason' => 'a SIM slot is required'];

    $ok      = !empty($in['ok']) ? 1 : 0;
    $text    = ciq_str($in['text'] ?? '', 500);
    $code    = ciq_str($in['code'] ?? '', 20);
    $balance = ciq_str($in['balance'] ?? '', 20);
    $carrier = ciq_str($in['carrier'] ?? '', 80);
    $till    = (is_string($in['valid_till'] ?? null) && preg_match('/^\d{4}-\d{2}-\d{2}$/', $in['valid_till']))
        ? $in['valid_till'] : null;
    $now     = date('Y-m-d H:i:s');

    $st = $conn->prepare("INSERT INTO caller_iq_sims
            (device_id, slot, carrier, auto_valid_till, auto_balance, auto_text, auto_code, auto_ok, auto_checked_at,
             first_seen_at, updated_at)
          VALUES (?,?,?,?,?,?,?,?,?,?,?)
          ON DUPLICATE KEY UPDATE
            carrier         = IF(VALUES(carrier) = '', carrier, VALUES(carrier)),
            auto_valid_till = COALESCE(VALUES(auto_valid_till), auto_valid_till),
            auto_balance    = IF(VALUES(auto_balance) = '', auto_balance, VALUES(auto_balance)),
            auto_text       = VALUES(auto_text),
            auto_code       = VALUES(auto_code),
            auto_ok         = VALUES(auto_ok),
            auto_checked_at = VALUES(auto_checked_at)");
    if (!$st) return ['ok' => false, 'reason' => 'prepare failed: ' . $conn->error];
    $st->bind_param('sissssssiss', $device, $slot, $carrier, $till, $balance, $text, $code, $ok, $now, $now, $now);
    $done = $st->execute();
    $err = $st->error;
    $st->close();
    return $done ? ['ok' => true, 'parsed_valid_till' => $till, 'parsed_balance' => $balance]
                 : ['ok' => false, 'reason' => $err];
}

/** Close the live row once the finished call itself arrives. */
/**
 * Close the live row for a call that has just been logged — only if the live row IS that call
 * (started within a minute of it). A late upload of an earlier call must never close the call
 * the counselor is on right now.
 */
function ciq_live_close_for_call(mysqli $conn, string $device, int $endMs, int $startMs = 0): void
{
    if ($device === '') return;
    $now = date('Y-m-d H:i:s');
    $st = $conn->prepare("UPDATE caller_iq_live
                          SET state = 'ended', ended_at = COALESCE(ended_at, ?), updated_at = ?
                          WHERE device_id = ? AND state <> 'ended' AND started_ms BETWEEN ? AND ?");
    if (!$st) return;
    $from = $startMs > 0 ? $startMs - 60000 : 0;
    $st->bind_param('sssii', $now, $now, $device, $from, $endMs);
    $st->execute();
    $st->close();
}

/**
 * Upsert one call. Returns ['ok'=>bool, 'reason'=>?, 'retry'=>bool].
 * A re-sent call (the app re-reads the last minutes of the log after every call)
 * only refreshes it; an outcome is never cleared by a later sync that has none.
 */
function ciq_ingest_call(mysqli $conn, array $c, string $ip): array
{
    $number = ciq_str($c['number'] ?? '', 40);
    $ts     = (int)round((float)($c['timestamp'] ?? 0));
    if ($number === '' || $ts <= 0) return ['ok' => false, 'retry' => false, 'reason' => 'number and timestamp are required'];
    if ($ts < 100000000000) $ts *= 1000; // seconds, not ms

    $device   = substr(preg_replace('/[^A-Za-z0-9_\-:.]/', '', (string)($c['device_id'] ?? '')), 0, 64);
    $key      = ciq_str($c['idempotency_key'] ?? '', 120);
    if ($key === '') $key = "{$number}_{$ts}";
    $rawType  = ciq_str($c['call_type'] ?? '', 40);
    $type     = ciq_norm_type($rawType);
    $dur      = max(0, min(86400, (int)($c['duration'] ?? 0)));
    $ring     = null;
    if (in_array($type, ['MISSED', 'REJECTED', 'BLOCKED'], true)) { $ring = $dur ?: null; $dur = 0; }
    $simId    = ciq_str($c['sim_id'] ?? '', 64);
    /* Slot 0 means the app could not identify the SIM. It is stored as NULL, never guessed at:
       a wrong "SIM 1" is worse than an honest "Unknown SIM" on the dashboard. */
    $slot     = (isset($c['sim_slot']) && is_numeric($c['sim_slot'])) ? (int)$c['sim_slot'] : null;
    if ($slot !== null && ($slot < 1 || $slot > 9)) $slot = null;
    $simLabel = ciq_str($c['sim_label'] ?? '', 120);
    $carrier  = ciq_str($c['carrier'] ?? '', 80);
    $simSrc   = ciq_str($c['sim_source'] ?? '', 16);
    $outcome  = ciq_str($c['outcome'] ?? '', 60);
    $outcome  = $outcome === '' ? null : $outcome;
    $outAt    = $outcome === null ? null : date('Y-m-d H:i:s');
    /* Where the tag came from: the post-call popup, its notification fallback, the app's own
       list, or an older build that did not say (recorded as 'device'). */
    $via      = ciq_str($c['tagged_via'] ?? '', 16);
    if (!in_array($via, ['popup', 'notification', 'app', 'device'], true)) $via = '';
    $outSrc   = $outcome === null ? null : ($via !== '' ? $via : 'device');
    $callAt   = date('Y-m-d H:i:s', intdiv($ts, 1000));
    $now      = date('Y-m-d H:i:s');
    $norm     = ciq_norm_number($number);

    /* Assignment order matters: MySQL evaluates ON DUPLICATE KEY UPDATE left to
       right and later expressions see earlier results, so outcome_at/_source are
       decided while `outcome` still holds the stored value. */
    $hasRing = ciq_has_col($conn, 'caller_iq_calls', 'ring_sec');
    $ringCol = $hasRing ? ', ring_sec' : '';
    $ringPh  = $hasRing ? ',?' : '';
    $ringUpd = $hasRing ? 'ring_sec = COALESCE(VALUES(ring_sec), ring_sec),' : '';
    $stmt = $conn->prepare("INSERT INTO caller_iq_calls
          (device_id, idempotency_key, number, number_norm, call_type, raw_call_type, duration_sec, call_ts_ms, call_at,
           sim_id, sim_slot, sim_label, carrier, sim_source, tagged_via, outcome, outcome_at, outcome_source, first_synced_at, last_synced_at$ringCol)
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?$ringPh)
        ON DUPLICATE KEY UPDATE
          call_type      = VALUES(call_type),
          raw_call_type  = VALUES(raw_call_type),
          duration_sec   = IF(VALUES(call_type) IN ('MISSED','REJECTED','BLOCKED'), 0, GREATEST(duration_sec, VALUES(duration_sec))),
          $ringUpd
          sim_id         = IF(VALUES(sim_id) = '', sim_id, VALUES(sim_id)),
          sim_slot       = COALESCE(VALUES(sim_slot), sim_slot),
          sim_label      = IF(VALUES(sim_label) = '', sim_label, VALUES(sim_label)),
          carrier        = IF(VALUES(carrier) = '', carrier, VALUES(carrier)),
          sim_source     = IF(VALUES(sim_source) = '', sim_source, VALUES(sim_source)),
          tagged_via     = IF(VALUES(tagged_via) = '', tagged_via, VALUES(tagged_via)),
          outcome_at     = IF(VALUES(outcome) IS NOT NULL AND NOT (outcome <=> VALUES(outcome)), VALUES(outcome_at), outcome_at),
          outcome_source = IF(VALUES(outcome) IS NOT NULL AND NOT (outcome <=> VALUES(outcome)), VALUES(outcome_source), outcome_source),
          outcome        = COALESCE(VALUES(outcome), outcome),
          last_synced_at = VALUES(last_synced_at),
          sync_count     = sync_count + 1");
    if (!$stmt) return ['ok' => false, 'retry' => true, 'reason' => 'prepare failed: ' . $conn->error];
    $params = [$device, $key, $number, $norm, $type, $rawType, $dur, $ts, $callAt,
               $simId, $slot, $simLabel, $carrier, $simSrc, $via, $outcome, $outAt, $outSrc, $now, $now];
    $types  = 'ssssssiississsssssss';
    if ($hasRing) { $params[] = $ring; $types .= 'i'; }
    $stmt->bind_param($types, ...$params);
    if (!$stmt->execute()) {
        $err = $stmt->error; $stmt->close();
        return ['ok' => false, 'retry' => true, 'reason' => 'insert failed: ' . $err];
    }
    $stmt->close();

    /* A call that has been logged is over. If its phone never managed to report the end (killed
       mid-call, no signal), close the live row here so the dashboard stops showing it. */
    ciq_live_close_for_call($conn, $device, $ts + (($dur + (int)($ring ?? 0)) * 1000), $ts);

    /* Hand this call any outcome that was tagged on the popup before the call itself arrived. */
    if ($outcome === null) ciq_apply_pending_tags($conn, $device, $ts, $norm);

    /* Every call tells us a SIM exists: register it, so the recharge list fills itself in and the
       only thing left to type is the plan. Never overwrites what a person recorded. */
    if ($slot !== null) {
        ciq_touch_sim($conn, $device, $slot, $carrier, $simLabel, ciq_str($c['sim_msisdn'] ?? '', 20));
    }

    $model   = ciq_str($c['device_model'] ?? '', 120);
    $version = ciq_str($c['app_version'] ?? '', 20);
    $agent   = ciq_str($c['agent_name'] ?? '', 120);
    $ipS     = substr($ip, 0, 64);
    $popupOk = array_key_exists('popup_ok', $c) ? (int)(bool)$c['popup_ok'] : null;
    $d = $conn->prepare("INSERT INTO caller_iq_devices (device_id, agent_name, device_model, app_version, last_ip, popup_ok, first_seen_at, last_seen_at, last_call_at)
        VALUES (?,?,?,?,?,?,?,?,?)
        ON DUPLICATE KEY UPDATE
          agent_name   = IF(agent_name = '', VALUES(agent_name), agent_name),
          device_model = IF(VALUES(device_model) = '', device_model, VALUES(device_model)),
          app_version  = IF(VALUES(app_version) = '', app_version, VALUES(app_version)),
          last_ip      = VALUES(last_ip),
          popup_ok     = COALESCE(VALUES(popup_ok), popup_ok),
          last_seen_at = VALUES(last_seen_at),
          last_call_at = IF(last_call_at IS NULL OR VALUES(last_call_at) > last_call_at, VALUES(last_call_at), last_call_at)");
    if ($d) {
        $d->bind_param('sssssisss', $device, $agent, $model, $version, $ipS, $popupOk, $now, $now, $callAt);
        $d->execute(); // a device-row failure must never cost the call itself
        $d->close();
    }
    return ['ok' => true];
}

/**
 * A phone saying "I exist, and this is how I am set up" — sent by the app when its setup changes
 * and twice a day otherwise (checkin.php).
 *
 * This is what makes a phone appear on the dashboard the moment the app is installed, before it
 * has uploaded a single call, and what lets the dashboard say precisely which switch is off on
 * which phone. It never touches last_seen_at or last_call_at: those still mean "calls arrived".
 */
function ciq_checkin(mysqli $conn, array $in, string $ip): array
{
    $device = substr(preg_replace('/[^A-Za-z0-9_\-:.]/', '', (string)($in['device_id'] ?? '')), 0, 64);
    if ($device === '') return ['ok' => false, 'reason' => 'device_id is required'];

    $model  = ciq_str($in['device_model'] ?? '', 120);
    $manu   = ciq_str($in['manufacturer'] ?? '', 40);
    $os     = ciq_str($in['os_release'] ?? '', 16);
    $sdk    = isset($in['sdk']) && is_numeric($in['sdk']) ? max(0, min(999, (int)$in['sdk'])) : null;
    $ver    = ciq_str($in['app_version'] ?? '', 20);
    $build  = isset($in['app_build']) && is_numeric($in['app_build']) ? max(0, (int)$in['app_build']) : null;
    $popup  = (array_key_exists('popup_ok', $in) && $in['popup_ok'] !== null) ? (int)(bool)$in['popup_ok'] : null;
    $health = is_array($in['health'] ?? null)
        ? json_encode($in['health'], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PARTIAL_OUTPUT_ON_ERROR)
        : null;
    if ($health !== null && strlen($health) > 60000) $health = null;   // TEXT limit; a sane report is ~2 KB
    $ipS = substr($ip, 0, 64);
    $now = date('Y-m-d H:i:s');   // PHP's clock, never MySQL's — they differ on this host

    $st = $conn->prepare("INSERT INTO caller_iq_devices
            (device_id, device_model, app_version, last_ip, popup_ok, manufacturer, os_release, sdk_int, app_build,
             health_json, first_seen_at, last_seen_at, last_checkin_at)
          VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)
          ON DUPLICATE KEY UPDATE
            device_model    = IF(VALUES(device_model) = '', device_model, VALUES(device_model)),
            app_version     = IF(VALUES(app_version) = '', app_version, VALUES(app_version)),
            last_ip         = VALUES(last_ip),
            popup_ok        = COALESCE(VALUES(popup_ok), popup_ok),
            manufacturer    = IF(VALUES(manufacturer) = '', manufacturer, VALUES(manufacturer)),
            os_release      = IF(VALUES(os_release) = '', os_release, VALUES(os_release)),
            sdk_int         = COALESCE(VALUES(sdk_int), sdk_int),
            app_build       = COALESCE(VALUES(app_build), app_build),
            health_json     = COALESCE(VALUES(health_json), health_json),
            last_checkin_at = VALUES(last_checkin_at)");
    if (!$st) return ['ok' => false, 'reason' => 'prepare failed: ' . $conn->error];
    $st->bind_param('ssssissiissss', $device, $model, $ver, $ipS, $popup, $manu, $os, $sdk, $build, $health, $now, $now, $now);
    $done = $st->execute();
    $err  = $st->error;
    $st->close();
    return $done ? ['ok' => true] : ['ok' => false, 'reason' => $err];
}

<?php
/*
 * /api/freshdesk/lib/config.php
 *
 * Every tunable for the Freshdesk helpdesk lives here. Two layers:
 *
 *   1. The define()s below — compiled-in defaults. Safe to ship, safe to read.
 *   2. The `fd_settings` DB table — per-install overrides edited from
 *      Settings -> Email / Realtime in the UI. fd_cfg() reads the DB value first
 *      and falls back to the define(). ALWAYS read config through fd_cfg(),
 *      never through the constant directly, or UI edits silently do nothing.
 *
 * The mailbox credentials are the real contact@internshipstudio.com ones the
 * rest of the site already uses; the Pusher block is intentionally DUMMY --
 * replace it in Settings -> Realtime (or here) once the real app is created at
 * pusher.com. Nothing breaks while it is dummy: fd_pusher_enabled() returns
 * false for placeholder values and the frontend transparently falls back to
 * short-interval polling (see fd_realtime.php + useFreshdeskRealtime.js).
 */

/* -- Incoming mail (IMAP) -------------------------------------------------- */
if (!defined('FD_IMAP_HOST'))     define('FD_IMAP_HOST', 'mailhost.internshipstudio.com');
if (!defined('FD_IMAP_PORT'))     define('FD_IMAP_PORT', 993);
// 'ssl' = implicit TLS on 993 (normal), 'tls' = STARTTLS on 143, 'plain' = no crypto (never use in prod)
if (!defined('FD_IMAP_SECURITY')) define('FD_IMAP_SECURITY', 'ssl');
if (!defined('FD_IMAP_USER'))     define('FD_IMAP_USER', 'contact@internshipstudio.com');
if (!defined('FD_IMAP_PASS'))     define('FD_IMAP_PASS', '5Hbe!j9rhbal~po1');
if (!defined('FD_IMAP_FOLDER'))   define('FD_IMAP_FOLDER', 'INBOX');
// Where a sent reply is IMAP-APPENDed so it also shows in Roundcube/Outlook's Sent.
// cPanel/Dovecot uses 'INBOX.Sent'; Gmail-style servers use '[Gmail]/Sent Mail'. Empty = skip.
if (!defined('FD_IMAP_SENT_FOLDER')) define('FD_IMAP_SENT_FOLDER', 'INBOX.Sent');
// Shared-host mail servers drop idle sockets aggressively; keep this generous.
if (!defined('FD_IMAP_TIMEOUT'))  define('FD_IMAP_TIMEOUT', 30);
// Self-signed / mismatched certs are common on cPanel mailhosts. 0 = don't verify.
// Flip to 1 once you have confirmed the cert matches FD_IMAP_HOST.
if (!defined('FD_IMAP_VERIFY_PEER')) define('FD_IMAP_VERIFY_PEER', 0);

/* -- Outgoing mail (SMTP) -------------------------------------------------- */
if (!defined('FD_SMTP_HOST'))     define('FD_SMTP_HOST', 'mailhost.internshipstudio.com');
if (!defined('FD_SMTP_PORT'))     define('FD_SMTP_PORT', 587);
if (!defined('FD_SMTP_SECURITY')) define('FD_SMTP_SECURITY', 'tls');   // 'tls' (587) | 'ssl' (465) | '' (25)
if (!defined('FD_SMTP_USER'))     define('FD_SMTP_USER', 'contact@internshipstudio.com');
if (!defined('FD_SMTP_PASS'))     define('FD_SMTP_PASS', '5Hbe!j9rhbal~po1');
if (!defined('FD_FROM_EMAIL'))    define('FD_FROM_EMAIL', 'contact@internshipstudio.com');
if (!defined('FD_FROM_NAME'))     define('FD_FROM_NAME', 'Internship Studio Support');
if (!defined('FD_REPLY_TO'))      define('FD_REPLY_TO', 'contact@internshipstudio.com');

/*
 * The ticket token stamped into every outgoing Subject as e.g. "[#IS-336270]".
 * This is the PRIMARY threading key: mail clients mangle References headers,
 * strip In-Reply-To, and rewrite subjects, but almost all of them preserve the
 * bracketed token when the human hits Reply. Changing this prefix orphans every
 * in-flight conversation, so treat it as permanent once live.
 */
if (!defined('FD_TICKET_TOKEN_PREFIX')) define('FD_TICKET_TOKEN_PREFIX', 'IS');
// Ticket numbers start here so they look like an established desk rather than #1.
if (!defined('FD_TICKET_NUMBER_START')) define('FD_TICKET_NUMBER_START', 336000);

/* -- Realtime (Pusher Channels) - DUMMY VALUES, replace in Settings -> Realtime */
if (!defined('FD_PUSHER_APP_ID'))  define('FD_PUSHER_APP_ID', '1234567');
if (!defined('FD_PUSHER_KEY'))     define('FD_PUSHER_KEY', 'dummy_pusher_key_replace_me');
if (!defined('FD_PUSHER_SECRET'))  define('FD_PUSHER_SECRET', 'dummy_pusher_secret_replace_me');
if (!defined('FD_PUSHER_CLUSTER')) define('FD_PUSHER_CLUSTER', 'ap2');
if (!defined('FD_PUSHER_TLS'))     define('FD_PUSHER_TLS', 1);
// One private channel for the whole desk. Private (not public) so a Pusher key
// leaking from the JS bundle still cannot be used to read your customers' mail --
// subscribing requires a signed grant from fd_realtime.php, which requires a JWT.
if (!defined('FD_PUSHER_CHANNEL')) define('FD_PUSHER_CHANNEL', 'private-freshdesk');
// Any value containing this substring is treated as "not configured yet".
if (!defined('FD_PUSHER_PLACEHOLDER')) define('FD_PUSHER_PLACEHOLDER', 'dummy_pusher');

/* -- Sync worker ----------------------------------------------------------- */
// Shared secret for calling fd_sync.php over HTTP from cron/uptime-pings without a JWT.
if (!defined('FD_CRON_SECRET')) define('FD_CRON_SECRET', 'fd_5c1a9e7b3d0f6a2c8e4b1d7f9a3c6e0b5d2f8a4c1e7b3d9f6a0c5e2b8d4f1a7c');
// Messages pulled per sync run. The worker walks UIDs oldest->newest, so a backlog
// drains over consecutive runs instead of one request timing out mid-mailbox.
if (!defined('FD_SYNC_BATCH'))  define('FD_SYNC_BATCH', 40);
// Hard wall-clock stop, well under PHP's max_execution_time, so the worker always
// gets to commit its watermark instead of being killed holding it.
if (!defined('FD_SYNC_MAX_SECONDS')) define('FD_SYNC_MAX_SECONDS', 50);
// First-ever sync on a mailbox with 40k old messages must not import all of them.
// Only mail newer than this many days is ingested on the initial run.
if (!defined('FD_SYNC_INITIAL_DAYS')) define('FD_SYNC_INITIAL_DAYS', 7);
// Send an automatic "we got your mail" acknowledgement on brand-new tickets.
if (!defined('FD_AUTO_ACK')) define('FD_AUTO_ACK', 0);

/*
 * Drop an out-of-office / auto-responder that does not thread onto an existing
 * ticket. On by default: an auto-reply to a conversation this desk never had is
 * noise, not a support request. (Bounces are ALWAYS dropped when orphaned --
 * that is not configurable, because hundreds of "message delayed 72 hours"
 * tickets is never what anyone wants.)
 */
if (!defined('FD_SKIP_ORPHAN_AUTOREPLIES')) define('FD_SKIP_ORPHAN_AUTOREPLIES', 1);

/*
 * Auto-close tickets with no activity for this many days. 0 = off (default).
 *
 * This is the "it happens on its own" half of keeping the queue honest: mail
 * that arrives, gets no reply and is never touched again would otherwise sit
 * Open forever, and a queue nobody can ever empty is a queue nobody reads.
 *
 * A ticket is only auto-closed when nothing has happened on it for the whole
 * window -- last_message_at is what is measured, so a customer replying resets
 * the clock and keeps their ticket open. Set from Settings > Mailbox.
 */
if (!defined('FD_AUTO_CLOSE_DAYS')) define('FD_AUTO_CLOSE_DAYS', 0);

/* -- Attachments ----------------------------------------------------------- */
if (!defined('FD_ATTACH_DIR')) define('FD_ATTACH_DIR', __DIR__ . '/../uploads');
if (!defined('FD_ATTACH_MAX_FILE_BYTES'))  define('FD_ATTACH_MAX_FILE_BYTES', 15 * 1024 * 1024);
if (!defined('FD_ATTACH_MAX_TOTAL_BYTES')) define('FD_ATTACH_MAX_TOTAL_BYTES', 25 * 1024 * 1024);
/*
 * Extension allowlist for files an AGENT uploads (outbound). Inbound attachments
 * from customers are NOT filtered by extension -- we must be able to show the
 * customer a .exe they mailed us -- they are instead stored with a randomised
 * name, served only through fd_attachments.php with Content-Disposition:
 * attachment and X-Content-Type-Options: nosniff, and never executed, because
 * the uploads dir carries an .htaccess that turns off the PHP handler.
 */
if (!defined('FD_ATTACH_ALLOWED_EXT')) {
    define('FD_ATTACH_ALLOWED_EXT', 'pdf,doc,docx,xls,xlsx,ppt,pptx,jpg,jpeg,png,gif,webp,svg,txt,csv,zip,rar,7z,mp4,mp3,eml,json,log');
}

/* -- Logging --------------------------------------------------------------- */
if (!defined('FD_LOG_PATH')) define('FD_LOG_PATH', __DIR__ . '/../freshdesk.log');
if (!defined('FD_LOG_MAX_BYTES')) define('FD_LOG_MAX_BYTES', 5 * 1024 * 1024);

/* -- SLA policy (minutes) -------------------------------------------------- */
// first-response target / resolution target, per priority.
if (!defined('FD_SLA_POLICY')) {
    define('FD_SLA_POLICY', '{"Urgent":{"first":30,"resolve":240},"Critical":{"first":30,"resolve":240},"High":{"first":60,"resolve":480},"Medium":{"first":240,"resolve":1440},"Low":{"first":480,"resolve":2880}}');
}
// A ticket flips to "At risk" once this fraction of its window is spent.
if (!defined('FD_SLA_RISK_RATIO')) define('FD_SLA_RISK_RATIO', 0.75);

/* ===========================================================================
   Settings overlay -- DB values win over the defines above
   ========================================================================== */

$GLOBALS['FD_SETTINGS_CACHE'] = null;

/**
 * Load the whole fd_settings table once per request.
 * Returns [] (never throws) if the table does not exist yet -- this function is
 * called from fd_log() and the schema bootstrap, so it must survive being run
 * before the table is created.
 */
function fd_settings_all() {
    if ($GLOBALS['FD_SETTINGS_CACHE'] !== null) return $GLOBALS['FD_SETTINGS_CACHE'];
    $out = array();
    global $conn;
    if ($conn) {
        try {
            $r = @$conn->query("SELECT setting_key, setting_value FROM fd_settings");
            if ($r) { while ($row = $r->fetch_assoc()) $out[$row['setting_key']] = $row['setting_value']; }
        } catch (Throwable $e) { /* table not created yet -- defaults only */ }
    }
    $GLOBALS['FD_SETTINGS_CACHE'] = $out;
    return $out;
}

/**
 * fd_cfg('IMAP_HOST') -> DB override, else the FD_IMAP_HOST constant, else $default.
 * Pass the key WITHOUT the FD_ prefix; both spellings are accepted for safety.
 */
function fd_cfg($key, $default = null) {
    $key  = preg_replace('/^FD_/', '', $key);
    $all  = fd_settings_all();
    if (array_key_exists($key, $all) && $all[$key] !== null && $all[$key] !== '') return $all[$key];
    $const = 'FD_' . $key;
    if (defined($const)) return constant($const);
    return $default;
}

/** Same as fd_cfg() but coerced to int -- for ports, timeouts, booleans-as-ints. */
function fd_cfg_int($key, $default = 0) {
    $v = fd_cfg($key, $default);
    return (int)$v;
}

/** Persist one setting (used by fd_settings.php). Invalidates the request cache. */
function fd_cfg_set($key, $value) {
    global $conn;
    $key = preg_replace('/^FD_/', '', $key);
    $stmt = $conn->prepare("INSERT INTO fd_settings (setting_key, setting_value) VALUES (?, ?)
                            ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value), updated_at = NOW()");
    if (!$stmt) return false;
    $stmt->bind_param('ss', $key, $value);
    $ok = $stmt->execute();
    $stmt->close();
    $GLOBALS['FD_SETTINGS_CACHE'] = null;
    return $ok;
}

/**
 * True only when Pusher has been given real credentials. Everything realtime
 * checks this first; when false the server skips the HTTP trigger entirely
 * (no wasted 200ms per reply) and the client polls instead.
 */
function fd_pusher_enabled() {
    $key    = (string)fd_cfg('PUSHER_KEY', '');
    $secret = (string)fd_cfg('PUSHER_SECRET', '');
    $appId  = (string)fd_cfg('PUSHER_APP_ID', '');
    if ($key === '' || $secret === '' || $appId === '') return false;
    $ph = FD_PUSHER_PLACEHOLDER;
    if (strpos($key, $ph) !== false || strpos($secret, $ph) !== false) return false;
    return true;
}

/** SLA targets for a priority, always returning a usable pair. */
function fd_sla_policy($priority) {
    $raw = fd_cfg('SLA_POLICY', FD_SLA_POLICY);
    $map = is_array($raw) ? $raw : json_decode((string)$raw, true);
    if (!is_array($map)) $map = json_decode(FD_SLA_POLICY, true);
    if (isset($map[$priority])) return $map[$priority];
    return array('first' => 240, 'resolve' => 1440);
}

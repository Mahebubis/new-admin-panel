<?php
/*
 * lib/Unsubscribe.php — our own unsubscribe, with a reason.
 *
 * WHY OURS RATHER THAN THE PROVIDER'S
 * SendGrid, Elastic Email and Amazon SES each offer a one-click unsubscribe that drops the address
 * into THEIR suppression list. Three providers means three lists, none of which this panel can see,
 * so an address that opted out through Elastic Email would keep being mailed the moment a campaign
 * went out through SES. It also tells us nothing: the address stops receiving mail and nobody ever
 * learns why, which is the one piece of information an unsubscribe actually carries.
 *
 * So the link points here. One page, one blocklist — the same list a hard bounce and a verification
 * failure already write to, and the one every campaign and journey already checks — plus the reason
 * the person gave.
 *
 * ── THE TOKEN ────────────────────────────────────────────────────────────────
 * The link has to identify the recipient from inside an email, with no session, possibly months
 * later, and possibly after the message row has been cleaned up. So it carries the address itself,
 * signed:
 *
 *     <base64url(email)>.<hmac-sha256(email, secret) truncated>
 *
 * Signed rather than plain for one specific reason: a bare email in a URL is an unsubscribe-anybody
 * button for whoever guesses an address, and the addresses here are guessable — they are students'
 * Gmail accounts. The HMAC makes a valid link something only we can mint.
 *
 * Not encrypted, because the person holding the link already knows the address: it is their own,
 * and it is in the To: header of the mail they are reading. Hiding it from them buys nothing and
 * would stop the page confirming which address it is about, which is worth more.
 */

require_once __DIR__ . '/config.php';

/** Its own secret, separate from CRON_SECRET: one is a server credential and this is minted into
 *  links sent to thousands of strangers, so rotating either must not be entangled with the other. */
if (!defined('UNSUB_SECRET')) {
    define('UNSUB_SECRET', 'unsub_3d7f1a9c4e8b2d6f0a5c3e9b7d1f4a8c2e6b0d5f3a9c7e1b4d8f2a6c0e5b3d9f');
}

/*
 * WHERE THE LINK IN THE EMAIL POINTS.
 *
 * The PHP page itself, which renders its own form, its own styling and its own confirmation. There
 * is no separate front end and nothing to keep in step: one file answers the click, asks the
 * question, writes the answer and says thank you.
 *
 * It is worth being explicit about why this is not the admin panel. The panel is a single-page app
 * behind a login; serving a public page from it means a route excluded from the session, a second
 * origin to allow through CORS, and a page that renders only after JavaScript has loaded. All of
 * that to show one form to somebody who wants to leave. This endpoint already has the token, the
 * database and the reasons list in the same process.
 */
if (!defined('UNSUB_PUBLIC_URL')) {
    define('UNSUB_PUBLIC_URL', 'https://cit3.internshipstudio.com/admin/react-api/api/campaigns/unsubscribe.php');
}

/*
 * The token every template's unsubscribe link carries, replaced per recipient at send time.
 *
 * Follows the XX_..._XX convention the rest of the merge tags use (see MergeTags.php), so it looks
 * like what it is to anyone editing a template and cannot collide with ordinary copy.
 */
if (!defined('UNSUB_TOKEN')) define('UNSUB_TOKEN', 'XX_UNSUBSCRIBE_URL_XX');

/*
 * THE TOKEN TEMPLATES CARRY NOW — the signed token ALONE, inside a link that is already a real URL.
 *
 * The old shape put a bare placeholder in the href and expected the sending code to swap in the
 * whole address. When that swap does not happen the recipient gets a link to "xx_unsubscribe_url_xx"
 * and their browser reports a DNS failure — which is what people actually received, because the
 * templates carrying the placeholder are shared through the database while the substitution lives
 * in code that one of the two sending machines had not been given yet.
 *
 * A template drift like that is not preventable from inside the template. What IS preventable is
 * the consequence: with the host and path baked in and only the token left to fill, an unsubstituted
 * link still lands on the unsubscribe page, which asks for the address instead of dead-ending in a
 * browser error. The legacy placeholder is still replaced wherever it appears, so templates written
 * before this keep working.
 */
if (!defined('UNSUB_TOKEN_ONLY')) define('UNSUB_TOKEN_ONLY', 'XX_UNSUBSCRIBE_TOKEN_XX');

/** The href a template stores: our page, with the per-recipient token still to be filled in. */
function unsub_template_href(): string {
    return UNSUB_PUBLIC_URL . '?u=' . UNSUB_TOKEN_ONLY;
}

/** URL-safe base64, so a token survives being a query parameter without escaping. */
function unsub_b64(string $raw): string {
    return rtrim(strtr(base64_encode($raw), '+/', '-_'), '=');
}
function unsub_b64_decode(string $enc): string {
    $s = strtr($enc, '-_', '+/');
    return (string)base64_decode(str_pad($s, strlen($s) % 4 ? strlen($s) + 4 - strlen($s) % 4 : strlen($s), '='), true);
}

/** The signed token for one address. */
function unsub_token(string $email): string {
    $email = strtolower(trim($email));
    if ($email === '') return '';
    $sig = substr(hash_hmac('sha256', $email, UNSUB_SECRET), 0, 32);
    return unsub_b64($email) . '.' . $sig;
}

/**
 * The address a token stands for, or null.
 *
 * hash_equals, not ===, so the comparison takes the same time whatever the input. A plain string
 * compare on an HMAC leaks how much of a guess was right, one byte at a time, which is enough to
 * forge a signature given enough attempts at a public endpoint.
 */
function unsub_email_from_token(string $token): ?string {
    $parts = explode('.', trim($token));
    if (count($parts) !== 2) return null;
    $email = strtolower(trim(unsub_b64_decode($parts[0])));
    if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) return null;
    $expect = substr(hash_hmac('sha256', $email, UNSUB_SECRET), 0, 32);
    return hash_equals($expect, $parts[1]) ? $email : null;
}

/** The full link for one address. */
function unsub_url(string $email): string {
    $t = unsub_token($email);
    return $t === '' ? '' : UNSUB_PUBLIC_URL . '?u=' . rawurlencode($t);
}

/* ════════════════════════════════════════════════════════════════════════════
   Schema
   ═══════════════════════════════════════════════════════════════════════════ */

function unsub_ensure_schema(): void {
    global $conn;
    static $done = false;
    if ($done) return;
    $done = true;

    /*
     * One row per opt-out, keeping the REASON.
     *
     * Separate from the blocklist rather than a column on it, because the two answer different
     * questions and are written by different things: the blocklist is "do not send", written by
     * bounces, verification and this; the reason is "what they told us", which only exists here and
     * is the entire reporting value of an unsubscribe. A person can also opt out twice from two
     * different campaigns, and both are worth keeping.
     */
    @$conn->query("CREATE TABLE IF NOT EXISTS email_unsubscribes (
        id          BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        email       VARCHAR(190) NOT NULL,
        reason_key  VARCHAR(40)  NOT NULL DEFAULT 'unspecified',
        reason_text VARCHAR(500) DEFAULT NULL,
        campaign_id BIGINT UNSIGNED DEFAULT NULL,
        journey_id  BIGINT UNSIGNED DEFAULT NULL,
        ip          VARCHAR(45)  DEFAULT NULL,
        user_agent  VARCHAR(255) DEFAULT NULL,
        created_at  DATETIME NOT NULL,
        INDEX idx_email (email),
        INDEX idx_reason (reason_key),
        INDEX idx_created (created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
}

/*
 * The reasons offered, in the order they are shown.
 *
 * Short, and worded as the person would say it rather than as the business would file it. The last
 * one is what makes the rest honest: without "something else" every answer is forced into a box
 * that may not fit, and the resulting report is confident and wrong.
 */
function unsub_reasons(): array {
    return [
        'too_frequent' => 'I get too many emails',
        'not_relevant' => 'The content is not relevant to me',
        'never_signed' => 'I never signed up for this',
        'no_longer'    => 'I am no longer looking for an internship',
        'spam'         => 'These emails look like spam',
        'other'        => 'Something else',
    ];
}

/* ════════════════════════════════════════════════════════════════════════════
   Recording
   ═══════════════════════════════════════════════════════════════════════════ */

/**
 * Records the opt-out and puts the address on the blocklist.
 *
 * The blocklist write is what actually stops the mail; the row above is why. Both happen here so
 * there is no path that records a reason without acting on it — an unsubscribe that is logged and
 * not honoured is worse than one that was never offered.
 *
 * @return bool whether anything was written (false only when the address is unusable)
 */
function unsub_record(string $email, string $reasonKey, string $reasonText = '',
                      ?int $campaignId = null, ?int $journeyId = null): bool {
    global $conn;

    $email = strtolower(trim($email));
    if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) return false;

    unsub_ensure_schema();

    $reasons = unsub_reasons();
    if (!isset($reasons[$reasonKey])) $reasonKey = 'unspecified';
    // Free text is trimmed hard: it is written by the public and read in the admin panel, and a
    // reason box is not a place anyone needs five hundred words.
    $reasonText = trim(mb_substr($reasonText, 0, 500));

    $conn->query("INSERT INTO email_unsubscribes
        (email, reason_key, reason_text, campaign_id, journey_id, ip, user_agent, created_at)
        VALUES ('" . $conn->real_escape_string($email) . "',
                '" . $conn->real_escape_string($reasonKey) . "',
                " . ($reasonText === '' ? 'NULL' : "'" . $conn->real_escape_string($reasonText) . "'") . ",
                " . ($campaignId ? (int)$campaignId : 'NULL') . ",
                " . ($journeyId ? (int)$journeyId : 'NULL') . ",
                '" . $conn->real_escape_string(substr((string)($_SERVER['REMOTE_ADDR'] ?? ''), 0, 45)) . "',
                '" . $conn->real_escape_string(substr((string)($_SERVER['HTTP_USER_AGENT'] ?? ''), 0, 255)) . "',
                NOW())");

    /*
     * On the blocklist, with the reason on the row.
     *
     * contact_upsert() rather than the bulk form: this is one person acting deliberately, and the
     * provider-side suppression it triggers as a side effect is genuinely wanted here — an opt-out
     * should hold even for mail sent from outside this panel.
     */
    if (function_exists('lists_get_or_create_blocklist_id') && function_exists('contact_upsert')) {
        $label = $reasons[$reasonKey] ?? 'Unsubscribed';
        $note  = 'Unsubscribed: ' . $label . ($reasonText !== '' ? ' — ' . $reasonText : '');
        @contact_upsert(['email' => $email], lists_get_or_create_blocklist_id(), mb_substr($note, 0, 480));
    }

    // Campaign reporting counts opt-outs, and the number is read straight off the campaign row.
    if ($campaignId) {
        @$conn->query("UPDATE email_campaigns SET unsubscribe_count = unsubscribe_count + 1 WHERE id = " . (int)$campaignId);
    }
    return true;
}

/** Has this address already opted out? Used to show "you are already unsubscribed" rather than
 *  silently recording a second row and implying the first one did not work. */
function unsub_already(string $email): bool {
    global $conn;
    unsub_ensure_schema();
    $r = @$conn->query("SELECT 1 FROM email_unsubscribes
                         WHERE email = '" . $conn->real_escape_string(strtolower(trim($email))) . "' LIMIT 1");
    return $r && $r->num_rows > 0;
}

/* ════════════════════════════════════════════════════════════════════════════
   Injection into the outgoing HTML
   ═══════════════════════════════════════════════════════════════════════════ */

/** The footer appended to an email whose template carries no unsubscribe link of its own. */
function unsub_default_footer(string $url): string {
    return '<div style="margin:28px auto 0;padding:18px 16px 22px;max-width:600px;'
         . 'border-top:1px solid #e2e8f0;font-family:Arial,Helvetica,sans-serif;'
         . 'font-size:12px;line-height:1.6;color:#94a3b8;text-align:center">'
         . 'You are receiving this because you registered with Internship Studio.<br>'
         . '<a href="' . htmlspecialchars($url, ENT_QUOTES) . '" '
         . 'style="color:#64748b;text-decoration:underline">Unsubscribe from these emails</a>'
         . '</div>';
}

/**
 * The footer stored INSIDE a template, carrying the token rather than a resolved URL.
 *
 * Deliberately a different thing from unsub_default_footer(): that one is minted per recipient at
 * send time with a real link in it, and storing a per-recipient URL in a shared template would
 * unsubscribe whoever was first into the editor for everybody who received it.
 */
function unsub_template_footer(): string {
    return "\n" . '<div style="margin:28px auto 0;padding:18px 16px 22px;max-width:600px;'
         . 'border-top:1px solid #e2e8f0;font-family:Arial,Helvetica,sans-serif;'
         . 'font-size:12px;line-height:1.6;color:#94a3b8;text-align:center">'
         . 'You are receiving this because you registered with Internship Studio.<br>'
         . '<a href="' . unsub_template_href() . '" style="color:#64748b;text-decoration:underline">'
         . 'Unsubscribe from these emails</a>'
         . '</div>' . "\n";
}

/** Does this HTML already offer a way out? */
/*
 * Every spelling of "put the unsubscribe link here" a template can hold.
 *
 * [UNSUBSCRIBEURL] is the older editor's token and is in seven templates — and nothing replaced
 * it, so the designed "unsubscribe" link in each of them was dead on every send. The editor's link
 * box also likes to put http:// in front of whatever is pasted, which turned the placeholder into
 * "http://XX_UNSUBSCRIBE_URL_XX" and then into a browser trying to reach a host of that name.
 * All of those are the same instruction and are answered with the same real link.
 */
if (!defined('UNSUB_TOKEN_LEGACY')) define('UNSUB_TOKEN_LEGACY', '[UNSUBSCRIBEURL]');

function unsub_html_has_link(string $html): bool {
    return strpos($html, UNSUB_TOKEN) !== false
        || strpos($html, UNSUB_TOKEN_LEGACY) !== false
        || strpos($html, UNSUB_TOKEN_ONLY) !== false
        || stripos($html, 'unsubscribe.php') !== false
        || stripos($html, '/unsubscribe?') !== false;
}

/**
 * Adds the footer to a template's HTML when it has none.
 *
 * Idempotent, which is what lets it run on every save and on the whole library at once without
 * stacking footers. Returns the HTML unchanged when a link is already there, so a template that
 * places its own — inside a designed footer, in another language, wherever — keeps it.
 */
function unsub_add_to_template(string $html): string {
    if (trim($html) === '' || unsub_html_has_link($html)) return $html;
    $footer = unsub_template_footer();
    if (preg_match('~</body\s*>~i', $html)) {
        return preg_replace('~</body\s*>~i', $footer . '$0', $html, 1);
    }
    return $html . $footer;
}

/**
 * Puts the real per-recipient link into the outgoing HTML.
 *
 * Two jobs, and the order matters:
 *   1. Replace XX_UNSUBSCRIBE_URL_XX wherever the template put it. A template that places its own
 *      link decides where it goes and what it says, which is what the template editor writes.
 *   2. If the template has NO unsubscribe link at all, append a plain one.
 *
 * The second is the important half. Every commercial email needs a way out, and relying on each
 * template to remember means the one that forgets is the one that generates spam complaints — and
 * a complaint costs the sending domain far more than an opt-out does.
 *
 * Deliberately AFTER click-tracking has rewritten the links: the unsubscribe URL must stay exactly
 * as minted. Sending it through the click tracker would bounce the person via a redirect that logs
 * a "click" on the campaign, inflating the click rate with people who were leaving.
 */
function inject_unsubscribe(string $html, string $email): string {
    $url = unsub_url($email);
    if ($url === '') return $html;

    /*
     * EVERY placeholder is replaced, not just the first kind found. A template commonly holds two:
     * its own designed link ([UNSUBSCRIBEURL] or XX_UNSUBSCRIBE_URL_XX) and the footer added on
     * save (XX_UNSUBSCRIBE_TOKEN_XX). Stopping at the first left the other one dead.
     */
    $found = false;

    /* The token alone, inside a link whose host and path the template already carries. */
    if (strpos($html, UNSUB_TOKEN_ONLY) !== false) {
        $html = str_replace(UNSUB_TOKEN_ONLY, rawurlencode(unsub_token($email)), $html);
        $found = true;
    }
    /* Whole-URL placeholders — with or without the http(s):// an editor put in front of them. */
    $safe = htmlspecialchars($url, ENT_QUOTES);
    foreach ([UNSUB_TOKEN, UNSUB_TOKEN_LEGACY] as $tok) {
        if (strpos($html, $tok) === false) continue;
        $html = str_ireplace(['https://' . $tok, 'http://' . $tok], $tok, $html);
        $html = str_replace($tok, $safe, $html);
        $found = true;
    }
    if ($found) return $html;

    // Already carries a hand-written link to our own page — leave it alone.
    if (stripos($html, 'unsubscribe.php') !== false || stripos($html, '/unsubscribe?') !== false) return $html;

    $footer = unsub_default_footer($url);
    // Inside </body> when there is one, so the footer sits in the document rather than after it.
    if (preg_match('~</body\s*>~i', $html)) {
        return preg_replace('~</body\s*>~i', $footer . '$0', $html, 1);
    }
    return $html . $footer;
}

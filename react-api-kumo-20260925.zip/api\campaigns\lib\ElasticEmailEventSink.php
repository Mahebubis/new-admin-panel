<?php
/*
 * Shared Elastic Email event handling — ONE mapping, TWO transports:
 *
 *   push  — elasticemail-webhook.php       Elastic Email POSTs one event per request
 *   pull  — elasticemail-events-poll.php   we GET /v4/events on a cron
 *
 * The pull path exists because webhooks are a PRO-plan feature at Elastic Email. On a plan
 * where Settings → Notifications → "Manage webhooks" is padlocked, nothing will ever POST to
 * the webhook, so delivered_count and bounce_count stay 0 forever no matter how many emails
 * actually arrive. GET /v4/events is NOT plan-gated and carries the same Sent/Error/Bounce
 * signals, so the poller can fill the same columns from the same vocabulary.
 *
 * The mapping lives here rather than in either caller specifically so the two cannot drift:
 * a change to bounce classification, blocklisting, or which counter moves lands on both at
 * once. That matters because they will normally run one at a time — whichever the account's
 * plan allows — so a bug introduced in the idle path would stay invisible until the day
 * someone upgrades and switches over.
 *
 * Events arrive as a flat array read case-insensitively, so the webhook hands over its raw
 * $_REQUEST untouched while the poller hands over a small array it has normalized from the
 * /v4/events field names (EventType→status, MsgID→messageid, MessageCategory→category).
 * Both callers therefore speak the WEBHOOK's vocabulary and this file only knows that one.
 */

require_once __DIR__ . '/../../lists/lib/schema.php';
require_once __DIR__ . '/DeliveryReceipts.php';
require_once __DIR__ . '/../../lists/lib/ContactImportWorker.php';

/*
 * Elastic Email's `category` on an Error event, split by "is the RECIPIENT address
 * permanently bad?" — because a hard bounce auto-blocklists the address forever
 * (same policy as sendgrid-webhook.php) and that must never happen for a problem
 * on OUR side or a transient one on theirs.
 *
 * Soft (retryable, never blocklisted): transient remote failures AND our own
 * misconfiguration — SPFProblem/AccountProblem/CodeError/ManualCancel are all
 * sender-side, so blocklisting an innocent recipient for them would be a bug.
 */
function ee_soft_bounce_categories(): array {
    return [
        'greylisted', 'throttled', 'timeout', 'connectionproblem', 'connectionterminated',
        'dnsproblem', 'whitelistingproblem', 'spfproblem', 'accountproblem', 'contentfilter',
        'codeerror', 'manualcancel', 'ignore',
    ];
}

/** Elastic Email's own field casing has varied across versions/transports; read
 *  case-insensitively so a `Status`/`MessageID` variant doesn't silently no-op. */
function ee_event_field(array $evt, string $key) {
    foreach ($evt as $k => $v) {
        if (strcasecmp((string)$k, $key) === 0) return $v;
    }
    return null;
}

/**
 * Applies one Elastic Email event to the campaign tables.
 *
 * @param array $evt Webhook-vocabulary event: status, category, postback (our rid), messageid.
 * @return bool true when the event was recognized and accounted for (including when it was a
 *              duplicate that had already been counted — the caller's tally is "understood",
 *              not "changed", so a re-poll of the same window does not look like a failure).
 */
function ee_handle_event(array $evt): bool {
    global $conn;

    $status   = strtolower(trim((string)ee_event_field($evt, 'status')));
    $category = strtolower(trim((string)ee_event_field($evt, 'category')));
    $rid      = (string)(ee_event_field($evt, 'postback') ?? '');
    $msgId    = (string)(ee_event_field($evt, 'messageid') ?? '');

    // Opens and clicks are already tracked first-party via track-open.php / track-click.php,
    // so ignore them here rather than double-counting. (The pull path never sees them at all:
    // /v4/events rejects Opened/Clicked as event types outright.)
    if ($status === 'opened' || $status === 'clicked') return false;

    $recipient = null;
    if (preg_match('/^[a-f0-9]{32}$/', $rid)) {
        $stmt = $conn->prepare("SELECT id, campaign_id, email, is_test FROM email_campaign_recipients WHERE rid = ? LIMIT 1");
        $stmt->bind_param('s', $rid);
        $stmt->execute();
        $recipient = $stmt->get_result()->fetch_assoc();
        $stmt->close();
    }
    if (!$recipient && $msgId !== '') {
        $stmt = $conn->prepare("SELECT id, campaign_id, email, is_test FROM email_campaign_recipients WHERE esp_message_id = ? LIMIT 1");
        $stmt->bind_param('s', $msgId);
        $stmt->execute();
        $recipient = $stmt->get_result()->fetch_assoc();
        $stmt->close();
    }
    if (!$recipient) {
        /*
         * Not a campaign recipient — offer it to the Journey engine, which keeps its own rids
         * in journey_messages.
         *
         * ── Why this needs a second lookup ──────────────────────────────────────────────
         * journey_webhook_email_event() matches on a 32-hex rid, which arrives as the event's
         * `postback`. A pushed webhook carries that field; /v4/events does NOT return it. So on
         * the polled path $rid is always empty and every journey receipt fell out here and was
         * dropped.
         *
         * That is why a journey's Delivered count stayed at almost nothing while Opened kept
         * climbing: opens are counted by our OWN tracking pixel (journeys/track-open.php) and
         * never needed the ESP at all, whereas "delivered" only ever comes from the provider. On
         * an Elastic Email plan without webhooks — they are a PRO feature — that receipt had no
         * route in whatsoever.
         *
         * It does have one. journey_messages stores provider_message_id, and for Elastic Email
         * that is the same `messageid` the events feed reports. Translating id to rid here hands
         * the event to the existing, already-tested webhook path rather than duplicating it.
         */
        $sink = __DIR__ . '/../../journeys/lib/JourneyWebhookSink.php';
        if ($rid === '' && $msgId !== '') {
            $stmt = $conn->prepare("SELECT rid FROM journey_messages WHERE provider_message_id = ? LIMIT 1");
            $stmt->bind_param('s', $msgId);
            $stmt->execute();
            $jrow = $stmt->get_result()->fetch_assoc();
            $stmt->close();
            if ($jrow && !empty($jrow['rid'])) $rid = (string)$jrow['rid'];
        }
        if ($rid !== '' && file_exists($sink)) {
            require_once $sink;
            $jType = $status === 'sent' ? 'delivered' : ($status === 'error' ? 'bounce'
                   : ($status === 'unsubscribed' ? 'unsubscribe' : ($status === 'abusereport' ? 'spamreport' : $status)));
            return journey_webhook_email_event($rid, $jType, $evt);
        }
        return false;
    }

    /*
     * 'Sent' is Elastic Email's provider-confirmed hand-off to the receiving mailbox — the
     * equivalent of SendGrid's 'delivered', and the ONLY thing that grows delivered_count
     * (the worker's own "sent" means merely that the API accepted our call).
     *
     * The delivered_at guard is what makes this safe to run from a poller. A webhook fires
     * once; a poller deliberately re-reads an overlapping window every run so nothing is lost
     * at the boundary, which means it WILL see the same Sent event several times. Counting on
     * the UPDATE's affected_rows instead of on having seen the event makes the increment
     * happen exactly once however many times the event is replayed.
     */
    if ($status === 'sent') {
        // Same helper as the other two providers now — the replay guard this sink already had,
        // plus the rule that a test send's receipt is recorded but never counted.
        campaign_receipt_delivered($recipient);
        return true;
    }

    $statusMap = [
        'error'        => 'bounce',
        'unsubscribed' => 'unsubscribe',
        'abusereport'  => 'spamreport',
    ];
    $mapped = $statusMap[$status] ?? null;
    if ($mapped === null) return false;

    /*
     * Same replay problem, different shape: these three each write a row to
     * email_campaign_events AND move a counter, so re-processing would duplicate both. There
     * is no per-recipient timestamp column for them the way delivered_at covers 'sent', so the
     * already-written event row is itself the idempotency record.
     */
    $existing = $conn->query("SELECT 1 FROM email_campaign_events
                               WHERE recipient_id={$recipient['id']} AND event_type='$mapped' LIMIT 1");
    if ($existing && $existing->num_rows > 0) return true;

    $metaE = $conn->real_escape_string(json_encode($evt));
    $conn->query("INSERT INTO email_campaign_events (campaign_id, recipient_id, event_type, meta)
                  VALUES ({$recipient['campaign_id']}, {$recipient['id']}, '$mapped', '$metaE')");

    if ($mapped === 'bounce') {
        // Anything not explicitly listed as soft (NoMailbox, BlackListed, Spam,
        // NotDelivered, Unknown, or a missing category) is treated as hard — the safer
        // assumption for suppression, matching sendgrid-webhook.php.
        $bounceType = in_array($category, ee_soft_bounce_categories(), true) ? 'soft' : 'hard';
        $firstBounce = campaign_receipt_bounced($recipient, $bounceType);

        // Hard bounce = the address is permanently invalid, so blocklist it exactly as an
        // unsubscribe would. Soft bounces are left alone — the address may work later.
        if ($firstBounce && $bounceType === 'hard' && !empty($recipient['email'])) {
            $blocklistId = lists_get_or_create_blocklist_id();
            contact_upsert(['email' => $recipient['email']], $blocklistId);
        }
    } elseif ($mapped === 'unsubscribe') {
        campaign_receipt_once($recipient, 'unsubscribe');
        if (!empty($recipient['email'])) {
            $blocklistId = lists_get_or_create_blocklist_id();
            contact_upsert(['email' => $recipient['email']], $blocklistId);
        }
    } elseif ($mapped === 'spamreport') {
        campaign_receipt_once($recipient, 'spamreport');
        if (!empty($recipient['email'])) {
            $blocklistId = lists_get_or_create_blocklist_id();
            contact_upsert(['email' => $recipient['email']], $blocklistId, 'Marked as spam via Elastic Email');
        }
    }
    return true;
}

<?php
/*
 * /api/freshdesk/lib/Pusher.php
 *
 * Minimal Pusher Channels REST client -- trigger events and sign private-channel
 * subscriptions, in ~150 lines of cURL, with no Composer package.
 *
 * (The official pusher/pusher-php-server is a fine library; it just cannot be
 * installed here -- there is no vendor/ tree under react-api and no composer on
 * the host. The REST API it wraps is small enough to speak directly.)
 *
 * DESIGN RULE THAT MATTERS: realtime is a nicety, mail is the product. Every
 * call here is best-effort and short-timeout. If Pusher is down, misconfigured,
 * or still holding the dummy credentials, trigger() returns false, writes one
 * log line, and the request that called it carries on and succeeds. An agent
 * must never fail to send a reply because a websocket provider had a bad day --
 * the client picks the change up on its next poll regardless.
 */

class FdPusher
{
    private $appId, $key, $secret, $cluster, $useTls;

    public function __construct($opts = array())
    {
        $this->appId   = isset($opts['app_id'])  ? $opts['app_id']  : (string)fd_cfg('PUSHER_APP_ID', '');
        $this->key     = isset($opts['key'])     ? $opts['key']     : (string)fd_cfg('PUSHER_KEY', '');
        $this->secret  = isset($opts['secret'])  ? $opts['secret']  : (string)fd_cfg('PUSHER_SECRET', '');
        $this->cluster = isset($opts['cluster']) ? $opts['cluster'] : (string)fd_cfg('PUSHER_CLUSTER', 'ap2');
        $this->useTls  = isset($opts['tls'])     ? (bool)$opts['tls'] : (bool)fd_cfg_int('PUSHER_TLS', 1);
    }

    public function isConfigured()
    {
        return fd_pusher_enabled();
    }

    private function host()
    {
        $c = preg_replace('/[^a-z0-9\-]/i', '', $this->cluster);
        return 'api-' . ($c !== '' ? $c : 'ap2') . '.pusher.com';
    }

    /**
     * Publish one event to one or more channels.
     *
     * @param string       $event    e.g. 'new-message'
     * @param array        $data     JSON-serialisable payload
     * @param string|array $channels channel name(s); defaults to the desk channel
     * @return bool  true only if Pusher accepted it
     */
    public function trigger($event, $data, $channels = null)
    {
        if (!$this->isConfigured()) {
            // Expected state until real credentials are pasted in. Debug, not error.
            fd_log('debug', 'Pusher not configured -- skipping trigger', array('event' => $event));
            return false;
        }
        if ($channels === null) $channels = array((string)fd_cfg('PUSHER_CHANNEL', 'private-freshdesk'));
        if (!is_array($channels)) $channels = array($channels);

        $payload = json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        if ($payload === false) {
            fd_log('warn', 'Pusher payload not serialisable', array('event' => $event));
            return false;
        }
        /*
         * Pusher hard-caps one event at 10KB. A ticket with a long HTML body
         * would blow straight past that, so events carry IDENTIFIERS and a
         * short preview, never the full record -- the client fetches the real
         * thing over HTTP when it needs it. Truncating here as a backstop keeps
         * an unusually large payload from silently failing to publish.
         */
        if (strlen($payload) > 9000) {
            $data = array(
                'truncated'  => true,
                'ticket_id'  => isset($data['ticket_id']) ? $data['ticket_id'] : null,
                'message_id' => isset($data['message_id']) ? $data['message_id'] : null,
                'cursor'     => isset($data['cursor']) ? $data['cursor'] : null,
            );
            $payload = json_encode($data);
        }

        $body = json_encode(array(
            'name'     => $event,
            'channels' => array_values($channels),
            'data'     => $payload,
        ));

        $path = '/apps/' . $this->appId . '/events';
        return $this->post($path, $body);
    }

    /** Publish several events in one HTTP round-trip (max 10 per Pusher's limit). */
    public function triggerBatch($events)
    {
        if (!$this->isConfigured() || empty($events)) return false;
        $default = (string)fd_cfg('PUSHER_CHANNEL', 'private-freshdesk');
        $batch = array();
        foreach (array_slice($events, 0, 10) as $e) {
            $batch[] = array(
                'channel' => isset($e['channel']) ? $e['channel'] : $default,
                'name'    => $e['event'],
                'data'    => json_encode(isset($e['data']) ? $e['data'] : array()),
            );
        }
        $body = json_encode(array('batch' => $batch));
        return $this->post('/apps/' . $this->appId . '/batch_events', $body);
    }

    /**
     * Sign a POST to the REST API.
     *
     * Pusher's scheme: the query string (minus auth_signature) is sorted by key,
     * joined into "POST\n<path>\n<query>", HMAC-SHA256'd with the app secret.
     * body_md5 must be the md5 of the EXACT bytes sent -- re-encoding the JSON
     * anywhere between here and curl invalidates the signature and Pusher
     * answers a flat 401 with no explanation of which field was wrong.
     */
    private function post($path, $body)
    {
        $params = array(
            'auth_key'       => $this->key,
            'auth_timestamp' => (string)time(),
            'auth_version'   => '1.0',
            'body_md5'       => md5($body),
        );
        ksort($params);
        $query = http_build_query($params, '', '&');
        $toSign = "POST\n" . $path . "\n" . $query;
        $signature = hash_hmac('sha256', $toSign, $this->secret);

        $url = ($this->useTls ? 'https://' : 'http://') . $this->host() . $path . '?' . $query . '&auth_signature=' . $signature;

        $ch = curl_init($url);
        curl_setopt_array($ch, array(
            CURLOPT_POST           => true,
            CURLOPT_POSTFIELDS     => $body,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HTTPHEADER     => array('Content-Type: application/json', 'Expect:'),
            // Short and deliberate: a reply must not sit waiting on Pusher.
            CURLOPT_TIMEOUT        => 4,
            CURLOPT_CONNECTTIMEOUT => 3,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_SSL_VERIFYHOST => 2,
        ));
        $resp = curl_exec($ch);
        $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $err  = curl_error($ch);
        curl_close($ch);

        if ($code >= 200 && $code < 300) return true;

        $hint = '';
        if ($code === 401) $hint = ' (bad app key/secret, or the server clock is more than 10 minutes off Pusher time)';
        elseif ($code === 404) $hint = ' (app id ' . $this->appId . ' does not exist in cluster ' . $this->cluster . ')';
        elseif ($code === 413) $hint = ' (event payload over 10KB)';
        elseif ($code === 0)   $hint = ' (could not reach Pusher: ' . $err . ' -- outbound HTTPS may be blocked)';
        fd_log('warn', 'Pusher trigger failed HTTP ' . $code . $hint, array('resp' => substr((string)$resp, 0, 200)));
        return false;
    }

    /**
     * Grant a browser permission to subscribe to a private channel.
     *
     * The client hands us its socket_id and the channel it wants; we return
     * "<key>:<hmac(socket_id:channel)>". This is the whole reason the desk uses
     * a PRIVATE channel: the Pusher key is public (it ships in the JS bundle),
     * so on a public channel anyone with the key could subscribe and read
     * customer names, subjects and previews. On a private channel they also
     * need this signature, which only comes from an endpoint behind the JWT.
     */
    public function authorizeChannel($channel, $socketId, $userData = null)
    {
        if (!$this->isConfigured()) {
            throw new Exception('Realtime is not configured. Add your Pusher credentials in Settings > Realtime.');
        }
        if (!preg_match('/^[A-Za-z0-9_\-=@,.;]+$/', (string)$channel)) {
            throw new Exception('Invalid channel name.');
        }
        // socket_id is "123.456" and comes straight from the client -- validate
        // it, or it becomes an injection into the string we sign.
        if (!preg_match('/^\d+\.\d+$/', (string)$socketId)) {
            throw new Exception('Invalid socket id.');
        }

        if (strpos($channel, 'presence-') === 0) {
            $channelData = json_encode($userData ? $userData : array('user_id' => 'agent'));
            $sig = hash_hmac('sha256', $socketId . ':' . $channel . ':' . $channelData, $this->secret);
            return array('auth' => $this->key . ':' . $sig, 'channel_data' => $channelData);
        }
        $sig = hash_hmac('sha256', $socketId . ':' . $channel, $this->secret);
        return array('auth' => $this->key . ':' . $sig);
    }

    /** What the browser needs to open a connection. The SECRET is never included. */
    public function clientConfig()
    {
        return array(
            'enabled' => $this->isConfigured(),
            'key'     => $this->isConfigured() ? $this->key : null,
            'cluster' => $this->cluster,
            'channel' => (string)fd_cfg('PUSHER_CHANNEL', 'private-freshdesk'),
            'tls'     => (bool)$this->useTls,
        );
    }
}

/* ------------------------------------------------------------------------ */

/**
 * The one function the rest of the codebase calls.
 *
 * Writes the event to fd_activity FIRST, then attempts the Pusher publish.
 * That order is the whole reliability story: the DB row is what the polling
 * fallback replays and what an agent who was offline for two minutes catches up
 * from, so it must exist whether or not the websocket publish works. Pusher is
 * only the low-latency shortcut on top of it.
 *
 * Returns the activity row id, which doubles as the client's polling cursor.
 */
function fd_emit($event, $data = array(), $opts = array())
{
    $ticketId  = isset($opts['ticket_id'])  ? (int)$opts['ticket_id']  : (isset($data['ticket_id']) ? (int)$data['ticket_id'] : null);
    $messageId = isset($opts['message_id']) ? (int)$opts['message_id'] : null;
    $actorType = isset($opts['actor_type']) ? $opts['actor_type'] : 'system';
    $actorId   = isset($opts['actor_id'])   ? (int)$opts['actor_id']   : null;
    $actorName = isset($opts['actor_name']) ? $opts['actor_name'] : null;
    $summary   = isset($opts['summary'])    ? $opts['summary'] : null;

    $cursor = 0;
    try {
        $cursor = fd_exec(
            "INSERT INTO fd_activity (ticket_id, message_id, event, actor_type, actor_id, actor_name, summary, payload)
             VALUES (?,?,?,?,?,?,?,?)",
            'iississs',
            array(
                $ticketId, $messageId, $event, $actorType, $actorId, $actorName,
                $summary !== null ? fd_snippet($summary, 480) : null,
                json_encode($data, JSON_UNESCAPED_UNICODE),
            ),
            true
        );
    } catch (Throwable $e) {
        // Even the audit write failing must not take the request down.
        fd_log('error', 'fd_emit could not record activity: ' . $e->getMessage(), array('event' => $event));
    }

    try {
        $pusher = new FdPusher();
        if ($pusher->isConfigured()) {
            $data['cursor'] = $cursor;
            $data['event']  = $event;
            $data['at']     = date('c');
            $pusher->trigger($event, $data);
        }
    } catch (Throwable $e) {
        fd_log('warn', 'Pusher publish threw: ' . $e->getMessage(), array('event' => $event));
    }

    return $cursor;
}

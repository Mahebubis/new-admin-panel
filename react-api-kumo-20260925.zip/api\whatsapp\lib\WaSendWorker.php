<?php
/*
 * The WhatsApp campaign send pipeline: materialize audience → claim a batch → render →
 * send concurrently → write outcomes back.
 *
 * Structurally a sibling of campaigns/lib/SendWorker.php (same flock'd cron + instant-kick
 * model, same three-phase batch, same "retryable failures don't burn an attempt" rule), with
 * three WhatsApp-specific differences:
 *
 *   1. Recipients are numbers, not addresses — see WaAudienceResolver.php.
 *   2. Deduplication runs at materialize time and is recorded, not silently applied.
 *   3. `sent` means the provider ACCEPTED the message. delivered/read only ever come from
 *      the webhook — a 200 from the send API is not evidence a phone ever showed anything.
 */
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/schema.php';
require_once __DIR__ . '/WaHelpers.php';
require_once __DIR__ . '/WaLinks.php';
// Both transports, unconditionally: a single batch can contain campaigns on different routes,
// and netcore_build_attributes()/meta_build_components() are both needed at render time.
require_once __DIR__ . '/MetaCloudTransport.php';
require_once __DIR__ . '/NetcoreTransport.php';
require_once __DIR__ . '/WaParallelSender.php';
// Required at TOP LEVEL, never lazily inside a function: WaAudienceResolver pulls in the
// email pipeline's AudienceResolver, which pulls in netcore/lib/segment_sql.php, whose
// $EVENT_SOURCE/$PAYLOAD_COLUMNS are plain top-level variables. Loading that file from inside
// a function traps those arrays in the function's LOCAL scope and every segment then silently
// resolves to zero users. (This exact bug is documented in campaigns/lib/SendWorker.php.)
require_once __DIR__ . '/WaAudienceResolver.php';
require_once __DIR__ . '/../../campaigns/lib/MergeTags.php';
require_once __DIR__ . '/../../campaigns/lib/AttributeResolver.php';

/** One timestamped line per event in wa-worker.log — "did cron run", "how many numbers did it
 *  find", "what did Netcore actually say" answerable without SSH/DB access. */
function wa_log(string $msg): void {
    wa_log_rotate_if_needed();
    @file_put_contents(WA_WORKER_LOG_PATH, '[' . date('Y-m-d H:i:s') . '] ' . $msg . "\n", FILE_APPEND | LOCK_EX);
}

/**
 * Keeps wa-worker.log from growing without bound, by trimming the oldest half once it passes
 * WA_LOG_MAX_BYTES.
 *
 * Deliberately in-place rather than the usual .log.1/.log.2 rotation: on shared hosting nothing
 * cleans numbered files up, so they trade one growing file for several. Keeping the recent tail
 * in the same path means the file everyone already tails stays the file with the answers.
 *
 * The size check is sampled, not run on every call — the webhook can log several times a second,
 * and a stat() per line is pure waste when the file only crosses the threshold once a week.
 */
function wa_log_rotate_if_needed(): void {
    static $counter = 0;
    if ($counter++ % 200 !== 0) return;

    $path = WA_WORKER_LOG_PATH;
    clearstatcache(true, $path);          // filesize() is cached per request; the webhook is long-lived
    $size = @filesize($path);
    if ($size === false || $size <= WA_LOG_MAX_BYTES) return;

    $keep = intdiv(WA_LOG_MAX_BYTES, 2);
    $fp = @fopen($path, 'r');
    if (!$fp) return;
    // Seek back from the END, then discard the first (partial) line so the trimmed file never
    // starts mid-sentence.
    @fseek($fp, -$keep, SEEK_END);
    @fgets($fp);
    $tail = @stream_get_contents($fp);
    @fclose($fp);
    if ($tail === false) return;

    @file_put_contents($path,
        '[' . date('Y-m-d H:i:s') . "] --- log trimmed: older entries dropped at "
        . round($size / 1048576, 1) . " MB ---\n" . $tail, LOCK_EX);
}

/*
 * The claim columns, and the recovery of rows a dead worker left holding.
 *
 * Mirrors campaign_claim_ensure_schema() / campaign_requeue_stale_claims() on the email side,
 * deliberately so: two channels with the same failure mode should not have two different answers
 * to it. The stale window is generous for the same reason — requeueing a row that is merely slow
 * recreates the exact double-send this closes.
 */
/*
 * How long a claim may sit untouched before another worker may take it back.
 *
 * It was fifteen minutes, chosen when a claim had no other way of proving it was alive: a long
 * batch had to be given room, because stealing rows from a healthy run is how duplicate sends
 * happen. A run now pushes this clock forward as it works (wa_claim_touch), so the window no
 * longer has to cover a whole batch — only a gap between two messages. Four minutes is far longer
 * than any single send and far shorter than a quarter of an hour of a campaign looking stuck.
 */
if (!defined('WA_CLAIM_STALE_MINUTES')) define('WA_CLAIM_STALE_MINUTES', 4);

function wa_claim_ensure_schema(): void {
    global $conn;
    static $done = false;
    if ($done) return;
    $done = true;

    foreach ([
        'claim_token' => "ADD COLUMN claim_token CHAR(32) DEFAULT NULL",
        'claimed_at'  => "ADD COLUMN claimed_at DATETIME DEFAULT NULL",
    ] as $col => $ddl) {
        $c = @$conn->query("SHOW COLUMNS FROM wa_campaign_recipients LIKE '$col'");
        if ($c && $c->num_rows === 0) @$conn->query("ALTER TABLE wa_campaign_recipients $ddl");
    }
    // Checked, not attempted-and-suppressed: mysqli throws here, and "@" does not catch a
    // throw — see the same note on the email side.
    $ix = $conn->query("SELECT COUNT(*) c FROM INFORMATION_SCHEMA.STATISTICS
                          WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'wa_campaign_recipients'
                            AND INDEX_NAME = 'idx_wa_claim'");
    if ($ix && (int)$ix->fetch_assoc()['c'] === 0) {
        try { $conn->query("CREATE INDEX idx_wa_claim ON wa_campaign_recipients (claim_token)"); }
        catch (Throwable $e) { wa_log('could not create idx_wa_claim: ' . $e->getMessage()); }
    }
}

/** Frees rows abandoned by a worker that died mid-batch. Returns how many. */
/*
 * A CLAIM MUST NOT OUTLIVE THE RUN THAT MADE IT.
 *
 * Send Now fires an instant kick at the other machine — wa_trigger_worker_async() opens a socket,
 * writes the request and closes it without waiting. That machine claims its rows and starts
 * sending. If it then dies for any reason, the rows stay marked 'processing' under a token nobody
 * holds, and every healthy tick afterwards reports "nothing left to claim" and walks away. The
 * campaign sits at Running with nothing sent until the stale sweep frees it a quarter of an hour
 * later. Campaigns 73 and 74 both did exactly that, minutes apart.
 *
 * So every token this process claims under is registered, and a shutdown handler puts back
 * whatever is still unsent when the process ends — normally, on a fatal error, or on a timeout.
 * PHP runs these handlers in all three cases. A hard kill still leaves the stale sweep as the
 * backstop, which is what it is for.
 */
function wa_claim_register(string $token): void {
    static $registered = false;
    $GLOBALS['__wa_live_claims'][$token] = true;
    if ($registered) return;
    $registered = true;

    register_shutdown_function(static function (): void {
        global $conn;
        $tokens = $GLOBALS['__wa_live_claims'] ?? [];
        if (!$tokens || !$conn) return;
        $in = [];
        foreach (array_keys($tokens) as $t) $in[] = "'" . $conn->real_escape_string((string)$t) . "'";
        @$conn->query("UPDATE wa_campaign_recipients
                          SET status='pending', claim_token=NULL, claimed_at=NULL
                        WHERE status='processing' AND claim_token IN (" . implode(',', $in) . ")");
        $n = $conn->affected_rows;
        if ($n > 0) wa_log("released $n still-unsent recipient(s) as this run ended — they go back in the queue immediately");
    });
}

/** This run is alive and working: push the claim's clock forward so the stale sweep leaves it be. */
function wa_claim_touch(string $token): void {
    global $conn;
    @$conn->query("UPDATE wa_campaign_recipients SET claimed_at = NOW()
                    WHERE status='processing' AND claim_token = '" . $conn->real_escape_string($token) . "'");
}

function wa_requeue_stale_claims(): int {
    global $conn;
    wa_claim_ensure_schema();
    $conn->query("UPDATE wa_campaign_recipients
                     SET status='pending', claim_token=NULL, claimed_at=NULL
                   WHERE status='processing'
                     AND (claimed_at IS NULL OR claimed_at < DATE_SUB(NOW(), INTERVAL " . (int)WA_CLAIM_STALE_MINUTES . " MINUTE))");
    $n = $conn->affected_rows;
    if ($n > 0) wa_log("requeued $n recipient(s) left in 'processing' by a worker that did not finish");
    return $n;
}

/** Flip due `scheduled` campaigns to `running`. Uses PHP's clock, not MySQL's NOW() — the two
 *  can sit in different timezones on shared hosting, and scheduled_at was written with PHP's
 *  date(), so comparing against NOW() would silently shift when a campaign actually fires. */
function wa_activate_due_scheduled(): void {
    global $conn;
    $now = $conn->real_escape_string(date('Y-m-d H:i:s'));
    $dueR = $conn->query("SELECT id, name, scheduled_at FROM wa_campaigns WHERE status='scheduled' AND scheduled_at <= '$now'");
    $due = [];
    while ($dueR && $row = $dueR->fetch_assoc()) $due[] = "#{$row['id']} \"{$row['name']}\" (was due {$row['scheduled_at']})";

    static $loggedOnce = false;
    if (!$loggedOnce || $due) {
        wa_log('checking due scheduled campaigns at server-time ' . $now . ' -> ' . ($due ? implode(', ', $due) : 'none due'));
        $loggedOnce = true;
    }
    $conn->query("UPDATE wa_campaigns SET status='running', started_at=IFNULL(started_at, '$now')
                  WHERE status='scheduled' AND scheduled_at <= '$now'");
}

/**
 * Resolves the audience and writes recipient rows — run inside the background worker, not on
 * the admin's "Send now" click, so that click stays instant even for a 40k-number audience.
 *
 * Returns the number of rows actually queued (after every dedup/limit rule).
 */
/**
 * Fills in user_id on recipients that arrived without one, by matching phone then email.
 *
 * Idempotent and cheap — it only ever touches rows still NULL — so it is safe to call from the
 * materializer AND from the conversion recompute. The second caller matters: campaigns already
 * sent before this existed would otherwise be permanently uncountable, because their recipients
 * were stored with no identity to join on.
 *
 * Phone matching compares the LAST 10 DIGITS, which is what makes the two representations meet:
 * we store E.164 digits (919921079337), `users` holds whatever was typed ("+91 9921079337").
 */
function wa_backfill_recipient_user_ids(int $campaignId): void {
    global $conn;

    /*
     * The explicit COLLATE is REQUIRED, not defensive.
     *
     * `users` is an older table created under utf8mb4_general_ci; wa_campaign_recipients was
     * created with utf8mb4_unicode_ci. Comparing two IMPLICIT-collation string columns across
     * that boundary raises MySQL error #1267:
     *
     *     Illegal mix of collations (utf8mb4_general_ci,IMPLICIT)
     *                           and (utf8mb4_unicode_ci,IMPLICIT) for operation '='
     *
     * and on PHP 8.1+ mysqli throws it. An EXPLICIT collation on either side settles the
     * comparison. It goes on the RECIPIENTS side because that set is small (one campaign) while
     * users.email keeps its index for the lookup — the same reasoning, and the same fix, as the
     * ₹99-store join in netcore/lib/segment_sql.php.
     */
    $conn->query("UPDATE wa_campaign_recipients r
                    JOIN users u ON RIGHT(u.phone, 10) = RIGHT(r.phone, 10) COLLATE utf8mb4_general_ci
                     SET r.user_id = u.user_id
                   WHERE r.campaign_id = $campaignId AND r.user_id IS NULL AND r.phone <> ''");
    $conn->query("UPDATE wa_campaign_recipients r
                    JOIN users u ON u.email = r.email COLLATE utf8mb4_general_ci
                     SET r.user_id = u.user_id
                   WHERE r.campaign_id = $campaignId AND r.user_id IS NULL AND r.email <> ''");
}

function wa_materialize_recipients(int $campaignId): int {
    global $conn;

    $r = $conn->query("SELECT * FROM wa_campaigns WHERE id=$campaignId LIMIT 1");
    if (!$r) {
        // mysqli returns false silently on a failed query (e.g. a column an older DB never
        // got); without this that's indistinguishable from "campaign not found".
        wa_log("campaign #$campaignId: FATAL — campaign SELECT failed: " . $conn->error);
        return 0;
    }
    $campaign = $r->fetch_assoc();
    if (!$campaign) return 0;

    $config = [
        'audience_type'       => $campaign['audience_type'],
        'segment_ids'         => json_decode($campaign['segment_ids'] ?? '[]', true) ?: [],
        'exclude_segment_ids' => json_decode($campaign['exclude_segment_ids'] ?? '[]', true) ?: [],
        'exclude_list_ids'    => json_decode($campaign['exclude_list_ids'] ?? '[]', true) ?: [],
        'list_ids'            => json_decode($campaign['list_ids'] ?? '[]', true) ?: [],
        'domain_filter'       => '', // email-only concept; never narrows a WhatsApp audience
    ];

    // Clear any previous non-test rows before re-materializing (re-scheduling a draft, requeue
    // after a 0-recipient run, etc.).
    $conn->query("DELETE FROM wa_campaign_recipients WHERE campaign_id=$campaignId AND is_test=0");

    $resolved = wa_resolve_audience($config);
    $rows = $resolved['recipients'];
    wa_log("campaign #$campaignId: audience -> " . count($rows) . " reachable number(s), {$resolved['unreachable']} without a usable phone, {$resolved['duplicates']} duplicate(s) merged");

    $skippedDedup = 0;

    // ── Cross-campaign deduplication ────────────────────────────────────────────────────
    if ((int)$campaign['dedup_enabled'] === 1) {
        $phones = array_column($rows, 'phone');
        $recent = wa_recently_messaged(
            $phones,
            (int)$campaign['dedup_window_hours'],
            (string)$campaign['dedup_scope'],
            $campaign['template_name'],
            $campaignId
        );
        if ($recent) {
            $before = count($rows);
            $rows = array_values(array_filter($rows, fn($x) => !isset($recent[$x['phone']])));
            $skippedDedup = $before - count($rows);
            wa_log("campaign #$campaignId: deduplication skipped $skippedDedup number(s) messaged in the last {$campaign['dedup_window_hours']}h (scope={$campaign['dedup_scope']})");
        }
    }

    // ── Opt-out suppression ─────────────────────────────────────────────────────────────
    // A number that replied STOP must never be messaged again, regardless of segment rules.
    $optins = wa_optin_map(array_column($rows, 'phone'));
    $before = count($rows);
    $rows = array_values(array_filter($rows, fn($x) => ($optins[$x['phone']] ?? '') !== 'optout'));
    $optedOut = $before - count($rows);
    if ($optedOut > 0) wa_log("campaign #$campaignId: $optedOut number(s) skipped — opted out");

    // ── Contact limit ───────────────────────────────────────────────────────────────────
    if ((int)$campaign['contact_limit_enabled'] === 1 && (int)$campaign['contact_limit'] > 0) {
        $limit = (int)$campaign['contact_limit'];
        if (count($rows) > $limit) {
            wa_log("campaign #$campaignId: contact limit $limit applied (audience was " . count($rows) . ")");
            $rows = array_slice($rows, 0, $limit);
        }
    }

    $total = count($rows);
    if ($total > 0) {
        foreach (array_chunk($rows, 500) as $chunk) {
            $values = [];
            foreach ($chunk as $u) {
                $rid   = bin2hex(random_bytes(16));
                $uid   = $u['user_id'] !== null && $u['user_id'] !== '' ? (int)$u['user_id'] : 'NULL';
                $phone = $conn->real_escape_string($u['phone']);
                $rawP  = $conn->real_escape_string((string)$u['raw_phone']);
                $email = $conn->real_escape_string((string)$u['email']);
                $fname = $conn->real_escape_string((string)$u['first_name']);
                $lname = $conn->real_escape_string((string)$u['last_name']);
                $values[] = "($campaignId, $uid, '$phone', '$rawP', '$email', '$fname', '$lname', 0, 'pending', '$rid')";
            }
            // INSERT IGNORE + uq_campaign_phone is the second half of the dedup guarantee: even
            // if a future caller hands this function a list it forgot to fold, the database
            // physically cannot store the same number twice for one campaign.
            $conn->query("INSERT IGNORE INTO wa_campaign_recipients
                (campaign_id, user_id, phone, raw_phone, email, first_name, last_name, is_test, status, rid)
                VALUES " . implode(',', $values));
        }
    }

    /*
     * Backfill user_id for recipients that arrived without one.
     *
     * Segment-sourced contacts come from `users` and already carry it. LIST-sourced contacts come
     * from campaign_contacts, which stores a phone and an email but no user_id — so they land here
     * with NULL, and NULL means invisible to anything that joins on identity: conversion goals,
     * per-user attributes, exam data. A campaign sent to a list would report 0 conversions
     * forever, no matter how many of those people actually converted.
     *
     * Matched on the last 10 digits so the two representations meet — we store E.164 digits
     * (919921079337) while `users` holds whatever was typed ("+91 9921079337", "9921079337").
     * Email is the second pass, for contacts whose stored number never normalised.
     *
     * Cheap enough to run every materialize: it touches only rows that are still NULL.
     */
    /*
     * Identity and attribution bookkeeping, both isolated from the send.
     *
     * These read columns added by later migrations (wa_campaign_recipients.user_id backfill,
     * wa_templates.click_target_url). On a server whose schema.php is a version behind, the
     * column is missing and mysqli — which PHP 8.1+ puts in exception mode by default — THROWS.
     * Uncaught, that killed the entire worker run between "audience -> N reachable" and the first
     * send, with display_errors off and nothing in the log to say why.
     *
     * Neither of these is worth failing a campaign over: one improves conversion matching, the
     * other fills in a click destination. Sending is the job.
     */
    try {
        wa_backfill_recipient_user_ids($campaignId);
    } catch (\Throwable $e) {
        wa_log("campaign #$campaignId: user_id backfill skipped — " . $e->getMessage());
    }

    try {
        // Snapshot the template's button destination onto the campaign: a template edited next
        // month must not retarget links already sitting in someone's WhatsApp. Only filled when
        // blank, so an explicit per-campaign override survives.
        $conn->query("UPDATE wa_campaigns c
                        JOIN wa_templates t ON t.id = c.template_id
                         SET c.click_target_url = t.click_target_url
                       WHERE c.id = $campaignId
                         AND (c.click_target_url IS NULL OR c.click_target_url = '')
                         AND t.click_target_url IS NOT NULL AND t.click_target_url <> ''");
    } catch (\Throwable $e) {
        wa_log("campaign #$campaignId: click destination not copied from the template — " . $e->getMessage());
    }

    /*
     * Point the template's tracked link at THIS campaign.
     *
     * The id inside the approved template ("…/login/23") is fixed forever — Meta approved that
     * exact string and it cannot vary per send. So the wa_links row is the only place that can
     * say which campaign a tap belongs to, and it has to be rebound every time the template goes
     * out. Without this a re-used template would keep crediting whichever campaign sent it first.
     *
     * The goal and window are copied across at the same moment for the same reason c.php read
     * them from the campaign: link.php hands them to the landing page, which sizes the attribution
     * cookie from them.
     *
     * Isolated like its neighbours — a campaign is not worth failing over a tracking row.
     */
    try {
        $lr = $conn->query("SELECT t.link_id
                              FROM wa_campaigns c
                              JOIN wa_templates t ON t.id = c.template_id
                             WHERE c.id = $campaignId LIMIT 1");
        $linkId = (int)(($lr ? $lr->fetch_assoc() : [])['link_id'] ?? 0);
        if ($linkId > 0) {
            wa_link_bind_campaign(
                $linkId,
                $campaignId,
                (string)($campaign['goal_event_name'] ?? ''),
                (int)($campaign['goal_window_days'] ?? 2)
            );
            wa_log("campaign #$campaignId: tracked link #$linkId bound to this campaign");
        }
    } catch (\Throwable $e) {
        wa_log("campaign #$campaignId: tracked link not bound — " . $e->getMessage());
    }

    // Count the rows that actually landed rather than trusting $total — INSERT IGNORE may have
    // collapsed more than we folded in PHP.
    $cR = $conn->query("SELECT COUNT(*) AS c FROM wa_campaign_recipients WHERE campaign_id=$campaignId AND is_test=0");
    $queued = $cR ? (int)$cR->fetch_assoc()['c'] : $total;

    $conn->query("UPDATE wa_campaigns
                     SET total_recipients=$queued, skipped_dedup_count=" . (int)$skippedDedup . ", materialized_at=NOW()
                   WHERE id=$campaignId");
    return $queued;
}

/**
 * Renders one recipient's message content — the campaign's variable values with merge tags
 * resolved for this specific person, ready to hand to the transport's buildRequest().
 *
 * @return array{content: array, preview: string}
 */
/**
 * Does this campaign's dynamic URL button already end in "?" (or carry a query)?
 *
 * Meta appends a dynamic button's parameter with no separator, so the answer decides whether
 * the attribution string needs a "?" in front of it. Returns true when in doubt — adding a
 * second "?" to a base that has one would break a link that currently works, which is the
 * worse of the two failures.
 */
function wa_button_base_has_query(array $campaign): bool {
    $btns = $campaign['buttons'] ?? [];
    if (is_string($btns)) $btns = json_decode($btns, true) ?: [];

    foreach ((array)$btns as $b) {
        // See wa_is_dynamic_url_button(): the type/dynamic flags are not always written, and a
        // "{{1}}" in the url is the fact that actually decides it.
        if (!wa_is_dynamic_url_button($b)) continue;

        // Strip the {{1}} placeholder first: it is the parameter's position, not part of the base.
        $base = preg_replace('~\{\{\s*\d+\s*\}\}~', '', (string)($b['url'] ?? ''));
        return strpos($base, '?') !== false;
    }

    return true;   // no dynamic button found — nothing to prefix
}

function wa_render_for_recipient(array $campaign, array $recipient, array $attrTokens): array {
    $vars = json_decode($campaign['variables'] ?? '{}', true) ?: [];

    $resolveList = function ($list) use ($recipient, $attrTokens) {
        $out = [];
        foreach ((array)$list as $v) $out[] = substitute_merge_tags((string)$v, $recipient, $attrTokens);
        return $out;
    };

    if (($campaign['message_type'] ?? 'template') === 'text') {
        $body = substitute_merge_tags((string)$campaign['text_content'], $recipient, $attrTokens);
        return [
            'content' => ['type' => 'text', 'body' => $body, 'preview_url' => (int)$campaign['preview_url'] === 1],
            'preview' => $body,
        ];
    }

    $headerValues = $resolveList($vars['header'] ?? []);
    $bodyValues   = $resolveList($vars['body'] ?? []);

    /*
     * The parameter count is the TEMPLATE's, never the campaign's.
     *
     * Meta counts {{1}}…{{n}} in the approved body and rejects the whole message when the array
     * it receives is a different length: "132000: body: number of localizable_params (11) does not
     * match the expected number of params (12)". That is a hard failure per recipient, and the
     * campaign still reports itself as sent.
     *
     * A campaign can be short for ordinary reasons — a template gained a placeholder after the
     * campaign was built, or the Content step was saved before every row was filled in. Padding
     * here means the message still goes out with the mapped values in the right positions, and
     * only the unmapped tail is blank, instead of nobody receiving anything.
     *
     * The filler is a HYPHEN, and that detail is the whole fix.
     *
     * It was a single space first, on the reasoning that Meta rejects an empty parameter. Meta
     * rejects a whitespace-only one for the same reason and with the same code — its own words are
     * "(#131008) Required parameter is missing — Parameter of type text is missing text value".
     * Netcore relays that as "buttons: Button at index 0 of type Url requires a parameter", which
     * points at the button and is simply wrong: the button parameter was present, and the blank
     * body parameter was the real cause. So a space swapped one silent hard failure for another,
     * wearing a misleading error message.
     *
     * A hyphen is not whitespace, reads as "nothing here", and Meta accepts it. The better answer
     * is still a default value on the attribute itself, which this can never be a substitute for.
     */
    $expected = 0;
    if (preg_match_all('/\{\{\s*(\d+)\s*\}\}/', (string)($campaign['body_text'] ?? ''), $m)) {
        $expected = max(array_map('intval', $m[1]));
    }
    if ($expected > count($bodyValues)) {
        wa_log("template {$campaign['template_name']}: campaign maps " . count($bodyValues)
             . " body variable(s) but the approved template expects $expected — padding the rest");
        $bodyValues = array_pad($bodyValues, $expected, '-');
    }
    // A value that resolved to nothing is the same hard failure as a missing one.
    foreach ($bodyValues as $i => $v) {
        if (trim((string)$v) === '') {
            $bodyValues[$i] = '-';
            wa_log("template {$campaign['template_name']}: body variable " . ($i + 1)
                 . " resolved to nothing for {$recipient['email']} — sent as '-'. Set a default value on that attribute to control what appears here.");
        }
    }

    $buttonSuffix = substitute_merge_tags((string)($vars['button_url_suffix'] ?? ''), $recipient, $attrTokens);

    /*
     * ATTRIBUTION IN THE BUTTON URL — the two tokens that make a WhatsApp link tap countable.
     *
     * Substituted here rather than through the merge-tag resolver because neither is a property
     * of the CONTACT: both identify THIS send to THIS person, and exist only on the recipient row
     * and the campaign.
     *
     *   XX_WA_ATTR_XX          the whole attribution query string. Put in a template button
     *                          approved as  https://dashboard.…/login?{{1}}  the visitor lands
     *                          directly on your platform already carrying everything it needs to
     *                          log the click and set the attribution cookie. No redirect hop, so
     *                          nothing to go wrong between the tap and the page.
     *
     *   XX_WA_CLICK_TOKEN_XX   just the rid, for the  …/c.php?t={{1}}  form, where our own server
     *                          records the click before forwarding. Use this one only if you want
     *                          the panel's own Clicked column to move.
     *
     * Both are safe to leave in a campaign that doesn't use them: an unmatched token is simply
     * never substituted, and a static button carries no variable at all.
     */
    $rid = (string)($recipient['rid'] ?? '');

    /*
     * Default the button variable to XX_WA_ATTR_XX when it was left blank.
     *
     * A dynamic URL button MUST be given a value — Meta rejects the send outright without one —
     * and there is exactly one sensible value it could be. Making an admin type the same token
     * into every campaign is a step that adds no information and silently costs every conversion
     * when it is forgotten.
     *
     * NOT conditional on the campaign having a conversion goal, though it used to be.
     *
     * The reasoning for that gate was that the attribution string is only USEFUL when there is a
     * goal to attribute to. True, but it confuses "this value is useful" with "this value is
     * required", and Meta only cares about the second. A goalless campaign on a template with a
     * dynamic button got a blank suffix, netcore_build_buttons() then omitted the parameter
     * entirely, and Meta rejected every single message with
     *
     *     131008  buttons: Button at index 0 of type Url requires a parameter
     *
     * That is not a degraded send, it is a total one: campaign 53 lost 3,005 of 3,548 recipients
     * this way, and burned 3,005 API calls to be told so. Worse, it looked like slow delivery
     * rather than failure — the delivered count crept toward the few hundred that did go out and
     * simply stopped, while the panel showed the campaign as SENT.
     *
     * Since $attr below is built with http_build_query over campaign_id/medium/attr_window/wa_rid,
     * all of which are always present, the substituted value is never empty — so defaulting here
     * cannot itself produce the blank that causes 131008. A goalless campaign now carries an
     * attribution string whose goal= happens to be empty, which is inert rather than fatal.
     *
     * Applied when both are true: the template has a dynamic url button, and nothing was typed.
     * An explicit value always wins.
     */
    /*
     * auto_button_attr lets a caller keep its goal while opting OUT of that defaulting.
     *
     * A journey has to: it needs goal_event_name for the `goal=` in its tracked link, but a
     * filled button block is refused by Netcore (131008 — it accepts the block and never passes
     * the value to Meta). Absent for campaigns, which keep the old behaviour exactly.
     */
    $autoButtonAttr = !array_key_exists('auto_button_attr', $campaign) || !empty($campaign['auto_button_attr']);

    if ($autoButtonAttr && trim($buttonSuffix) === '') {
        $btns = $campaign['buttons'] ?? [];
        if (is_string($btns)) $btns = json_decode($btns, true) ?: [];
        foreach ((array)$btns as $b) {
            // See wa_is_dynamic_url_button(): this is the check that campaign 53 fell through.
            // Its button was [{"url": "https://nctrckg.com/{{1}}", "text": "Result"}] — dynamic
            // beyond doubt, but carrying neither the 'type' nor the 'dynamic' key this used to
            // require, so the suffix was never defaulted and every send was rejected with 131008.
            if (wa_is_dynamic_url_button($b)) { $buttonSuffix = 'XX_WA_ATTR_XX'; break; }
        }
    }

    /*
     * XX_WA_ATTR_XX also works in HEADER and BODY variables, not only in the button.
     *
     * It has to, because a tracked BUTTON is not currently deliverable through Netcore: their API
     * ignores the button's parameter in every documented shape we can construct, and WhatsApp then
     * refuses the message with "131008 buttons: Button at index 0 of type Url requires a
     * parameter". Until that field is confirmed, the working way to give each recipient their own
     * tracked link is to put it in the message text:
     *
     *     body:      Please log in here: {{1}}
     *     variable:  https://dashboard.internshipstudio.com/login?XX_WA_ATTR_XX
     *
     * Body variables travel in `attributes`, which is the one part of Netcore's template payload
     * that is proven to work. WhatsApp auto-links the result, so the recipient still taps a link —
     * it just isn't a button — and every downstream step (click.php, the cookie, the conversion)
     * is byte-identical because the URL is the same.
     */
    $needsAttr = static function ($v) { return is_string($v) && strpos($v, 'XX_WA_ATTR_XX') !== false; };
    $anyAttrInText = count(array_filter($headerValues, $needsAttr)) > 0
                  || count(array_filter($bodyValues, $needsAttr)) > 0;

    if ($anyAttrInText || strpos($buttonSuffix, 'XX_WA_ATTR_XX') !== false) {
        /*
         * phone is included so your platform can tie the click to a person before they log in —
         * at tap time there is no session, and the number is the only identity WhatsApp gives us.
         * wa_rid is the exact recipient row, so a click can be reported back to this panel
         * unambiguously even if the same person is in two campaigns.
         *
         * http_build_query, not string concatenation: a goal name or campaign id with an & or a
         * space in it would otherwise silently truncate every parameter after it.
         */
        /*
         * campaign_id / medium are overridable so a JOURNEY can use this same renderer without
         * pretending to be a campaign. A journey passes its offset id (1000000 + journey_id) and
         * medium 'journey', which is what keeps its cookie and its conversion row distinct from a
         * campaign that happens to share the number. Campaigns pass neither and are unaffected.
         */
        $attr = http_build_query([
            'campaign_id' => (int)($campaign['attr_campaign_id'] ?? $campaign['id']),
            'medium'      => (string)($campaign['attr_medium'] ?? 'whatsapp'),
            'phone'       => (string)($recipient['phone'] ?? ''),
            'goal'        => (string)($campaign['goal_event_name'] ?? ''),
            'attr_window' => max(1, min(90, (int)($campaign['goal_window_days'] ?: 2))),
            'wa_rid'      => $rid,
        ]);
        /*
         * The BUTTON suffix may need a leading "?" that the text form never does.
         *
         * Meta concatenates a dynamic URL button's parameter straight onto the approved base
         * with no separator. That only produces a valid URL if the approved base already ends
         * in "?" — e.g.  …/login?{{1}}  — which is what the note above assumes.
         *
         * A template approved as  …/login{{1}}  instead (easy to do, and Meta accepts it)
         * silently produces  …/logincampaign_id=51&medium=whatsapp&…  — one unbroken path
         * segment. Every recipient lands on a 404 and the campaign records zero clicks, with
         * nothing anywhere reporting a failure.
         *
         * Re-approving the template is the tidy fix but Meta refuses a re-submission under the
         * same name, so it means a new template and a new approval wait. Adding the separator
         * here fixes every already-approved template at once. A base that DOES end in "?" or
         * already carries a query is left alone.
         */
        $buttonAttr = $attr;
        if (strpos($buttonSuffix, 'XX_WA_ATTR_XX') !== false && !wa_button_base_has_query($campaign)) {
            $buttonAttr = '?' . $attr;
        }

        $buttonSuffix = str_replace('XX_WA_ATTR_XX', $buttonAttr, $buttonSuffix);

        // Text variables carry the whole URL, so the template author wrote the "?" themselves.
        $swap = static function ($v) use ($attr) {
            return is_string($v) ? str_replace('XX_WA_ATTR_XX', $attr, $v) : $v;
        };
        $headerValues = array_map($swap, $headerValues);
        $bodyValues   = array_map($swap, $bodyValues);
    }

    $buttonSuffix = str_replace('XX_WA_CLICK_TOKEN_XX', $rid, $buttonSuffix);

    $content = [
        'type'     => 'template',
        'name'     => $campaign['template_name'],
        'language' => $campaign['template_language'] ?: 'en',
    ];

    $tpl = [
        'header_type'      => $campaign['header_type'],
        'header_text'      => $campaign['header_text'],
        'header_media_url' => $campaign['header_media_url'],
        'body_text'        => $campaign['body_text'],
        'buttons'          => $campaign['buttons'],
    ];
    $values = ['header' => $headerValues, 'body' => $bodyValues, 'button_url_suffix' => $buttonSuffix];

    /*
     * BOTH shapes are built, and the transport takes the one it understands: Meta wants nested
     * components[], Netcore wants a flat attributes[]. Rendering is pure CPU on already-resolved
     * values, so computing the unused one costs nothing measurable — and it keeps this function
     * from needing to know which route the campaign is on, which is decided per campaign and can
     * differ between two campaigns processed in the same batch.
     */
    /*
     * This recipient's own button destination, if the template nominated an attribute for it.
     *
     * The button URL is the SAME in every copy of the message — Meta approves it once and allows a
     * variable only at the end — so a per-person address cannot live there. It lives here, is
     * written to the recipient's row by the caller, and c.php reads it back when the tap arrives.
     * Resolved now rather than at click time, so a link re-assigned tomorrow cannot change where a
     * message sent today goes.
     */
    $destToken = trim((string)($vars['button_destination_attr'] ?? ''));
    $clickTarget = '';
    if ($destToken !== '') {
        $resolvedDest = substitute_merge_tags($destToken, $recipient, $attrTokens);
        // Unchanged means nothing filled it — storing the raw token would send people to a 404.
        if ($resolvedDest !== $destToken && preg_match('~^https?://~i', trim($resolvedDest))) {
            $clickTarget = trim($resolvedDest);
        }
    }

    $content['components'] = meta_build_components($tpl, $values);
    $content['attributes'] = netcore_build_attributes($tpl, $values);
    // Netcore keeps the button's value out of `attributes` — mixing them is error 132000.
    $content['buttons']    = netcore_build_buttons($tpl, $values);
    // Netcore carries a media header as its own block rather than a component parameter.
    $content['header_type']      = $campaign['header_type'];
    $content['header_media_url'] = $campaign['header_media_url'];

    return [
        'click_target' => $clickTarget,
        'content' => $content,
        // Human-readable copy of exactly what this person was sent, stored on their row so the
        // report can show it without re-deriving anything.
        'preview' => wa_fill_placeholders((string)$campaign['body_text'], $bodyValues),
    ];
}

/*
 * Meta error codes that describe the TEMPLATE or the send configuration rather than the
 * recipient — a fault every remaining contact will hit identically.
 *
 * The distinction is the whole point. "Not a WhatsApp user" is per-person and a campaign should
 * sail past thousands of them; "your template needs a button parameter you did not send" is true
 * of recipient 1 and recipient 3,548 alike, and every attempt after the first is a wasted API
 * call that also tells Meta you are generating errors at scale.
 *
 * Deliberately conservative: a code earns a place here only when it cannot depend on who is
 * being messaged. Anything uncertain is left out, because a false entry stops a campaign that
 * should have run — a worse failure than the one being prevented.
 */
if (!defined('WA_CONFIG_ERROR_CODES')) {
    define('WA_CONFIG_ERROR_CODES', json_encode([
        '131008',   // required parameter missing (e.g. a dynamic URL button with no value)
        '132000',   // parameter count mismatch against the approved template
        '132001',   // template does not exist in this name/language pair
        '132005',   // translated text too long
        '132007',   // template content violates format policy
        '132012',   // parameter format mismatch
        '132015',   // template is paused
        '132016',   // template is disabled
    ]));
}

/*
 * How many identical config failures to tolerate before halting the campaign.
 *
 * Low enough that the damage is one partial batch rather than a whole audience, high enough
 * that a handful of unlucky rows cannot stop a healthy send. Campaign 53 produced 3,005 of
 * these; at this threshold it would have stopped at 25.
 */
if (!defined('WA_CONFIG_ERROR_HALT_AT')) define('WA_CONFIG_ERROR_HALT_AT', 25);

/**
 * The campaign's template, if Meta has re-filed it and it has been auto-disabled — otherwise null.
 *
 * WHY THIS IS CHECKED AT SEND TIME AND NOT ONLY AT SCHEDULE TIME
 * Everything else about a re-classified template already works: the sweep in
 * whatsapp/lib/WaTemplateWabas.php spots the drift and sets auto_disabled, the pickers stop
 * offering it, journeys suppress it per message, and pressing Send or Schedule refuses outright.
 *
 * A campaign SCHEDULED before the drift was none of those things. It was validated last Tuesday,
 * Meta re-filed the template on Thursday, and on Friday the worker flips it from 'scheduled' to
 * 'running' and sends the whole audience — at marketing prices, to marketing opt-ins only, under
 * a frequency cap that silently drops it for anyone over their limit, while the report cheerfully
 * says thousands sent. Nothing between the schedule and the send re-asked the question.
 *
 * The reactive halt below eventually catches the worst version of this, but only via Meta's own
 * 132015/132016 and only after WA_CONFIG_ERROR_HALT_AT recipients have already failed — and a
 * re-categorised template does not fail, it delivers, expensively and to fewer people. So it is
 * asked directly, here, before a single recipient of the batch is claimed.
 *
 * A campaign built from a template that has since been DELETED is not stopped: its content was
 * snapshotted onto the campaign at build time and is still perfectly sendable. Only a live
 * template saying "Meta and this panel disagree about what I am" halts anything.
 */
function wa_disabled_template_for(array $campaign): ?array {
    global $conn;
    $tplId = (int)($campaign['template_id'] ?? 0);
    if ($tplId <= 0) return null;
    // Suppressed: a server whose schema is a release behind has no auto_disabled column, and a
    // reporting-grade safety check must never be the thing that stops every campaign on it.
    $r = @$conn->query("SELECT id, name, auto_disabled, disabled_reason, meta_category, category
                          FROM wa_templates WHERE id = $tplId LIMIT 1");
    $row = $r ? $r->fetch_assoc() : null;
    if (!$row || empty($row['auto_disabled'])) return null;
    return $row;
}

/**
 * The config-error code that has already failed this campaign at least WA_CONFIG_ERROR_HALT_AT
 * times, or null when there is no reason to stop.
 *
 * Read before claiming each batch, so a campaign whose very first batch fails wholesale is
 * suspended before the second one is attempted.
 */
function wa_halting_config_error(int $campaignId): ?array {
    global $conn;
    $codes = json_decode(WA_CONFIG_ERROR_CODES, true);
    $in    = "'" . implode("','", array_map([$conn, 'real_escape_string'], $codes)) . "'";
    $r = $conn->query("SELECT error_code, error_message, COUNT(*) c
                         FROM wa_campaign_recipients
                        WHERE campaign_id=$campaignId AND is_test=0
                          AND status='failed' AND error_code IN ($in)
                        GROUP BY error_code, error_message
                        HAVING c >= " . WA_CONFIG_ERROR_HALT_AT . "
                        ORDER BY c DESC LIMIT 1");
    $row = $r ? $r->fetch_assoc() : null;
    return $row ?: null;
}

/**
 * Processes one chunk of pending recipients (per running campaign, or a single $campaignId
 * for the instant "Send now" kick). Concurrency-safe by virtue of the caller's flock().
 */
function wa_process_batch(int $limit = 200, ?int $campaignId = null): array {
    global $conn;
    wa_claim_ensure_schema();
    wa_activate_due_scheduled();

    $filter = $campaignId ? 'id = ' . (int)$campaignId : "status = 'running'";
    $ids = [];
    $res = $conn->query("SELECT id FROM wa_campaigns WHERE $filter");
    while ($res && $row = $res->fetch_assoc()) $ids[] = (int)$row['id'];

    static $tickLogged = false;
    if (!$tickLogged) {
        wa_log('tick: ' . count($ids) . ' running campaign(s) to check'
            . ($campaignId ? " (instant kick for campaign #$campaignId)" : ' (cron sweep)'));
        $tickLogged = true;
    }

    $processed = 0; $sent = 0; $failed = 0;
    $settings  = wa_settings_row() ?: [];

    foreach ($ids as $cid) {
        try {
            $campRes = $conn->query("SELECT * FROM wa_campaigns WHERE id=$cid LIMIT 1");
            $campaign = $campRes ? $campRes->fetch_assoc() : null;

            /*
             * Both skips below used to be a bare `continue`, which made this the one path that could
             * do nothing and say nothing: an instant kick selects a campaign BY ID regardless of
             * status, so a campaign that isn't 'running' produced "processed: 0" with no line
             * explaining why, and no amount of re-kicking would ever change it. Whatever the worker
             * declines to do, it now says so.
             */
            if (!$campaign) {
                wa_log("campaign #$cid: skipped — no such campaign row");
                continue;
            }
            if ($campaign['status'] !== 'running') {
                wa_log("campaign #$cid \"{$campaign['name']}\": skipped — status is '{$campaign['status']}', and only 'running' campaigns are sent."
                    . " Open it in the wizard and press Send now, or use Resume on the report.");
                continue;
            }

            if (empty($campaign['materialized_at'])) {
                wa_log("campaign #$cid \"{$campaign['name']}\": resolving audience (type={$campaign['audience_type']}, segments={$campaign['segment_ids']}, lists={$campaign['list_ids']})…");
                $n = wa_materialize_recipients($cid);
                if ($n === 0) {
                    wa_log("campaign #$cid: 0 reachable recipients -> marking FAILED (nothing was sent)");
                    $conn->query("UPDATE wa_campaigns SET status='failed', completed_at=NOW() WHERE id=$cid");
                    continue;
                }
                // Re-read: materialize stamped total_recipients/materialized_at on the row.
                $campRes = $conn->query("SELECT * FROM wa_campaigns WHERE id=$cid LIMIT 1");
                $campaign = $campRes ? $campRes->fetch_assoc() : $campaign;
            }

            // Re-check live status right before claiming — a Suspend click can land while this tick
            // was busy waiting on slow API calls for an earlier batch.
            $liveR = $conn->query("SELECT status FROM wa_campaigns WHERE id=$cid LIMIT 1");
            $live  = $liveR ? $liveR->fetch_assoc() : null;
            if (!$live || $live['status'] !== 'running') continue;

            /*
             * Halt a campaign that is failing for a reason the remaining audience shares.
             *
             * Checked HERE — after the running-status re-check, before any new recipient is
             * claimed — so the campaign stops between batches rather than part-way through one,
             * leaving no row stranded in 'processing'.
             *
             * Suspended, not failed: the recipients already sent are real and their receipts are
             * still arriving, and the ones never attempted are still pending. Once the template
             * or campaign is corrected, Resume picks up exactly where this stopped. Marking it
             * failed would discard that.
             */
            /*
             * Stop before sending anything if the template has been re-classified since this
             * campaign was scheduled. Suspended rather than failed, exactly like the halt below:
             * nothing has gone wrong with the recipients, the campaign simply must not continue
             * until somebody decides what to do about the new category. Resume picks up here.
             */
            if ($badTpl = wa_disabled_template_for($campaign)) {
                $why = trim((string)($badTpl['disabled_reason'] ?? ''));
                if ($why === '') {
                    $why = 'Meta has re-classified it as ' . strtoupper((string)($badTpl['meta_category'] ?: 'a different category'))
                         . ', not the ' . strtoupper((string)($badTpl['category'] ?: 'category')) . ' it was built as.';
                }
                wa_log("campaign #$cid: PAUSED before sending — template \"{$badTpl['name']}\" is disabled. $why"
                     . ' — remaining recipients left pending; resolve the template under Content → WhatsApp'
                     . ' templates, then Resume');
                $conn->query("UPDATE wa_campaigns SET status='suspended' WHERE id=$cid");
                continue;
            }

            if ($halt = wa_halting_config_error($cid)) {
                $reason = ($halt['error_code'] !== null && $halt['error_code'] !== '' ? $halt['error_code'] . ': ' : '')
                        . (string)$halt['error_message'];
                wa_log("campaign #$cid: HALTED after {$halt['c']} identical configuration failures — $reason"
                     . ' — remaining recipients left pending; fix the template/campaign and Resume');
                /*
                 * No wa_campaign_events row for this: event_type is an ENUM of message-level
                 * outcomes and a halt is a campaign-level one, so recording it would mean
                 * widening that ENUM for a value no per-recipient query ever wants. The log line
                 * above and the suspended status carry it instead, and the failures that caused
                 * the halt are already on the recipient rows with their codes.
                 */
                $conn->query("UPDATE wa_campaigns SET status='suspended' WHERE id=$cid");
                continue;
            }

            /*
             * CLAIM UNDER A TOKEN ONLY THIS RUN KNOWS — the same fix, and the same reason, as the
             * email sender (see campaigns/lib/SendWorker.php).
             *
             * Marking rows 'processing' and then selecting any 'processing' row is safe only while
             * exactly one worker exists. This one has the identical two-machine shape as the email
             * worker: a cron every minute on the monitoring box, and an HTTP kick to cit3 from
             * wa_trigger_worker_async() when Send Now is pressed. The flock in
             * whatsapp-send-worker.php is a file in the local temp directory, so each machine
             * happily believes it is alone.
             *
             * On the email side that shipped 24,499 duplicate sends before anyone noticed. It has
             * not visibly bitten here only because these audiences are smaller — the defect is the
             * same one, and a WhatsApp message costs money per message too.
             */
            $waTok = bin2hex(random_bytes(16));
            $waTokE = $conn->real_escape_string($waTok);
            // Registered before the claim, so a crash between the UPDATE and the first send still
            // releases the rows — see wa_claim_register().
            wa_claim_register($waTok);
            $conn->query("UPDATE wa_campaign_recipients
                             SET status='processing', claim_token='$waTokE', claimed_at=NOW()
                           WHERE campaign_id=$cid AND status='pending' AND is_test=0
                           ORDER BY id LIMIT " . (int)$limit);
            $claimed = [];
            if ($conn->affected_rows > 0) {
                $claimedR = $conn->query("SELECT * FROM wa_campaign_recipients
                                           WHERE campaign_id=$cid AND claim_token='$waTokE' ORDER BY id");
                while ($claimedR && $row = $claimedR->fetch_assoc()) $claimed[] = $row;
            }
            if (!$claimed) {
                // Same reasoning as the status skips above: say what was found, so "nothing happened"
                // is never the whole story. finalize() decides sent-vs-failed and logs its own line.
                $cntR = $conn->query("SELECT status, COUNT(*) c FROM wa_campaign_recipients
                                       WHERE campaign_id=$cid AND is_test=0 GROUP BY status");
                $parts = [];
                while ($cntR && $cr = $cntR->fetch_assoc()) $parts[] = "{$cr['status']}={$cr['c']}";
                wa_log("campaign #$cid: nothing left to claim (" . ($parts ? implode(', ', $parts) : 'no recipient rows at all') . ')');
                wa_finalize_if_drained($cid);
                continue;
            }

            $sender    = wa_sender_for_campaign($campaign);
            // The campaign's snapshotted route wins over the number's current default, so changing a
            // number's provider never re-routes a campaign that is already part-way through sending.
            $provider  = wa_resolve_provider($sender, $campaign['send_provider'] ?? null);
            $transport = wa_transport_for_sender($settings, $sender, $provider);

            // Settled once per batch rather than discovered 200 times over the network: without
            // credentials every single request is a guaranteed 401. The missing piece differs by
            // route, so the message names the one that actually applies.
            $blocker = null;
            if (!$transport->isConfigured()) {
                $blocker = $provider === 'netcore'
                    ? 'No Netcore API key on ' . ($campaign['business_number'] ?: 'the sending number')
                        . ' — add it in Settings → Sending numbers → Edit'
                    : 'Meta token or phone number ID missing for ' . ($campaign['business_number'] ?: 'the sending number')
                        . ' — check WhatsApp settings';
            }
            if ($blocker) wa_log("campaign #$cid: $blocker — this batch will be marked failed");
            else wa_log("campaign #$cid: sending via " . strtoupper($provider)
                . ' as ' . ($sender['business_number'] ?? 'unknown number'));

            // Customer Attributes resolved ONCE for the whole batch (one query per attribute), not
            // once per recipient — same batching as the email worker.
            $attributes = load_all_attributes();
            $attrByEmail = $attributes ? resolve_attribute_values_batch($attributes, $claimed) : [];

            // ── Phase 1: render everything (pure CPU, no network) ──
            $jobs = []; $rowsById = []; $previews = []; $clickTargets = [];
            foreach ($claimed as $rec) {
                $processed++;
                $rowsById[$rec['id']] = $rec;

                /*
                  Proof of life for the claim, every twenty-five recipients.

                  The stale sweep frees a claim nobody has touched for four minutes, which is what
                  makes a crashed run recoverable quickly. A healthy batch of two hundred can easily
                  run longer than that, and having its rows taken out from under it is how the same
                  person gets messaged twice. One cheap UPDATE per twenty-five keeps the claim
                  demonstrably alive without adding a write per message.
                */
                if (($processed % 25) === 0) wa_claim_touch($waTok);

                if ($blocker) continue;

                $attrTokens = $attrByEmail[strtolower((string)$rec['email'])] ?? [];
                $rendered   = wa_render_for_recipient($campaign, $rec, $attrTokens);
                $previews[$rec['id']] = $rendered['preview'];
                // Only rows that actually resolved one; everything else keeps the campaign default.
                if (!empty($rendered['click_target'])) $clickTargets[$rec['id']] = $rendered['click_target'];
                $jobs[] = [
                    'key' => $rec['id'],
                    'rid' => $rec['rid'],
                    'req' => $transport->buildRequest($rec['phone'], $rendered['content'], $rec['rid']),
                ];
            }

            // ── Phase 2: send them concurrently ──
            if ($blocker) {
                $results = [];
                foreach ($rowsById as $id => $_) {
                    $results[$id] = ['ok' => false, 'message_id' => null, 'error' => $blocker, 'code' => 'unconfigured', 'retryable' => false];
                }
            } else {
                // Sized per route: Meta's published limit is far higher than what Netcore will
                // absorb, and using one number for both means either leaving Meta throughput on
                // the table or provoking 429s on Netcore. See wa_concurrency_for().
                $concurrency = wa_concurrency_for($provider);
                $startedAt = microtime(true);
                $results = wa_send_parallel($transport, $jobs, $concurrency);
                $elapsed = max(0.001, microtime(true) - $startedAt);
                if ($jobs) {
                    wa_log(sprintf('campaign #%d: %d sends in %.1fs (%.0f/s, %s at concurrency %d)',
                        $cid, count($jobs), $elapsed, count($jobs) / $elapsed, $provider, $concurrency));
                }
            }

            // ── Phase 3: write outcomes back in a handful of queries ──
            // The campaign's own Retry toggle decides whether a recipient gets more than one go:
            // with it off, both a permanent rejection AND a provider-busy response settle the
            // recipient immediately instead of going back in the queue.
            $retryOn = (int)($campaign['retry_enabled'] ?? 1) === 1;
            $maxAttempts = $retryOn ? WA_MAX_ATTEMPTS : 1;

            $sentIds = []; $messageIds = []; $failures = []; $retryables = [];
            $accountFault = null;   // set when the SENDING NUMBER is the problem, not the recipient
            foreach ($results as $id => $res) {
                if ($accountFault === null && !empty($res['account_fault'])) $accountFault = (string)$res['account_fault'];
                if (!empty($res['ok'])) {
                    $sentIds[] = (int)$id;
                    $messageIds[(int)$id] = (string)($res['message_id'] ?? '');
                } elseif (!empty($res['retryable']) && $retryOn) {
                    $retryables[(int)$id] = $res['error'] ?? 'Provider busy';
                } else {
                    $failures[(int)$id] = ['error' => $res['error'] ?? 'Unknown send error', 'code' => $res['code'] ?? null];
                }
            }

            if ($sentIds) {
                $idCases = ''; $bodyCases = ''; $destCases = '';
                foreach ($sentIds as $id) {
                    $idCases   .= " WHEN $id THEN '" . $conn->real_escape_string($messageIds[$id] ?? '') . "'";
                    $bodyCases .= " WHEN $id THEN '" . $conn->real_escape_string(mb_substr((string)($previews[$id] ?? ''), 0, 4000)) . "'";
                    // Only rows that resolved one are named; the CASE leaves the rest alone.
                    if (!empty($clickTargets[$id])) {
                        $destCases .= " WHEN $id THEN '" . $conn->real_escape_string(mb_substr((string)$clickTargets[$id], 0, 1000)) . "'";
                    }
                }
                $destSql = $destCases !== '' ? ", click_target_url = CASE id$destCases ELSE click_target_url END" : '';
                $inList = implode(',', $sentIds);
                /*
                 * error_message/error_code are CLEARED here, and that is not housekeeping.
                 *
                 * A recipient whose first attempt was rejected goes back to 'pending' with the
                 * rejection stored on the row (see wa_mark_failed_batch — only the final attempt
                 * settles as 'failed'). When a later attempt succeeds, this UPDATE used to set
                 * the status and leave the old reason sitting there, so the report showed rows
                 * reading "Delivered — 131008: buttons: Button at index 0 of type Url requires a
                 * parameter": an outcome and a contradicting explanation on the same line, with
                 * no way to tell which one was current.
                 *
                 * The row succeeded. Whatever went wrong on an earlier try is no longer its
                 * outcome, and the failure is still on record in wa_campaign_events.
                 */
                $conn->query("UPDATE wa_campaign_recipients
                                 SET status='sent', sent_at=NOW(),
                                     error_message = NULL, error_code = NULL,
                                     wa_message_id = CASE id$idCases ELSE wa_message_id END,
                                     rendered_body = CASE id$bodyCases ELSE rendered_body END$destSql
                               WHERE id IN ($inList)");
                // delivered_count/read_count are deliberately NOT touched here — "sent" only means
                // the provider accepted the API call. Real delivery arrives later via webhook.php.
                /*
                 * Counts only recipients being accepted for the FIRST time, not every row in
                 * $sentIds — and that distinction is the whole bug.
                 *
                 * A recipient that Netcore rate-limited goes back to 'pending' with its attempts
                 * untouched (see the retryable branch below), gets claimed by a later batch, and
                 * succeeds. Adding count($sentIds) each time counted that person once per attempt,
                 * so sent_count climbed past the number of people the campaign actually had.
                 * Campaign #53 reported Sent 3,696 against Published 3,548 — more messages sent
                 * than recipients to send them to, which is impossible and was on the dashboard.
                 *
                 * sent_at is the test: it is NULL until the first acceptance and is never cleared,
                 * so a row already carrying one is a re-send and must not be counted again. The
                 * snapshot in $rowsById was read BEFORE the UPDATE above stamped sent_at, which is
                 * what makes this readable at all.
                 */
                $firstTime = 0;
                foreach ($sentIds as $id) {
                    if (empty($rowsById[$id]['sent_at'])) $firstTime++;
                }
                if ($firstTime > 0) {
                    $conn->query("UPDATE wa_campaigns SET sent_count = sent_count + $firstTime WHERE id=$cid");
                }
                foreach ($sentIds as $id) wa_record_event($cid, $id, 'sent');
                $sent += count($sentIds);
            }

            /*
             * The sending number itself is unusable — stop, don't grind.
             *
             * An account-level rejection (#133010 "not registered on Cloud API" above all) fails
             * every recipient identically, so continuing would burn a 40,000-row audience into the
             * same error, mark them all permanently failed, and leave the campaign unresendable
             * once the number is fixed. Instead the round is rolled back to 'pending', the campaign
             * is SUSPENDED with the reason attached, and Resume picks up exactly where it stopped.
             */
            if ($accountFault !== null) {
                $back = array_merge(array_keys($failures), array_keys($retryables));
                if ($back) {
                    $conn->query("UPDATE wa_campaign_recipients SET status='pending'
                                   WHERE id IN (" . implode(',', array_map('intval', $back)) . ")");
                }
                $reason = 'Sending stopped: ' . $accountFault;
                $conn->query("UPDATE wa_campaigns SET status='suspended',
                                     last_error='" . $conn->real_escape_string(mb_substr($reason, 0, 500)) . "'
                               WHERE id=$cid");
                wa_log("campaign #$cid: SUSPENDED — $accountFault");
                wa_log("campaign #$cid: " . count($back) . " recipient(s) put back to pending, none consumed. "
                     . "Fix the number, then press Resume on the campaign.");
                continue;
            }

            if ($failures) {
                wa_mark_failed_batch($cid, $failures, $rowsById, $maxAttempts);
                $failed += count($failures);
                $sampleId = array_key_first($failures);
                wa_log("campaign #$cid: " . count($failures) . " permanent rejection(s), e.g. "
                    . ($rowsById[$sampleId]['phone'] ?? '?') . ' -> ' . $failures[$sampleId]['error']);
            }

            if ($retryables) {
                // Straight back to 'pending' with attempts untouched: the provider said "not now",
                // not "never". Burning an attempt here would permanently fail thousands of perfectly
                // good numbers after three rate-limit bursts.
                $conn->query("UPDATE wa_campaign_recipients SET status='pending'
                               WHERE id IN (" . implode(',', array_keys($retryables)) . ")");
                $sampleId = array_key_first($retryables);
                wa_log("campaign #$cid: " . count($retryables) . ' rate-limited/retryable, requeued (attempts NOT consumed), e.g. '
                    . $retryables[$sampleId] . ' — lower WA_SEND_CONCURRENCY if this is constant');
                sleep(WA_RATE_LIMIT_BACKOFF_SECONDS);
            }

            wa_finalize_if_drained($cid);
        } catch (\Throwable $e) {
            /*
             * One campaign must never take the whole run down.
             *
             * mysqli throws on PHP 8.1+, display_errors is off in the worker, and this loop is
             * the only thing standing between an unexpected exception and a run that simply
             * stops — no "COMPLETED", no "run finished", nothing in the log at all. That is
             * exactly how campaign #13 vanished mid-materialize after a schema migration lagged
             * behind the code that read the new column.
             *
             * The campaign is left 'running' on purpose rather than failed: the cause is usually
             * environmental (a missing column, a lock, a timeout), so the next tick should retry
             * it rather than write it off permanently.
             */
            wa_log("campaign #$cid: ABORTED — [" . get_class($e) . '] ' . $e->getMessage()
                . ' (left running; the next tick will retry it)');
            continue;
        }
    }

    return ['processed' => $processed, 'sent' => $sent, 'failed' => $failed, 'campaigns' => count($ids)];
}

/**
 * $maxAttempts strikes → 'failed', otherwise back to 'pending' — in two queries rather than one
 * per recipient. Only ever called with PERMANENT failures (provider-busy takes the requeue path
 * above, unless the campaign has Retry switched off, in which case $maxAttempts is 1 and
 * everything settles on the first try).
 */
function wa_mark_failed_batch(int $campaignId, array $failures, array $rowsById, int $maxAttempts = WA_MAX_ATTEMPTS): void {
    global $conn;
    if (!$failures) return;

    $byStatus = ['failed' => [], 'pending' => []];
    $errCases = ''; $codeCases = '';
    foreach ($failures as $id => $f) {
        $id = (int)$id;
        $attempts = (int)($rowsById[$id]['attempts'] ?? 0) + 1;
        $byStatus[$attempts >= $maxAttempts ? 'failed' : 'pending'][] = $id;
        $errCases  .= " WHEN $id THEN '" . $conn->real_escape_string(substr((string)$f['error'], 0, 480)) . "'";
        $codeCases .= " WHEN $id THEN '" . $conn->real_escape_string(substr((string)($f['code'] ?? ''), 0, 60)) . "'";
    }

    foreach ($byStatus as $status => $ids) {
        if (!$ids) continue;
        $inList = implode(',', $ids);
        $failedAt = $status === 'failed' ? ', failed_at=NOW()' : '';
        // attempts + 1 rather than a computed literal, so a concurrent write can't be
        // overwritten with a stale value.
        $conn->query("UPDATE wa_campaign_recipients
                         SET status='$status', attempts = attempts + 1$failedAt,
                             error_message = CASE id$errCases ELSE error_message END,
                             error_code    = CASE id$codeCases ELSE error_code END
                       WHERE id IN ($inList)");
        if ($status === 'failed') {
            $conn->query("UPDATE wa_campaigns SET failed_count = failed_count + " . count($ids) . " WHERE id=$campaignId");
            foreach ($ids as $id) {
                wa_record_event($campaignId, $id, 'failed', $failures[$id]['code'] ?? null, $failures[$id]['error'] ?? null);
            }
        }
    }
}

function wa_record_event(int $campaignId, int $recipientId, string $type, ?string $code = null, ?string $detail = null): void {
    global $conn;
    $codeSql   = $code === null ? 'NULL' : "'" . $conn->real_escape_string(substr($code, 0, 60)) . "'";
    $detailSql = $detail === null ? 'NULL' : "'" . $conn->real_escape_string(substr($detail, 0, 480)) . "'";
    $conn->query("INSERT INTO wa_campaign_events (campaign_id, recipient_id, event_type, error_code, detail)
                  VALUES ($campaignId, $recipientId, '" . $conn->real_escape_string($type) . "', $codeSql, $detailSql)");
}


/**
 * Recomputes sent/delivered/read/failed for the given campaigns from the recipient rows.
 *
 * THIS REPLACES `SET delivered_count = delivered_count + 1` PER RECEIPT, and that is the whole
 * point. The old form took a row lock on the same wa_campaigns row for every single receipt, so
 * 50,000 receipts meant 50,000 serialized lock acquisitions on one row. This runs ONCE per
 * campaign per drain chunk regardless of how many receipts it carried.
 *
 * It also fixes a real bug rather than just being faster. Incremented counters DRIFT, because
 * nothing ever reconciles them against the rows they claim to describe:
 *
 *   - the send worker does `sent_count = sent_count + N` on every batch, so a recipient that was
 *     rate-limited, requeued and successfully re-sent counted TWICE. That is why campaign #53
 *     reported Sent 3,696 against Published 3,548 — more messages sent than people to send to,
 *     which is impossible and was visible on the dashboard.
 *   - any receipt applied twice (a provider retry, a replayed callback) permanently inflated a
 *     number with no way to correct it short of manual SQL.
 *
 * Derived counts cannot drift: they are a fact about the rows, recomputed from scratch. If a
 * number is ever wrong, the next chunk corrects it by itself.
 *
 * COUNTED FROM TIMESTAMPS, NOT `status`, for delivered/read/sent — deliberately:
 *
 *   status holds the CURRENT verdict and is overwritten as the message progresses, so counting
 *   `status='delivered'` would make delivered_count DROP each time a row moved on to 'read'. The
 *   timestamps are write-once milestones, so the counts only ever climb — which is both truthful
 *   and what someone watching a live campaign expects to see.
 *
 *   delivered counts read_at as well, because a message that was read was necessarily delivered,
 *   and WhatsApp does sometimes deliver the 'read' receipt when the 'delivered' one was lost.
 *
 * failed is the exception and DOES read status: a rejection is a verdict, not a milestone, and a
 * row that failed one attempt and succeeded on the next must not stay counted as a failure.
 */
function wa_refresh_campaign_counts(array $campaignIds): void {
    global $conn;

    $ids = array_values(array_unique(array_map('intval', array_filter($campaignIds))));
    if (!$ids) return;

    foreach (array_chunk($ids, 200) as $slice) {
        $in = implode(',', $slice);
        /*
         * One statement for every campaign in the slice. The derived table groups the recipient
         * rows once — covered by the campaign_id prefix of idx_campaign_status — and the join
         * writes each campaign's four numbers in a single pass.
         */
        $conn->query("UPDATE wa_campaigns c
                        JOIN (
                              SELECT campaign_id,
                                     SUM(sent_at IS NOT NULL)                                  AS sent_c,
                                     SUM(delivered_at IS NOT NULL OR read_at IS NOT NULL)      AS del_c,
                                     SUM(read_at IS NOT NULL)                                  AS read_c,
                                     SUM(status = 'failed')                                    AS fail_c
                                FROM wa_campaign_recipients
                               WHERE campaign_id IN ($in) AND is_test = 0
                               GROUP BY campaign_id
                             ) t ON t.campaign_id = c.id
                         SET c.sent_count      = t.sent_c,
                             c.delivered_count = t.del_c,
                             c.read_count      = t.read_c,
                             c.failed_count    = t.fail_c
                       WHERE c.id IN ($in)");
    }
}

/**
 * Closes out a campaign once its queue is empty.
 *
 * "Nothing left pending" is NOT the same as "everyone got it" — a recipient that fails
 * WA_MAX_ATTEMPTS times also leaves the queue. So the final status depends on whether
 * anything actually succeeded, which is what stops a campaign showing SENT when every single
 * message was rejected (e.g. an unapproved template name).
 */
function wa_finalize_if_drained(int $campaignId): void {
    global $conn;
    $r = $conn->query("SELECT COUNT(*) AS c FROM wa_campaign_recipients
                        WHERE campaign_id=$campaignId AND is_test=0 AND status IN ('pending','processing')");
    $remaining = $r ? (int)$r->fetch_assoc()['c'] : 0;
    if ($remaining > 0) return;

    $s = $conn->query("SELECT COUNT(*) AS c FROM wa_campaign_recipients
                        WHERE campaign_id=$campaignId AND is_test=0 AND status IN ('sent','delivered','read')");
    $sentCount = $s ? (int)$s->fetch_assoc()['c'] : 0;
    $finalStatus = $sentCount > 0 ? 'sent' : 'failed';
    $conn->query("UPDATE wa_campaigns SET status='$finalStatus', completed_at=NOW()
                   WHERE id=$campaignId AND status='running'");
    /*
     * Settle the counters against the rows before anyone reads the finished campaign. The send
     * loop's running totals are incremented as batches complete, so this is the moment they stop
     * being an estimate and become a fact — and the moment any drift accumulated during a long
     * send is corrected, rather than being frozen into the report forever.
     */
    wa_refresh_campaign_counts([$campaignId]);
    wa_log("campaign #$campaignId: COMPLETED -> status=$finalStatus ($sentCount accepted by the provider)");
}

/**
 * Re-decides a finished campaign's status after a webhook changes a recipient's outcome.
 *
 * wa_finalize_if_drained() runs the moment the last message is ACCEPTED by the provider, and at
 * that instant every recipient reads 'sent' — so the campaign is marked 'sent'. The rejections
 * arrive seconds to minutes later, on the webhook, and flip those rows to 'failed'. Nothing was
 * re-checking the campaign, so one where every single message was rejected still showed a green
 * SENT badge next to "Failed 2".
 *
 * Only ever touches a campaign that has already finished, and never while recipients are still
 * pending or processing — a mid-send failure must not prematurely fail the whole campaign.
 *
 * Idempotent: it computes the status the data implies and writes only when that differs.
 */
function wa_reconcile_campaign_status(int $campaignId): void {
    global $conn;

    $r = $conn->query("SELECT status FROM wa_campaigns WHERE id=$campaignId LIMIT 1");
    $row = $r ? $r->fetch_assoc() : null;
    // 'running' is the worker's business; 'draft'/'scheduled'/'suspended' are the admin's.
    if (!$row || !in_array($row['status'], ['sent', 'failed'], true)) return;

    $c = $conn->query("SELECT SUM(status IN ('pending','processing')) AS busy,
                              SUM(status IN ('sent','delivered','read')) AS ok
                         FROM wa_campaign_recipients
                        WHERE campaign_id=$campaignId AND is_test=0");
    $s = $c ? $c->fetch_assoc() : null;
    if (!$s || (int)$s['busy'] > 0) return;

    $want = (int)$s['ok'] > 0 ? 'sent' : 'failed';
    if ($want === $row['status']) return;

    /*
     * When a campaign is being demoted to 'failed', carry the REASON up with it.
     *
     * Without this the campaign row says FAILED and stops there. The actual explanation —
     * "131042: no payment method is set up for your WhatsApp Business account", with Meta's own
     * fix URL in it — sits on the individual recipient rows and in wa-worker.log, which means
     * the first question after every failed campaign is "why?" and the only people who can
     * answer it are the ones willing to open a log file or write SQL.
     *
     * The most common error among the failures is the one that goes up, not the first: a
     * campaign that half-failed on invalid numbers and half on an account-level problem should
     * report the account-level problem, because that is the one worth acting on and it will be
     * the majority. GROUP BY does that far more honestly than picking a row at random.
     */
    $err = null;
    if ($want === 'failed') {
        $er = $conn->query("SELECT error_code, error_message, COUNT(*) c
                              FROM wa_campaign_recipients
                             WHERE campaign_id=$campaignId AND is_test=0 AND status='failed'
                               AND error_message IS NOT NULL AND error_message <> ''
                             GROUP BY error_code, error_message
                             ORDER BY c DESC LIMIT 1");
        $e = $er ? $er->fetch_assoc() : null;
        if ($e) {
            $err = ($e['error_code'] !== '' && $e['error_code'] !== null ? $e['error_code'] . ': ' : '')
                 . (string)$e['error_message'];
        }
    }

    $sets = "status='$want'";
    // Cleared on the way back UP as well: a campaign that turns out to have succeeded must not
    // keep a stale failure message hanging off it.
    $sets .= ', last_error=' . ($err === null ? 'NULL' : "'" . $conn->real_escape_string(mb_substr($err, 0, 490)) . "'");

    $conn->query("UPDATE wa_campaigns SET $sets WHERE id=$campaignId");
    wa_log("campaign #$campaignId: status corrected to $want — "
        . ($want === 'failed'
            ? 'every message was rejected after the provider accepted it'
              . ($err !== null ? ' (' . mb_substr($err, 0, 200) . ')' : '')
            : 'a recipient succeeded after all'));
}

/**
 * Fire-and-forget kick so "Send now" doesn't wait for the next cron minute — opens a socket
 * to the worker endpoint and closes it without reading the response. Cron remains the
 * reliable safety net that finishes whatever this didn't get to.
 */
function wa_trigger_worker_async(int $campaignId): void {
    $path = WA_WORKER_PATH . '?cron_secret=' . urlencode(WA_CRON_SECRET) . '&campaign_id=' . $campaignId;
    $fp = @fsockopen('ssl://' . WA_WORKER_HOST, 443, $errno, $errstr, 1);
    if (!$fp) return;
    stream_set_timeout($fp, 1);
    fwrite($fp, "GET $path HTTP/1.1\r\nHost: " . WA_WORKER_HOST . "\r\nConnection: Close\r\n\r\n");
    fclose($fp);
}

<?php
/*
 * attributes_ensure_schema() — idempotent CREATE TABLE IF NOT EXISTS for the
 * Customer Attributes feature. Called at the top of every entrypoint in this
 * feature, mirrors campaigns/lib/schema.php's campaigns_ensure_schema().
 *
 * campaign_attributes: an attribute is either
 *   - 'system' (category), mapped to a real column in an existing table
 *     (mapped_db/mapped_table/mapped_column), correlated back to the
 *     recipient via mapped_join_col ('user_id' or 'email' — whichever exists
 *     on that same table, auto-detected at create time — see attributes.php's
 *     search_columns/create actions). Resolved live at send time, never
 *     copied/cached — see campaigns/lib/AttributeResolver.php.
 *   - 'linked' (category), a MULTI-STEP lookup chain (resolver_json) for values no single
 *     table.column holds — e.g. COMMUNITY_LINK, which needs
 *     email -> users.user_id -> assigned_links.assigned_id ->
 *     whatsapp_placement_club_link.community_link, plus a whole second path through the
 *     *_for_refund tables to fall back on when the first finds nothing. Paths are tried in
 *     order and the first one that produces a value wins. See attr_chain_normalize() for
 *     the stored shape and AttributeResolver.php's resolve_chain_for_emails() for the read
 *     side. Also resolved live at send time, never copied/cached.
 *   - 'custom' (category), backed by its OWN real column in campaign_attribute_data
 *     (one wide table, one column per custom attribute, keyed by email) — either
 *     typed in manually or (most commonly) auto-populated from an unrecognized CSV
 *     column during a Lists import (see lists/lib/ContactImportWorker.php's
 *     contact_upsert()/fan_out_extra_attributes()). Each new custom attribute gets
 *     its column added via ALTER TABLE the moment it's created.
 */
function attributes_ensure_schema() {
    global $conn;
    if (!$conn) return;

    try {
        $conn->query("CREATE TABLE IF NOT EXISTS campaign_attributes (
            id              INT AUTO_INCREMENT PRIMARY KEY,
            name            VARCHAR(100) NOT NULL,
            category        ENUM('custom','system','linked') NOT NULL DEFAULT 'custom',
            data_type       ENUM('text','number','date','url','boolean') NOT NULL DEFAULT 'text',
            date_format     VARCHAR(40)  DEFAULT NULL,
            mapped_db       VARCHAR(64)  DEFAULT NULL,
            mapped_table    VARCHAR(128) DEFAULT NULL,
            mapped_column   VARCHAR(128) DEFAULT NULL,
            mapped_join_col VARCHAR(32)  DEFAULT NULL,
            resolver_json   TEXT         DEFAULT NULL,
            default_value   VARCHAR(500) DEFAULT NULL,
            created_by      BIGINT UNSIGNED DEFAULT NULL,
            created_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            UNIQUE INDEX uq_name (name)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

        // One real column per custom attribute (added dynamically via ALTER TABLE — see
        // attribute_data_ensure_column() below), one row per email. This is what backs
        // every 'custom' (unmapped) attribute — a system-mapped attribute never touches
        // this table at all, its data lives in its own real source table instead.
        $conn->query("CREATE TABLE IF NOT EXISTS campaign_attribute_data (
            email VARCHAR(255) NOT NULL,
            PRIMARY KEY (email)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

        $conn->query("CREATE TABLE IF NOT EXISTS campaign_attribute_logs (
            id              BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            attribute_id    INT DEFAULT NULL,
            attribute_name  VARCHAR(100) NOT NULL,
            action          VARCHAR(100) NOT NULL,
            username        VARCHAR(100) DEFAULT NULL,
            status          ENUM('processed','failed') NOT NULL DEFAULT 'processed',
            created_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_created_at (created_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    } catch (\Throwable $e) {
        // Another concurrent request is doing this exact same idempotent setup right now —
        // every statement above is CREATE-IF-NOT-EXISTS, so whichever request finishes first
        // still leaves the schema correct; this request just continues instead of fatal-erroring.
        error_log('attributes_ensure_schema: ' . $e->getMessage());
    }

    // Columns added after the first release — a no-op on a fresh install (the CREATE above
    // already includes them), an ALTER on a deployment that predates them.
    attributes_migrate_schema();
}

/** Normalizes a user-typed or CSV-header attribute name into the upper_snake_case form
 *  used in its XX_{name}_XX token — so "First Name" / "first-name" / "First_Name" all
 *  become FIRST_NAME. Shared by attributes.php (manual create) and
 *  lists/lib/ContactImportWorker.php (auto-create from an unrecognized CSV column). */
function normalize_attribute_name(string $raw): string {
    $s = strtoupper(trim($raw));
    $s = preg_replace('/[^A-Z0-9]+/', '_', $s);
    return trim($s, '_');
}

/** MySQL identifiers cap at 64 chars — campaign_attributes.name allows up to 100, so the
 *  physical column in campaign_attribute_data uses a truncated form. Truncation collisions
 *  are extremely unlikely in practice and are a pre-existing risk of this approach; not
 *  guarded against further since campaign_attributes.name itself is already unique. */
function attribute_column_name(string $attributeName): string {
    return substr($attributeName, 0, 64);
}

/** Idempotently adds a TEXT column to campaign_attribute_data for one custom (unmapped)
 *  attribute — called once when the attribute is first created (manually, or auto-created
 *  from an unrecognized CSV column) so the column always exists before anything tries to
 *  write or read it. */
function attribute_data_ensure_column(string $attributeName): void {
    global $conn;
    $col = attribute_column_name($attributeName);

    /*
     * Confirmed columns are remembered for the life of the process.
     *
     * The name says "called once when the attribute is first created", and that was true of the
     * UI path this was written for. The CSV importer calls it per attribute PER ROW instead, so a
     * 2,000-contact upload with six columns ran SHOW COLUMNS twelve thousand times — and SHOW
     * COLUMNS is a metadata query, far dearer than the indexed writes it was guarding. That was
     * the bulk of an import moving at roughly 100 contacts a minute.
     *
     * Only the positive result is cached, which is what makes it safe: a column that exists
     * cannot stop existing under us mid-run, so a hit can never be wrong. A miss still asks the
     * database, so a column added by another process is picked up normally, and the ALTER stays
     * guarded for the case where two importers race on the same new attribute.
     */
    static $ensured = [];
    if (isset($ensured[$col])) return;

    $colE = $conn->real_escape_string($col);
    $chk = $conn->query("SHOW COLUMNS FROM campaign_attribute_data LIKE '$colE'");
    if ($chk && $chk->num_rows === 0) {
        $conn->query("ALTER TABLE campaign_attribute_data ADD COLUMN `$col` TEXT DEFAULT NULL");
    }
    $ensured[$col] = true;
}

/** Writes one row to campaign_attribute_logs — every create/edit/delete/auto-create goes
 *  through here so the Attribute Logs screen has a single consistent source. */
function attribute_log(?int $attributeId, string $attributeName, string $action, ?string $username, string $status = 'processed') {
    global $conn;
    $nameE = $conn->real_escape_string($attributeName);
    $actionE = $conn->real_escape_string($action);
    $userE = $username !== null ? "'" . $conn->real_escape_string($username) . "'" : 'NULL';
    $idSql = $attributeId !== null ? (int)$attributeId : 'NULL';
    $statusE = $conn->real_escape_string($status);
    $conn->query("INSERT INTO campaign_attribute_logs (attribute_id, attribute_name, action, username, status)
                  VALUES ($idSql, '$nameE', '$actionE', $userE, '$statusE')");
}

/* ------------------------------------------------------------------------- *
 * Databases this feature may map / chain attributes against. All three live on
 * the same MySQL server (see config/database.php's DB_HOST comment), so one
 * connection can query any of them via db.table qualification.
 * ------------------------------------------------------------------------- */
if (!defined('ATTRIBUTES_SEARCHABLE_DBS')) {
    define('ATTRIBUTES_SEARCHABLE_DBS', ['istudio_cit', 'istudio_exam', 'istudio_main']);
}

/** The database + table holding the canonical email -> user_id mapping, used to seed a
 *  lookup chain whose first step matches on user_id when the recipient row itself has no
 *  user_id attached (e.g. a CSV-imported contact that carries only an email). */
if (!defined('ATTRIBUTES_USERS_DB'))    define('ATTRIBUTES_USERS_DB', 'istudio_cit');
if (!defined('ATTRIBUTES_USERS_TABLE')) define('ATTRIBUTES_USERS_TABLE', 'users');

/**
 * Adds the columns introduced after this feature's first release to an already-created
 * campaign_attributes table. Split out of the CREATE TABLE above (which only ever runs on
 * a fresh install) so existing deployments pick them up on the next request — same
 * idempotent, run-on-every-entrypoint contract as attributes_ensure_schema() itself.
 */
function attributes_migrate_schema() {
    global $conn;
    if (!$conn) return;
    try {
        $have = [];
        $r = $conn->query("SHOW COLUMNS FROM campaign_attributes");
        while ($r && $row = $r->fetch_assoc()) $have[$row['Field']] = $row['Type'];
        if (!$have) return; // table doesn't exist yet — the CREATE above already made it current

        // Output format for data_type='date' attributes (an attr_date_presets() id).
        // Editable at any time: it only changes how the stored value is RENDERED.
        if (!isset($have['date_format'])) {
            $conn->query("ALTER TABLE campaign_attributes ADD COLUMN date_format VARCHAR(40) DEFAULT NULL AFTER data_type");
        }
        // The multi-step lookup definition for category='linked' — see attr_chain_normalize().
        if (!isset($have['resolver_json'])) {
            $conn->query("ALTER TABLE campaign_attributes ADD COLUMN resolver_json TEXT DEFAULT NULL AFTER mapped_join_col");
        }
        // 'linked' is a third category alongside 'custom' and 'system'.
        if (isset($have['category']) && stripos($have['category'], 'linked') === false) {
            $conn->query("ALTER TABLE campaign_attributes MODIFY COLUMN category ENUM('custom','system','linked') NOT NULL DEFAULT 'custom'");
        }
    } catch (\Throwable $e) {
        error_log('attributes_migrate_schema: ' . $e->getMessage());
    }
}

/* ------------------------------------------------------------------------- *
 * Date formatting — how a data_type='date' attribute is rendered in a template
 * ------------------------------------------------------------------------- */

/**
 * The output formats offered for a data_type='date' attribute. 'id' is what is stored in
 * campaign_attributes.date_format, 'php' is the date() format used to render it, and
 * 'sept' marks the presets that use the four-letter "Sept" month abbreviation rather than
 * PHP's own three-letter "Sep". Exposed to the UI via attributes.php?action=date_formats
 * so the dropdown and the send-time renderer can never drift apart.
 */
function attr_date_presets(): array {
    return [
        ['id' => 'iso_date',      'php' => 'Y-m-d',        'sept' => false],
        ['id' => 'dmy_dash',      'php' => 'd-m-Y',        'sept' => false],
        ['id' => 'dmy_slash',     'php' => 'd/m/Y',        'sept' => false],
        ['id' => 'dmy_24h',       'php' => 'd-m-Y H:i',    'sept' => false],
        ['id' => 'dmy_12h',       'php' => 'd-m-Y g:i A',  'sept' => false],
        ['id' => 'iso_datetime',  'php' => 'Y-m-d H:i:s',  'sept' => false],
        ['id' => 'dmon_sep',      'php' => 'j M, Y',       'sept' => false],
        ['id' => 'dmon_sept',     'php' => 'j M, Y',       'sept' => true],
        ['id' => 'dmon_sept_12h', 'php' => 'j M, Y g:i A', 'sept' => true],
        ['id' => 'dmon_full',     'php' => 'j F Y',        'sept' => false],
        ['id' => 'dmon_full_12h', 'php' => 'j F Y, g:i A', 'sept' => false],
        ['id' => 'time_24h',      'php' => 'H:i',          'sept' => false],
        ['id' => 'time_12h',      'php' => 'g:i A',        'sept' => false],
    ];
}

/** attr_date_presets() plus a rendered sample of each, so the picker can label every option
 *  with what it will actually produce instead of a cryptic format string. */
function attr_date_presets_with_samples(?int $sampleTs = null): array {
    $ts = $sampleTs ?? strtotime('2026-09-10 16:06:00');
    $out = [];
    foreach (attr_date_presets() as $p) {
        $out[] = ['id' => $p['id'], 'sample' => attr_date_render($ts, $p['php'], $p['sept'])];
    }
    return $out;
}

/** date() with one extra trick: when $sept is on, the M (short month) token is replaced by a
 *  literal Jan/Feb/.../Sept/... abbreviation first, since PHP has no format character that
 *  produces the four-letter "Sept" form. */
function attr_date_render(int $ts, string $fmt, bool $sept): string {
    if ($sept) {
        $months = [1 => 'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sept', 'Oct', 'Nov', 'Dec'];
        $abbr = $months[(int)date('n', $ts)];
        // Escape every character so date() emits the abbreviation literally instead of
        // interpreting its letters as further format tokens.
        $literal = '';
        foreach (str_split($abbr) as $ch) $literal .= chr(92) . $ch;
        $fmt = str_replace('M', $literal, $fmt);
    }
    return date($fmt, $ts);
}

/** Best-effort parse of whatever a date-ish source column holds — a DATE, a DATETIME, a unix
 *  timestamp, or MySQL's 0000-00-00 zero date (which is not a real date and must not be
 *  rendered as one). Returns null when the value cannot be read as a date, in which case the
 *  caller leaves it untouched rather than showing a wrong one. */
function attr_parse_date_value($value): ?int {
    $v = trim((string)$value);
    if ($v === '') return null;
    if (strncmp($v, '0000-00-00', 10) === 0) return null;
    if (ctype_digit($v) && strlen($v) >= 9 && strlen($v) <= 11) return (int)$v; // unix timestamp
    $ts = strtotime($v);
    return $ts === false ? null : $ts;
}

/** Renders one resolved value through a date preset id. An unknown or blank preset, and a
 *  value that is not a readable date, both pass straight through unchanged. */
function attr_format_date($value, ?string $formatId) {
    if ($formatId === null || $formatId === '') return $value;
    $preset = null;
    foreach (attr_date_presets() as $p) if ($p['id'] === $formatId) { $preset = $p; break; }
    if (!$preset) return $value;
    $ts = attr_parse_date_value($value);
    if ($ts === null) return $value;
    return attr_date_render($ts, $preset['php'], $preset['sept']);
}

/** True when $formatId is one this build knows how to render. */
function attr_is_valid_date_format(string $formatId): bool {
    foreach (attr_date_presets() as $p) if ($p['id'] === $formatId) return true;
    return false;
}

/* ------------------------------------------------------------------------- *
 * Multi-step lookup chains (category='linked')
 * ------------------------------------------------------------------------- */

/** Real column names of $db.$table, as a name => data_type map. Cached per process because
 *  validating a chain asks for the same table several times over (match column, output
 *  column, order column). */
function attr_table_columns(string $db, string $table): array {
    global $conn;
    static $cache = [];
    $key = "$db.$table";
    if (isset($cache[$key])) return $cache[$key];
    $dbE = $conn->real_escape_string($db);
    $tblE = $conn->real_escape_string($table);
    $cols = [];
    $r = $conn->query("SELECT COLUMN_NAME, DATA_TYPE FROM INFORMATION_SCHEMA.COLUMNS
                        WHERE TABLE_SCHEMA='$dbE' AND TABLE_NAME='$tblE'
                        ORDER BY ORDINAL_POSITION");
    while ($r && $row = $r->fetch_assoc()) $cols[$row['COLUMN_NAME']] = $row['DATA_TYPE'];
    return $cache[$key] = $cols;
}

/**
 * Validates and normalizes a lookup-chain definition posted by the chain builder.
 *
 * Shape (also what ends up in campaign_attributes.resolver_json):
 *   {
 *     "seed": "user_id" | "email",     // what the FIRST step of every branch matches on
 *     "branches": [                     // tried top to bottom, first non-empty value wins
 *       { "label": "Regular",
 *         "steps": [                    // each step feeds its out_col into the next match_col
 *           {"db":"istudio_cit","table":"assigned_links","match_col":"user_id",
 *            "out_col":"assigned_id","order_by":null,"order_dir":"desc"},
 *           {"db":"istudio_cit","table":"whatsapp_placement_club_link","match_col":"id",
 *            "out_col":"community_link"}
 *         ] }
 *     ]
 *   }
 *
 * Every db/table/column is re-checked against INFORMATION_SCHEMA here rather than trusted
 * from the client, because these names go into the SQL as identifiers at send time.
 *
 * @return array ['ok' => bool, 'error' => string, 'chain' => array]
 */
function attr_chain_normalize($raw): array {
    $bad = fn($msg) => ['ok' => false, 'error' => $msg, 'chain' => []];

    $chain = is_array($raw) ? $raw : json_decode((string)$raw, true);
    if (!is_array($chain)) return $bad('The lookup steps could not be read');

    $seed = $chain['seed'] ?? 'user_id';
    if (!in_array($seed, ['user_id', 'email'], true)) return $bad('Start value must be user_id or email');

    $branches = $chain['branches'] ?? [];
    if (!is_array($branches) || !$branches) return $bad('Add at least one lookup path');
    if (count($branches) > 5) return $bad('At most 5 lookup paths');

    $outBranches = [];
    foreach ($branches as $bi => $branch) {
        $steps = is_array($branch) ? ($branch['steps'] ?? []) : [];
        if (!is_array($steps) || !$steps) return $bad('Path ' . ($bi + 1) . ' has no steps');
        if (count($steps) > 6) return $bad('Path ' . ($bi + 1) . ' has more than 6 steps');

        $outSteps = [];
        foreach ($steps as $si => $step) {
            $where = 'Path ' . ($bi + 1) . ', step ' . ($si + 1);
            if (!is_array($step)) return $bad("$where: could not be read");
            $db    = trim((string)($step['db'] ?? ''));
            $table = trim((string)($step['table'] ?? ''));
            $match = trim((string)($step['match_col'] ?? ''));
            $out   = trim((string)($step['out_col'] ?? ''));
            $order = trim((string)($step['order_by'] ?? ''));
            $dir   = strtolower(trim((string)($step['order_dir'] ?? 'desc'))) === 'asc' ? 'asc' : 'desc';

            if (!in_array($db, ATTRIBUTES_SEARCHABLE_DBS, true)) return $bad("$where: unknown database");
            if ($table === '' || $match === '' || $out === '') return $bad("$where: pick a table, a match column and a value column");

            $cols = attr_table_columns($db, $table);
            if (!$cols) return $bad("$where: table $db.$table does not exist");
            if (!isset($cols[$match])) return $bad("$where: column $match does not exist on $table");
            if (!isset($cols[$out]))   return $bad("$where: column $out does not exist on $table");
            if ($order !== '' && !isset($cols[$order])) return $bad("$where: order column $order does not exist on $table");

            $outSteps[] = [
                'db' => $db, 'table' => $table, 'match_col' => $match, 'out_col' => $out,
                'order_by' => $order !== '' ? $order : null, 'order_dir' => $dir,
            ];
        }
        $outBranches[] = ['label' => trim((string)($branch['label'] ?? '')), 'steps' => $outSteps];
    }

    return ['ok' => true, 'error' => '', 'chain' => ['seed' => $seed, 'branches' => $outBranches]];
}

/** One-line human summary of a stored chain, e.g.
 *  "user_id → assigned_links.assigned_id → whatsapp_placement_club_link.community_link (+1 fallback)"
 *  — used for the Mapped source column of the attributes table. */
function attr_chain_summary(?string $resolverJson): string {
    $chain = json_decode((string)$resolverJson, true);
    if (!is_array($chain) || empty($chain['branches'][0]['steps'])) return '';
    $parts = [$chain['seed'] ?? 'user_id'];
    foreach ($chain['branches'][0]['steps'] as $s) $parts[] = $s['table'] . '.' . $s['out_col'];
    $summary = implode(' → ', $parts);
    $extra = count($chain['branches']) - 1;
    if ($extra > 0) $summary .= " (+$extra fallback" . ($extra > 1 ? 's' : '') . ')';
    return $summary;
}

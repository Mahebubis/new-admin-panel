<?php
/*
 * /api/lists/contact_uploads.php — the 3-step Import Contacts wizard's backend.
 *
 * action=preview_upload     &file (multipart) &list_id   → Step 1: stage file, detect headers/sample row
 * action=start_import       &list_id &token &mapping(json) &default_values(json)
 *                                                          → Step 2 confirm: commit file, queue background import
 * action=logs               &page &per_page &search &status → Contact Logs table
 * action=status             &id                            → single upload's live progress (Step 3 / Contact Logs polling)
 * action=failures           &id &page &per_page            → paginated per-row failure reasons
 * action=download_failures  &id                            → CSV blob of just the failed rows
 * action=sample_file                                       → downloadable CSV with the canonical header row
 */
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../middleware/auth.php';
require_once __DIR__ . '/lib/config.php';
require_once __DIR__ . '/lib/schema.php';
require_once __DIR__ . '/lib/CsvMapper.php';
require_once __DIR__ . '/lib/ContactImportWorker.php';

lists_ensure_schema();

$jwt = require_jwt();
/* Shared with the Kumo MTA module, which manages the same data through
   this endpoint — so either permission may use it. */
require_any_permission(['netcore_behaviour', 'kumo_mta'], $jwt);

function jin($k, $d = null) { $v = $_REQUEST[$k] ?? null; return ($v === null || $v === '') ? $d : $v; }

$action = jin('action', '');

if ($action === 'sample_file') {
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="contacts_sample.csv"');
    $out = fopen('php://output', 'w');
    fputcsv($out, ['EMAIL', 'FIRST_NAME', 'LAST_NAME', 'PHONE', 'STATE', 'COUNTRY', 'CITY']);
    fputcsv($out, ['jane.doe@example.com', 'Jane', 'Doe', '9876543210', 'Maharashtra', 'India', 'Pune']);
    fclose($out);
    exit;
}

if ($action === 'preview_upload') {
    $listId = (int)jin('list_id', 0);
    if (!$listId) api_error('list_id required');
    if (empty($_FILES['file']) || $_FILES['file']['error'] !== UPLOAD_ERR_OK) api_error('Choose a CSV file to upload');

    $file = $_FILES['file'];
    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    if ($ext !== 'csv') api_error('Only CSV files are supported — export your spreadsheet as CSV first');
    if ($file['size'] > CONTACT_UPLOAD_MAX_FILE_BYTES) {
        api_error('File too large — max ' . (CONTACT_UPLOAD_MAX_FILE_BYTES / 1024 / 1024) . 'MB');
    }

    if (!is_dir(CONTACT_UPLOADS_TMP_DIR)) mkdir(CONTACT_UPLOADS_TMP_DIR, 0755, true);
    $token = bin2hex(random_bytes(16));
    $tmpPath = CONTACT_UPLOADS_TMP_DIR . '/' . $token . '.csv';
    if (!move_uploaded_file($file['tmp_name'], $tmpPath)) api_error('Could not stage the uploaded file');

    $fh = fopen($tmpPath, 'r');
    if (!$fh) api_error('Could not read the uploaded file');
    $headers = fgetcsv($fh);
    if (!$headers) { fclose($fh); @unlink($tmpPath); api_error('The file appears to be empty'); }
    $sampleRow = fgetcsv($fh);

    $totalRows = 0;
    if ($sampleRow) {
        $totalRows = 1;
        while (fgetcsv($fh) !== false) $totalRows++;
    }
    fclose($fh);

    if ($totalRows > CONTACT_UPLOAD_MAX_ROWS) {
        @unlink($tmpPath);
        api_error('Too many rows (' . number_format($totalRows) . ') — max ' . number_format(CONTACT_UPLOAD_MAX_ROWS) . ' per file. Please split the file.');
    }

    $suggested = csv_suggest_mapping($headers);
    $sample = [];
    if ($sampleRow) foreach ($headers as $i => $h) $sample[$h] = $sampleRow[$i] ?? '';

    api_success([
        'token' => $token,
        'headers' => array_values($headers),
        'suggested_mapping' => $suggested,
        'sample_row' => $sample,
        'total_rows' => $totalRows,
        'original_filename' => $file['name'],
    ]);
}

if ($action === 'start_import') {
    $listId = (int)jin('list_id', 0);
    $token  = trim((string)jin('token', ''));
    $mapping = json_decode((string)jin('mapping', '{}'), true) ?: [];
    $defaults = json_decode((string)jin('default_values', '{}'), true) ?: [];
    $originalFilename = trim((string)jin('original_filename', 'contacts.csv'));
    $totalRows = (int)jin('total_rows', 0);
    if (!$listId) api_error('list_id required');
    if (!preg_match('/^[a-f0-9]{32}$/', $token)) api_error('Invalid or expired upload token');
    if (!in_array('email', $mapping, true)) api_error('You must map one column to Email before importing');

    $tmpPath = CONTACT_UPLOADS_TMP_DIR . '/' . $token . '.csv';
    if (!is_file($tmpPath)) api_error('Upload session expired — please choose the file again');

    if (!is_dir(CONTACT_UPLOADS_DIR)) mkdir(CONTACT_UPLOADS_DIR, 0755, true);

    $mappingE = $conn->real_escape_string(json_encode(['mapping' => $mapping, 'defaults' => $defaults]));
    $nameE = $conn->real_escape_string($originalFilename);
    $conn->query("INSERT INTO campaign_contact_uploads
        (list_id, original_filename, stored_path, column_mapping, status, total_rows, uploaded_by)
        VALUES ($listId, '$nameE', '', '$mappingE', 'pending', $totalRows, " . (int)($jwt['user_id'] ?? 0) . ")");
    $uploadId = $conn->insert_id;

    $finalPath = CONTACT_UPLOADS_DIR . '/' . $uploadId . '.csv';
    if (!rename($tmpPath, $finalPath)) {
        $conn->query("DELETE FROM campaign_contact_uploads WHERE id=$uploadId");
        api_error('Could not finalize the uploaded file');
    }
    $pathE = $conn->real_escape_string($finalPath);
    $conn->query("UPDATE campaign_contact_uploads SET stored_path='$pathE' WHERE id=$uploadId");

    contact_import_trigger_worker_async($uploadId);
    api_success(['upload_id' => $uploadId, 'status' => 'pending']);
}

if ($action === 'logs') {
    $page    = max(1, (int)jin('page', 1));
    $perPage = max(1, min(100, (int)jin('per_page', 10)));
    $search  = trim((string)jin('search', ''));
    $status  = jin('status', '');
    $offset  = ($page - 1) * $perPage;

    $listId  = (int)jin('list_id', 0);

    $where = [];
    if ($search !== '') $where[] = "u.original_filename LIKE '%" . $conn->real_escape_string($search) . "%'";
    if ($status !== '' && $status !== 'all') $where[] = "u.status='" . $conn->real_escape_string($status) . "'";
    if ($listId) $where[] = "u.list_id=$listId";
    $whereSql = $where ? 'WHERE ' . implode(' AND ', $where) : '';

    $tr = $conn->query("SELECT COUNT(*) AS c FROM campaign_contact_uploads u $whereSql");
    $total = $tr ? (int)$tr->fetch_assoc()['c'] : 0;

    $r = $conn->query("SELECT u.id, u.original_filename, u.status, u.total_rows, u.processed_rows,
                               u.success_count, u.failed_count, l.name AS list_name, u.s3_url,
                               u.created_at, u.started_at, u.completed_at
                        FROM campaign_contact_uploads u
                        LEFT JOIN campaign_lists l ON l.id = u.list_id
                        $whereSql
                        ORDER BY u.id DESC LIMIT $perPage OFFSET $offset");
    $rows = [];
    while ($r && $row = $r->fetch_assoc()) {
        $row['percent'] = $row['total_rows'] > 0 ? (int)round(($row['processed_rows'] / $row['total_rows']) * 100) : ($row['status'] === 'processed' ? 100 : 0);
        $rows[] = $row;
    }

    api_success([
        'uploads' => $rows, 'total' => $total, 'page' => $page, 'per_page' => $perPage,
        'pages' => $total > 0 ? (int)ceil($total / $perPage) : 1,
    ]);
}

if ($action === 'status') {
    $id = (int)jin('id', 0);
    $r = $conn->query("SELECT id, list_id, original_filename, status, total_rows, processed_rows, success_count, failed_count,
                               created_at, started_at, completed_at
                        FROM campaign_contact_uploads WHERE id=$id LIMIT 1");
    $row = $r ? $r->fetch_assoc() : null;
    if (!$row) api_error('Not found', 404);
    $row['percent'] = $row['total_rows'] > 0 ? (int)round(($row['processed_rows'] / $row['total_rows']) * 100) : ($row['status'] === 'processed' ? 100 : 0);
    api_success(['upload' => $row]);
}

if ($action === 'failures') {
    $id      = (int)jin('id', 0);
    $page    = max(1, (int)jin('page', 1));
    $perPage = max(1, min(200, (int)jin('per_page', 25)));
    $offset  = ($page - 1) * $perPage;

    $tr = $conn->query("SELECT COUNT(*) AS c FROM campaign_contact_upload_errors WHERE upload_id=$id");
    $total = $tr ? (int)$tr->fetch_assoc()['c'] : 0;

    $r = $conn->query("SELECT row_number, email, error_message, raw_row, created_at
                        FROM campaign_contact_upload_errors WHERE upload_id=$id
                        ORDER BY row_number ASC LIMIT $perPage OFFSET $offset");
    $rows = [];
    while ($r && $row = $r->fetch_assoc()) { $row['raw_row'] = json_decode($row['raw_row'] ?? '[]', true) ?: []; $rows[] = $row; }

    api_success([
        'failures' => $rows, 'total' => $total, 'page' => $page, 'per_page' => $perPage,
        'pages' => $total > 0 ? (int)ceil($total / $perPage) : 1,
    ]);
}

if ($action === 'download_failures') {
    $id = (int)jin('id', 0);
    $r = $conn->query("SELECT original_filename FROM campaign_contact_uploads WHERE id=$id LIMIT 1");
    $row = $r ? $r->fetch_assoc() : null;
    if (!$row) api_error('Not found', 404);

    $filename = 'failures_' . preg_replace('/[^a-zA-Z0-9_]+/', '_', $row['original_filename']) . '.csv';
    header('Content-Type: text/csv; charset=utf-8');
    header("Content-Disposition: attachment; filename=\"$filename\"");
    $out = fopen('php://output', 'w');
    fputcsv($out, ['row_number', 'email', 'error_message']);
    $q = $conn->query("SELECT row_number, email, error_message FROM campaign_contact_upload_errors WHERE upload_id=$id ORDER BY row_number ASC");
    while ($q && $row = $q->fetch_assoc()) fputcsv($out, $row);
    fclose($out);
    exit;
}

api_error('Invalid action');

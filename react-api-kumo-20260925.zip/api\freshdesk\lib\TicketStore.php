<?php
/*
 * /api/freshdesk/lib/TicketStore.php
 *
 * The write side of the helpdesk: turn a parsed email into a ticket + message +
 * attachments + contact, keep the denormalised counters honest, and decide
 * which existing conversation an incoming mail belongs to.
 *
 * Everything that mutates a ticket goes through here so the counters, the SLA
 * clocks and the realtime events can never drift apart from the rows.
 */

/* ============================================================== threading == */

/**
 * Find the ticket an inbound message belongs to, in strict order of certainty.
 * Returns a ticket id, or null when this should start a new conversation.
 *
 *   1. The [#IS-nnnnnn] token we put in our own outgoing Subject.
 *      Most reliable by far -- clients rewrite almost everything else but keep
 *      the subject text the human sees.
 *   2. In-Reply-To / References pointing at a Message-ID we have stored.
 *      Correct per RFC, but Outlook drops these on "Reply" from some mobile
 *      builds and mailing lists rewrite them, hence it is not first.
 *   3. Same sender + same normalised subject within a recent window.
 *      A heuristic, and deliberately the last resort: it is what catches the
 *      customer who replies by composing a fresh mail with the same subject.
 *
 * Each rule is bounded so a stale/closed conversation from months ago cannot
 * swallow a genuinely new request -- reopening a 6-month-old ticket because the
 * subject happened to match is worse than opening a duplicate.
 */
function fd_resolve_ticket($parsed)
{
    // ---- 1. subject token -------------------------------------------------
    $tokenId = fd_parse_ticket_token($parsed['subject']);
    if ($tokenId) {
        $t = fd_query_one("SELECT id, merged_into FROM fd_tickets WHERE id = ?", 'i', array($tokenId));
        if ($t) {
            $id = !empty($t['merged_into']) ? (int)$t['merged_into'] : (int)$t['id'];
            fd_log('debug', 'Threaded by subject token', array('ticket' => $id));
            return $id;
        }
        // Token names a ticket we do not have (mail forwarded in from another
        // desk, or the row was purged). Fall through rather than inventing it.
    }

    // ---- 2. In-Reply-To / References --------------------------------------
    $ids = array();
    if (!empty($parsed['in_reply_to'])) $ids[] = $parsed['in_reply_to'];
    if (!empty($parsed['references']))  $ids = array_merge($ids, $parsed['references']);
    // Newest reference first: References is ordered oldest -> newest, and the
    // last entry is the direct parent.
    $ids = array_values(array_unique(array_reverse($ids)));
    if (!empty($ids)) {
        $slice = array_slice($ids, 0, 20);   // bound the IN() list
        $place = implode(',', array_fill(0, count($slice), '?'));
        $rows = fd_query(
            "SELECT m.ticket_id FROM fd_messages m WHERE m.message_id IN ($place) ORDER BY m.id DESC LIMIT 1",
            str_repeat('s', count($slice)), $slice
        );
        if (!empty($rows)) {
            $tid = (int)$rows[0]['ticket_id'];
            $t = fd_query_one("SELECT id, merged_into FROM fd_tickets WHERE id = ?", 'i', array($tid));
            if ($t) {
                $id = !empty($t['merged_into']) ? (int)$t['merged_into'] : (int)$t['id'];
                fd_log('debug', 'Threaded by References', array('ticket' => $id));
                return $id;
            }
        }
    }

    // ---- 3. same sender + subject, recent ---------------------------------
    $email = fd_norm_email($parsed['from_email']);
    $base  = fd_normalize_subject($parsed['subject']);
    if ($email !== '' && $base !== '') {
        $key = fd_thread_key($email, $base);

        /*
         * 30 days EITHER SIDE OF THIS MESSAGE'S OWN DATE, and never a ticket
         * that was already closed -- a closed conversation with a recycled
         * subject is a new request.
         *
         * The window used to be anchored on NOW(), which is the same thing for
         * live mail (a message arriving now IS now) but is badly wrong for
         * backfilled history: a 2025 email whose sender and subject happen to
         * match a ticket that is active TODAY satisfied "within the last 30
         * days" and was filed into it -- dropping a two-year-old message into a
         * live conversation and, via fd_touch_ticket_archived(), dragging that
         * ticket's created_at back two years with it.
         *
         * Anchoring on the message instead makes the rule mean what it always
         * read as: "the same person wrote about the same thing at around the
         * same time". The upper bound changes nothing for live mail, because no
         * ticket has activity 30 days in the future.
         */
        $when = !empty($parsed['date']) ? $parsed['date'] : date('Y-m-d H:i:s');
        $row = fd_query_one(
            "SELECT id, merged_into FROM fd_tickets
             WHERE thread_key = ? AND is_trash = 0
               AND status NOT IN ('Closed')
               AND last_message_at >= DATE_SUB(?, INTERVAL 30 DAY)
               AND last_message_at <= DATE_ADD(?, INTERVAL 30 DAY)
             ORDER BY last_message_at DESC LIMIT 1",
            'sss', array($key, $when, $when)
        );
        if ($row) {
            $id = !empty($row['merged_into']) ? (int)$row['merged_into'] : (int)$row['id'];
            fd_log('debug', 'Threaded by sender+subject', array('ticket' => $id));
            return $id;
        }
    }

    return null;
}

function fd_thread_key($email, $baseSubject)
{
    return substr(md5(strtolower(trim($email)) . '|' . strtolower(trim($baseSubject))), 0, 40);
}

/* ================================================================ contacts == */

/**
 * Create or refresh the contact behind an email address, and link it to the
 * platform user account when one exists.
 *
 * The link is what makes the ticket sidebar show a real student -- enrollment,
 * program, phone -- instead of just an address. It is best-effort: the users
 * table lives in the same database but the columns have varied over time, so a
 * failure here degrades to "unregistered contact" rather than breaking mail
 * ingestion.
 */
function fd_contact_upsert($email, $name = '', $phone = null)
{
    $email = fd_norm_email($email);
    if ($email === '' || strpos($email, '@') === false) return null;
    $name = fd_display_name($name, $email);

    $existing = fd_query_one("SELECT id, name, user_id FROM fd_contacts WHERE email = ?", 's', array($email));

    if ($existing) {
        // Only fill blanks -- never let a later mail with a worse display name
        // ("info", "no-reply") overwrite a good one.
        $sets = array('last_seen_at = NOW()');
        $types = ''; $params = array();
        if ((empty($existing['name']) || $existing['name'] === $email) && $name !== '' && $name !== $email) {
            $sets[] = 'name = ?'; $types .= 's'; $params[] = $name;
        }
        if ($phone) { $sets[] = 'phone = COALESCE(NULLIF(phone,""), ?)'; $types .= 's'; $params[] = $phone; }
        $params[] = (int)$existing['id']; $types .= 'i';
        fd_exec("UPDATE fd_contacts SET " . implode(', ', $sets) . " WHERE id = ?", $types, $params);
        $contactId = (int)$existing['id'];
    } else {
        $contactId = fd_exec(
            "INSERT INTO fd_contacts (email, name, phone, first_seen_at, last_seen_at)
             VALUES (?,?,?,NOW(),NOW())",
            'sss', array($email, $name, $phone), true
        );
    }

    if ($contactId && empty($existing['user_id'])) {
        fd_contact_link_student($contactId, $email);
    }
    return $contactId;
}

/** Best-effort lookup of the platform account for a contact. Never throws. */
function fd_contact_link_student($contactId, $email)
{
    global $conn;
    try {
        $stmt = @$conn->prepare("SELECT user_id, name, mobile FROM users WHERE email = ? LIMIT 1");
        if (!$stmt) {
            // Column set differs on this install -- try the minimal shape.
            $stmt = @$conn->prepare("SELECT user_id, name FROM users WHERE email = ? LIMIT 1");
            if (!$stmt) return;
        }
        $stmt->bind_param('s', $email);
        if (!$stmt->execute()) { $stmt->close(); return; }
        $row = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        if (!$row) return;

        fd_exec("UPDATE fd_contacts
                 SET user_id = ?, is_registered = 1,
                     name  = COALESCE(NULLIF(name,''), ?),
                     phone = COALESCE(NULLIF(phone,''), ?)
                 WHERE id = ?",
            'issi',
            array((int)$row['user_id'], isset($row['name']) ? $row['name'] : null,
                  isset($row['mobile']) ? $row['mobile'] : null, (int)$contactId)
        );
    } catch (Throwable $e) {
        fd_log('debug', 'Student link skipped: ' . $e->getMessage(), array('email' => $email));
    }
}

/* ================================================================= tickets == */

/** Keyword routing so a new ticket lands in a sensible bucket instead of "General". */
function fd_guess_category($subject, $bodyText)
{
    $hay = strtolower($subject . ' ' . fd_snippet($bodyText, 600));
    $rules = array(
        'Billing'        => array('refund', 'payment', 'invoice', 'gst', 'charged', 'transaction', 'razorpay', 'cashfree', 'money', 'fees', 'paid'),
        'Certificate'    => array('certificate', 'certification', 'letter of completion', 'lor', 'marksheet'),
        'Attendance'     => array('attendance', 'present', 'absent', 'mark not reflect'),
        'Account Access' => array('login', 'log in', 'password', 'otp', 'sign in', 'locked', 'access denied', 'cannot access'),
        'Placement'      => array('placement', 'offer letter', 'interview', 'job', 'hiring', 'resume'),
        'Internship'     => array('internship', 'start date', 'batch', 'enrol', 'enroll', 'joining', 'domain'),
        'Technical'      => array('error', 'not loading', 'not working', 'bug', 'crash', 'video', 'dashboard', 'portal issue', 'blank screen'),
    );
    foreach ($rules as $cat => $words) {
        foreach ($words as $w) {
            if (strpos($hay, $w) !== false) return $cat;
        }
    }
    return 'General';
}

/** Urgency hints -- deliberately conservative; agents re-prioritise anyway. */
function fd_guess_priority($subject, $bodyText)
{
    $hay = strtolower($subject . ' ' . fd_snippet($bodyText, 400));
    foreach (array('urgent', 'asap', 'immediately', 'emergency', 'critical', 'escalat') as $w) {
        if (strpos($hay, $w) !== false) return 'High';
    }
    foreach (array('refund', 'payment failed', 'money deducted', 'not received', 'fraud') as $w) {
        if (strpos($hay, $w) !== false) return 'High';
    }
    return 'Medium';
}

/**
 * Create a ticket. Used by inbound sync and by "New Ticket" in the panel.
 */
function fd_create_ticket($fields)
{
    $subject   = isset($fields['subject']) && trim($fields['subject']) !== '' ? $fields['subject'] : '(no subject)';
    $base      = fd_normalize_subject($subject);
    $email     = fd_norm_email(isset($fields['requester_email']) ? $fields['requester_email'] : '');
    $name      = fd_display_name(isset($fields['requester_name']) ? $fields['requester_name'] : '', $email);
    $priority  = isset($fields['priority']) ? $fields['priority'] : 'Medium';
    $source    = isset($fields['source']) ? $fields['source'] : 'Email';
    $status    = isset($fields['status']) ? $fields['status'] : 'New';
    $category  = isset($fields['category']) ? $fields['category'] : null;
    $createdAt = isset($fields['created_at']) ? $fields['created_at'] : date('Y-m-d H:i:s');

    $contactId = fd_contact_upsert($email, $name, isset($fields['requester_phone']) ? $fields['requester_phone'] : null);
    $contact   = $contactId ? fd_query_one("SELECT * FROM fd_contacts WHERE id = ?", 'i', array($contactId)) : null;
    if ($contact && !empty($contact['phone']) && empty($fields['requester_phone'])) {
        $fields['requester_phone'] = $contact['phone'];
    }

    $due = fd_sla_due_dates($createdAt, $priority);

    $ticketId = fd_exec(
        "INSERT INTO fd_tickets
            (subject, base_subject, requester_name, requester_email, requester_phone, contact_id,
             status, priority, source, category, department, agent_name, tags,
             raised_by_agent, response_status, first_response_due, resolution_due,
             thread_key, last_message_at, created_at, updated_at)
         VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,NOW())",
        'sssssisssssssissssss',
        array(
            fd_snippet($subject, 490), fd_snippet($base, 490), $name, $email,
            isset($fields['requester_phone']) ? $fields['requester_phone'] : null,
            $contactId,
            $status, $priority, $source, $category,
            isset($fields['department']) ? $fields['department'] : null,
            isset($fields['agent_name']) ? $fields['agent_name'] : 'Unassigned',
            isset($fields['tags']) ? json_encode(array_values((array)$fields['tags'])) : '[]',
            !empty($fields['raised_by_agent']) ? 1 : 0,
            'Awaiting reply',
            $due['first_response_due'], $due['resolution_due'],
            fd_thread_key($email, $base),
            $createdAt, $createdAt
        ),
        true
    );

    if ($contactId) {
        fd_exec("UPDATE fd_contacts SET tickets_count = tickets_count + 1 WHERE id = ?", 'i', array($contactId));
    }
    return (int)$ticketId;
}

/* ================================================================ messages == */

/**
 * Persist one parsed inbound email.
 *
 * Returns ['ticket_id','message_id','is_new_ticket','duplicate'].
 * `duplicate` is the normal, expected outcome for any message we have seen
 * before -- it is not an error and must not be logged as one, because a
 * re-synced mailbox produces thousands of them.
 */
function fd_store_inbound($parsed, $meta = array())
{
    global $conn;

    /*
     * ARCHIVE MODE -- set by the backfill worker (fd_backfill.php), never by the
     * live sync.
     *
     * Importing two years of old mail through the normal path would be a
     * disaster in four separate ways, so every one of them is disarmed here:
     *
     *   - a new ticket opens Closed, not New, so 20,000 conversations that were
     *     settled years ago do not land in today's unresolved queue;
     *   - resolved_at/closed_at are stamped at the message's own date, which is
     *     what makes fd_sla_evaluate() report them On track instead of painting
     *     the dashboard red with SLAs that never existed;
     *   - an existing ticket is NOT reopened and its unread count is NOT bumped
     *     (see fd_touch_ticket_archived below);
     *   - last_message_at keeps the real date instead of NOW(), so the desk does
     *     not claim a 2024 email arrived this afternoon.
     *
     * The caller is separately responsible for not running automations, not
     * publishing realtime events and never sending an auto-acknowledgement --
     * mailing a customer about a thread from 2024 is the one mistake here that
     * cannot be undone.
     */
    $archive      = !empty($meta['archive']);

    $messageIdHdr = isset($parsed['message_id']) ? trim($parsed['message_id']) : '';
    $mailbox      = isset($meta['mailbox']) ? $meta['mailbox'] : (string)fd_cfg('IMAP_FOLDER', 'INBOX');
    $uid          = isset($meta['uid']) ? (int)$meta['uid'] : 0;
    $uidvalidity  = isset($meta['uidvalidity']) ? (int)$meta['uidvalidity'] : 0;
    $uidKey       = $uid ? ($mailbox . ':' . $uidvalidity . ':' . $uid) : null;

    // ---- duplicate gate ---------------------------------------------------
    // Checked explicitly (not just relied on via the unique index) so the
    // caller learns it was a duplicate without having to interpret a
    // constraint-violation error code.
    if ($messageIdHdr !== '') {
        $dup = fd_query_one("SELECT id, ticket_id FROM fd_messages WHERE message_id = ?", 's', array($messageIdHdr));
        if ($dup) {
            return array('ticket_id' => (int)$dup['ticket_id'], 'message_id' => (int)$dup['id'],
                         'is_new_ticket' => false, 'duplicate' => true);
        }
    }
    if ($uidKey) {
        $dup = fd_query_one("SELECT id, ticket_id FROM fd_messages WHERE uid_key = ?", 's', array($uidKey));
        if ($dup) {
            return array('ticket_id' => (int)$dup['ticket_id'], 'message_id' => (int)$dup['id'],
                         'is_new_ticket' => false, 'duplicate' => true);
        }
    }

    /*
     * Ignore our own outgoing copies.
     *
     * The mailbox is shared with humans, and a reply sent from Roundcube (or
     * APPENDed by us into Sent, on servers that also drop a copy into INBOX)
     * comes back as an inbound message from contact@internshipstudio.com. Left
     * unchecked, the desk answers itself and every thread doubles.
     */
    if (fd_is_own_address($parsed['from_email']) && empty($meta['allow_own'])) {
        return array('ticket_id' => 0, 'message_id' => 0, 'is_new_ticket' => false,
                     'duplicate' => true, 'reason' => 'own-copy');
    }

    $bodyText = isset($parsed['body_text']) ? $parsed['body_text'] : '';
    $bodyHtml = isset($parsed['body_html']) ? $parsed['body_html'] : '';
    $visible  = fd_strip_quoted_text($bodyText);

    $isBounce    = !empty($parsed['is_bounce']);
    $isAutoReply = !empty($parsed['is_auto_reply']);

    $ticketId = fd_resolve_ticket($parsed);
    $isNew    = false;

    if (!$ticketId) {
        /*
         * ORPHAN MACHINE MAIL IS NOT A TICKET.
         *
         * This check has to happen BEFORE the ticket is created, and for a
         * while it did not -- the code created the ticket first and only then
         * looked at is_bounce, so every "Warning: message ... delayed 72 hours"
         * from Mail Delivery System opened its own ticket. On a mailbox that
         * has been running for years that is hundreds of them, which is exactly
         * why this desk showed ~850 unresolved while the mailbox itself had a
         * handful of real conversations outstanding.
         *
         * A bounce that DOES thread onto an existing ticket is still ingested
         * below -- that is genuinely useful ("the reply you sent did not
         * arrive"). It is only the orphans, which refer to a conversation this
         * desk never had, that are dropped.
         *
         * Same treatment for an orphan auto-responder: an out-of-office replying
         * to a thread we do not have is noise, not a support request.
         */
        if ($isBounce) {
            /*
             * READ IT FOR THE DEAD ADDRESS FIRST, then drop it as before.
             *
             * This message is about to be discarded, and it is the only place the mail system tells
             * us an address does not exist — "550-5.1.1 The email account that you tried to reach
             * does not exist". That is worth strictly more than the message itself: it is what keeps
             * a mistyped registration address out of every future campaign and journey. The desk's
             * own behaviour is unchanged; nothing is imported and no ticket is created.
             *
             * file_exists because these two trees deploy separately, and a require of a file that
             * is not there yet would take the whole mailbox sync down with it.
             */
            $bouncer = __DIR__ . '/../../campaigns/lib/BounceMailbox.php';
            if (file_exists($bouncer)) {
                try {
                    require_once $bouncer;
                    $seen = bounce_process_report($bodyText !== '' ? $bodyText : strip_tags($bodyHtml),
                                                  isset($parsed['message_date']) ? $parsed['message_date'] : null);
                    if (!empty($seen['blocklisted'])) {
                        fd_log('info', 'Bounce blocklisted a dead address', array(
                            'addresses' => $seen['addresses'], 'blocklisted' => $seen['blocklisted'],
                        ));
                    }
                } catch (Throwable $e) {
                    fd_log('warn', 'Bounce not processed: ' . $e->getMessage(), array());
                }
            }
            fd_log('info', 'Orphan bounce ignored (no matching ticket)', array(
                'from' => $parsed['from_email'], 'subject' => fd_snippet($parsed['subject'], 120),
            ));
            return array('ticket_id' => 0, 'message_id' => 0, 'is_new_ticket' => false,
                         'duplicate' => false, 'skipped' => 'orphan-bounce');
        }
        if ($isAutoReply && fd_cfg_int('SKIP_ORPHAN_AUTOREPLIES', 1)) {
            fd_log('info', 'Orphan auto-reply ignored (no matching ticket)', array(
                'from' => $parsed['from_email'], 'subject' => fd_snippet($parsed['subject'], 120),
            ));
            return array('ticket_id' => 0, 'message_id' => 0, 'is_new_ticket' => false,
                         'duplicate' => false, 'skipped' => 'orphan-auto-reply');
        }

        $msgDate = !empty($parsed['date']) ? $parsed['date'] : date('Y-m-d H:i:s');

        $ticketId = fd_create_ticket(array(
            'subject'         => $parsed['subject'],
            'requester_email' => $parsed['from_email'],
            'requester_name'  => $parsed['from_name'],
            'priority'        => fd_guess_priority($parsed['subject'], $visible),
            'category'        => fd_guess_category($parsed['subject'], $visible),
            'source'          => 'Email',
            'status'          => $archive ? 'Closed' : 'New',
            'created_at'      => $msgDate,
        ));
        $isNew = true;

        if ($archive && $ticketId) {
            // Closed AT ITS OWN DATE. fd_sla_evaluate() reads resolved_at, so
            // this is what makes a 2024 ticket report "On track" rather than
            // breaching an SLA clock that was never running.
            fd_exec(
                "UPDATE fd_tickets
                 SET is_archived = 1, resolved_at = ?, closed_at = ?,
                     response_status = 'Archived', updated_at = ?
                 WHERE id = ?",
                'sssi', array($msgDate, $msgDate, $msgDate, (int)$ticketId)
            );
        }
    }

    /*
     * The SELECTs above are an optimisation, not the guarantee. Two sync runs
     * (cron tick + an agent pressing Refresh) can both pass them for the same
     * UID and race to INSERT. The UNIQUE indexes on message_id/uid_key are what
     * actually decides, and the loser lands here as error 1062 -- a correct,
     * expected outcome, so it is swallowed quietly rather than logged as a
     * failure or surfaced to the agent.
     */
    try {
        $msgId = fd_exec(
            "INSERT INTO fd_messages
                (ticket_id, direction, msg_type, from_name, from_email, to_emails, cc_emails, subject,
                 body_html, body_text, snippet, message_id, in_reply_to, references_hdr,
                 mailbox, imap_uid, imap_uidvalidity, uid_key, has_attachments, attachment_count,
                 delivery_status, message_date, raw_size, is_auto_reply, is_backfilled, created_at)
             VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?, 'received', ?,?,?,?, NOW())",
            'issssssssssssssiisiisiii',
            array(
                $ticketId,
                'inbound',
                $isBounce ? 'bounce' : 'reply',
                $parsed['from_name'], $parsed['from_email'],
                json_encode($parsed['to']), json_encode($parsed['cc']),
                fd_snippet($parsed['subject'], 490),
                fd_sanitize_html($bodyHtml), $bodyText, fd_snippet($visible, 250),
                $messageIdHdr !== '' ? $messageIdHdr : null,
                !empty($parsed['in_reply_to']) ? $parsed['in_reply_to'] : null,
                !empty($parsed['references']) ? implode(' ', $parsed['references']) : null,
                $mailbox, $uid ?: null, $uidvalidity ?: null, $uidKey,
                !empty($parsed['attachments']) ? 1 : 0, count($parsed['attachments']),
                !empty($parsed['date']) ? $parsed['date'] : date('Y-m-d H:i:s'),
                isset($meta['size']) ? (int)$meta['size'] : 0,
                !empty($parsed['is_auto_reply']) ? 1 : 0,
                $archive ? 1 : 0,
            ),
            true
        );
    } catch (Throwable $e) {
        if ((int)$conn->errno === 1062) {
            $dup = fd_query_one("SELECT id, ticket_id FROM fd_messages WHERE message_id = ? OR uid_key = ? LIMIT 1",
                                'ss', array($messageIdHdr !== '' ? $messageIdHdr : '~none~', $uidKey !== null ? $uidKey : '~none~'));
            // We lost the race AND had already opened a ticket for this mail --
            // the winner opened its own. Drop ours instead of leaving an empty
            // ticket in the queue for an agent to puzzle over.
            if ($isNew && $ticketId && (!$dup || (int)$dup['ticket_id'] !== (int)$ticketId)) {
                try { fd_exec("DELETE FROM fd_tickets WHERE id = ? AND message_count = 0", 'i', array((int)$ticketId)); } catch (Throwable $e2) {}
            }
            return array(
                'ticket_id'     => $dup ? (int)$dup['ticket_id'] : (int)$ticketId,
                'message_id'    => $dup ? (int)$dup['id'] : 0,
                'is_new_ticket' => false,
                'duplicate'     => true,
            );
        }
        throw $e;
    }

    if (!$msgId) {
        throw new Exception('Message insert returned no id.');
    }

    $saved = fd_store_attachments($ticketId, (int)$msgId, $parsed['attachments'], 'inbound');

    // Rewrite cid: references in the stored HTML to point at our own attachment
    // endpoint, so inline screenshots actually render in the panel instead of
    // showing a broken image icon.
    if (!empty($saved['cid_map'])) {
        fd_rewrite_inline_cids((int)$msgId, $saved['cid_map']);
    }

    if ($archive) {
        fd_touch_ticket_archived($ticketId, !empty($parsed['date']) ? $parsed['date'] : null);
    } else {
        fd_touch_ticket_inbound($ticketId, $isBounce, $isAutoReply);
    }
    fd_recount_ticket($ticketId);
    fd_sla_refresh($ticketId);

    return array('ticket_id' => (int)$ticketId, 'message_id' => (int)$msgId,
                 'is_new_ticket' => $isNew, 'duplicate' => false, 'is_bounce' => $isBounce);
}

/**
 * The archive-mode counterpart of fd_touch_ticket_inbound().
 *
 * Deliberately does almost nothing. A backfilled message is history: it must
 * not reopen the ticket, must not mark it unread, and must not claim to be the
 * latest activity.
 *
 * The one thing it DOES do is widen the ticket's date range. The backfill walks
 * newest to oldest, so a thread's later messages are stored first and the
 * ticket is created carrying the wrong (later) date; each older message then
 * pulls created_at back with LEAST. That is what makes "the oldest email we
 * hold" a true statement once the run finishes.
 */
function fd_touch_ticket_archived($ticketId, $messageDate)
{
    $ticketId = (int)$ticketId;
    if (!$messageDate) return;

    fd_exec(
        "UPDATE fd_tickets
         SET created_at      = LEAST(created_at, ?),
             last_message_at = GREATEST(COALESCE(last_message_at, ?), ?),
             last_customer_at= GREATEST(COALESCE(last_customer_at, ?), ?)
         WHERE id = ?",
        'sssssi', array($messageDate, $messageDate, $messageDate, $messageDate, $messageDate, $ticketId)
    );
}

/**
 * Move a ticket's state on after an inbound message.
 *
 * A REAL customer reply reopens a Resolved/Closed ticket -- the customer is
 * telling us it was not actually fixed, and leaving it closed is how those get
 * lost.
 *
 * MACHINE MAIL DOES NOT. A delivery bounce, a "message delayed 24 hours"
 * warning or an out-of-office is not the customer saying anything, and
 * reopening on one is the single biggest reason closed tickets would not stay
 * closed here: an agent answers, closes, and the reply bounces or trips an
 * auto-responder seconds later. That bounce threads onto the ticket by
 * References and, until this distinction existed, dragged it straight back into
 * the queue. On this mailbox, where roughly seven messages in ten are
 * mailer-daemon, that turned into a queue that could not be emptied.
 *
 * The machine message is still stored and still shown in the thread -- "the
 * reply you sent did not arrive" is worth knowing -- and a bounce still raises
 * is_undelivered and the unread badge so it is noticed. What it no longer does
 * is change the status or clear the resolved/closed stamps.
 */
function fd_touch_ticket_inbound($ticketId, $isBounce = false, $isAutoReply = false)
{
    $t = fd_query_one("SELECT status, first_response_at FROM fd_tickets WHERE id = ?", 'i', array((int)$ticketId));
    if (!$t) return;

    $machine  = $isBounce || $isAutoReply;
    $finished = in_array($t['status'], array('Resolved', 'Closed'), true);

    /*
     * Machine mail on a finished ticket: touch the timestamps and the delivery
     * flags, leave the state alone. resolved_at/closed_at are deliberately NOT
     * cleared -- they are what fd_sla_evaluate() reads, and clearing them
     * restarts an SLA clock on a conversation that is over.
     */
    if ($machine && $finished) {
        fd_exec(
            "UPDATE fd_tickets
             SET last_message_at = NOW(),
                 unread_count = unread_count + CASE WHEN ? = 1 THEN 1 ELSE 0 END,
                 is_undelivered = CASE WHEN ? = 1 THEN 1 ELSE is_undelivered END,
                 updated_at = NOW()
             WHERE id = ?",
            'iii', array($isBounce ? 1 : 0, $isBounce ? 1 : 0, (int)$ticketId)
        );
        return;
    }

    $status = $t['status'];
    if ($finished)                                            $status = 'Open';
    elseif ($status === 'Pending' || $status === 'Waiting')   $status = 'Open';

    /*
     * "Customer replied" is a claim about a human. A bounce or an auto-reply on
     * an open ticket still moves it along, but saying the customer replied
     * sends agents to a thread whose newest message is a robot.
     */
    $responseStatus  = $machine ? 'Awaiting reply' : 'Customer replied';
    $customerReplied = $machine ? 0 : 1;

    fd_exec(
        "UPDATE fd_tickets
         SET status = ?, response_status = ?, customer_replied = ?,
             unread_count = unread_count + 1,
             last_message_at = NOW(),
             last_customer_at = CASE WHEN ? = 1 THEN last_customer_at ELSE NOW() END,
             is_undelivered = CASE WHEN ? = 1 THEN 1 ELSE is_undelivered END,
             resolved_at = NULL, closed_at = NULL,
             updated_at = NOW()
         WHERE id = ?",
        'ssiiii', array($status, $responseStatus, $customerReplied,
                        $machine ? 1 : 0, $isBounce ? 1 : 0, (int)$ticketId)
    );
}

/** Recompute the denormalised counters from the messages themselves. */
function fd_recount_ticket($ticketId)
{
    $ticketId = (int)$ticketId;
    fd_exec(
        "UPDATE fd_tickets t SET
            message_count = (SELECT COUNT(*) FROM fd_messages m WHERE m.ticket_id = t.id),
            attachment_count = (SELECT COUNT(*) FROM fd_attachments a WHERE a.ticket_id = t.id AND a.is_inline = 0)
         WHERE t.id = ?",
        'i', array($ticketId)
    );
}

/**
 * Un-hide attachments the old parser filed as inline.
 *
 * Until MimeParser learned that the Content-Disposition decides, any part with
 * a Content-ID was stored with is_inline = 1 -- and Gmail and Outlook put a
 * Content-ID on every attachment, not only on embedded images. Those files
 * were saved and are in S3, but the reader filters the file strip on !inline
 * and attachment_count only counts is_inline = 0, so the agent saw nothing.
 * The worker box kept running that parser after the fix shipped to the web
 * servers, so the mail it imported in that window is affected too.
 *
 * The rule is reconcileInline()'s, applied to stored rows: a part is inline
 * only if its message's HTML actually shows it. After fd_rewrite_inline_cids()
 * the stored HTML may name it either way -- cid:<id> or our own
 * fd_attachments.php?action=view&id=N -- so both are checked, or every
 * genuinely embedded image would be pushed into the file strip as well.
 *
 * One-way (inline -> attachment only), idempotent, and keyset-paged by id so a
 * large table is walked in bounded batches. Dry run unless told otherwise.
 */
function fd_repair_hidden_attachments($afterId = 0, $limit = 500, $dryRun = true)
{
    $limit = max(1, min(2000, (int)$limit));
    $rows = fd_query(
        "SELECT a.id, a.ticket_id, a.content_id, m.body_html
         FROM fd_attachments a
         LEFT JOIN fd_messages m ON m.id = a.message_id
         WHERE a.is_inline = 1 AND a.id > ?
         ORDER BY a.id ASC LIMIT $limit",
        'i', array((int)$afterId)
    );

    $out = array('scanned' => 0, 'unhidden' => 0, 'kept_inline' => 0, 'tickets' => 0,
                 'next_after' => (int)$afterId, 'done' => false, 'dry_run' => (bool)$dryRun,
                 'sample_ids' => array());
    $flip = array();
    $tickets = array();
    foreach ($rows as $r) {
        $out['scanned']++;
        $out['next_after'] = (int)$r['id'];
        $html = (string)$r['body_html'];
        $cid  = trim((string)$r['content_id'], " <>\t");
        $shown = $html !== '' && (
            ($cid !== '' && stripos($html, 'cid:' . $cid) !== false)
            || preg_match('/action=view(?:&|&amp;)id=' . (int)$r['id'] . '(?!\d)/i', $html)
        );
        if ($shown) { $out['kept_inline']++; continue; }
        $flip[] = (int)$r['id'];
        $tickets[(int)$r['ticket_id']] = true;
        if (count($out['sample_ids']) < 10) $out['sample_ids'][] = (int)$r['id'];
    }
    $out['unhidden'] = count($flip);
    $out['tickets']  = count($tickets);
    $out['done']     = count($rows) < $limit;

    if (!$dryRun && !empty($flip)) {
        $place = implode(',', array_fill(0, count($flip), '?'));
        fd_exec("UPDATE fd_attachments SET is_inline = 0 WHERE is_inline = 1 AND id IN ($place)",
                str_repeat('i', count($flip)), $flip);
        foreach (array_keys($tickets) as $tid) fd_recount_ticket($tid);
        fd_log('info', 'Un-hid ' . count($flip) . ' attachment(s) filed as inline',
               array('tickets' => count($tickets), 'through_id' => $out['next_after']));
    }
    return $out;
}

/* ============================================================ attachments == */

/**
 * Store a message's attachments in S3 and index them.
 *
 * Files do NOT stay on the web server. fd_storage_put_bytes() puts the bytes in
 * the shared bucket under a random key, and the row keeps only that key and its
 * URL -- so the cPanel disk never fills up with years of customer screenshots,
 * and the same object is reachable from every server that talks to this DB.
 *
 * (If S3 is unreachable it falls back to local disk and marks the row
 * storage='local'. That is a degraded mode kept so a broken AWS config loses
 * nothing while it is being fixed; Settings > Diagnostics reports it.)
 *
 * The object key is random, never the customer's filename. That is what stops
 * a mail attachment called "../../index.php" from being both a path traversal
 * and a code-execution vector, and it means two customers both sending
 * "screenshot.png" cannot collide. The real name is data in a column and is
 * what the agent sees.
 *
 * Sizes are enforced per file and per message so one 200MB video cannot run up
 * an unbounded storage bill or exhaust PHP's memory limit mid-sync.
 */
function fd_store_attachments($ticketId, $messageId, $attachments, $direction = 'inbound')
{
    $out = array('saved' => 0, 'skipped' => 0, 'cid_map' => array(), 'ids' => array(), 'errors' => array());
    if (empty($attachments)) return $out;

    $maxFile = (int)FD_ATTACH_MAX_FILE_BYTES;
    $running = 0;

    foreach ($attachments as $a) {
        $content = isset($a['content']) ? $a['content'] : '';
        $size    = strlen($content);

        if ($size === 0) { $out['skipped']++; continue; }
        if ($size > $maxFile) {
            fd_log('warn', 'Attachment too large, skipped', array('name' => $a['filename'], 'size' => $size));
            $out['skipped']++;
            continue;
        }
        if ($running + $size > (int)FD_ATTACH_MAX_TOTAL_BYTES) {
            fd_log('warn', 'Per-message attachment budget exhausted', array('ticket' => $ticketId));
            $out['skipped']++;
            continue;
        }

        $original = MimeParser::sanitizeFilename(isset($a['filename']) ? $a['filename'] : 'attachment');
        $mime     = (isset($a['mime']) && $a['mime'] !== '') ? $a['mime'] : 'application/octet-stream';

        $put = fd_storage_put_bytes($ticketId, $original, $content, $mime);
        if (empty($put['ok'])) {
            fd_log('error', 'Attachment storage failed: ' . $put['error'], array('name' => $original));
            $out['skipped']++;
            $out['errors'][] = $original . ': ' . $put['error'];
            continue;
        }
        $running += $size;

        try {
            $id = fd_exec(
                "INSERT INTO fd_attachments
                    (ticket_id, message_id, filename, stored_name, rel_path, storage, s3_key, s3_url,
                     mime_type, size_bytes, content_id, is_inline, checksum, direction)
                 VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                'iissssssssisss',
                array(
                    (int)$ticketId, (int)$messageId, $original,
                    basename($put['key']), $put['rel_path'], $put['storage'], $put['key'], $put['url'],
                    $mime, $size,
                    (isset($a['content_id']) && $a['content_id'] !== '') ? $a['content_id'] : null,
                    !empty($a['is_inline']) ? 1 : 0,
                    md5($content),
                    $direction
                ),
                true
            );
            $out['saved']++;
            $out['ids'][] = (int)$id;
            if (!empty($a['content_id'])) $out['cid_map'][$a['content_id']] = (int)$id;
        } catch (Throwable $e) {
            // Never leave a stored object orphaned behind a failed row -- those
            // are invisible to every screen and bill forever.
            fd_storage_delete(array('storage' => $put['storage'], 's3_key' => $put['key'], 'rel_path' => $put['rel_path']));
            fd_log('error', 'Attachment row failed: ' . $e->getMessage());
            $out['skipped']++;
        }
    }
    return $out;
}

/**
 * Point <img src="cid:xyz"> at our attachment endpoint so inline images render.
 * Runs after the attachments are indexed, because it needs their row ids.
 */
function fd_rewrite_inline_cids($messageId, $cidMap)
{
    $row = fd_query_one("SELECT body_html FROM fd_messages WHERE id = ?", 'i', array((int)$messageId));
    if (!$row || $row['body_html'] === null || $row['body_html'] === '') return;

    $html = $row['body_html'];
    $changed = false;
    foreach ($cidMap as $cid => $attId) {
        $clean = trim($cid, " <>\t");
        if ($clean === '') continue;
        $url = 'fd_attachments.php?action=view&id=' . (int)$attId;
        $new = preg_replace('/cid:' . preg_quote($clean, '/') . '/i', $url, $html);
        if ($new !== null && $new !== $html) { $html = $new; $changed = true; }
    }
    if ($changed) {
        fd_exec("UPDATE fd_messages SET body_html = ? WHERE id = ?", 'si', array($html, (int)$messageId));
    }
}

/* =============================================================== activity == */

/** Record a human action on a ticket and publish it. */
function fd_activity($ticketId, $event, $summary, $actor = array(), $payload = array())
{
    return fd_emit($event, array_merge(array('ticket_id' => (int)$ticketId), $payload), array(
        'ticket_id'  => (int)$ticketId,
        'actor_type' => isset($actor['type']) ? $actor['type'] : 'agent',
        'actor_id'   => isset($actor['id']) ? (int)$actor['id'] : null,
        'actor_name' => isset($actor['name']) ? $actor['name'] : null,
        'summary'    => $summary,
    ));
}

/* ==========================================================================
   SENT-FOLDER INGEST — replies that were not written in this panel
   ========================================================================== */

/**
 * Store a copy of an OUTBOUND message found in the mailbox's Sent folder.
 *
 * WHY THIS EXISTS
 * This desk is not the only thing answering contact@internshipstudio.com. The
 * team also replies from the real Freshdesk and, occasionally, straight from
 * webmail. Those replies never touched our Mailer, so the panel showed a
 * customer's question with no answer under it -- the conversation looked
 * unanswered when it had in fact been handled hours ago.
 *
 * Anything that leaves the mailbox and lands in Sent is an answer somebody
 * gave. Reading that folder is how the panel sees them.
 *
 * DIFFERENCES FROM fd_store_inbound()
 *   - The sender must be US. The inbound path drops our own address to stop the
 *     desk answering itself; here that same address is the entry criterion.
 *   - It NEVER opens a ticket. A sent mail that matches no conversation is an
 *     agent writing to someone out of band; inventing a ticket for it would
 *     fill the queue with our own outgoing post.
 *   - Threading also tries the RECIPIENT, because on an outgoing message the
 *     customer is in To:, not From:.
 *
 * @return array ticket_id / message_id / duplicate / skipped
 */
function fd_store_outbound_copy($parsed, $meta = array())
{
    global $conn;

    $messageIdHdr = isset($parsed['message_id']) ? trim($parsed['message_id']) : '';
    $mailbox      = isset($meta['mailbox']) ? $meta['mailbox'] : (string)fd_cfg('IMAP_SENT_FOLDER', 'INBOX.Sent');
    $uid          = isset($meta['uid']) ? (int)$meta['uid'] : 0;
    $uidvalidity  = isset($meta['uidvalidity']) ? (int)$meta['uidvalidity'] : 0;
    $uidKey       = $uid ? ($mailbox . ':' . $uidvalidity . ':' . $uid) : null;

    // ---- duplicate gate ---------------------------------------------------
    // Our own Mailer APPENDs every reply it sends into this same folder, so the
    // overwhelming majority of what is here is already in fd_messages. This is
    // the check that keeps re-reading Sent cheap and idempotent.
    if ($messageIdHdr !== '') {
        $dup = fd_query_one("SELECT id, ticket_id FROM fd_messages WHERE message_id = ?", 's', array($messageIdHdr));
        if ($dup) {
            return array('ticket_id' => (int)$dup['ticket_id'], 'message_id' => (int)$dup['id'], 'duplicate' => true);
        }
    }
    if ($uidKey) {
        $dup = fd_query_one("SELECT id, ticket_id FROM fd_messages WHERE uid_key = ?", 's', array($uidKey));
        if ($dup) {
            return array('ticket_id' => (int)$dup['ticket_id'], 'message_id' => (int)$dup['id'], 'duplicate' => true);
        }
    }

    // ---- it has to be from us --------------------------------------------
    // A Sent folder can contain drafts and misfiled mail. Only what this
    // mailbox actually sent counts as an agent reply.
    if (!fd_is_own_address($parsed['from_email'])) {
        return array('ticket_id' => 0, 'message_id' => 0, 'duplicate' => false, 'skipped' => 'sent-not-ours');
    }

    // ---- which conversation? ---------------------------------------------
    $ticketId = fd_resolve_ticket($parsed);

    if (!$ticketId) {
        // Threading by sender cannot work outbound -- the sender is us. Try the
        // recipient against the subject, the same 30-day window the inbound
        // fallback uses.
        $ticketId = fd_resolve_ticket_by_recipient($parsed);
    }

    if (!$ticketId) {
        return array('ticket_id' => 0, 'message_id' => 0, 'duplicate' => false, 'skipped' => 'sent-no-ticket');
    }

    $bodyText = isset($parsed['body_text']) ? $parsed['body_text'] : '';
    $bodyHtml = isset($parsed['body_html']) ? $parsed['body_html'] : '';
    $visible  = fd_strip_quoted_text($bodyText);

    try {
        $msgId = fd_exec(
            "INSERT INTO fd_messages
                (ticket_id, direction, msg_type, from_name, from_email, to_emails, cc_emails, subject,
                 body_html, body_text, snippet, message_id, in_reply_to, references_hdr,
                 mailbox, imap_uid, imap_uidvalidity, uid_key, has_attachments, attachment_count,
                 delivery_status, sent_by_name, message_date, raw_size, created_at)
             VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?, 'sent', ?,?,?, NOW())",
            'issssssssssssssiisiissi',
            array(
                $ticketId,
                'outbound',
                'reply',
                $parsed['from_name'], $parsed['from_email'],
                json_encode($parsed['to']), json_encode($parsed['cc']),
                fd_snippet($parsed['subject'], 490),
                fd_sanitize_html($bodyHtml), $bodyText, fd_snippet($visible, 250),
                $messageIdHdr !== '' ? $messageIdHdr : null,
                !empty($parsed['in_reply_to']) ? $parsed['in_reply_to'] : null,
                !empty($parsed['references']) ? implode(' ', $parsed['references']) : null,
                $mailbox, $uid ?: null, $uidvalidity ?: null, $uidKey,
                !empty($parsed['attachments']) ? 1 : 0, count($parsed['attachments']),
                // Named so the thread can say where the answer came from rather
                // than attributing someone else's work to this panel.
                'Sent from the mailbox',
                !empty($parsed['date']) ? $parsed['date'] : date('Y-m-d H:i:s'),
                isset($meta['size']) ? (int)$meta['size'] : 0,
            ),
            true
        );
    } catch (Throwable $e) {
        // Same race as the inbound path: the UNIQUE indexes decide, not the
        // SELECTs above, and losing is a correct outcome.
        if ((int)$conn->errno === 1062) {
            return array('ticket_id' => $ticketId, 'message_id' => 0, 'duplicate' => true);
        }
        throw $e;
    }
    if (!$msgId) throw new Exception('Outbound copy insert returned no id.');

    $saved = fd_store_attachments($ticketId, (int)$msgId, $parsed['attachments'], 'outbound');
    if (!empty($saved['cid_map'])) fd_rewrite_inline_cids((int)$msgId, $saved['cid_map']);

    fd_touch_ticket_outbound($ticketId, !empty($parsed['date']) ? $parsed['date'] : null);
    fd_recount_ticket($ticketId);
    fd_sla_refresh($ticketId);

    return array('ticket_id' => (int)$ticketId, 'message_id' => (int)$msgId, 'duplicate' => false);
}

/**
 * Thread an OUTGOING message by who it was addressed to.
 *
 * The inbound resolver's last resort is "same sender + same subject, recently".
 * On a message we sent, the person is in To:, so this is that rule with the
 * direction turned around. Deliberately narrow: it needs a normalised subject
 * match, not just an address, or every reply would land on that customer's
 * oldest open ticket.
 */
function fd_resolve_ticket_by_recipient($parsed)
{
    $to = isset($parsed['to']) && is_array($parsed['to']) ? $parsed['to'] : array();
    if (empty($to)) return 0;

    $base = fd_normalize_subject(isset($parsed['subject']) ? $parsed['subject'] : '');
    if ($base === '') return 0;

    foreach ($to as $addr) {
        $email = is_array($addr) && isset($addr['email']) ? $addr['email'] : (is_string($addr) ? $addr : '');
        $email = fd_norm_email($email);
        if ($email === '' || fd_is_own_address($email)) continue;

        $rows = fd_query(
            "SELECT id, subject, merged_into FROM fd_tickets
             WHERE requester_email = ? AND created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
             ORDER BY id DESC LIMIT 20",
            's', array($email)
        );
        foreach ($rows as $t) {
            if (fd_normalize_subject($t['subject']) === $base) {
                return !empty($t['merged_into']) ? (int)$t['merged_into'] : (int)$t['id'];
            }
        }
    }
    return 0;
}

/**
 * Ticket bookkeeping after an answer that this panel did not send.
 *
 * Mirrors Mailer::afterSend(): the first-response clock stops, the customer's
 * "waiting" flags clear, and a New ticket becomes Open. It does NOT reopen a
 * Resolved or Closed one -- an agent answering a closed ticket from elsewhere
 * is finishing it off, not reopening it.
 */
function fd_touch_ticket_outbound($ticketId, $when = null)
{
    $t = fd_query_one("SELECT id, status, first_response_at FROM fd_tickets WHERE id = ?", 'i', array((int)$ticketId));
    if (!$t) return;

    $status = $t['status'];
    if ($status === 'New') $status = 'Open';
    if (in_array($status, array('Open', 'New'), true)) $status = 'Pending';

    $at = $when ? $when : date('Y-m-d H:i:s');

    if (empty($t['first_response_at'])) {
        fd_exec("UPDATE fd_tickets
                 SET first_response_at = ?, status = ?, response_status = 'Agent responded',
                     customer_replied = 0, unread_count = 0,
                     last_message_at = ?, last_agent_at = ?, updated_at = NOW()
                 WHERE id = ?",
                'ssssi', array($at, $status, $at, $at, (int)$ticketId));
    } else {
        fd_exec("UPDATE fd_tickets
                 SET status = ?, response_status = 'Agent responded',
                     customer_replied = 0, unread_count = 0,
                     last_message_at = ?, last_agent_at = ?, updated_at = NOW()
                 WHERE id = ?",
                'sssi', array($status, $at, $at, (int)$ticketId));
    }
}

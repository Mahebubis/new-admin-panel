<?php
/**
 * starter_kit_payments.php
 * ---------------------------------------------------------------------------
 * Admin API for "Purchased Starter Kit" (the 99 Store checkout).
 *
 * Reads the `ninety_nine_store_orders` table. The table is self-contained —
 * the buyer's details are captured at checkout (guest flow), so there is no
 * join to `users` any more. One order can carry SEVERAL courses: `courses`
 * is a JSON array of {name, slug, price} and `course_count` is its length,
 * while `course_slug` / `course_name` hold the first (primary) course.
 *
 * Columns in ninety_nine_store_orders:
 *   id, first_name, last_name, email, phone_number, state, course_slug,
 *   course_name, courses (json), course_count, batch, order_id,
 *   razorpay_order_id, payment_id, provider, amount, status,
 *   created_at, updated_at
 *
 * Every route also accepts &q= — a free-text search matched against the
 * buyer's email and phone_number (partial match; digits-only comparison so a
 * plain 10-digit number still finds a '+91 …' row).
 *
 * Routes (POST or GET ?action=):
 *   action=fetch_stats  &range=&start=&end=&provider=&q=
 *                                 -> success/initiated/failed counts + sums
 *   action=fetch_list   &status=&range=&start=&end=&provider=&q=&page=&per_page=
 *                                 -> paginated records + total
 *   action=export       &status=&range=&start=&end=&provider=&q=
 *                                 -> every matching record (no pagination)
 *
 * The "Add Starter Kit Order" popup (an admin-entered purchase) uses:
 *   action=fetch_courses          -> the store catalogue, built from the orders
 *   action=lookup_email &email=   -> name + phone from the learner's account,
 *                                    falling back to their last store order
 *   action=create_order &email=&first_name=&last_name=&phone=&courses=(json)
 *                       &amount=&status=&provider=&order_id=&payment_id=
 *                       &created_at=(YYYY-MM-DDTHH:MM)
 *                                 -> inserts one row; created_at is written to
 *                                    BOTH created_at and updated_at
 *
 * Responses: { "status":"success", "data":{...} } | { "status":"error", ... }
 *
 * Mirrors the bootstrap / error-handling style of problem_statements_api.php.
 * ---------------------------------------------------------------------------
 */

@ini_set('display_errors', '0');
error_reporting(E_ALL);

define('SK_LOG_FILE', __DIR__ . '/starter_kit_payments_errors.log');
@ini_set('log_errors', '1');
@ini_set('error_log', SK_LOG_FILE);

function sk_log($label, $msg) {
    $line = '[' . date('Y-m-d H:i:s') . '] ' . $label . ': ' . $msg
          . '  {' . ($_SERVER['REQUEST_METHOD'] ?? 'CLI') . ' '
          . ($_SERVER['REQUEST_URI'] ?? '') . '}' . PHP_EOL;
    @file_put_contents(SK_LOG_FILE, $line, FILE_APPEND | LOCK_EX);
}

set_error_handler(function ($no, $str, $file, $line) {
    if (strpos($file, 'starter_kit_payments.php') !== false) {
        sk_log('PHP-ERROR(' . $no . ')', $str . ' in ' . $file . ':' . $line);
    }
    return true;
});

/* shared bootstrap — provides global $conn (same as the other endpoints here) */
ob_start();
chdir('/home/istudio/public_html/cit/common');
include '/home/istudio/public_html/cit/common/helper.php';
ob_clean();

header('Content-Type: application/json');

register_shutdown_function(function () {
    $e = error_get_last();
    if ($e && in_array($e['type'], [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR], true)) {
        sk_log('FATAL', $e['message'] . ' in ' . $e['file'] . ':' . $e['line']);
        if (!headers_sent()) header('Content-Type: application/json');
        echo json_encode(['status' => 'error', 'message' => 'Server error: ' . $e['message']]);
    }
});

set_exception_handler(function ($e) {
    sk_log('EXCEPTION', get_class($e) . ': ' . $e->getMessage()
        . ' in ' . $e->getFile() . ':' . $e->getLine());
    if (!headers_sent()) {
        http_response_code(500);
        header('Content-Type: application/json');
    }
    echo json_encode(['status' => 'error', 'message' => 'Server error: ' . $e->getMessage()]);
    exit;
});

/* ====== helpers ====== */
function sk_out($p) { echo json_encode($p); exit; }
function sk_error($m, $c = 400) {
    sk_log('API-ERROR(' . $c . ')', $m);
    http_response_code($c);
    sk_out(['status' => 'error', 'message' => $m]);
}
function sk_ok($d = null, $m = '') {
    $r = ['status' => 'success'];
    if ($d !== null) $r['data'] = $d;
    if ($m !== '')   $r['message'] = $m;
    sk_out($r);
}

/* Build a safe SQL date-range condition on `created_at`.
   Returns a string that is always a valid boolean expression. */
function sk_date_condition($range, $start, $end) {
    switch ($range) {
        case 'today':
            return "DATE(o.created_at) = CURDATE()";
        case 'yesterday':
            return "DATE(o.created_at) = (CURDATE() - INTERVAL 1 DAY)";
        case 'last7':
            // last 7 days including today
            return "DATE(o.created_at) >= (CURDATE() - INTERVAL 6 DAY)";
        case 'custom':
            $re = '/^\d{4}-\d{2}-\d{2}$/';
            if (!preg_match($re, $start) || !preg_match($re, $end)) {
                sk_error('Invalid custom date range — expected YYYY-MM-DD for both start and end');
            }
            if ($start > $end) { $t = $start; $start = $end; $end = $t; }
            return "DATE(o.created_at) BETWEEN '$start' AND '$end'";
        case 'all':
        default:
            return "1";
    }
}

/* Build a safe search condition on email / mobile. Empty => no filter.
   Partial matches are allowed so half an email or the last digits of a number
   still find the order. The extra REPLACE() comparison strips spaces, dashes
   and the +/91 prefix from the stored number, so "9433583685" also matches a
   row saved as "+91 94335 83685". */
function sk_search_condition($conn, $q) {
    if ($q === '') return "1";

    $like   = '%' . $conn->real_escape_string($q) . '%';
    $parts  = ["o.email LIKE '$like'", "o.phone_number LIKE '$like'"];

    $digits = preg_replace('/\D+/', '', $q);
    if ($digits !== '') {
        if (strlen($digits) > 10) $digits = substr($digits, -10);   // drop a typed country code
        $d = $conn->real_escape_string($digits);
        $parts[] = "REPLACE(REPLACE(REPLACE(o.phone_number, ' ', ''), '-', ''), '+', '') LIKE '%$d%'";
    }

    return '(' . implode(' OR ', $parts) . ')';
}

/* Build a safe provider condition. Empty / "all" => no filter. */
function sk_provider_condition($conn, $provider) {
    if ($provider === '' || $provider === 'all') return "1";
    if (!in_array($provider, ['cashfree', 'razorpay'], true)) {
        sk_error('Invalid provider — must be cashfree, razorpay or all');
    }
    $p = $conn->real_escape_string($provider);
    return "o.provider = '$p'";
}

/* Normalise one DB row for the panel:
   - name        = first_name + last_name
   - phone       = phone_number (legacy key kept for the UI)
   - courses     = [{name, slug, price}, …] — always an array, even for the
                   older single-course rows where `courses` is NULL
   - course_count= trusted from the column, falling back to the array length
   - paid_at     = updated_at once paid, else created_at */
function sk_shape_row($r) {
    $r['name']  = trim(($r['first_name'] ?? '') . ' ' . ($r['last_name'] ?? ''));
    $r['phone'] = $r['phone_number'] ?? '';

    $list = [];
    if (!empty($r['courses'])) {
        $decoded = json_decode($r['courses'], true);
        if (is_array($decoded)) {
            foreach ($decoded as $c) {
                if (is_string($c)) {
                    $list[] = ['name' => $c, 'slug' => '', 'price' => null];
                } elseif (is_array($c)) {
                    $list[] = [
                        'name'  => $c['name']  ?? $c['course_name'] ?? $c['title'] ?? ($c['slug'] ?? ''),
                        'slug'  => $c['slug']  ?? $c['course_slug'] ?? '',
                        'price' => isset($c['price']) ? (float)$c['price'] : null,
                    ];
                }
            }
        }
    }
    /* pre-multi-course rows (and any row with an unparseable JSON blob) */
    if (!$list && (($r['course_name'] ?? '') !== '' || ($r['course_slug'] ?? '') !== '')) {
        $list[] = [
            'name'  => $r['course_name'] ?? '',
            'slug'  => $r['course_slug'] ?? '',
            'price' => null,
        ];
    }

    $r['courses']      = $list;
    $r['course_count'] = (int)($r['course_count'] ?? 0) ?: count($list);
    $r['paid_at']      = ($r['status'] === 'success') ? $r['updated_at'] : $r['created_at'];
    return $r;
}

/* every column the panel renders / exports */
function sk_select_columns() {
    return "o.id,
            o.first_name,
            o.last_name,
            o.email,
            o.phone_number,
            o.state,
            o.course_slug,
            o.course_name,
            o.courses,
            o.course_count,
            o.batch,
            o.order_id,
            o.razorpay_order_id,
            o.payment_id,
            o.provider,
            o.amount,
            o.status,
            o.created_at,
            o.updated_at";
}

global $conn;
if (!$conn) sk_error('Database connection failed', 500);

$action   = $_REQUEST['action']   ?? '';
$range    = $_REQUEST['range']    ?? 'today';
$start    = trim($_REQUEST['start'] ?? '');
$end      = trim($_REQUEST['end']   ?? '');
$provider = strtolower(trim($_REQUEST['provider'] ?? 'all'));
$q        = trim($_REQUEST['q']    ?? '');
if (mb_strlen($q) > 120) $q = mb_substr($q, 0, 120);

$dateCond     = sk_date_condition($range, $start, $end);
$providerCond = sk_provider_condition($conn, $provider);
$searchCond   = sk_search_condition($conn, $q);

/* ════════════════════════════════════════
   FETCH STATS — success / initiated / failed totals for the range.
   *_courses sums the number of courses sold, which is what the 99 Store
   actually moves — an order of 3 courses is 1 order but 3 courses.
════════════════════════════════════════ */
if ($action === 'fetch_stats') {
    $sql = "SELECT
                SUM(o.status = 'success')                              AS success_count,
                SUM(o.status = 'initiated')                            AS initiated_count,
                SUM(o.status = 'failed')                               AS failed_count,
                COALESCE(SUM(CASE WHEN o.status = 'success'   THEN o.amount ELSE 0 END), 0) AS success_amount,
                COALESCE(SUM(CASE WHEN o.status = 'initiated' THEN o.amount ELSE 0 END), 0) AS initiated_amount,
                COALESCE(SUM(CASE WHEN o.status = 'failed'    THEN o.amount ELSE 0 END), 0) AS failed_amount,
                COALESCE(SUM(CASE WHEN o.status = 'success'   THEN GREATEST(o.course_count, 1) ELSE 0 END), 0) AS success_courses,
                COALESCE(SUM(CASE WHEN o.status = 'initiated' THEN GREATEST(o.course_count, 1) ELSE 0 END), 0) AS initiated_courses,
                COALESCE(SUM(CASE WHEN o.status = 'failed'    THEN GREATEST(o.course_count, 1) ELSE 0 END), 0) AS failed_courses
            FROM ninety_nine_store_orders o
            WHERE $dateCond AND $providerCond AND $searchCond";

    $res = $conn->query($sql);
    if ($res === false) sk_error('Stats query failed: ' . $conn->error, 500);
    $row = $res->fetch_assoc() ?: [];
    $conn->close();

    sk_ok([
        'success_count'     => (int)($row['success_count']     ?? 0),
        'initiated_count'   => (int)($row['initiated_count']   ?? 0),
        'failed_count'      => (int)($row['failed_count']      ?? 0),
        'success_amount'    => (float)($row['success_amount']   ?? 0),
        'initiated_amount'  => (float)($row['initiated_amount'] ?? 0),
        'failed_amount'     => (float)($row['failed_amount']    ?? 0),
        'success_courses'   => (int)($row['success_courses']   ?? 0),
        'initiated_courses' => (int)($row['initiated_courses'] ?? 0),
        'failed_courses'    => (int)($row['failed_courses']    ?? 0),
    ]);
}

/* ════════════════════════════════════════
   FETCH LIST — paginated records for one status
════════════════════════════════════════ */
if ($action === 'fetch_list') {
    $status = $_REQUEST['status'] ?? 'success';
    if (!in_array($status, ['success', 'initiated', 'failed'], true)) {
        sk_error('Invalid status — must be success, initiated or failed');
    }

    $page     = max(1,  (int)($_REQUEST['page']     ?? 1));
    $perPage  = (int)($_REQUEST['per_page'] ?? 20);
    if (!in_array($perPage, [20, 50, 100, 200], true)) $perPage = 20;
    $offset   = ($page - 1) * $perPage;

    $where = "$dateCond AND $providerCond AND $searchCond AND o.status = '$status'";

    /* total count */
    $cRes = $conn->query("SELECT COUNT(*) AS c FROM ninety_nine_store_orders o WHERE $where");
    if ($cRes === false) sk_error('Count query failed: ' . $conn->error, 500);
    $total = (int)($cRes->fetch_assoc()['c'] ?? 0);

    /* main data */
    $sql = "SELECT " . sk_select_columns() . "
            FROM ninety_nine_store_orders o
            WHERE $where
            ORDER BY o.id DESC
            LIMIT $perPage OFFSET $offset";

    $res = $conn->query($sql);
    if ($res === false) sk_error('List query failed: ' . $conn->error, 500);

    $rows = [];
    while ($r = $res->fetch_assoc()) $rows[] = sk_shape_row($r);
    $conn->close();

    sk_ok([
        'rows'     => $rows,
        'total'    => $total,
        'page'     => $page,
        'per_page' => $perPage,
    ]);
}

/* ════════════════════════════════════════
   EXPORT — every matching record (no pagination) for the date range.
   status = success | initiated | failed | all (default all)
════════════════════════════════════════ */
if ($action === 'export') {
    $status = $_REQUEST['status'] ?? 'all';
    if (!in_array($status, ['success', 'initiated', 'failed', 'all'], true)) {
        sk_error('Invalid status — must be success, initiated, failed or all');
    }
    $statusCond = ($status === 'all') ? "1" : "o.status = '$status'";

    $sql = "SELECT " . sk_select_columns() . "
            FROM ninety_nine_store_orders o
            WHERE $dateCond AND $providerCond AND $searchCond AND $statusCond
            ORDER BY o.id DESC";

    $res = $conn->query($sql);
    if ($res === false) sk_error('Export query failed: ' . $conn->error, 500);

    $rows = [];
    while ($r = $res->fetch_assoc()) $rows[] = sk_shape_row($r);
    $conn->close();

    sk_ok(['rows' => $rows, 'total' => count($rows)]);
}

/* ════════════════════════════════════════
   FETCH COURSES — the store's catalogue, derived from the orders themselves
   so a course added to the 99 Store later shows up here without a code change.
   Primary courses come from the indexed course_slug/course_name columns; the
   extra courses of a multi-course order live only inside the `courses` JSON,
   so the DISTINCT blobs (far fewer than the rows) are parsed as well.
════════════════════════════════════════ */
if ($action === 'fetch_courses') {
    $map = [];   // slug => ['slug'=>…, 'name'=>…, 'orders'=>n]

    $add = function ($slug, $name, $n) use (&$map) {
        $slug = trim((string)$slug);
        $name = trim((string)$name);
        if ($slug === '' && $name === '') return;
        $key = $slug !== '' ? $slug : $name;
        if (!isset($map[$key])) {
            $map[$key] = [
                'slug'   => ($slug !== '' ? $slug : $name),
                'name'   => ($name !== '' ? $name : $slug),
                'orders' => 0,
            ];
        } elseif ($map[$key]['name'] === $map[$key]['slug'] && $name !== '') {
            $map[$key]['name'] = $name;          // a nicer label turned up later
        }
        $map[$key]['orders'] += $n;
    };

    $res = $conn->query("SELECT o.course_slug, o.course_name, COUNT(*) AS c
                         FROM ninety_nine_store_orders o
                         WHERE COALESCE(o.course_slug, '') <> '' OR COALESCE(o.course_name, '') <> ''
                         GROUP BY o.course_slug, o.course_name");
    if ($res === false) sk_error('Course query failed: ' . $conn->error, 500);
    while ($r = $res->fetch_assoc()) $add($r['course_slug'], $r['course_name'], (int)$r['c']);

    /* the 2nd..Nth course of a multi-course order lives only in the JSON */
    $res = $conn->query("SELECT DISTINCT o.courses
                         FROM ninety_nine_store_orders o
                         WHERE o.courses IS NOT NULL AND o.courses <> '' AND o.course_count > 1
                         LIMIT 2000");
    if ($res !== false) {
        while ($r = $res->fetch_assoc()) {
            $decoded = json_decode($r['courses'], true);
            if (!is_array($decoded)) continue;
            foreach ($decoded as $c) {
                if (is_string($c)) {
                    $add('', $c, 0);
                } elseif (is_array($c)) {
                    $add($c['slug'] ?? $c['course_slug'] ?? '',
                         $c['name'] ?? $c['course_name'] ?? $c['title'] ?? '', 0);
                }
            }
        }
    }
    $conn->close();

    $courses = array_values($map);
    usort($courses, function ($a, $b) {
        if ($a['orders'] === $b['orders']) return strcasecmp($a['name'], $b['name']);
        return $b['orders'] - $a['orders'];
    });

    sk_ok(['courses' => $courses]);
}

/* ════════════════════════════════════════
   LOOKUP EMAIL — pre-fills the add-order form.
   The learner's dashboard account wins; if they never signed up, their own
   last store order is used instead. `orders` is how many store orders that
   email already has, so an admin can spot a duplicate before adding one.
════════════════════════════════════════ */
if ($action === 'lookup_email') {
    $email = strtolower(trim($_REQUEST['email'] ?? ''));
    if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        sk_error('Enter a valid email address');
    }
    $e = $conn->real_escape_string($email);

    $orders = 0;
    $cRes = $conn->query("SELECT COUNT(*) AS c FROM ninety_nine_store_orders o WHERE LOWER(o.email) = '$e'");
    if ($cRes !== false) $orders = (int)($cRes->fetch_assoc()['c'] ?? 0);

    /* 1 — dashboard account (users.name is one field, so it is split) */
    $uRes = $conn->query("SELECT user_id, name, phone FROM users WHERE email = '$e' LIMIT 1");
    if ($uRes !== false && ($u = $uRes->fetch_assoc())) {
        $parts = preg_split('/\s+/', trim((string)$u['name']), 2);
        $conn->close();
        sk_ok([
            'found'      => true,
            'from'       => 'account',
            'user_id'    => (int)$u['user_id'],
            'first_name' => $parts[0] ?? '',
            'last_name'  => $parts[1] ?? '',
            'phone'      => (string)($u['phone'] ?? ''),
            'orders'     => $orders,
        ]);
    }

    /* 2 — their own last store order (guest checkout, no account) */
    $oRes = $conn->query("SELECT o.first_name, o.last_name, o.phone_number
                          FROM ninety_nine_store_orders o
                          WHERE LOWER(o.email) = '$e'
                          ORDER BY o.id DESC LIMIT 1");
    if ($oRes !== false && ($o = $oRes->fetch_assoc())) {
        $conn->close();
        sk_ok([
            'found'      => true,
            'from'       => 'order',
            'first_name' => (string)($o['first_name'] ?? ''),
            'last_name'  => (string)($o['last_name'] ?? ''),
            'phone'      => (string)($o['phone_number'] ?? ''),
            'orders'     => $orders,
        ]);
    }

    $conn->close();
    sk_ok(['found' => false, 'orders' => 0]);
}

/* ════════════════════════════════════════
   CREATE ORDER — an admin-entered store purchase.
   The picked date-time is written to BOTH created_at and updated_at so the row
   lands inside the range being reconciled (the list shows updated_at as the
   paid date of a successful order).
════════════════════════════════════════ */
if ($action === 'create_order') {
    $email     = strtolower(trim($_REQUEST['email'] ?? ''));
    $first     = trim($_REQUEST['first_name'] ?? '');
    $last      = trim($_REQUEST['last_name']  ?? '');
    $phone     = preg_replace('/[^0-9+]/', '', (string)($_REQUEST['phone'] ?? ''));
    $state     = trim($_REQUEST['state'] ?? '');
    $batch     = trim($_REQUEST['batch'] ?? '');
    $newStatus = trim($_REQUEST['status'] ?? '');
    $orderId   = trim($_REQUEST['order_id']   ?? '');
    $paymentId = trim($_REQUEST['payment_id'] ?? '');
    $amountRaw = trim($_REQUEST['amount'] ?? '');
    $whenIn    = trim($_REQUEST['created_at'] ?? '');

    if (!filter_var($email, FILTER_VALIDATE_EMAIL))       sk_error('Enter a valid email address');
    if ($first === '')                                    sk_error('First name is required');
    if ($last === '')                                     sk_error('Last name is required');
    if (strlen(preg_replace('/\D/', '', $phone)) < 10)    sk_error('Enter a valid phone number (at least 10 digits)');
    if (!in_array($newStatus, ['success', 'initiated', 'failed'], true)) {
        sk_error('Invalid status — must be success, initiated or failed');
    }
    if (!in_array($provider, ['cashfree', 'razorpay'], true)) {
        sk_error('Invalid provider — must be cashfree or razorpay');
    }
    if ($orderId === '')                                  sk_error('Order ID is required');
    if ($paymentId === '')                                sk_error('Payment ID is required');
    if (!is_numeric($amountRaw) || (float)$amountRaw <= 0) sk_error('Enter a valid amount');

    /* courses — a JSON array of {slug, name, price}, re-normalised here so the
       stored blob always has the shape sk_shape_row() reads back */
    $cart = json_decode($_REQUEST['courses'] ?? '', true);
    if (!is_array($cart) || !$cart) sk_error('Select at least one course');

    $clean = [];
    foreach ($cart as $c) {
        if (is_string($c)) $c = ['name' => $c];
        if (!is_array($c)) continue;
        $slug = trim((string)($c['slug'] ?? $c['course_slug'] ?? ''));
        $name = trim((string)($c['name'] ?? $c['course_name'] ?? $c['title'] ?? ''));
        if ($slug === '' && $name === '') continue;
        $clean[] = [
            'name'  => $name !== '' ? $name : $slug,
            'slug'  => $slug !== '' ? $slug : $name,
            'price' => (isset($c['price']) && is_numeric($c['price'])) ? (float)$c['price'] : null,
        ];
    }
    if (!$clean)             sk_error('Select at least one course');
    if (count($clean) > 50)  sk_error('Too many courses in one order');

    /* the datetime-local value the admin picked (YYYY-MM-DDTHH:MM[:SS]) */
    if (!preg_match('/^(\d{4}-\d{2}-\d{2})[T ](\d{2}:\d{2})(:\d{2})?$/', $whenIn, $m)) {
        sk_error('Pick a valid purchase date & time');
    }
    $when = $m[1] . ' ' . $m[2] . (isset($m[3]) ? $m[3] : ':00');
    if (strtotime($when) === false) sk_error('Pick a valid purchase date & time');

    /* never let a hand-added order collide with a real one */
    $oEsc = $conn->real_escape_string($orderId);
    $dup  = $conn->query("SELECT id FROM ninety_nine_store_orders WHERE order_id = '$oEsc' LIMIT 1");
    if ($dup !== false && $dup->num_rows > 0) sk_error('That Order ID already exists — generate a new one');

    $pEsc = $conn->real_escape_string($paymentId);
    $dup  = $conn->query("SELECT id FROM ninety_nine_store_orders WHERE payment_id = '$pEsc' LIMIT 1");
    if ($dup !== false && $dup->num_rows > 0) sk_error('That Payment ID already exists — generate a new one');

    /* user_id / source / from_main only exist once the LMS migration has run */
    $cols = [];
    $colRes = $conn->query("SHOW COLUMNS FROM ninety_nine_store_orders");
    if ($colRes !== false) while ($c = $colRes->fetch_assoc()) $cols[$c['Field']] = true;

    $uid = 0;
    if (isset($cols['user_id'])) {
        $uRes = $conn->query("SELECT user_id FROM users WHERE email = '" . $conn->real_escape_string($email) . "' LIMIT 1");
        if ($uRes !== false && ($u = $uRes->fetch_assoc())) $uid = (int)$u['user_id'];
    }

    $quoted   = function ($v) use ($conn) { return "'" . $conn->real_escape_string((string)$v) . "'"; };
    $nullable = function ($v) use ($conn) {
        return trim((string)$v) === '' ? 'NULL' : "'" . $conn->real_escape_string((string)$v) . "'";
    };

    $fields = [
        'first_name'   => $quoted($first),
        'last_name'    => $quoted($last),
        'email'        => $quoted($email),
        'phone_number' => $quoted($phone),
        'state'        => $nullable($state),
        'course_slug'  => $quoted($clean[0]['slug']),
        'course_name'  => $quoted($clean[0]['name']),
        'courses'      => $quoted(json_encode($clean, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)),
        'course_count' => (string)count($clean),
        'batch'        => $nullable($batch),
        'order_id'     => $quoted($orderId),
        'payment_id'   => $quoted($paymentId),
        'provider'     => $quoted($provider),
        'amount'       => (string)(float)$amountRaw,
        'status'       => $quoted($newStatus),
        'created_at'   => $quoted($when),
        'updated_at'   => $quoted($when),
    ];
    if (isset($cols['razorpay_order_id'])) $fields['razorpay_order_id'] = 'NULL';
    if (isset($cols['user_id']))           $fields['user_id']   = $uid > 0 ? (string)$uid : 'NULL';
    if (isset($cols['source']))            $fields['source']    = "'admin'";
    if (isset($cols['from_main']))         $fields['from_main'] = "'no'";

    $sql = "INSERT INTO ninety_nine_store_orders (`" . implode('`, `', array_keys($fields)) . "`)
            VALUES (" . implode(', ', array_values($fields)) . ")";

    if (!$conn->query($sql)) sk_error('Could not add the order: ' . $conn->error, 500);
    $newId = (int)$conn->insert_id;
    $conn->close();

    sk_log('CREATE-ORDER', "id=$newId order_id=$orderId email=$email courses=" . count($clean) . " status=$newStatus");
    sk_ok(['id' => $newId, 'order_id' => $orderId], 'Order added');
}

sk_error('Unknown action: ' . $action, 404);

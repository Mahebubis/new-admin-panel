<?php
/*
 * Audience — turns a campaign's audience config into rows in
 * kumo_campaign_recipients, and owns contact import.
 *
 * READ-ONLY CONTRACT: when an audience comes from the existing product data
 * (a netcore segment, or the `users` table), this file only ever SELECTs from
 * those tables. Everything it writes goes into kumo_* tables.
 */

require_once __DIR__ . '/schema.php';

/* ── Contacts ──────────────────────────────────────────────────────────────── */

/** Insert-or-update one contact. Returns its id, or 0 when the email is junk. */
/**
 * Fills blank names and phone numbers on kumo_contacts from the panel's own
 * student records.
 *
 * A contact added by hand or imported from a bare email list is usually someone
 * we already know — leaving the row blank would waste that, show dashes in the
 * table and send "Hi there" to a person whose name is one join away.
 *
 * READ-ONLY on `users`: a single SELECT per chunk, then an UPDATE that touches
 * kumo_contacts and nothing else. COALESCE means an explicitly entered name is
 * never overwritten — only NULLs are filled.
 *
 * The lookup matches `email` exactly rather than with LOWER(), which would drop
 * the index and turn this into a full scan of a multi-million row table.
 */
function kumo_enrich_contacts_from_users(array $emails): int {
    global $conn;
    $emails = array_values(array_unique(array_filter(array_map(
        fn($e) => strtolower(trim((string)$e)), $emails
    ))));
    if (!$emails) return 0;

    $filled = 0;
    foreach (array_chunk($emails, 500) as $chunk) {
        $in = implode(',', array_map(fn($e) => "'" . $conn->real_escape_string($e) . "'", $chunk));
        try {
            $r = $conn->query("SELECT email, fname, lname, phone FROM users WHERE email IN ($in)");
        } catch (\Throwable $ex) {
            error_log('kumo_enrich_contacts_from_users: ' . $ex->getMessage());
            return $filled;
        }
        while ($r && $u = $r->fetch_assoc()) {
            $fn = trim((string)($u['fname'] ?? ''));
            $ln = trim((string)($u['lname'] ?? ''));
            $ph = trim((string)($u['phone'] ?? ''));
            if ($fn === '' && $ln === '' && $ph === '') continue;

            $conn->query(sprintf(
                "UPDATE kumo_contacts SET
                    first_name = COALESCE(first_name, NULLIF('%s','')),
                    last_name  = COALESCE(last_name,  NULLIF('%s','')),
                    phone      = COALESCE(phone,      NULLIF('%s',''))
                 WHERE email='%s'",
                $conn->real_escape_string($fn),
                $conn->real_escape_string($ln),
                $conn->real_escape_string($ph),
                $conn->real_escape_string(strtolower((string)$u['email']))
            ));
            if ($conn->affected_rows > 0) $filled++;
        }
    }
    return $filled;
}

function kumo_contact_upsert(string $email, array $fields = [], string $source = 'manual'): int {
    global $conn;
    $email = strtolower(trim($email));
    if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) return 0;

    $e  = $conn->real_escape_string($email);
    $fn = $conn->real_escape_string((string)($fields['first_name'] ?? ''));
    $ln = $conn->real_escape_string((string)($fields['last_name'] ?? ''));
    $ph = $conn->real_escape_string((string)($fields['phone'] ?? ''));
    $sc = $conn->real_escape_string($source);

    try {
        $conn->query("INSERT INTO kumo_contacts (email, first_name, last_name, phone, source)
                      VALUES ('$e', NULLIF('$fn',''), NULLIF('$ln',''), NULLIF('$ph',''), '$sc')
                      ON DUPLICATE KEY UPDATE
                        first_name = COALESCE(NULLIF('$fn',''), first_name),
                        last_name  = COALESCE(NULLIF('$ln',''), last_name),
                        phone      = COALESCE(NULLIF('$ph',''), phone)");
        $id = (int)$conn->insert_id;
        if ($id > 0) return $id;
        $r = $conn->query("SELECT id FROM kumo_contacts WHERE email='$e' LIMIT 1");
        if ($r && $x = $r->fetch_assoc()) return (int)$x['id'];
    } catch (\Throwable $ex) { error_log('kumo_contact_upsert: ' . $ex->getMessage()); }
    return 0;
}

/** Adds contacts to a list, refreshing its cached count. */
function kumo_list_add(int $listId, array $contactIds): int {
    global $conn;
    if (!$listId || !$contactIds) return 0;
    $n = 0;
    $chunks = array_chunk(array_values(array_unique(array_map('intval', $contactIds))), 500);
    foreach ($chunks as $chunk) {
        $vals = implode(',', array_map(fn($c) => "($listId,$c)", $chunk));
        try {
            $conn->query("INSERT IGNORE INTO kumo_list_members (list_id, contact_id) VALUES $vals");
            $n += $conn->affected_rows;
        } catch (\Throwable $e) { error_log('kumo_list_add: ' . $e->getMessage()); }
    }
    kumo_list_recount($listId);
    return $n;
}

function kumo_list_recount(int $listId): int {
    global $conn;
    try {
        $r = $conn->query("SELECT COUNT(*) c FROM kumo_list_members WHERE list_id=" . (int)$listId);
        $c = $r ? (int)$r->fetch_assoc()['c'] : 0;
        $conn->query("UPDATE kumo_lists SET contact_count=$c WHERE id=" . (int)$listId);
        return $c;
    } catch (\Throwable $e) { error_log('kumo_list_recount: ' . $e->getMessage()); return 0; }
}

/* ── Suppression ───────────────────────────────────────────────────────────── */

function kumo_suppress(string $email, string $reason = 'manual', string $detail = '', ?int $campaignId = null): void {
    global $conn;
    $email = strtolower(trim($email));
    if ($email === '') return;
    $valid = ['hard_bounce','complaint','unsubscribe','manual','imported','invalid'];
    if (!in_array($reason, $valid, true)) $reason = 'manual';
    try {
        $conn->query(sprintf(
            "INSERT INTO kumo_blocklist (email, reason, detail, campaign_id) VALUES ('%s','%s',%s,%s)
             ON DUPLICATE KEY UPDATE reason=VALUES(reason), detail=VALUES(detail)",
            $conn->real_escape_string($email), $reason,
            $detail === '' ? 'NULL' : "'" . $conn->real_escape_string(substr($detail, 0, 480)) . "'",
            $campaignId ? (int)$campaignId : 'NULL'
        ));
        $status = $reason === 'complaint' ? 'complained' : ($reason === 'hard_bounce' ? 'bounced' : 'unsubscribed');
        $conn->query("UPDATE kumo_contacts SET status='$status' WHERE email='" . $conn->real_escape_string($email) . "'");
    } catch (\Throwable $e) { error_log('kumo_suppress: ' . $e->getMessage()); }
}

/*
 * Is this address suppressed?
 *
 * Checks our own list first, then — READ-ONLY — the panel's existing Netcore
 * blocklist (campaign_lists.kind='blocklist'), because someone who unsubscribed
 * or bounced over there must not start receiving mail again just because this
 * platform is new. Nothing is written to those tables.
 */
function kumo_is_suppressed(string $email): bool {
    global $conn;
    $e = $conn->real_escape_string(strtolower(trim($email)));
    if ($e === '') return false;

    try {
        $r = $conn->query("SELECT 1 FROM kumo_blocklist WHERE email='$e' LIMIT 1");
        if ($r && $r->fetch_row()) return true;
    } catch (\Throwable $ex) { /* fall through */ }

    if (kumo_setting('honour_netcore_blocklist', '1') !== '1') return false;

    try {
        $r = $conn->query("SELECT 1
            FROM campaign_list_members m
            JOIN campaign_lists  l ON l.id = m.list_id AND l.kind = 'blocklist'
            JOIN campaign_contacts c ON c.id = m.contact_id
            WHERE c.email = '$e' LIMIT 1");
        return (bool)($r && $r->fetch_row());
    } catch (\Throwable $ex) { return false; }   // netcore tables absent → ignore
}

/** How many addresses the shared Netcore blocklist holds (read-only). */
function kumo_netcore_blocklist_count(): int {
    global $conn;
    try {
        $r = $conn->query("SELECT COUNT(*) c
            FROM campaign_list_members m
            JOIN campaign_lists l ON l.id = m.list_id AND l.kind='blocklist'");
        return $r ? (int)$r->fetch_assoc()['c'] : 0;
    } catch (\Throwable $e) { return 0; }
}

/* ── Segments ──────────────────────────────────────────────────────────────── */

/**
 * Builds the SELECT that yields {email, first_name, last_name} for a segment.
 * Returns null when the segment cannot be resolved.
 *
 *  source = kumo_list   → config: {list_ids:[..]}
 *  source = engagement  → config: {status, engaged_days, never_opened, domain}
 *  source = netcore     → config: {netcore_segment_id}   (READ-ONLY reuse)
 */
function kumo_segment_select(array $seg): ?string {
    global $conn;
    $cfg = is_array($seg['config'] ?? null) ? $seg['config'] : (json_decode((string)($seg['config'] ?? ''), true) ?: []);

    if ($seg['source'] === 'kumo_list') {
        $ids = array_filter(array_map('intval', (array)($cfg['list_ids'] ?? [])));
        if (!$ids) return null;
        $in = implode(',', $ids);
        return "SELECT DISTINCT c.email, c.first_name, c.last_name
                FROM kumo_list_members m
                JOIN kumo_contacts c ON c.id = m.contact_id
                WHERE m.list_id IN ($in) AND c.status = 'active'";
    }

    if ($seg['source'] === 'engagement') {
        $w = ["c.status = 'active'"];
        $days = (int)($cfg['engaged_days'] ?? 0);
        if ($days > 0) $w[] = "(c.last_open_at >= DATE_SUB(NOW(), INTERVAL $days DAY) OR c.last_click_at >= DATE_SUB(NOW(), INTERVAL $days DAY))";
        if (!empty($cfg['never_opened'])) $w[] = "c.last_open_at IS NULL";
        if (!empty($cfg['domain']))       $w[] = "c.email LIKE '%@" . $conn->real_escape_string(ltrim((string)$cfg['domain'], '@')) . "'";
        if (!empty($cfg['engagement']) && in_array($cfg['engagement'], ['new','hot','warm','cold','dormant'], true)) {
            $w[] = "c.engagement = '" . $conn->real_escape_string($cfg['engagement']) . "'";
        }
        return "SELECT c.email, c.first_name, c.last_name FROM kumo_contacts c WHERE " . implode(' AND ', $w);
    }

    /*
     * 'rules' — the Netcore condition builder, saved into OUR table but resolved
     * by the existing (read-only) segment SQL builder so the behaviour is
     * identical to a Netcore segment. Nothing is written to netcore_*.
     */
    if ($seg['source'] === 'rules') {
        try {
            require_once __DIR__ . '/../../netcore/lib/segment_sql.php';
            if (!function_exists('buildSegmentSql')) return null;
            $inner = buildSegmentSql($cfg);
            if (!$inner) return null;
            return "SELECT DISTINCT u.email AS email, u.first_name AS first_name, u.last_name AS last_name
                    FROM ($inner) seg
                    JOIN users u ON u.user_id = seg.user_id
                    WHERE u.email IS NOT NULL AND u.email <> ''";
        } catch (\Throwable $e) {
            error_log('kumo_segment_select(rules): ' . $e->getMessage());
            return null;
        }
    }

    if ($seg['source'] === 'netcore') {
        $nid = (int)($cfg['netcore_segment_id'] ?? 0);
        if (!$nid) return null;
        try {
            $r = $conn->query("SELECT config FROM netcore_segments WHERE id = $nid LIMIT 1");
            $row = $r ? $r->fetch_assoc() : null;
            if (!$row) return null;
            $ncCfg = json_decode((string)$row['config'], true);
            if (!$ncCfg) return null;

            require_once __DIR__ . '/../../netcore/lib/segment_sql.php';
            if (!function_exists('buildSegmentSql')) return null;
            $inner = buildSegmentSql($ncCfg);
            if (!$inner) return null;

            /* READ-ONLY join onto the product's users table purely to read the
               address and name for the send. Nothing is written back. */
            return "SELECT DISTINCT u.email AS email, u.first_name AS first_name, u.last_name AS last_name
                    FROM ($inner) seg
                    JOIN users u ON u.user_id = seg.user_id
                    WHERE u.email IS NOT NULL AND u.email <> ''";
        } catch (\Throwable $e) {
            error_log('kumo_segment_select(netcore): ' . $e->getMessage());
            return null;
        }
    }
    return null;
}

function kumo_segment_count(array $seg): int {
    global $conn;
    $sql = kumo_segment_select($seg);
    if (!$sql) return 0;
    try {
        $r = $conn->query("SELECT COUNT(*) c FROM ($sql) s");
        return $r ? (int)$r->fetch_assoc()['c'] : 0;
    } catch (\Throwable $e) { error_log('kumo_segment_count: ' . $e->getMessage()); return 0; }
}

function kumo_segment_row(int $id): ?array {
    global $conn;
    try {
        $r = $conn->query("SELECT * FROM kumo_segments WHERE id=" . (int)$id . " LIMIT 1");
        $x = $r ? $r->fetch_assoc() : null;
        if (!$x) return null;
        $x['config'] = json_decode((string)$x['config'], true) ?: [];
        return $x;
    } catch (\Throwable $e) { return null; }
}

/* ── Materialisation ───────────────────────────────────────────────────────── */

/**
 * Expands a campaign's audience into kumo_campaign_recipients.
 *
 * Runs in bounded chunks and is safe to call again: the unique rid plus the
 * per-campaign dedupe on email means a re-run tops the list up rather than
 * duplicating it.
 */
function kumo_materialize(int $campaignId): array {
    global $conn;
    $out = ['inserted' => 0, 'skipped_suppressed' => 0, 'skipped_dupe' => 0, 'error' => null];

    $r = $conn->query("SELECT * FROM kumo_campaigns WHERE id=" . (int)$campaignId . " LIMIT 1");
    $c = $r ? $r->fetch_assoc() : null;
    if (!$c) { $out['error'] = 'Campaign not found'; return $out; }

    $selects = [];
    $listIds    = array_filter(array_map('intval', json_decode((string)$c['list_ids'], true) ?: []));
    $segIds     = array_filter(array_map('intval', json_decode((string)$c['segment_ids'], true) ?: []));
    $excludeIds = array_filter(array_map('intval', json_decode((string)$c['exclude_list_ids'], true) ?: []));

    if ($c['audience_type'] === 'list' && $listIds) {
        $in = implode(',', $listIds);
        $selects[] = "SELECT DISTINCT c.email, c.first_name, c.last_name
                      FROM kumo_list_members m JOIN kumo_contacts c ON c.id = m.contact_id
                      WHERE m.list_id IN ($in) AND c.status='active'";
    } elseif ($c['audience_type'] === 'segment' && $segIds) {
        foreach ($segIds as $sid) {
            $seg = kumo_segment_row($sid);
            if (!$seg) continue;
            $s = kumo_segment_select($seg);
            if ($s) $selects[] = $s;
        }
    } elseif ($c['audience_type'] === 'all_contacts') {
        $selects[] = "SELECT email, first_name, last_name FROM kumo_contacts WHERE status='active'";
    }

    if (!$selects) { $out['error'] = 'This campaign has no resolvable audience'; return $out; }

    $union = implode(' UNION ', array_map(fn($s) => "($s)", $selects));

    $excludeSql = '';
    if ($excludeIds) {
        $in = implode(',', $excludeIds);
        $excludeSql = " AND a.email NOT IN (SELECT c2.email FROM kumo_list_members m2 JOIN kumo_contacts c2 ON c2.id=m2.contact_id WHERE m2.list_id IN ($in))";
    }

    /* Pull in pages so a million-row segment never materialises in PHP memory. */
    $page = 0;
    $per  = 5000;
    $now  = date('Y-m-d H:i:s');
    try {
        while (true) {
            $offset = $page * $per;
            $sql = "SELECT a.email, a.first_name, a.last_name
                    FROM ($union) a
                    WHERE a.email IS NOT NULL AND a.email <> ''
                      AND a.email NOT IN (SELECT b.email FROM kumo_blocklist b WHERE b.email = a.email)
                      $excludeSql
                    LIMIT $per OFFSET $offset";
            $res = $conn->query($sql);
            if (!$res) break;

            $values = [];
            while ($row = $res->fetch_assoc()) {
                $email = strtolower(trim((string)$row['email']));
                if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) continue;
                $values[] = sprintf("(%d, '%s', %s, %s, '%s', 'pending', '%s')",
                    $campaignId,
                    $conn->real_escape_string($email),
                    $row['first_name'] ? "'" . $conn->real_escape_string($row['first_name']) . "'" : 'NULL',
                    $row['last_name']  ? "'" . $conn->real_escape_string($row['last_name'])  . "'" : 'NULL',
                    kumo_rid(),
                    $now
                );
            }
            $got = $res->num_rows;

            if ($values) {
                foreach (array_chunk($values, 500) as $chunk) {
                    $conn->query("INSERT INTO kumo_campaign_recipients
                        (campaign_id, email, first_name, last_name, rid, status, queued_at)
                        VALUES " . implode(',', $chunk));
                    $out['inserted'] += $conn->affected_rows;
                }
            }
            if ($got < $per) break;
            $page++;
            if ($page > 400) break;   // 2M safety stop
        }

        /* De-duplicate inside this campaign (keeps the lowest id per email). */
        $conn->query("DELETE r1 FROM kumo_campaign_recipients r1
                      JOIN kumo_campaign_recipients r2
                        ON r1.campaign_id = r2.campaign_id AND r1.email = r2.email AND r1.id > r2.id
                      WHERE r1.campaign_id = " . (int)$campaignId);
        $out['skipped_dupe'] = $conn->affected_rows;

        $r2 = $conn->query("SELECT COUNT(*) c FROM kumo_campaign_recipients WHERE campaign_id=" . (int)$campaignId . " AND is_test=0");
        $total = $r2 ? (int)$r2->fetch_assoc()['c'] : 0;
        $conn->query("UPDATE kumo_campaigns SET total_recipients=$total, queued_count=$total, materialized_at=NOW() WHERE id=" . (int)$campaignId);
    } catch (\Throwable $e) {
        $out['error'] = $e->getMessage();
        error_log('kumo_materialize: ' . $e->getMessage());
    }
    return $out;
}

/**
 * Preview count without writing anything — powers the wizard's live
 * "N recipients" readout.
 */
function kumo_audience_preview(string $type, array $listIds, array $segIds, array $excludeIds): int {
    global $conn;
    $selects = [];
    if ($type === 'list' && $listIds) {
        $in = implode(',', array_map('intval', $listIds));
        $selects[] = "SELECT DISTINCT c.email FROM kumo_list_members m JOIN kumo_contacts c ON c.id=m.contact_id WHERE m.list_id IN ($in) AND c.status='active'";
    } elseif ($type === 'segment' && $segIds) {
        foreach ($segIds as $sid) {
            $seg = kumo_segment_row((int)$sid);
            if (!$seg) continue;
            $s = kumo_segment_select($seg);
            if ($s) $selects[] = "SELECT email FROM ($s) x";
        }
    } elseif ($type === 'all_contacts') {
        $selects[] = "SELECT email FROM kumo_contacts WHERE status='active'";
    }
    if (!$selects) return 0;

    $union = implode(' UNION ', array_map(fn($s) => "($s)", $selects));
    $excludeSql = '';
    if ($excludeIds) {
        $in = implode(',', array_map('intval', $excludeIds));
        $excludeSql = " AND a.email NOT IN (SELECT c2.email FROM kumo_list_members m2 JOIN kumo_contacts c2 ON c2.id=m2.contact_id WHERE m2.list_id IN ($in))";
    }
    try {
        $r = $conn->query("SELECT COUNT(*) c FROM ($union) a
                           WHERE a.email <> '' AND a.email NOT IN (SELECT b.email FROM kumo_blocklist b WHERE b.email=a.email) $excludeSql");
        return $r ? (int)$r->fetch_assoc()['c'] : 0;
    } catch (\Throwable $e) { error_log('kumo_audience_preview: ' . $e->getMessage()); return 0; }
}

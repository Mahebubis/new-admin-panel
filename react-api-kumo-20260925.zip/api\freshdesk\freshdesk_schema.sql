-- =============================================================================
--  Freshdesk helpdesk — schema reference
--
--  This file is DOCUMENTATION. The tables are created and migrated at runtime
--  by fd_ensure_schema() in lib/schema.php, which every endpoint calls, so
--  nothing here needs to be run by hand on a normal deploy. It exists so the
--  shape is reviewable without reading PHP, and so a DBA can see the indexes.
--
--  Database: istudio_cit (alongside the email_campaigns tables).
--
--  If you DO run this by hand, run it once on an empty database. On an existing
--  install let lib/schema.php do it — it adds new columns without touching data.
-- =============================================================================


-- -----------------------------------------------------------------------------
-- fd_tickets — one row per conversation.
--
-- `id` IS the ticket number humans see. AUTO_INCREMENT is seeded at 336000 so
-- the first real ticket looks like an established desk rather than #1. There is
-- deliberately no separate ticket_no column: two identifiers for one row is how
-- "#336270 not found" bugs are born.
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS fd_tickets (
  id                  BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  subject             VARCHAR(998) NOT NULL DEFAULT '',
  -- subject with the [#IS-nnn] token and every Re:/Fwd: prefix stripped; the
  -- half of the fallback threading key that is not the sender address.
  base_subject        VARCHAR(500) NOT NULL DEFAULT '',

  requester_name      VARCHAR(191) NOT NULL DEFAULT '',
  requester_email     VARCHAR(191) NOT NULL DEFAULT '',
  requester_phone     VARCHAR(64)  DEFAULT NULL,
  contact_id          BIGINT UNSIGNED DEFAULT NULL,

  status              VARCHAR(32) NOT NULL DEFAULT 'New',
  priority            VARCHAR(16) NOT NULL DEFAULT 'Medium',
  source              VARCHAR(16) NOT NULL DEFAULT 'Email',
  category            VARCHAR(64) DEFAULT NULL,
  department          VARCHAR(64) DEFAULT NULL,
  ticket_type         VARCHAR(64) DEFAULT NULL,

  agent_user_id       BIGINT UNSIGNED DEFAULT NULL,
  agent_name          VARCHAR(128) NOT NULL DEFAULT 'Unassigned',
  tags                TEXT DEFAULT NULL,           -- JSON array of strings

  is_spam             TINYINT(1) NOT NULL DEFAULT 0,
  is_trash            TINYINT(1) NOT NULL DEFAULT 0,
  is_undelivered      TINYINT(1) NOT NULL DEFAULT 0,
  raised_by_agent     TINYINT(1) NOT NULL DEFAULT 0,
  -- Merged tickets become tombstones pointing at the survivor rather than being
  -- deleted, so an old link (or a [#IS-nnn] token still sitting in a customer's
  -- mail client) keeps resolving.
  merged_into         BIGINT UNSIGNED DEFAULT NULL,

  response_status     VARCHAR(32) NOT NULL DEFAULT 'Awaiting reply',
  unread_count        INT NOT NULL DEFAULT 0,
  customer_replied    TINYINT(1) NOT NULL DEFAULT 0,

  -- Two independent SLA clocks; see lib/Sla.php.
  first_response_at   DATETIME DEFAULT NULL,
  first_response_due  DATETIME DEFAULT NULL,
  resolution_due      DATETIME DEFAULT NULL,
  resolved_at         DATETIME DEFAULT NULL,
  closed_at           DATETIME DEFAULT NULL,
  sla_status          VARCHAR(16) NOT NULL DEFAULT 'On track',
  sla_breached        TINYINT(1) NOT NULL DEFAULT 0,

  last_message_at     DATETIME DEFAULT NULL,
  last_customer_at    DATETIME DEFAULT NULL,
  last_agent_at       DATETIME DEFAULT NULL,
  message_count       INT NOT NULL DEFAULT 0,
  attachment_count    INT NOT NULL DEFAULT 0,

  -- md5(lower(email) | lower(base_subject)); rule 3 of fd_resolve_ticket().
  thread_key          VARCHAR(191) DEFAULT NULL,
  student_context     TEXT DEFAULT NULL,           -- JSON, agent-editable overlay

  created_at          DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at          DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

  INDEX idx_status   (status),
  INDEX idx_email    (requester_email),
  INDEX idx_thread   (thread_key),
  INDEX idx_updated  (updated_at),
  INDEX idx_last_msg (last_message_at),
  INDEX idx_flags    (is_spam, is_trash),
  INDEX idx_agent    (agent_user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=336000;


-- -----------------------------------------------------------------------------
-- fd_messages — every inbound email, outbound reply/forward, and private note.
--
-- THE TWO UNIQUE KEYS ARE THE WHOLE ANTI-DUPLICATE STORY. IMAP hands the same
-- message back whenever UIDVALIDITY rolls over, the mailbox is rebuilt, or two
-- sync runs overlap. Without these, one customer email appears in the thread
-- four times; with them, a re-sync is a harmless no-op.
--
--   uniq_message_id — the sender's RFC 5322 Message-ID.
--   uniq_uid_key    — mailbox:uidvalidity:uid, for the rare message with no
--                     Message-ID header at all.
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS fd_messages (
  id                BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  ticket_id         BIGINT UNSIGNED NOT NULL,
  -- 'note' never leaves the building: nothing in the send path selects it.
  direction         ENUM('inbound','outbound','note') NOT NULL DEFAULT 'inbound',
  msg_type          VARCHAR(16) NOT NULL DEFAULT 'reply',   -- reply|forward|note|auto_ack|bounce

  from_name         VARCHAR(191) DEFAULT NULL,
  from_email        VARCHAR(191) DEFAULT NULL,
  to_emails         TEXT DEFAULT NULL,             -- JSON array
  cc_emails         TEXT DEFAULT NULL,
  bcc_emails        TEXT DEFAULT NULL,
  subject           VARCHAR(998) DEFAULT NULL,

  -- body_html is stored ALREADY SANITISED (lib/Helpers.php fd_sanitize_html).
  body_html         LONGTEXT DEFAULT NULL,
  body_text         LONGTEXT DEFAULT NULL,
  snippet           VARCHAR(500) DEFAULT NULL,     -- quoted history stripped

  message_id        VARCHAR(255) DEFAULT NULL,
  in_reply_to       VARCHAR(255) DEFAULT NULL,
  references_hdr    TEXT DEFAULT NULL,

  mailbox           VARCHAR(128) DEFAULT NULL,
  imap_uid          BIGINT UNSIGNED DEFAULT NULL,
  imap_uidvalidity  BIGINT UNSIGNED DEFAULT NULL,
  uid_key           VARCHAR(191) DEFAULT NULL,

  has_attachments   TINYINT(1) NOT NULL DEFAULT 0,
  attachment_count  INT NOT NULL DEFAULT 0,

  -- A failed send is a STATE, not an error: the row survives with the SMTP
  -- reason attached so the agent sees their message marked "not delivered"
  -- with a Retry button instead of losing what they typed.
  delivery_status   ENUM('received','queued','sent','failed','bounced') NOT NULL DEFAULT 'received',
  delivery_error    TEXT DEFAULT NULL,
  retry_count       INT NOT NULL DEFAULT 0,

  sent_by_user_id   BIGINT UNSIGNED DEFAULT NULL,
  sent_by_name      VARCHAR(128) DEFAULT NULL,

  message_date      DATETIME DEFAULT NULL,         -- the Date: header
  created_at        DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,

  raw_size          INT NOT NULL DEFAULT 0,
  is_auto_reply     TINYINT(1) NOT NULL DEFAULT 0,

  UNIQUE KEY uniq_message_id (message_id),
  UNIQUE KEY uniq_uid_key    (uid_key),
  INDEX idx_ticket    (ticket_id, id),
  INDEX idx_created   (created_at),
  INDEX idx_inreplyto (in_reply_to),
  INDEX idx_delivery  (delivery_status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- -----------------------------------------------------------------------------
-- fd_attachments — index of files; the BYTES live in S3.
--
-- storage='s3' is the normal case: s3_key/s3_url point at the shared
-- internshipstudio-prod-data-bucket-new object and nothing is written to the
-- web server. storage='local' is the degraded fallback used only while S3 is
-- unreachable (rel_path is then relative to lib/../uploads). Settings >
-- Diagnostics reports how many rows are in that state.
--
-- stored_name/s3_key are RANDOM, never the customer's filename: an attachment
-- called "../../index.php" must be able to neither traverse nor execute.
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS fd_attachments (
  id             BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  ticket_id      BIGINT UNSIGNED NOT NULL,
  -- NULL while an agent has staged a file but not yet sent the reply.
  message_id     BIGINT UNSIGNED DEFAULT NULL,
  filename       VARCHAR(255) NOT NULL,            -- what the human sees
  stored_name    VARCHAR(255) DEFAULT NULL,
  rel_path       VARCHAR(500) DEFAULT NULL,        -- local fallback only
  storage        ENUM('s3','local') NOT NULL DEFAULT 's3',
  s3_key         VARCHAR(500) DEFAULT NULL,
  s3_url         VARCHAR(1000) DEFAULT NULL,
  mime_type      VARCHAR(128) DEFAULT NULL,        -- sniffed, not the browser's claim
  size_bytes     BIGINT NOT NULL DEFAULT 0,
  content_id     VARCHAR(255) DEFAULT NULL,        -- cid: for inline images
  is_inline      TINYINT(1) NOT NULL DEFAULT 0,
  checksum       VARCHAR(64) DEFAULT NULL,
  direction      ENUM('inbound','outbound') NOT NULL DEFAULT 'inbound',
  uploaded_by    BIGINT UNSIGNED DEFAULT NULL,
  created_at     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_ticket  (ticket_id),
  INDEX idx_message (message_id),
  INDEX idx_cid     (content_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- -----------------------------------------------------------------------------
-- fd_contacts — one row per email address that has ever written in.
-- user_id links to the platform account when one exists, which is what makes
-- the ticket sidebar show a real student instead of just an address.
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS fd_contacts (
  id              BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  email           VARCHAR(191) NOT NULL,
  name            VARCHAR(191) DEFAULT NULL,
  phone           VARCHAR(64) DEFAULT NULL,
  user_id         BIGINT UNSIGNED DEFAULT NULL,
  college         VARCHAR(191) DEFAULT NULL,
  program         VARCHAR(191) DEFAULT NULL,
  enroll_id       VARCHAR(64) DEFAULT NULL,
  is_registered   TINYINT(1) NOT NULL DEFAULT 0,
  -- Blocked senders get no auto-reply and their open tickets go to Spam.
  is_blocked      TINYINT(1) NOT NULL DEFAULT 0,
  tickets_count   INT NOT NULL DEFAULT 0,
  first_seen_at   DATETIME DEFAULT NULL,
  last_seen_at    DATETIME DEFAULT NULL,
  notes           TEXT DEFAULT NULL,
  meta            TEXT DEFAULT NULL,               -- JSON
  created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uniq_email (email),
  INDEX idx_user (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- -----------------------------------------------------------------------------
-- fd_mailbox_state — one row per watched IMAP folder. The sync watermark.
--
-- uidvalidity sits beside last_uid because IMAP only guarantees UIDs are
-- comparable within one UIDVALIDITY generation. When the server changes it (a
-- rebuilt or restored mailbox) every stored UID silently means something else,
-- and the worker must re-baseline instead of trusting last_uid. Getting this
-- wrong makes a desk either re-import its whole mailbox or go permanently deaf.
--
-- lock_token/lock_at are the worker mutex, so a per-minute cron and an agent
-- pressing Refresh cannot import the same range twice. A lock older than five
-- minutes is treated as abandoned — that is the crash recovery.
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS fd_mailbox_state (
  id                BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  mailbox           VARCHAR(128) NOT NULL,
  uidvalidity       BIGINT UNSIGNED DEFAULT NULL,
  last_uid          BIGINT UNSIGNED NOT NULL DEFAULT 0,
  last_sync_at      DATETIME DEFAULT NULL,
  last_success_at   DATETIME DEFAULT NULL,
  last_status       VARCHAR(32) NOT NULL DEFAULT 'idle',
  last_error        TEXT DEFAULT NULL,
  consecutive_fails INT NOT NULL DEFAULT 0,
  imported_total    BIGINT NOT NULL DEFAULT 0,
  lock_token        VARCHAR(64) DEFAULT NULL,
  lock_at           DATETIME DEFAULT NULL,
  UNIQUE KEY uniq_mailbox (mailbox)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- -----------------------------------------------------------------------------
-- fd_activity — append-only audit trail AND the realtime replay log.
--
-- Its AUTO_INCREMENT id doubles as the client's polling cursor: the panel asks
-- for "everything after id N". That is what makes the no-Pusher fallback
-- CORRECT rather than merely frequent — a client that was offline for a minute
-- still receives every event it missed, in order, exactly once.
--
-- Every event is written here BEFORE any attempt to publish it over Pusher, so
-- the record exists whether or not the websocket worked.
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS fd_activity (
  id            BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  ticket_id     BIGINT UNSIGNED DEFAULT NULL,
  message_id    BIGINT UNSIGNED DEFAULT NULL,
  event         VARCHAR(48) NOT NULL,
  actor_type    ENUM('customer','agent','system') NOT NULL DEFAULT 'system',
  actor_id      BIGINT UNSIGNED DEFAULT NULL,
  actor_name    VARCHAR(128) DEFAULT NULL,
  summary       VARCHAR(500) DEFAULT NULL,
  payload       TEXT DEFAULT NULL,                 -- JSON
  created_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_ticket  (ticket_id),
  INDEX idx_event   (event),
  INDEX idx_created (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- -----------------------------------------------------------------------------
-- fd_settings — per-install overrides for everything in lib/config.php.
-- fd_cfg() reads a DB value first and falls back to the compiled-in define(),
-- which is how Settings > Email / Realtime edits take effect without a deploy.
-- Also holds per-agent composer drafts under 'draft_<userId>_<ticketId>'.
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS fd_settings (
  setting_key   VARCHAR(64) NOT NULL PRIMARY KEY,
  setting_value TEXT DEFAULT NULL,
  updated_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- -----------------------------------------------------------------------------
-- fd_canned_responses — reusable reply templates ("/c" in the composer).
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS fd_canned_responses (
  id              BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  name            VARCHAR(191) NOT NULL,
  category        VARCHAR(64) DEFAULT NULL,
  body            LONGTEXT DEFAULT NULL,
  shortcut        VARCHAR(32) DEFAULT NULL,
  uses            INT NOT NULL DEFAULT 0,
  is_active       TINYINT(1) NOT NULL DEFAULT 1,
  created_by      BIGINT UNSIGNED DEFAULT NULL,
  created_by_name VARCHAR(128) DEFAULT NULL,
  created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_active (is_active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- -----------------------------------------------------------------------------
-- fd_backfill — the DOWNWARD sync watermark. One row per mailbox.
--
-- fd_mailbox_state.last_uid only ever moves forward: the worker baselines a new
-- mailbox with the last SYNC_INITIAL_DAYS of mail and then imports whatever
-- arrives after it. Everything OLDER than that baseline sits in the mailbox and
-- was never read. This table is the cursor that walks the other way, driven by
-- fd_backfill.php.
--
-- Separate from fd_mailbox_state for two reasons: the two cursors move in
-- opposite directions and must never be confused, and the backfill needs its
-- OWN lock — a history import that runs for hours must not stop today's mail
-- from arriving.
--
-- cursor_uid walks DOWNWARD; each batch takes UIDs strictly below it and
-- commits before returning, so a killed worker resumes where it stopped and the
-- worst case is re-fetching one batch (which the UNIQUE keys on fd_messages
-- absorb). uidvalidity is stored beside it because the cursor is meaningless
-- without it: if the server rebuilds the mailbox mid-run, every remaining UID
-- refers to a different message and the run must stop rather than import the
-- wrong mail under a right-looking number.
--
-- Mail imported this way is marked: fd_messages.is_backfilled = 1 and
-- fd_tickets.is_archived = 1, and those tickets are created Closed, stamped at
-- the date they were actually sent. That is what keeps two years of settled
-- conversations out of today's unresolved queue and off the SLA report.
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS fd_backfill (
  id              BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  mailbox         VARCHAR(128) NOT NULL,
  until_date      DATE NOT NULL,                -- import back to this date
  uidvalidity     BIGINT UNSIGNED DEFAULT NULL,
  cursor_uid      BIGINT UNSIGNED DEFAULT NULL, -- next batch takes UIDs < this
  floor_uid       BIGINT UNSIGNED NOT NULL DEFAULT 0,    -- lowest UID in scope, measured once at start
  -- 1 = exclude mailer-daemon/postmaster bounces and "delayed"/"delivery failed"
  -- warnings, negated server-side in the SEARCH so their bodies are never fetched.
  -- Per run, because the same desk may want a byte-exact copy on one import and
  -- only the real conversations on the next.
  skip_auto       TINYINT(1) NOT NULL DEFAULT 0,
  status          VARCHAR(16) NOT NULL DEFAULT 'idle',   -- idle|running|paused|done|error
  total_in_scope  BIGINT NOT NULL DEFAULT 0,
  processed       BIGINT NOT NULL DEFAULT 0,
  imported        BIGINT NOT NULL DEFAULT 0,
  duplicates      BIGINT NOT NULL DEFAULT 0,
  skipped         BIGINT NOT NULL DEFAULT 0,
  errors          BIGINT NOT NULL DEFAULT 0,
  new_tickets     BIGINT NOT NULL DEFAULT 0,
  last_error      TEXT DEFAULT NULL,
  lock_token      VARCHAR(64) DEFAULT NULL,     -- worker mutex, 5-minute staleness
  lock_at         DATETIME DEFAULT NULL,
  started_at      DATETIME DEFAULT NULL,
  updated_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  finished_at     DATETIME DEFAULT NULL,
  UNIQUE KEY uniq_mailbox (mailbox)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

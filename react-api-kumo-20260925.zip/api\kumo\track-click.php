<?php
/*
 * Click tracker. Public by design (no JWT).
 *
 * Redirects FIRST (a reader must never wait for our database), then records.
 * The destination URL is carried in the query string and validated against the
 * signed token, so this can't be used as an open redirect by a third party.
 */
ini_set('display_errors', 0);
error_reporting(0);

$token = (string)($_GET['t'] ?? '');
$url   = (string)($_GET['u'] ?? '');

$safe = filter_var($url, FILTER_VALIDATE_URL) && preg_match('#^https?://#i', $url);
$dest = $safe ? $url : 'https://internshipstudio.com/';

header('Location: ' . $dest, true, 302);
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');

if (function_exists('fastcgi_finish_request')) { fastcgi_finish_request(); }
else { @ob_end_flush(); @flush(); }

if ($token === '' || !$safe) exit;

try {
    require_once __DIR__ . '/../../config/database.php';
    require_once __DIR__ . '/lib/config.php';
    require_once __DIR__ . '/lib/schema.php';
    require_once __DIR__ . '/lib/Stats.php';
    require_once __DIR__ . '/lib/Mailer.php';
    kumo_ensure_schema();

    $tok = kumo_token_verify($token);
    if (!$tok || $tok['kind'] !== 'c') exit;
    /* The token carries a short hash of the URL it was minted for. */
    if ($tok['extra'] !== '' && $tok['extra'] !== substr(md5($url), 0, 8)) exit;

    $rid = $conn->real_escape_string($tok['rid']);
    $r = $conn->query("SELECT * FROM kumo_campaign_recipients WHERE rid='$rid' LIMIT 1");
    $rcpt = $r ? $r->fetch_assoc() : null;
    if (!$rcpt) exit;

    $ua = substr((string)($_SERVER['HTTP_USER_AGENT'] ?? ''), 0, 480);
    $ip = trim(explode(',', (string)($_SERVER['HTTP_X_FORWARDED_FOR'] ?? $_SERVER['REMOTE_ADDR'] ?? ''))[0]);
    $first = ($rcpt['clicked_at'] === null);

    $conn->query("UPDATE kumo_campaign_recipients SET click_count=click_count+1, clicked_at=COALESCE(clicked_at, NOW()) WHERE id=" . (int)$rcpt['id']);
    $conn->query(sprintf(
        "INSERT INTO kumo_campaign_events (campaign_id, recipient_id, rid, ip_id, type, provider, url, ip_address, user_agent, created_at)
         VALUES (%d, %d, '%s', %s, 'click', '%s', '%s', '%s', '%s', NOW())",
        (int)$rcpt['campaign_id'], (int)$rcpt['id'], $rid,
        $rcpt['ip_id'] ? (int)$rcpt['ip_id'] : 'NULL',
        $conn->real_escape_string((string)$rcpt['provider']),
        $conn->real_escape_string(substr($url, 0, 990)),
        $conn->real_escape_string($ip), $conn->real_escape_string($ua)
    ));
    $conn->query("UPDATE kumo_campaigns SET click_count=click_count+1" . ($first ? ", unique_click_count=unique_click_count+1" : "") . " WHERE id=" . (int)$rcpt['campaign_id']);
    kumo_stats_bump((int)$rcpt['ip_id'], (string)$rcpt['provider'], ['clicks' => 1]);
    $conn->query("UPDATE kumo_contacts SET last_click_at=NOW(), engagement='hot' WHERE email='" . $conn->real_escape_string((string)$rcpt['email']) . "'");
} catch (\Throwable $e) {
    error_log('kumo track-click: ' . $e->getMessage());
}

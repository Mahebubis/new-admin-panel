<?php
/*
 * lib/JourneyFailureKind.php — bounce, or refusal?
 *
 * One definition, because the same failure reaches the database down two different roads: the send
 * path sees it as the provider's answer to our API call (JourneyDispatch), and the webhook sees it
 * minutes later as an event (JourneyWebhookSink). While only the first road classified them, a
 * WhatsApp "131026 Message Undeliverable" counted as a bounce when the send call returned it and as
 * a rejection when the webhook reported it — the same event in two columns depending on timing.
 *
 * The distinction matters because the two need opposite work: a bounce is an address or number that
 * cannot receive (fix the audience), a rejection is the provider declining to send (fix the setup,
 * or wait out a rate limit).
 */

if (!function_exists('journey_failure_is_bounce')) {
    /**
     * Does this failure mean the message could not reach the person, as opposed to the provider
     * refusing to send it for us?
     *
     * Matched on wording because each provider words it differently and none gives a code we could
     * switch on: SES and SendGrid say "Bounced", Meta answers 131026 "Message Undeliverable",
     * Netcore says the number is not on WhatsApp. Meta's 131049 (per-user marketing cap) and
     * 130472 (user in an experiment) are deliberately NOT here: the person is reachable, this
     * message was simply not sent.
     */
    function journey_failure_is_bounce(?string $error): bool {
        $e = strtolower(trim((string)$error));
        if ($e === '') return false;
        foreach (['bounce', 'undeliverable', '131026', 'not a whatsapp user', 'no whatsapp account',
                  'invalid number', 'does not exist', 'mailbox unavailable', 'user unknown',
                  'address rejected', 'recipient rejected', 'no such user'] as $needle) {
            if (strpos($e, $needle) !== false) return true;
        }
        return false;
    }
}

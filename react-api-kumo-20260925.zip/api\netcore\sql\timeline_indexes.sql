-- Indexes for the Netcore contact timeline (api/netcore/user_timeline.php + lib/MessageTimeline.php).
-- Run on istudio_cit in phpMyAdmin → SQL. Safe to run more than once: each index is only added when
-- no existing index already starts with that column. Online DDL — reads and writes keep working,
-- but the big tables (payment_status, signin_log, campaign recipients) can take a few minutes each.

-- Messages we sent: looked up by user_id and by email.
-- email_campaign_recipients (user_id)
SET @s = (SELECT IF(COUNT(*) = 0, 'ALTER TABLE `email_campaign_recipients` ADD INDEX idx_tl_user (user_id), ALGORITHM=INPLACE, LOCK=NONE', 'DO 0')
  FROM information_schema.statistics
 WHERE table_schema = DATABASE() AND table_name = 'email_campaign_recipients' AND seq_in_index = 1 AND column_name = 'user_id');
SET @s = IF((SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = DATABASE() AND table_name = 'email_campaign_recipients') = 0, 'DO 0', @s);
PREPARE st FROM @s; EXECUTE st; DEALLOCATE PREPARE st;

-- email_campaign_recipients (email)
SET @s = (SELECT IF(COUNT(*) = 0, 'ALTER TABLE `email_campaign_recipients` ADD INDEX idx_tl_email (email), ALGORITHM=INPLACE, LOCK=NONE', 'DO 0')
  FROM information_schema.statistics
 WHERE table_schema = DATABASE() AND table_name = 'email_campaign_recipients' AND seq_in_index = 1 AND column_name = 'email');
SET @s = IF((SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = DATABASE() AND table_name = 'email_campaign_recipients') = 0, 'DO 0', @s);
PREPARE st FROM @s; EXECUTE st; DEALLOCATE PREPARE st;

-- wa_campaign_recipients (user_id)
SET @s = (SELECT IF(COUNT(*) = 0, 'ALTER TABLE `wa_campaign_recipients` ADD INDEX idx_tl_user (user_id), ALGORITHM=INPLACE, LOCK=NONE', 'DO 0')
  FROM information_schema.statistics
 WHERE table_schema = DATABASE() AND table_name = 'wa_campaign_recipients' AND seq_in_index = 1 AND column_name = 'user_id');
SET @s = IF((SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = DATABASE() AND table_name = 'wa_campaign_recipients') = 0, 'DO 0', @s);
PREPARE st FROM @s; EXECUTE st; DEALLOCATE PREPARE st;

-- wa_campaign_recipients (email)
SET @s = (SELECT IF(COUNT(*) = 0, 'ALTER TABLE `wa_campaign_recipients` ADD INDEX idx_tl_email (email), ALGORITHM=INPLACE, LOCK=NONE', 'DO 0')
  FROM information_schema.statistics
 WHERE table_schema = DATABASE() AND table_name = 'wa_campaign_recipients' AND seq_in_index = 1 AND column_name = 'email');
SET @s = IF((SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = DATABASE() AND table_name = 'wa_campaign_recipients') = 0, 'DO 0', @s);
PREPARE st FROM @s; EXECUTE st; DEALLOCATE PREPARE st;

-- journey_messages (user_id)
SET @s = (SELECT IF(COUNT(*) = 0, 'ALTER TABLE `journey_messages` ADD INDEX idx_tl_user (user_id), ALGORITHM=INPLACE, LOCK=NONE', 'DO 0')
  FROM information_schema.statistics
 WHERE table_schema = DATABASE() AND table_name = 'journey_messages' AND seq_in_index = 1 AND column_name = 'user_id');
SET @s = IF((SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = DATABASE() AND table_name = 'journey_messages') = 0, 'DO 0', @s);
PREPARE st FROM @s; EXECUTE st; DEALLOCATE PREPARE st;

-- journey_messages (to_addr)
SET @s = (SELECT IF(COUNT(*) = 0, 'ALTER TABLE `journey_messages` ADD INDEX idx_tl_to_addr (to_addr), ALGORITHM=INPLACE, LOCK=NONE', 'DO 0')
  FROM information_schema.statistics
 WHERE table_schema = DATABASE() AND table_name = 'journey_messages' AND seq_in_index = 1 AND column_name = 'to_addr');
SET @s = IF((SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = DATABASE() AND table_name = 'journey_messages') = 0, 'DO 0', @s);
PREPARE st FROM @s; EXECUTE st; DEALLOCATE PREPARE st;

-- What the student did: every table in the activity UNION is filtered by user_id.
-- signin_log (user_id)
SET @s = (SELECT IF(COUNT(*) = 0, 'ALTER TABLE `signin_log` ADD INDEX idx_tl_user (user_id), ALGORITHM=INPLACE, LOCK=NONE', 'DO 0')
  FROM information_schema.statistics
 WHERE table_schema = DATABASE() AND table_name = 'signin_log' AND seq_in_index = 1 AND column_name = 'user_id');
SET @s = IF((SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = DATABASE() AND table_name = 'signin_log') = 0, 'DO 0', @s);
PREPARE st FROM @s; EXECUTE st; DEALLOCATE PREPARE st;

-- cit_results (user_id)
SET @s = (SELECT IF(COUNT(*) = 0, 'ALTER TABLE `cit_results` ADD INDEX idx_tl_user (user_id), ALGORITHM=INPLACE, LOCK=NONE', 'DO 0')
  FROM information_schema.statistics
 WHERE table_schema = DATABASE() AND table_name = 'cit_results' AND seq_in_index = 1 AND column_name = 'user_id');
SET @s = IF((SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = DATABASE() AND table_name = 'cit_results') = 0, 'DO 0', @s);
PREPARE st FROM @s; EXECUTE st; DEALLOCATE PREPARE st;

-- payment_status (user_id)
SET @s = (SELECT IF(COUNT(*) = 0, 'ALTER TABLE `payment_status` ADD INDEX idx_tl_user (user_id), ALGORITHM=INPLACE, LOCK=NONE', 'DO 0')
  FROM information_schema.statistics
 WHERE table_schema = DATABASE() AND table_name = 'payment_status' AND seq_in_index = 1 AND column_name = 'user_id');
SET @s = IF((SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = DATABASE() AND table_name = 'payment_status') = 0, 'DO 0', @s);
PREPARE st FROM @s; EXECUTE st; DEALLOCATE PREPARE st;

-- user_slected_domain_new (user_id)
SET @s = (SELECT IF(COUNT(*) = 0, 'ALTER TABLE `user_slected_domain_new` ADD INDEX idx_tl_user (user_id), ALGORITHM=INPLACE, LOCK=NONE', 'DO 0')
  FROM information_schema.statistics
 WHERE table_schema = DATABASE() AND table_name = 'user_slected_domain_new' AND seq_in_index = 1 AND column_name = 'user_id');
SET @s = IF((SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = DATABASE() AND table_name = 'user_slected_domain_new') = 0, 'DO 0', @s);
PREPARE st FROM @s; EXECUTE st; DEALLOCATE PREPARE st;

-- user_iap_visits (user_id)
SET @s = (SELECT IF(COUNT(*) = 0, 'ALTER TABLE `user_iap_visits` ADD INDEX idx_tl_user (user_id), ALGORITHM=INPLACE, LOCK=NONE', 'DO 0')
  FROM information_schema.statistics
 WHERE table_schema = DATABASE() AND table_name = 'user_iap_visits' AND seq_in_index = 1 AND column_name = 'user_id');
SET @s = IF((SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = DATABASE() AND table_name = 'user_iap_visits') = 0, 'DO 0', @s);
PREPARE st FROM @s; EXECUTE st; DEALLOCATE PREPARE st;

-- score_view_logs (user_id)
SET @s = (SELECT IF(COUNT(*) = 0, 'ALTER TABLE `score_view_logs` ADD INDEX idx_tl_user (user_id), ALGORITHM=INPLACE, LOCK=NONE', 'DO 0')
  FROM information_schema.statistics
 WHERE table_schema = DATABASE() AND table_name = 'score_view_logs' AND seq_in_index = 1 AND column_name = 'user_id');
SET @s = IF((SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = DATABASE() AND table_name = 'score_view_logs') = 0, 'DO 0', @s);
PREPARE st FROM @s; EXECUTE st; DEALLOCATE PREPARE st;

-- assigned_links (user_id)
SET @s = (SELECT IF(COUNT(*) = 0, 'ALTER TABLE `assigned_links` ADD INDEX idx_tl_user (user_id), ALGORITHM=INPLACE, LOCK=NONE', 'DO 0')
  FROM information_schema.statistics
 WHERE table_schema = DATABASE() AND table_name = 'assigned_links' AND seq_in_index = 1 AND column_name = 'user_id');
SET @s = IF((SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = DATABASE() AND table_name = 'assigned_links') = 0, 'DO 0', @s);
PREPARE st FROM @s; EXECUTE st; DEALLOCATE PREPARE st;

-- assigned_links_for_refund (user_id)
SET @s = (SELECT IF(COUNT(*) = 0, 'ALTER TABLE `assigned_links_for_refund` ADD INDEX idx_tl_user (user_id), ALGORITHM=INPLACE, LOCK=NONE', 'DO 0')
  FROM information_schema.statistics
 WHERE table_schema = DATABASE() AND table_name = 'assigned_links_for_refund' AND seq_in_index = 1 AND column_name = 'user_id');
SET @s = IF((SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = DATABASE() AND table_name = 'assigned_links_for_refund') = 0, 'DO 0', @s);
PREPARE st FROM @s; EXECUTE st; DEALLOCATE PREPARE st;

-- set_reminder (user_id)
SET @s = (SELECT IF(COUNT(*) = 0, 'ALTER TABLE `set_reminder` ADD INDEX idx_tl_user (user_id), ALGORITHM=INPLACE, LOCK=NONE', 'DO 0')
  FROM information_schema.statistics
 WHERE table_schema = DATABASE() AND table_name = 'set_reminder' AND seq_in_index = 1 AND column_name = 'user_id');
SET @s = IF((SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = DATABASE() AND table_name = 'set_reminder') = 0, 'DO 0', @s);
PREPARE st FROM @s; EXECUTE st; DEALLOCATE PREPARE st;

-- internship_edit_logs (user_id)
SET @s = (SELECT IF(COUNT(*) = 0, 'ALTER TABLE `internship_edit_logs` ADD INDEX idx_tl_user (user_id), ALGORITHM=INPLACE, LOCK=NONE', 'DO 0')
  FROM information_schema.statistics
 WHERE table_schema = DATABASE() AND table_name = 'internship_edit_logs' AND seq_in_index = 1 AND column_name = 'user_id');
SET @s = IF((SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = DATABASE() AND table_name = 'internship_edit_logs') = 0, 'DO 0', @s);
PREPARE st FROM @s; EXECUTE st; DEALLOCATE PREPARE st;

-- instant_exam_reminder_logs (user_id)
SET @s = (SELECT IF(COUNT(*) = 0, 'ALTER TABLE `instant_exam_reminder_logs` ADD INDEX idx_tl_user (user_id), ALGORITHM=INPLACE, LOCK=NONE', 'DO 0')
  FROM information_schema.statistics
 WHERE table_schema = DATABASE() AND table_name = 'instant_exam_reminder_logs' AND seq_in_index = 1 AND column_name = 'user_id');
SET @s = IF((SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = DATABASE() AND table_name = 'instant_exam_reminder_logs') = 0, 'DO 0', @s);
PREPARE st FROM @s; EXECUTE st; DEALLOCATE PREPARE st;

-- project_submission_reminder_logs (user_id)
SET @s = (SELECT IF(COUNT(*) = 0, 'ALTER TABLE `project_submission_reminder_logs` ADD INDEX idx_tl_user (user_id), ALGORITHM=INPLACE, LOCK=NONE', 'DO 0')
  FROM information_schema.statistics
 WHERE table_schema = DATABASE() AND table_name = 'project_submission_reminder_logs' AND seq_in_index = 1 AND column_name = 'user_id');
SET @s = IF((SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = DATABASE() AND table_name = 'project_submission_reminder_logs') = 0, 'DO 0', @s);
PREPARE st FROM @s; EXECUTE st; DEALLOCATE PREPARE st;

-- one_day_before_batch_start_logs (user_id)
SET @s = (SELECT IF(COUNT(*) = 0, 'ALTER TABLE `one_day_before_batch_start_logs` ADD INDEX idx_tl_user (user_id), ALGORITHM=INPLACE, LOCK=NONE', 'DO 0')
  FROM information_schema.statistics
 WHERE table_schema = DATABASE() AND table_name = 'one_day_before_batch_start_logs' AND seq_in_index = 1 AND column_name = 'user_id');
SET @s = IF((SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = DATABASE() AND table_name = 'one_day_before_batch_start_logs') = 0, 'DO 0', @s);
PREPARE st FROM @s; EXECUTE st; DEALLOCATE PREPARE st;

-- same_day_batch_end_logs (user_id)
SET @s = (SELECT IF(COUNT(*) = 0, 'ALTER TABLE `same_day_batch_end_logs` ADD INDEX idx_tl_user (user_id), ALGORITHM=INPLACE, LOCK=NONE', 'DO 0')
  FROM information_schema.statistics
 WHERE table_schema = DATABASE() AND table_name = 'same_day_batch_end_logs' AND seq_in_index = 1 AND column_name = 'user_id');
SET @s = IF((SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = DATABASE() AND table_name = 'same_day_batch_end_logs') = 0, 'DO 0', @s);
PREPARE st FROM @s; EXECUTE st; DEALLOCATE PREPARE st;

-- store_full_url (user_id)
SET @s = (SELECT IF(COUNT(*) = 0, 'ALTER TABLE `store_full_url` ADD INDEX idx_tl_user (user_id), ALGORITHM=INPLACE, LOCK=NONE', 'DO 0')
  FROM information_schema.statistics
 WHERE table_schema = DATABASE() AND table_name = 'store_full_url' AND seq_in_index = 1 AND column_name = 'user_id');
SET @s = IF((SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = DATABASE() AND table_name = 'store_full_url') = 0, 'DO 0', @s);
PREPARE st FROM @s; EXECUTE st; DEALLOCATE PREPARE st;

-- user_login_activity (user_id, login_date)
SET @s = (SELECT IF(COUNT(*) = 0, 'ALTER TABLE `user_login_activity` ADD INDEX idx_tl_user_date (user_id, login_date), ALGORITHM=INPLACE, LOCK=NONE', 'DO 0')
  FROM information_schema.statistics
 WHERE table_schema = DATABASE() AND table_name = 'user_login_activity' AND seq_in_index = 1 AND column_name = 'user_id');
SET @s = IF((SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = DATABASE() AND table_name = 'user_login_activity') = 0, 'DO 0', @s);
PREPARE st FROM @s; EXECUTE st; DEALLOCATE PREPARE st;

-- attendance_log (user_id, attendance_date)
SET @s = (SELECT IF(COUNT(*) = 0, 'ALTER TABLE `attendance_log` ADD INDEX idx_tl_user_date (user_id, attendance_date), ALGORITHM=INPLACE, LOCK=NONE', 'DO 0')
  FROM information_schema.statistics
 WHERE table_schema = DATABASE() AND table_name = 'attendance_log' AND seq_in_index = 1 AND column_name = 'user_id');
SET @s = IF((SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = DATABASE() AND table_name = 'attendance_log') = 0, 'DO 0', @s);
PREPARE st FROM @s; EXECUTE st; DEALLOCATE PREPARE st;


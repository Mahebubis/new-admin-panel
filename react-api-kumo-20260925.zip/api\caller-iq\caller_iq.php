<?php
/**
 * /api/caller-iq/caller_iq.php  —  Caller IQ analytics for the admin panel
 * ---------------------------------------------------------------------------
 * POST JSON { action, range: { from, to, from_time?, to_time?, all? }, filters: { … } }
 *
 *   overview        every headline number (+ the same-length period before it),
 *                   the trend, type / outcome / duration / SIM splits, the
 *                   weekday × hour heatmap, the agent leaderboard and the
 *                   callback queue — one request paints the Overview tab.
 *   calls           the call log, sorted + paginated  (export=1 → up to 25 000 rows)
 *   numbers         one row per phone number
 *   agents          one row per phone/agent, with a per-bucket sparkline
 *   number_detail   every call with one number, across every agent, all time
 *   match_numbers   which numbers belong to a registered student (best effort)
 *   save_device     name the counselor behind a phone, set a team, hide a test phone
 *   set_outcome     tag / re-tag a call's outcome and notes from the panel
 *
 * Every action applies the same filter set through ciq_filter_sql(), so a number
 * on the Overview always equals the row count of the Call log beside it.
 *
 * "Callback pending" = a MISSED / REJECTED call from a number that nobody has
 * called since (an OUTGOING attempt, or an INCOMING call that connected). It is
 * judged against ALL later calls, not just the selected range — a missed call
 * from last night returned this morning is not pending.
 * ---------------------------------------------------------------------------
 */
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../middleware/auth.php';
require_once __DIR__ . '/ciq_lib.php';

/*
 * Deploy safety. These helpers live in ciq_lib.php, which can lag behind this file when only part
 * of the folder is uploaded — and a missing helper is a PHP fatal, which takes the whole page down.
 * Defining fallbacks here means this file works against any version of the library.
 */
if (!function_exists('ciq_has_col')) {
    function ciq_has_col(mysqli $conn, string $table, string $col): bool
    {
        static $cache = [];
        if (!isset($cache[$table])) {
            $cols = [];
            if ($res = $conn->query("SHOW COLUMNS FROM `" . str_replace('`', '', $table) . "`")) {
                while ($r = $res->fetch_assoc()) $cols[$r['Field']] = true;
            }
            $cache[$table] = $cols;
        }
        return $cache[$table] === [] ? true : isset($cache[$table][$col]);
    }
}

/** Does this table exist yet? Tables are created by ciq_lib.php, which may not be deployed. */
function ciq_table_exists(mysqli $conn, string $table): bool
{
    $res = $conn->query("SHOW TABLES LIKE '" . $conn->real_escape_string($table) . "'");
    return $res && $res->num_rows > 0;
}

/* PHP 8.1+ mysqli throws instead of returning false; see q_all() below. */
mysqli_report(MYSQLI_REPORT_OFF);
set_exception_handler(function (Throwable $e) {
    error_log('[caller-iq] uncaught: ' . $e->getMessage() . ' @ ' . $e->getFile() . ':' . $e->getLine());
    api_error('Caller IQ could not load: ' . $e->getMessage(), 500);
});

$jwt = require_jwt();
require_permission('caller_iq', $jwt);
require_method('POST');
@set_time_limit(120);

$t0     = microtime(true);
$in     = get_json_input();
$action = $in['action'] ?? '';
$f      = is_array($in['filters'] ?? null) ? $in['filters'] : [];

ciq_ensure_schema($conn);

/*
 * Columns added after the first release. ciq_ensure_schema() creates them, but only if the
 * deployed ciq_lib.php is the current one — a half-finished upload used to take the whole page
 * down with "Unknown column 'c.tagged_via' in 'field list'". Every query below asks for these
 * through the expressions here, so a missing column costs that one detail and nothing else.
 */
$CIQ_HAS_TAGGED_VIA = ciq_has_col($conn, 'caller_iq_calls', 'tagged_via');
$CIQ_HAS_SIM_SOURCE = ciq_has_col($conn, 'caller_iq_calls', 'sim_source');
$TAGGED_VIA = $CIQ_HAS_TAGGED_VIA ? 'c.tagged_via' : "''";
$SIM_SOURCE = $CIQ_HAS_SIM_SOURCE ? 'c.sim_source' : "''";
// How long a never-answered call rang (never counted as talk time); NULL until the column exists.
$RING_SEC = ciq_has_col($conn, 'caller_iq_calls', 'ring_sec') ? 'c.ring_sec' : 'NULL';
$CIQ_MISSING_COLS = array_values(array_filter([
    $CIQ_HAS_TAGGED_VIA ? null : 'tagged_via',
    $CIQ_HAS_SIM_SOURCE ? null : 'sim_source',
]));

/* ── Query helpers ─────────────────────────────────────────────────────── */

const CIQ_TEXT_KEYS = ['number', 'number_norm', 'device_id', 'call_type', 'raw_call_type', 'b', 'o', 'label', 'sim_label', 'carrier',
    'outcome', 'outcome_at', 'outcome_source', 'notes', 'call_at', 'first_at', 'last_at', 'last_call_at', 'first_synced_at', 'last_synced_at',
    'last_outcome', 'last_type', 'last_device', 'cb', 'agent_name', 'team', 'device_model', 'app_version'];

/** SUM()/COUNT() come back as strings; turn every numeric column into a number. */
function ciq_row(array $r): array
{
    foreach ($r as $k => $v) {
        if ($v !== null && !in_array($k, CIQ_TEXT_KEYS, true) && is_numeric($v)) $r[$k] = $v + 0;
    }
    return $r;
}

function q_all(mysqli $conn, string $sql): array
{
    $res = $conn->query($sql);
    if (!$res) throw new RuntimeException($conn->error);
    $rows = [];
    while ($row = $res->fetch_assoc()) $rows[] = ciq_row($row);
    return $rows;
}

function q_one(mysqli $conn, string $sql): array
{
    return q_all($conn, $sql)[0] ?? [];
}

function esc(mysqli $conn, $v): string
{
    return "'" . $conn->real_escape_string((string)$v) . "'";
}

/* ── Range ─────────────────────────────────────────────────────────────── */

function ciq_range(mysqli $conn, array $in): array
{
    $r    = is_array($in['range'] ?? null) ? $in['range'] : [];
    $date = fn($v) => (is_string($v) && preg_match('/^\d{4}-\d{2}-\d{2}$/', $v)) ? $v : null;
    $time = fn($v, $d) => (is_string($v) && preg_match('/^\d{2}:\d{2}(:\d{2})?$/', $v)) ? (strlen($v) === 5 ? "$v:" . ($d === '23:59:59' ? '59' : '00') : $v) : $d;

    $today = date('Y-m-d');
    $from  = $date($r['from'] ?? null) ?? $today;
    $to    = $date($r['to'] ?? null) ?? $today;
    if (!empty($r['all'])) {
        $first = q_one($conn, "SELECT DATE(MIN(call_at)) d FROM caller_iq_calls")['d'] ?? null;
        $from  = $first ?: $today;
        $to    = max($to, $today);
    }
    $start = "$from " . $time($r['from_time'] ?? null, '00:00:00');
    $end   = "$to " . $time($r['to_time'] ?? null, '23:59:59');
    if ($start > $end) [$start, $end] = [$end, $start];

    $span = max(1, strtotime($end) - strtotime($start) + 1);
    $gran = $span <= 2 * 86400 ? 'hour' : ($span <= 120 * 86400 ? 'day' : ($span <= 540 * 86400 ? 'week' : 'month'));

    return [
        'start' => $start, 'end' => $end, 'gran' => $gran, 'span' => $span,
        'prev_start' => date('Y-m-d H:i:s', strtotime($start) - $span),
        'prev_end'   => date('Y-m-d H:i:s', strtotime($start) - 1),
    ];
}

function ciq_bucket_sql(string $gran, string $a = 'c'): string
{
    switch ($gran) {
        case 'hour':  return "DATE_FORMAT($a.call_at, '%Y-%m-%d %H:00')";
        case 'week':  return "DATE_FORMAT(DATE_SUB(DATE($a.call_at), INTERVAL WEEKDAY($a.call_at) DAY), '%Y-%m-%d')";
        case 'month': return "DATE_FORMAT($a.call_at, '%Y-%m-01')";
        default:      return "DATE_FORMAT($a.call_at, '%Y-%m-%d')";
    }
}

/** Every bucket in the range, so the chart has no silent gaps on quiet days. */
function ciq_buckets(string $start, string $end, string $gran): array
{
    $t = strtotime($start); $e = strtotime($end); $out = [];
    switch ($gran) {
        case 'hour':  $t = strtotime(date('Y-m-d H:00:00', $t)); $fmt = 'Y-m-d H:00'; $step = '+1 hour'; break;
        case 'week':  $t = strtotime(date('Y-m-d', $t)); $t = strtotime('-' . ((int)date('N', $t) - 1) . ' days', $t); $fmt = 'Y-m-d'; $step = '+1 week'; break;
        case 'month': $t = strtotime(date('Y-m-01', $t)); $fmt = 'Y-m-01'; $step = '+1 month'; break;
        default:      $t = strtotime(date('Y-m-d', $t)); $fmt = 'Y-m-d'; $step = '+1 day';
    }
    while ($t <= $e && count($out) < 2000) { $out[] = date($fmt, $t); $t = strtotime($step, $t); }
    return $out;
}

/* ── Filters ───────────────────────────────────────────────────────────── */

/** Correlated "somebody got back to this number after call c" test. */
function ciq_returned_sql(string $a = 'c'): string
{
    return "EXISTS (SELECT 1 FROM caller_iq_calls o WHERE o.number_norm = $a.number_norm AND o.call_at > $a.call_at
              AND (o.call_type = 'OUTGOING' OR (o.call_type = 'INCOMING' AND o.duration_sec > 0)))";
}

function ciq_first_return_sql(string $a = 'c'): string
{
    return "(SELECT MIN(o.call_at) FROM caller_iq_calls o WHERE o.number_norm = $a.number_norm AND o.call_at > $a.call_at
              AND (o.call_type = 'OUTGOING' OR (o.call_type = 'INCOMING' AND o.duration_sec > 0)))";
}

function ciq_list($v): array
{
    return is_array($v) ? array_values(array_filter($v, fn($x) => is_scalar($x) && $x !== '')) : [];
}

function ciq_filter_sql(mysqli $conn, array $f, string $a = 'c'): string
{
    $w  = [];
    $in = fn(array $vals) => implode(',', array_map(fn($v) => esc($conn, $v), $vals));

    $types = array_values(array_intersect(ciq_list($f['types'] ?? []), CIQ_TYPES));
    if ($types) $w[] = "$a.call_type IN (" . $in($types) . ")";

    // '__none__' stands for device_id '' — phones on the original app build, which send no id.
    $devices = array_map(fn($d) => $d === '__none__' ? '' : $d, ciq_list($f['devices'] ?? []));
    if ($devices) {
        $w[] = "$a.device_id IN (" . $in(array_unique($devices)) . ")";
    } else {
        // Phones hidden in the panel (test handsets) stay out unless picked by name.
        $w[] = "$a.device_id NOT IN (SELECT device_id FROM caller_iq_devices WHERE is_hidden = 1)";
    }

    $sims = array_map('intval', ciq_list($f['sims'] ?? []));
    if ($sims) $w[] = "COALESCE($a.sim_slot, 0) IN (" . implode(',', $sims) . ")";

    $outs = ciq_list($f['outcomes'] ?? []);
    if ($outs) {
        $named = array_values(array_filter($outs, fn($o) => $o !== '__none__'));
        $or = [];
        if ($named) $or[] = "$a.outcome IN (" . $in($named) . ")";
        if (count($named) !== count($outs)) $or[] = "$a.outcome IS NULL";
        $w[] = '(' . implode(' OR ', $or) . ')';
    }

    $conn_ = $f['connected'] ?? '';
    if ($conn_ === 'yes') $w[] = "$a.duration_sec > 0";
    if ($conn_ === 'no')  $w[] = "$a.duration_sec = 0";

    if (isset($f['min_dur']) && is_numeric($f['min_dur'])) $w[] = "$a.duration_sec >= " . max(0, (int)$f['min_dur']);
    if (isset($f['max_dur']) && is_numeric($f['max_dur'])) $w[] = "$a.duration_sec <= " . max(0, (int)$f['max_dur']);

    $hf = $f['hour_from'] ?? ''; $ht = $f['hour_to'] ?? '';
    if (is_numeric($hf) || is_numeric($ht)) {
        $hf = is_numeric($hf) ? max(0, min(23, (int)$hf)) : 0;
        $ht = is_numeric($ht) ? max(0, min(23, (int)$ht)) : 23;
        $w[] = $hf <= $ht ? "HOUR($a.call_at) BETWEEN $hf AND $ht" : "(HOUR($a.call_at) >= $hf OR HOUR($a.call_at) <= $ht)";
    }

    $days = array_values(array_filter(array_map('intval', ciq_list($f['weekdays'] ?? [])), fn($d) => $d >= 0 && $d <= 6));
    if ($days) $w[] = "WEEKDAY($a.call_at) IN (" . implode(',', $days) . ")";

    $q = trim((string)($f['q'] ?? ''));
    if ($q !== '') {
        $digits = preg_replace('/\D+/', '', $q);
        $like   = $conn->real_escape_string(addcslashes($q, '%_'));
        $or     = ["$a.outcome LIKE '%$like%'", "$a.notes LIKE '%$like%'", "$a.sim_label LIKE '%$like%'",
                   "$a.device_id IN (SELECT device_id FROM caller_iq_devices WHERE agent_name LIKE '%$like%' OR team LIKE '%$like%')"];
        if (strlen($digits) >= 3) array_unshift($or, "$a.number_norm LIKE '%" . (strlen($digits) > 10 ? substr($digits, -10) : $digits) . "%'");
        else $or[] = "$a.number LIKE '%$like%'";
        $w[] = '(' . implode(' OR ', $or) . ')';
    }

    $cb = $f['callback'] ?? '';
    if ($cb === 'pending' || $cb === 'returned') {
        $w[] = "$a.call_type IN ('MISSED','REJECTED') AND $a.number_norm <> '' AND " . ($cb === 'pending' ? 'NOT ' : '') . ciq_returned_sql($a);
    }

    $rep = $f['repeat'] ?? '';
    if ($rep === 'repeat' || $rep === 'first') {
        $sub = "SELECT number_norm FROM (SELECT number_norm FROM caller_iq_calls WHERE number_norm <> '' GROUP BY number_norm HAVING COUNT(*) > 1) rn";
        $w[] = $rep === 'repeat' ? "$a.number_norm IN ($sub)" : "$a.number_norm NOT IN ($sub)";
    }

    $team = trim((string)($f['team'] ?? ''));
    if ($team !== '') $w[] = "$a.device_id IN (SELECT device_id FROM caller_iq_devices WHERE team = " . esc($conn, $team) . ")";

    return $w ? ' AND ' . implode(' AND ', $w) : '';
}

function ciq_where(mysqli $conn, string $start, string $end, string $fsql, string $a = 'c'): string
{
    return "$a.call_at BETWEEN " . esc($conn, $start) . " AND " . esc($conn, $end) . $fsql;
}

const CIQ_TOTALS = "COUNT(*) total,
    COALESCE(SUM(c.call_type = 'INCOMING'), 0) incoming,
    COALESCE(SUM(c.call_type = 'OUTGOING'), 0) outgoing,
    COALESCE(SUM(c.call_type = 'MISSED'), 0) missed,
    COALESCE(SUM(c.call_type = 'REJECTED'), 0) rejected,
    COALESCE(SUM(c.call_type NOT IN ('INCOMING','OUTGOING','MISSED','REJECTED')), 0) other,
    COALESCE(SUM(c.duration_sec > 0), 0) connected,
    COALESCE(SUM(c.call_type = 'OUTGOING' AND c.duration_sec > 0), 0) out_connected,
    COALESCE(SUM(c.duration_sec), 0) talk_sec,
    COALESCE(MAX(c.duration_sec), 0) longest_sec,
    COUNT(DISTINCT NULLIF(c.number_norm, '')) unique_numbers,
    COALESCE(SUM(c.outcome IS NOT NULL), 0) tagged,
    COALESCE(SUM(c.sim_slot IS NULL), 0) sim_unknown,
    COUNT(DISTINCT c.device_id) agents";

/* ── Devices ───────────────────────────────────────────────────────────── */

function ciq_devices(mysqli $conn): array
{
    $rows = q_all($conn, "SELECT d.*, (SELECT COUNT(*) FROM caller_iq_calls c WHERE c.device_id = d.device_id) all_calls
                          FROM caller_iq_devices d ORDER BY d.is_hidden, d.last_seen_at DESC");
    $now = time();

    /* The newest build any phone runs is the one to be on. A phone behind it is flagged, with no
       version number here to keep up to date by hand. */
    $latest = '';
    foreach ($rows as $d) {
        $v = (string)($d['app_version'] ?? '');
        if ($v !== '' && ($latest === '' || version_compare($v, $latest, '>'))) $latest = $v;
    }

    foreach ($rows as &$d) {
        /* Alive = a call uploaded OR the phone checked in, whichever is later — so a phone that is
           installed and healthy but has not made a call today still reads as reachable. */
        $seen  = strtotime((string)$d['last_seen_at']) ?: 0;
        $chk   = !empty($d['last_checkin_at']) ? (strtotime((string)$d['last_checkin_at']) ?: 0) : 0;
        $age   = $now - max($seen, $chk);
        $d['status'] = $age <= 3 * 3600 ? 'online' : ($age <= 48 * 3600 ? 'idle' : 'offline');
        $d['label']  = ciq_device_label($d);

        /* The phone's own setup report. Absent on builds before 1.4, which never send one — and
           that must read as "unknown", never as "off". */
        $h = !empty($d['health_json']) ? json_decode((string)$d['health_json'], true) : null;
        unset($d['health_json']);
        $d['health'] = is_array($h) ? $h : null;
        $steps = is_array($h['steps'] ?? null) ? $h['steps'] : [];
        $d['setup_left'] = is_array($h)
            ? count(array_filter($steps, fn($s) => !empty($s['required']) && ($s['status'] ?? '') === 'todo'))
            : null;
        $d['setup_unconfirmed'] = is_array($h)
            ? count(array_filter($steps, fn($s) => !empty($s['required']) && ($s['status'] ?? '') === 'unknown'))
            : null;

        $d['popup_state']    = $d['popup_ok'] === null ? 'unknown' : ((int)$d['popup_ok'] ? 'on' : 'off');
        $d['latest_version'] = $latest;
        $d['outdated']       = ($d['app_version'] ?? '') !== '' && $latest !== ''
                               && version_compare((string)$d['app_version'], $latest, '<');
    }
    return $rows;
}

function ciq_device_label(array $d): string
{
    if (($d['agent_name'] ?? '') !== '') return $d['agent_name'];
    if (($d['device_id'] ?? '') === '') return 'Unidentified phone';
    return ($d['device_model'] ?? '') !== '' ? $d['device_model'] : 'Phone ' . substr($d['device_id'], 0, 6);
}

function ciq_ingest_url(): string
{
    $host = $_SERVER['HTTP_HOST'] ?? 'cit3.internshipstudio.com';
    $dir  = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? '/api/caller-iq/caller_iq.php')), '/');
    return "https://$host$dir/log_call.php";
}

/* ── Students by phone (best effort — never fails the request) ─────────── */

function ciq_match_students(mysqli $conn, array $norms): array
{
    $norms = array_slice(array_values(array_unique(array_filter($norms, fn($n) => is_string($n) && preg_match('/^\d{5,10}$/', $n)))), 0, 150);
    if (!$norms) return [];
    $variants = [];
    foreach ($norms as $n) {
        foreach ([$n, "91$n", "+91$n", "0$n", "+91 $n", "91 $n"] as $v) $variants[] = esc($conn, $v);
    }
    $res = $conn->query("SELECT user_id, name, email, phone FROM users WHERE phone IN (" . implode(',', $variants) . ") LIMIT 600");
    if (!$res) return [];
    $out = [];
    while ($r = $res->fetch_assoc()) {
        $k = ciq_norm_number((string)$r['phone']);
        // `phone` is the value exactly as `users` stores it, which is what the panel's global
        // search matches on (it compares email / phone exactly, never LIKE).
        if ($k !== '' && !isset($out[$k])) $out[$k] = ['user_id' => (int)$r['user_id'], 'name' => $r['name'], 'email' => $r['email'], 'phone' => $r['phone']];
    }
    return $out;
}

/* ── Actions ───────────────────────────────────────────────────────────── */

switch ($action) {

case 'overview': {
    $r    = ciq_range($conn, $in);
    $fsql = ciq_filter_sql($conn, $f);
    $W    = ciq_where($conn, $r['start'], $r['end'], $fsql);
    $PW   = ciq_where($conn, $r['prev_start'], $r['prev_end'], $fsql);

    $totals = q_one($conn, "SELECT " . CIQ_TOTALS . " FROM caller_iq_calls c WHERE $W");
    $prev   = q_one($conn, "SELECT " . CIQ_TOTALS . " FROM caller_iq_calls c WHERE $PW");

    $cb = q_one($conn, "SELECT COUNT(*) missed_calls,
            COALESCE(SUM(t.cb IS NULL), 0) pending_calls,
            COUNT(DISTINCT IF(t.cb IS NULL, t.number_norm, NULL)) pending_numbers,
            COALESCE(SUM(t.cb IS NOT NULL), 0) returned_calls,
            COALESCE(ROUND(AVG(TIMESTAMPDIFF(SECOND, t.call_at, t.cb))), 0) avg_return_sec
        FROM (SELECT c.number_norm, c.call_at, " . ciq_first_return_sql() . " cb
              FROM caller_iq_calls c WHERE $W AND c.call_type IN ('MISSED','REJECTED') AND c.number_norm <> '') t");

    $B = ciq_bucket_sql($r['gran']);
    $seriesRows = q_all($conn, "SELECT $B b,
            SUM(c.call_type = 'INCOMING') incoming, SUM(c.call_type = 'OUTGOING') outgoing,
            SUM(c.call_type = 'MISSED') missed, SUM(c.call_type = 'REJECTED') rejected,
            SUM(c.call_type NOT IN ('INCOMING','OUTGOING','MISSED','REJECTED')) other,
            SUM(c.duration_sec > 0) connected, SUM(c.duration_sec) talk_sec, COUNT(*) total
        FROM caller_iq_calls c WHERE $W GROUP BY b ORDER BY b");
    $byB = array_column($seriesRows, null, 'b');
    $zero = ['incoming' => 0, 'outgoing' => 0, 'missed' => 0, 'rejected' => 0, 'other' => 0, 'connected' => 0, 'talk_sec' => 0, 'total' => 0];
    $series = [];
    foreach (ciq_buckets($r['start'], $r['end'], $r['gran']) as $b) $series[] = ['b' => $b] + ($byB[$b] ?? $zero);

    $outcomes = q_all($conn, "SELECT COALESCE(c.outcome, '') o, COUNT(*) n, SUM(c.duration_sec) talk_sec
                              FROM caller_iq_calls c WHERE $W GROUP BY o ORDER BY n DESC");

    $heat = q_all($conn, "SELECT WEEKDAY(c.call_at) d, HOUR(c.call_at) h, COUNT(*) n,
                              SUM(c.call_type IN ('MISSED','REJECTED')) missed, SUM(c.duration_sec > 0) connected
                          FROM caller_iq_calls c WHERE $W GROUP BY d, h");

    $durations = q_all($conn, "SELECT CASE WHEN c.duration_sec = 0 THEN 0 WHEN c.duration_sec <= 30 THEN 1 WHEN c.duration_sec <= 60 THEN 2
                                   WHEN c.duration_sec <= 180 THEN 3 WHEN c.duration_sec <= 300 THEN 4 WHEN c.duration_sec <= 600 THEN 5 ELSE 6 END k,
                                   COUNT(*) n, SUM(c.call_type = 'INCOMING') incoming, SUM(c.call_type = 'OUTGOING') outgoing
                               FROM caller_iq_calls c WHERE $W GROUP BY k ORDER BY k");

    /* How tags are arriving. The post-call popup should dominate once the phones are on v1.2;
       a high "panel" share means counselors are not tagging on the phone at all. */
    $tagging = q_one($conn, "SELECT
            COALESCE(SUM($TAGGED_VIA = 'popup'), 0) via_popup,
            COALESCE(SUM($TAGGED_VIA = 'notification'), 0) via_notification,
            COALESCE(SUM($TAGGED_VIA = 'app'), 0) via_app,
            COALESCE(SUM(c.outcome IS NOT NULL AND c.outcome_source LIKE 'admin%'), 0) via_panel,
            COALESCE(SUM(c.outcome IS NOT NULL AND $TAGGED_VIA = '' AND c.outcome_source NOT LIKE 'admin%'), 0) via_legacy,
            COALESCE(ROUND(AVG(IF(c.outcome_at IS NOT NULL AND c.outcome_at >= c.call_at,
                TIMESTAMPDIFF(SECOND, c.call_at, c.outcome_at), NULL))), 0) avg_tag_sec,
            COALESCE(SUM(c.outcome_at IS NOT NULL AND TIMESTAMPDIFF(SECOND, c.call_at, c.outcome_at) BETWEEN 0 AND 300), 0) tagged_fast
        FROM caller_iq_calls c WHERE $W");

    /* Which evidence identified the SIM — 'unknown' rows are the ones to chase. */
    $simSources = q_all($conn, "SELECT IFNULL(NULLIF($SIM_SOURCE, ''), 'legacy') src, COUNT(*) n
                                FROM caller_iq_calls c WHERE $W GROUP BY src ORDER BY n DESC");

    $sims = q_all($conn, "SELECT COALESCE(c.sim_slot, 0) slot, MAX(c.sim_label) label, MAX(c.carrier) carrier, COUNT(*) total,
                              SUM(c.call_type = 'INCOMING') incoming, SUM(c.call_type = 'OUTGOING') outgoing,
                              SUM(c.call_type IN ('MISSED','REJECTED')) missed, SUM(c.duration_sec) talk_sec
                          FROM caller_iq_calls c WHERE $W GROUP BY slot ORDER BY slot");

    $agents = q_all($conn, "SELECT c.device_id, " . CIQ_TOTALS . ", MAX(c.call_at) last_call_at
                            FROM caller_iq_calls c WHERE $W GROUP BY c.device_id ORDER BY total DESC");

    $queue = q_all($conn, "SELECT c.number_norm, MAX(c.number) number, COUNT(*) attempts, MIN(c.call_at) first_at, MAX(c.call_at) last_at,
                               SUBSTRING_INDEX(GROUP_CONCAT(c.device_id ORDER BY c.call_at DESC SEPARATOR '|'), '|', 1) last_device
                           FROM caller_iq_calls c
                           WHERE $W AND c.call_type IN ('MISSED','REJECTED') AND c.number_norm <> '' AND NOT " . ciq_returned_sql() . "
                           GROUP BY c.number_norm ORDER BY last_at DESC LIMIT 25");

    /* SIMs about to go dead — a lapsed SIM stops a counselor working, so it is worth saying on
       every tab, not only inside the SIM register. Dates are compared on PHP's clock. */
    $simAlerts = ['expired' => 0, 'soon' => 0];
    if (ciq_table_exists($conn, 'caller_iq_sims')) {
        $todayS = esc($conn, date('Y-m-d'));
        $soonS  = esc($conn, date('Y-m-d', time() + 5 * 86400));
        $simAlerts = q_one($conn, "SELECT
                COALESCE(SUM(valid_till < $todayS), 0) expired,
                COALESCE(SUM(valid_till >= $todayS AND valid_till <= $soonS), 0) soon
            FROM caller_iq_sims s
            WHERE valid_till IS NOT NULL
              AND s.device_id NOT IN (SELECT device_id FROM caller_iq_devices WHERE is_hidden = 1)") ?: $simAlerts;
    }

    $meta = q_one($conn, "SELECT COUNT(*) all_calls, MIN(call_at) first_call_at, MAX(call_at) last_call_at, MAX(last_synced_at) last_sync_at FROM caller_iq_calls");
    $known = q_all($conn, "SELECT DISTINCT outcome FROM caller_iq_calls WHERE outcome IS NOT NULL ORDER BY outcome LIMIT 60");
    $teams = q_all($conn, "SELECT DISTINCT team FROM caller_iq_devices WHERE team <> '' ORDER BY team");

    api_success([
        'range'     => ['start' => $r['start'], 'end' => $r['end'], 'granularity' => $r['gran'], 'prev_start' => $r['prev_start'], 'prev_end' => $r['prev_end']],
        'totals'    => $totals + $cb,
        'prev'      => $prev,
        'series'    => $series,
        'outcomes'  => $outcomes,
        'heatmap'   => $heat,
        'durations' => $durations,
        'sims'      => $sims,
        'tagging'   => $tagging,
        'sim_sources' => $simSources,
        'sim_alerts'  => $simAlerts,
        'agents'    => $agents,
        'queue'     => $queue,
        'devices'   => ciq_devices($conn),
        'outcome_options' => array_column($known, 'outcome'),
        'teams'     => array_column($teams, 'team'),
        'meta'      => $meta,
        'ingest_url'   => ciq_ingest_url(),
        // Non-empty when the database is still missing a column this build expects: the page keeps
        // working, minus that detail, and says so rather than failing.
        'schema_missing' => $CIQ_MISSING_COLS,
        'generated_at' => date('Y-m-d H:i:s'),
        'took_ms'   => (int)round((microtime(true) - $t0) * 1000),
    ]);
}

/*
 * Calls in progress right now, for the dashboard's "Live now" strip. Polled every few seconds, so
 * it stays one small query with no joins beyond the device names.
 *
 * Ageing rules — a live row only disappears for a reason:
 *   ringing    dropped after 3 minutes. No phone rings that long; the "ended" event was lost.
 *   connected  kept, but flagged stale once the phone has been silent for 3 minutes (the app
 *              heartbeats every 45s), and dropped after 6 hours, which is a stuck row, not a call.
 *   ended      shown for 45 seconds so the panel can animate it away, then dropped.
 */
case 'live': {
    /* The live table is created by ciq_lib.php. Say so plainly instead of throwing an SQL error at
       a panel that polls this every few seconds. */
    if (!ciq_table_exists($conn, 'caller_iq_live')) {
        api_error('Live calls need the latest react-api/api/caller-iq/ciq_lib.php deployed', 400);
    }

    /* Every timestamp in this table is written with PHP's clock (Asia/Kolkata), and MySQL on this
       host runs a different one — so the ages are measured against a PHP "now" passed in, never
       against MySQL's NOW(), which would age every row by the offset between the two clocks. */
    $t     = time();
    $now   = date('Y-m-d H:i:s', $t);
    $ringOld = esc($conn, date('Y-m-d H:i:s', $t - 180));
    $connOld = esc($conn, date('Y-m-d H:i:s', $t - 6 * 3600));
    $endOld  = esc($conn, date('Y-m-d H:i:s', $t - 45));
    $nowS  = esc($conn, $now);

    $rows = q_all($conn, "SELECT l.*,
            TIMESTAMPDIFF(SECOND, l.started_at, COALESCE(l.ended_at, $nowS)) elapsed_sec,
            TIMESTAMPDIFF(SECOND, l.answered_at, COALESCE(l.ended_at, $nowS)) talk_sec,
            TIMESTAMPDIFF(SECOND, l.updated_at, $nowS) silent_sec,
            d.agent_name, d.team, d.device_model, d.is_hidden
        FROM caller_iq_live l
        LEFT JOIN caller_iq_devices d ON d.device_id = l.device_id
        WHERE (l.state = 'ringing'   AND l.updated_at >= $ringOld)
           OR (l.state = 'connected' AND l.started_at >= $connOld)
           OR (l.state = 'ended'     AND l.ended_at   >= $endOld)
        ORDER BY l.started_at ASC");

    $out = [];
    foreach ($rows as $r) {
        if ((int)($r['is_hidden'] ?? 0) === 1) continue;    // test handsets stay out of the panel
        $r['label'] = ciq_device_label([
            'agent_name' => $r['agent_name'] ?? '',
            'device_id' => $r['device_id'],
            'device_model' => $r['device_model'] ?? '',
        ]);
        $r['stale'] = ($r['state'] === 'connected' && (int)$r['silent_sec'] > 180);
        $r['elapsed_sec'] = max(0, (int)$r['elapsed_sec']);
        $r['talk_sec'] = $r['answered_at'] ? max(0, (int)$r['talk_sec']) : null;
        /* Once the phone has read the call log it sends the real talk time. That is the only
           trustworthy figure for an outgoing call, where "off hook" covers ringing as well. */
        if (isset($r['duration_sec']) && $r['duration_sec'] !== null) $r['talk_sec'] = max(0, (int)$r['duration_sec']);
        unset($r['is_hidden'], $r['device_model'], $r['agent_name']);
        $out[] = $r;
    }

    /*
     * Who the number belongs to and how often we have called it before. This is the only expensive
     * part (matching a phone against `users`), and it cannot change while the same call is up, so
     * the panel asks for it once per new number rather than on every poll.
     */
    $students = [];
    $history  = [];
    $norms = !empty($in['with_context'])
        ? array_values(array_unique(array_filter(array_column($out, 'number_norm'))))
        : [];
    if ($norms) {
        $students = ciq_match_students($conn, $norms);
        $list = implode(',', array_map(fn($n) => esc($conn, $n), $norms));
        foreach (q_all($conn, "SELECT number_norm, COUNT(*) calls, MAX(call_at) last_at,
                                      SUBSTRING_INDEX(GROUP_CONCAT(COALESCE(outcome, '') ORDER BY (outcome IS NULL), call_at DESC SEPARATOR '~|~'), '~|~', 1) last_outcome
                               FROM caller_iq_calls WHERE number_norm IN ($list) GROUP BY number_norm") as $h) {
            $history[$h['number_norm']] = $h;
        }
    }

    api_success([
        'live' => $out,
        'students' => (object)$students,
        'history' => (object)$history,
        'has_context' => !empty($in['with_context']),
        'server_time' => $now,
    ]);
}

case 'calls': {
    $r    = ciq_range($conn, $in);
    $W    = ciq_where($conn, $r['start'], $r['end'], ciq_filter_sql($conn, $f));
    $sorts = ['time' => 'c.call_at', 'duration' => 'c.duration_sec', 'number' => 'c.number_norm', 'type' => 'c.call_type',
              'agent' => 'd.agent_name', 'outcome' => 'c.outcome', 'sim' => 'c.sim_slot'];
    $sort = $sorts[$in['sort'] ?? 'time'] ?? 'c.call_at';
    $dir  = strtolower($in['dir'] ?? 'desc') === 'asc' ? 'ASC' : 'DESC';
    $export = !empty($in['export']);
    $pp   = $export ? 25000 : max(10, min(200, (int)($in['per_page'] ?? 25)));
    $page = $export ? 1 : max(1, (int)($in['page'] ?? 1));
    $off  = ($page - 1) * $pp;

    $total = (int)(q_one($conn, "SELECT COUNT(*) n FROM caller_iq_calls c WHERE $W")['n'] ?? 0);
    $rows  = q_all($conn, "SELECT c.id, c.device_id, c.number, c.number_norm, c.call_type, c.raw_call_type, c.duration_sec, $RING_SEC ring_sec, c.call_at,
                               c.sim_slot, c.sim_label, c.carrier, $SIM_SOURCE sim_source, $TAGGED_VIA tagged_via, c.outcome, c.outcome_at, c.outcome_source, c.notes,
                               c.first_synced_at, c.last_synced_at, c.sync_count
                           FROM caller_iq_calls c LEFT JOIN caller_iq_devices d ON d.device_id = c.device_id
                           WHERE $W ORDER BY $sort $dir, c.id DESC LIMIT $off, $pp");

    if (!$export && $rows) {
        // All-time call count per number on this page, and whether each missed call was ever returned.
        $norms = array_values(array_unique(array_filter(array_column($rows, 'number_norm'))));
        $counts = $norms ? array_column(q_all($conn, "SELECT number_norm, COUNT(*) n FROM caller_iq_calls
                                                      WHERE number_norm IN (" . implode(',', array_map(fn($n) => esc($conn, $n), $norms)) . ")
                                                      GROUP BY number_norm"), 'n', 'number_norm') : [];
        $missIds = array_column(array_filter($rows, fn($x) => in_array($x['call_type'], ['MISSED', 'REJECTED'], true) && $x['number_norm'] !== ''), 'id');
        $ret = $missIds ? array_column(q_all($conn, "SELECT c.id, " . ciq_first_return_sql() . " cb FROM caller_iq_calls c WHERE c.id IN (" . implode(',', array_map('intval', $missIds)) . ")"), 'cb', 'id') : [];
        foreach ($rows as &$x) {
            $x['number_calls'] = (int)($counts[$x['number_norm']] ?? 1);
            if (array_key_exists($x['id'], $ret)) $x['returned_at'] = $ret[$x['id']];
        }
        unset($x);
    }

    api_success(['rows' => $rows, 'total' => $total, 'page' => $page, 'per_page' => $pp,
                 'took_ms' => (int)round((microtime(true) - $t0) * 1000)]);
}

case 'numbers': {
    $r = ciq_range($conn, $in);
    $W = ciq_where($conn, $r['start'], $r['end'], ciq_filter_sql($conn, $f));
    $sorts = ['total' => 'total', 'last' => 'last_at', 'talk' => 'talk_sec', 'missed' => 'missed', 'incoming' => 'incoming', 'outgoing' => 'outgoing', 'agents' => 'agents', 'number' => 'c.number_norm'];
    $sort = $sorts[$in['sort'] ?? 'last'] ?? 'last_at';
    $dir  = strtolower($in['dir'] ?? 'desc') === 'asc' ? 'ASC' : 'DESC';
    $pp   = max(10, min(200, (int)($in['per_page'] ?? 25)));
    $page = max(1, (int)($in['page'] ?? 1));
    $off  = ($page - 1) * $pp;
    $minCalls = max(0, (int)($in['min_calls'] ?? 0));
    $having = $minCalls > 1 ? "HAVING COUNT(*) >= $minCalls" : '';

    $total = (int)(q_one($conn, "SELECT COUNT(*) n FROM (SELECT c.number_norm FROM caller_iq_calls c WHERE $W AND c.number_norm <> '' GROUP BY c.number_norm $having) t")['n'] ?? 0);
    $rows = q_all($conn, "SELECT c.number_norm, MAX(c.number) number, COUNT(*) total,
            SUM(c.call_type = 'INCOMING') incoming, SUM(c.call_type = 'OUTGOING') outgoing,
            SUM(c.call_type IN ('MISSED','REJECTED')) missed, SUM(c.duration_sec > 0) connected, SUM(c.duration_sec) talk_sec,
            MIN(c.call_at) first_at, MAX(c.call_at) last_at, COUNT(DISTINCT c.device_id) agents,
            SUBSTRING_INDEX(GROUP_CONCAT(COALESCE(c.outcome, '') ORDER BY (c.outcome IS NULL), c.call_at DESC SEPARATOR '~|~'), '~|~', 1) last_outcome,
            SUBSTRING_INDEX(GROUP_CONCAT(c.call_type ORDER BY c.call_at DESC), ',', 1) last_type,
            SUBSTRING_INDEX(GROUP_CONCAT(c.device_id ORDER BY c.call_at DESC SEPARATOR '|'), '|', 1) last_device
        FROM caller_iq_calls c WHERE $W AND c.number_norm <> ''
        GROUP BY c.number_norm $having ORDER BY $sort $dir LIMIT $off, $pp");

    if ($rows) {
        $list = implode(',', array_map(fn($x) => esc($conn, $x['number_norm']), $rows));
        $pending = array_flip(array_column(q_all($conn, "SELECT DISTINCT c.number_norm FROM caller_iq_calls c
            WHERE c.number_norm IN ($list) AND c.call_type IN ('MISSED','REJECTED') AND NOT " . ciq_returned_sql()), 'number_norm'));
        foreach ($rows as &$x) $x['pending'] = isset($pending[$x['number_norm']]);
        unset($x);
    }
    api_success(['rows' => $rows, 'total' => $total, 'page' => $page, 'per_page' => $pp]);
}

case 'agents': {
    $r    = ciq_range($conn, $in);
    $fsql = ciq_filter_sql($conn, $f);
    $W    = ciq_where($conn, $r['start'], $r['end'], $fsql);
    $PW   = ciq_where($conn, $r['prev_start'], $r['prev_end'], $fsql);
    $stats = array_column(q_all($conn, "SELECT c.device_id, " . CIQ_TOTALS . ", MAX(c.call_at) last_call_at FROM caller_iq_calls c WHERE $W GROUP BY c.device_id"), null, 'device_id');
    $prev  = array_column(q_all($conn, "SELECT c.device_id, COUNT(*) total, COALESCE(SUM(c.duration_sec), 0) talk_sec, COALESCE(SUM(c.duration_sec > 0), 0) connected FROM caller_iq_calls c WHERE $PW GROUP BY c.device_id"), null, 'device_id');
    $pend  = array_column(q_all($conn, "SELECT c.device_id, COUNT(DISTINCT c.number_norm) n FROM caller_iq_calls c
                                        WHERE $W AND c.call_type IN ('MISSED','REJECTED') AND c.number_norm <> '' AND NOT " . ciq_returned_sql() . " GROUP BY c.device_id"), 'n', 'device_id');
    $B = ciq_bucket_sql($r['gran']);
    $spark = [];
    foreach (q_all($conn, "SELECT c.device_id, $B b, COUNT(*) n FROM caller_iq_calls c WHERE $W GROUP BY c.device_id, b") as $s) {
        $spark[$s['device_id']][$s['b']] = $s['n'];
    }
    $buckets = ciq_buckets($r['start'], $r['end'], $r['gran']);
    $out = [];
    foreach (ciq_devices($conn) as $d) {
        $id = $d['device_id'];
        $d['stats'] = $stats[$id] ?? null;
        $d['prev'] = $prev[$id] ?? null;
        $d['pending_callbacks'] = (int)($pend[$id] ?? 0);
        $d['spark'] = array_map(fn($b) => (int)($spark[$id][$b] ?? 0), $buckets);
        $out[] = $d;
    }
    api_success(['agents' => $out, 'granularity' => $r['gran'], 'buckets' => $buckets]);
}

case 'number_detail': {
    $norm = preg_replace('/\D+/', '', (string)($in['number_norm'] ?? ''));
    $raw  = trim((string)($in['number'] ?? ''));
    if ($norm === '' && $raw === '') api_error('number_norm or number is required');
    $cond = $norm !== '' ? "c.number_norm = " . esc($conn, $norm) : "c.number = " . esc($conn, $raw);

    $stats = q_one($conn, "SELECT " . CIQ_TOTALS . ", MIN(c.call_at) first_at, MAX(c.call_at) last_at FROM caller_iq_calls c WHERE $cond");
    $calls = q_all($conn, "SELECT c.id, c.device_id, c.number, c.number_norm, c.call_type, c.raw_call_type, c.duration_sec, c.call_at,
                               c.sim_slot, c.sim_label, c.carrier, $SIM_SOURCE sim_source, $TAGGED_VIA tagged_via, c.outcome, c.outcome_at, c.outcome_source, c.notes, c.last_synced_at
                           FROM caller_iq_calls c WHERE $cond ORDER BY c.call_at DESC LIMIT 300");
    $pending = $norm !== '' ? (int)(q_one($conn, "SELECT COUNT(*) n FROM caller_iq_calls c WHERE $cond AND c.call_type IN ('MISSED','REJECTED') AND NOT " . ciq_returned_sql())['n'] ?? 0) : 0;
    $student = $norm !== '' ? (ciq_match_students($conn, [$norm])[$norm] ?? null) : null;
    api_success(['stats' => $stats, 'calls' => $calls, 'pending_calls' => $pending, 'student' => $student]);
}

/*
 * The SIM register: every SIM any phone has used, with what it cost to keep running and how long
 * that lasts. Android tells an app nothing about a prepaid balance or a plan's validity — there is
 * no API for it on any version — so the plan itself is what somebody recorded here, while the SIM,
 * its slot, its carrier and its usage come from the calls themselves.
 */
case 'sims': {
    $r = ciq_range($conn, $in);
    $W = ciq_where($conn, $r['start'], $r['end'], ciq_filter_sql($conn, $f));
    $today = date('Y-m-d');

    // Usage per SIM in the chosen range, so an expiring SIM can be weighed by how much it is used.
    $usage = [];
    foreach (q_all($conn, "SELECT c.device_id, COALESCE(c.sim_slot, 0) slot, COUNT(*) calls,
                                  COALESCE(SUM(c.duration_sec), 0) talk_sec, MAX(c.call_at) last_call_at
                           FROM caller_iq_calls c WHERE $W GROUP BY c.device_id, slot") as $u) {
        $usage[$u['device_id'] . '|' . $u['slot']] = $u;
    }

    /*
     * A credit signal Android will not give us, taken from the calls themselves.
     *
     * When a prepaid SIM runs dry the network stops connecting its outgoing calls: they end at
     * zero seconds, every time, while the other SIM in the same phone keeps working. That pattern
     * is visible in data we already hold, so a SIM that has tried repeatedly and connected nothing
     * is flagged as probably out of credit. It is evidence, not a balance — hence "check", never
     * "empty".
     */
    $sinceOut = esc($conn, date('Y-m-d H:i:s', time() - 3 * 86400));
    $health = [];
    foreach (q_all($conn, "SELECT c.device_id, COALESCE(c.sim_slot, 0) slot,
                                  COALESCE(SUM(c.call_type = 'OUTGOING'), 0) out_calls,
                                  COALESCE(SUM(c.call_type = 'OUTGOING' AND c.duration_sec > 0), 0) out_connected,
                                  MAX(IF(c.call_type = 'OUTGOING' AND c.duration_sec > 0, c.call_at, NULL)) last_connected_out
                           FROM caller_iq_calls c WHERE c.call_at >= $sinceOut GROUP BY c.device_id, slot") as $h) {
        $health[$h['device_id'] . '|' . $h['slot']] = $h;
    }

    $devices = array_column(ciq_devices($conn), null, 'device_id');
    $rows = q_all($conn, "SELECT * FROM caller_iq_sims ORDER BY device_id, slot");

    $out = [];
    foreach ($rows as $s) {
        $dev = $devices[$s['device_id']] ?? null;
        if ($dev && (int)($dev['is_hidden'] ?? 0) === 1) continue;
        $u = $usage[$s['device_id'] . '|' . $s['slot']] ?? null;

        /*
         * Validity: what a person recorded wins, and the carrier's own USSD reply fills the gap.
         * Measured in whole days against PHP's clock — MySQL's differs on this host and would
         * shift every expiry by hours.
         */
        $till = !empty($s['valid_till']) ? $s['valid_till'] : ($s['auto_valid_till'] ?? null);
        $days = null;
        $status = 'unknown';
        if (!empty($till)) {
            $days = (int)floor((strtotime($till) - strtotime($today)) / 86400);
            $status = $days < 0 ? 'expired' : ($days <= 5 ? 'soon' : 'active');
        }
        $s['valid_source'] = !empty($s['valid_till']) ? 'recorded' : (!empty($s['auto_valid_till']) ? 'operator' : '');
        $s['effective_valid_till'] = $till;

        /* Five or more attempts in three days, not one of them connected → worth checking the
           recharge. Below five it is as likely to be a quiet patch as a dead SIM. */
        $h = $health[$s['device_id'] . '|' . $s['slot']] ?? null;
        $outTried = $h ? (int)$h['out_calls'] : 0;
        $outOk    = $h ? (int)$h['out_connected'] : 0;

        $out[] = $s + [
            'out_tried'          => $outTried,
            'out_connected'      => $outOk,
            'last_connected_out' => $h['last_connected_out'] ?? null,
            'credit_suspect'     => ($outTried >= 5 && $outOk === 0),
            'agent'        => $dev ? $dev['label'] : ($s['device_id'] === '' ? 'Unidentified phone' : $s['device_id']),
            'team'         => $dev['team'] ?? '',
            'device_model' => $dev['device_model'] ?? '',
            'status'       => $status,
            'days_left'    => $days,
            'calls'        => $u ? (int)$u['calls'] : 0,
            'talk_sec'     => $u ? (int)$u['talk_sec'] : 0,
            'last_call_at' => $u['last_call_at'] ?? null,
        ];
    }

    // Soonest to lapse first; SIMs with no plan recorded sit just behind them, not at the bottom.
    $rank = ['expired' => 0, 'soon' => 1, 'unknown' => 2, 'active' => 3];
    usort($out, function ($a, $b) use ($rank) {
        $ra = $rank[$a['status']]; $rb = $rank[$b['status']];
        if ($ra !== $rb) return $ra <=> $rb;
        if ($a['days_left'] !== null && $b['days_left'] !== null) return $a['days_left'] <=> $b['days_left'];
        return $b['calls'] <=> $a['calls'];
    });

    api_success([
        'sims'  => $out,
        'today' => $today,
        'counts' => [
            'total'   => count($out),
            'active'  => count(array_filter($out, fn($s) => $s['status'] === 'active')),
            'soon'    => count(array_filter($out, fn($s) => $s['status'] === 'soon')),
            'expired' => count(array_filter($out, fn($s) => $s['status'] === 'expired')),
            'unknown' => count(array_filter($out, fn($s) => $s['status'] === 'unknown')),
        ],
    ]);
}

case 'save_sim': {
    $device = (string)($in['device_id'] ?? '');
    $slot   = max(0, min(9, (int)($in['slot'] ?? 0)));
    if ($slot < 1) api_error('A SIM slot is required');

    $date = fn($v) => (is_string($v) && preg_match('/^\d{4}-\d{2}-\d{2}$/', $v)) ? $v : null;
    $plan   = ciq_str($in['plan_name'] ?? '', 120);
    $msisdn = ciq_str($in['msisdn'] ?? '', 20);
    $amount = (isset($in['amount']) && is_numeric($in['amount'])) ? round((float)$in['amount'], 2) : null;
    $from   = $date($in['recharged_on'] ?? null);
    $till   = $date($in['valid_till'] ?? null);
    $notes  = mb_substr((string)($in['notes'] ?? ''), 0, 2000);
    $who    = substr('admin:' . (int)($jwt['user_id'] ?? 0), 0, 40);
    $now    = date('Y-m-d H:i:s');

    $st = $conn->prepare("INSERT INTO caller_iq_sims
            (device_id, slot, msisdn, plan_name, amount, recharged_on, valid_till, notes, first_seen_at, updated_at, updated_by)
          VALUES (?,?,?,?,?,?,?,?,?,?,?)
          ON DUPLICATE KEY UPDATE
            msisdn = IF(VALUES(msisdn) = '', msisdn, VALUES(msisdn)),
            plan_name = VALUES(plan_name), amount = VALUES(amount),
            recharged_on = VALUES(recharged_on), valid_till = VALUES(valid_till),
            notes = VALUES(notes), updated_at = VALUES(updated_at), updated_by = VALUES(updated_by)");
    if (!$st) api_error('Could not save: ' . $conn->error, 500);
    $st->bind_param('sissdssssss', $device, $slot, $msisdn, $plan, $amount, $from, $till, $notes, $now, $now, $who);
    if (!$st->execute()) api_error('Could not save: ' . $st->error, 500);
    api_success(['device_id' => $device, 'slot' => $slot], 'Saved');
}

case 'match_numbers': {
    api_success(['students' => (object)ciq_match_students($conn, ciq_list($in['numbers'] ?? []))]);
}

case 'save_device': {
    $id = (string)($in['device_id'] ?? '');
    $name = ciq_str($in['agent_name'] ?? '', 120);
    $team = ciq_str($in['team'] ?? '', 80);
    $hidden = !empty($in['is_hidden']) ? 1 : 0;
    $now = date('Y-m-d H:i:s');
    $stmt = $conn->prepare("INSERT INTO caller_iq_devices (device_id, agent_name, team, is_hidden, first_seen_at, last_seen_at) VALUES (?,?,?,?,?,?)
                            ON DUPLICATE KEY UPDATE agent_name = VALUES(agent_name), team = VALUES(team), is_hidden = VALUES(is_hidden)");
    if (!$stmt) api_error('Could not save: ' . $conn->error, 500);
    $stmt->bind_param('sssiss', $id, $name, $team, $hidden, $now, $now);
    if (!$stmt->execute()) api_error('Could not save: ' . $stmt->error, 500);
    api_success(['device_id' => $id], 'Saved');
}

case 'set_outcome': {
    $id = (int)($in['id'] ?? 0);
    if ($id <= 0) api_error('id is required');
    $outcome = ciq_str($in['outcome'] ?? '', 60);
    $outcome = $outcome === '' ? null : $outcome;
    $notes = mb_substr((string)($in['notes'] ?? ''), 0, 4000);
    $at  = $outcome === null ? null : date('Y-m-d H:i:s');
    $src = $outcome === null ? null : substr('admin:' . (int)($jwt['user_id'] ?? 0), 0, 20);
    $stmt = $conn->prepare("UPDATE caller_iq_calls SET
                              outcome_at = IF(outcome <=> ?, outcome_at, ?), outcome_source = IF(outcome <=> ?, outcome_source, ?),
                              outcome = ?, notes = NULLIF(?, '') WHERE id = ?");
    if (!$stmt) api_error('Could not save: ' . $conn->error, 500);
    $stmt->bind_param('ssssssi', $outcome, $at, $outcome, $src, $outcome, $notes, $id);
    if (!$stmt->execute()) api_error('Could not save: ' . $stmt->error, 500);
    api_success(q_one($conn, "SELECT id, outcome, outcome_at, outcome_source, notes FROM caller_iq_calls WHERE id = $id"), 'Saved');
}

default:
    api_error('Unknown action', 400);
}

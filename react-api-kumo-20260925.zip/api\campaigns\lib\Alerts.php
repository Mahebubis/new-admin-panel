<?php
/*
 * lib/Alerts.php — "something went wrong in a send, tell a human now".
 *
 * WHY THIS EXISTS
 * A campaign to fifty people fails visibly: you look at the report. A campaign to five hundred
 * thousand fails invisibly — the worker logs it, the run ends, and nobody finds out until somebody
 * happens to open the screen, by which time the audience is spent and the window has passed. At
 * that size the only useful failure is one that comes and finds you.
 *
 * So anything that stops or degrades a send raises an alert on both channels the team already
 * watches: the Slack channel and the alert mailing list. Both are already configured on the
 * monitoring box for the uptime monitor, and this deliberately reuses that configuration rather
 * than introducing a second copy of the same secrets to keep in sync.
 *
 * ── WHAT IT REFUSES TO DO ────────────────────────────────────────────────────
 * It never raises the same alert twice in quick succession. A failing send produces one error per
 * recipient, and at this scale that is tens of thousands of identical events in a minute. An
 * alerting system that relays all of them is an alerting system people mute, which is worse than
 * having none. Every alert carries a key and a cooldown, so the first one goes out immediately and
 * the rest are counted rather than sent.
 *
 * It also never throws. A notification failing must not be able to take down the send it was
 * reporting on — that turns a recoverable problem into an outage.
 */

require_once __DIR__ . '/config.php';

/** Where the uptime monitor keeps its Slack token, SMTP credentials and recipient list. */
if (!defined('ALERT_ENV_PATH')) define('ALERT_ENV_PATH', '/opt/istudio-monitoring/.env');

/** How long the same alert key stays quiet after firing. Long enough that a failing campaign
 *  produces a handful of messages rather than thousands; short enough to re-raise if it drags on. */
if (!defined('ALERT_COOLDOWN_MINUTES')) define('ALERT_COOLDOWN_MINUTES', 15);

/* ════════════════════════════════════════════════════════════════════════════
   Configuration
   ═══════════════════════════════════════════════════════════════════════════ */

/**
 * The monitor's own .env, parsed once.
 *
 * Read from disk rather than duplicated into this codebase because these are live credentials: a
 * second copy is a second thing to rotate, and the one nobody remembers to rotate is the one that
 * leaks. On a machine without that file — cit3, which also runs this worker via the instant Send
 * Now kick — everything below degrades to "not configured" and simply does not alert, which is the
 * right failure: a missing notification must never stop a send.
 */
function alert_config(): array {
    static $cfg = null;
    if ($cfg !== null) return $cfg;

    $env = [];
    if (is_readable(ALERT_ENV_PATH)) {
        foreach (file(ALERT_ENV_PATH, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) as $line) {
            $line = trim($line);
            if ($line === '' || $line[0] === '#' || strpos($line, '=') === false) continue;
            [$k, $v] = explode('=', $line, 2);
            // Values are sometimes quoted in that file ("#issues_bugs_threads"), and a channel
            // name carrying its own quotation marks is rejected by Slack with a confusing error.
            $env[trim($k)] = trim(trim($v), "\"'");
        }
    }

    $cfg = [
        'enabled'     => strtolower((string)($env['ALERT_ENABLED'] ?? 'true')) !== 'false',
        'slackToken'  => (string)($env['SLACK_BOT_TOKEN'] ?? ''),
        'slackChannel'=> (string)($env['SLACK_CHANNEL'] ?? ''),
        'to'          => array_values(array_filter(array_map('trim', explode(',', (string)($env['ALERT_TO'] ?? ''))))),
        'from'        => (string)($env['ALERT_FROM'] ?? ''),
        'subjectPrefix' => (string)($env['ALERT_SUBJECT_PREFIX'] ?? '[iStudio]'),
        'smtpHost'    => (string)($env['SMTP_HOST'] ?? ''),
        'smtpPort'    => (int)($env['SMTP_PORT'] ?? 587),
        'smtpUser'    => (string)($env['SMTP_USER'] ?? ''),
        'smtpPass'    => (string)($env['SMTP_PASSWORD'] ?? ''),
    ];
    return $cfg;
}

/** Whether anything can be delivered at all. Checked before work is done building a message. */
function alert_available(): bool {
    $c = alert_config();
    if (!$c['enabled']) return false;
    return ($c['slackToken'] !== '' && $c['slackChannel'] !== '')
        || ($c['smtpHost'] !== '' && $c['to']);
}

/* ════════════════════════════════════════════════════════════════════════════
   Outbox — alerts raised on a machine that cannot deliver them
   ═══════════════════════════════════════════════════════════════════════════ */

function alert_outbox_ensure_schema(): void {
    global $conn;
    static $done = false;
    if ($done) return;
    $done = true;
    @$conn->query("CREATE TABLE IF NOT EXISTS ops_alert_outbox (
        id           BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
        alert_key    VARCHAR(190) NOT NULL,
        title        VARCHAR(255) NOT NULL,
        severity     VARCHAR(16)  NOT NULL DEFAULT 'error',
        summary      TEXT         NULL,
        fields_json  MEDIUMTEXT   NULL,
        raised_on    VARCHAR(100) NULL,
        created_at   DATETIME     NOT NULL,
        delivered_at DATETIME     NULL,
        KEY idx_undelivered (delivered_at, id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
}

function alert_outbox_enqueue(string $key, string $title, string $summary, array $fields, string $severity): void {
    global $conn;
    try {
        alert_outbox_ensure_schema();
        $fields['Raised on'] = (string)gethostname() . ' at ' . date('Y-m-d H:i:s');
        @$conn->query("INSERT INTO ops_alert_outbox (alert_key, title, severity, summary, fields_json, raised_on, created_at)
            VALUES ('" . $conn->real_escape_string(mb_substr($key, 0, 190)) . "',
                    '" . $conn->real_escape_string(mb_substr($title, 0, 250)) . "',
                    '" . $conn->real_escape_string($severity) . "',
                    '" . $conn->real_escape_string(mb_substr($summary, 0, 4000)) . "',
                    '" . $conn->real_escape_string((string)json_encode($fields, JSON_UNESCAPED_UNICODE)) . "',
                    '" . $conn->real_escape_string(mb_substr((string)gethostname(), 0, 100)) . "',
                    '" . date('Y-m-d H:i:s') . "')");
    } catch (\Throwable $e) {
        error_log('[alerts] outbox enqueue failed: ' . $e->getMessage());
    }
}

/**
 * Delivers alerts other machines parked. Runs only where a channel exists, and takes each row with
 * an atomic UPDATE first so two runs never send the same one. Never throws.
 */
function alert_outbox_flush(int $limit = 20): int {
    global $conn;
    $sent = 0;
    try {
        if (!alert_available()) return 0;
        alert_outbox_ensure_schema();
        $r = @$conn->query("SELECT * FROM ops_alert_outbox WHERE delivered_at IS NULL ORDER BY id LIMIT " . (int)$limit);
        $rows = [];
        while ($r && $row = $r->fetch_assoc()) $rows[] = $row;
        foreach ($rows as $row) {
            $id = (int)$row['id'];
            @$conn->query("UPDATE ops_alert_outbox SET delivered_at = NOW() WHERE id = $id AND delivered_at IS NULL");
            if ($conn->affected_rows < 1) continue;   // another run took it
            $fields = json_decode((string)$row['fields_json'], true) ?: [];
            alert_notify((string)$row['alert_key'], (string)$row['title'], (string)$row['summary'], $fields, (string)$row['severity']);
            $sent++;
        }
    } catch (\Throwable $e) {
        error_log('[alerts] outbox flush failed: ' . $e->getMessage());
    }
    return $sent;
}

/* ════════════════════════════════════════════════════════════════════════════
   Throttling
   ═══════════════════════════════════════════════════════════════════════════ */

function alert_ensure_schema(): void {
    global $conn;
    static $done = false;
    if ($done) return;
    $done = true;

    /*
     * The throttle, and the record of what was raised.
     *
     * In the database rather than a file or a static, because the thing being throttled happens
     * across several worker processes on two machines — an in-process guard would let each of them
     * send the same alert and achieve nothing.
     *
     * suppressed_count is the honest part: a cooldown that silently drops events would understate
     * a problem, so the next alert on the same key says how many it stood in for.
     */
    @$conn->query("CREATE TABLE IF NOT EXISTS ops_alerts (
        alert_key        VARCHAR(190) NOT NULL PRIMARY KEY,
        title            VARCHAR(255) NOT NULL,
        severity         VARCHAR(16)  NOT NULL DEFAULT 'error',
        last_sent_at     DATETIME     NOT NULL,
        last_body        TEXT,
        fired_count      INT UNSIGNED NOT NULL DEFAULT 1,
        suppressed_count INT UNSIGNED NOT NULL DEFAULT 0,
        slack_ok         TINYINT(1)   NOT NULL DEFAULT 0,
        email_ok         TINYINT(1)   NOT NULL DEFAULT 0,
        INDEX idx_last (last_sent_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
}

/**
 * May this key fire now?
 *
 * Two statements, in this order, and the order is the whole mechanism:
 *
 *   1. A conditional UPDATE that only matches a row whose cooldown has EXPIRED. MySQL reports how
 *      many rows it changed, and because the cooldown is in the WHERE clause rather than inside an
 *      IF(), a non-zero answer can only mean "this caller took the slot".
 *   2. If that matched nothing, the key may simply be new — INSERT IGNORE claims it, and reports a
 *      row when it did.
 *
 * Anything else is inside the cooldown and only bumps the suppressed counter.
 *
 * The first version of this did it in one INSERT ... ON DUPLICATE KEY UPDATE and read
 * affected_rows to decide. That was wrong in a way the self-test caught: the statement always
 * changed something — the suppressed counter — so affected_rows was always 2 and every alert
 * claimed the slot. The throttle existed and never throttled anything, which at five hundred
 * thousand recipients is the difference between one Slack message and tens of thousands.
 */
function alert_claim(string $key, string $title, string $severity): bool {
    global $conn;
    alert_ensure_schema();

    $k = $conn->real_escape_string(mb_substr($key, 0, 190));
    $t = $conn->real_escape_string(mb_substr($title, 0, 250));
    $s = $conn->real_escape_string($severity);
    $cool = (int)ALERT_COOLDOWN_MINUTES;

    // 1. An existing key whose quiet period is over. Atomic: two workers racing this, only one
    //    matches the row, because the first one's commit moves last_sent_at out of range.
    @$conn->query("UPDATE ops_alerts
                      SET last_sent_at = NOW(), fired_count = fired_count + 1,
                          title = '$t', severity = '$s'
                    WHERE alert_key = '$k'
                      AND last_sent_at < DATE_SUB(NOW(), INTERVAL $cool MINUTE)");
    if ($conn->affected_rows > 0) return true;

    // 2. A key nobody has raised before.
    @$conn->query("INSERT IGNORE INTO ops_alerts (alert_key, title, severity, last_sent_at, fired_count)
                   VALUES ('$k', '$t', '$s', NOW(), 1)");
    if ($conn->affected_rows > 0) return true;

    // 3. Inside the cooldown. Counted, so the next alert can say how many it stood in for.
    @$conn->query("UPDATE ops_alerts SET suppressed_count = suppressed_count + 1 WHERE alert_key = '$k'");
    return false;
}

/** How many events this alert is standing in for, and reset the counter. */
function alert_take_suppressed(string $key): int {
    global $conn;
    $k = $conn->real_escape_string(mb_substr($key, 0, 190));
    $r = @$conn->query("SELECT suppressed_count FROM ops_alerts WHERE alert_key = '$k' LIMIT 1");
    $n = $r && ($row = $r->fetch_assoc()) ? (int)$row['suppressed_count'] : 0;
    if ($n > 0) @$conn->query("UPDATE ops_alerts SET suppressed_count = 0 WHERE alert_key = '$k'");
    return $n;
}

/* ════════════════════════════════════════════════════════════════════════════
   Slack
   ═══════════════════════════════════════════════════════════════════════════ */

/**
 * Posts to the team channel.
 *
 * Blocks rather than a plain string, so the fields line up in a readable grid on a phone — which is
 * where these are read at 2am, and a wall of "key: value, key: value" is not readable there.
 */
function alert_slack(string $title, string $summary, array $fields, string $severity): bool {
    $c = alert_config();
    if ($c['slackToken'] === '' || $c['slackChannel'] === '') return false;

    $icon = $severity === 'critical' ? ':rotating_light:' : ':warning:';
    $head = $icon . ' *' . $title . '*';
    // @channel only for critical. Using it for everything is how a channel gets muted, and a muted
    // channel is the same as no alerting at all.
    if ($severity === 'critical') $head = '<!channel> ' . $head;

    $blocks = [
        ['type' => 'section', 'text' => ['type' => 'mrkdwn', 'text' => $head . "\n" . $summary]],
    ];
    if ($fields) {
        $pairs = [];
        foreach ($fields as $k => $v) {
            $v = trim((string)$v);
            if ($v === '') continue;
            $pairs[] = ['type' => 'mrkdwn', 'text' => '*' . $k . "*\n" . mb_substr($v, 0, 1800)];
        }
        // Slack caps a fields block at 10; anything beyond goes in its own section rather than
        // being silently dropped, because the dropped one is always the one that mattered.
        foreach (array_chunk($pairs, 10) as $chunk) {
            $blocks[] = ['type' => 'section', 'fields' => $chunk];
        }
    }
    $blocks[] = ['type' => 'context', 'elements' => [
        ['type' => 'mrkdwn', 'text' => 'Engage · ' . date('Y-m-d H:i:s') . ' · ' . gethostname()],
    ]];

    $payload = json_encode([
        'channel' => $c['slackChannel'],
        'text'    => $title . ' — ' . mb_substr(strip_tags($summary), 0, 200),   // notification fallback
        'blocks'  => $blocks,
    ]);

    $ch = curl_init('https://slack.com/api/chat.postMessage');
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT        => 10,
        CURLOPT_POST           => true,
        CURLOPT_POSTFIELDS     => $payload,
        CURLOPT_HTTPHEADER     => [
            'Content-Type: application/json; charset=utf-8',
            'Authorization: Bearer ' . $c['slackToken'],
        ],
    ]);
    $body = curl_exec($ch);
    $err  = curl_error($ch);
    curl_close($ch);

    $d = json_decode((string)$body, true);
    $ok = is_array($d) && !empty($d['ok']);
    if (!$ok) {
        // Logged, never thrown. Slack being down is not a reason to stop a campaign.
        error_log('[alerts] slack post failed: ' . ($err !== '' ? $err : (string)($d['error'] ?? 'unknown')));
    }
    return $ok;
}

/* ════════════════════════════════════════════════════════════════════════════
   Email
   ═══════════════════════════════════════════════════════════════════════════ */

/**
 * Sends the same alert to the operations mailing list, over the monitor's own SMTP.
 *
 * DELIBERATELY NOT through the campaign ESPs. The most important alert this will ever send is "the
 * email provider has stopped accepting mail" — routing it through that same provider means the one
 * message you needed is the one that does not arrive.
 *
 * curl's SMTP support rather than a mail library, because there is no dependency manager here and
 * the SES transport already proves the approach works on this PHP build.
 */
function alert_email(string $subject, string $bodyText): bool {
    $c = alert_config();
    if ($c['smtpHost'] === '' || !$c['to']) return false;

    $from = $c['from'] !== '' ? $c['from'] : $c['smtpUser'];
    $subject = trim($c['subjectPrefix'] . ' ' . $subject);

    $headers = "From: iStudio Engage <$from>\r\n"
             . 'To: ' . implode(', ', $c['to']) . "\r\n"
             . 'Subject: ' . mb_encode_mimeheader($subject, 'UTF-8') . "\r\n"
             . "MIME-Version: 1.0\r\n"
             . "Content-Type: text/plain; charset=UTF-8\r\n"
             . "Content-Transfer-Encoding: 8bit\r\n"
             . 'Date: ' . date('r') . "\r\n\r\n";
    $mime = $headers . $bodyText . "\r\n";

    $fp = fopen('php://temp', 'r+');
    fwrite($fp, $mime);
    rewind($fp);

    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL            => 'smtp://' . $c['smtpHost'] . ':' . $c['smtpPort'],
        CURLOPT_USE_SSL        => CURLUSESSL_ALL,       // STARTTLS on 587; refuses to fall back to plaintext
        CURLOPT_USERNAME       => $c['smtpUser'],
        CURLOPT_PASSWORD       => $c['smtpPass'],
        CURLOPT_MAIL_FROM      => '<' . $from . '>',
        CURLOPT_MAIL_RCPT      => array_map(fn($a) => '<' . $a . '>', $c['to']),
        CURLOPT_UPLOAD         => true,
        CURLOPT_INFILE         => $fp,
        CURLOPT_INFILESIZE     => strlen($mime),
        CURLOPT_TIMEOUT        => 20,
        CURLOPT_RETURNTRANSFER => true,
    ]);
    curl_exec($ch);
    $err  = curl_error($ch);
    $code = (int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
    curl_close($ch);
    fclose($fp);

    $ok = $err === '' && $code >= 200 && $code < 400;
    if (!$ok) error_log('[alerts] smtp send failed: ' . ($err !== '' ? $err : "code $code"));
    return $ok;
}

/* ════════════════════════════════════════════════════════════════════════════
   The one function everything else calls
   ═══════════════════════════════════════════════════════════════════════════ */

/**
 * Raise an alert on every configured channel, once per cooldown.
 *
 * @param string $key      what is being alerted about, e.g. "campaign:91:provider_failed". Two
 *                         events sharing a key are the same problem and the second one waits.
 * @param string $title    one line, read first and often the only thing read
 * @param string $summary  a sentence or two of what happened and what it means
 * @param array  $fields   label => value, shown as a grid in Slack and a list in the email
 * @param string $severity 'error' (default) or 'critical', which adds an @channel
 * @return bool            whether anything was actually delivered
 */
function alert_notify(string $key, string $title, string $summary, array $fields = [],
                      string $severity = 'error'): bool {
    try {
        /*
         * No channel on this machine — cit3, where the Send button runs the worker. Alerts raised
         * there used to vanish: campaigns #100 and #101 both switched provider mid-send and nobody
         * was told. They are parked in the database instead, and the monitoring box, which has the
         * channels, delivers them on its next minute (alert_outbox_flush, from the send worker).
         */
        if (!alert_available()) {
            alert_outbox_enqueue($key, $title, $summary, $fields, $severity);
            return false;
        }
        if (!alert_claim($key, $title, $severity)) return false;   // inside the cooldown

        $also = alert_take_suppressed($key);
        if ($also > 0) $fields['Similar events since the last alert'] = (string)$also;

        $slackOk = alert_slack($title, $summary, $fields, $severity);

        $lines = [$summary, ''];
        foreach ($fields as $k => $v) {
            $v = trim((string)$v);
            if ($v !== '') $lines[] = $k . ': ' . $v;
        }
        $lines[] = '';
        $lines[] = 'Raised by iStudio Engage on ' . gethostname() . ' at ' . date('Y-m-d H:i:s') . '.';
        $lines[] = 'Alert key: ' . $key;
        $emailOk = alert_email($title, implode("\n", $lines));

        global $conn;
        $k = $conn->real_escape_string(mb_substr($key, 0, 190));
        @$conn->query("UPDATE ops_alerts SET slack_ok = " . ($slackOk ? 1 : 0)
            . ", email_ok = " . ($emailOk ? 1 : 0)
            . ", last_body = '" . $conn->real_escape_string(mb_substr($summary, 0, 2000)) . "'
               WHERE alert_key = '$k'");

        return $slackOk || $emailOk;
    } catch (\Throwable $e) {
        // The whole point of this file is to report failures; it must never become one.
        error_log('[alerts] notify failed: ' . $e->getMessage());
        return false;
    }
}

<?php
/**
 * /api/profile-metrics/profile_metrics.php  —  Resume / Profile Metrics
 * ---------------------------------------------------------------------------
 * One endpoint, a handful of actions, all POST JSON. Every action takes the same
 * { start, end, filters } envelope, so the page can apply a filter once and have
 * it hold across tabs and every level of a drill-down.
 *
 *   bootstrap   the filter option lists (companies, statuses, sections), how far
 *               back each data source actually goes, and which of this page's
 *               indexes are missing. Cached for a few minutes because none of it
 *               changes minute to minute and two of the queries touch `users`.
 *
 *   overview    every headline number for the range AND the equal-length range
 *               before it, plus a day-by-day series for each. One query per
 *               metric covering both windows at once — the split happens in PHP
 *               — so the tab costs ~10 grouped counts, not 20.
 *
 *   series      day-by-day for a named set of metrics.
 *
 *   breakdown   the same counts grouped by company / job / status / section /
 *               learner / read-state. Every drawer level is one of these.
 *
 *   rows        the leaf — individual records, paginated, and the CSV source.
 *
 *   health      which indexes are missing and how big the gap is.
 *   install_indexes  creates them. Superadmin only, and only on request.
 *
 * All of the shaping lives in pm_lib.php; this file is routing, the composite
 * actions, and the leaf row queries.
 * ---------------------------------------------------------------------------
 */
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../middleware/auth.php';
require_once __DIR__ . '/pm_lib.php';

/*
 * ── mysqli error mode ────────────────────────────────────────────────────────
 * PHP 8.1 made mysqli's default MYSQLI_REPORT_ERROR|STRICT, so a failed query
 * THROWS mysqli_sql_exception instead of returning false. This whole feature is
 * written against the return-false contract — pm_daily(), pm_total(),
 * pm_breakdown() and the bootstrap probes all read
 *
 *     $res = $conn->query(...); if (!$res) { …note it, carry on… }
 *
 * and under exception mode not one of those branches is reachable. Every one of
 * them became an uncaught exception and a bare 500 with no JSON body, which is
 * exactly what "Server error. Please try again later." was: a counter whose
 * query hit the execution-time ceiling took the whole request down instead of
 * reporting itself unavailable, and `stock` 500'd despite having an explicit
 * success path for failure.
 *
 * Same opt-back-in as api/lms/lms_api.php and api/journeys/lib/schema.php, and
 * scoped to this request only — nothing else on the server is affected.
 */
mysqli_report(MYSQLI_REPORT_OFF);

/* Belt and braces for everything the line above does not cover. Anything that
   still escapes comes back as JSON the page can print, rather than an empty 500
   that tells the reader only "Server error. Please try again later." */
set_exception_handler(function (Throwable $e) {
    error_log('[profile-metrics] uncaught: ' . $e->getMessage() . ' @ ' . $e->getFile() . ':' . $e->getLine());
    api_error('Something went wrong reading these numbers: ' . $e->getMessage(), 500);
});

$jwt = require_jwt();
require_permission('profile_metrics', $jwt);
require_method('POST');

/* Creating indexes on a large table is the one action here that legitimately
   takes minutes. Everything else should be well under a second once they exist. */
@set_time_limit(600);

/* Counts change by the minute; a cached page would quietly show yesterday. */
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');

$in     = get_json_input();
$action = $in['action'] ?? '';
$f      = is_array($in['filters'] ?? null) ? $in['filters'] : [];
$r      = pm_range($in);

/* A server-side ceiling, so a query with no usable index is aborted by MySQL
   with a message instead of running until the browser gives up. `stock` and
   `install_indexes` set their own, longer, budgets. */
if ($action !== 'install_indexes' && $action !== 'stock') pm_query_budget(15000);

/* ── the headline sets, in the order the tabs show them ──────────────────── */
$TABS = [
    'overview'  => ['new_profiles', 'profiles_updated', 'resume_uploaded', 'profile_section_updated',
                    'applications', 'assignments_sent', 'assignments_submitted',
                    'interviews_scheduled', 'msg_from_company', 'msg_from_student'],
    'profile'   => ['new_profiles', 'profiles_updated', 'resume_uploaded', 'resume_first_upload',
                    'resume_replaced', 'resume_removed', 'profile_section_updated',
                    'profile_editors', 'profile_photo_updated'],
    'hiring'    => ['applications', 'invites', 'assignments_sent', 'assignments_submitted',
                    'interviews_scheduled', 'interviews_held', 'reschedule_requests'],
    'messaging' => ['msg_from_company', 'msg_from_company_read', 'msg_from_company_unread',
                    'msg_from_student', 'msg_from_student_read', 'msg_from_student_unread'],
];

/* ── a tiny file cache, for bootstrap only ─────────────────────────────────
   The filter option lists and the learner totals are the only things on this
   page that are both expensive and slow-moving. Everything else is a live count
   and is never cached. */
function pm_cache_path($key) {
    return rtrim(sys_get_temp_dir(), '/\\') . DIRECTORY_SEPARATOR . 'pm_' . preg_replace('/[^a-z0-9_]/i', '', $key) . '.json';
}
function pm_cache_get($key, $ttl) { return pm_file_cache($key, $ttl); }
function pm_cache_put($key, $value) { pm_file_cache($key, 0, $value); }

/** Every day in the range, so a quiet Sunday is a zero on the chart, not a gap. */
function pm_days($start, $end) {
    $out = [];
    for ($t = strtotime($start); $t <= strtotime($end); $t = strtotime('+1 day', $t)) {
        $out[] = date('Y-m-d', $t);
    }
    return $out;
}

/**
 * One grouped-by-day query spanning previous-start → end, split into the two
 * windows afterwards. Halves the query count versus asking each window
 * separately, and the series the chart needs falls out of the same rows.
 */
function pm_metric_block($key, $f, $r) {
    $m     = pm_metric($key);
    $daily = pm_daily($key, $f, $r['prev_start'], $r['end']);

    $series = [];
    $cur    = 0;
    foreach (pm_days($r['start'], $r['end']) as $d) {
        $n = $daily[$d] ?? 0;
        $cur += $n;
        $series[] = ['date' => $d, 'value' => $n];
    }
    $prev = 0;
    foreach (pm_days($r['prev_start'], $r['prev_end']) as $d) $prev += $daily[$d] ?? 0;

    return [
        'key'    => $key,
        'label'  => $m['label'],
        'hint'   => $m['hint'] ?? '',
        'family' => $m['family'],
        'source' => $m['source'],
        'dims'   => $m['dims'],
        'total'  => $cur,
        'prev'   => $prev,
        /* Percent change is meaningless against a zero baseline; the UI prints
           "new" for that case, so hand it null rather than a fake infinity. */
        'delta'  => $prev > 0 ? round((($cur - $prev) / $prev) * 100, 1) : null,
        'series' => $series,
        /* Non-null when the query behind this counter failed, so the tile can
           say "could not read" instead of showing a zero that looks like fact. */
        'error'  => pm_note()[$key] ?? null,
    ];
}

switch ($action) {

/* ─────────────────────────────────────────────────────────────────────────
   health / install_indexes
───────────────────────────────────────────────────────────────────────── */
case 'health': {
    api_success([
        'missing_indexes' => pm_missing_indexes(),
        'has_activity_log' => pm_table('user_activity_log'),
    ]);
}

case 'install_indexes': {
    /* Deliberately superadmin-only and never automatic: these are large tables
       and the ALTER, online or not, is not something a dashboard should start
       behind somebody's back. */
    if (!is_superadmin($jwt)) {
        $live = get_admin_permissions((int)($jwt['user_id'] ?? 0), $conn);
        if (!in_array('__superadmin__', $live, true)) {
            api_error('Only a Super Admin can create database indexes.', 403);
        }
    }
    /* One per call by default; the page keeps calling while any remain, so a
       long ALTER can never take a whole batch down with it. */
    $results = pm_create_indexes((int)($in['limit'] ?? 1));

    /* The cached option lists — and the cached test-account ids, which are only
       collected once the index for them exists — were built against the old
       shape. */
    @unlink(pm_cache_path('bootstrap_v2'));
    @unlink(pm_cache_path('test_user_ids'));

    /* Re-probe rather than reuse the list from before the ALTERs. */
    $remaining = pm_missing_indexes();
    api_success([
        'created'         => $results,
        'missing_indexes' => $remaining,
        'remaining'       => count($remaining),
        'done'            => count($remaining) === 0,
    ]);
}

/* ─────────────────────────────────────────────────────────────────────────
   bootstrap — filter options + how far back the data actually goes
───────────────────────────────────────────────────────────────────────── */
case 'bootstrap': {
    /* Index health is a single information_schema read and is the thing the page
       most needs to be current, so it is computed fresh outside the cache. */
    $health = ['missing_indexes' => pm_missing_indexes()];

    $cached = empty($in['refresh']) ? pm_cache_get('bootstrap_v2', 300) : null;
    if ($cached) api_success($cached + $health + ['cached' => true]);

    $out = ['metrics' => [], 'tabs' => $TABS];

    foreach (pm_metrics() as $k => $m) {
        $out['metrics'][$k] = [
            'key'   => $k, 'label' => $m['label'], 'family' => $m['family'],
            'hint'  => $m['hint'] ?? '', 'source' => $m['source'], 'dims' => $m['dims'],
        ];
    }

    /* Just the companies, with no per-company application count. That count was
       a join across every application ever recorded with no date bound — on its
       own it could outlast the request timeout, and it only decorated a dropdown. */
    $out['employers'] = [];
    $res = $conn->query(
        "SELECT employer_id AS id,
                COALESCE(NULLIF(employer_name,''), CONCAT('Company #', employer_id)) AS label,
                employer_logo AS logo
           FROM hiring_employer
          ORDER BY employer_name ASC
          LIMIT 5000");
    if ($res) {
        while ($x = $res->fetch_assoc()) { $x['id'] = (int)$x['id']; $out['employers'][] = $x; }
        $res->free();
    }

    $distinct = function ($sql) use ($conn) {
        $vals = []; $res = $conn->query($sql);
        if ($res) { while ($x = $res->fetch_row()) { if ($x[0] !== null && $x[0] !== '') $vals[] = $x[0]; } $res->free(); }
        return $vals;
    };
    /* Distinct values rather than a hard-coded list — the hiring portal adds job
       types and statuses without telling this panel. Taken from the most recent
       rows by primary key rather than the whole table: a DISTINCT over every
       application ever is a full scan for a list that has four entries in it. */
    $out['job_types']  = $distinct("SELECT DISTINCT job_type FROM job_list ORDER BY 1 LIMIT 100");
    $out['job_modes']  = $distinct("SELECT DISTINCT job_mode FROM job_list ORDER BY 1 LIMIT 100");
    $out['app_status'] = $distinct(
        "SELECT DISTINCT status FROM
           (SELECT status FROM hiring_applications_new ORDER BY id DESC LIMIT 50000) t
          ORDER BY 1 LIMIT 100");
    $out['sections']   = $distinct(
        "SELECT DISTINCT s FROM
           (SELECT JSON_UNQUOTE(JSON_EXTRACT(activity_data,'$.section')) AS s
              FROM user_activity_log
             WHERE activity_type = 'profile_section_updated'
             ORDER BY id DESC LIMIT 50000) t
          ORDER BY 1 LIMIT 100");

    /* The honest start date for the instrumented families. Before this, nothing
       was written, so a zero on the chart means "not recorded", not "nobody did
       it" — and the page says so. MIN() on an indexed column is instant; the row
       count is deliberately not asked for, since COUNT(*) over the table is not. */
    $out['tracking'] = ['since' => null, 'rows' => 0];
    if (pm_table('user_activity_log')) {
        $res = $conn->query(
            "SELECT created_at FROM user_activity_log
              WHERE activity_type IN ('resume_uploaded','resume_removed',
                                      'profile_section_updated','profile_photo_updated')
              ORDER BY id ASC LIMIT 1");
        if ($res) {
            $x = $res->fetch_assoc(); $res->free();
            $out['tracking']['since'] = $x['created_at'] ?? null;
        }
    }

    /* The `users` totals are NOT computed here. `SUM(CASE WHEN resume …)` has to
       read every row of `users` whatever indexes exist, and bootstrap is the one
       call that must always come back — it carries the index health that tells
       the page how to get fast in the first place. An expensive query in here is
       a page that can never recover from being slow. It lives in `stock` below,
       which the page asks for separately and can do without. */
    pm_cache_put('bootstrap_v2', $out);
    api_success($out + $health + ['cached' => false, 'degraded' => pm_degraded()]);
}

/* ─────────────────────────────────────────────────────────────────────────
   stock — how many learners there are, and how many have a resume
   Deliberately its own call: it is a full read of `users`, it changes by
   fractions of a percent per day, and nothing else on the page waits for it.
───────────────────────────────────────────────────────────────────────── */
case 'stock': {
    $cached = empty($in['refresh']) ? pm_cache_get('stock_v1', 3600) : null;
    if ($cached) api_success($cached + ['cached' => true]);

    pm_query_budget(25000);

    $out = ['learners' => null, 'with_resume' => null];
    $testGuard = (pm_has('users', 'is_test_account') && pm_index_exists('users', 'idx_pm_is_test'))
        ? 'AND COALESCE(is_test_account,0) = 0' : '';
    $res = $conn->query(
        "SELECT COUNT(*) AS learners,
                SUM(CASE WHEN resume IS NOT NULL AND resume <> '' THEN 1 ELSE 0 END) AS with_resume
           FROM users WHERE applyforexam = 1 $testGuard");
    if (!$res) {
        error_log('[profile-metrics] stock: ' . $conn->error);
        /* Not an error the page should see: the card simply shows nothing. */
        api_success($out + ['cached' => false, 'error' => $conn->error]);
    }
    $x = $res->fetch_assoc(); $res->free();
    $out = ['learners' => (int)$x['learners'], 'with_resume' => (int)$x['with_resume']];

    pm_cache_put('stock_v1', $out);
    api_success($out + ['cached' => false]);
}

/* ─────────────────────────────────────────────────────────────────────────
   overview — the KPI grid and its charts, for one tab
───────────────────────────────────────────────────────────────────────── */
case 'overview': {
    $tab  = $in['tab'] ?? 'overview';
    $keys = $TABS[$tab] ?? $TABS['overview'];

    $cards = [];
    foreach ($keys as $k) $cards[] = pm_metric_block($k, $f, $r);

    api_success([
        'range' => $r,
        'tab'   => $tab,
        'cards' => $cards,
        'days'  => pm_days($r['start'], $r['end']),
        /* Anything a counter had to skip to stay fast — e.g. test accounts left
           in because the index that would exclude them does not exist yet. */
        'degraded' => pm_degraded(),
    ]);
}

/* ─────────────────────────────────────────────────────────────────────────
   series — day-by-day for an explicit list of metrics
───────────────────────────────────────────────────────────────────────── */
case 'series': {
    $keys = $in['metrics'] ?? [];
    if (!is_array($keys) || !$keys) api_error('No metrics requested');
    $keys = array_slice(array_values(array_unique($keys)), 0, 25);

    $out = [];
    foreach ($keys as $k) $out[] = pm_metric_block($k, $f, $r);

    api_success(['range' => $r, 'metrics' => $out, 'days' => pm_days($r['start'], $r['end'])]);
}

/* ─────────────────────────────────────────────────────────────────────────
   breakdown — group one metric by one dimension (every drawer level)
───────────────────────────────────────────────────────────────────────── */
case 'breakdown': {
    $metric = $in['metric'] ?? '';
    $dim    = $in['dim']    ?? 'employer';
    $limit  = (int)($in['limit']  ?? 200);
    $offset = (int)($in['offset'] ?? 0);

    $rows    = pm_breakdown($metric, $dim, $f, $r['start'], $r['end'], $limit, $offset);
    $pageSum = array_sum(array_column($rows, 'count'));
    $m       = pm_metric($metric);

    /* The drawer is paginated, so the rows on one page are not the whole story.
       Two figures describe the whole list, and both are only computed for the
       first page — the drawer keeps them while it pages through the rest:

         groups  how many companies / learners / sections there are in total
         total   the metric's own count for the range, the number the list adds
                 up to. Summing the page stopped being that the moment the page
                 got shorter than the list.

       When every group fits on page one, both fall out of the rows for free —
       except for a DISTINCT metric (learners who edited), whose groups overlap,
       so its true total is never the sum of its parts. */
    $groups = null;
    $total  = null;
    if ($offset === 0) {
        $fits   = count($rows) < $limit;
        $groups = $fits ? count($rows) : pm_breakdown_size($metric, $dim, $f, $r['start'], $r['end']);
        $total  = ($fits && !$m['distinct']) ? $pageSum : pm_total($metric, $f, $r['start'], $r['end']);
    }

    api_success([
        'range'  => $r, 'metric' => $metric, 'label' => $m['label'], 'dim' => $dim,
        'rows'   => $rows,
        'offset' => $offset,
        'limit'  => $limit,
        'shown'  => count($rows),
        'sum'    => $pageSum,
        'total'  => $total,
        'groups' => $groups,
        'more'   => count($rows) >= $limit,
    ]);
}

/* ─────────────────────────────────────────────────────────────────────────
   rows — the leaf: individual records behind a number
───────────────────────────────────────────────────────────────────────── */
case 'rows': {
    $metric   = $in['metric'] ?? '';
    $m        = pm_metric($metric);
    $per_page = max(1, min(5000, (int)($in['per_page'] ?? 50)));
    $page     = max(1, (int)($in['page'] ?? 1));
    $offset   = ($page - 1) * $per_page;

    /* The leaf is the one place that WANTS every descriptive column, so it asks
       for every join the metric has. It is also the one place where that is
       cheap: the date index orders the rows, and only the LIMIT-sized window
       ever gets joined. */
    $wantAliases = array_values(array_intersect($m['has'], array_keys($m['joins'])));
    [$from, $emitted, $where] = pm_leaf_context($m, $f, $r['start'], $r['end'], $wantAliases);

    /* Every column is guarded by pm_live(), not by "is it joined" — `users` is
       the base table for the two profile counters and `chat_messages` is its own
       base, so an emitted-joins-only check silently dropped the learner's name
       from exactly the listings that are only about learners. */
    $uid  = pm_user_col($m, $emitted);

    $cols = ["{$m['date']} AS occurred_at", "{$m['key']} AS row_key"];
    if ($uid) $cols[] = "$uid AS user_id";
    if (pm_live($m, $emitted, 'u')) {
        $cols[] = "COALESCE(NULLIF(TRIM(u.name),''),
                            NULLIF(TRIM(CONCAT(COALESCE(u.fname,''),' ',COALESCE(u.lname,''))),''),
                            u.email, CONCAT('User #', u.user_id)) AS user_name";
        $cols[] = "u.email AS user_email";
        $cols[] = "u.phone AS user_phone";
    }
    if (pm_live($m, $emitted, 'jl')) {
        $cols[] = "jl.job_id AS job_id";
        $cols[] = "jl.job_title AS job_title";
        $cols[] = "jl.job_type AS job_type";
    }
    if (pm_live($m, $emitted, 'he')) {
        $cols[] = "jl.employer_id AS employer_id";
        $cols[] = "he.employer_name AS employer_name";
        $cols[] = "he.employer_logo AS employer_logo";
    }
    if (pm_live($m, $emitted, 'a')) {
        $cols[] = "a.id AS application_id";
        $cols[] = "a.status AS application_status";
    }
    if (pm_live($m, $emitted, 'cm')) {
        $cols[] = "cm.status AS message_status";
        $cols[] = "LEFT(COALESCE(cm.message_text,''), 280) AS message_text";
        $cols[] = "IF(COALESCE(cm.attachment,'') = '', 0, 1) AS has_attachment";
    }
    if (pm_live($m, $emitted, 'al')) {
        $cols[] = "JSON_UNQUOTE(JSON_EXTRACT(al.activity_data,'$.section')) AS section";
        $cols[] = "JSON_UNQUOTE(JSON_EXTRACT(al.activity_data,'$.replaced')) AS replaced";
        $cols[] = "JSON_UNQUOTE(JSON_EXTRACT(al.activity_data,'$.source')) AS source_page";
    }

    $sql = "SELECT " . implode(",\n       ", $cols) . "
              FROM $from
             WHERE $where
             ORDER BY {$m['date']} DESC
             LIMIT $per_page OFFSET $offset";
    $res = $conn->query($sql);
    if (!$res) {
        error_log('[profile-metrics] rows ' . $metric . ': ' . $conn->error);
        api_error('Could not list "' . $m['label'] . '": ' . $conn->error, 500);
    }

    $rows = [];
    while ($x = $res->fetch_assoc()) $rows[] = $x;
    $res->free();

    /* Total only on the first page — it is a second full pass and the table
       keeps the number once it has it. */
    $total = null;
    if ($page === 1) $total = pm_total($metric, $f, $r['start'], $r['end']);

    api_success([
        'range' => $r, 'metric' => $metric, 'label' => $m['label'],
        'rows'  => $rows, 'page' => $page, 'per_page' => $per_page,
        'total' => $total, 'more' => count($rows) >= $per_page,
    ]);
}

default:
    api_error('Unknown action');
}

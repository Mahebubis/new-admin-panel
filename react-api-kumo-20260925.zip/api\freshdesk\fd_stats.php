<?php
/*
 * /api/freshdesk/fd_stats.php
 *
 *   action=dashboard   [&days=7]  -> stat cards, SLA health, distributions, live feed
 *   action=analytics   &from &to  -> per-day volume/resolution series for Reports
 *   action=agents                 -> per-agent performance table
 *   action=feed        [&limit]   -> recent activity only (cheap, polled)
 *
 * Every number is computed from the tables at read time rather than kept in a
 * counters row. Slower in principle, correct in practice: a denormalised
 * dashboard counter drifts the first time anything is merged, deleted or
 * re-synced, and a support dashboard that quietly lies is worse than a slow one.
 * The tables are indexed for these queries and the volumes here (thousands of
 * rows, not millions) make it a non-issue.
 */

require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../middleware/auth.php';
require_once __DIR__ . '/lib/config.php';
require_once __DIR__ . '/lib/Helpers.php';
require_once __DIR__ . '/lib/schema.php';
require_once __DIR__ . '/lib/Sla.php';

$jwt = require_jwt();
require_permission('freshdesk', $jwt);
fd_install_error_handlers();
fd_ensure_schema();

$ME = array('id' => isset($jwt['user_id']) ? (int)$jwt['user_id'] : null,
            'name' => isset($jwt['name']) ? $jwt['name'] : 'Agent');

$LIVE = "is_trash = 0 AND is_spam = 0 AND merged_into IS NULL";

function fd_count($where, $types = '', $params = array())
{
    $r = fd_query_one("SELECT COUNT(*) AS c FROM fd_tickets WHERE $where", $types, $params);
    return $r ? (int)$r['c'] : 0;
}

/**
 * Percentage change vs the previous window of the same length.
 * Returns ['delta' => float, 'dir' => 'up'|'down'|'flat'].
 *
 * Growth from zero is reported as 100%, not infinity -- "+∞%" on a dashboard
 * card is a bug report waiting to happen.
 */
function fd_trend($current, $previous)
{
    if ($previous <= 0) {
        return array('delta' => $current > 0 ? 100.0 : 0.0, 'dir' => $current > 0 ? 'up' : 'flat');
    }
    $d = (($current - $previous) / $previous) * 100;
    return array('delta' => round(abs($d), 1), 'dir' => $d > 0.5 ? 'up' : ($d < -0.5 ? 'down' : 'flat'));
}

$action = fd_str('action', 'dashboard');
$GLOBALS['FD_ACTION'] = $action;

/* ------------------------------------------------------------- dashboard -- */
if ($action === 'dashboard') {
    global $LIVE;
    $days = max(1, min(90, fd_int('days', 7)));
    $since     = date('Y-m-d H:i:s', strtotime("-$days days"));
    $prevSince = date('Y-m-d H:i:s', strtotime('-' . ($days * 2) . ' days'));

    $unresolved = fd_count("$LIVE AND status NOT IN ('Resolved','Closed')");
    $overdue    = fd_count("$LIVE AND sla_breached = 1 AND status NOT IN ('Resolved','Closed')");
    $open       = fd_count("$LIVE AND status IN ('Open','New','In Progress')");
    $closedMonth= fd_count("$LIVE AND status IN ('Resolved','Closed') AND (resolved_at >= ? OR closed_at >= ?)",
                           'ss', array(date('Y-m-01 00:00:00'), date('Y-m-01 00:00:00')));
    $dueToday   = fd_count("$LIVE AND status NOT IN ('Resolved','Closed') AND resolution_due BETWEEN NOW() AND ?",
                           's', array(date('Y-m-d H:i:s', strtotime('+24 hours'))));
    $newTickets = fd_count("$LIVE AND created_at >= ?", 's', array(date('Y-m-d H:i:s', strtotime('-24 hours'))));
    // Mirrors the six cards Freshdesk's own dashboard shows, so the two can be
    // compared at a glance.
    $onHold     = fd_count("$LIVE AND status IN ('Pending','On Hold','Waiting')");
    $unassigned = fd_count("$LIVE AND agent_user_id IS NULL AND status NOT IN ('Resolved','Closed')");

    // Previous-window comparisons for the little trend arrows.
    $prevNew  = fd_count("$LIVE AND created_at >= ? AND created_at < ?", 'ss',
                         array(date('Y-m-d H:i:s', strtotime('-48 hours')), date('Y-m-d H:i:s', strtotime('-24 hours'))));
    $prevUnres = fd_count("$LIVE AND status NOT IN ('Resolved','Closed') AND created_at < ?", 's', array($since));
    $prevOverdue = fd_count("$LIVE AND sla_breached = 1 AND created_at < ?", 's', array($since));

    /*
     * How much of the unresolved queue nobody has looked at. Same test the list
     * paints with: something arrived since anyone looked, OR nobody has ever
     * opened it. Computed here so the card is self-contained.
     */
    $unresUnread = fd_count("$LIVE AND status NOT IN ('Resolved','Closed') AND (unread_count > 0 OR last_read_at IS NULL)");

    /* Same six cards, same order, as Freshdesk's own dashboard. */
    $stats = array(
        array('key' => 'unresolved', 'label' => 'Unresolved', 'value' => $unresolved, 'sub' => 'Awaiting resolution',
              'unread' => $unresUnread, 'read' => max(0, $unresolved - $unresUnread),
              'trend' => fd_trend($unresolved, $prevUnres)),
        array('key' => 'overdue',    'label' => 'Overdue',    'value' => $overdue,    'sub' => 'Past SLA deadline',    'trend' => fd_trend($overdue, $prevOverdue)),
        array('key' => 'dueToday',   'label' => 'Due today',  'value' => $dueToday,   'sub' => 'Deadline within 24h',  'trend' => fd_trend($dueToday, 0)),
        array('key' => 'open',       'label' => 'Open',       'value' => $open,       'sub' => 'Currently in progress','trend' => fd_trend($open, $prevUnres)),
        array('key' => 'onHold',     'label' => 'On hold',    'value' => $onHold,     'sub' => 'Waiting on someone',   'trend' => fd_trend($onHold, 0)),
        array('key' => 'unassigned', 'label' => 'Unassigned', 'value' => $unassigned, 'sub' => 'No agent yet',         'trend' => fd_trend($unassigned, 0)),
    );

    // Still returned for the rest of the dashboard even though they no longer
    // have cards of their own.
    $extra = array('closed' => $closedMonth, 'new' => $newTickets);

    /*
     * SLA attainment over the window.
     *
     * "First response on target" counts only tickets whose clock actually
     * STOPPED (someone replied). Counting tickets nobody has answered yet as
     * "not on target" makes the number drop simply because the window is still
     * open, and counting them as on-target inflates it. Both are wrong; the
     * right denominator is answered tickets.
     */
    $frTotal = fd_query_one("SELECT COUNT(*) AS c,
                                    SUM(CASE WHEN first_response_at <= first_response_due THEN 1 ELSE 0 END) AS met
                             FROM fd_tickets
                             WHERE $LIVE AND first_response_at IS NOT NULL AND first_response_due IS NOT NULL
                               AND created_at >= ?", 's', array($since));
    $resTotal = fd_query_one("SELECT COUNT(*) AS c,
                                     SUM(CASE WHEN COALESCE(resolved_at, closed_at) <= resolution_due THEN 1 ELSE 0 END) AS met
                              FROM fd_tickets
                              WHERE $LIVE AND COALESCE(resolved_at, closed_at) IS NOT NULL AND resolution_due IS NOT NULL
                                AND created_at >= ?", 's', array($since));

    $frPct  = ($frTotal && (int)$frTotal['c'] > 0)  ? round(((int)$frTotal['met']  / (int)$frTotal['c'])  * 100) : 100;
    $resPct = ($resTotal && (int)$resTotal['c'] > 0) ? round(((int)$resTotal['met'] / (int)$resTotal['c']) * 100) : 100;
    $atRisk = fd_count("$LIVE AND sla_status = 'At risk' AND status NOT IN ('Resolved','Closed')");

    // Median-ish averages, in minutes.
    $avg = fd_query_one("SELECT
            AVG(TIMESTAMPDIFF(MINUTE, created_at, first_response_at)) AS frm,
            AVG(TIMESTAMPDIFF(MINUTE, created_at, COALESCE(resolved_at, closed_at))) AS resm
        FROM fd_tickets WHERE $LIVE AND created_at >= ?", 's', array($since));

    $dist = function ($col) use ($LIVE, $since) {
        $rows = fd_query("SELECT COALESCE(NULLIF($col,''),'Unspecified') AS k, COUNT(*) AS c
                          FROM fd_tickets WHERE $LIVE AND created_at >= ?
                          GROUP BY k ORDER BY c DESC LIMIT 12", 's', array($since));
        $out = array();
        foreach ($rows as $r) $out[] = array('name' => $r['k'], 'value' => (int)$r['c']);
        return $out;
    };

    // Per-day volume for the sparkline.
    $series = fd_query("SELECT DATE(created_at) AS d, COUNT(*) AS c
                        FROM fd_tickets WHERE $LIVE AND created_at >= ?
                        GROUP BY DATE(created_at) ORDER BY d ASC", 's', array($since));
    $byDay = array();
    foreach ($series as $s) $byDay[$s['d']] = (int)$s['c'];
    $volume = array();
    for ($i = $days - 1; $i >= 0; $i--) {
        $d = date('Y-m-d', strtotime("-$i days"));
        $volume[] = array('date' => $d, 'label' => date('j M', strtotime($d)), 'value' => isset($byDay[$d]) ? $byDay[$d] : 0);
    }

    $feed = fd_query("SELECT a.id, a.event, a.actor_type, a.actor_name, a.summary, a.ticket_id, a.created_at,
                             t.subject, t.requester_name
                      FROM fd_activity a LEFT JOIN fd_tickets t ON t.id = a.ticket_id
                      ORDER BY a.id DESC LIMIT 15");
    foreach ($feed as &$f) {
        $f['ago'] = fd_relative_time($f['created_at']);
        $f['dt']  = date('j M Y, h:i a', strtotime($f['created_at']));
    }
    unset($f);

    api_success(array(
        'stats' => $stats,
        'extra' => $extra,
        'sla' => array(
            'firstResponse' => (int)$frPct,
            'resolution'    => (int)$resPct,
            'atRisk'        => $atRisk,
            'breached'      => $overdue,
            'avgFirstResponseMins' => $avg && $avg['frm']  !== null ? round((float)$avg['frm'])  : null,
            'avgResolutionMins'    => $avg && $avg['resm'] !== null ? round((float)$avg['resm']) : null,
        ),
        'distribution' => array(
            'byCategory' => $dist('category'),
            'byPriority' => $dist('priority'),
            'bySource'   => $dist('source'),
            'byStatus'   => $dist('status'),
            'byAgent'    => $dist('agent_name'),
        ),
        'volume'   => $volume,
        'feed'     => $feed,
        'window'   => array('days' => $days, 'since' => $since),
        'totals'   => array(
            'tickets'  => fd_count($LIVE),
            'contacts' => (int)(fd_query_one("SELECT COUNT(*) AS c FROM fd_contacts")['c'] ?? 0),
            'messages' => (int)(fd_query_one("SELECT COUNT(*) AS c FROM fd_messages")['c'] ?? 0),
        ),
    ), 'OK');
}

/* ------------------------------------------------------------- analytics -- */
if ($action === 'analytics') {
    global $LIVE;
    $from = fd_str('from', date('Y-m-d', strtotime('-29 days')));
    $to   = fd_str('to', date('Y-m-d'));
    // A reversed range returns nothing and looks like a data bug; swap instead.
    if (strtotime($from) > strtotime($to)) { $tmp = $from; $from = $to; $to = $tmp; }
    $fromDt = $from . ' 00:00:00';
    $toDt   = $to . ' 23:59:59';

    $created = fd_query("SELECT DATE(created_at) AS d, COUNT(*) AS c FROM fd_tickets
                         WHERE $LIVE AND created_at BETWEEN ? AND ? GROUP BY d", 'ss', array($fromDt, $toDt));
    $resolved = fd_query("SELECT DATE(COALESCE(resolved_at, closed_at)) AS d, COUNT(*) AS c FROM fd_tickets
                          WHERE $LIVE AND COALESCE(resolved_at, closed_at) BETWEEN ? AND ? GROUP BY d", 'ss', array($fromDt, $toDt));

    $cm = array(); foreach ($created as $r)  $cm[$r['d']] = (int)$r['c'];
    $rm = array(); foreach ($resolved as $r) $rm[$r['d']] = (int)$r['c'];

    $series = array();
    $cursor = strtotime($from);
    $end = strtotime($to);
    $guard = 0;
    while ($cursor <= $end && $guard++ < 400) {
        $d = date('Y-m-d', $cursor);
        $series[] = array(
            'date'     => $d,
            'label'    => date('j M', $cursor),
            'created'  => isset($cm[$d]) ? $cm[$d] : 0,
            'resolved' => isset($rm[$d]) ? $rm[$d] : 0,
        );
        $cursor = strtotime('+1 day', $cursor);
    }

    $summary = fd_query_one("SELECT
            COUNT(*) AS total,
            SUM(CASE WHEN status IN ('Resolved','Closed') THEN 1 ELSE 0 END) AS resolved,
            SUM(CASE WHEN sla_breached = 1 THEN 1 ELSE 0 END) AS breached,
            AVG(TIMESTAMPDIFF(MINUTE, created_at, first_response_at)) AS avg_first,
            AVG(TIMESTAMPDIFF(MINUTE, created_at, COALESCE(resolved_at, closed_at))) AS avg_res
        FROM fd_tickets WHERE $LIVE AND created_at BETWEEN ? AND ?", 'ss', array($fromDt, $toDt));

    api_success(array('series' => $series, 'summary' => $summary, 'from' => $from, 'to' => $to), 'OK');
}

/* ---------------------------------------------------------------- agents -- */
if ($action === 'agents') {
    global $LIVE;
    $days = max(1, min(180, fd_int('days', 30)));
    $since = date('Y-m-d H:i:s', strtotime("-$days days"));

    $rows = fd_query("SELECT
            t.agent_name AS agent,
            COUNT(*) AS assigned,
            SUM(CASE WHEN t.status IN ('Resolved','Closed') THEN 1 ELSE 0 END) AS resolved,
            SUM(CASE WHEN t.status NOT IN ('Resolved','Closed') THEN 1 ELSE 0 END) AS openCount,
            SUM(CASE WHEN t.sla_breached = 1 THEN 1 ELSE 0 END) AS breached,
            AVG(TIMESTAMPDIFF(MINUTE, t.created_at, t.first_response_at)) AS avgFirst,
            AVG(TIMESTAMPDIFF(MINUTE, t.created_at, COALESCE(t.resolved_at, t.closed_at))) AS avgRes
        FROM fd_tickets t
        WHERE $LIVE AND t.created_at >= ?
        GROUP BY t.agent_name ORDER BY assigned DESC LIMIT 50", 's', array($since));

    $out = array();
    foreach ($rows as $r) {
        $assigned = (int)$r['assigned'];
        $out[] = array(
            'agent'     => $r['agent'],
            'assigned'  => $assigned,
            'resolved'  => (int)$r['resolved'],
            'open'      => (int)$r['openCount'],
            'breached'  => (int)$r['breached'],
            'slaPct'    => $assigned > 0 ? round((($assigned - (int)$r['breached']) / $assigned) * 100) : 100,
            'avgFirstMins' => $r['avgFirst'] !== null ? round((float)$r['avgFirst']) : null,
            'avgResMins'   => $r['avgRes']   !== null ? round((float)$r['avgRes'])   : null,
        );
    }
    api_success(array('agents' => $out, 'days' => $days), 'OK');
}

/* ------------------------------------------------------------------ feed -- */
if ($action === 'feed') {
    $limit = max(1, min(100, fd_int('limit', 20)));
    $rows = fd_query("SELECT a.id, a.event, a.actor_type, a.actor_name, a.summary, a.ticket_id, a.created_at,
                             t.subject, t.requester_name
                      FROM fd_activity a LEFT JOIN fd_tickets t ON t.id = a.ticket_id
                      ORDER BY a.id DESC LIMIT $limit");
    foreach ($rows as &$r) {
        $r['ago'] = fd_relative_time($r['created_at']);
        $r['dt']  = date('j M Y, h:i a', strtotime($r['created_at']));
    }
    unset($r);
    api_success(array('feed' => $rows), 'OK');
}

api_error('Unknown action: ' . $action, 400);

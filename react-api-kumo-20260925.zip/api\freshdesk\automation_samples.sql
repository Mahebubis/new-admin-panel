-- ---------------------------------------------------------------------------
-- Sample automation rules for the Freshdesk helpdesk.
--
-- Run these AFTER the app has been opened once, so fd_ensure_schema() has
-- created fd_automations (with its match_type and kind columns) and
-- fd_automation_log. Nothing here is required: the Automation screen writes
-- exactly these rows itself. They are here so you can seed a working set in
-- one go, and as a reference for the JSON shape the engine reads.
--
-- HOW A RULE IS READ
--   event       ticket_created | ticket_updated | tag_added
--   match_type  all  = every condition must hold (AND)
--               any  = one is enough            (OR)
--   conditions  [{"field":..,"op":..,"value":..}, ...]
--     field     subject | description | subject_or_description | from_email |
--               from_name | status | priority | category | agent | tags
--     op        contains | not_contains | is | is_not | starts_with |
--               ends_with | any_of | is_empty | is_not_empty
--   actions     [{"type":..,"value":..}, ...] executed in order
--     type      set_status | set_priority | assign_agent | add_tag |
--               set_category | forward | notify | send_canned
--   kind        which module screen the rule appears on:
--               closure | forward | notify | canned
--
-- An empty condition value matches NOTHING, so a half-written rule cannot
-- fire on every ticket. A rule with no conditions at all matches every ticket
-- -- that is deliberate, and it is how you write "always do this".
--
-- A rule runs at most once per ticket. That is what stops a rule whose action
-- edits the ticket from re-triggering itself forever.
-- ---------------------------------------------------------------------------


-- 1. The example you asked for: close anything whose subject says "mahhe".
INSERT INTO fd_automations
  (name, description, event, match_type, kind, conditions, actions, is_active, position, created_by_name)
VALUES
  ('Close "mahhe" emails',
   'Closes any ticket whose subject contains mahhe.',
   'ticket_created', 'all', 'closure',
   '[{"field":"subject","op":"contains","value":"mahhe"}]',
   '[{"type":"set_status","value":"Closed"}]',
   1, 0, 'Seed');


-- 2. Auto-close thank-you replies. OR, because any one of these words is enough.
INSERT INTO fd_automations
  (name, description, event, match_type, kind, conditions, actions, is_active, position, created_by_name)
VALUES
  ('Auto-close Thank-You emails',
   'Resolves a ticket when the customer only writes back to say thanks.',
   'ticket_updated', 'any', 'closure',
   '[{"field":"subject_or_description","op":"any_of","value":"thank you, thanks, much appreciated"}]',
   '[{"type":"set_status","value":"Resolved"},{"type":"add_tag","value":"Auto-resolved"}]',
   1, 1, 'Seed');


-- 3. Close out-of-office bounces without answering them.
INSERT INTO fd_automations
  (name, description, event, match_type, kind, conditions, actions, is_active, position, created_by_name)
VALUES
  ('Close Out-of-Office replies',
   'Out-of-office autoresponders are not support requests.',
   'ticket_created', 'any', 'closure',
   '[{"field":"subject_or_description","op":"any_of","value":"out of office, auto-reply, automatic reply, on vacation"}]',
   '[{"type":"set_status","value":"Closed"},{"type":"add_tag","value":"Auto-reply"}]',
   1, 2, 'Seed');


-- 4. Spam domain: close it and tag it, so the tag explains the closure later.
INSERT INTO fd_automations
  (name, description, event, match_type, kind, conditions, actions, is_active, position, created_by_name)
VALUES
  ('Spam domain closure',
   'Closes mail from a known bulk sender.',
   'ticket_created', 'all', 'closure',
   '[{"field":"from_email","op":"ends_with","value":"@promo-blast.co"}]',
   '[{"type":"set_status","value":"Closed"},{"type":"add_tag","value":"Spam"}]',
   0, 3, 'Seed');


-- 5. Forward billing tickets to finance. "cc" and "bcc" are optional; "note"
--    replaces the default covering line. The original thread is always quoted.
INSERT INTO fd_automations
  (name, description, event, match_type, kind, conditions, actions, is_active, position, created_by_name)
VALUES
  ('Billing → Finance',
   'Routes billing tickets to the finance inbox.',
   'ticket_created', 'all', 'forward',
   '[{"field":"category","op":"is","value":"Billing"}]',
   '[{"type":"forward","value":"finance@istudio.in","cc":"","bcc":"","note":"Billing query for {Customer Name}, ticket {Ticket ID}."}]',
   1, 4, 'Seed');


-- 6. Forward on a keyword rather than a category.
INSERT INTO fd_automations
  (name, description, event, match_type, kind, conditions, actions, is_active, position, created_by_name)
VALUES
  ('Refund requests → Finance',
   'Anything mentioning a refund or chargeback goes to finance.',
   'ticket_created', 'any', 'forward',
   '[{"field":"subject_or_description","op":"any_of","value":"refund, chargeback, money back"}]',
   '[{"type":"forward","value":"finance@istudio.in","cc":"lead@istudio.in","bcc":"","note":""}]',
   1, 5, 'Seed');


-- 7. Tell the team the moment a ticket is tagged Urgent. Notifications go to
--    your own staff as a plain email -- they are not added to the customer's
--    ticket. Merge tags in "template" are filled in before sending.
INSERT INTO fd_automations
  (name, description, event, match_type, kind, conditions, actions, is_active, position, created_by_name)
VALUES
  ('Urgent tag alert',
   'Alerts ops and the support lead when a ticket is tagged Urgent.',
   'tag_added', 'all', 'notify',
   '[{"field":"tags","op":"contains","value":"Urgent"}]',
   '[{"type":"notify","value":"ops@istudio.in, lead@istudio.in","template":"Ticket {Ticket ID} from {Customer Name} was tagged Urgent.\\nSubject: {Ticket Subject}\\nStatus: {Status} · Priority: {Priority}"}]',
   1, 6, 'Seed');


-- 8. A VIP alert that also raises the priority.
INSERT INTO fd_automations
  (name, description, event, match_type, kind, conditions, actions, is_active, position, created_by_name)
VALUES
  ('VIP tag alert',
   'Raises priority and tells customer success when a VIP writes in.',
   'tag_added', 'all', 'notify',
   '[{"field":"tags","op":"contains","value":"VIP"}]',
   '[{"type":"notify","value":"success@istudio.in","template":"VIP ticket {Ticket ID} from {Customer Name}: {Ticket Subject}"},{"type":"set_priority","value":"High"}]',
   1, 7, 'Seed');


-- 9. Send a canned response automatically. The value is the canned response's
--    name (or its numeric id) from fd_canned_responses, and it must be active.
INSERT INTO fd_automations
  (name, description, event, match_type, kind, conditions, actions, is_active, position, created_by_name)
VALUES
  ('Certificate query auto-reply',
   'Answers the most common certificate question immediately.',
   'ticket_created', 'any', 'canned',
   '[{"field":"subject_or_description","op":"any_of","value":"certificate, certificate download, my certificate"}]',
   '[{"type":"send_canned","value":"Certificate Download Steps"}]',
   0, 8, 'Seed');


-- ---------------------------------------------------------------------------
-- The four module switches live in the settings table, not here. They gate the
-- ACTIONS, so a rule can stay on while its action type is off globally -- the
-- run log then says "forwarding module off" rather than silently doing nothing.
-- The Automation screen's four toggles write exactly these rows.
-- ---------------------------------------------------------------------------
-- SELECT * FROM fd_settings WHERE setting_key LIKE 'AUTOMATION_%';


-- Check what the rules have actually done:
-- SELECT l.created_at, l.rule_name, l.ticket_id, l.applied, l.skipped
--   FROM fd_automation_log l ORDER BY l.id DESC LIMIT 50;

-- Clear the once-per-ticket guard for one rule, so it can act on those
-- tickets again. Only do this deliberately: it is what lets a rule re-fire.
-- DELETE FROM fd_automation_log WHERE rule_id = <id>;

<?php
/*
 * /api/freshdesk/lib/Sla.php
 *
 * SLA clocks. Two independent timers per ticket:
 *
 *   first response  -- created_at + policy[priority].first, stopped forever by
 *                      the first outbound agent reply.
 *   resolution      -- created_at + policy[priority].resolve, stopped when the
 *                      ticket reaches Resolved/Closed.
 *
 * The badge the list shows is the WORSE of the two live clocks, so a ticket
 * that answered fast but is drifting towards a missed resolution still turns
 * amber. Only clocks that are still running are considered -- once an agent has
 * replied, a long-past first-response target must not keep the ticket red
 * forever; that is what trains agents to ignore the colour entirely.
 *
 * Everything is recomputed from timestamps rather than incremented, so a
 * priority change, a reopen, or a worker that missed a tick all self-heal on
 * the next read.
 */

/** Absolute due times for a ticket, from its creation time and priority. */
function fd_sla_due_dates($createdAt, $priority)
{
    $p = fd_sla_policy($priority);
    $base = strtotime($createdAt);
    if (!$base) $base = time();
    return array(
        'first_response_due' => date('Y-m-d H:i:s', $base + ((int)$p['first'] * 60)),
        'resolution_due'     => date('Y-m-d H:i:s', $base + ((int)$p['resolve'] * 60)),
    );
}

/**
 * Evaluate one clock.
 * @return 'Breached' | 'At risk' | 'On track' | null (clock not running)
 */
function fd_sla_clock_state($createdAt, $dueAt, $stoppedAt)
{
    if (!$dueAt) return null;
    $due = strtotime($dueAt);
    if (!$due) return null;

    // A stopped clock is judged by whether it was met, not by the wall clock.
    if ($stoppedAt) {
        $done = strtotime($stoppedAt);
        return ($done !== false && $done > $due) ? 'Breached' : null;
    }

    $now = time();
    if ($now > $due) return 'Breached';

    $start = strtotime($createdAt);
    if (!$start || $due <= $start) return 'On track';

    $ratio = ($now - $start) / ($due - $start);
    $risk  = (float)fd_cfg('SLA_RISK_RATIO', FD_SLA_RISK_RATIO);
    if ($risk <= 0 || $risk >= 1) $risk = 0.75;

    return ($ratio >= $risk) ? 'At risk' : 'On track';
}

/**
 * The badge for a whole ticket: worst live clock wins.
 * @return array ['status' => 'On track'|'At risk'|'Breached', 'breached' => 0|1]
 */
function fd_sla_evaluate($ticket)
{
    $created  = isset($ticket['created_at']) ? $ticket['created_at'] : null;
    $resolved = !empty($ticket['resolved_at']) ? $ticket['resolved_at'] : (!empty($ticket['closed_at']) ? $ticket['closed_at'] : null);
    $status   = isset($ticket['status']) ? $ticket['status'] : 'Open';

    // Closed work is history: report whether the targets were met, and stop
    // repainting it every time the page reloads.
    $isDone = in_array($status, array('Resolved', 'Closed'), true) || $resolved;

    $states = array();
    $states[] = fd_sla_clock_state($created, isset($ticket['first_response_due']) ? $ticket['first_response_due'] : null,
                                   !empty($ticket['first_response_at']) ? $ticket['first_response_at'] : ($isDone ? $resolved : null));
    $states[] = fd_sla_clock_state($created, isset($ticket['resolution_due']) ? $ticket['resolution_due'] : null,
                                   $isDone ? ($resolved ?: date('Y-m-d H:i:s')) : null);

    $rank = array('On track' => 0, 'At risk' => 1, 'Breached' => 2);
    $worst = 'On track'; $worstRank = 0;
    foreach ($states as $s) {
        if ($s === null) continue;
        if ($rank[$s] > $worstRank) { $worstRank = $rank[$s]; $worst = $s; }
    }
    return array('status' => $worst, 'breached' => $worst === 'Breached' ? 1 : 0);
}

/**
 * Recompute and persist SLA for one ticket. Cheap enough to call after every
 * write that could move a clock (new message, priority change, status change).
 */
function fd_sla_refresh($ticketId)
{
    $t = fd_query_one("SELECT id, created_at, priority, status, first_response_at, first_response_due,
                              resolution_due, resolved_at, closed_at
                       FROM fd_tickets WHERE id = ?", 'i', array((int)$ticketId));
    if (!$t) return null;

    // Backfill due dates for rows created before a policy existed.
    if (empty($t['first_response_due']) || empty($t['resolution_due'])) {
        $due = fd_sla_due_dates($t['created_at'], $t['priority']);
        fd_exec("UPDATE fd_tickets SET first_response_due = ?, resolution_due = ? WHERE id = ?",
                'ssi', array($due['first_response_due'], $due['resolution_due'], (int)$ticketId));
        $t['first_response_due'] = $due['first_response_due'];
        $t['resolution_due']     = $due['resolution_due'];
    }

    $ev = fd_sla_evaluate($t);
    fd_exec("UPDATE fd_tickets SET sla_status = ?, sla_breached = ? WHERE id = ?",
            'sii', array($ev['status'], $ev['breached'], (int)$ticketId));
    return $ev;
}

/**
 * Re-apply due dates after a priority change -- an escalation to Urgent must
 * shorten the clock, and it is measured from creation, not from the change.
 */
function fd_sla_reprice($ticketId, $newPriority)
{
    $t = fd_query_one("SELECT created_at FROM fd_tickets WHERE id = ?", 'i', array((int)$ticketId));
    if (!$t) return;
    $due = fd_sla_due_dates($t['created_at'], $newPriority);
    fd_exec("UPDATE fd_tickets SET first_response_due = ?, resolution_due = ? WHERE id = ?",
            'ssi', array($due['first_response_due'], $due['resolution_due'], (int)$ticketId));
    fd_sla_refresh($ticketId);
}

/**
 * Sweep every open ticket and refresh its badge. Run from the sync cron -- an
 * SLA that only moves when someone opens the page is not an SLA.
 * Bounded so one run can never turn into a table scan of a year of history.
 */
function fd_sla_sweep($limit = 500)
{
    $rows = fd_query("SELECT id, created_at, priority, status, first_response_at, first_response_due,
                             resolution_due, resolved_at, closed_at
                      FROM fd_tickets
                      WHERE status NOT IN ('Resolved','Closed') AND is_trash = 0 AND is_spam = 0
                      ORDER BY updated_at DESC LIMIT " . (int)$limit);
    $changed = 0;
    $breached = array();
    foreach ($rows as $t) {
        $ev = fd_sla_evaluate($t);
        $curr = isset($t['sla_status']) ? $t['sla_status'] : null;
        if ($curr !== $ev['status']) {
            fd_exec("UPDATE fd_tickets SET sla_status = ?, sla_breached = ? WHERE id = ?",
                    'sii', array($ev['status'], $ev['breached'], (int)$t['id']));
            $changed++;
            if ($ev['status'] === 'Breached') $breached[] = (int)$t['id'];
        }
    }

    /*
     * ONE aggregated event, not one per ticket.
     *
     * A sweep across an imported backlog breaches hundreds of tickets in a
     * single pass. Emitting per ticket wrote hundreds of near-identical rows
     * into fd_activity and buried every real event -- new mail, replies,
     * assignments -- under a wall of "SLA breached on #…". The feed is a
     * narrative of what happened, and "312 tickets breached" is the sentence a
     * human actually wants.
     */
    if (!empty($breached)) {
        $n = count($breached);
        fd_emit('sla-breach', array(
            'count'   => $n,
            // Enough to click through; the rest are findable in the Overdue view.
            'tickets' => array_slice($breached, 0, 20),
        ), array(
            'ticket_id' => $n === 1 ? $breached[0] : null,
            'summary'   => $n === 1
                ? ('SLA breached on #' . $breached[0])
                : ($n . ' tickets breached their SLA'),
        ));
    }

    return $changed;
}

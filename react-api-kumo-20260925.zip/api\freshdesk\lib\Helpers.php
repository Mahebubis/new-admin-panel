<?php
/*
 * /api/freshdesk/lib/Helpers.php
 *
 * Small, dependency-free utilities shared by every Freshdesk entrypoint:
 * input reading, logging, HTML sanitising, quote-trimming, relative time,
 * and the ticket-token helpers that make email threading work.
 *
 * Nothing in here touches the network or the mailbox -- keep it that way so it
 * stays safe to require from any context, including the cron worker.
 */

/* ---------------------------------------------------------------- input --- */

/**
 * One reader for every entrypoint. The panel sends JSON bodies (axios) for
 * writes and querystrings for reads, and multipart for uploads; older callers
 * post form-encoded. Read them all rather than making each endpoint guess.
 *
 * The decoded JSON body is cached because php://input can only be read once
 * on some SAPI configurations -- a second read returns an empty string and the
 * endpoint silently sees no parameters at all.
 */
function fd_input($key = null, $default = null) {
    static $body = null;
    if ($body === null) {
        $body = array();
        $raw  = file_get_contents('php://input');
        if ($raw !== '' && $raw !== false) {
            $j = json_decode($raw, true);
            if (is_array($j)) $body = $j;
        }
    }
    $merged = array_merge($body, $_GET, $_POST);
    if ($key === null) return $merged;
    if (!array_key_exists($key, $merged)) return $default;
    $v = $merged[$key];
    if ($v === '' || $v === null) return $default;
    return $v;
}

/** Trimmed string input. */
function fd_str($key, $default = '') {
    $v = fd_input($key, $default);
    return is_string($v) ? trim($v) : (is_scalar($v) ? trim((string)$v) : $default);
}

/** Integer input. */
function fd_int($key, $default = 0) {
    return (int)fd_input($key, $default);
}

/** Boolean input tolerant of "1"/"true"/"yes"/"on". */
function fd_bool($key, $default = false) {
    $v = fd_input($key, null);
    if ($v === null) return $default;
    if (is_bool($v)) return $v;
    $s = strtolower(trim((string)$v));
    return in_array($s, array('1', 'true', 'yes', 'on'), true);
}

/**
 * Array input. The panel sends real JSON arrays, but a plain form post can only
 * send a JSON *string* -- accept both so no caller has to care.
 */
function fd_arr($key, $default = array()) {
    $v = fd_input($key, null);
    if ($v === null) return $default;
    if (is_array($v)) return $v;
    $j = json_decode((string)$v, true);
    if (is_array($j)) return $j;
    // last resort: comma separated
    $s = trim((string)$v);
    return $s === '' ? $default : array_map('trim', explode(',', $s));
}

/* ------------------------------------------------------------- logging --- */

/**
 * Append one line to freshdesk.log. Every mailbox connection, send, sync run
 * and failure goes through here -- when a customer says "I mailed you and got
 * nothing back", this file is the answer, and it is readable without DB access.
 *
 * Self-truncating: once past FD_LOG_MAX_BYTES the file is rotated to .1 so a
 * chatty failure loop can never fill the account's disk quota.
 */
function fd_log($level, $message, $context = array()) {
    $path = FD_LOG_PATH;
    try {
        if (@file_exists($path) && @filesize($path) > FD_LOG_MAX_BYTES) {
            @rename($path, $path . '.1');
        }
        $line = date('Y-m-d H:i:s') . ' | ' . str_pad(strtoupper($level), 5) . ' | ' . $message;
        if (!empty($context)) $line .= ' | ' . json_encode($context, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
        @file_put_contents($path, $line . "\n", FILE_APPEND | LOCK_EX);
    } catch (Throwable $e) {
        // Logging must never be the thing that breaks a request.
    }
}

/**
 * Install handlers so a fatal/uncaught error in any Freshdesk endpoint still
 * answers the panel with JSON instead of an HTML error page or -- worse -- a
 * 200 with a blank body, which axios reports as an unhelpful "parse error".
 *
 * Call this immediately after the auth gate in every entrypoint.
 */
function fd_install_error_handlers() {
    set_exception_handler(function ($e) {
        fd_log('error', 'Uncaught exception: ' . $e->getMessage(), array(
            'action' => isset($GLOBALS['FD_ACTION']) ? $GLOBALS['FD_ACTION'] : null,
            'file' => $e->getFile(), 'line' => $e->getLine(),
        ));
        if (!headers_sent()) {
            http_response_code(500);
            header('Content-Type: application/json; charset=UTF-8');
        }
        echo json_encode(array('success' => false, 'message' => 'Server error: ' . $e->getMessage(), 'data' => array()));
        exit;
    });
    register_shutdown_function(function () {
        $err = error_get_last();
        if ($err && in_array($err['type'], array(E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR), true)) {
            fd_log('error', 'Fatal: ' . $err['message'], array('file' => $err['file'], 'line' => $err['line']));
            if (!headers_sent()) {
                http_response_code(500);
                header('Content-Type: application/json; charset=UTF-8');
            }
            echo json_encode(array('success' => false, 'message' => 'Fatal error: ' . $err['message'], 'data' => array()));
        }
    });
}

/* ------------------------------------------------------------ html/text --- */

/**
 * Make a customer's HTML email safe to render inside the agent panel.
 *
 * This is the single most security-sensitive function in the feature: the body
 * is attacker-controlled text from a stranger on the internet, and it is about
 * to be injected into an authenticated admin page. Anything that slips through
 * runs with the agent's session.
 *
 * Strategy is allow-nothing-dangerous rather than blocklist-a-few-tags:
 *   - <script>, <style>, <iframe>, <object>, <embed>, <form>, <link>, <meta>,
 *     <base> and their contents are removed outright.
 *   - every on* event attribute is stripped.
 *   - javascript:/vbscript:/data: URLs are neutered (data: images excepted --
 *     inline screenshots are the single most common attachment).
 *   - remote <img> are rewritten to a placeholder unless the agent clicks
 *     "show images" (the frontend swaps data-fd-src back in), so merely opening
 *     a ticket does not confirm the address to a spammer's tracking pixel.
 */
function fd_sanitize_html($html, $blockRemoteImages = true) {
    if ($html === null || $html === '') return '';
    $s = (string)$html;

    // Kill dangerous elements together with their content.
    $s = preg_replace('#<\s*(script|style|iframe|object|embed|form|link|meta|base|applet|frameset|frame)\b[^>]*>.*?<\s*/\s*\1\s*>#is', '', $s);
    // ...and their self-closing / unterminated variants.
    $s = preg_replace('#<\s*/?\s*(script|style|iframe|object|embed|form|link|meta|base|applet|frameset|frame)\b[^>]*>#is', '', $s);

    // Strip every inline event handler (onclick=, onerror=, onload=, ...).
    $s = preg_replace('#\son[a-z]+\s*=\s*"[^"]*"#i', '', $s);
    $s = preg_replace("#\son[a-z]+\s*=\s*'[^']*'#i", '', $s);
    $s = preg_replace('#\son[a-z]+\s*=\s*[^\s>]+#i', '', $s);

    // Neuter script-bearing URL schemes wherever they appear in an attribute.
    $s = preg_replace('#(href|src|action|background|formaction)\s*=\s*(["\']?)\s*(javascript|vbscript)\s*:#i', '$1=$2#blocked:', $s);
    // CSS expression()/url(javascript:) in surviving style attributes.
    $s = preg_replace('#expression\s*\(#i', 'blocked(', $s);
    $s = preg_replace('#url\s*\(\s*["\']?\s*(javascript|vbscript)\s*:#i', 'url(#blocked:', $s);

    if ($blockRemoteImages) {
        // Move remote image sources into data-fd-src. The panel shows a
        // "Images blocked" chip and restores them on demand. cid: sources are
        // left alone -- those are the message's own inline attachments, already
        // rewritten to our attachment endpoint by MimeParser.
        $s = preg_replace_callback('#<img\b([^>]*)>#i', function ($m) {
            $attrs = $m[1];
            // Already parked by an earlier pass. Parking it again would add a
            // second, empty data-fd-src that nothing afterwards removes.
            if (stripos($attrs, 'data-fd-blocked') !== false
                || stripos($attrs, 'data-fd-src') !== false) {
                return '<img' . $attrs . '>';
            }
            if (preg_match('#\ssrc\s*=\s*(["\'])(.*?)\1#is', $attrs, $sm)) {
                $url = trim($sm[2]);
                // An empty source loads nothing, so there is nothing to block.
                if ($url === '') return '<img' . $attrs . '>';
                /*
                 * Three kinds of source are the message's own and are never
                 * blocked: an inline data: URI, one of our attachment URLs,
                 * and a cid: reference -- which points at a part of THIS
                 * message and cannot reach the network at all. cid: is here
                 * because this pass runs before the one that turns those
                 * references into attachment URLs.
                 */
                $isSafeLocal = (stripos($url, 'data:image/') === 0)
                            || (stripos($url, 'cid:') === 0)
                            || (strpos($url, 'fd_attachments.php') !== false);
                if (!$isSafeLocal) {
                    $attrs = str_replace($sm[0], ' data-fd-src=' . $sm[1] . $sm[2] . $sm[1] . ' src="" data-fd-blocked="1"', $attrs);
                }
            }
            return '<img' . $attrs . '>';
        }, $s);
    }

    // Every surviving link opens in a new tab and cannot reach back into the
    // panel through window.opener.
    $s = preg_replace('#<a\b(?![^>]*\btarget=)#i', '<a target="_blank" rel="noopener noreferrer nofollow" ', $s);

    return $s;
}

/**
 * Flatten HTML to plain text for the list-view snippet and for search.
 * Block-level tags become newlines first so "Hi there</p><p>Thanks" does not
 * come out as "Hi thereThanks".
 */
function fd_html_to_text($html) {
    if ($html === null || $html === '') return '';
    $s = (string)$html;
    $s = preg_replace('#<\s*(script|style)\b[^>]*>.*?<\s*/\s*\1\s*>#is', ' ', $s);
    $s = preg_replace('#<\s*br\s*/?\s*>#i', "\n", $s);
    $s = preg_replace('#<\s*/\s*(p|div|tr|li|h[1-6]|table|blockquote)\s*>#i', "\n", $s);
    $s = strip_tags($s);
    $s = html_entity_decode($s, ENT_QUOTES | ENT_HTML5, 'UTF-8');
    $s = str_replace("\xc2\xa0", ' ', $s);              // nbsp
    $s = preg_replace("#[ \t]+#", ' ', $s);
    $s = preg_replace("#\n{3,}#", "\n\n", $s);
    return trim($s);
}

/**
 * Cut the quoted history off a reply so the conversation view shows what the
 * person actually wrote, not the entire thread pasted back at us each time.
 * The original text is kept in the DB; this only produces the collapsed view.
 *
 * Matches the separators the common clients emit. Deliberately conservative --
 * a missed quote block is ugly, a false positive eats the customer's message.
 */
function fd_strip_quoted_text($text) {
    if ($text === null || $text === '') return '';
    $markers = array(
        '#^\s*On .{5,120}\bwrote:\s*$#im',                        // Gmail / Apple Mail
        '#^\s*-{2,}\s*Original Message\s*-{2,}\s*$#im',           // Outlook (en)
        '#^\s*-{2,}\s*Forwarded message\s*-{2,}\s*$#im',
        '#^\s*_{10,}\s*$#m',                                      // Outlook divider rule
        '#^\s*From:\s.+\bSent:\s#ims',                            // Outlook header block
        '#^\s*>{1,}\s?.*(\n\s*>{1,}\s?.*){3,}#m',                 // 4+ consecutive quote lines
    );
    $cut = strlen($text);
    foreach ($markers as $re) {
        if (preg_match($re, $text, $m, PREG_OFFSET_CAPTURE)) {
            $at = $m[0][1];
            if ($at > 0 && $at < $cut) $cut = $at;
        }
    }
    $out = rtrim(substr($text, 0, $cut));
    // If quote-stripping ate everything, the heuristic was wrong -- keep the original.
    return $out === '' ? trim($text) : $out;
}

/** First N characters of the visible body, single-line, for list rows. */
function fd_snippet($text, $len = 180) {
    $t = preg_replace('#\s+#u', ' ', trim((string)$text));
    if ($t === '') return '';
    if (function_exists('mb_substr')) {
        return mb_strlen($t, 'UTF-8') > $len ? mb_substr($t, 0, $len, 'UTF-8') . '...' : $t;
    }
    return strlen($t) > $len ? substr($t, 0, $len) . '...' : $t;
}

/* ---------------------------------------------------------- ticket token --- */

/** The token stamped into outgoing subjects, e.g. "[#IS-336270]". */
function fd_ticket_token($ticketNo) {
    return '[#' . fd_cfg('TICKET_TOKEN_PREFIX', 'IS') . '-' . $ticketNo . ']';
}

/** Pull a ticket number back out of an incoming subject, or null. */
function fd_parse_ticket_token($subject) {
    $prefix = preg_quote((string)fd_cfg('TICKET_TOKEN_PREFIX', 'IS'), '#');
    if (preg_match('#\[\s*\#\s*' . $prefix . '\s*-\s*(\d+)\s*\]#i', (string)$subject, $m)) {
        return (int)$m[1];
    }
    return null;
}

/** Subject with any existing token and Re:/Fwd: prefixes removed -- the "base" subject. */
function fd_normalize_subject($subject) {
    $s = (string)$subject;
    $prefix = preg_quote((string)fd_cfg('TICKET_TOKEN_PREFIX', 'IS'), '#');
    $s = preg_replace('#\[\s*\#\s*' . $prefix . '\s*-\s*\d+\s*\]#i', '', $s);
    // Strip any number of stacked Re:/RE:/Fwd:/FW:/Antwort: prefixes.
    $s = preg_replace('#^(\s*(re|aw|fw|fwd|antwort|res|sv|vs)\s*(\[\d+\])?\s*:\s*)+#i', '', $s);
    return trim(preg_replace('#\s+#u', ' ', $s));
}

/* ----------------------------------------------------------------- misc --- */

/** "5 min ago" / "2 hours ago" -- the relative strings the ticket list renders. */
function fd_relative_time($mysqlDatetime) {
    if (!$mysqlDatetime || $mysqlDatetime === '0000-00-00 00:00:00') return '';
    $ts = strtotime($mysqlDatetime);
    if (!$ts) return '';
    $d = time() - $ts;
    if ($d < 0)    return 'just now';
    if ($d < 45)   return 'just now';
    if ($d < 90)   return 'a minute ago';
    if ($d < 3600) return floor($d / 60) . ' minutes ago';
    if ($d < 7200) return 'an hour ago';
    if ($d < 86400)  return floor($d / 3600) . ' hours ago';
    if ($d < 172800) return 'yesterday';
    if ($d < 2592000) return floor($d / 86400) . ' days ago';
    if ($d < 5184000) return 'a month ago';
    return floor($d / 2592000) . ' months ago';
}

/** "in 30 min" / "overdue by 2h" -- the SLA due strings. */
function fd_due_text($mysqlDatetime) {
    if (!$mysqlDatetime || $mysqlDatetime === '0000-00-00 00:00:00') return '';
    $ts = strtotime($mysqlDatetime);
    if (!$ts) return '';
    $d = $ts - time();
    $over = $d < 0;
    $d = abs($d);
    if ($d < 60)     $txt = 'less than a minute';
    elseif ($d < 3600)  $txt = floor($d / 60) . ' min';
    elseif ($d < 86400) $txt = floor($d / 3600) . ' hours';
    else                $txt = floor($d / 86400) . ' days';
    return $over ? ('overdue by ' . $txt) : ('in ' . $txt);
}

/** Split "Full Name" into initials for the avatar, mirroring the frontend. */
function fd_display_name($name, $email) {
    $n = trim((string)$name);
    if ($n !== '') return $n;
    $e = (string)$email;
    $local = strpos($e, '@') !== false ? substr($e, 0, strpos($e, '@')) : $e;
    $local = str_replace(array('.', '_', '-', '+'), ' ', $local);
    $local = preg_replace('#\d+#', '', $local);
    $local = trim(preg_replace('#\s+#', ' ', $local));
    return $local === '' ? $e : ucwords($local);
}

/** Lowercased, trimmed email -- the canonical form used for all contact matching. */
function fd_norm_email($email) {
    return strtolower(trim((string)$email));
}

/** RFC 5322 Message-ID we can recognise as ours on the way back in. */
function fd_generate_message_id() {
    $host = (string)fd_cfg('FROM_EMAIL', 'contact@internshipstudio.com');
    $domain = strpos($host, '@') !== false ? substr($host, strpos($host, '@') + 1) : 'internshipstudio.com';
    return '<fd.' . bin2hex(random_bytes(12)) . '.' . time() . '@' . $domain . '>';
}

/** Whether an address is one of ours -- used to ignore our own copies on sync. */
function fd_is_own_address($email) {
    $e = fd_norm_email($email);
    if ($e === '') return false;
    $ours = array(
        fd_norm_email(fd_cfg('FROM_EMAIL', '')),
        fd_norm_email(fd_cfg('IMAP_USER', '')),
        fd_norm_email(fd_cfg('SMTP_USER', '')),
        fd_norm_email(fd_cfg('REPLY_TO', '')),
    );
    return in_array($e, array_filter($ours), true);
}

/* ------------------------------------------------------ signed attachments --- */

/*
 * A customer's email body contains <img src="cid:...">, which we rewrite to
 * point at fd_attachments.php. The browser loads those itself, and a browser
 * attaches no Authorization header to an <img> request -- so a JWT-only
 * attachment endpoint renders every inline screenshot as a broken image, and
 * every "Download" link as a 401.
 *
 * The fix is a capability URL: a short-lived HMAC over (attachment id, expiry),
 * keyed on the app's JWT secret. It grants access to exactly ONE attachment,
 * for a few hours, and cannot be edited into a different id without the secret.
 * Signatures are minted per response, so a URL scraped out of the DOM stops
 * working shortly after the agent closes the ticket.
 */

/** Seconds a freshly-minted attachment URL stays valid. */
if (!defined('FD_ATTACH_URL_TTL')) define('FD_ATTACH_URL_TTL', 6 * 3600);

function fd_attachment_sig($id, $exp)
{
    $secret = defined('JWT_SECRET_KEY') ? JWT_SECRET_KEY : 'fd-fallback-secret';
    return hash_hmac('sha256', 'fd-attach|' . (int)$id . '|' . (int)$exp, $secret);
}

function fd_verify_attachment_sig($id, $exp, $sig)
{
    if ((int)$id <= 0 || (int)$exp <= 0 || !is_string($sig) || $sig === '') return false;
    if ((int)$exp < time()) return false;
    // hash_equals, not ==: a plain comparison leaks the signature one byte at a
    // time through response timing.
    return hash_equals(fd_attachment_sig($id, $exp), $sig);
}

/** A ready-to-use, signed attachment URL. Relative -- the client resolves it. */
function fd_attachment_url($id, $action = 'download', $ttl = null)
{
    $exp = time() + ($ttl === null ? FD_ATTACH_URL_TTL : (int)$ttl);
    return 'fd_attachments.php?action=' . ($action === 'view' ? 'view' : 'download')
         . '&id=' . (int)$id . '&exp=' . $exp . '&sig=' . fd_attachment_sig($id, $exp);
}

/**
 * Put back images that were parked as "remote" but are in fact ours.
 *
 * Inline pictures ingested before cid: was exempted from image blocking are
 * stored with src="" and their real URL in data-fd-src. That URL points at our
 * own attachment endpoint, so there is nothing to protect the agent from --
 * the image is part of the email they are already reading. Rather than
 * rewriting every stored row, the markup is repaired as the body is read.
 */
function fd_unblock_own_images($html)
{
    if ($html === null || $html === '') return '';
    return preg_replace_callback('#<img\b([^>]*)>#i', function ($m) {
        $attrs = $m[1];
        // An empty data-fd-src is the residue of double-parking: it names no
        // image, so it cannot be "shown", and leaving it makes the panel count
        // a blocked image that does not exist.
        $attrs = preg_replace('#\sdata-fd-src\s*=\s*(["\'])\s*\1#i', '', $attrs);
        if (strpos($attrs, 'data-fd-blocked') === false) return $m[0];
        if (!preg_match('#\sdata-fd-src\s*=\s*(["\'])(.*?)\1#is', $attrs, $sm)) return $m[0];
        $url = trim($sm[2]);
        $ours = (stripos($url, 'data:image/') === 0) || (strpos($url, 'fd_attachments.php') !== false);
        if (!$ours) return $m[0];

        $attrs = str_replace($sm[0], '', $attrs);              // drop data-fd-src
        $attrs = preg_replace('#\ssrc\s*=\s*("[^"]*"|\'[^\']*\'|[^\s>]*)#i', '', $attrs);
        $attrs = preg_replace('#\sdata-fd-blocked\s*=\s*("[^"]*"|\'[^\']*\'|[^\s>]*)#i', '', $attrs);
        return '<img src="' . htmlspecialchars($url, ENT_QUOTES, 'UTF-8') . '"' . $attrs . '>';
    }, (string)$html);
}

/**
 * The admin_users row behind an email address, or null.
 *
 * Only ACTIVE admins: a notification for someone whose access was revoked is
 * an inbox nobody reads, and forwarding to an ex-colleague's address should
 * not resurrect them in the panel.
 */
function fd_admin_by_email($email)
{
    $email = trim((string)$email);
    if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) return null;
    try {
        return fd_query_one(
            "SELECT u.user_id, u.name, u.email
             FROM admin_users a
             INNER JOIN users u ON u.user_id = a.user_id
             WHERE a.is_active = 1 AND u.email = ? LIMIT 1",
            's', array($email));
    } catch (Throwable $e) {
        fd_log('debug', 'Admin lookup skipped: ' . $e->getMessage());
        return null;
    }
}

/**
 * Write one notification.
 *
 * Never throws: a notification is a courtesy, and failing to record one must
 * not fail the assignment or the forward that prompted it. Returns whether a
 * row was written, which the callers use only for their own logs.
 *
 * @param int|null $userId  who it is for; nothing happens without one
 * @param array    $actor   ['id' => int|null, 'name' => string] who caused it
 */
function fd_notify_user($userId, $kind, $ticketId, $title, $body = '', $actor = array())
{
    $userId = (int)$userId;
    if ($userId <= 0) return false;

    // Telling someone what they just did themselves is noise.
    $actorId = isset($actor['id']) ? (int)$actor['id'] : 0;
    if ($actorId > 0 && $actorId === $userId) return false;

    try {
        fd_exec("INSERT INTO fd_notifications
                    (user_id, kind, ticket_id, title, body, actor_id, actor_name)
                 VALUES (?,?,?,?,?,?,?)",
                'issssis', array(
                    $userId,
                    (string)$kind,
                    $ticketId ? (int)$ticketId : null,
                    mb_substr((string)$title, 0, 255),
                    mb_substr((string)$body, 0, 500),
                    $actorId > 0 ? $actorId : null,
                    isset($actor['name']) ? (string)$actor['name'] : null,
                ));
        return true;
    } catch (Throwable $e) {
        fd_log('warn', 'Notification not recorded: ' . $e->getMessage(),
               array('for' => $userId, 'kind' => $kind, 'ticket' => $ticketId));
        return false;
    }
}

/**
 * Notify whichever of these addresses belong to agents.
 *
 * Forwarding to finance@ and to a colleague are the same action from the
 * agent's side; only the second has anyone here to tell. Returns the names
 * that were notified, for the caller's own message.
 */
function fd_notify_emails($emails, $kind, $ticketId, $title, $body = '', $actor = array())
{
    $told = array();
    $seen = array();
    foreach ((array)$emails as $addr) {
        $admin = fd_admin_by_email($addr);
        if (!$admin) continue;
        $uid = (int)$admin['user_id'];
        if (isset($seen[$uid])) continue;        // the same person on To and Cc
        $seen[$uid] = true;
        if (fd_notify_user($uid, $kind, $ticketId, $title, $body, $actor)) {
            $told[] = $admin['name'];
        }
    }
    return $told;
}

/**
 * Sign every attachment URL already embedded in a stored message body.
 *
 * Inline cid: images were rewritten to an UNSIGNED fd_attachments.php URL at
 * ingest time, on purpose -- a signature baked into the database would expire
 * and the image would break a few hours later, permanently. The signature is
 * added here instead, freshly, every time the body is read.
 */
function fd_sign_html_attachments($html)
{
    if ($html === null || $html === '') return '';
    $html = fd_unblock_own_images($html);
    return preg_replace_callback(
        '#fd_attachments\.php\?action=(view|download)&(?:amp;)?id=(\d+)(?![\d&])#i',
        function ($m) { return fd_attachment_url((int)$m[2], $m[1]); },
        (string)$html
    );
}

/**
 * mysqli helper: run a prepared statement and return the result rows.
 * Every query in this feature goes through prepared statements -- ticket
 * subjects and sender names are attacker-controlled and end up in WHERE
 * clauses via search.
 */
function fd_query($sql, $types = '', $params = array()) {
    global $conn;
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        fd_log('error', 'Prepare failed: ' . $conn->error, array('sql' => substr($sql, 0, 300)));
        throw new Exception('Database query failed');
    }
    if ($types !== '' && !empty($params)) {
        $bind = array();
        $bind[] = $types;
        foreach ($params as $i => $v) $bind[] = &$params[$i];
        call_user_func_array(array($stmt, 'bind_param'), $bind);
    }
    if (!$stmt->execute()) {
        $err = $stmt->error;
        $stmt->close();
        fd_log('error', 'Execute failed: ' . $err, array('sql' => substr($sql, 0, 300)));
        throw new Exception('Database query failed');
    }
    $res = $stmt->get_result();
    $rows = array();
    if ($res) { while ($r = $res->fetch_assoc()) $rows[] = $r; }
    $stmt->close();
    return $rows;
}

/** Same as fd_query() but returns only the first row (or null). */
function fd_query_one($sql, $types = '', $params = array()) {
    $rows = fd_query($sql, $types, $params);
    return empty($rows) ? null : $rows[0];
}

/** Prepared INSERT/UPDATE/DELETE. Returns affected rows (or insert id when asked). */
function fd_exec($sql, $types = '', $params = array(), $wantInsertId = false) {
    global $conn;
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        fd_log('error', 'Prepare failed: ' . $conn->error, array('sql' => substr($sql, 0, 300)));
        throw new Exception('Database write failed');
    }
    if ($types !== '' && !empty($params)) {
        $bind = array();
        $bind[] = $types;
        foreach ($params as $i => $v) $bind[] = &$params[$i];
        call_user_func_array(array($stmt, 'bind_param'), $bind);
    }
    if (!$stmt->execute()) {
        $err = $stmt->error;
        $stmt->close();
        fd_log('error', 'Execute failed: ' . $err, array('sql' => substr($sql, 0, 300)));
        throw new Exception('Database write failed: ' . $err);
    }
    $out = $wantInsertId ? $stmt->insert_id : $stmt->affected_rows;
    $stmt->close();
    return $out;
}

/* ==========================================================================
   QUOTED HISTORY — splitting it out, and calming the typography around it
   ========================================================================== */

/**
 * Split an HTML body into what the person actually wrote and the quoted
 * history underneath it.
 *
 * WHY THIS EXISTS
 * fd_strip_quoted_text() has always done this for the plain-text copy, but the
 * conversation view renders body_html whenever it exists — and that was the
 * FULL html, quoted chain and all. Every reply therefore redisplayed the whole
 * thread, and because our own outgoing replies embed the previous messages,
 * each round trip multiplied the stored body. A seven-message ticket that
 * Freshdesk draws in one screen was rendering tens of thousands of pixels tall.
 *
 * The markers below are the ones real clients emit. They are listed in order of
 * confidence — an explicit class or id first, a prose separator last — and the
 * EARLIEST match wins, because a reply can carry several generations of quoting
 * and the topmost one is where the new text ends.
 *
 * Conservative on purpose: if the split would leave nothing visible, or the
 * quoted part is too small to be worth hiding, the body comes back whole. A
 * missed quote block is untidy; eating the customer's message is not.
 *
 * @return array ['visible' => string, 'quoted' => string]
 */
function fd_split_quoted_html($html)
{
    $s = (string)$html;
    if ($s === '') return array('visible' => '', 'quoted' => '');

    $markers = array(
        // Our own outgoing replies mark their history explicitly — no guessing.
        '#<div[^>]*class\s*=\s*["\'][^"\']*\bfd-quoted-history\b#i',
        // Gmail, web and mobile.
        '#<(?:div|blockquote)[^>]*class\s*=\s*["\'][^"\']*\bgmail_quote#i',
        '#<div[^>]*class\s*=\s*["\'][^"\']*\bgmail_extra\b#i',
        // Apple Mail and most standards-compliant clients.
        '#<blockquote[^>]*type\s*=\s*["\']?cite#i',
        // Outlook desktop and OWA.
        '#<div[^>]*id\s*=\s*["\']?(?:divRplyFwdMsg|appendonsend|OLK_SRC_BODY_SECTION|mail-editor-reference-message-container)#i',
        '#<hr[^>]*id\s*=\s*["\']?stopSpelling#i',
        // Yahoo and Zimbra.
        '#<div[^>]*class\s*=\s*["\'][^"\']*\b(?:yahoo_quoted|ZmBrowserRow)#i',
        // Plain separators that survive the trip into HTML.
        '#-{2,}\s*Original\s+Message\s*-{2,}#i',
        '#-{2,}\s*Forwarded\s+message\s*-{2,}#i',
        // "On <date>, <someone> wrote:" — last, and never allowed across a tag.
        '#On\s[^<>]{5,180}?\bwrote\s*:#i',
    );

    $cut = null;
    foreach ($markers as $re) {
        if (preg_match($re, $s, $m, PREG_OFFSET_CAPTURE)) {
            $at = $m[0][1];
            if ($at > 0 && ($cut === null || $at < $cut)) $cut = $at;
        }
    }
    if ($cut === null) return array('visible' => $s, 'quoted' => '');

    /*
     * Move the split to an element boundary. A prose marker sits INSIDE a tag
     * ("<p>On Tue, … wrote:</p>"), and cutting at the word itself would leave
     * the opening <p> stranded in the visible half.
     */
    $lt = strrpos(substr($s, 0, $cut), '<');
    if ($lt !== false) {
        $tail = substr($s, $lt, $cut - $lt);
        $gt = strrpos($tail, '>');
        if ($gt === false) {
            $cut = $lt;                                     // landed mid-tag
        } elseif (trim(substr($tail, $gt + 1)) === '') {
            $cut = $lt;                                     // that tag opens the quote
        }
    }

    $visible = substr($s, 0, $cut);
    $quoted  = substr($s, $cut);

    // Both halves have to be worth the split.
    if (trim(fd_html_to_text($visible)) === '') return array('visible' => $s, 'quoted' => '');
    if (strlen(trim(fd_html_to_text($quoted))) < 40) return array('visible' => $s, 'quoted' => '');

    return array('visible' => $visible, 'quoted' => $quoted);
}

/**
 * Calm down the typography a mail client baked into a body.
 *
 * Every client hard-codes its own font stack, pixel size and text colour, so a
 * thread of five replies arrived in five different faces at five different
 * sizes. Worse, a hard-coded #1f1f1f is invisible against this panel's dark
 * theme — the message is there and simply cannot be read.
 *
 * Structure, emphasis, links, lists, tables and images are all kept. Only the
 * presentation the sender's client chose is dropped, and only for DISPLAY: the
 * original stays untouched in fd_messages.body_html, so nothing is lost and the
 * decision can be reversed by not calling this.
 */
/**
 * Take our own campaign tracking out of a mail body.
 *
 * The campaign mailer rewrites every link to
 * campaigns/track-click.php?rid=<recipient>&u=<destination> and adds an open
 * pixel (track-open.php?rid=...). A student replying quotes all of it back, so
 * an agent clicking the logo in a ticket -- or whoever receives a forward --
 * was counted as THAT student clicking or opening, inflating the campaign's
 * numbers and its attribution. Links go straight to their destination; the
 * pixel is removed. Only our own domains are touched.
 */
function fd_untrack_own_links($html)
{
    $s = (string)$html;
    if ($s === '' || stripos($s, '/campaigns/track-') === false) return $s;

    $s = preg_replace_callback(
        '#(\shref\s*=\s*)(["\'])(https?://(?:[a-z0-9-]+\.)*internshipstudio\.com/[^"\']*/campaigns/track-click\.php\?[^"\']*)\2#i',
        function ($m) {
            parse_str((string)parse_url(html_entity_decode($m[3], ENT_QUOTES, 'UTF-8'), PHP_URL_QUERY), $p);
            $dest = isset($p['u']) ? (string)$p['u'] : '';
            if (!preg_match('#^https?://#i', $dest)) return $m[1] . $m[2] . '#' . $m[2];
            return $m[1] . $m[2] . htmlspecialchars($dest, ENT_QUOTES, 'UTF-8') . $m[2];
        },
        $s
    );
    // The open pixel, whether still live (src) or already parked (data-fd-src).
    $s = preg_replace('#<img\b[^>]*internshipstudio\.com/[^"\'>]*/campaigns/track-open\.php[^>]*>#i', '', $s);
    return $s;
}

function fd_tidy_email_html($html)
{
    $s = (string)$html;
    if ($s === '') return '';
    $s = fd_untrack_own_links($s);

    /*
     * First, before anything else looks at this markup. Scripts, frames and
     * event handlers go; remote images are parked. Our own attachment URLs are
     * put back by fd_unblock_own_images() in fd_sign_html_attachments(), which
     * every caller runs immediately after this.
     */
    $s = fd_sanitize_html($s, true);

    /*
     * Clients write a blank line as an empty element, so ONE of these is the
     * author's paragraph break and must survive. It is the run of four or five
     * -- what a few taps of Enter leaves behind -- that turns a short reply
     * into a screenful of nothing.
     */
    // <p><br></p>, not <p></p>: an empty paragraph renders at zero height, so
    // collapsing to it deleted the one blank line this is meant to keep.
    $s = preg_replace('#(?:<p\b[^>]*>(?:\s|&nbsp;|<br\s*/?>)*</p>\s*){2,}#i', '<p><br></p>', $s);
    $s = preg_replace('#(?:<div\b[^>]*>(?:\s|&nbsp;|<br\s*/?>)*</div>\s*){2,}#i', '<div><br></div>', $s);
    $s = preg_replace('#(?:<br\s*/?>\s*){3,}#i', '<br><br>', $s);
    // Leading and trailing breaks are pure padding -- the card already has it.
    $s = preg_replace('#^(?:\s|&nbsp;|<br\s*/?>)+#i', '', $s);
    $s = preg_replace('#(?:\s|&nbsp;|<br\s*/?>)+$#i', '', $s);

    // Drop the sender's typography from inline styles, keep everything else.
    $drop = array('font-family', 'font-size', 'color', 'background', 'background-color',
                  'line-height', 'width', 'max-width', 'min-width');
    $s = preg_replace_callback('#\sstyle\s*=\s*(["\'])(.*?)\1#is', function ($m) use ($drop) {
        $keep = array();
        foreach (explode(';', $m[2]) as $decl) {
            $decl = trim($decl);
            if ($decl === '') continue;
            $colon = strpos($decl, ':');
            if ($colon === false) continue;
            $prop = strtolower(trim(substr($decl, 0, $colon)));
            if (in_array($prop, $drop, true)) continue;
            $keep[] = $decl;
        }
        return empty($keep) ? '' : ' style="' . htmlspecialchars(implode('; ', $keep), ENT_QUOTES, 'UTF-8') . '"';
    }, $s);

    // <font> and the legacy presentation attributes say the same thing.
    $s = preg_replace('#<\s*/?\s*font\b[^>]*>#i', '', $s);
    $s = preg_replace('#\s(?:face|color|bgcolor)\s*=\s*(["\'])[^"\']*\1#i', '', $s);
    $s = preg_replace('#\s(?:face|color|bgcolor)\s*=\s*[^\s>]+#i', '', $s);

    // Last, so it sees the final markup and nothing above can undo it.
    $s = fd_linkify_html($s);

    return trim($s);
}

/**
 * Turn bare URLs in an HTML body into real links.
 *
 * Mail arrives as often as not in plain text, which MimeParser wraps in a
 * pre-wrap div -- so "http://127.0.0.1:8000/view-quotation/2/1" rendered as
 * grey text you had to select and copy. Every other mail client links those,
 * and so should this.
 *
 * Walks the markup tag by tag and only ever rewrites the TEXT between tags, so
 * it cannot touch an href, a src, a style attribute, or anything else that
 * merely looks like a URL. Text already inside an <a> is skipped too --
 * relinking a link produces nested anchors, which browsers "fix" by dropping
 * one of them at random.
 */
function fd_linkify_html($html)
{
    $s = (string)$html;
    if ($s === '') return '';
    // Cheap bail-out: most bodies have neither.
    if (stripos($s, 'http') === false && stripos($s, 'www.') === false) return $s;

    $out = '';
    $offset = 0;
    $insideAnchor = 0;

    while (preg_match('#<[^>]*>#', $s, $m, PREG_OFFSET_CAPTURE, $offset)) {
        $tag = $m[0][0];
        $at  = $m[0][1];

        $text = substr($s, $offset, $at - $offset);
        $out .= $insideAnchor > 0 ? $text : fd_linkify_text($text);

        if (preg_match('#^<a\b#i', $tag))        $insideAnchor++;
        elseif (preg_match('#^</\s*a\s*>#i', $tag)) $insideAnchor = max(0, $insideAnchor - 1);

        $out .= $tag;
        $offset = $at + strlen($tag);
    }

    $tail = substr($s, $offset);
    $out .= $insideAnchor > 0 ? $tail : fd_linkify_text($tail);

    return $out;
}

/**
 * The text-node half of fd_linkify_html(). Never call this on markup.
 *
 * The fragment is already HTML-escaped -- MimeParser and fd_compose_html both
 * run htmlspecialchars() before this sees it -- so the matched string is safe
 * to put straight into the href. Escaping it again would turn a legitimate
 * "&amp;" in a query string into "&amp;amp;". Quotes and angle brackets cannot
 * appear in a match because the pattern excludes them, so there is no way to
 * break out of the attribute.
 */
function fd_linkify_text($text)
{
    if ($text === '' || (stripos($text, 'http') === false && stripos($text, 'www.') === false)) {
        return $text;
    }
    return preg_replace_callback(
        // Stop before trailing punctuation: a URL at the end of a sentence
        // should not swallow the full stop.
        '#\b((?:https?://|www\.)[^\s<>"\'`]+[^\s<>"\'`.,;:!?)\]}])#i',
        function ($m) {
            $url  = $m[1];
            $href = (stripos($url, 'http') === 0) ? $url : 'http://' . $url;
            return '<a href="' . $href . '" target="_blank" rel="noopener noreferrer nofollow">' . $url . '</a>';
        },
        $text
    );
}

/**
 * Turn an agent's composer input into safe HTML.
 *
 * The composer sends either plain text (textarea) or light HTML (rich editor).
 * Even though this comes from a logged-in agent rather than the internet, it is
 * still passed through the sanitiser: an agent pasting a formatted block copied
 * out of a customer's email would otherwise carry that customer's markup --
 * scripts included -- straight back out through our own mail server, over our
 * own domain's reputation.
 */
function fd_compose_html($body, $isHtml = null)
{
    $body = (string)$body;
    if ($body === '') return '';
    $looksHtml = $isHtml === null ? (bool)preg_match('/<(p|div|br|ul|ol|li|strong|em|b|i|a|table|span|h[1-6])\b/i', $body) : (bool)$isHtml;
    if (!$looksHtml) {
        /*
         * Collapse runs of blank lines before nl2br().
         *
         * nl2br() turns EVERY newline into a <br>, so "a\n\n\n\nb" arrives in the
         * customer's inbox as four empty lines. Two newlines is a paragraph
         * break; anything beyond that is an accident of how the text was
         * assembled or pasted. Trailing whitespace goes too, or a signature
         * ends with a stack of empty rows.
         */
        $body = str_replace(array("\r\n", "\r"), "\n", $body);
        $body = preg_replace("/[ \t]+\n/", "\n", $body);   // trailing spaces per line
        $body = preg_replace("/\n{3,}/", "\n\n", $body);     // 3+ blank lines -> one
        $body = trim($body, "\n");

        return '<div style="white-space:pre-wrap;font-family:Arial,Helvetica,sans-serif;font-size:14px;line-height:1.6">'
             . nl2br(htmlspecialchars($body, ENT_QUOTES, 'UTF-8')) . '</div>';
    }
    return fd_sanitize_html($body, false);
}

/** Substitute the placeholders canned responses and templates use. */
function fd_apply_merge_tags($body, $ticket, $me)
{
    $first = trim(explode(' ', (string)$ticket['requester_name'])[0]);
    $map = array(
        '{Customer Name}' => $ticket['requester_name'],
        '{customer_name}' => $ticket['requester_name'],
        '{First Name}'    => $first !== '' ? $first : $ticket['requester_name'],
        '{Ticket ID}'     => '#' . $ticket['id'],
        '{ticket_id}'     => '#' . $ticket['id'],
        '{Ticket Subject}' => $ticket['subject'],
        '{Agent Name}'    => $me['name'],
        '{agent_name}'    => $me['name'],
        '{Status}'        => $ticket['status'],
        '{Priority}'      => $ticket['priority'],
    );
    return str_replace(array_keys($map), array_values($map), (string)$body);
}

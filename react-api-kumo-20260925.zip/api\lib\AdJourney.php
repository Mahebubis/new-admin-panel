<?php
/**
 * Ad journey: which ads a student came through, read from the tables the dashboard writes
 * (user_dashboard/docs/ad-journey-context-for-adp.md). Used by api/students/ad_visits.php and
 * api/netcore/user_timeline.php.
 *
 * A visit belongs to a student in one of two ways:
 *   device — ad_visits.user_id is set: the same browser (ad_vid cookie) later registered or
 *            logged in. Reliable.
 *   ip     — an anonymous visit from a network the student was seen on, close to when they were
 *            seen there. A hint only:
 *              IPv4 is NATed: everyone on one Wi-Fi, hostel or mobile carrier NAT shares a single
 *              public address, so an exact IPv4 match can be any of 15 classmates.
 *              IPv6 is not NATed: each device gets its own address, but the last half rotates
 *              (privacy extensions), so IPv6 is matched on the /64 network — one home router, or
 *              one phone on mobile data — never on the full address.
 *            The time window stops a college IP from pulling in every stranger who ever clicked
 *            an ad there.
 *
 * The private address a device has on the Wi-Fi (192.168.x.x) never reaches the server, so there
 * is no "personal IP" to tell those 15 students apart: only the browser id can.
 */

const AD_IP_WINDOW_BEFORE = 7 * 86400; // visit up to 7 days before the student was seen on that network
const AD_IP_WINDOW_AFTER  = 1 * 86400; // ...or up to 1 day after
const AD_REGISTER_CONTEXTS = ['normal_register', 'google_register', 'apple_register', 'mobile_register', 'referral_register'];
const AD_CANDIDATE_CAP = 5000;
/* Clicks on our own email/WhatsApp/Netcore messages, stored before the dashboard started skipping
   them (track_ad_visit.php). Not ads, so never counted. */
const AD_NOT_OWN_SQL = "COALESCE(source,'') NOT IN ('email','netcore')
    AND COALESCE(medium,'') NOT IN ('email','netcore')
    AND COALESCE(utm_medium,'') NOT IN ('email','netcore')
    AND COALESCE(landing_url,'') NOT LIKE '%attr\\_window=%'";

/** 4, 6, or 0 if not an IP. IPv4-mapped IPv6 (::ffff:1.2.3.4) counts as 4. */
function ad_ip_version(string $ip): int {
    $bin = @inet_pton(trim($ip));
    if ($bin === false) return 0;
    if (strlen($bin) === 4 || substr($bin, 0, 12) === str_repeat("\0", 10) . "\xff\xff") return 4;
    return 6;
}

/** What two IPs must share to count as one network: the whole IPv4, or the IPv6 /64. */
function ad_ip_key(string $ip): string {
    $bin = @inet_pton(trim($ip));
    if ($bin === false) return '';
    if (strlen($bin) === 4) return inet_ntop($bin);
    if (substr($bin, 0, 12) === str_repeat("\0", 10) . "\xff\xff") return inet_ntop(substr($bin, 12));
    return implode(':', array_map(fn($g) => ltrim($g, '0') ?: '0', str_split(bin2hex(substr($bin, 0, 8)), 4))) . '::/64';
}

/** SQL condition that finds (a superset of) the stored addresses on this IP's network. */
function ad_ip_sql(mysqli $conn, string $ip): string {
    $bin = @inet_pton(trim($ip));
    if ($bin === false) return '';
    if (ad_ip_version($ip) === 4) {
        return "ip_address = '" . $conn->real_escape_string(ad_ip_key($ip)) . "'";
    }
    // Stored text is the compressed form (2401:4900:1c5a:3a2b:...). If a zero group sits in the
    // prefix it may be written as '::', so fall back to the first group; PHP re-checks the /64.
    $groups = array_map(fn($g) => ltrim($g, '0') ?: '0', str_split(bin2hex(substr($bin, 0, 8)), 4));
    $prefix = in_array('0', $groups, true) ? $groups[0] . ':' : implode(':', $groups) . ':';
    return "ip_address LIKE '" . $conn->real_escape_string($prefix) . "%'";
}

function ad_journey_available(mysqli $conn): bool {
    static $ok = null;
    if ($ok === null) {
        try {
            $r = $conn->query("SHOW TABLES LIKE 'ad_visits'");
            $ok = $r && $r->num_rows > 0;
        } catch (Throwable $e) {
            $ok = false;
        }
    }
    return $ok;
}

/**
 * ad_visits and user_ip_log are stamped by MySQL's clock, which is not PHP's (Asia/Kolkata) on
 * this host. Seconds to add to a MySQL-stamped time to put it on PHP's clock, to the nearest 15 min.
 */
function ad_mysql_skew(mysqli $conn): int {
    static $skew = null;
    if ($skew === null) {
        $skew = 0;
        try {
            $r = $conn->query("SELECT NOW() AS n");
            if ($r && ($row = $r->fetch_assoc())) {
                $skew = (int) (round((time() - strtotime($row['n'])) / 900) * 900);
            }
        } catch (Throwable $e) {
        }
    }
    return $skew;
}

/** "Campaign › Adset › Ad", else the UTM equivalents, else what kind of click id it had. */
function ad_label(array $v): string {
    $parts = array_filter([$v['campaign'] ?: $v['utm_campaign'], $v['adset'] ?: $v['utm_term'], $v['ad'] ?: $v['utm_content']]);
    if ($parts) return implode(' › ', $parts);
    if (!empty($v['fbclid'])) return 'Facebook ad (fbclid only)';
    if (!empty($v['gclid'])) return 'Google ad (gclid only)';
    return 'Unknown ad';
}

/**
 * Every ad visit matched to each of $userIds, oldest first.
 * @return array<int, array{registered_at:?string, ips:array, visits:array}>
 */
function ad_journey_collect(mysqli $conn, array $userIds): array {
    $ids = array_values(array_unique(array_filter(array_map('intval', $userIds), fn($i) => $i > 0)));
    $out = [];
    foreach ($ids as $id) $out[$id] = ['registered_at' => null, 'ips' => [], 'visits' => []];
    if (!$ids || !ad_journey_available($conn)) return $out;

    $skew = ad_mysql_skew($conn);
    $fix = fn($ts) => $ts ? date('Y-m-d H:i:s', strtotime($ts) + $skew) : null;
    $in = implode(',', $ids);

    // Where each student has been seen: every register/login logs the IP.
    $seen = []; // network key => [[user_id, unix time], ...]
    $netSql = [];
    try {
        $r = $conn->query("SELECT user_id, ip_address, context, created_at FROM user_ip_log
                            WHERE user_id IN ($in) AND ip_address IS NOT NULL AND ip_address <> ''
                            ORDER BY created_at");
        while ($r && ($row = $r->fetch_assoc())) {
            $key = ad_ip_key($row['ip_address']);
            if ($key === '') continue;
            $uid = (int) $row['user_id'];
            $at = $fix($row['created_at']);
            $seen[$key][] = [$uid, strtotime($at)];
            $netSql[$key] = ad_ip_sql($conn, $row['ip_address']);
            $out[$uid]['ips'][] = ['ip_address' => $row['ip_address'], 'context' => $row['context'], 'seen_at' => $at];
            if (in_array($row['context'], AD_REGISTER_CONTEXTS, true) && !$out[$uid]['registered_at']) {
                $out[$uid]['registered_at'] = $at;
            }
        }
    } catch (Throwable $e) {
        error_log('[AdJourney] user_ip_log unavailable: ' . $e->getMessage());
    }

    // Accounts older than the IP log: fall back to users.registered_at (already on PHP's clock).
    $missing = array_keys(array_filter($out, fn($u) => !$u['registered_at']));
    if ($missing) {
        $r = $conn->query("SELECT user_id, registered_at FROM users WHERE user_id IN (" . implode(',', $missing) . ")");
        while ($r && ($row = $r->fetch_assoc())) {
            $out[(int) $row['user_id']]['registered_at'] = $row['registered_at'] ?: null;
        }
    }

    $shape = function (array $v, string $match) use ($fix) {
        return [
            'id'          => (int) $v['id'],
            'visited_at'  => $fix($v['created_at']),
            'match_type'  => $match,
            'ip_address'  => $v['ip_address'],
            'ip_version'  => ad_ip_version((string) $v['ip_address']),
            'network'     => ad_ip_key((string) $v['ip_address']),
            'source'      => $v['source'],
            'ad_label'    => ad_label($v),
            'campaign'    => $v['campaign'],
            'adset'       => $v['adset'],
            'ad'          => $v['ad'],
            'medium'      => $v['medium'],
            'utm_source'  => $v['utm_source'],
            'utm_medium'  => $v['utm_medium'],
            'utm_campaign'=> $v['utm_campaign'],
            'utm_content' => $v['utm_content'],
            'utm_term'    => $v['utm_term'],
            'campaign_id' => $v['campaign_id'],
            'has_fbclid'  => !empty($v['fbclid']),
            'has_gclid'   => !empty($v['gclid']),
            'device'      => $v['device'],
            'landing_url' => $v['landing_url'],
            'referrer'    => $v['referrer'],
            'visitor_id'  => $v['visitor_id'],
        ];
    };

    try {
        $r = $conn->query("SELECT * FROM ad_visits WHERE user_id IN ($in) AND " . AD_NOT_OWN_SQL);
        while ($r && ($v = $r->fetch_assoc())) {
            $out[(int) $v['user_id']]['visits'][] = $shape($v, 'device');
        }

        if ($netSql) {
            $r = $conn->query("SELECT * FROM ad_visits WHERE user_id IS NULL AND ("
                . implode(' OR ', array_unique($netSql)) . ") AND " . AD_NOT_OWN_SQL
                . " ORDER BY id DESC LIMIT " . AD_CANDIDATE_CAP);
            while ($r && ($v = $r->fetch_assoc())) {
                $key = ad_ip_key((string) $v['ip_address']);
                if (!isset($seen[$key])) continue;
                $t = strtotime($fix($v['created_at']));
                $matched = [];
                foreach ($seen[$key] as [$uid, $at]) {
                    if (!isset($matched[$uid]) && $t >= $at - AD_IP_WINDOW_BEFORE && $t <= $at + AD_IP_WINDOW_AFTER) {
                        $matched[$uid] = true;
                        $out[$uid]['visits'][] = $shape($v, 'ip');
                    }
                }
            }
        }
    } catch (Throwable $e) {
        error_log('[AdJourney] ad_visits query failed: ' . $e->getMessage());
    }

    foreach ($out as &$u) {
        usort($u['visits'], fn($a, $b) => strcmp($a['visited_at'], $b['visited_at']));
        foreach ($u['visits'] as &$v) {
            $v['before_register'] = $u['registered_at'] ? $v['visited_at'] <= $u['registered_at'] : null;
        }
        unset($v);
    }
    unset($u);
    return $out;
}

/** Per-student totals for a page of the students list. */
function ad_journey_counts(mysqli $conn, array $userIds): array {
    $counts = [];
    foreach (ad_journey_collect($conn, $userIds) as $uid => $u) {
        $device = count(array_filter($u['visits'], fn($v) => $v['match_type'] === 'device'));
        $counts[$uid] = [
            'total'           => count($u['visits']),
            'device'          => $device,
            'ip'              => count($u['visits']) - $device,
            'before_register' => count(array_filter($u['visits'], fn($v) => $v['before_register'] === true)),
        ];
    }
    return $counts;
}

/**
 * How many OTHER students have been seen on this network. Uses user_ip_log.idx_ip; still capped
 * at 2.5s (a busy college IP can have thousands of rows) and returns null when it runs out.
 */
function ad_network_shared(mysqli $conn, string $ip, int $userId): ?int {
    $cond = ad_ip_sql($conn, $ip);
    if ($cond === '') return null;
    try {
        $r = $conn->query("SELECT /*+ MAX_EXECUTION_TIME(2500) */ DISTINCT user_id, ip_address
                             FROM user_ip_log WHERE $cond AND user_id <> $userId LIMIT 500");
        $key = ad_ip_key($ip);
        $users = [];
        while ($r && ($row = $r->fetch_assoc())) {
            if (ad_ip_key($row['ip_address']) === $key) $users[(int) $row['user_id']] = true;
        }
        return count($users);
    } catch (Throwable $e) {
        return null;
    }
}

/**
 * How far to trust one visit.
 *   high   — same browser, or an IPv6 network nobody else has used
 *   medium — IPv6 network shared with others (a family), or an IPv4 nobody else has used
 *   low    — an IPv4 other students have used too (Wi-Fi, hostel, carrier NAT)
 */
function ad_confidence(array $v, ?int $shared): string {
    if ($v['match_type'] === 'device') return 'high';
    if ($v['ip_version'] === 6) return $shared === 0 ? 'high' : 'medium';
    return $shared === 0 ? 'medium' : 'low';
}

/** Everything the drawer shows for one student. */
function ad_journey_detail(mysqli $conn, int $userId): ?array {
    $r = $conn->query("SELECT user_id, name, email, phone, registered_at FROM users WHERE user_id = $userId LIMIT 1");
    $user = $r ? $r->fetch_assoc() : null;
    if (!$user) return null;

    $j = ad_journey_collect($conn, [$userId])[$userId];
    $user['registered_at'] = $j['registered_at'] ?: $user['registered_at'];

    // One row per network the student has been seen on.
    $networks = [];
    foreach ($j['ips'] as $ip) {
        $key = ad_ip_key($ip['ip_address']);
        if (!isset($networks[$key])) {
            $networks[$key] = [
                'network'    => $key,
                'ip_version' => ad_ip_version($ip['ip_address']),
                'addresses'  => [],
                'contexts'   => [],
                'first_seen' => $ip['seen_at'],
                'last_seen'  => $ip['seen_at'],
                'shared_with_users' => ad_network_shared($conn, $ip['ip_address'], $userId),
            ];
        }
        $n = &$networks[$key];
        $n['addresses'][$ip['ip_address']] = true;
        $n['contexts'][$ip['context']] = true;
        $n['last_seen'] = $ip['seen_at'];
        unset($n);
    }
    foreach ($networks as &$n) {
        $n['addresses'] = array_keys($n['addresses']);
        $n['contexts'] = array_keys($n['contexts']);
    }
    unset($n);

    foreach ($j['visits'] as &$v) {
        $shared = $networks[$v['network']]['shared_with_users'] ?? null;
        $v['shared_with_users'] = $v['match_type'] === 'ip' ? $shared : null;
        $v['confidence'] = ad_confidence($v, $shared);
    }
    unset($v);

    $visits = $j['visits'];
    $before = array_values(array_filter($visits, fn($v) => $v['before_register'] === true));
    $distinct = [];
    $sources = [];
    foreach ($visits as $v) {
        $distinct[$v['source'] . '|' . $v['ad_label']] = true;
        $s = $v['source'] ?: 'unknown';
        $sources[$s] = ($sources[$s] ?? 0) + 1;
    }
    arsort($sources);

    return [
        'user'     => $user,
        'networks' => array_values($networks),
        'stats'    => [
            'total'           => count($visits),
            'device'          => count(array_filter($visits, fn($v) => $v['match_type'] === 'device')),
            'ip'              => count(array_filter($visits, fn($v) => $v['match_type'] === 'ip')),
            'before_register' => count($before),
            'distinct_ads'    => count($distinct),
            'first_touch'     => $visits[0]['ad_label'] ?? null,
            'last_touch'      => $before ? end($before)['ad_label'] : null,
            'sources'         => $sources,
        ],
        'visits'   => $visits,
    ];
}

/**
 * Students registered in [from, to] whose matched ad visits pass the filters, for the All Students
 * filter view.
 *
 * Starts from the small side: ad_visits is tiny next to users, so only students who could have a
 * visit are ever run through ad_journey_collect() —
 *   same browser: ad_visits.user_id among students registered in range;
 *   same network: students in range whose logged IP is on a network an anonymous visit came from
 *                 since (from − 7 days), the earliest a visit can still match them.
 *
 * $o: from, to (Y-m-d), min (visits), source ('' = any), match ('any'|'device'),
 *     timing ('any'|'before'|'after'), sort ('visits'|'recent'|'first_visit').
 */
function ad_journey_filter(mysqli $conn, array $o): array {
    $empty = ['students' => [], 'summary' => ['students' => 0, 'visits' => 0, 'before_register' => 0,
              'device' => 0, 'sources' => []], 'available_sources' => []];
    if (!ad_journey_available($conn)) return $empty;

    $fromTs = $o['from'] . ' 00:00:00';
    $toTs   = $o['to'] . ' 23:59:59';
    $range  = "u.role = 4 AND u.registered_at BETWEEN '$fromTs' AND '$toTs'";
    $cand = [];

    $r = $conn->query("SELECT DISTINCT v.user_id
                         FROM (SELECT user_id FROM ad_visits WHERE user_id IS NOT NULL AND " . AD_NOT_OWN_SQL . ") v
                         JOIN users u ON u.user_id = v.user_id
                        WHERE $range");
    while ($r && ($row = $r->fetch_assoc())) $cand[(int) $row['user_id']] = true;

    // ad_visits.created_at is on MySQL's clock; PHP time = MySQL time + skew.
    $since = date('Y-m-d H:i:s', strtotime($fromTs) - AD_IP_WINDOW_BEFORE - ad_mysql_skew($conn));
    $nets = [];
    $r = $conn->query("SELECT DISTINCT ip_address FROM ad_visits
                        WHERE user_id IS NULL AND ip_address IS NOT NULL AND created_at >= '$since' AND " . AD_NOT_OWN_SQL);
    while ($r && ($row = $r->fetch_assoc())) {
        $k = ad_ip_key((string) $row['ip_address']);
        if ($k !== '') $nets[$k] = true;
    }
    if ($nets) {
        $r = $conn->query("SELECT l.user_id, l.ip_address FROM users u JOIN user_ip_log l ON l.user_id = u.user_id
                            WHERE $range AND l.ip_address IS NOT NULL AND l.ip_address <> ''");
        while ($r && ($row = $r->fetch_assoc())) {
            if (isset($nets[ad_ip_key((string) $row['ip_address'])])) $cand[(int) $row['user_id']] = true;
        }
    }
    if (!$cand) return $empty;

    $min = max(1, (int) $o['min']);
    $source = strtolower(trim((string) $o['source']));
    $rows = [];
    $available = [];
    $summary = $empty['summary'];
    foreach (array_chunk(array_keys($cand), 400) as $chunk) {
        foreach (ad_journey_collect($conn, $chunk) as $uid => $j) {
            $vs = [];
            foreach ($j['visits'] as $v) {
                $src = strtolower((string) ($v['source'] ?: 'unknown'));
                if (($o['match'] === 'device' && $v['match_type'] !== 'device')
                    || ($o['timing'] === 'before' && $v['before_register'] !== true)
                    || ($o['timing'] === 'after' && $v['before_register'] !== false)) continue;
                $available[$src] = ($available[$src] ?? 0) + 1;
                if ($source !== '' && $src !== $source) continue;
                $vs[] = $v + ['src' => $src];
            }
            if (count($vs) < $min) continue;

            $srcCount = [];
            $ads = [];
            foreach ($vs as $v) {
                $srcCount[$v['src']] = ($srcCount[$v['src']] ?? 0) + 1;
                $ads[$v['src'] . '|' . $v['ad_label']] = true;
                $summary['sources'][$v['src']] = ($summary['sources'][$v['src']] ?? 0) + 1;
            }
            arsort($srcCount);
            $device = count(array_filter($vs, fn($v) => $v['match_type'] === 'device'));
            $before = array_values(array_filter($vs, fn($v) => $v['before_register'] === true));
            $rows[$uid] = [
                'user_id'         => $uid,
                'registered_at'   => $j['registered_at'],
                'visits'          => count($vs),
                'device'          => $device,
                'ip'              => count($vs) - $device,
                'before_register' => count($before),
                'distinct_ads'    => count($ads),
                'sources'         => $srcCount,
                'first_touch'     => $vs[0]['ad_label'],
                'last_touch'      => $before ? end($before)['ad_label'] : null,
                'first_visit_at'  => $vs[0]['visited_at'],
                'last_visit_at'   => end($vs)['visited_at'],
                'devices'         => array_values(array_unique(array_filter(array_column($vs, 'device')))),
            ];
            $summary['visits'] += count($vs);
            $summary['device'] += $device;
            $summary['before_register'] += count($before);
        }
    }
    if (!$rows) return ['available_sources' => $available] + $empty;

    $r = $conn->query("SELECT user_id, name, email, phone, registered_at, state FROM users WHERE user_id IN (" . implode(',', array_keys($rows)) . ")");
    while ($r && ($u = $r->fetch_assoc())) {
        $id = (int) $u['user_id'];
        $rows[$id]['name']  = $u['name'];
        $rows[$id]['email'] = $u['email'];
        $rows[$id]['phone'] = $u['phone'];
        $rows[$id]['state'] = $u['state'];
        $rows[$id]['registered_at'] = $u['registered_at'] ?: $rows[$id]['registered_at'];
    }

    $rows = array_values($rows);
    $sort = $o['sort'];
    usort($rows, function ($a, $b) use ($sort) {
        if ($sort === 'recent') return strcmp((string) $b['registered_at'], (string) $a['registered_at']);
        if ($sort === 'first_visit') return strcmp((string) $a['first_visit_at'], (string) $b['first_visit_at']);
        return [$b['visits'], $b['before_register']] <=> [$a['visits'], $a['before_register']];
    });
    arsort($summary['sources']);
    arsort($available);
    $summary['students'] = count($rows);
    return ['students' => $rows, 'summary' => $summary, 'available_sources' => $available];
}

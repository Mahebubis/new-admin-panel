<?php
require_once __DIR__ . '/SendGridTransport.php';
require_once __DIR__ . '/ElasticEmailTransport.php';
require_once __DIR__ . '/SesTransport.php';
require_once __DIR__ . '/EspRateLimiter.php';

/**
 * The sending domains that belong to one email_esp_settings row.
 *
 * Its default first, then every extra domain verified with it. One function because the settings
 * screen, the campaign wizard and anything added later must agree on the answer — two readings of
 * this drift apart quietly, and the symptom is a campaign addressed from a domain its own provider
 * has never heard of, which fails on every recipient with an authentication error.
 *
 * @return string[] lowercase hostnames, no duplicates, default first
 */
function esp_domains_from_row(array $row): array {
    $out = [];
    $default = strtolower(trim((string)($row['default_sending_domain'] ?? '')));
    if ($default !== '') $out[] = $default;

    $extra = $row['sending_domains'] ?? null;
    $list = is_array($extra) ? $extra : json_decode((string)$extra, true);
    if (is_array($list)) {
        foreach ($list as $d) {
            $d = strtolower(trim((string)$d));
            if ($d !== '' && !in_array($d, $out, true)) $out[] = $d;
        }
    }
    return $out;
}

class TransportFactory {
    /** Providers that can actually be selected/configured today. MailWizz is intentionally
     *  absent: its row is gone from email_esp_settings and its transport class was removed,
     *  but the value survives in the esp_transport ENUM so historical campaign rows stay
     *  readable (see the migration note in lib/schema.php). */
    public const PROVIDERS = ['sendgrid', 'elasticemail', 'ses'];

    /** Reads $campaign['esp_transport'], loads the matching email_esp_settings row, instantiates.
     *
     *  An empty value means the campaign predates the Content step's "Send through" picker and
     *  never named a provider; it falls back to whichever sender Settings has flagged active,
     *  which is what such a campaign would have used anyway. It is NOT defaulted to SendGrid —
     *  that silently sent legacy campaigns through a provider nobody chose. */
    public static function forCampaign(array $campaign): ?EspTransport {
        $p = (string)($campaign['esp_transport'] ?? '');
        if (!in_array($p, self::PROVIDERS, true)) $p = self::activeProvider();
        return self::forProvider($p);
    }

    public static function forProvider(string $provider): ?EspTransport {
        global $conn;
        // Anything unrecognized — including the retired 'mailwizz' on an old campaign being
        // requeued — falls back to SendGrid rather than returning null, so a legacy campaign
        // still sends instead of failing every recipient with "No ESP transport configured".
        if (!in_array($provider, self::PROVIDERS, true)) $provider = 'sendgrid';

        $stmt = $conn->prepare("SELECT * FROM email_esp_settings WHERE provider = ? LIMIT 1");
        $stmt->bind_param('s', $provider);
        $stmt->execute();
        $row = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        if (!$row) return null;

        if ($provider === 'elasticemail') return new ElasticEmailTransport($row);
        if ($provider === 'ses')          return new SesTransport($row);
        return new SendGridTransport($row);
    }

    /** Which provider is flagged active in Settings (used as the default for new campaigns). */
    public static function activeProvider(): string {
        global $conn;
        $r = $conn->query("SELECT provider FROM email_esp_settings WHERE is_active = 1 LIMIT 1");
        $row = $r ? $r->fetch_assoc() : null;
        $provider = $row['provider'] ?? 'sendgrid';
        return in_array($provider, self::PROVIDERS, true) ? $provider : 'sendgrid';
    }

    /**
     * How many sends this provider tolerates in flight at once.
     *
     * CAMPAIGN_SEND_CONCURRENCY is tuned for SendGrid and Elastic Email, which absorb a burst
     * and answer 429 only under sustained load. Amazon SES is different in kind: it enforces a
     * hard requests-PER-SECOND ceiling (14/s by default in production, 1/s while the account is
     * still in the sandbox) and rejects everything above it immediately. Firing 32 concurrent
     * sends at it means most of a batch comes back throttled — those retry rather than being
     * lost (see SesTransport::parseResponse), but the run is spent achieving nothing.
     *
     * So SES is capped at its default rate. Raise SES_MAX_CONCURRENCY in lib/config.php after
     * AWS grants a higher sending rate — the value is a per-second rate and each send takes
     * well under a second, so concurrency ≈ rate is the right approximation.
     */
    /**
     * The sends-per-second pacing a transport needs, or null when it needs none.
     *
     * Only Amazon SES: it refuses everything above its per-second rate instead of queueing it,
     * which concurrency alone cannot prevent (see lib/EspRateLimiter.php). The account's real rate
     * is read from SES once per worker run, so a raise from AWS takes effect without a deploy.
     */
    public static function rateLimiterFor(?EspTransport $transport): ?EspRateLimiter {
        if (!($transport instanceof SesTransport)) return null;
        static $rate = null;
        if ($rate === null) {
            $live = 0.0;
            try {
                require_once __DIR__ . '/SesSuppressionClient.php';
                $st = ses_account_status();
                if (!empty($st['ok'])) $live = (float)($st['max_send_rate'] ?? 0);
            } catch (Throwable $e) { /* fall back to the configured ceiling */ }
            $ceiling = $live > 0 ? $live : (float)(defined('SES_MAX_SEND_RATE') ? SES_MAX_SEND_RATE : 14);
            $headroom = defined('SES_SEND_RATE_HEADROOM') ? (float)SES_SEND_RATE_HEADROOM : 0.8;
            $rate = max(1.0, floor($ceiling * $headroom));
        }
        return new EspRateLimiter('ses', $rate);
    }

    public static function concurrencyFor(string $provider): int {
        $base = defined('CAMPAIGN_SEND_CONCURRENCY') ? (int)CAMPAIGN_SEND_CONCURRENCY : 32;
        if ($provider === 'ses') {
            $cap = defined('SES_MAX_CONCURRENCY') ? (int)SES_MAX_CONCURRENCY : 14;
            return max(1, min($base, $cap));
        }
        return max(1, $base);
    }
}

<?php
/*
 * The WhatsApp webhook PROCESSING side — everything webhook.php used to do inline, moved into a
 * background drainer and rewritten to work on a whole chunk of receipts at once.
 *
 * WHAT CHANGED, AND WHY IT MATTERS
 * The parsing (wa_collect_statuses and friends) is carried over verbatim — it was never the
 * problem, and every one of its comments records a payload shape learned from a real rejection.
 * What changed is the WRITE side. The old loop, per event, ran roughly:
 *
 *     SELECT by wa_message_id  →  SELECT by rid  →  SELECT by phone  →  UPDATE the recipient
 *     →  UPDATE wa_campaigns SET delivered_count = delivered_count + 1  →  INSERT an event row
 *
 * Six round trips per receipt, and the counter UPDATE took a row lock on the SAME wa_campaigns
 * row every time. For a 50,000-recipient campaign that is 300,000 queries and 50,000 serialized
 * lock acquisitions on one row.
 *
 * Here the same work is done per CHUNK: three correlation SELECTs total (one per identifier
 * kind, batched with IN), at most four grouped UPDATEs, one multi-row INSERT, and ONE count
 * refresh per campaign. A 2,000-receipt chunk costs about a dozen queries instead of 12,000.
 *
 * The per-receipt "+ 1" on wa_campaigns is gone entirely. Counters are now DERIVED from the
 * recipient rows by wa_refresh_campaign_counts() (in WaSendWorker.php, so the send worker can
 * reach it too), which removes the hot row and makes the numbers self-healing.
 */
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/schema.php';
require_once __DIR__ . '/WaSendWorker.php';
require_once __DIR__ . '/WaInbox.php';
require_once __DIR__ . '/WaWebhookQueue.php';

/** Provider vocabulary → our recipient statuses. Anything unrecognized is logged, not guessed. */
const WA_STATUS_MAP = [
    'sent' => 'sent', 'accepted' => 'sent', 'submitted' => 'sent',
    'delivered' => 'delivered', 'delivery' => 'delivered',
    'read' => 'read', 'seen' => 'read',
    'failed' => 'failed', 'undelivered' => 'failed', 'rejected' => 'failed', 'error' => 'failed',
    'click' => 'button_click', 'button_click' => 'button_click', 'clicked' => 'button_click',
    'reply' => 'replied', 'replied' => 'replied', 'inbound' => 'replied',
];

/*
 * Status only ever moves FORWARD along sent → delivered → read. WhatsApp does not guarantee
 * webhook ordering, and a late-arriving "delivered" must not overwrite a "read" that already
 * landed — otherwise the read count silently decays over the life of a campaign.
 *
 * 'failed' ranks ABOVE read so nothing overwrites it. It used to be absent from this table
 * entirely, which scored a rejected row as 0 — below every other state — so the next delivered
 * receipt won the comparison, flipped the row, and counted the same person twice. That is how
 * Delivered + Failed came to exceed a campaign's own audience.
 */
const WA_STATUS_RANK = ['pending' => 0, 'processing' => 1, 'sent' => 2, 'delivered' => 3, 'read' => 4, 'failed' => 5];

/** Identifiers per IN(...) list. Keeps one chunk from building a multi-megabyte query string
 *  that trips max_allowed_packet on shared hosting. */
const WA_CORRELATE_BATCH = 1000;

// ─────────────────────────────────────────────────────────────────────────────────────────────
// Payload parsing — moved verbatim from webhook.php. Behaviour is unchanged.
// ─────────────────────────────────────────────────────────────────────────────────────────────

/** Collects every {id, status} pair anywhere in the payload. */
/**
 * WHEN THE EVENT HAPPENED, as the provider reports it — not when we got round to applying it.
 *
 * Meta stamps every status with a unix "timestamp", and it is the only honest answer to "when was
 * this read". A receipt can arrive minutes or hours after the fact: WhatsApp holds read receipts
 * for a message the recipient has not scrolled to, Meta retries a callback it could not deliver,
 * and our own drainer is a cron. Writing NOW() collapsed all of that into "whenever the worker
 * noticed", which put a read at 18:08 on the report at 19:35 — indistinguishable from the student
 * having genuinely opened the message an hour and a half late, and now also the wrong bucket for
 * the report's date-range filter.
 *
 * Returns 'Y-m-d H:i:s' or null. Anything unparseable, absurdly old, or in the future is refused
 * rather than trusted: a bad clock on the far side must not be able to stamp a message with a
 * date the report will then order everything else around.
 */
function wa_event_time($raw): ?string {
    if ($raw === null || $raw === '' || is_array($raw)) return null;

    $ts = null;
    if (is_numeric($raw)) {
        $n = (float)$raw;
        // Milliseconds are just as common as seconds across BSPs, and telling them apart by
        // magnitude is exact for every date this product will ever see.
        if ($n > 100000000000) $n = $n / 1000;
        $ts = (int)$n;
    } else {
        $p = strtotime((string)$raw);
        if ($p !== false) $ts = $p;
    }
    if (!$ts) return null;

    $now = time();
    // A minute of tolerance forward, for ordinary clock skew between Meta and this server.
    if ($ts > $now + 60) return null;
    if ($ts < $now - 90 * 86400) return null;
    return date('Y-m-d H:i:s', $ts);
}

function wa_collect_statuses(array $node, array &$out): void {
    $idKeys     = ['message_id', 'messageId', 'id', 'wamid', 'mid'];
    $statusKeys = ['status', 'event', 'event_type', 'state'];
    // Meta sends 'timestamp'; the others are what BSPs wrapping it have been seen to use.
    $timeKeys   = ['timestamp', 'event_time', 'eventTime', 'status_time', 'time', 'updated_at'];

    $id = null; $status = null; $rid = null; $reason = null; $code = null; $at = null;
    foreach ($idKeys as $k) {
        if (isset($node[$k]) && (is_string($node[$k]) || is_numeric($node[$k]))) { $id = (string)$node[$k]; break; }
    }
    /*
     * Meta's Cloud API shape: entry[].changes[].value.statuses[] = {id: "wamid…", status:
     * "sent|delivered|read|failed", errors: [{code, title, error_data:{details}}]}. The id and
     * status keys already match the loops above; only the nested error array needs pulling out,
     * otherwise a Meta failure would arrive with no reason attached.
     */
    if (isset($node['errors'][0]) && is_array($node['errors'][0])) {
        $e = $node['errors'][0];
        $reason = $e['error_data']['details'] ?? ($e['title'] ?? ($e['message'] ?? null));
        if (isset($e['code'])) $code = (string)$e['code'];
    }
    foreach ($statusKeys as $k) {
        if (isset($node[$k]) && is_string($node[$k])) { $status = strtolower($node[$k]); break; }
    }
    foreach (['x-apiheader', 'x_apiheader', 'apiheader', 'custom_id'] as $k) {
        if (isset($node[$k]) && is_string($node[$k])) { $rid = $node[$k]; break; }
    }
    foreach ($timeKeys as $k) {
        if (!isset($node[$k])) continue;
        $parsed = wa_event_time($node[$k]);
        if ($parsed !== null) { $at = $parsed; break; }
    }
    // Guarded on being unset: Meta's nested errors[] was already read above and is more
    // specific than any flat key, so it must not be overwritten here.
    if ($reason === null) {
        /*
         * Widened well past Meta's own vocabulary because a BSP wraps the rejection in its own
         * envelope, and the reason is the single most useful field on a failure — "Reported
         * failed by WhatsApp" tells an admin nothing they can act on. Netcore in particular
         * nests it under error{}/errors[] with `title`/`details` rather than a flat key.
         */
        foreach (['status_remark', 'reason', 'error_message', 'description', 'detail', 'details',
                  'error_desc', 'errorMessage', 'failure_reason', 'title', 'message'] as $k) {
            if (isset($node[$k]) && is_string($node[$k]) && trim($node[$k]) !== '') { $reason = $node[$k]; break; }
        }
    }
    if ($reason === null && isset($node['error']) && is_array($node['error'])) {
        $e = $node['error'];
        $reason = $e['error_data']['details'] ?? ($e['details'] ?? ($e['title'] ?? ($e['message'] ?? null)));
        if ($code === null && isset($e['code'])) $code = (string)$e['code'];
    }
    if ($code === null) {
        foreach (['error_code', 'code', 'errorCode'] as $k) {
            if (isset($node[$k]) && (is_string($node[$k]) || is_numeric($node[$k]))) { $code = (string)$node[$k]; break; }
        }
    }

    /*
     * The recipient's number, pulled out alongside the id because with Netcore it is the ONLY
     * thing linking an event to a recipient. Their send response returns a per-REQUEST uuid
     * ({"data":{"id":"6aafb690-…"}}), their webhooks report Meta wamids, and they do not echo the
     * x-apiheader we send — so no identifier we hold at send time ever appears again.
     */
    $phone = null;
    foreach (['recipient_whatsapp', 'mobile', 'msisdn', 'mobile_number', 'phone', 'wa_id', 'recipient', 'to'] as $k) {
        if (isset($node[$k]) && (is_string($node[$k]) || is_numeric($node[$k]))) { $phone = (string)$node[$k]; break; }
    }

    if ($status !== null && ($id !== null || $rid !== null)) {
        $out[] = ['id' => $id, 'rid' => $rid, 'phone' => $phone, 'status' => $status,
                  'reason' => $reason, 'code' => $code, 'at' => $at];
        // Stop here rather than also walking this node's children: a node carrying both an id
        // and a status IS the message record, and descending into it would collect the same
        // event a second time — which would double-count clicks and replies (delivered/read
        // are protected by the forward-only rank check below, those two are not).
        return;
    }
    foreach ($node as $child) {
        if (is_array($child)) wa_collect_statuses($child, $out);
    }
}

/**
 * The recipient's number, read out of a Meta wamid.
 *
 * A wamid is base64 after the "wamid." prefix, and the decoded bytes begin with a short header
 * followed by the recipient's number as plain ASCII digits:
 *
 *   wamid.HBgMOTE5NzY3Njk0NDE0FQIA…  →  \x1c\x18\x0c 919767694414 …
 *
 * Used ONLY as a fallback, when the payload carries no phone field of its own — Netcore's event
 * webhook is the case that needs it. It is a heuristic on an undocumented encoding, so nothing is
 * trusted on its say-so: whatever comes out is looked up against recipients WE actually messaged
 * recently, and a wrong guess simply finds no row rather than mis-crediting one.
 */
function wa_phone_from_wamid(?string $wamid): ?string {
    if ($wamid === null || strpos($wamid, 'wamid.') !== 0) return null;
    $b64 = substr($wamid, 6);
    // wamids use standard base64 but are sometimes passed through URL-safe encoders.
    $decoded = base64_decode(strtr($b64, '-_', '+/'), false);
    if ($decoded === false || $decoded === '') return null;
    return preg_match('/(\d{10,15})/', $decoded, $m) ? $m[1] : null;
}

/*
 * The same endpoint is registered on the panel's Consent tab as well as its Event tab, because
 * an opt-out made anywhere — the Netcore UI, a STOP reply, another system on the same number —
 * has to reach our suppression list or the next campaign will message that person again.
 *
 * Consent payloads carry a phone number and an optin/optout state but no message id, so they
 * never match the status collector above and need their own pass.
 */
function wa_apply_consent_events(array $node, int &$applied): void {
    $phone = null; $state = null;
    foreach (['mobile', 'recipient', 'recipient_whatsapp', 'phone', 'mobile_number', 'msisdn'] as $k) {
        if (isset($node[$k]) && (is_string($node[$k]) || is_numeric($node[$k]))) { $phone = (string)$node[$k]; break; }
    }
    foreach (['type', 'status', 'consent', 'consent_status', 'event'] as $k) {
        if (isset($node[$k]) && is_string($node[$k])) {
            $v = strtolower(trim($node[$k]));
            if (in_array($v, ['optin', 'opt-in', 'opt_in', 'optout', 'opt-out', 'opt_out', 'blocklist', 'blocked'], true)) {
                $state = $v; break;
            }
        }
    }

    if ($phone !== null && $state !== null) {
        $normalized = wa_normalize_phone($phone, wa_default_cc());
        if ($normalized !== null) {
            // Blocklisted is treated as opted out: either way we must not message them.
            $isOut = strpos($state, 'out') !== false || strpos($state, 'block') !== false;
            wa_record_optin($normalized, $isOut ? 'optout' : 'optin', 'WEBHOOK');
            $applied++;
        }
        return;
    }
    foreach ($node as $child) {
        if (is_array($child)) wa_apply_consent_events($child, $applied);
    }
}

/*
 * Registered on the Template tab too: Meta's approval decisions arrive here, and an approval
 * badge that silently goes stale is worse than none — the wizard uses it to warn before a send.
 * Only ever updates a template we already know about, so an unrelated payload can't create rows.
 */
function wa_apply_template_events(array $node, int &$applied): void {
    global $conn;
    $name = null; $status = null;
    foreach (['template_name', 'templateName', 'name'] as $k) {
        if (isset($node[$k]) && is_string($node[$k]) && preg_match('/^[a-z0-9_]+$/', $node[$k])) { $name = $node[$k]; break; }
    }
    foreach (['status', 'event', 'template_status'] as $k) {
        if (isset($node[$k]) && is_string($node[$k])) {
            $v = strtolower(trim($node[$k]));
            if (in_array($v, ['approved', 'rejected', 'pending', 'paused', 'disabled'], true)) { $status = $v; break; }
        }
    }

    if ($name !== null && $status !== null) {
        // 'paused'/'disabled' are not deliverable, so they map to the same warning state as a
        // rejection rather than being dropped on the floor.
        $mapped = $status === 'approved' ? 'approved' : ($status === 'pending' ? 'pending' : 'rejected');
        $conn->query("UPDATE wa_templates SET approval_status='" . $conn->real_escape_string($mapped) . "'
                       WHERE name='" . $conn->real_escape_string($name) . "'");
        if ($conn->affected_rows > 0) $applied++;
        return;
    }
    foreach ($node as $child) {
        if (is_array($child)) wa_apply_template_events($child, $applied);
    }
}

/*
 * The Journey engine's half of this endpoint, loaded only if it is actually on disk.
 *
 * This backend deploys folder by folder, so whatsapp/ can be newer than journeys/. A bare
 * require of a file that has not been uploaded yet is a FATAL — which would silently stop every
 * campaign delivery receipt below, turning a missing journeys feature into a broken WhatsApp
 * report. Missing sink = journeys get no counts, campaigns are untouched.
 */
function journey_sink_ready(): bool {
    static $ready = null;
    if ($ready !== null) return $ready;
    $sink = __DIR__ . '/../../journeys/lib/JourneyWebhookSink.php';
    if (!file_exists($sink)) return $ready = false;
    require_once $sink;
    return $ready = function_exists('journey_webhook_wa_event');
}

/*
 * FIX 2 — the derived campaign counters — lives in WaSendWorker.php as wa_refresh_campaign_counts().
 *
 * It sits there rather than here because BOTH sides need it: the drainer calls it after every
 * chunk, and the send worker calls it when a campaign drains. WaSendWorker.php is the one file
 * they already share, and putting it here would mean the send worker had to require the whole
 * webhook processor to correct its own numbers.
 */

// ─────────────────────────────────────────────────────────────────────────────────────────────
// Bulk correlation
// ─────────────────────────────────────────────────────────────────────────────────────────────

/** Escaped, comma-joined, quoted list for an IN(...) — empty string when there is nothing. */
function wa_wq_in_list(array $values): string {
    global $conn;
    $out = [];
    foreach ($values as $v) $out[] = "'" . $conn->real_escape_string((string)$v) . "'";
    return implode(',', $out);
}

/**
 * The most recent journey WhatsApp send per phone, for every phone at once.
 *
 * The Journey engine sends to the same numbers over the same WABA, and the campaign phone
 * fallback below reaches back 7 days — so a campaign a student was in last week will happily
 * claim a receipt that belongs to a journey message sent two minutes ago. Whichever actually
 * sent LAST is the right owner.
 *
 * The per-phone helper in JourneyWebhookSink.php answers exactly this, but one query at a time,
 * which is the shape this rewrite exists to remove. One GROUP BY replaces N queries.
 *
 * Wrapped: on an install where journeys was never deployed the table does not exist, and mysqli
 * throws on PHP 8.1+. A missing journeys feature must cost journey counts, never campaign ones.
 */
function wa_wq_journey_last_sent_bulk(array $phones): array {
    global $conn;
    if (!$phones || !journey_sink_ready()) return [];

    $out = [];
    try {
        foreach (array_chunk(array_values(array_unique($phones)), WA_CORRELATE_BATCH) as $slice) {
            $in = wa_wq_in_list($slice);
            if ($in === '') continue;
            $r = $conn->query("SELECT to_addr, MAX(sent_at) AS last_sent
                                 FROM journey_messages
                                WHERE channel = 'whatsapp' AND to_addr IN ($in)
                                  AND sent_at IS NOT NULL
                                  AND sent_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)
                                GROUP BY to_addr");
            while ($r && $row = $r->fetch_assoc()) $out[(string)$row['to_addr']] = (string)$row['last_sent'];
        }
    } catch (\Throwable $e) {
        return [];
    }
    return $out;
}

/**
 * Resolves a whole chunk of events to recipient rows in three queries instead of three per event.
 *
 * The lookup ORDER is the same as the old per-event code, and for the same reasons:
 *
 *   wa_message_id first — it is what Meta's receipts carry, so that route hits immediately.
 *   rid second       — our own id, echoed by providers that support a custom header.
 *   phone last       — the Netcore route, where NEITHER of the above can ever match: Netcore
 *                      returns a per-request uuid at send time, reports Meta wamids on its
 *                      webhooks, and does not echo our x-apiheader. The recipient's number is
 *                      the only value present on both sides.
 *
 * Two separate equality lookups rather than `WHERE wa_message_id=… OR rid=…`: that OR spans two
 * indexes, and MySQL routinely declines to index-merge it and full-scans wa_campaign_recipients
 * instead — every row of every campaign ever sent, once per receipt.
 *
 * @param array $events events as produced by wa_collect_statuses(), each already carrying a
 *                      normalized `mapped` status and `norm_phone`.
 * @return array{rows: array<int,array>, byMsgId: array, byRid: array, byPhone: array}
 */
function wa_wq_correlate(array $events): array {
    global $conn;

    $msgIds = []; $rids = []; $phones = [];
    foreach ($events as $ev) {
        if ($ev['id']  !== null && $ev['id']  !== '') $msgIds[$ev['id']]  = true;
        if ($ev['rid'] !== null && $ev['rid'] !== '') $rids[$ev['rid']]   = true;
        if ($ev['norm_phone'] !== null)               $phones[$ev['norm_phone']] = true;
    }

    $byMsgId = []; $byRid = []; $byPhone = []; $rows = [];

    $keep = function (array $r) use (&$rows) {
        $rows[(int)$r['id']] = $r;
        return (int)$r['id'];
    };

    foreach (array_chunk(array_keys($msgIds), WA_CORRELATE_BATCH) as $slice) {
        $in = wa_wq_in_list($slice);
        if ($in === '') continue;
        $r = $conn->query("SELECT id, campaign_id, status, phone, rid, wa_message_id
                             FROM wa_campaign_recipients WHERE wa_message_id IN ($in)");
        while ($r && $row = $r->fetch_assoc()) $byMsgId[(string)$row['wa_message_id']] = $keep($row);
    }

    foreach (array_chunk(array_keys($rids), WA_CORRELATE_BATCH) as $slice) {
        $in = wa_wq_in_list($slice);
        if ($in === '') continue;
        $r = $conn->query("SELECT id, campaign_id, status, phone, rid, wa_message_id
                             FROM wa_campaign_recipients WHERE rid IN ($in)");
        while ($r && $row = $r->fetch_assoc()) $byRid[(string)$row['rid']] = $keep($row);
    }

    /*
     * Scoped exactly as the per-event fallback was, so it can only ever credit the right row:
     * our campaigns only, non-test, actually sent, NOT already rejected, within 7 days — well
     * past any real delivery delay, and short enough that a receipt cannot attach to a
     * months-old campaign to the same person. ORDER BY phone, sent_at DESC lets one pass keep
     * the newest row per number, which is what "LIMIT 1 per phone" meant when it ran once per
     * event.
     *
     * `status <> 'failed'` IS THE LOAD-BEARING ONE, and it is not the same as sent_at IS NOT
     * NULL. sent_at is stamped when the send is ATTEMPTED, so a recipient Meta rejected outright
     * still carries one and would stay eligible to match.
     *
     * That matters because this WABA is SHARED. Campaigns sent from Netcore's own dashboard go to
     * the same students over the same number, and their receipts arrive here carrying Meta wamids
     * we have never seen and no rid of ours — so they fall through to this fallback. With rejected
     * rows still eligible, a receipt for SOMEBODY ELSE'S message finds our failed row for that
     * phone and marks it delivered.
     *
     * Campaign 53 is the worked example: 2,946 recipients rejected with 131008, so 602 messages
     * existed in total — and its delivered count then climbed past 640 over the following hours,
     * with rows still carrying the 131008 that proves no message was ever sent to them. Every one
     * of those was another campaign's receipt being counted as ours.
     *
     * A failed row has nothing in flight, so it can never legitimately own a receipt. Excluding it
     * also gets the cross-campaign case right by construction: when our send to a number failed and
     * someone else's succeeded, nothing matches, which is the correct answer.
     *
     * This clause was added to webhook.php in production AFTER the copy this rewrite started from,
     * and reintroducing the bug by rebuilding on the older logic is exactly the failure this note
     * exists to prevent. Do not drop it.
     */
    foreach (array_chunk(array_keys($phones), WA_CORRELATE_BATCH) as $slice) {
        $in = wa_wq_in_list($slice);
        if ($in === '') continue;
        $r = $conn->query("SELECT id, campaign_id, status, phone, rid, wa_message_id, sent_at
                             FROM wa_campaign_recipients
                            WHERE phone IN ($in)
                              AND is_test = 0
                              AND sent_at IS NOT NULL
                              AND status <> 'failed'
                              AND sent_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)
                            ORDER BY phone, sent_at DESC");
        while ($r && $row = $r->fetch_assoc()) {
            $p = (string)$row['phone'];
            if (isset($byPhone[$p])) continue;   // first row per phone is the newest
            $byPhone[$p] = $keep($row);
        }
    }

    return ['rows' => $rows, 'byMsgId' => $byMsgId, 'byRid' => $byRid, 'byPhone' => $byPhone];
}

// ─────────────────────────────────────────────────────────────────────────────────────────────
// The drain
// ─────────────────────────────────────────────────────────────────────────────────────────────

/**
 * Claims and processes up to $chunk queued callbacks.
 *
 * @return array{claimed:int, events:int, applied:int, campaigns:array<int,bool>, lag:?float}
 */
function wa_wq_drain_once(int $chunk = WA_WEBHOOK_CHUNK): array {
    global $conn;
    $empty = ['claimed' => 0, 'events' => 0, 'applied' => 0, 'campaigns' => [], 'lag' => null];

    /*
     * Claim with a token that is unique to THIS claim, then read back only the rows carrying it.
     *
     * Reading back "WHERE status='processing'" instead would be wrong the moment a second drainer
     * exists — and one does: webhook.php runs on the public web server (that is where Netcore
     * POSTs) while the drainer's cron runs on the monitoring box, both against the same database.
     * flock() is a local lock and cannot see across machines, so the two would happily read each
     * other's in-flight rows and apply every receipt twice.
     *
     * The token removes the need for any coordination at all: whatever this UPDATE stamped is
     * exactly what the SELECT returns, no matter how many drainers are running or where.
     *
     * The status flip still earns its place — it is what makes a run killed mid-chunk visible as
     * 'processing' rather than silently lost, so the recovery in wa_wq_drain_loop() can find it.
     */
    $token = bin2hex(random_bytes(16));
    $conn->query("UPDATE wa_webhook_queue
                     SET status='processing', attempts = attempts + 1,
                         claim_token='$token', claimed_at=NOW()
                   WHERE status='pending' ORDER BY id LIMIT " . (int)$chunk);
    if ($conn->affected_rows <= 0) return $empty;

    $qrows = [];
    $r = $conn->query("SELECT id, raw_body, received_at FROM wa_webhook_queue
                        WHERE claim_token='$token' ORDER BY id");
    while ($r && $row = $r->fetch_assoc()) $qrows[] = $row;
    if (!$qrows) return $empty;

    $queueIds = array_map(fn($x) => (int)$x['id'], $qrows);
    // Measured against the OLDEST row in the chunk: that is the worst-case wait any receipt in
    // this batch experienced, and the number worth watching when tuning the poll interval.
    $lag = time() - strtotime((string)$qrows[0]['received_at']);

    // ── Pass 1: parse every payload, collect the status events ────────────────────────────
    $events = []; $consentApplied = 0; $templateApplied = 0; $inboxTotals = 0; $badRows = [];
    foreach ($qrows as $qr) {
        $payload = json_decode((string)$qr['raw_body'], true);
        if (!is_array($payload)) {
            $badRows[(int)$qr['id']] = 'unparseable JSON body';
            continue;
        }
        try {
            wa_apply_consent_events($payload, $consentApplied);
            wa_apply_template_events($payload, $templateApplied);
            /*
             * Live Chat ingestion — inbound replies, and delivery statuses for replies WE sent
             * from the inbox. Wrapped separately because a malformed inbound payload must never
             * cost us the delivery statuses in the same body: those are what keep the campaign
             * reports honest.
             */
            try {
                $ing = wa_ingest_webhook($payload);
                $inboxTotals += (int)($ing['messages'] ?? 0) + (int)($ing['statuses'] ?? 0) + (int)($ing['clicks'] ?? 0);
            } catch (\Throwable $e) {
                wa_wq_log('inbox ingestion failed on queue row #' . $qr['id'] . ' — ' . $e->getMessage());
            }
            wa_collect_statuses($payload, $events);
        } catch (\Throwable $e) {
            $badRows[(int)$qr['id']] = mb_substr($e->getMessage(), 0, 400);
        }
    }

    // Normalize once, here, so neither the correlation nor the apply pass has to think about it.
    $usable = [];
    foreach ($events as $ev) {
        $mapped = WA_STATUS_MAP[$ev['status']] ?? null;
        if ($mapped === null) continue;
        $phone = $ev['phone'] ?? wa_phone_from_wamid($ev['id'] ?? null);
        $ev['mapped']     = $mapped;
        $ev['norm_phone'] = $phone !== null ? wa_normalize_phone($phone, wa_default_cc()) : null;
        $usable[] = $ev;
    }

    if (!$usable) {
        wa_wq_finish($queueIds, $badRows);
        return ['claimed' => count($qrows), 'events' => 0, 'applied' => $consentApplied + $templateApplied + $inboxTotals,
                'campaigns' => [], 'lag' => $lag];
    }

    // ── Pass 2: correlate the whole chunk in three queries ────────────────────────────────
    $corr    = wa_wq_correlate($usable);
    $rows    = $corr['rows'];
    $journey = wa_wq_journey_last_sent_bulk(array_values(array_filter(array_column($usable, 'norm_phone'))));

    // ── Pass 3: decide every row's outcome in PHP, writing nothing yet ────────────────────
    $final     = [];   // recipientId => ['rank'=>int,'status'=>string,'seen'=>[...]]
    $failInfo  = [];   // recipientId => ['reason'=>?string,'code'=>?string]
    $clickBump = [];   // recipientId => int
    $clickCampaignBump = []; // campaignId => int — the campaign total the old code bumped alongside
    $replyBump = [];   // campaignId  => int
    $eventRows = [];   // multi-row INSERT into wa_campaign_events
    $msgIdFix  = [];   // recipientId => provider message id learned via the phone fallback
    $optOut    = [];   // phones that replied STOP
    $campaigns = [];
    $applied   = 0;
    $unmatched = 0;
    $journeyHits = 0;

    foreach ($usable as $ev) {
        $mapped = $ev['mapped'];
        $recId  = null;
        $viaPhone = false;

        if ($ev['id'] !== null && isset($corr['byMsgId'][$ev['id']]))        $recId = $corr['byMsgId'][$ev['id']];
        elseif ($ev['rid'] !== null && isset($corr['byRid'][$ev['rid']]))    $recId = $corr['byRid'][$ev['rid']];
        elseif ($ev['norm_phone'] !== null && isset($corr['byPhone'][$ev['norm_phone']])) {
            $recId = $corr['byPhone'][$ev['norm_phone']];
            $viaPhone = true;
        }

        /*
         * Journey ownership contest — only on the phone fallback, exactly as before. A campaign
         * from last week must not claim a receipt for a journey message sent two minutes ago.
         */
        if ($ev['norm_phone'] !== null && isset($journey[$ev['norm_phone']])) {
            $jSent = $journey[$ev['norm_phone']];
            $rSent = $recId !== null ? (string)($rows[$recId]['sent_at'] ?? '') : '';
            if ($recId === null || ($viaPhone && ($rSent === '' || strtotime($jSent) > strtotime($rSent)))) {
                if (journey_webhook_wa_event($mapped, $ev['id'] ?? null, $ev['rid'] ?? null, $ev['norm_phone'],
                                             $ev['reason'] ?? null, $ev['code'] ?? null, $ev['at'] ?? null)) {
                    $journeyHits++; $applied++;
                    continue;
                }
            }
        }

        if ($recId === null) {
            // No campaign recipient and no journey message — somebody else's traffic on a shared
            // WABA, which is expected and not an error.
            $unmatched++;
            continue;
        }

        $cid = (int)$rows[$recId]['campaign_id'];
        $campaigns[$cid] = true;

        // On the first phone match, remember the provider's id so every LATER status for this
        // message takes the fast wa_message_id path instead of the phone fallback.
        if ($viaPhone && !empty($ev['id'])
            && (($rows[$recId]['wa_message_id'] ?? null) === null
                || $rows[$recId]['wa_message_id'] === $rows[$recId]['rid'])) {
            $msgIdFix[$recId] = (string)$ev['id'];
        }

        if ($mapped === 'button_click') {
            $clickBump[$recId] = ($clickBump[$recId] ?? 0) + 1;
            $clickCampaignBump[$cid] = ($clickCampaignBump[$cid] ?? 0) + 1;
            $eventRows[] = [$cid, $recId, 'button_click', null, $ev['reason'] ?? null];
            $applied++;
            continue;
        }

        if ($mapped === 'replied') {
            $replyBump[$cid] = ($replyBump[$cid] ?? 0) + 1;
            $eventRows[] = [$cid, $recId, 'replied', null, $ev['reason'] ?? null];
            // "STOP" is the universal WhatsApp opt-out. Honouring it here is what keeps a future
            // campaign from messaging someone who explicitly asked us not to.
            if ($ev['reason'] !== null && preg_match('/\b(stop|unsubscribe|opt\s*out)\b/i', $ev['reason'])) {
                $optOut[(string)$rows[$recId]['phone']] = true;
            }
            $applied++;
            continue;
        }

        // delivered / read / failed / sent — forward-only, against BOTH the stored status and
        // anything already decided for this recipient earlier in the same chunk.
        $currentRank = WA_STATUS_RANK[$rows[$recId]['status']] ?? 0;
        $bestRank    = max($currentRank, $final[$recId]['rank'] ?? 0);
        $newRank     = WA_STATUS_RANK[$mapped] ?? 0;

        // Milestones are recorded even when they lose the rank contest: a 'delivered' that
        // arrives after 'read' must still stamp delivered_at, or the derived delivered count
        // would miss a message that demonstrably reached a handset.
        $final[$recId]['seen'][$mapped] = true;
        $final[$recId]['campaign'] = $cid;

        if ($newRank <= $bestRank) continue;

        $final[$recId]['rank']   = $newRank;
        $final[$recId]['status'] = $mapped;
        if ($mapped === 'failed') {
            $failInfo[$recId] = ['reason' => $ev['reason'] ?? null, 'code' => $ev['code'] ?? null];
        }
        $eventRows[] = [$cid, $recId, $mapped, $ev['code'] ?? null, $ev['reason'] ?? null];
        $applied++;
    }

    // ── Pass 4: write it all back in a handful of grouped queries ─────────────────────────
    wa_wq_apply($final, $failInfo, $clickBump, $clickCampaignBump, $replyBump, $eventRows, $msgIdFix, $optOut);

    /*
     * FIX 2 — one refresh per campaign for the whole chunk, replacing one "+ 1" per receipt.
     * Runs after the writes above so it sees the rows this chunk just changed.
     */
    wa_refresh_campaign_counts(array_keys($campaigns));

    /*
     * A campaign marked 'sent' the moment the provider accepted its messages may turn out to
     * have had every one of them rejected. Re-taking that verdict costs two aggregate scans, so
     * it runs once per campaign per chunk — never per receipt, which is what made receipts back
     * up to a trickle before.
     */
    foreach (array_keys($campaigns) as $rcid) {
        if (!$failInfo) break;
        try {
            wa_reconcile_campaign_status((int)$rcid);
        } catch (\Throwable $e) {
            wa_wq_log("status reconcile skipped for campaign #$rcid — " . $e->getMessage());
        }
    }

    wa_wq_finish($queueIds, $badRows);

    if ($unmatched > 0) {
        // Expected on a shared WABA — other apps' traffic reaches this endpoint too — so it is a
        // per-chunk tally rather than the old per-event line.
        wa_wq_log("drain: $unmatched event(s) matched no recipient (usually other traffic on this WABA)");
    }

    return ['claimed' => count($qrows), 'events' => count($usable),
            'applied' => $applied + $consentApplied + $templateApplied + $inboxTotals,
            'campaigns' => $campaigns, 'lag' => $lag];
}

/**
 * The grouped writes. Every argument is keyed by recipient id and covers the WHOLE chunk, so
 * this is a fixed handful of queries no matter whether the chunk held 10 receipts or 2,000.
 */
function wa_wq_apply(array $final, array $failInfo, array $clickBump, array $clickCampaignBump,
                     array $replyBump, array $eventRows, array $msgIdFix, array $optOut): void {
    global $conn;

    // Bucket by the outcome each row settled on. `seen` decides whether a read row also gets its
    // delivered_at stamped — see the note where `seen` is filled in.
    $toDelivered = []; $toReadWithDel = []; $toReadOnly = []; $toFailed = []; $toSent = [];
    foreach ($final as $recId => $f) {
        if (!isset($f['status'])) continue;
        switch ($f['status']) {
            case 'delivered': $toDelivered[] = (int)$recId; break;
            case 'read':
                if (!empty($f['seen']['delivered'])) $toReadWithDel[] = (int)$recId;
                else                                 $toReadOnly[]    = (int)$recId;
                break;
            case 'failed':    $toFailed[]    = (int)$recId; break;
            case 'sent':      $toSent[]      = (int)$recId; break;
        }
    }

    /*
     * error_message/error_code are CLEARED on every success path, and that is not housekeeping.
     * A recipient whose first attempt was rejected keeps the rejection on the row while it waits
     * to be retried; when a later attempt lands, leaving that text behind produces a report row
     * reading "Delivered — 131008: buttons: Button at index 0 of type Url requires a parameter":
     * an outcome and a contradicting explanation on the same line. The row succeeded. The failure
     * is still on record in wa_campaign_events.
     */
    foreach (array_chunk($toDelivered, WA_CORRELATE_BATCH) as $slice) {
        $conn->query("UPDATE wa_campaign_recipients
                         SET status='delivered', delivered_at=NOW(), error_message=NULL, error_code=NULL
                       WHERE id IN (" . implode(',', $slice) . ")");
    }
    foreach (array_chunk($toReadWithDel, WA_CORRELATE_BATCH) as $slice) {
        // COALESCE, not NOW(): if delivered_at was already stamped by an earlier chunk, that is
        // the real delivery moment and must not be rewritten to the time we happened to catch up.
        $conn->query("UPDATE wa_campaign_recipients
                         SET status='read', read_at=NOW(), delivered_at=COALESCE(delivered_at, NOW()),
                             error_message=NULL, error_code=NULL
                       WHERE id IN (" . implode(',', $slice) . ")");
    }
    foreach (array_chunk($toReadOnly, WA_CORRELATE_BATCH) as $slice) {
        $conn->query("UPDATE wa_campaign_recipients
                         SET status='read', read_at=NOW(), error_message=NULL, error_code=NULL
                       WHERE id IN (" . implode(',', $slice) . ")");
    }
    foreach (array_chunk($toSent, WA_CORRELATE_BATCH) as $slice) {
        $conn->query("UPDATE wa_campaign_recipients
                         SET status='sent', sent_at=COALESCE(sent_at, NOW())
                       WHERE id IN (" . implode(',', $slice) . ")");
    }

    // Failures carry per-row text, so this one needs CASE arms rather than a flat SET.
    foreach (array_chunk($toFailed, 500) as $slice) {
        $errCases = ''; $codeCases = '';
        foreach ($slice as $id) {
            $reason = (string)($failInfo[$id]['reason'] ?? 'Reported failed by WhatsApp');
            $code   = (string)($failInfo[$id]['code'] ?? '');
            $errCases  .= " WHEN $id THEN '" . $conn->real_escape_string(substr($reason, 0, 480)) . "'";
            $codeCases .= " WHEN $id THEN '" . $conn->real_escape_string(substr($code, 0, 60)) . "'";
        }
        $in = implode(',', $slice);
        $conn->query("UPDATE wa_campaign_recipients
                         SET status='failed', failed_at=NOW(),
                             error_message = CASE id$errCases  ELSE error_message END,
                             error_code    = CASE id$codeCases ELSE error_code END
                       WHERE id IN ($in)");
    }

    // Clicks grouped by how many arrived for the same recipient in this chunk, so a person who
    // tapped three times costs one query per distinct count rather than three updates.
    $byCount = [];
    foreach ($clickBump as $recId => $n) $byCount[$n][] = (int)$recId;
    foreach ($byCount as $n => $recIds) {
        foreach (array_chunk($recIds, WA_CORRELATE_BATCH) as $slice) {
            $conn->query("UPDATE wa_campaign_recipients SET click_count = click_count + " . (int)$n . "
                           WHERE id IN (" . implode(',', $slice) . ")");
        }
    }

    /*
     * click_count and reply_count stay INCREMENTED rather than derived.
     *
     * Deliberate, and the asymmetry with sent/delivered/read/failed is the point: those four are
     * fully described by the recipient rows, so they can be recomputed from scratch. Campaign
     * click_count cannot — link taps are also counted from wa_link_clicks by click.php and c.php,
     * which know about visitors this table has never heard of. Deriving it here would silently
     * throw those away. These two are low-volume anyway; they were never the bottleneck.
     */
    foreach ($clickCampaignBump as $cid => $n) {
        $conn->query("UPDATE wa_campaigns SET click_count = click_count + " . (int)$n . " WHERE id=" . (int)$cid);
    }
    foreach ($replyBump as $cid => $n) {
        $conn->query("UPDATE wa_campaigns SET reply_count = reply_count + " . (int)$n . " WHERE id=" . (int)$cid);
    }

    // Backfill the provider's message id onto rows matched by phone, so their next status takes
    // the indexed fast path.
    foreach (array_chunk($msgIdFix, 500, true) as $slice) {
        $cases = ''; $ids = [];
        foreach ($slice as $recId => $mid) {
            $cases .= " WHEN " . (int)$recId . " THEN '" . $conn->real_escape_string($mid) . "'";
            $ids[]  = (int)$recId;
        }
        $conn->query("UPDATE wa_campaign_recipients
                         SET wa_message_id = CASE id$cases ELSE wa_message_id END
                       WHERE id IN (" . implode(',', $ids) . ")
                         AND (wa_message_id IS NULL OR wa_message_id = rid)");
    }

    // One multi-row INSERT for the audit trail, instead of one INSERT per event.
    foreach (array_chunk($eventRows, 500) as $slice) {
        $values = [];
        foreach ($slice as [$cid, $recId, $type, $code, $detail]) {
            $values[] = '(' . (int)$cid . ',' . (int)$recId . ",'" . $conn->real_escape_string($type) . "',"
                . ($code === null ? 'NULL' : "'" . $conn->real_escape_string(substr((string)$code, 0, 60)) . "'") . ','
                . ($detail === null ? 'NULL' : "'" . $conn->real_escape_string(substr((string)$detail, 0, 480)) . "'") . ')';
        }
        $conn->query("INSERT INTO wa_campaign_events (campaign_id, recipient_id, event_type, error_code, detail)
                      VALUES " . implode(',', $values));
    }

    foreach (array_keys($optOut) as $phone) {
        wa_record_optin((string)$phone, 'optout', 'REPLY');
    }
}

/** Clears the finished rows and parks the ones that could not be parsed. */
function wa_wq_finish(array $queueIds, array $badRows): void {
    global $conn;

    /*
     * Successful rows are DELETED, not marked done. A 50,000-recipient campaign produces at least
     * that many receipts; keeping them would grow this table by millions of raw JSON bodies a
     * month for no benefit, and the outcome of every one of them is already recorded on the
     * recipient row and in wa_campaign_events. Rows that FAILED to parse are kept — those are the
     * only ones anybody would ever want to look at.
     */
    $ok = array_values(array_diff($queueIds, array_keys($badRows)));
    foreach (array_chunk($ok, WA_CORRELATE_BATCH) as $slice) {
        $conn->query("DELETE FROM wa_webhook_queue WHERE id IN (" . implode(',', array_map('intval', $slice)) . ")");
    }

    foreach ($badRows as $id => $msg) {
        // Retried until WA_WEBHOOK_MAX_ATTEMPTS, then parked: one malformed payload must never
        // block the receipts queued behind it.
        // claim_token is released along with the row: a retry must be claimable again, and a
        // parked 'error' row holding a stale token would confuse the recovery sweep above.
        $conn->query("UPDATE wa_webhook_queue
                         SET status = CASE WHEN attempts >= " . (int)WA_WEBHOOK_MAX_ATTEMPTS . " THEN 'error' ELSE 'pending' END,
                             claim_token = NULL,
                             error_message = '" . $conn->real_escape_string(mb_substr($msg, 0, 480)) . "'
                       WHERE id = " . (int)$id);
    }
    if ($badRows) wa_wq_log('drain: ' . count($badRows) . ' queue row(s) could not be processed — see wa_webhook_queue.error_message');
}

/**
 * Drains until the queue is empty and the time budget runs out.
 *
 * The idle poll is what delivers the "delivered count updates within a second" behaviour: rather
 * than processing once and exiting for cron to restart it a minute later, the worker stays alive
 * and re-checks five times a second, so a receipt is applied almost the moment it is enqueued.
 */
/**
 * Is a WhatsApp campaign sending right now, or finished recently enough that receipts are still
 * landing? Decides the idle poll speed in wa_wq_drain_loop().
 *
 * Cached for a few seconds: it is asked on every idle pass, and the answer cannot meaningfully
 * change five times a second. Wrapped because a slower poll is a far better failure than a dead
 * drainer if the column list ever drifts.
 */
function wa_wq_is_active(): bool {
    global $conn;
    static $cached = null, $cachedAt = 0;
    if ($cached !== null && (time() - $cachedAt) < 5) return $cached;

    try {
        $r = $conn->query("SELECT 1 FROM wa_campaigns
                            WHERE status = 'running'
                               OR (completed_at IS NOT NULL
                                   AND completed_at >= DATE_SUB(NOW(), INTERVAL " . (int)WA_WEBHOOK_ACTIVE_WINDOW . " SECOND))
                            LIMIT 1");
        $cached = (bool)($r && $r->fetch_row());
    } catch (\Throwable $e) {
        $cached = false;
    }
    $cachedAt = time();
    return $cached;
}

function wa_wq_drain_loop(float $deadline): array {
    global $conn;
    $totals = ['claimed' => 0, 'events' => 0, 'applied' => 0, 'chunks' => 0, 'worstLag' => 0];

    /*
     * Recover anything a previous run died in the middle of.
     *
     * The claimed_at guard is essential, not tidiness: a drainer on the OTHER machine may be
     * working through its rows right now, and requeuing every 'processing' row would hand its
     * work to this process as well — the exact double-apply the claim token exists to prevent.
     * Ten minutes is far longer than any chunk can legitimately take and far shorter than anyone
     * would wait for a stuck receipt.
     */
    $conn->query("UPDATE wa_webhook_queue SET status='pending', claim_token=NULL
                   WHERE status='processing'
                     AND (claimed_at IS NULL OR claimed_at < DATE_SUB(NOW(), INTERVAL 10 MINUTE))
                     AND attempts < " . (int)WA_WEBHOOK_MAX_ATTEMPTS);

    while (microtime(true) < $deadline) {
        $round = wa_wq_drain_once(WA_WEBHOOK_CHUNK);
        if ($round['claimed'] === 0) {
            /*
             * Two idle speeds, because this loop runs on the monitoring box against a REMOTE
             * database and the fast one is not free: a 200 ms poll is five network round trips a
             * second, every second, forever — roughly 430,000 queries a day to discover that
             * nothing happened.
             *
             * The fast poll is what makes "delivered updates within a second" true, so it is kept
             * for exactly the window where anyone is watching a number move: a campaign sending,
             * or one that finished recently enough that receipts are still arriving. Outside that
             * window a two-second poll is still far faster than the cron minute it replaced, at a
             * tenth of the traffic.
             */
            usleep((wa_wq_is_active() ? WA_WEBHOOK_IDLE_POLL_MS : WA_WEBHOOK_QUIET_POLL_MS) * 1000);
            continue;
        }
        $totals['chunks']++;
        $totals['claimed'] += $round['claimed'];
        $totals['events']  += $round['events'];
        $totals['applied'] += $round['applied'];
        if ($round['lag'] !== null) $totals['worstLag'] = max($totals['worstLag'], (int)$round['lag']);
    }
    return $totals;
}

<?php
/**
 * /api/caller-iq/log_call.php  —  Caller IQ device ingest (no JWT: phones cannot log in)
 * ---------------------------------------------------------------------------
 * POST one call object, or { calls: [ … ] } for a batch of up to 500.
 * Point the app's "CRM Call Log Endpoint URL" (gear → PIN) at this file.
 *
 * Status codes are chosen for Android WorkManager, which retries every non-2xx:
 *   200  stored, OR the payload is unusable (retrying would never fix it)
 *   401  wrong ingest key (only when CALLER_IQ_INGEST_KEY is set)
 *   503  our failure (database) — the phone keeps the call and tries again
 * ---------------------------------------------------------------------------
 */
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../middleware/auth.php';
require_once __DIR__ . '/ciq_lib.php';

/* PHP 8.1+ mysqli throws; this file checks return values instead. */
mysqli_report(MYSQLI_REPORT_OFF);
set_exception_handler(function (Throwable $e) {
    error_log('[caller-iq ingest] ' . $e->getMessage() . ' @ ' . $e->getFile() . ':' . $e->getLine());
    api_error('Temporary failure, retry later', 503);
});

require_method('POST');

$in = get_json_input();

if (CALLER_IQ_INGEST_KEY !== '') {
    $sent = $_SERVER['HTTP_X_CALLIQ_KEY'] ?? ($in['key'] ?? '');
    if (!hash_equals(CALLER_IQ_INGEST_KEY, (string)$sent)) api_error('Invalid ingest key', 401);
}

if (!$in) api_success(['received' => 0, 'saved' => 0], 'Empty payload ignored');

$calls = (isset($in['calls']) && is_array($in['calls'])) ? array_values($in['calls']) : [$in];
if (count($calls) > 500) api_error('At most 500 calls per request', 413);

ciq_ensure_schema($conn);

$ip = get_client_ip();
$saved = 0; $skipped = []; $retry = false;
foreach ($calls as $i => $c) {
    if (!is_array($c)) { $skipped[] = ['index' => $i, 'reason' => 'not an object']; continue; }
    $r = ciq_ingest_call($conn, $c, $ip);
    if ($r['ok']) { $saved++; continue; }
    if ($r['retry']) { $retry = true; error_log('[caller-iq ingest] ' . $r['reason']); }
    $skipped[] = ['index' => $i, 'reason' => $r['reason']];
}

if ($retry && $saved === 0) api_error('Could not store the call, retry later', 503);

api_success(['received' => count($calls), 'saved' => $saved, 'skipped' => $skipped], $saved ? 'Stored' : 'Nothing stored');

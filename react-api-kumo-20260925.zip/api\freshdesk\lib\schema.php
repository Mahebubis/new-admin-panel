<?php
/*
 * /api/freshdesk/lib/schema.php
 *
 * fd_ensure_schema() -- idempotent CREATE TABLE IF NOT EXISTS + additive column
 * migrations for the 8 tables backing the helpdesk. Called at the top of every
 * entrypoint, exactly like campaigns_ensure_schema().
 *
 * Why on every request: CREATE TABLE IF NOT EXISTS and SHOW COLUMNS are
 * metadata-only and cheap, and this is what lets a column added in a later
 * release actually appear on a server whose tables already exist. Do not
 * "optimise" it away behind a flag file -- that is how a new column ships to
 * production and silently never gets created.
 *
 * All eight tables live in istudio_cit alongside the campaign tables.
 */

function fd_add_column_if_missing($table, $column, $definition) {
    global $conn;
    try {
        $r = @$conn->query("SHOW COLUMNS FROM `$table` LIKE '" . $conn->real_escape_string($column) . "'");
        if ($r && $r->num_rows === 0) {
            @$conn->query("ALTER TABLE `$table` ADD COLUMN $definition");
        }
    } catch (Throwable $e) { /* table missing entirely -- the CREATE above handles it */ }
}

function fd_add_index_if_missing($table, $indexName, $definition) {
    global $conn;
    try {
        $r = @$conn->query("SHOW INDEX FROM `$table` WHERE Key_name = '" . $conn->real_escape_string($indexName) . "'");
        if ($r && $r->num_rows === 0) {
            @$conn->query("ALTER TABLE `$table` ADD $definition");
        }
    } catch (Throwable $e) { /* ignore */ }
}

function fd_ensure_schema() {
    global $conn;
    if (!$conn) return;

    $start = (int)(defined('FD_TICKET_NUMBER_START') ? FD_TICKET_NUMBER_START : 336000);

    /* ---------------------------------------------------------- tickets --- */
    /*
     * id IS the ticket number shown to humans -- AUTO_INCREMENT seeded at
     * FD_TICKET_NUMBER_START so the very first real ticket is #336000 rather
     * than #1. There is deliberately no separate ticket_no column: two
     * identifiers for one row is how "#336270 not found" bugs are born.
     */
    @$conn->query("CREATE TABLE IF NOT EXISTS fd_tickets (
        id                  BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
        subject             VARCHAR(998) NOT NULL DEFAULT '',
        base_subject        VARCHAR(500) NOT NULL DEFAULT '',
        requester_name      VARCHAR(191) NOT NULL DEFAULT '',
        requester_email     VARCHAR(191) NOT NULL DEFAULT '',
        requester_phone     VARCHAR(64)  DEFAULT NULL,
        contact_id          BIGINT UNSIGNED DEFAULT NULL,

        status              VARCHAR(32) NOT NULL DEFAULT 'New',
        priority            VARCHAR(16) NOT NULL DEFAULT 'Medium',
        source              VARCHAR(16) NOT NULL DEFAULT 'Email',
        category            VARCHAR(64) DEFAULT NULL,
        department          VARCHAR(64) DEFAULT NULL,
        ticket_type         VARCHAR(64) DEFAULT NULL,

        agent_user_id       BIGINT UNSIGNED DEFAULT NULL,
        agent_name          VARCHAR(128) NOT NULL DEFAULT 'Unassigned',

        tags                TEXT DEFAULT NULL,

        is_spam             TINYINT(1) NOT NULL DEFAULT 0,
        is_trash            TINYINT(1) NOT NULL DEFAULT 0,
        is_undelivered      TINYINT(1) NOT NULL DEFAULT 0,
        raised_by_agent     TINYINT(1) NOT NULL DEFAULT 0,
        merged_into         BIGINT UNSIGNED DEFAULT NULL,

        response_status     VARCHAR(32) NOT NULL DEFAULT 'Awaiting reply',
        unread_count        INT NOT NULL DEFAULT 0,
        customer_replied    TINYINT(1) NOT NULL DEFAULT 0,

        first_response_at   DATETIME DEFAULT NULL,
        first_response_due  DATETIME DEFAULT NULL,
        resolution_due      DATETIME DEFAULT NULL,
        resolved_at         DATETIME DEFAULT NULL,
        closed_at           DATETIME DEFAULT NULL,
        sla_status          VARCHAR(16) NOT NULL DEFAULT 'On track',
        sla_breached        TINYINT(1) NOT NULL DEFAULT 0,

        last_message_at     DATETIME DEFAULT NULL,
        last_customer_at    DATETIME DEFAULT NULL,
        last_agent_at       DATETIME DEFAULT NULL,
        message_count       INT NOT NULL DEFAULT 0,
        attachment_count    INT NOT NULL DEFAULT 0,

        thread_key          VARCHAR(191) DEFAULT NULL,
        student_context     TEXT DEFAULT NULL,

        created_at          DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at          DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

        INDEX idx_status      (status),
        INDEX idx_email       (requester_email),
        INDEX idx_thread      (thread_key),
        INDEX idx_updated     (updated_at),
        INDEX idx_last_msg    (last_message_at),
        INDEX idx_flags       (is_spam, is_trash),
        INDEX idx_agent       (agent_user_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=$start");

    // Seed the counter on an existing-but-empty table (CREATE ... AUTO_INCREMENT
    // is a no-op when the table already exists from an earlier release).
    try {
        $c = @$conn->query("SELECT COUNT(*) AS c FROM fd_tickets");
        if ($c && (int)$c->fetch_assoc()['c'] === 0) {
            @$conn->query("ALTER TABLE fd_tickets AUTO_INCREMENT = $start");
        }
    } catch (Throwable $e) {}

    /* --------------------------------------------------------- messages --- */
    /*
     * message_id carries a UNIQUE key and it is the whole anti-duplicate story:
     * IMAP hands the same message back whenever UIDVALIDITY rolls over, the
     * mailbox is rebuilt, or two sync runs overlap. An INSERT IGNORE against
     * this key turns all three into a harmless no-op instead of the same
     * customer email appearing in the thread four times.
     *
     * uid_key does the same job for messages whose sender omitted a Message-ID
     * (rare, but legal): it is mailbox+uidvalidity+uid, unique per mailbox.
     */
    @$conn->query("CREATE TABLE IF NOT EXISTS fd_messages (
        id                BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
        ticket_id         BIGINT UNSIGNED NOT NULL,
        direction         ENUM('inbound','outbound','note') NOT NULL DEFAULT 'inbound',
        msg_type          VARCHAR(16) NOT NULL DEFAULT 'reply',

        from_name         VARCHAR(191) DEFAULT NULL,
        from_email        VARCHAR(191) DEFAULT NULL,
        to_emails         TEXT DEFAULT NULL,
        cc_emails         TEXT DEFAULT NULL,
        bcc_emails        TEXT DEFAULT NULL,
        subject           VARCHAR(998) DEFAULT NULL,

        body_html         LONGTEXT DEFAULT NULL,
        body_text         LONGTEXT DEFAULT NULL,
        snippet           VARCHAR(500) DEFAULT NULL,

        message_id        VARCHAR(255) DEFAULT NULL,
        in_reply_to       VARCHAR(255) DEFAULT NULL,
        references_hdr    TEXT DEFAULT NULL,

        mailbox           VARCHAR(128) DEFAULT NULL,
        imap_uid          BIGINT UNSIGNED DEFAULT NULL,
        imap_uidvalidity  BIGINT UNSIGNED DEFAULT NULL,
        uid_key           VARCHAR(191) DEFAULT NULL,

        has_attachments   TINYINT(1) NOT NULL DEFAULT 0,
        attachment_count  INT NOT NULL DEFAULT 0,

        delivery_status   ENUM('received','queued','sent','failed','bounced') NOT NULL DEFAULT 'received',
        delivery_error    TEXT DEFAULT NULL,
        retry_count       INT NOT NULL DEFAULT 0,

        sent_by_user_id   BIGINT UNSIGNED DEFAULT NULL,
        sent_by_name      VARCHAR(128) DEFAULT NULL,

        message_date      DATETIME DEFAULT NULL,
        created_at        DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,

        raw_size          INT NOT NULL DEFAULT 0,
        is_auto_reply     TINYINT(1) NOT NULL DEFAULT 0,

        UNIQUE KEY uniq_message_id (message_id),
        UNIQUE KEY uniq_uid_key    (uid_key),
        INDEX idx_ticket     (ticket_id, id),
        INDEX idx_created    (created_at),
        INDEX idx_inreplyto  (in_reply_to),
        INDEX idx_delivery   (delivery_status)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    /* ------------------------------------------------------ attachments --- */
    @$conn->query("CREATE TABLE IF NOT EXISTS fd_attachments (
        id             BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
        ticket_id      BIGINT UNSIGNED NOT NULL,
        message_id     BIGINT UNSIGNED DEFAULT NULL,
        filename       VARCHAR(255) NOT NULL,
        stored_name    VARCHAR(255) NOT NULL,
        rel_path       VARCHAR(500) NOT NULL,
        mime_type      VARCHAR(128) DEFAULT NULL,
        size_bytes     BIGINT NOT NULL DEFAULT 0,
        -- Files live in S3; the row keeps the key + public URL and nothing else.
        -- 'local' is the degraded fallback used only when S3 is unreachable
        -- (see lib/Storage.php), which is why rel_path still exists.
        storage        ENUM('s3','local') NOT NULL DEFAULT 's3',
        s3_key         VARCHAR(500) DEFAULT NULL,
        s3_url         VARCHAR(1000) DEFAULT NULL,
        content_id     VARCHAR(255) DEFAULT NULL,
        is_inline      TINYINT(1) NOT NULL DEFAULT 0,
        checksum       VARCHAR(64) DEFAULT NULL,
        direction      ENUM('inbound','outbound') NOT NULL DEFAULT 'inbound',
        uploaded_by    BIGINT UNSIGNED DEFAULT NULL,
        created_at     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_ticket  (ticket_id),
        INDEX idx_message (message_id),
        INDEX idx_cid     (content_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    /* --------------------------------------------------------- contacts --- */
    @$conn->query("CREATE TABLE IF NOT EXISTS fd_contacts (
        id              BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
        email           VARCHAR(191) NOT NULL,
        name            VARCHAR(191) DEFAULT NULL,
        phone           VARCHAR(64) DEFAULT NULL,
        user_id         BIGINT UNSIGNED DEFAULT NULL,
        college         VARCHAR(191) DEFAULT NULL,
        program         VARCHAR(191) DEFAULT NULL,
        enroll_id       VARCHAR(64) DEFAULT NULL,
        is_registered   TINYINT(1) NOT NULL DEFAULT 0,
        is_blocked      TINYINT(1) NOT NULL DEFAULT 0,
        tickets_count   INT NOT NULL DEFAULT 0,
        first_seen_at   DATETIME DEFAULT NULL,
        last_seen_at    DATETIME DEFAULT NULL,
        notes           TEXT DEFAULT NULL,
        meta            TEXT DEFAULT NULL,
        created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        UNIQUE KEY uniq_email (email),
        INDEX idx_user (user_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    /* ---------------------------------------------------- mailbox state --- */
    /*
     * One row per watched folder. last_uid is the sync watermark; uidvalidity
     * is stored beside it because IMAP guarantees UIDs are only comparable
     * within one UIDVALIDITY generation -- when the server changes it (mailbox
     * rebuilt/restored), every stored UID becomes meaningless and the worker
     * must re-baseline instead of trusting last_uid. Getting this wrong is what
     * makes a desk either re-import the whole mailbox or go permanently deaf.
     *
     * lock_token/lock_at give the worker a mutex so an every-minute cron and an
     * agent hitting "Refresh" cannot double-import the same UID range.
     */
    @$conn->query("CREATE TABLE IF NOT EXISTS fd_mailbox_state (
        id                BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
        mailbox           VARCHAR(128) NOT NULL,
        uidvalidity       BIGINT UNSIGNED DEFAULT NULL,
        last_uid          BIGINT UNSIGNED NOT NULL DEFAULT 0,
        last_sync_at      DATETIME DEFAULT NULL,
        last_success_at   DATETIME DEFAULT NULL,
        last_status       VARCHAR(32) NOT NULL DEFAULT 'idle',
        last_error        TEXT DEFAULT NULL,
        consecutive_fails INT NOT NULL DEFAULT 0,
        imported_total    BIGINT NOT NULL DEFAULT 0,
        lock_token        VARCHAR(64) DEFAULT NULL,
        lock_at           DATETIME DEFAULT NULL,
        UNIQUE KEY uniq_mailbox (mailbox)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    /* --------------------------------------------------------- activity --- */
    /*
     * Append-only audit trail AND the realtime replay log. Its AUTO_INCREMENT
     * id doubles as the polling cursor: the frontend asks "everything after id
     * N", which is what makes the no-Pusher fallback correct rather than
     * merely frequent -- a client that was offline for a minute still receives
     * every event it missed, in order, exactly once.
     */
    @$conn->query("CREATE TABLE IF NOT EXISTS fd_activity (
        id            BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
        ticket_id     BIGINT UNSIGNED DEFAULT NULL,
        message_id    BIGINT UNSIGNED DEFAULT NULL,
        event         VARCHAR(48) NOT NULL,
        actor_type    ENUM('customer','agent','system') NOT NULL DEFAULT 'system',
        actor_id      BIGINT UNSIGNED DEFAULT NULL,
        actor_name    VARCHAR(128) DEFAULT NULL,
        summary       VARCHAR(500) DEFAULT NULL,
        payload       TEXT DEFAULT NULL,
        created_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_ticket (ticket_id),
        INDEX idx_event  (event),
        INDEX idx_created (created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    /* --------------------------------------------------------- settings --- */
    @$conn->query("CREATE TABLE IF NOT EXISTS fd_settings (
        setting_key   VARCHAR(64) NOT NULL PRIMARY KEY,
        setting_value TEXT DEFAULT NULL,
        updated_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    /* -------------------------------------------------- canned responses --- */
    /*
     * One automation rule. Conditions and actions are JSON because their shape
     * is the rule's business, not the schema's -- a normalised conditions table
     * would need a migration every time a new operator is added.
     */
    @$conn->query("CREATE TABLE IF NOT EXISTS fd_automations (
        id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
        name        VARCHAR(191) NOT NULL,
        description TEXT DEFAULT NULL,
        event       VARCHAR(32) NOT NULL DEFAULT 'ticket_created',
        conditions  TEXT DEFAULT NULL,
        actions     TEXT DEFAULT NULL,
        is_active   TINYINT(1) NOT NULL DEFAULT 1,
        position    INT NOT NULL DEFAULT 0,
        runs        BIGINT NOT NULL DEFAULT 0,
        last_run_at DATETIME DEFAULT NULL,
        created_by  BIGINT UNSIGNED DEFAULT NULL,
        created_by_name VARCHAR(128) DEFAULT NULL,
        created_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        INDEX idx_event (event, is_active)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    /*
     * What each rule did, and the guard that stops a rule re-triggering itself:
     * a row here means "this rule has already handled this ticket".
     */
    @$conn->query("CREATE TABLE IF NOT EXISTS fd_automation_log (
        id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
        rule_id     BIGINT UNSIGNED NOT NULL,
        rule_name   VARCHAR(191) DEFAULT NULL,
        ticket_id   BIGINT UNSIGNED NOT NULL,
        event       VARCHAR(32) DEFAULT NULL,
        applied     TEXT DEFAULT NULL,
        skipped     TEXT DEFAULT NULL,
        created_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_rule_ticket (rule_id, ticket_id),
        INDEX idx_created (created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    /*
     * One person's notification.
     *
     * user_id is who it is FOR -- an admin_users.user_id. Read state lives on
     * the row rather than being derived from a "last seen" timestamp, because
     * marking one thing read must not silently mark the rest read too.
     */
    @$conn->query("CREATE TABLE IF NOT EXISTS fd_notifications (
        id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
        user_id     BIGINT UNSIGNED NOT NULL,
        kind        VARCHAR(32) NOT NULL,
        ticket_id   BIGINT UNSIGNED DEFAULT NULL,
        title       VARCHAR(255) NOT NULL,
        body        VARCHAR(500) DEFAULT NULL,
        actor_id    BIGINT UNSIGNED DEFAULT NULL,
        actor_name  VARCHAR(128) DEFAULT NULL,
        is_read     TINYINT(1) NOT NULL DEFAULT 0,
        read_at     DATETIME DEFAULT NULL,
        created_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_inbox (user_id, is_read, id),
        INDEX idx_ticket (ticket_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    @$conn->query("CREATE TABLE IF NOT EXISTS fd_canned_folders (
        id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
        name        VARCHAR(191) NOT NULL,
        created_by  BIGINT UNSIGNED DEFAULT NULL,
        created_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        UNIQUE KEY uniq_name (name)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    @$conn->query("CREATE TABLE IF NOT EXISTS fd_canned_responses (
        id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
        name        VARCHAR(191) NOT NULL,
        category    VARCHAR(64) DEFAULT NULL,
        body        LONGTEXT DEFAULT NULL,
        shortcut    VARCHAR(32) DEFAULT NULL,
        uses        INT NOT NULL DEFAULT 0,
        is_active   TINYINT(1) NOT NULL DEFAULT 1,
        created_by  BIGINT UNSIGNED DEFAULT NULL,
        created_by_name VARCHAR(128) DEFAULT NULL,
        created_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        INDEX idx_active (is_active)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    /* ------------------------------------------------ additive migrations --- */
    // Columns added after the first release go here, never by editing the
    // CREATE above (that only runs on servers that don't have the table yet).
    fd_add_column_if_missing('fd_tickets',  'ticket_type',    "ticket_type VARCHAR(64) DEFAULT NULL");
    fd_add_column_if_missing('fd_tickets',  'student_context', "student_context TEXT DEFAULT NULL");
    fd_add_column_if_missing('fd_tickets',  'merged_into',     "merged_into BIGINT UNSIGNED DEFAULT NULL");
    /* Canned responses live in folders now; the old free-text category becomes
       the folder name on first run (see the backfill below). */
    fd_add_column_if_missing('fd_canned_responses', 'folder_id', "folder_id BIGINT UNSIGNED DEFAULT NULL");

    /*
     * Whether a rule's conditions are ANDed or ORed. The builder has offered an
     * AND/OR switch since this screen was drawn; the engine reads this column so
     * the switch means something instead of being decoration.
     *
     * "kind" is which of the four module screens a rule belongs to. It is
     * derived from the rule's first action on save, and stored so the closure /
     * forwarding / notification tables can each list their own rules without
     * every screen having to re-interpret the actions JSON.
     */
    fd_add_column_if_missing('fd_automations', 'match_type', "match_type VARCHAR(3) NOT NULL DEFAULT 'all'");
    fd_add_column_if_missing('fd_automations', 'kind',       "kind VARCHAR(16) NOT NULL DEFAULT 'closure'");
    /* Read receipts. NULL last_read_at means nobody on the team has opened it. */
    fd_add_column_if_missing('fd_tickets',  'last_read_at',      "last_read_at DATETIME DEFAULT NULL");
    fd_add_column_if_missing('fd_tickets',  'last_read_by',      "last_read_by BIGINT UNSIGNED DEFAULT NULL");
    fd_add_column_if_missing('fd_tickets',  'last_read_by_name', "last_read_by_name VARCHAR(190) DEFAULT NULL");
    fd_add_column_if_missing('fd_messages', 'is_auto_reply',   "is_auto_reply TINYINT(1) NOT NULL DEFAULT 0");

    /*
     * Turn the old free-text categories into real folders, once.
     * Idempotent and cheap: after the first run every response already has a
     * folder_id and this SELECT returns nothing.
     */
    $catRows = @$conn->query("SELECT DISTINCT category FROM fd_canned_responses
                              WHERE folder_id IS NULL AND category IS NOT NULL AND category <> ''");
    if ($catRows) {
        while ($row = $catRows->fetch_assoc()) {
            $esc = $conn->real_escape_string($row['category']);
            @$conn->query("INSERT IGNORE INTO fd_canned_folders (name) VALUES ('$esc')");
            @$conn->query("UPDATE fd_canned_responses r
                           JOIN fd_canned_folders f ON f.name = r.category
                           SET r.folder_id = f.id
                           WHERE r.folder_id IS NULL AND r.category = '$esc'");
        }
    }
    /*
     * REPAIR: attachments wrongly filed as inline, once.
     *
     * MimeParser used to mark a part inline whenever it carried a Content-ID,
     * regardless of its Content-Disposition. Outlook and Exchange put a
     * Content-ID on every part they emit, so genuine attachments -- a CV, a
     * screenshot, a fee receipt -- were stored with is_inline = 1 and then went
     * missing from the UI entirely: the reader's file strip filters on
     * !inline, and attachment_count only counts is_inline = 0, so not even the
     * paperclip appeared. The files were in S3 and indexed the whole time.
     *
     * The parser is fixed, but that only helps mail that arrives from now on.
     * Everything already stored needs the same test applied retroactively: an
     * attachment is only really inline if the message body actually points at
     * its cid. LOCATE beats LIKE with CONCAT here because a filename or
     * content-id containing % or _ would otherwise become a wildcard.
     *
     * Guarded by a settings flag rather than a re-runnable condition because
     * this must not run on every request -- fd_ensure_schema() is called at the
     * top of every endpoint, and this touches two large tables.
     */
    if (fd_cfg('ATTACH_INLINE_REPAIRED', '') !== '1') {
        /*
         * "Referenced" has TWO spellings, and missing the second one would have
         * made this repair worse than the bug.
         *
         * fd_rewrite_inline_cids() rewrites cid:<id> in the stored body_html to
         * our own fd_attachments.php?action=view&id=<attachment id> as soon as
         * a message is ingested, precisely so embedded images render. So for a
         * genuine inline image the raw cid: is NOT in body_html any more --
         * testing only for cid: would flip every real embedded image to
         * is_inline = 0 and duplicate every signature logo into the file strip
         * of every ticket.
         *
         * A row is therefore left alone if the body points at it EITHER way,
         * and only demoted when neither appears. The &amp; variant is checked
         * because the rewritten URL sits inside an attribute that later
         * sanitising can escape.
         */
        @$conn->query(
            "UPDATE fd_attachments a
               JOIN fd_messages m ON m.id = a.message_id
                SET a.is_inline = 0
              WHERE a.is_inline = 1
                AND LOCATE(CONCAT('action=view&id=', a.id),     COALESCE(m.body_html, '')) = 0
                AND LOCATE(CONCAT('action=view&amp;id=', a.id), COALESCE(m.body_html, '')) = 0
                AND (COALESCE(a.content_id, '') = ''
                     OR LOCATE(CONCAT('cid:', a.content_id), COALESCE(m.body_html, '')) = 0)"
        );
        /* The counter is denormalised, so fixing the flag is only half of it --
           without this the paperclip and the "N attachments" heading stay at
           whatever the broken count said. */
        @$conn->query(
            "UPDATE fd_tickets t
                SET t.attachment_count =
                    (SELECT COUNT(*) FROM fd_attachments a
                      WHERE a.ticket_id = t.id AND a.is_inline = 0)
              WHERE EXISTS (SELECT 1 FROM fd_attachments a WHERE a.ticket_id = t.id)"
        );
        fd_cfg_set('ATTACH_INLINE_REPAIRED', '1');
    }

    fd_add_column_if_missing('fd_messages', 'retry_count',     "retry_count INT NOT NULL DEFAULT 0");
    fd_add_column_if_missing('fd_contacts', 'is_blocked',      "is_blocked TINYINT(1) NOT NULL DEFAULT 0");
    // S3 storage, added after the first release -- installs created before this
    // have rows with storage='local' and they keep working unchanged.
    fd_add_column_if_missing('fd_attachments', 'storage', "storage ENUM('s3','local') NOT NULL DEFAULT 's3'");
    fd_add_column_if_missing('fd_attachments', 's3_key',  "s3_key VARCHAR(500) DEFAULT NULL");
    fd_add_column_if_missing('fd_attachments', 's3_url',  "s3_url VARCHAR(1000) DEFAULT NULL");
    // rel_path was NOT NULL when every file was local; S3 rows leave it empty.
    try { @$GLOBALS['conn']->query("ALTER TABLE fd_attachments MODIFY rel_path VARCHAR(500) NULL DEFAULT NULL"); } catch (Throwable $e) {}
    try { @$GLOBALS['conn']->query("ALTER TABLE fd_attachments MODIFY stored_name VARCHAR(255) NULL DEFAULT NULL"); } catch (Throwable $e) {}

    /* --------------------------------------------------------- backfill --- */
    /*
     * fd_backfill -- the DOWNWARD sync watermark. One row per mailbox.
     *
     * fd_mailbox_state.last_uid only ever moves forward: the worker baselines a
     * new mailbox with the last SYNC_INITIAL_DAYS of mail and then imports what
     * arrives after it. Everything OLDER than that baseline sits in the mailbox
     * and was never read. This table is the cursor that walks the other way.
     *
     * It is a separate table rather than more columns on fd_mailbox_state so the
     * two cursors can never be confused for one another, and so the backfill has
     * its OWN lock -- a backfill that will run for hours must never stop new
     * mail from arriving.
     *
     * cursor_uid walks DOWNWARD: each batch takes UIDs strictly below it. It is
     * committed after every batch, so a killed worker resumes where it stopped
     * and the worst case is re-fetching one batch, which the UNIQUE keys on
     * fd_messages absorb.
     *
     * uidvalidity is stored because the cursor is meaningless without it: if the
     * server rebuilds the mailbox mid-run, every remaining UID refers to a
     * different message and the run must stop rather than import nonsense.
     */
    @$conn->query("CREATE TABLE IF NOT EXISTS fd_backfill (
        id              BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
        mailbox         VARCHAR(128) NOT NULL,
        until_date      DATE NOT NULL,
        uidvalidity     BIGINT UNSIGNED DEFAULT NULL,
        cursor_uid      BIGINT UNSIGNED DEFAULT NULL,
        floor_uid       BIGINT UNSIGNED NOT NULL DEFAULT 0,
        skip_auto       TINYINT(1) NOT NULL DEFAULT 0,
        status          VARCHAR(16) NOT NULL DEFAULT 'idle',
        total_in_scope  BIGINT NOT NULL DEFAULT 0,
        processed       BIGINT NOT NULL DEFAULT 0,
        imported        BIGINT NOT NULL DEFAULT 0,
        duplicates      BIGINT NOT NULL DEFAULT 0,
        skipped         BIGINT NOT NULL DEFAULT 0,
        errors          BIGINT NOT NULL DEFAULT 0,
        new_tickets     BIGINT NOT NULL DEFAULT 0,
        last_error      TEXT DEFAULT NULL,
        lock_token      VARCHAR(64) DEFAULT NULL,
        lock_at         DATETIME DEFAULT NULL,
        started_at      DATETIME DEFAULT NULL,
        updated_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        finished_at     DATETIME DEFAULT NULL,
        UNIQUE KEY uniq_mailbox (mailbox)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    /*
     * Which messages arrived through the backfill rather than live.
     *
     * Needed so an imported two-year-old email is never mistaken for one that
     * came in this morning -- by the dashboard, by SLA, or by a human reading
     * the thread.
     */
    // Added after fd_backfill shipped: installs created before it have the table
    // without this column, and the windowed walk needs it.
    fd_add_column_if_missing('fd_backfill', 'floor_uid', "floor_uid BIGINT UNSIGNED NOT NULL DEFAULT 0");
    // Whether this run excludes mailer-daemon bounces server-side. Per run, not
    // global: the same desk may want the noise on one import and not the next.
    fd_add_column_if_missing('fd_backfill', 'skip_auto', "skip_auto TINYINT(1) NOT NULL DEFAULT 0");

    fd_add_column_if_missing('fd_messages', 'is_backfilled', "is_backfilled TINYINT(1) NOT NULL DEFAULT 0");
    fd_add_column_if_missing('fd_tickets',  'is_archived',   "is_archived TINYINT(1) NOT NULL DEFAULT 0");
    fd_add_index_if_missing('fd_tickets', 'idx_archived', "INDEX idx_archived (is_archived)");

    fd_ensure_uploads_dir();
}

/**
 * Create the attachment store and make it inert.
 *
 * The .htaccess is not optional. Customers mail us .php files, and this
 * directory sits under the web root; without turning the PHP handler off, an
 * inbound attachment named invoice.php becomes remote code execution the
 * moment anyone guesses its URL. index.html blocks directory listing on hosts
 * that ignore Options -Indexes.
 */
function fd_ensure_uploads_dir() {
    $dir = FD_ATTACH_DIR;
    if (!is_dir($dir)) @mkdir($dir, 0755, true);
    if (!is_dir($dir)) {
        fd_log('error', 'Could not create attachments dir', array('dir' => $dir));
        return false;
    }
    $ht = $dir . '/.htaccess';
    if (!file_exists($ht)) {
        @file_put_contents($ht, implode("\n", array(
            '# Attachments are DATA, never code. Nothing here may ever execute.',
            'php_flag engine off',
            '<IfModule mod_php.c>',
            '  php_flag engine off',
            '</IfModule>',
            'RemoveHandler .php .phtml .php3 .php4 .php5 .php7 .php8 .pl .py .jsp .asp .cgi',
            'RemoveType .php .phtml .php3 .php4 .php5 .php7 .php8',
            'AddType text/plain .php .phtml .php3 .php4 .php5 .php7 .php8 .pl .py .cgi .asp .jsp .html .htm .shtml',
            'Options -Indexes -ExecCGI',
            '<IfModule mod_headers.c>',
            '  Header set X-Content-Type-Options "nosniff"',
            '  Header set Content-Disposition "attachment"',
            '</IfModule>',
        )) . "\n");
    }
    $idx = $dir . '/index.html';
    if (!file_exists($idx)) @file_put_contents($idx, '');
    return true;
}

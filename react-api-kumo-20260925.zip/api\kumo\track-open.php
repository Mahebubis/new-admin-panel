<?php
/*
 * Open pixel. Public by design (no JWT).
 *
 * Serves the 1x1 GIF FIRST, flushes, and only then touches the database, so a
 * slow query can never delay the reader's mail client. Mirrors
 * campaigns/track-open.php.
 */
ini_set('display_errors', 0);
error_reporting(0);

$gif = base64_decode('R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7');
header('Content-Type: image/gif');
header('Content-Length: ' . strlen($gif));
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
echo $gif;

if (function_exists('fastcgi_finish_request')) { fastcgi_finish_request(); }
else { @ob_end_flush(); @flush(); }

$token = (string)($_GET['t'] ?? '');
if ($token === '') exit;

try {
    require_once __DIR__ . '/../../config/database.php';
    require_once __DIR__ . '/lib/config.php';
    require_once __DIR__ . '/lib/schema.php';
    require_once __DIR__ . '/lib/Stats.php';
    require_once __DIR__ . '/lib/Mailer.php';
    kumo_ensure_schema();

    $tok = kumo_token_verify($token);
    if (!$tok || $tok['kind'] !== 'o') exit;

    $rid = $conn->real_escape_string($tok['rid']);
    $r = $conn->query("SELECT * FROM kumo_campaign_recipients WHERE rid='$rid' LIMIT 1");
    $rcpt = $r ? $r->fetch_assoc() : null;
    if (!$rcpt) exit;

    $ua = substr((string)($_SERVER['HTTP_USER_AGENT'] ?? ''), 0, 480);
    $ip = (string)($_SERVER['HTTP_X_FORWARDED_FOR'] ?? $_SERVER['REMOTE_ADDR'] ?? '');
    $ip = trim(explode(',', $ip)[0]);

    /* Apple Mail Privacy Protection and security scanners pre-fetch images.
       They are still logged, but not counted, so the open rate stays honest. */
    $bot = (stripos($ua, 'GoogleImageProxy') !== false && (int)$rcpt['open_count'] === 0 && strtotime((string)$rcpt['sent_at']) > time() - 5)
        || stripos($ua, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605') !== false && stripos($ua, 'Safari') === false;

    $first = ($rcpt['opened_at'] === null);
    $conn->query("UPDATE kumo_campaign_recipients SET open_count=open_count+1, opened_at=COALESCE(opened_at, NOW()) WHERE id=" . (int)$rcpt['id']);
    $conn->query(sprintf(
        "INSERT INTO kumo_campaign_events (campaign_id, recipient_id, rid, ip_id, type, provider, ip_address, user_agent, meta, created_at)
         VALUES (%d, %d, '%s', %s, 'open', '%s', '%s', '%s', '%s', NOW())",
        (int)$rcpt['campaign_id'], (int)$rcpt['id'], $rid,
        $rcpt['ip_id'] ? (int)$rcpt['ip_id'] : 'NULL',
        $conn->real_escape_string((string)$rcpt['provider']),
        $conn->real_escape_string($ip), $conn->real_escape_string($ua),
        $conn->real_escape_string(json_encode(['bot' => $bot]))
    ));

    if (!$bot) {
        $conn->query("UPDATE kumo_campaigns SET open_count=open_count+1" . ($first ? ", unique_open_count=unique_open_count+1" : "") . " WHERE id=" . (int)$rcpt['campaign_id']);
        kumo_stats_bump((int)$rcpt['ip_id'], (string)$rcpt['provider'], ['opens' => 1]);
        $conn->query("UPDATE kumo_contacts SET last_open_at=NOW(), engagement='hot' WHERE email='" . $conn->real_escape_string((string)$rcpt['email']) . "'");
    }
} catch (\Throwable $e) {
    error_log('kumo track-open: ' . $e->getMessage());
}

<?php
/*
 * /api/campaigns/messaging_analytics.php — send analytics across BOTH channels and BOTH engines.
 *
 * Four streams, one vocabulary:
 *
 *   stream           table                        provider comes from
 *   email_campaign   email_campaign_recipients    email_campaigns.esp_transport
 *   wa_campaign      wa_campaign_recipients       wa_campaigns.send_provider → wa_senders.provider
 *   email_journey    journey_messages (email)     journey_messages.provider
 *   wa_journey       journey_messages (whatsapp)  journey_messages.provider
 *   email_support    fd_messages (outbound)       'smtp' — Freshdesk replies sent over SMTP from contact@internshipstudio.com
 *   email_smtp       smtp_mail_log                'smtp' — refund / project emails from refunds/list.php (logged since
 *                                                 lib/SmtpMailLog.php was deployed; nothing before that was recorded)
 *
 * The Freshdesk stream only knows whether SMTP accepted the message (sent / failed / bounced): there
 * is no delivery receipt, open pixel or tracked link on a support reply, so those stay 0. Its
 * "sources" are the agents who sent the replies (sent_by_user_id; 0 = automated).
 *
 * Every metric is counted on the MESSAGE COHORT of the range: a message belongs to the day it was
 * sent (or, when it never went out, the day it failed / was suppressed), and its delivered /
 * opened / clicked flags are whatever has happened to it since. So "Today: 1,000 sent, 900
 * delivered" means 900 of today's 1,000. Conversions are the exception and are dated by when the
 * conversion happened — that is the only date a conversion has.
 *
 *   metric      email                          whatsapp
 *   attempted   every processed row            every processed row
 *   sent        accepted by the ESP            accepted by Meta / Netcore
 *   delivered   ESP delivery receipt           delivery receipt
 *   opened      open pixel / ESP open          read receipt
 *   clicked     tracked link click             tracked link / button tap
 *   failed      rejected at send               rejected at send or by WhatsApp
 *   bounced     hard/soft bounce               — (0)
 *   skipped     journey suppression            campaign skip (dedup/opt-out) + journey suppression
 *
 * SPEED
 * None of these tables index the send date, and adding indexes to live worker tables is not this
 * file's call. Instead, each table's AUTO_INCREMENT id grows with its queued_at, so a ~17-step
 * binary search on the primary key finds the first id that can possibly belong to the range
 * (with a 7-day margin for scheduled/held sends) and every query is then a PK range scan. "Today"
 * reads today's rows, not the whole table.
 *
 * Every action also takes &from_time &to_time (HH:MM[:SS]) and &provider=sendgrid,elasticemail,ses,meta,netcore.
 *
 * action=overview  &from &to [&include_test]   → totals, streams, providers, senders, series, sources
 * action=failures  &from &to                   → top failure reasons per stream/provider
 * action=source    &kind &channel &id &from &to→ one campaign/journey: series, steps, reasons
 * action=people    &kind &channel &id &from &to [&node_id &status &search &page &per_page]
 */
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../middleware/auth.php';

// PHP 8.1+: make mysqli return false instead of throwing, so every guard below is reachable.
mysqli_report(MYSQLI_REPORT_OFF);
set_exception_handler(function ($e) { api_error('Analytics failed: ' . $e->getMessage(), 500); });

$jwt = require_jwt();
require_permission('netcore_analytics', $jwt);

$T0 = microtime(true);

function ma_in($k, $d = null) { $v = $_REQUEST[$k] ?? null; return ($v === null || $v === '') ? $d : $v; }

function ma_table_exists(string $t): bool {
    global $conn;
    static $c = [];
    if (isset($c[$t])) return $c[$t];
    $r = $conn->query("SHOW TABLES LIKE '" . $conn->real_escape_string($t) . "'");
    return $c[$t] = (bool)($r && $r->num_rows > 0);
}

function ma_rows(string $sql): array {
    global $conn;
    $r = $conn->query($sql);
    if (!$r) throw new RuntimeException($conn->error);
    $out = [];
    while ($x = $r->fetch_assoc()) $out[] = $x;
    return $out;
}

/* ── Range ─────────────────────────────────────────────────────────────── */

$from = (string)ma_in('from', date('Y-m-d'));
$to   = (string)ma_in('to', $from);
if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $from) || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $to)) api_error('from/to must be YYYY-MM-DD');
/* Optional time of day on each end — "10:05 to 10:45" — defaulting to the whole of both days. */
function ma_hms($v, string $def): string {
    $v = trim((string)$v);
    if (!preg_match('/^(\d{1,2}):(\d{2})(?::(\d{2}))?$/', $v, $m)) return $def;
    [$h, $i, $sec] = [(int)$m[1], (int)$m[2], (int)($m[3] ?? 0)];
    if ($h > 23 || $i > 59 || $sec > 59) return $def;
    return sprintf('%02d:%02d:%02d', $h, $i, $sec);
}
$FROM = "$from " . ma_hms(ma_in('from_time'), '00:00:00');
$TO   = "$to " . ma_hms(ma_in('to_time'), '23:59:59');
if ($TO < $FROM) [$FROM, $TO] = [$TO, $FROM];
/*
 * &all=1 — "All time". The start is pulled forward to the first day any sending table has data,
 * so the chart does not open on years of empty buckets. Each lookup is a first-row or indexed MIN.
 */
if (ma_in('all') === '1') {
    $firsts = [];
    foreach ([
        "SELECT queued_at FROM email_campaign_recipients ORDER BY id LIMIT 1" => 'email_campaign_recipients',
        "SELECT queued_at FROM wa_campaign_recipients ORDER BY id LIMIT 1"    => 'wa_campaign_recipients',
        "SELECT queued_at FROM journey_messages ORDER BY id LIMIT 1"          => 'journey_messages',
        "SELECT MIN(created_at) FROM fd_messages"                             => 'fd_messages',
        "SELECT MIN(created_at) FROM smtp_mail_log"                           => 'smtp_mail_log',
        "SELECT MIN(attributed_at) FROM campaign_attributions"                => 'campaign_attributions',
    ] as $sql => $table) {
        if (!ma_table_exists($table)) continue;
        $r = $conn->query($sql);
        $v = $r ? ($r->fetch_row()[0] ?? null) : null;
        if ($v) $firsts[] = substr((string)$v, 0, 10);
    }
    if ($firsts) { $first = min($firsts); if ($first > $from) { $from = $first; $FROM = "$first 00:00:00"; } }
}
[$from, $to] = [substr($FROM, 0, 10), substr($TO, 0, 10)];
$days = (int)round((strtotime($to) - strtotime($from)) / 86400) + 1;
if ($days > 3700) api_error('Pick a range of 10 years or less');
$SPAN = strtotime($TO) - strtotime($FROM);
// Minutes for ≤3 hours, hours up to two days, days up to six months, months beyond that.
$GRAN = $SPAN <= 3 * 3600 ? 'minute' : ($days <= 2 ? 'hour' : ($days <= 186 ? 'day' : 'month'));
$INCLUDE_TEST = ma_in('include_test') === '1';

function ma_bucket(string $col): string {
    global $GRAN;
    if ($GRAN === 'minute') return "DATE_FORMAT($col, '%Y-%m-%d %H:%i')";
    if ($GRAN === 'month')  return "DATE_FORMAT($col, '%Y-%m')";
    return $GRAN === 'hour' ? "DATE_FORMAT($col, '%Y-%m-%d %H:00')" : "DATE_FORMAT($col, '%Y-%m-%d')";
}

/**
 * First id of $table that can belong to the range. queued_at tracks insertion order, so a binary
 * search over the PK finds it in ~17 single-row index lookups.
 */
function ma_min_id(string $table): int {
    global $conn, $FROM;
    static $cache = [];
    if (isset($cache[$table])) return $cache[$table];
    $floor = date('Y-m-d H:i:s', strtotime(substr($FROM, 0, 10)) - 7 * 86400);
    $r = $conn->query("SELECT MIN(id) lo, MAX(id) hi FROM `$table`");
    $x = $r ? $r->fetch_assoc() : null;
    $lo = (int)($x['lo'] ?? 0); $hi = (int)($x['hi'] ?? 0);
    if ($hi <= 0) return $cache[$table] = 0;
    while ($lo < $hi) {
        $mid = intdiv($lo + $hi, 2);
        $q = $conn->query("SELECT queued_at FROM `$table` WHERE id >= $mid ORDER BY id LIMIT 1");
        $row = $q ? $q->fetch_row() : null;
        if ($row && $row[0] !== null && $row[0] < $floor) $lo = $mid + 1; else $hi = $mid;
    }
    return $cache[$table] = $lo;
}

/* ── Per-stream SQL fragments (alias r = recipient/message row) ─────────── */

const MA_EMAIL_DT = "COALESCE(r.sent_at, r.bounced_at, r.claimed_at, r.queued_at)";
const MA_WA_DT    = "COALESCE(r.sent_at, r.failed_at, r.claimed_at, r.queued_at)";
const MA_J_DT     = "COALESCE(r.sent_at, r.queued_at)";
const MA_FD_DT    = "COALESCE(r.message_date, r.created_at)";
// First recipient of a Freshdesk reply. to_emails is a JSON array written by the desk; string
// surgery rather than JSON_EXTRACT so one malformed row cannot fail the whole query.
const MA_FD_TO    = "TRIM(BOTH '\"' FROM TRIM(SUBSTRING_INDEX(REPLACE(REPLACE(COALESCE(r.to_emails, ''), '[', ''), ']', ''), ',', 1)))";

/** journey / support / transactional / campaign, from a stream key. */
function ma_kind(string $stream): string {
    if (str_ends_with($stream, '_journey')) return 'journey';
    if ($stream === 'email_support') return 'support';
    if ($stream === 'email_smtp') return 'transactional';
    return 'campaign';
}

/* Refund / project emails: a "source" is the email TYPE, keyed by a small fixed id. */
const MA_SMTP_PURPOSES = [
    1 => ['refund_processed', 'Refund processed emails'],
    2 => ['refund_rejected',  'Refund rejected emails'],
    3 => ['project_approved', 'Project approved emails'],
    4 => ['project_declined', 'Project declined emails'],
    9 => ['other',            'Other contact@ emails'],
];
function ma_smtp_sid_sql(): string {
    $c = "CASE r.purpose";
    foreach (MA_SMTP_PURPOSES as $id => [$key]) if ($id !== 9) $c .= " WHEN '$key' THEN $id";
    return "$c ELSE 9 END";
}
function ma_smtp_ok(): bool {
    $f = ma_providers();
    return ma_table_exists('smtp_mail_log') && (!$f || in_array('smtp', $f, true));
}
function ma_where_smtp(): string {
    global $FROM, $TO;
    return "r.created_at BETWEEN '$FROM' AND '$TO'";
}
function ma_smtp_metrics(): string {
    return "COUNT(*) attempted, SUM(r.status = 'sent') sent, 0 delivered, 0 opened, 0 clicked,
            SUM(r.status = 'failed') failed, 0 bounced, 0 skipped";
}
/** The Freshdesk stream exists here and the provider filter lets SMTP through. */
function ma_fd_ok(): bool {
    $f = ma_providers();
    return ma_table_exists('fd_messages') && (!$f || in_array('smtp', $f, true));
}
function ma_where_fd(): string {
    global $FROM, $TO;
    // created_at is indexed; the day of slack either side lets the exact test use the Date: header.
    $lo = date('Y-m-d H:i:s', strtotime($FROM) - 86400);
    $hi = date('Y-m-d H:i:s', strtotime($TO) + 86400);
    return "r.direction = 'outbound' AND r.delivery_status IN ('sent','failed','bounced')
            AND r.created_at BETWEEN '$lo' AND '$hi' AND " . MA_FD_DT . " BETWEEN '$FROM' AND '$TO'";
}
function ma_fd_metrics(): string {
    return "COUNT(*) attempted,
            SUM(r.delivery_status IN ('sent','bounced')) sent,
            0 delivered, 0 opened, 0 clicked,
            SUM(r.delivery_status = 'failed') failed,
            SUM(r.delivery_status = 'bounced') bounced,
            0 skipped";
}

function ma_email_metrics(): string {
    return "COUNT(*) attempted,
            SUM(r.status IN ('sent','bounced')) sent,
            SUM(r.delivered_at IS NOT NULL AND r.status = 'sent') delivered,
            SUM(r.opened_at IS NOT NULL) opened,
            SUM(r.first_clicked_at IS NOT NULL) clicked,
            SUM(r.status = 'failed') failed,
            SUM(r.status = 'bounced') bounced,
            0 skipped";
}
function ma_wa_metrics(): string {
    return "COUNT(*) attempted,
            SUM(r.sent_at IS NOT NULL AND r.status NOT IN ('failed','skipped')) sent,
            SUM((r.delivered_at IS NOT NULL OR r.status IN ('delivered','read')) AND r.status NOT IN ('failed','skipped')) delivered,
            SUM(r.read_at IS NOT NULL OR r.status = 'read') opened,
            SUM(r.first_clicked_at IS NOT NULL) clicked,
            SUM(r.status = 'failed') failed,
            0 bounced,
            SUM(r.status = 'skipped') skipped";
}
function ma_j_metrics(): string {
    return "COUNT(*) attempted,
            SUM(r.status = 'sent') sent,
            SUM(r.delivered_at IS NOT NULL AND r.status = 'sent') delivered,
            SUM(r.opened_at IS NOT NULL) opened,
            SUM(r.first_clicked_at IS NOT NULL) clicked,
            SUM(r.status = 'failed') failed,
            0 bounced,
            SUM(r.status = 'suppressed') skipped";
}

function ma_where_email(): string {
    global $FROM, $TO, $INCLUDE_TEST;
    $min = ma_min_id('email_campaign_recipients');
    return "r.id >= $min AND r.status IN ('sent','failed','bounced')" . ($INCLUDE_TEST ? '' : ' AND r.is_test = 0')
         . " AND " . MA_EMAIL_DT . " BETWEEN '$FROM' AND '$TO'";
}
function ma_where_wa(): string {
    global $FROM, $TO, $INCLUDE_TEST;
    $min = ma_min_id('wa_campaign_recipients');
    return "r.id >= $min AND r.status NOT IN ('pending','processing')" . ($INCLUDE_TEST ? '' : ' AND r.is_test = 0')
         . " AND " . MA_WA_DT . " BETWEEN '$FROM' AND '$TO'";
}
function ma_where_j(): string {
    global $FROM, $TO;
    $min = ma_min_id('journey_messages');
    return "r.id >= $min AND r.status <> 'queued' AND r.channel IN ('email','whatsapp')"
         . " AND " . MA_J_DT . " BETWEEN '$FROM' AND '$TO'";
}

const MA_KEYS = ['attempted', 'sent', 'delivered', 'opened', 'clicked', 'failed', 'bounced', 'skipped', 'conversions', 'revenue'];

function ma_zero(): array { return array_fill_keys(MA_KEYS, 0); }
function ma_add(array &$acc, array $row): void {
    foreach (MA_KEYS as $k) if (isset($row[$k])) $acc[$k] += ($k === 'revenue' ? (float)$row[$k] : (int)$row[$k]);
}

function ma_provider_label(string $channel, ?string $p): string {
    $p = ma_pkey($p);
    $map = ['sendgrid' => 'SendGrid', 'elasticemail' => 'Elastic Email', 'ses' => 'Amazon SES', 'mailwizz' => 'MailWizz',
            'meta' => 'Meta API', 'netcore' => 'Netcore API', 'smtp' => 'SMTP (contact@)'];
    if ($p === 'none') return 'Not sent (no provider)';
    return $map[$p] ?? ucfirst($p);
}

/** Canonical provider key. Journey rows written before Netcore/Meta were split say 'whatsapp' — that was Netcore. */
function ma_pkey(?string $p): string {
    $p = strtolower(trim((string)$p));
    return $p === '' ? 'none' : ($p === 'whatsapp' ? 'netcore' : $p);
}

/** The providers the request narrowed to (&provider=ses,meta), as canonical keys; [] means all. */
function ma_providers(): array {
    static $v = null;
    if ($v !== null) return $v;
    $v = [];
    foreach (explode(',', strtolower((string)ma_in('provider', ''))) as $p) {
        $p = trim($p);
        if (preg_match('/^[a-z]{2,20}$/', $p)) $v[] = $p;
    }
    return $v = array_values(array_unique($v));
}
function ma_provider_ok(?string $p): bool {
    $f = ma_providers();
    return !$f || in_array(ma_pkey($p), $f, true);
}
/** SQL guard for a provider expression, matching ma_pkey()'s mapping. */
function ma_provider_sql(string $expr): string {
    $f = ma_providers();
    if (!$f) return '';
    $vals = []; $parts = [];
    foreach ($f as $p) {
        if ($p === 'none') continue;
        $vals[] = "'$p'";
        if ($p === 'netcore') $vals[] = "'whatsapp'";
    }
    if ($vals) $parts[] = "LOWER($expr) IN (" . implode(',', $vals) . ')';
    if (in_array('none', $f, true)) $parts[] = "($expr IS NULL OR $expr = '')";
    return ' AND (' . implode(' OR ', $parts) . ')';
}

/** Step name from a journey graph: the builder's own label, else type · template. */
function ma_step_label(?array $graph, string $nodeId, string $channel): string {
    $n = $graph['nodes'][$nodeId] ?? null;
    if (!$n) return "Step $nodeId (removed)";
    $cfg = $n['cfg'] ?? [];
    $name = trim((string)($cfg['__label'] ?? ''));
    if ($name === '') $name = $channel === 'whatsapp' ? 'WhatsApp' : 'Email';
    $tpl = trim((string)($cfg['template'] ?? $cfg['subject'] ?? ''));
    return $tpl !== '' ? "$name · $tpl" : $name;
}

/* ── Conversions ───────────────────────────────────────────────────────── */

/**
 * Conversions as flat rows: [stream, sid, bk, prov, c, rev]. NOT narrowed by the provider filter —
 * the overview needs every provider's count for the provider strip and applies the filter itself.
 * A campaign conversion takes its campaign's provider; a journey one takes the message's.
 */
function ma_conversions(?int $onlyId = null, ?string $onlyStream = null): array {
    global $FROM, $TO;
    $out = [];
    $b = ma_bucket('ca.attributed_at');
    if (ma_table_exists('campaign_attributions')) {
        foreach (['email' => 'email_campaign', 'whatsapp' => 'wa_campaign'] as $medium => $stream) {
            if ($onlyStream && $onlyStream !== $stream) continue;
            $idw = $onlyId ? " AND ca.campaign_id = $onlyId" : '';
            $join = $medium === 'email'
                ? 'LEFT JOIN email_campaigns pc ON pc.id = ca.campaign_id'
                : 'LEFT JOIN wa_campaigns pc ON pc.id = ca.campaign_id LEFT JOIN wa_senders ps ON ps.id = pc.sender_id';
            $prov = $medium === 'email' ? 'pc.esp_transport' : 'COALESCE(pc.send_provider, ps.provider)';
            foreach (ma_rows("SELECT ca.campaign_id sid, $b bk, $prov prov, COUNT(*) c FROM campaign_attributions ca $join
                              WHERE ca.medium = '$medium' AND ca.attributed_at BETWEEN '$FROM' AND '$TO' $idw
                              GROUP BY 1, 2, 3") as $x) {
                $out[] = ['stream' => $stream, 'sid' => (int)$x['sid'], 'bk' => $x['bk'], 'prov' => $x['prov'], 'c' => (int)$x['c'], 'rev' => 0.0];
            }
        }
    }
    if (ma_table_exists('journey_conversions') && (!$onlyStream || str_ends_with($onlyStream, '_journey'))) {
        $b = ma_bucket('c.converted_at');
        $idw = $onlyId ? " AND c.journey_id = $onlyId" : '';
        foreach (ma_rows("SELECT c.journey_id sid, $b bk,
                                 COALESCE(m.channel, (SELECT m2.channel FROM journey_messages m2
                                                       WHERE m2.journey_id = c.journey_id AND m2.node_id = c.node_id LIMIT 1), 'email') ch,
                                 m.provider prov, COUNT(*) c, COALESCE(SUM(c.revenue), 0) rev
                          FROM journey_conversions c
                          LEFT JOIN journey_messages m ON m.id = c.message_id
                          WHERE c.is_control = 0 AND c.converted_at BETWEEN '$FROM' AND '$TO' $idw
                          GROUP BY 1, 2, 3, 4") as $x) {
            $stream = $x['ch'] === 'whatsapp' ? 'wa_journey' : 'email_journey';
            if ($onlyStream && $onlyStream !== $stream) continue;
            $out[] = ['stream' => $stream, 'sid' => (int)$x['sid'], 'bk' => $x['bk'], 'prov' => $x['prov'], 'c' => (int)$x['c'], 'rev' => (float)$x['rev']];
        }
    }
    return $out;
}

/* ── The grouped scans ─────────────────────────────────────────────────── */

/**
 * One row per (stream, source, provider, sender, bucket) with every metric.
 * $filter = ['stream' => ..., 'id' => ...] narrows to one source.
 */
function ma_scan(array $filter = []): array {
    $rows = [];
    $only = $filter['stream'] ?? null;
    $id   = isset($filter['id']) ? (int)$filter['id'] : null;
    $pf   = !empty($filter['providers']);

    if ((!$only || $only === 'email_campaign') && ma_table_exists('email_campaign_recipients')) {
        $b = ma_bucket(MA_EMAIL_DT);
        $idw = $id ? " AND r.campaign_id = $id" : '';
        foreach (ma_rows("SELECT r.campaign_id sid, c.esp_transport provider, '' sender, $b bk, " . ma_email_metrics() . "
                          FROM email_campaign_recipients r JOIN email_campaigns c ON c.id = r.campaign_id
                          WHERE " . ma_where_email() . " $idw" . ($pf ? ma_provider_sql('c.esp_transport') : '') . "
                          GROUP BY 1, 2, 4") as $x) { $x['stream'] = 'email_campaign'; $rows[] = $x; }
    }
    if ((!$only || $only === 'wa_campaign') && ma_table_exists('wa_campaign_recipients')) {
        $b = ma_bucket(MA_WA_DT);
        $idw = $id ? " AND r.campaign_id = $id" : '';
        foreach (ma_rows("SELECT r.campaign_id sid, COALESCE(c.send_provider, s.provider) provider,
                                 COALESCE(c.business_number, s.business_number, '') sender, $b bk, " . ma_wa_metrics() . "
                          FROM wa_campaign_recipients r JOIN wa_campaigns c ON c.id = r.campaign_id
                          LEFT JOIN wa_senders s ON s.id = c.sender_id
                          WHERE " . ma_where_wa() . " $idw" . ($pf ? ma_provider_sql('COALESCE(c.send_provider, s.provider)') : '') . "
                          GROUP BY 1, 2, 3, 4") as $x) { $x['stream'] = 'wa_campaign'; $rows[] = $x; }
    }
    if ((!$only || str_ends_with($only, '_journey')) && ma_table_exists('journey_messages')) {
        $b = ma_bucket(MA_J_DT);
        $idw = $id ? " AND r.journey_id = $id" : '';
        $chw = $only ? " AND r.channel = '" . ($only === 'wa_journey' ? 'whatsapp' : 'email') . "'" : '';
        foreach (ma_rows("SELECT r.journey_id sid, r.channel ch, r.provider provider, '' sender, $b bk, " . ma_j_metrics() . "
                          FROM journey_messages r
                          WHERE " . ma_where_j() . " $idw $chw" . ($pf ? ma_provider_sql('r.provider') : '') . "
                          GROUP BY 1, 2, 3, 5") as $x) {
            $x['stream'] = $x['ch'] === 'whatsapp' ? 'wa_journey' : 'email_journey'; $rows[] = $x;
        }
    }
    if ((!$only || $only === 'email_support') && (!$pf || ma_fd_ok()) && ma_table_exists('fd_messages')) {
        $b = ma_bucket(MA_FD_DT);
        $idw = ($only === 'email_support' && $id !== null) ? " AND COALESCE(r.sent_by_user_id, 0) = $id" : '';
        foreach (ma_rows("SELECT COALESCE(r.sent_by_user_id, 0) sid, 'smtp' provider, '' sender, $b bk, " . ma_fd_metrics() . "
                          FROM fd_messages r
                          WHERE " . ma_where_fd() . " $idw
                          GROUP BY 1, 4") as $x) { $x['stream'] = 'email_support'; $rows[] = $x; }
    }
    if ((!$only || $only === 'email_smtp') && (!$pf || ma_smtp_ok()) && ma_table_exists('smtp_mail_log')) {
        $b = ma_bucket('r.created_at');
        $sid = ma_smtp_sid_sql();
        $idw = ($only === 'email_smtp' && $id !== null) ? " AND ($sid) = $id" : '';
        foreach (ma_rows("SELECT $sid sid, 'smtp' provider, '' sender, $b bk, " . ma_smtp_metrics() . "
                          FROM smtp_mail_log r
                          WHERE " . ma_where_smtp() . " $idw
                          GROUP BY 1, 4") as $x) { $x['stream'] = 'email_smtp'; $rows[] = $x; }
    }
    return $rows;
}

/** Every bucket label in the range, so the chart has no gaps. */
function ma_all_buckets(): array {
    global $FROM, $TO, $GRAN;
    $out = [];
    $end = strtotime($TO);
    if ($GRAN === 'minute') {
        $end = min($end, time());
        for ($t = strtotime(substr($FROM, 0, 16) . ':00'); $t <= $end; $t += 60) $out[] = date('Y-m-d H:i', $t);
    } elseif ($GRAN === 'hour') {
        // Stop at the current hour: a flat line to midnight reads as "sending stopped".
        $end = min($end, strtotime(date('Y-m-d H:00:00')));
        for ($t = strtotime(substr($FROM, 0, 13) . ':00:00'); $t <= $end; $t += 3600) $out[] = date('Y-m-d H:00', $t);
    } elseif ($GRAN === 'month') {
        for ($t = strtotime(substr($FROM, 0, 7) . '-01'); $t <= $end; $t = strtotime('+1 month', $t)) $out[] = date('Y-m', $t);
    } else {
        for ($t = strtotime($FROM); $t <= $end; $t += 86400) $out[] = date('Y-m-d', $t);
    }
    return $out;
}

function ma_names(array $ids): array {
    // $ids: ['email_campaign' => [id...], 'wa_campaign' => [...], 'journey' => [...]]
    $out = ['email_campaign' => [], 'wa_campaign' => [], 'journey' => []];
    if (!empty($ids['email_campaign'])) foreach (ma_rows("SELECT id, name, status, subject info FROM email_campaigns WHERE id IN (" . implode(',', array_map('intval', array_unique($ids['email_campaign']))) . ")") as $x) $out['email_campaign'][(int)$x['id']] = $x;
    if (!empty($ids['wa_campaign']))    foreach (ma_rows("SELECT id, name, status, template_name info FROM wa_campaigns WHERE id IN (" . implode(',', array_map('intval', array_unique($ids['wa_campaign']))) . ")") as $x) $out['wa_campaign'][(int)$x['id']] = $x;
    if (!empty($ids['journey']))        foreach (ma_rows("SELECT id, name, status, '' info FROM journeys WHERE id IN (" . implode(',', array_map('intval', array_unique($ids['journey']))) . ")") as $x) $out['journey'][(int)$x['id']] = $x;
    if (!empty($ids['email_support'])) {
        $in = implode(',', array_map('intval', array_unique($ids['email_support'])));
        foreach (ma_rows("SELECT COALESCE(sent_by_user_id, 0) id, MAX(sent_by_name) agent FROM fd_messages
                          WHERE direction = 'outbound' AND COALESCE(sent_by_user_id, 0) IN ($in) GROUP BY 1") as $x) {
            $out['email_support'][(int)$x['id']] = ['name' => 'Freshdesk replies · ' . ($x['agent'] ?: ((int)$x['id'] ? 'Agent #' . $x['id'] : 'Automated')),
                                                    'status' => null, 'info' => 'contact@internshipstudio.com'];
        }
    }
    foreach (array_unique($ids['email_smtp'] ?? []) as $sid) {
        $out['email_smtp'][(int)$sid] = ['name' => MA_SMTP_PURPOSES[(int)$sid][1] ?? 'Other contact@ emails', 'status' => null, 'info' => 'contact@internshipstudio.com'];
    }
    return $out;
}

$action = (string)ma_in('action', 'overview');

/* ══ overview ══════════════════════════════════════════════════════════ */
if ($action === 'overview') {
    $scan = ma_scan();
    $conv = ma_conversions();
    $buckets = ma_all_buckets();

    $STREAMS = ['email_campaign', 'email_journey', 'wa_campaign', 'wa_journey', 'email_support', 'email_smtp'];
    $streams = []; foreach ($STREAMS as $s) $streams[$s] = ma_zero();
    $series = []; foreach ($buckets as $bk) { $series[$bk] = ['bucket' => $bk]; foreach ($STREAMS as $s) $series[$bk][$s] = ma_zero(); }
    $providers = []; $senders = []; $sources = []; $ids = ['email_campaign' => [], 'wa_campaign' => [], 'journey' => []];

    foreach ($scan as $x) {
        $s = $x['stream']; $sid = (int)$x['sid'];
        $channel = str_starts_with($s, 'wa_') ? 'whatsapp' : 'email';
        $pkey = ma_pkey($x['provider']);

        // The provider breakdown ignores the provider filter, so every provider's chip keeps its count.
        $pk = "$channel|$pkey|$s";
        if (!isset($providers[$pk])) $providers[$pk] = ['channel' => $channel, 'provider' => $pkey, 'label' => ma_provider_label($channel, $pkey), 'stream' => $s] + ma_zero();
        ma_add($providers[$pk], $x);
        if (!ma_provider_ok($x['provider'])) continue;

        ma_add($streams[$s], $x);
        if (!isset($series[$x['bk']])) { $series[$x['bk']] = ['bucket' => $x['bk']]; foreach ($STREAMS as $s2) $series[$x['bk']][$s2] = ma_zero(); }
        ma_add($series[$x['bk']][$s], $x);

        if ($channel === 'whatsapp' && $x['sender'] !== '') {
            $sk = $x['sender'] . '|' . $pkey;
            if (!isset($senders[$sk])) $senders[$sk] = ['number' => $x['sender'], 'provider' => $pkey, 'label' => ma_provider_label('whatsapp', $pkey)] + ma_zero();
            ma_add($senders[$sk], $x);
        }

        $key = "$s:$sid";
        if (!isset($sources[$key])) $sources[$key] = ['key' => $key, 'stream' => $s, 'kind' => ma_kind($s), 'channel' => $channel, 'id' => $sid, 'providers' => []] + ma_zero();
        ma_add($sources[$key], $x);
        $sources[$key]['providers'][ma_provider_label($channel, $x['provider'])] = true;
        $ids[str_ends_with($s, '_journey') ? 'journey' : $s][] = $sid;
    }

    // Conversions land on streams, series and sources (a source can convert on a day it sent nothing).
    foreach ($conv as $cv) {
        ['stream' => $s, 'sid' => $sid, 'bk' => $bk, 'c' => $c, 'rev' => $rev] = $cv;
        $channel = str_starts_with($s, 'wa_') ? 'whatsapp' : 'email';
        $pkey = ma_pkey($cv['prov']);
        $pk = "$channel|$pkey|$s";
        if (!isset($providers[$pk])) $providers[$pk] = ['channel' => $channel, 'provider' => $pkey, 'label' => ma_provider_label($channel, $pkey), 'stream' => $s] + ma_zero();
        $providers[$pk]['conversions'] += $c; $providers[$pk]['revenue'] += $rev;
        if (!ma_provider_ok($cv['prov'])) continue;

        $streams[$s]['conversions'] += $c; $streams[$s]['revenue'] += $rev;
        if (isset($series[$bk])) { $series[$bk][$s]['conversions'] += $c; $series[$bk][$s]['revenue'] += $rev; }
        $key = "$s:$sid";
        if (!isset($sources[$key])) {
            $sources[$key] = ['key' => $key, 'stream' => $s, 'kind' => ma_kind($s), 'channel' => $channel, 'id' => $sid, 'providers' => []] + ma_zero();
            $ids[str_ends_with($s, '_journey') ? 'journey' : $s][] = $sid;
        }
        $sources[$key]['conversions'] += $c; $sources[$key]['revenue'] += $rev;
    }

    $names = ma_names($ids);
    foreach ($sources as &$src) {
        $n = $names[$src['kind'] === 'journey' ? 'journey' : $src['stream']][$src['id']] ?? null;
        $src['name'] = $n['name'] ?? ('#' . $src['id'] . ' (deleted)');
        $src['status'] = $n['status'] ?? null;
        $src['info'] = $n['info'] ?? '';
        $src['providers'] = array_keys($src['providers']);
    }
    unset($src);

    $totals = ma_zero(); $byChannel = ['email' => ma_zero(), 'whatsapp' => ma_zero()];
    foreach ($streams as $s => $m) { ma_add($totals, $m); ma_add($byChannel[str_starts_with($s, 'wa_') ? 'whatsapp' : 'email'], $m); }

    $sources = array_values($sources);
    usort($sources, fn($a, $b) => [$b['sent'], $b['attempted']] <=> [$a['sent'], $a['attempted']]);
    $providers = array_values($providers);
    usort($providers, fn($a, $b) => $b['attempted'] <=> $a['attempted']);
    $senders = array_values($senders);
    usort($senders, fn($a, $b) => $b['attempted'] <=> $a['attempted']);
    ksort($series);

    api_success([
        'range'       => ['from' => $from, 'to' => $to, 'days' => $days, 'granularity' => $GRAN, 'from_at' => $FROM, 'to_at' => $TO],
        'totals'      => $totals,
        'by_channel'  => $byChannel,
        'streams'     => $streams,
        'providers'   => $providers,
        'senders'     => $senders,
        'series'      => array_values($series),
        'sources'     => $sources,
        'provider_filter' => ma_providers(),
        'generated_at'=> date('Y-m-d H:i:s'),
        'took_ms'     => (int)round((microtime(true) - $GLOBALS['T0']) * 1000),
    ]);
}

/* ══ failures ══════════════════════════════════════════════════════════ */
if ($action === 'failures') {
    $out = [];
    $trim = fn($col) => "LEFT(COALESCE(NULLIF(TRIM($col), ''), 'No reason recorded'), 160)";
    if (ma_table_exists('email_campaign_recipients'))
        foreach (ma_rows("SELECT 'email_campaign' stream, c.esp_transport provider, " . $trim('r.error_message') . " reason, COUNT(*) c
                          FROM email_campaign_recipients r JOIN email_campaigns c ON c.id = r.campaign_id
                          WHERE " . ma_where_email() . " AND r.status IN ('failed','bounced')" . ma_provider_sql('c.esp_transport') . "
                          GROUP BY 2, 3 ORDER BY c DESC LIMIT 25") as $x) $out[] = $x;
    if (ma_table_exists('wa_campaign_recipients'))
        foreach (ma_rows("SELECT 'wa_campaign' stream, COALESCE(c.send_provider, s.provider) provider,
                                 " . $trim("CONCAT_WS(' — ', NULLIF(r.error_code, ''), COALESCE(r.error_message, r.skip_reason))") . " reason,
                                 SUM(r.status = 'failed') c, SUM(r.status = 'skipped') sk
                          FROM wa_campaign_recipients r JOIN wa_campaigns c ON c.id = r.campaign_id
                          LEFT JOIN wa_senders s ON s.id = c.sender_id
                          WHERE " . ma_where_wa() . " AND r.status IN ('failed','skipped')" . ma_provider_sql('COALESCE(c.send_provider, s.provider)') . "
                          GROUP BY 2, 3 ORDER BY COUNT(*) DESC LIMIT 25") as $x) {
            if ((int)$x['c'] > 0) $out[] = ['stream' => 'wa_campaign', 'provider' => $x['provider'], 'reason' => $x['reason'], 'c' => $x['c']];
            if ((int)$x['sk'] > 0) $out[] = ['stream' => 'wa_campaign', 'provider' => $x['provider'], 'reason' => 'Skipped: ' . $x['reason'], 'c' => $x['sk'], 'skipped' => 1];
        }
    if (ma_table_exists('journey_messages'))
        foreach (ma_rows("SELECT IF(r.channel = 'whatsapp', 'wa_journey', 'email_journey') stream, r.provider,
                                 IF(r.status = 'suppressed', CONCAT('Suppressed: ', COALESCE(r.suppress_reason, 'unspecified')), " . $trim('r.error_message') . ") reason,
                                 COUNT(*) c, MAX(r.status = 'suppressed') skipped
                          FROM journey_messages r
                          WHERE " . ma_where_j() . " AND r.status IN ('failed','suppressed')" . ma_provider_sql('r.provider') . "
                          GROUP BY 1, 2, 3 ORDER BY c DESC LIMIT 40") as $x) $out[] = $x;
    if (ma_fd_ok())
        foreach (ma_rows("SELECT 'email_support' stream, 'smtp' provider,
                                 IF(r.delivery_status = 'bounced', CONCAT('Bounced: ', " . $trim('r.delivery_error') . "), " . $trim('r.delivery_error') . ") reason, COUNT(*) c
                          FROM fd_messages r
                          WHERE " . ma_where_fd() . " AND r.delivery_status IN ('failed','bounced')
                          GROUP BY 3 ORDER BY c DESC LIMIT 15") as $x) $out[] = $x;
    if (ma_smtp_ok())
        foreach (ma_rows("SELECT 'email_smtp' stream, 'smtp' provider, " . $trim('r.error') . " reason, COUNT(*) c
                          FROM smtp_mail_log r
                          WHERE " . ma_where_smtp() . " AND r.status = 'failed'
                          GROUP BY 3 ORDER BY c DESC LIMIT 15") as $x) $out[] = $x;
    foreach ($out as &$x) {
        $x['c'] = (int)$x['c'];
        $x['channel'] = str_starts_with($x['stream'], 'wa_') ? 'whatsapp' : 'email';
        $x['provider_label'] = ma_provider_label($x['channel'], $x['provider'] ?? null);
        $x['skipped'] = !empty($x['skipped']) ? 1 : 0;
    }
    unset($x);
    usort($out, fn($a, $b) => $b['c'] <=> $a['c']);
    api_success(['reasons' => $out, 'took_ms' => (int)round((microtime(true) - $T0) * 1000)]);
}

/* ── Shared by source + people ─────────────────────────────────────────── */
function ma_source_params(): array {
    $kind = ma_in('kind'); $channel = ma_in('channel'); $id = (int)ma_in('id', 0);
    // A Freshdesk "source" is an agent, and 0 is a real one: the automated replies.
    $minId = $kind === 'support' ? 0 : 1;
    if (!in_array($kind, ['campaign', 'journey', 'support', 'transactional'], true) || !in_array($channel, ['email', 'whatsapp'], true) || $id < $minId) api_error('kind, channel and id are required');
    if (in_array($kind, ['support', 'transactional'], true)) $channel = 'email';
    $stream = $kind === 'transactional' ? 'email_smtp' : (($channel === 'whatsapp' ? 'wa_' : 'email_') . $kind);
    return [$kind, $channel, $id, $stream];
}

/* ══ source ════════════════════════════════════════════════════════════ */
if ($action === 'source') {
    [$kind, $channel, $id, $stream] = ma_source_params();
    $scan = ma_scan(['stream' => $stream, 'id' => $id, 'providers' => true]);
    $conv = [];
    foreach (ma_conversions($id, $stream) as $cv) {
        if ($cv['sid'] !== $id || !ma_provider_ok($cv['prov'])) continue;
        $prev = $conv[$cv['bk']] ?? [0, 0.0];
        $conv[$cv['bk']] = [$prev[0] + $cv['c'], $prev[1] + $cv['rev']];
    }
    $buckets = ma_all_buckets();

    $totals = ma_zero();
    $series = []; foreach ($buckets as $bk) $series[$bk] = ['bucket' => $bk] + ma_zero();
    $providers = [];
    foreach ($scan as $x) {
        ma_add($totals, $x);
        if (!isset($series[$x['bk']])) $series[$x['bk']] = ['bucket' => $x['bk']] + ma_zero();
        ma_add($series[$x['bk']], $x);
        $pl = ma_provider_label($channel, $x['provider']) . ($x['sender'] !== '' ? ' · ' . $x['sender'] : '');
        if (!isset($providers[$pl])) $providers[$pl] = ['label' => $pl] + ma_zero();
        ma_add($providers[$pl], $x);
    }
    foreach ($conv as $bk => [$c, $rev]) {
        $totals['conversions'] += $c; $totals['revenue'] += $rev;
        if (isset($series[$bk])) { $series[$bk]['conversions'] += $c; $series[$bk]['revenue'] += $rev; }
    }
    ksort($series);

    $meta = [];
    $steps = [];
    if ($kind === 'transactional') {
        $meta = ['id' => $id, 'name' => MA_SMTP_PURPOSES[$id][1] ?? 'Other contact@ emails', 'sender' => 'contact@internshipstudio.com', 'provider' => 'smtp', 'module' => 'refunds'];
    } elseif ($kind === 'support') {
        $meta = ma_names(['email_support' => [$id]])['email_support'][$id] ?? ['name' => 'Freshdesk replies'];
        $meta['id'] = $id;
        $meta['sender'] = 'contact@internshipstudio.com';
        $meta['provider'] = 'smtp';
    } elseif ($kind === 'campaign') {
        $t = $channel === 'whatsapp' ? 'wa_campaigns' : 'email_campaigns';
        $cols = $channel === 'whatsapp'
            ? "id, name, status, template_name, business_number sender, send_provider provider, started_at, completed_at, scheduled_at, total_recipients, last_error"
            : "id, name, status, subject, sender_email sender, esp_transport provider, started_at, completed_at, scheduled_at, total_recipients";
        $meta = ma_rows("SELECT $cols FROM $t WHERE id = $id")[0] ?? ['id' => $id, 'name' => "#$id (deleted)"];
    } else {
        $j = ma_rows("SELECT id, name, status, graph, start_at, deployed_at, goal_event FROM journeys WHERE id = $id")[0] ?? null;
        $graph = $j ? json_decode((string)$j['graph'], true) : null;
        if ($j) { unset($j['graph']); $meta = $j; } else $meta = ['id' => $id, 'name' => "#$id (deleted)"];
        $ch = $channel === 'whatsapp' ? 'whatsapp' : 'email';
        $stepRows = ma_rows("SELECT r.node_id, " . ma_j_metrics() . ", MIN(" . MA_J_DT . ") first_at, MAX(" . MA_J_DT . ") last_at
                             FROM journey_messages r
                             WHERE " . ma_where_j() . " AND r.journey_id = $id AND r.channel = '$ch'
                             GROUP BY r.node_id");
        $stepConv = [];
        if (ma_table_exists('journey_conversions')) {
            global $FROM, $TO;
            foreach (ma_rows("SELECT node_id, COUNT(*) c, COALESCE(SUM(revenue),0) rev FROM journey_conversions
                              WHERE journey_id = $id AND is_control = 0 AND converted_at BETWEEN '$FROM' AND '$TO' GROUP BY node_id") as $x)
                $stepConv[(string)$x['node_id']] = [(int)$x['c'], (float)$x['rev']];
        }
        foreach ($stepRows as $x) {
            $nid = (string)$x['node_id'];
            $row = ['node_id' => $nid, 'label' => ma_step_label($graph, $nid, $ch), 'first_at' => $x['first_at'], 'last_at' => $x['last_at']] + ma_zero();
            ma_add($row, $x);
            if (isset($stepConv[$nid])) { $row['conversions'] = $stepConv[$nid][0]; $row['revenue'] = $stepConv[$nid][1]; }
            // Canvas order: top to bottom, which is how the builder reads.
            $row['_y'] = (float)($graph['nodes'][$nid]['y'] ?? 1e9);
            $steps[] = $row;
        }
        usort($steps, fn($a, $b) => $a['_y'] <=> $b['_y']);
        foreach ($steps as &$st) unset($st['_y']);
        unset($st);
    }

    api_success([
        'meta' => $meta, 'kind' => $kind, 'channel' => $channel, 'stream' => $stream,
        'totals' => $totals, 'series' => array_values($series), 'providers' => array_values($providers), 'steps' => $steps,
        'range' => ['from' => $from, 'to' => $to, 'granularity' => $GRAN, 'from_at' => $FROM, 'to_at' => $TO],
        'took_ms' => (int)round((microtime(true) - $T0) * 1000),
    ]);
}

/* ══ people ════════════════════════════════════════════════════════════ */
if ($action === 'people') {
    [$kind, $channel, $id, $stream] = ma_source_params();
    $status  = (string)ma_in('status', 'all');
    $search  = trim((string)ma_in('search', ''));
    $page    = max(1, (int)ma_in('page', 1));
    $per     = min(100, max(10, (int)ma_in('per_page', 25)));
    $offset  = ($page - 1) * $per;
    $s = $conn->real_escape_string($search);

    if ($stream === 'email_campaign') {
        $base = "FROM email_campaign_recipients r WHERE " . ma_where_email() . " AND r.campaign_id = $id";
        $F = [
            'sent' => "r.status IN ('sent','bounced')", 'delivered' => "r.delivered_at IS NOT NULL AND r.status = 'sent'", 'opened' => 'r.opened_at IS NOT NULL',
            'clicked' => 'r.first_clicked_at IS NOT NULL', 'failed' => "r.status = 'failed'", 'bounced' => "r.status = 'bounced'",
            'not_delivered' => "r.status IN ('sent') AND r.delivered_at IS NULL", 'skipped' => '0',
        ];
        $sw = $search !== '' ? " AND (r.email LIKE '%$s%' OR CONCAT_WS(' ', r.first_name, r.last_name) LIKE '%$s%')" : '';
        $sel = "r.id, r.user_id, r.email contact, CONCAT_WS(' ', r.first_name, r.last_name) name, r.status raw_status,
                r.sent_at, r.delivered_at, r.opened_at, r.first_clicked_at clicked_at, r.bounced_at failed_at, r.error_message error,
                r.open_count opens, r.click_count clicks, " . MA_EMAIL_DT . " at";
    } elseif ($stream === 'wa_campaign') {
        $base = "FROM wa_campaign_recipients r WHERE " . ma_where_wa() . " AND r.campaign_id = $id";
        $F = [
            'sent' => "r.sent_at IS NOT NULL AND r.status NOT IN ('failed','skipped')", 'delivered' => "(r.delivered_at IS NOT NULL OR r.status IN ('delivered','read')) AND r.status NOT IN ('failed','skipped')",
            'opened' => "(r.read_at IS NOT NULL OR r.status = 'read')", 'clicked' => 'r.first_clicked_at IS NOT NULL',
            'failed' => "r.status = 'failed'", 'bounced' => '0', 'skipped' => "r.status = 'skipped'",
            'not_delivered' => "r.status = 'sent' AND r.delivered_at IS NULL",
        ];
        $sw = $search !== '' ? " AND (r.phone LIKE '%$s%' OR r.email LIKE '%$s%' OR CONCAT_WS(' ', r.first_name, r.last_name) LIKE '%$s%')" : '';
        $sel = "r.id, r.user_id, r.phone contact, CONCAT_WS(' ', r.first_name, r.last_name) name, r.status raw_status,
                r.sent_at, r.delivered_at, r.read_at opened_at, r.first_clicked_at clicked_at, r.failed_at,
                CONCAT_WS(' — ', NULLIF(r.error_code,''), COALESCE(r.error_message, r.skip_reason)) error, 0 opens, r.click_count clicks, " . MA_WA_DT . " at";
    } elseif ($stream === 'email_smtp') {
        $base = "FROM smtp_mail_log r LEFT JOIN users u ON u.user_id = r.user_id
                 WHERE " . ma_where_smtp() . " AND (" . ma_smtp_sid_sql() . ") = $id";
        $F = [
            'sent' => "r.status = 'sent'", 'delivered' => '0', 'opened' => '0', 'clicked' => '0',
            'failed' => "r.status = 'failed'", 'bounced' => '0', 'skipped' => '0', 'not_delivered' => '0',
        ];
        $sw = $search !== '' ? " AND (r.to_email LIKE '%$s%' OR r.subject LIKE '%$s%')" : '';
        $sel = "r.id, r.user_id, r.to_email contact, CONVERT(COALESCE(NULLIF(TRIM(u.name), ''), CONCAT_WS(' ', u.fname, u.lname)) USING utf8mb4) name,
                r.status raw_status, IF(r.status = 'sent', r.created_at, NULL) sent_at, NULL delivered_at, NULL opened_at, NULL clicked_at,
                IF(r.status = 'failed', r.created_at, NULL) failed_at, r.error, 0 opens, 0 clicks, r.subject, r.created_at at";
    } elseif ($stream === 'email_support') {
        $base = "FROM fd_messages r LEFT JOIN fd_tickets t ON t.id = r.ticket_id
                 WHERE " . ma_where_fd() . " AND COALESCE(r.sent_by_user_id, 0) = $id";
        $F = [
            'sent' => "r.delivery_status IN ('sent','bounced')", 'delivered' => '0', 'opened' => '0', 'clicked' => '0',
            'failed' => "r.delivery_status = 'failed'", 'bounced' => "r.delivery_status = 'bounced'", 'skipped' => '0', 'not_delivered' => '0',
        ];
        $sw = $search !== '' ? " AND (r.to_emails LIKE '%$s%' OR r.subject LIKE '%$s%' OR t.requester_name LIKE '%$s%')" : '';
        $sel = "r.id, NULL user_id, " . MA_FD_TO . " contact, t.requester_name name, r.delivery_status raw_status,
                IF(r.delivery_status IN ('sent','bounced'), " . MA_FD_DT . ", NULL) sent_at, NULL delivered_at, NULL opened_at, NULL clicked_at,
                IF(r.delivery_status IN ('failed','bounced'), " . MA_FD_DT . ", NULL) failed_at, r.delivery_error error, 0 opens, 0 clicks,
                r.subject, r.ticket_id, " . MA_FD_DT . " at";
    } else {
        $ch = $channel === 'whatsapp' ? 'whatsapp' : 'email';
        $nodeId = (string)ma_in('node_id', '');
        $nw = $nodeId !== '' ? " AND r.node_id = '" . $conn->real_escape_string($nodeId) . "'" : '';
        $base = "FROM journey_messages r LEFT JOIN journey_entries e ON e.id = r.entry_id
                 WHERE " . ma_where_j() . " AND r.journey_id = $id AND r.channel = '$ch' $nw" . ma_provider_sql('r.provider');
        $F = [
            'sent' => "r.status = 'sent'", 'delivered' => "r.delivered_at IS NOT NULL AND r.status = 'sent'", 'opened' => 'r.opened_at IS NOT NULL',
            'clicked' => 'r.first_clicked_at IS NOT NULL', 'failed' => "r.status = 'failed'", 'bounced' => '0',
            'skipped' => "r.status = 'suppressed'", 'not_delivered' => "r.status = 'sent' AND r.delivered_at IS NULL",
        ];
        $sw = $search !== '' ? " AND (r.to_addr LIKE '%$s%' OR e.email LIKE '%$s%' OR e.phone LIKE '%$s%' OR CONCAT_WS(' ', e.first_name, e.last_name) LIKE '%$s%')" : '';
        $sel = "r.id, r.user_id, COALESCE(r.to_addr, IF(r.channel = 'whatsapp', e.phone, e.email)) contact, CONCAT_WS(' ', e.first_name, e.last_name) name,
                r.status raw_status, r.sent_at, r.delivered_at, r.opened_at, r.first_clicked_at clicked_at, NULL failed_at,
                IF(r.status = 'suppressed', CONCAT('Suppressed: ', COALESCE(r.suppress_reason, '')), r.error_message) error,
                r.open_count opens, r.click_count clicks, r.node_id, " . MA_J_DT . " at";
    }

    // Counts for every status chip in one pass, so the chips and the list always agree.
    $cntSel = [];
    foreach ($F as $k => $expr) $cntSel[] = "SUM($expr) `$k`";
    $counts = ma_rows("SELECT COUNT(*) `all`, " . implode(', ', $cntSel) . " $base $sw")[0] ?? [];
    foreach ($counts as $k => $v) $counts[$k] = (int)$v;

    $stw = ($status !== 'all' && isset($F[$status])) ? " AND ({$F[$status]})" : '';
    $total = $status === 'all' ? ($counts['all'] ?? 0) : ($counts[$status] ?? 0);
    $rows = ma_rows("SELECT $sel $base $sw $stw ORDER BY at DESC, r.id DESC LIMIT $per OFFSET $offset");

    foreach ($rows as &$r) {
        // One human status per person — the furthest they got.
        $raw = $r['raw_status'];
        $r['status'] = in_array($raw, ['failed', 'bounced', 'skipped', 'suppressed'], true) ? ($raw === 'suppressed' ? 'skipped' : $raw)
            : ($r['clicked_at'] ? 'clicked' : ($r['opened_at'] ? 'opened' : ($r['delivered_at'] ? 'delivered' : ($r['sent_at'] ? 'sent' : $raw))));
        $r['name'] = trim((string)$r['name']);
    }
    unset($r);

    api_success([
        'rows' => $rows, 'total' => (int)$total, 'counts' => $counts, 'page' => $page, 'per_page' => $per,
        'pages' => max(1, (int)ceil($total / $per)),
        'took_ms' => (int)round((microtime(true) - $T0) * 1000),
    ]);
}

/* ══ people_all ════════════════════════════════════════════════════════
 * The people behind a KPI tile: one metric, across every campaign and journey the filters allow,
 * newest first, as ONE paginated list. Each stream is queried with the same column shape and the
 * branches are UNION ALLed, each pre-limited to offset+per so page N never reads a table whole.
 * Per-stream counts come back with it, so the drawer can show where the number came from.
 *
 * &metric (sent|delivered|opened|clicked|failed|bounced|skipped|rejected|attempted|conversions)
 * &channel (all|email|whatsapp) &source (all|campaign|journey) [&stream &search &page &per_page]
 */
if ($action === 'people_all') {
    $metric = (string)ma_in('metric', 'sent');
    $chan   = (string)ma_in('channel', 'all');
    $kindF  = (string)ma_in('source', 'all');
    $only   = (string)ma_in('stream', '');
    $search = trim((string)ma_in('search', ''));
    $page   = max(1, (int)ma_in('page', 1));
    $per    = min(100, max(10, (int)ma_in('per_page', 25)));
    $offset = ($page - 1) * $per;
    $cap    = $offset + $per;
    $s = $conn->real_escape_string($search);
    if (!in_array($metric, ['attempted', 'sent', 'delivered', 'opened', 'clicked', 'failed', 'bounced', 'skipped', 'rejected', 'conversions'], true)) api_error('Unknown metric');

    $streams = [];
    foreach (['email_campaign', 'email_journey', 'wa_campaign', 'wa_journey', 'email_support', 'email_smtp'] as $st) {
        $c = str_starts_with($st, 'wa_') ? 'whatsapp' : 'email';
        $k = ma_kind($st);
        if (($chan === 'all' || $chan === $c) && ($kindF === 'all' || $kindF === $k)) $streams[] = $st;
    }
    $like = function (array $cols) use ($search, $s): string {
        if ($search === '') return '';
        return ' AND (' . implode(' OR ', array_map(fn($x) => "$x LIKE '%$s%'", $cols)) . ')';
    };

    // Every branch selects exactly these columns, in this order.
    $branches = [];   // stream => [select-without-order, count]
    if ($metric === 'conversions') {
        foreach ($streams as $st) {
            if (in_array($st, ['email_campaign', 'wa_campaign'], true) && ma_table_exists('campaign_attributions')) {
                $isWa = $st === 'wa_campaign';
                $ct = $isWa ? 'wa_campaigns' : 'email_campaigns';
                $base = "FROM campaign_attributions ca LEFT JOIN $ct c ON c.id = ca.campaign_id LEFT JOIN users u ON u.user_id = ca.user_id"
                         . ($isWa ? ' LEFT JOIN wa_senders sd ON sd.id = c.sender_id' : '') . "
                         WHERE ca.medium = '" . ($isWa ? 'whatsapp' : 'email') . "' AND ca.attributed_at BETWEEN '$FROM' AND '$TO'"
                         . ma_provider_sql($isWa ? 'COALESCE(c.send_provider, sd.provider)' : 'c.esp_transport')
                         . $like(['u.email', 'u.phone', 'u.name', 'c.name']);
                $branches[$st] = ["SELECT '$st' stream, CAST(ca.id AS CHAR) rid, ca.campaign_id sid, c.name source_name, NULL node_id,
                        CAST(ca.user_id AS CHAR) user_id, " . ($isWa ? 'u.phone' : 'u.email') . " contact,
                        COALESCE(NULLIF(TRIM(u.name), ''), TRIM(CONCAT_WS(' ', u.fname, u.lname))) name, 'converted' raw_status, " . ($isWa ? 'COALESCE(c.send_provider, sd.provider)' : 'c.esp_transport') . " provider,
                        NULL queued_at, NULL sent_at, NULL delivered_at, NULL opened_at, ca.clicked_at clicked_at, NULL failed_at, NULL error,
                        0 opens, 0 clicks, NULL message_id, NULL subject, ca.event_key conv_event, ca.attributed_at converted_at, 0 revenue,
                        ca.attributed_at at $base", "SELECT COUNT(*) c $base"];
            }
            if (str_ends_with($st, '_journey') && ma_table_exists('journey_conversions')) {
                $ch = $st === 'wa_journey' ? 'whatsapp' : 'email';
                $base = "FROM journey_conversions cv LEFT JOIN journey_messages m ON m.id = cv.message_id
                         LEFT JOIN journeys j ON j.id = cv.journey_id LEFT JOIN journey_entries e ON e.id = cv.entry_id
                         WHERE cv.is_control = 0 AND cv.converted_at BETWEEN '$FROM' AND '$TO'
                           AND COALESCE(m.channel, (SELECT m2.channel FROM journey_messages m2 WHERE m2.journey_id = cv.journey_id AND m2.node_id = cv.node_id LIMIT 1), 'email') = '$ch'"
                         . ma_provider_sql('m.provider')
                         . $like(['e.email', 'e.phone', "CONCAT_WS(' ', e.first_name, e.last_name)", 'j.name']);
                $branches[$st] = ["SELECT '$st' stream, CAST(cv.id AS CHAR) rid, cv.journey_id sid, j.name source_name, cv.node_id,
                        CAST(cv.user_id AS CHAR) user_id, " . ($ch === 'whatsapp' ? 'e.phone' : 'e.email') . " contact,
                        TRIM(CONCAT_WS(' ', e.first_name, e.last_name)) name, 'converted' raw_status, m.provider,
                        m.queued_at, m.sent_at, m.delivered_at, m.opened_at, m.first_clicked_at clicked_at, NULL failed_at, NULL error,
                        COALESCE(m.open_count, 0) opens, COALESCE(m.click_count, 0) clicks, m.provider_message_id message_id, m.subject,
                        cv.event_key conv_event, cv.converted_at, cv.revenue, cv.converted_at at $base", "SELECT COUNT(*) c $base"];
            }
        }
    } else {
        $F = [
            'email_campaign' => ['attempted' => '1', 'sent' => "r.status IN ('sent','bounced')", 'delivered' => "r.delivered_at IS NOT NULL AND r.status = 'sent'",
                'opened' => 'r.opened_at IS NOT NULL', 'clicked' => 'r.first_clicked_at IS NOT NULL', 'failed' => "r.status = 'failed'",
                'bounced' => "r.status = 'bounced'", 'skipped' => '0', 'rejected' => "r.status IN ('failed','bounced')"],
            'wa_campaign' => ['attempted' => '1', 'sent' => "r.sent_at IS NOT NULL AND r.status NOT IN ('failed','skipped')",
                'delivered' => "(r.delivered_at IS NOT NULL OR r.status IN ('delivered','read')) AND r.status NOT IN ('failed','skipped')",
                'opened' => "(r.read_at IS NOT NULL OR r.status = 'read')", 'clicked' => 'r.first_clicked_at IS NOT NULL',
                'failed' => "r.status = 'failed'", 'bounced' => '0', 'skipped' => "r.status = 'skipped'", 'rejected' => "r.status = 'failed'"],
            'journey' => ['attempted' => '1', 'sent' => "r.status = 'sent'", 'delivered' => "r.delivered_at IS NOT NULL AND r.status = 'sent'",
                'opened' => 'r.opened_at IS NOT NULL', 'clicked' => 'r.first_clicked_at IS NOT NULL', 'failed' => "r.status = 'failed'",
                'bounced' => '0', 'skipped' => "r.status = 'suppressed'", 'rejected' => "r.status = 'failed'"],
        ];
        foreach ($streams as $st) {
            if ($st === 'email_campaign' && ma_table_exists('email_campaign_recipients')) {
                if ($F[$st][$metric] === '0') continue;
                $base = "FROM email_campaign_recipients r JOIN email_campaigns c ON c.id = r.campaign_id
                         WHERE " . ma_where_email() . " AND ({$F[$st][$metric]})" . ma_provider_sql('c.esp_transport')
                         . $like(['r.email', "CONCAT_WS(' ', r.first_name, r.last_name)", 'c.name']);
                $branches[$st] = ["SELECT 'email_campaign' stream, CAST(r.id AS CHAR) rid, r.campaign_id sid, c.name source_name, NULL node_id,
                        CAST(r.user_id AS CHAR) user_id, r.email contact, TRIM(CONCAT_WS(' ', r.first_name, r.last_name)) name, r.status raw_status,
                        c.esp_transport provider, r.queued_at, r.sent_at, r.delivered_at, r.opened_at, r.first_clicked_at clicked_at, r.bounced_at failed_at,
                        r.error_message error, r.open_count opens, r.click_count clicks, r.esp_message_id message_id, c.subject,
                        NULL conv_event, NULL converted_at, 0 revenue, " . MA_EMAIL_DT . " at $base", "SELECT COUNT(*) c $base"];
            }
            if ($st === 'wa_campaign' && ma_table_exists('wa_campaign_recipients')) {
                if ($F[$st][$metric] === '0') continue;
                $base = "FROM wa_campaign_recipients r JOIN wa_campaigns c ON c.id = r.campaign_id LEFT JOIN wa_senders sd ON sd.id = c.sender_id
                         WHERE " . ma_where_wa() . " AND ({$F[$st][$metric]})" . ma_provider_sql('COALESCE(c.send_provider, sd.provider)')
                         . $like(['r.phone', 'r.email', "CONCAT_WS(' ', r.first_name, r.last_name)", 'c.name']);
                $branches[$st] = ["SELECT 'wa_campaign' stream, CAST(r.id AS CHAR) rid, r.campaign_id sid, c.name source_name, NULL node_id,
                        CAST(r.user_id AS CHAR) user_id, r.phone contact, TRIM(CONCAT_WS(' ', r.first_name, r.last_name)) name, r.status raw_status,
                        COALESCE(c.send_provider, sd.provider) provider, r.queued_at, r.sent_at, r.delivered_at, r.read_at opened_at,
                        r.first_clicked_at clicked_at, r.failed_at,
                        CONCAT_WS(' — ', NULLIF(r.error_code, ''), COALESCE(r.error_message, r.skip_reason)) error, 0 opens, r.click_count clicks,
                        r.wa_message_id message_id, CONCAT_WS(' · ', c.template_name, COALESCE(c.business_number, sd.business_number)) subject,
                        NULL conv_event, NULL converted_at, 0 revenue, " . MA_WA_DT . " at $base", "SELECT COUNT(*) c $base"];
            }
            if (str_ends_with($st, '_journey') && ma_table_exists('journey_messages')) {
                if ($F['journey'][$metric] === '0') continue;
                $ch = $st === 'wa_journey' ? 'whatsapp' : 'email';
                $base = "FROM journey_messages r LEFT JOIN journey_entries e ON e.id = r.entry_id LEFT JOIN journeys j ON j.id = r.journey_id
                         WHERE " . ma_where_j() . " AND r.channel = '$ch' AND ({$F['journey'][$metric]})" . ma_provider_sql('r.provider')
                         . $like(['r.to_addr', 'e.email', 'e.phone', "CONCAT_WS(' ', e.first_name, e.last_name)", 'j.name']);
                $branches[$st] = ["SELECT '$st' stream, CAST(r.id AS CHAR) rid, r.journey_id sid, j.name source_name, r.node_id,
                        CAST(r.user_id AS CHAR) user_id, COALESCE(r.to_addr, IF(r.channel = 'whatsapp', e.phone, e.email)) contact,
                        TRIM(CONCAT_WS(' ', e.first_name, e.last_name)) name, r.status raw_status, r.provider, r.queued_at, r.sent_at, r.delivered_at,
                        r.opened_at, r.first_clicked_at clicked_at, NULL failed_at,
                        IF(r.status = 'suppressed', CONCAT('Suppressed: ', COALESCE(r.suppress_reason, '')), r.error_message) error,
                        r.open_count opens, r.click_count clicks, r.provider_message_id message_id, r.subject,
                        NULL conv_event, NULL converted_at, 0 revenue, " . MA_J_DT . " at $base", "SELECT COUNT(*) c $base"];
            }
            if ($st === 'email_support' && ma_fd_ok()) {
                $FD = ['attempted' => '1', 'sent' => "r.delivery_status IN ('sent','bounced')", 'delivered' => '0', 'opened' => '0', 'clicked' => '0',
                       'failed' => "r.delivery_status = 'failed'", 'bounced' => "r.delivery_status = 'bounced'", 'skipped' => '0',
                       'rejected' => "r.delivery_status IN ('failed','bounced')"];
                if ($FD[$metric] === '0') continue;
                $base = "FROM fd_messages r LEFT JOIN fd_tickets t ON t.id = r.ticket_id
                         WHERE " . ma_where_fd() . " AND ({$FD[$metric]})"
                         . $like(['r.to_emails', 'r.subject', 't.requester_name', 'r.sent_by_name']);
                $branches[$st] = ["SELECT 'email_support' stream, CAST(r.id AS CHAR) rid, COALESCE(r.sent_by_user_id, 0) sid,
                        CONCAT('Freshdesk replies · ', COALESCE(r.sent_by_name, 'Automated')) source_name, CAST(r.ticket_id AS CHAR) COLLATE utf8mb4_unicode_ci node_id,
                        NULL user_id, " . MA_FD_TO . " contact, t.requester_name name, r.delivery_status raw_status, 'smtp' provider,
                        r.created_at queued_at, IF(r.delivery_status IN ('sent','bounced'), " . MA_FD_DT . ", NULL) sent_at,
                        NULL delivered_at, NULL opened_at, NULL clicked_at, IF(r.delivery_status IN ('failed','bounced'), " . MA_FD_DT . ", NULL) failed_at,
                        r.delivery_error error, 0 opens, 0 clicks, r.message_id, r.subject,
                        NULL conv_event, NULL converted_at, 0 revenue, " . MA_FD_DT . " at $base", "SELECT COUNT(*) c $base"];
            }
            if ($st === 'email_smtp' && ma_smtp_ok()) {
                $SM = ['attempted' => '1', 'sent' => "r.status = 'sent'", 'delivered' => '0', 'opened' => '0', 'clicked' => '0',
                       'failed' => "r.status = 'failed'", 'bounced' => '0', 'skipped' => '0', 'rejected' => "r.status = 'failed'"];
                if ($SM[$metric] === '0') continue;
                $label = "CASE r.purpose";
                foreach (MA_SMTP_PURPOSES as $pid => [$pkey, $plabel]) if ($pid !== 9) $label .= " WHEN '$pkey' THEN '$plabel'";
                $label .= " ELSE 'Other contact@ emails' END";
                $base = "FROM smtp_mail_log r LEFT JOIN users u ON u.user_id = r.user_id
                         WHERE " . ma_where_smtp() . " AND ({$SM[$metric]})"
                         . $like(['r.to_email', 'r.subject']);
                // users.* may use another collation than this table; everything textual is pinned so the UNION stays legal.
                $branches[$st] = ["SELECT 'email_smtp' stream, CAST(r.id AS CHAR) rid, " . ma_smtp_sid_sql() . " sid,
                        $label source_name, r.purpose node_id,
                        CAST(r.user_id AS CHAR) user_id, r.to_email contact,
                        CONVERT(COALESCE(NULLIF(TRIM(u.name), ''), CONCAT_WS(' ', u.fname, u.lname)) USING utf8mb4) COLLATE utf8mb4_unicode_ci name,
                        r.status raw_status, 'smtp' provider, r.created_at queued_at, IF(r.status = 'sent', r.created_at, NULL) sent_at,
                        NULL delivered_at, NULL opened_at, NULL clicked_at, IF(r.status = 'failed', r.created_at, NULL) failed_at,
                        r.error, 0 opens, 0 clicks, r.message_id, r.subject,
                        NULL conv_event, NULL converted_at, 0 revenue, r.created_at at $base", "SELECT COUNT(*) c $base"];
            }
        }
    }

    $counts = [];
    foreach ($branches as $st => $b) $counts[$st] = (int)(ma_rows($b[1])[0]['c'] ?? 0);
    $pick = ($only !== '' && isset($branches[$only])) ? [$only => $branches[$only]] : $branches;
    $total = 0;
    foreach ($pick as $st => $_) $total += $counts[$st];

    $rows = [];
    if ($pick && $offset < $total) {
        $parts = [];
        foreach ($pick as $st => $b) if ($counts[$st] > 0) $parts[] = '(' . $b[0] . " ORDER BY at DESC LIMIT $cap)";
        if ($parts) $rows = ma_rows(implode(' UNION ALL ', $parts) . " ORDER BY at DESC, rid DESC LIMIT $per OFFSET $offset");
    }

    // Step labels for journey rows, from each journey's graph (read once per journey).
    $jids = [];
    foreach ($rows as $r) if (str_ends_with($r['stream'], '_journey')) $jids[(int)$r['sid']] = true;
    $graphs = [];
    if ($jids) foreach (ma_rows("SELECT id, graph FROM journeys WHERE id IN (" . implode(',', array_keys($jids)) . ")") as $g) $graphs[(int)$g['id']] = json_decode((string)$g['graph'], true);

    foreach ($rows as &$r) {
        $channel = str_starts_with($r['stream'], 'wa_') ? 'whatsapp' : 'email';
        $r['channel'] = $channel;
        $r['kind'] = ma_kind($r['stream']);
        $r['sid'] = (int)$r['sid'];
        $r['step'] = ($r['kind'] === 'journey' && $r['node_id']) ? ma_step_label($graphs[$r['sid']] ?? null, (string)$r['node_id'], $channel)
            : (($r['kind'] === 'support' && $r['node_id']) ? 'Ticket #IS-' . $r['node_id']
            : ($r['kind'] === 'transactional' ? 'Refund management' : null));
        $r['provider_label'] = $r['provider'] ? ma_provider_label($channel, $r['provider']) : null;
        $r['source_name'] = $r['source_name'] ?: ('#' . $r['sid'] . ' (deleted)');
        $raw = $r['raw_status'];
        $r['status'] = $raw === 'converted' ? 'converted'
            : (in_array($raw, ['failed', 'bounced', 'skipped', 'suppressed'], true) ? ($raw === 'suppressed' ? 'skipped' : $raw)
            : ($r['clicked_at'] ? 'clicked' : ($r['opened_at'] ? 'opened' : ($r['delivered_at'] ? 'delivered' : ($r['sent_at'] ? 'sent' : $raw)))));
        $r['name'] = trim((string)$r['name']);
        $r['opens'] = (int)$r['opens'];
        $r['clicks'] = (int)$r['clicks'];
        $r['revenue'] = (float)$r['revenue'];
    }
    unset($r);

    api_success([
        'rows' => $rows, 'total' => $total, 'counts' => $counts, 'page' => $page, 'per_page' => $per,
        'pages' => max(1, (int)ceil($total / $per)), 'metric' => $metric,
        'took_ms' => (int)round((microtime(true) - $T0) * 1000),
    ]);
}

api_error('Unknown action');

<?php
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../config/cache.php';
require_once __DIR__ . '/../../middleware/auth.php';

/* ─── helpers ─── */
/* Total attendance window in days, derived from the purchased duration.
   total_duration is stored as an approximate day count; bucket it to whole
   months and use 30 days per month (e.g. 65 → 2 months → 60 days). */
function rl_getDurationDays($days) {
    if (!$days) return 0;
    if ($days <= 35)  return 30;
    if ($days <= 65)  return 60;
    if ($days <= 95)  return 90;
    if ($days <= 125) return 120;
    if ($days <= 155) return 150;
    return 180;
}

function rl_calculateAttendance($conn, $user_id, $batch, $total_duration = 0) {
    if (!$batch) return 0;
    $cleanBatch = preg_replace('/(\d+)(st|nd|rd|th)/i', '$1', $batch);
    try { $start = new DateTime($cleanBatch); } catch (Exception $e) { return 0; }
    /* Window = full batch duration starting from the batch date.
       e.g. batch 22 Mar 2026 + 60 days → day 60 = 20 May 2026. */
    $totalDays = rl_getDurationDays((int)$total_duration);
    if ($totalDays <= 0) $totalDays = 30;
    $end = clone $start; $end->modify('+' . ($totalDays - 1) . ' days');
    $startStr = $start->format('Y-m-d'); $endStr = $end->format('Y-m-d');
    /* From 2026-05-13 a day counts as PRESENT only when the user has BOTH a
       user_login_activity record AND an attendance_log record for that date.
       Dates before 2026-05-13 keep the old rule (login record only). */
    $sql = "SELECT COUNT(*) AS present_days FROM (
                SELECT DATE(la.login_date) AS d
                FROM user_login_activity la
                WHERE la.user_id = ?
                  AND DATE(la.login_date) BETWEEN ? AND LEAST(?, CURDATE())
                  AND la.activity_level >= 1
                  AND ( DATE(la.login_date) < '2026-05-13'
                        OR EXISTS ( SELECT 1 FROM attendance_log al
                                    WHERE al.user_id = la.user_id
                                      AND DATE(al.attendance_date) = DATE(la.login_date) ) )
                GROUP BY DATE(la.login_date)
            ) t";
    $stmt = $conn->prepare($sql); $stmt->bind_param("iss", $user_id, $startStr, $endStr); $stmt->execute();
    $present = (int)($stmt->get_result()->fetch_assoc()['present_days'] ?? 0);
    /* Denominator is the FULL window so days not yet elapsed still count as
       absent — e.g. 59 present of a 60-day window → 98.3%. */
    return round(($present / $totalDays) * 100, 1);
}

function rl_getDurationInMonths($days) {
    if (!$days) return '—';
    if ($days <= 35) return '1 month';
    if ($days <= 65) return '2 months';
    if ($days <= 95) return '3 months';
    if ($days <= 125) return '4 months';
    if ($days <= 155) return '5 months';
    return '6 months';
}

function rl_wrapEmail($html) {
    $year = date('Y');
    return "<!DOCTYPE html><html><head><meta charset='utf-8'><style>
body{margin:0;padding:0;background:#f0faf8;font-family:'Segoe UI',Arial,sans-serif;}
.wrap{max-width:620px;margin:32px auto;background:#fff;border-radius:14px;overflow:hidden;box-shadow:0 4px 24px rgba(0,0,0,.08);}
.hdr{background:linear-gradient(135deg,#0d2137,#164a3e);padding:28px 32px;text-align:center;}
.hdr h2{color:#fff;font-size:18px;margin:12px 0 0;font-weight:700;}
.body{padding:32px 36px;font-size:14px;color:#1a2e2b;line-height:1.7;}
.foot{background:#f0faf8;border-top:1px solid #d4efeb;padding:18px 32px;text-align:center;font-size:11px;color:#6b8f8a;}
</style></head><body><div class='wrap'><div class='hdr'><h2>Internship Studio</h2></div><div class='body'>{$html}</div><div class='foot'>&copy; {$year} Internship Studio | This is an automated email.</div></div></body></html>";
}

/* ─── project review log (admin-side timeline of approve/reject events) ───
   Created lazily so no manual migration is needed. Stores one row per admin
   decision; the submitted/resubmitted events are derived from
   project_submission + project_resubmission_log at read time. */
function rl_ensureReviewLog($conn) {
    $conn->query("CREATE TABLE IF NOT EXISTS project_review_log (
        id            INT AUTO_INCREMENT PRIMARY KEY,
        ps_id         INT DEFAULT NULL,
        user_id       INT NOT NULL,
        internship_id INT NOT NULL,
        action        ENUM('submitted','resubmitted','approved','rejected','pending') NOT NULL,
        reason        TEXT DEFAULT NULL,
        admin_id      INT DEFAULT 0,
        event_at      DATETIME DEFAULT CURRENT_TIMESTAMP,
        created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_user_internship (user_id, internship_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
}

/* Record one admin decision. $event_at is 'Y-m-d H:i:s' or null (=> NOW()). */
function rl_logReview($conn, $user_id, $internship_id, $action, $reason, $admin_id, $event_at = null) {
    rl_ensureReviewLog($conn);
    $psId = null;
    $q = $conn->prepare("SELECT id FROM project_submission WHERE user_id=? AND internship_id=? ORDER BY id DESC LIMIT 1");
    $q->bind_param('ii', $user_id, $internship_id);
    $q->execute();
    if ($row = $q->get_result()->fetch_assoc()) $psId = (int)$row['id'];

    if ($event_at) {
        $st = $conn->prepare("INSERT INTO project_review_log (ps_id, user_id, internship_id, action, reason, admin_id, event_at) VALUES (?,?,?,?,?,?,?)");
        $st->bind_param('iiissis', $psId, $user_id, $internship_id, $action, $reason, $admin_id, $event_at);
    } else {
        $st = $conn->prepare("INSERT INTO project_review_log (ps_id, user_id, internship_id, action, reason, admin_id, event_at) VALUES (?,?,?,?,?,?,NOW())");
        $st->bind_param('iiissi', $psId, $user_id, $internship_id, $action, $reason, $admin_id);
    }
    $st->execute();
}

/* ─── Assignment schedule helpers — mirror frontend utils/assignmentSchedule.js
   exactly so the admin panel shows the same within/after-deadline verdict the
   student dashboard does. Each assignment owns a 5-day window; the LAST one's
   deadline lands on the project-submission open day (months*30 - 5, +1 for the
   6 May 2026 batch) and earlier ones step back 5 days each. ─── */
function rl_durationDaysToMonths($days) {
    $days = (int)$days;
    $map = [35 => 1, 65 => 2, 95 => 3, 125 => 4, 155 => 5, 185 => 6];
    if (isset($map[$days])) return $map[$days];
    if (!$days) return 1;
    $approx = (int)round(($days - 5) / 30);
    return min(6, max(1, $approx));
}

/* Parse a batch string ("8th June, 2026") into a midnight DateTime, or null. */
function rl_parseBatch($batch) {
    if (!$batch) return null;
    $clean = preg_replace('/(\d+)(st|nd|rd|th)/i', '$1', $batch);
    try { $d = new DateTime($clean); } catch (Exception $e) { return null; }
    $d->setTime(0, 0, 0);
    return $d;
}

/* Day-of-batch (1-indexed) on which project submission opens. */
function rl_submissionOpenDay($batchStart, $totalDuration) {
    $m = rl_durationDaysToMonths($totalDuration);
    $offset = $m * 30 - 6;                 // projectUnlockOffsetDays
    $extra = ($batchStart instanceof DateTime
        && (int)$batchStart->format('Y') === 2026
        && (int)$batchStart->format('n') === 5
        && (int)$batchStart->format('j') === 6) ? 1 : 0;
    return $offset + 1 + $extra;
}

/* Per-assignment unlock + deadline dates (mirrors computeAssignmentSchedule). */
function rl_assignmentSchedule($batchStart, $totalDuration, $count) {
    $WINDOW = 5;
    $submitOpenDay = rl_submissionOpenDay($batchStart, $totalDuration);
    $items = [];
    $n = max(0, (int)$count);
    for ($i = 0; $i < $n; $i++) {
        $fromLast    = $n - 1 - $i;        // 0 for the last assignment
        $deadlineDay = $submitOpenDay - $fromLast * $WINDOW;
        $unlockDay   = $deadlineDay - ($WINDOW - 1);
        $unlockDate = $deadlineDate = null;
        if ($batchStart instanceof DateTime) {
            $u = clone $batchStart; $u->modify(($unlockDay   - 1) . ' days');
            $d = clone $batchStart; $d->modify(($deadlineDay - 1) . ' days');
            $unlockDate   = $u->format('Y-m-d');
            $deadlineDate = $d->format('Y-m-d');
        }
        $items[] = [
            'unlock_day'    => $unlockDay,
            'deadline_day'  => $deadlineDay,
            'unlock_date'   => $unlockDate,
            'deadline_date' => $deadlineDate,
        ];
    }
    return $items;
}

$jwt = require_jwt();
require_permission('manage_refund', $jwt);

/* ─── GET: per-student assignment status (submitted? within / after deadline?) ─── */
if ($_SERVER['REQUEST_METHOD'] === 'GET' && ($_GET['action'] ?? '') === 'assignment_status') {
    $user_id       = (int)($_GET['user_id'] ?? 0);
    $internship_id = (int)($_GET['internship_id'] ?? 0);
    if (!$user_id || !$internship_id) api_error('Invalid parameters', 400);

    /* batch + duration — same source as the project_timeline deadline */
    $batchStart = null; $totalDuration = 0; $batchLabel = null;
    $pay = $conn->prepare("SELECT ip.batch, ip.total_duration
                           FROM internship_payment ip
                           INNER JOIN internship_list il ON il.internship_name = ip.internship
                           WHERE ip.user_id=? AND il.id=? AND ip.refund='yes'
                           ORDER BY ip.id DESC LIMIT 1");
    $pay->bind_param('ii', $user_id, $internship_id);
    $pay->execute();
    $payRow = $pay->get_result()->fetch_assoc();
    if ($payRow) {
        $batchLabel    = $payRow['batch'];
        $batchStart    = rl_parseBatch($payRow['batch']);
        $totalDuration = (int)$payRow['total_duration'];
    }

    /* active assignments for this internship, in step order */
    $assignments = []; $ids = [];
    $st = $conn->prepare("SELECT id, title FROM internship_assignments
                          WHERE internship_id=? AND status='active'
                          ORDER BY step_order ASC, id ASC");
    $st->bind_param('i', $internship_id);
    $st->execute();
    $ar = $st->get_result();
    while ($a = $ar->fetch_assoc()) {
        $assignments[] = ['id' => (int)$a['id'], 'title' => $a['title'], 'fields' => []];
        $ids[(int)$a['id']] = count($assignments) - 1;
    }

    /* active fields per assignment — so we can show "label: answer" pairs */
    if (!empty($ids)) {
        $in = implode(',', array_map('intval', array_keys($ids)));
        $fr = $conn->query("SELECT id, assignment_id, label, field_type, field_order
                            FROM internship_assignment_fields
                            WHERE assignment_id IN ($in) AND status='active'
                            ORDER BY field_order ASC, id ASC");
        if ($fr) {
            while ($f = $fr->fetch_assoc()) {
                $aid = (int)$f['assignment_id'];
                if (!isset($ids[$aid])) continue;
                $assignments[$ids[$aid]]['fields'][] = [
                    'id'         => (int)$f['id'],
                    'label'      => $f['label'],
                    'field_type' => $f['field_type'],
                ];
            }
        }
    }

    /* this student's submissions (assignment_id → submitted_at).
       The submissions table is created lazily by assignment_student_api.php —
       ensure it exists so this read never fatals on a fresh internship. */
    $subs = [];
    if (!empty($ids)) {
        $conn->query("CREATE TABLE IF NOT EXISTS internship_assignment_submissions (
            id            INT AUTO_INCREMENT PRIMARY KEY,
            user_id       INT NOT NULL,
            assignment_id INT NOT NULL,
            internship_id INT NOT NULL,
            values_json   LONGTEXT DEFAULT NULL,
            submitted_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            UNIQUE KEY uq_user_assignment (user_id, assignment_id),
            INDEX idx_user_internship (user_id, internship_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
        $sq = $conn->prepare("SELECT assignment_id, submitted_at, values_json
                              FROM internship_assignment_submissions
                              WHERE user_id=? AND internship_id=?");
        $sq->bind_param('ii', $user_id, $internship_id);
        $sq->execute();
        $sr = $sq->get_result();
        while ($s = $sr->fetch_assoc()) {
            $vals = json_decode($s['values_json'] ?? '', true);
            $subs[(int)$s['assignment_id']] = [
                'submitted_at' => $s['submitted_at'],
                'values'       => is_array($vals) ? $vals : [],
            ];
        }
    }

    $schedule = rl_assignmentSchedule($batchStart, $totalDuration, count($assignments));

    $out = [];
    foreach ($assignments as $i => $a) {
        $sch         = $schedule[$i] ?? [];
        $sub         = $subs[$a['id']] ?? null;
        $submittedAt = $sub['submitted_at'] ?? null;
        $values      = $sub['values'] ?? [];
        /* within = submitted on or before the deadline date (midnight compare,
           same as isSubmittedWithinDeadline). null = unknown. */
        $within = null;
        if ($submittedAt && !empty($sch['deadline_date'])) {
            $within = (substr($submittedAt, 0, 10) <= $sch['deadline_date']);
        }
        /* answers — one {label, type, value} per active field (view-only) */
        $answers = [];
        foreach ($a['fields'] as $f) {
            $answers[] = [
                'label'      => $f['label'],
                'field_type' => $f['field_type'],
                'value'      => $values[(string)$f['id']] ?? ($values[$f['id']] ?? null),
            ];
        }
        $out[] = [
            'step'            => $i + 1,
            'title'           => $a['title'],
            'unlock_date'     => $sch['unlock_date'] ?? null,
            'deadline_date'   => $sch['deadline_date'] ?? null,
            'submitted'       => $submittedAt ? true : false,
            'submitted_at'    => $submittedAt,
            'within_deadline' => $within,
            'answers'         => $answers,
        ];
    }

    api_success([
        'batch'       => $batchLabel,
        'has_batch'   => $batchStart ? true : false,
        'assignments' => $out,
    ]);
}

/* ─── GET: project timeline (submitted / resubmitted / approved / rejected) ─── */
if ($_SERVER['REQUEST_METHOD'] === 'GET' && ($_GET['action'] ?? '') === 'project_timeline') {
    $user_id       = (int)($_GET['user_id'] ?? 0);
    $internship_id = (int)($_GET['internship_id'] ?? 0);
    if (!$user_id || !$internship_id) api_error('Invalid parameters', 400);

    rl_ensureReviewLog($conn);

    /* base submission */
    $st = $conn->prepare("SELECT id, status, reject_reason, file_link, video_link, created_at, updated_at
                          FROM project_submission WHERE user_id=? AND internship_id=? ORDER BY id DESC LIMIT 1");
    $st->bind_param('ii', $user_id, $internship_id);
    $st->execute();
    $ps = $st->get_result()->fetch_assoc();

    $events = [];
    if ($ps && $ps['created_at']) {
        $events[] = ['type'=>'submitted', 'at'=>$ps['created_at'], 'reason'=>null, 'admin'=>null,
                     'file_link'=>$ps['file_link'], 'video_link'=>$ps['video_link']];
    }

    /* resubmissions — sourced from project_resubmission_log.submitted_at */
    $rs = $conn->prepare("SELECT submitted_at, file_link, video_link, within_duration
                          FROM project_resubmission_log WHERE user_id=? AND internship_id=?
                          ORDER BY submitted_at ASC, id ASC");
    $rs->bind_param('ii', $user_id, $internship_id);
    $rs->execute();
    $rsr = $rs->get_result();
    while ($r = $rsr->fetch_assoc()) {
        $events[] = ['type'=>'resubmitted', 'at'=>$r['submitted_at'], 'reason'=>null, 'admin'=>null,
                     'file_link'=>$r['file_link'], 'video_link'=>$r['video_link'],
                     'within_duration'=>$r['within_duration']];
    }

    /* admin decisions */
    $rl = $conn->prepare("SELECT prl.action, prl.reason, prl.event_at, u.name AS admin_name
                          FROM project_review_log prl
                          LEFT JOIN users u ON u.user_id = prl.admin_id
                          WHERE prl.user_id=? AND prl.internship_id=?
                          ORDER BY prl.event_at ASC, prl.id ASC");
    $rl->bind_param('ii', $user_id, $internship_id);
    $rl->execute();
    $rlr = $rl->get_result();
    $hasLog = false;
    while ($r = $rlr->fetch_assoc()) {
        $hasLog = true;
        $events[] = ['type'=>$r['action'], 'at'=>$r['event_at'], 'reason'=>$r['reason'], 'admin'=>$r['admin_name']];
    }

    /* legacy fallback: pre-log decisions — synthesize one event from ps */
    if (!$hasLog && $ps && in_array($ps['status'], ['approved','rejected'], true) && $ps['updated_at']) {
        $events[] = ['type'=>$ps['status'], 'at'=>$ps['updated_at'],
                     'reason'=>$ps['status']==='rejected' ? $ps['reject_reason'] : null,
                     'admin'=>null, 'legacy'=>true];
    }

    /* refund claim lifecycle — requested / rejected / approved (refunded) */
    $rcq = $conn->prepare("SELECT status, admin_notes, created_at, processed_at
                           FROM refund_claims WHERE user_id=? AND internship_id=? ORDER BY id DESC LIMIT 1");
    $rcq->bind_param('ii', $user_id, $internship_id);
    $rcq->execute();
    $rc = $rcq->get_result()->fetch_assoc();
    if ($rc) {
        if (!empty($rc['created_at'])) {
            $events[] = ['type'=>'refund_requested', 'at'=>$rc['created_at'], 'reason'=>null, 'admin'=>null];
        }
        $decidedAt = !empty($rc['processed_at']) ? $rc['processed_at'] : $rc['created_at'];
        if ($rc['status'] === 'refunded') {
            $events[] = ['type'=>'refund_approved', 'at'=>$decidedAt, 'reason'=>null, 'admin'=>null];
        } elseif ($rc['status'] === 'rejected') {
            $events[] = ['type'=>'refund_rejected', 'at'=>$decidedAt,
                         'reason'=>($rc['admin_notes'] !== '' ? $rc['admin_notes'] : null), 'admin'=>null];
        }
    }

    usort($events, function ($a, $b) { return strcmp((string)$a['at'], (string)$b['at']); });

    /* project deadline = batch start + full internship duration (last day),
       same window used by rl_calculateAttendance. */
    $deadline = null;
    $pay = $conn->prepare("SELECT ip.batch, ip.total_duration
                           FROM internship_payment ip
                           INNER JOIN internship_list il ON il.internship_name = ip.internship
                           WHERE ip.user_id=? AND il.id=? AND ip.refund='yes'
                           ORDER BY ip.id DESC LIMIT 1");
    $pay->bind_param('ii', $user_id, $internship_id);
    $pay->execute();
    $payRow = $pay->get_result()->fetch_assoc();
    if ($payRow && !empty($payRow['batch'])) {
        $cleanBatch = preg_replace('/(\d+)(st|nd|rd|th)/i', '$1', $payRow['batch']);
        try {
            $start = new DateTime($cleanBatch);
            $totalDays = rl_getDurationDays((int)$payRow['total_duration']);
            if ($totalDays <= 0) $totalDays = 30;
            $end = clone $start;
            $end->modify('+' . ($totalDays - 1) . ' days');
            $deadline = $end->format('Y-m-d');
        } catch (Exception $e) { $deadline = null; }
    }

    api_success([
        'has_submission' => $ps ? true : false,
        'current_status' => $ps['status'] ?? null,
        'deadline'       => $deadline,
        'events'         => $events,
    ]);
}

/* ─── GET: Fetch refund list ─── */
if ($_SERVER['REQUEST_METHOD'] === 'GET') {

    $page     = max(1, (int)($_GET['page'] ?? 1));
    $per_page = max(1, min(100, (int)($_GET['per_page'] ?? 20)));
    $search   = trim($_GET['search'] ?? '');
    $status   = trim($_GET['status'] ?? '');
    $batch    = trim($_GET['batch'] ?? '');
    $hasVideo = !empty($_GET['has_video']) && $_GET['has_video'] !== '0';
    $resubmitted = !empty($_GET['resubmitted']) && $_GET['resubmitted'] !== '0';
    /* assignment filter — '' (off) | 'submitted' (>=1 assignment) | 'both' (>=2) */
    $assignment = trim($_GET['assignment'] ?? '');

    /* The submissions table is created lazily by the student-side API; ensure it
       exists so the assignment subqueries below never fatal on a fresh DB. */
    $conn->query("CREATE TABLE IF NOT EXISTS internship_assignment_submissions (
        id            INT AUTO_INCREMENT PRIMARY KEY,
        user_id       INT NOT NULL,
        assignment_id INT NOT NULL,
        internship_id INT NOT NULL,
        values_json   LONGTEXT DEFAULT NULL,
        submitted_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        UNIQUE KEY uq_user_assignment (user_id, assignment_id),
        INDEX idx_user_internship (user_id, internship_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    /* Base SELECT & FROM */
    $selectCols = "ip.id AS payment_row_id, ip.user_id, u.name, u.email, u.phone AS contact,
        u.registered_at, ip.internship AS internship_name, il.id AS internship_id,
        ip.batch, ip.total_duration, ip.paid_at, ip.payment_id,
        ps.id AS ps_id, ps.status AS project_status, ps.file_link, ps.video_link,
        ps.created_at AS project_submitted_date,
        CASE WHEN ps.status='approved' THEN ps.updated_at END AS project_approved_date,
        /* Latest resubmission — sourced from the dedicated project_resubmission_log table. */
        (SELECT MAX(prl.submitted_at) FROM project_resubmission_log prl
            WHERE prl.user_id = ip.user_id AND prl.internship_id = il.id) AS project_resubmitted_date,
        /* Distinct assignments this student has submitted for this internship. */
        (SELECT COUNT(DISTINCT s.assignment_id) FROM internship_assignment_submissions s
            WHERE s.user_id = ip.user_id AND s.internship_id = il.id) AS assignment_count,
        rc.id AS claim_id, rc.status AS refund_claim_status, rc.admin_notes,
        rc.created_at AS claim_requested_date,
        rc.processed_at, rc.proof_url";

    $from = "FROM internship_payment ip
        INNER JOIN users u ON u.user_id = ip.user_id
        LEFT JOIN internship_list il ON il.internship_name = ip.internship
        LEFT JOIN refund_claims rc ON rc.user_id = ip.user_id AND rc.internship_id = il.id
        LEFT JOIN project_submission ps ON ps.user_id = ip.user_id AND ps.internship_id = il.id
        WHERE ip.refund = 'yes'";

    $params = [];
    $types  = '';
    $where  = '';

    /* Search filter */
    if ($search !== '') {
        $like = '%' . $search . '%';
        $where .= " AND (u.name LIKE ? OR u.email LIKE ? OR u.phone LIKE ? OR ip.internship LIKE ? OR ip.payment_id LIKE ?)";
        $params = array_merge($params, [$like, $like, $like, $like, $like]);
        $types .= 'sssss';
    }

    /* Batch filter */
    if ($batch !== '') {
        $where .= " AND ip.batch = ?";
        $params[] = $batch;
        $types .= 's';
    }

    /* Has-video filter */
    if ($hasVideo) {
        $where .= " AND ps.video_link IS NOT NULL AND ps.video_link != ''";
    }

    /* Resubmitted filter — matches the SELECT alias (project_resubmission_log) */
    if ($resubmitted) {
        $where .= " AND EXISTS (SELECT 1 FROM project_resubmission_log prl
                    WHERE prl.user_id = ip.user_id AND prl.internship_id = il.id)";
    }

    /* Assignment filter — submitted at least 1 (any), or both assignment 1 & 2 (>=2). */
    if ($assignment === 'submitted') {
        $where .= " AND EXISTS (SELECT 1 FROM internship_assignment_submissions s
                    WHERE s.user_id = ip.user_id AND s.internship_id = il.id)";
    } elseif ($assignment === 'both') {
        $where .= " AND (SELECT COUNT(DISTINCT s.assignment_id) FROM internship_assignment_submissions s
                    WHERE s.user_id = ip.user_id AND s.internship_id = il.id) >= 2";
    }

    /* Status filter (SQL-level) */
    $phpPostFilter = '';
    if ($status !== '' && !in_array($status, ['completed', 'active'])) {
        switch ($status) {
            case 'under_review':
                $where .= " AND rc.status = 'under_review'";
                break;
            case 'refunded':
                $where .= " AND rc.status = 'refunded'";
                break;
            case 'rejected':
                $where .= " AND rc.status = 'rejected'";
                break;
            case 'project_submitted':
                $where .= " AND ps.status = 'pending'";
                break;
            case 'project_approved':
                $where .= " AND ps.status = 'approved'";
                break;
            case 'project_rejected':
                $where .= " AND ps.status = 'rejected'";
                break;
        }
    } elseif ($status === 'completed' || $status === 'active') {
        $where .= " AND rc.id IS NULL";
        $phpPostFilter = $status;
    }

    $orderBy = " ORDER BY CASE WHEN rc.status = 'under_review' THEN 0 ELSE 1 END ASC, ip.paid_at DESC, u.name ASC";

    /* ── Stats: count each category from full result set ── */
    $statsWhere = '';
    $statsParams = [];
    $statsTypes  = '';
    if ($search !== '') {
        $statsWhere .= " AND (u.name LIKE ? OR u.email LIKE ? OR u.phone LIKE ? OR ip.internship LIKE ? OR ip.payment_id LIKE ?)";
        $statsParams = array_merge($statsParams, [$like, $like, $like, $like, $like]);
        $statsTypes .= 'sssss';
    }
    if ($batch !== '') {
        $statsWhere .= " AND ip.batch = ?";
        $statsParams[] = $batch;
        $statsTypes .= 's';
    }
    if ($hasVideo) {
        $statsWhere .= " AND ps.video_link IS NOT NULL AND ps.video_link != ''";
    }
    if ($resubmitted) {
        $statsWhere .= " AND EXISTS (SELECT 1 FROM project_resubmission_log prl
                         WHERE prl.user_id = ip.user_id AND prl.internship_id = il.id)";
    }

    $statsSql = "SELECT $selectCols $from $statsWhere $orderBy";
    $statsStmt = $conn->prepare($statsSql);
    if ($statsTypes) $statsStmt->bind_param($statsTypes, ...$statsParams);
    $statsStmt->execute();
    $allRows = $statsStmt->get_result()->fetch_all(MYSQLI_ASSOC);

    $statsCount = [
        'total' => 0, 'under_review' => 0, 'refunded' => 0, 'rejected' => 0,
        'completed' => 0, 'active' => 0,
        'project_submitted' => 0, 'project_approved' => 0, 'project_rejected' => 0,
        'assignment_submitted' => 0, 'assignment_both' => 0
    ];

    foreach ($allRows as &$row) {
        /* assignment-submission tallies (independent of the status buckets) */
        $ac = (int)($row['assignment_count'] ?? 0);
        if ($ac >= 1) $statsCount['assignment_submitted']++;
        if ($ac >= 2) $statsCount['assignment_both']++;

        /* Attendance needs a per-row DB query (correlated EXISTS on
           attendance_log). It only matters for APPROVED projects — to split
           "completed" (≥100%) from "project_approved" (<100%). Every other
           category ignores it. Computing it for the whole result set was an
           N+1 that made this list take ~20s; restrict it to approved rows. */
        $row['attendance'] = ($row['project_status'] === 'approved')
            ? rl_calculateAttendance($conn, $row['user_id'], $row['batch'], $row['total_duration'] ?? 0)
            : 0;
        $row['duration'] = rl_getDurationInMonths($row['total_duration']);

        $statsCount['total']++;

        if ($row['refund_claim_status'] === 'under_review') {
            $statsCount['under_review']++;
        } elseif ($row['refund_claim_status'] === 'refunded') {
            $statsCount['refunded']++;
        } elseif ($row['refund_claim_status'] === 'rejected') {
            $statsCount['rejected']++;
        } elseif ($row['project_status'] === 'pending') {
            $statsCount['project_submitted']++;
        } elseif ($row['project_status'] === 'approved') {
            if ($row['attendance'] >= 100) {
                $statsCount['completed']++;
            } else {
                $statsCount['project_approved']++;
            }
        } elseif ($row['project_status'] === 'rejected') {
            $statsCount['project_rejected']++;
        } else {
            // No claim, no project submission
            if (!$row['ps_id']) {
                $statsCount['active']++;
            }
        }
    }
    unset($row);

    /* ── CSV export — stream the FULL filtered set (ignores pagination) ──
       Applies the same status + assignment filters the list uses, in PHP,
       against $allRows (already filtered by search/batch/video/resubmitted),
       so the export always matches what the current filter shows on screen. */
    if (($_GET['action'] ?? '') === 'download_csv') {
        $csvRows = [];
        foreach ($allRows as $row) {
            $ac = (int)($row['assignment_count'] ?? 0);
            if ($assignment === 'submitted' && $ac < 1) continue;
            if ($assignment === 'both'      && $ac < 2) continue;

            switch ($status) {
                case 'under_review':      $keep = $row['refund_claim_status'] === 'under_review'; break;
                case 'refunded':          $keep = $row['refund_claim_status'] === 'refunded'; break;
                case 'rejected':          $keep = $row['refund_claim_status'] === 'rejected'; break;
                case 'project_submitted': $keep = $row['project_status'] === 'pending'; break;
                case 'project_approved':  $keep = $row['project_status'] === 'approved'; break;
                case 'project_rejected':  $keep = $row['project_status'] === 'rejected'; break;
                case 'completed':         $keep = empty($row['refund_claim_status']) && $row['project_status'] === 'approved' && ($row['attendance'] ?? 0) >= 100; break;
                case 'active':            $keep = empty($row['refund_claim_status']) && empty($row['ps_id']) && !($row['project_status'] === 'approved' && ($row['attendance'] ?? 0) >= 100); break;
                default:                  $keep = true; // '' = all statuses
            }
            if ($keep) $csvRows[] = $row;
        }

        set_time_limit(0);
        while (ob_get_level()) ob_end_clean();
        header('Content-Type: text/csv; charset=UTF-8');
        header('Content-Disposition: attachment; filename="refund_claims_' . date('Y-m-d') . '.csv"');
        echo "\xEF\xBB\xBF"; // UTF-8 BOM so Excel reads UTF-8 correctly

        $fp = fopen('php://output', 'w');
        fputcsv($fp, [
            'User ID','Name','Email','Contact','Internship','Duration','Batch',
            'Paid At','Attendance %','Assignments Submitted',
            'Project Status','Project Submitted','Project Approved','Resubmitted',
            'Refund Claim Status','Claim Requested','Processed At','Payment ID',
            'File Link','Video Link','Proof URL'
        ]);
        foreach ($csvRows as $row) {
            /* attendance is precomputed only for approved rows in the stats loop;
               compute on demand for the rest so the column matches the UI. */
            $att = ($row['project_status'] === 'approved')
                ? ($row['attendance'] ?? 0)
                : rl_calculateAttendance($conn, $row['user_id'], $row['batch'], $row['total_duration'] ?? 0);
            fputcsv($fp, [
                $row['user_id'],
                $row['name'],
                $row['email'],
                "\t" . ($row['contact'] ?? ''),       // leading tab keeps Excel from mangling the phone
                $row['internship_name'],
                $row['duration'] ?? rl_getDurationInMonths($row['total_duration']),
                $row['batch'],
                $row['paid_at'],
                $att,
                (int)($row['assignment_count'] ?? 0),
                $row['project_status'] ?? '',
                $row['project_submitted_date'] ?? '',
                $row['project_approved_date'] ?? '',
                $row['project_resubmitted_date'] ?? '',
                $row['refund_claim_status'] ?? '',
                $row['claim_requested_date'] ?? '',
                $row['processed_at'] ?? '',
                $row['payment_id'] ?? '',
                $row['file_link'] ?? '',
                $row['video_link'] ?? '',
                $row['proof_url'] ?? '',
            ]);
        }
        fclose($fp);
        exit;
    }

    /* ── Fetch filtered rows ── */
    if ($phpPostFilter !== '') {
        // completed or active requires PHP post-filtering
        $filtered = [];
        foreach ($allRows as $row) {
            if ($row['refund_claim_status']) continue; // has claim, skip

            /* keep the assignment sub-filter consistent in the PHP path too */
            $ac = (int)($row['assignment_count'] ?? 0);
            if ($assignment === 'submitted' && $ac < 1) continue;
            if ($assignment === 'both' && $ac < 2) continue;

            if ($phpPostFilter === 'completed') {
                if ($row['project_status'] === 'approved' && $row['attendance'] >= 100) {
                    $filtered[] = $row;
                }
            } elseif ($phpPostFilter === 'active') {
                // active = no claim, not completed, no project submission
                $isCompleted = ($row['project_status'] === 'approved' && $row['attendance'] >= 100);
                if (!$isCompleted && !$row['ps_id']) {
                    $filtered[] = $row;
                }
            }
        }
        $totalFiltered = count($filtered);
        $totalPages = max(1, ceil($totalFiltered / $per_page));
        $page = min($page, $totalPages);
        $offset = ($page - 1) * $per_page;
        $refunds = array_slice($filtered, $offset, $per_page);
    } else {
        // SQL-level filtering already done; re-query with LIMIT or slice from allRows
        // For status-filtered queries, we need a separate count + paginated fetch
        $countSql = "SELECT COUNT(*) AS cnt $from $where";
        $countStmt = $conn->prepare($countSql);
        if ($types) $countStmt->bind_param($types, ...$params);
        $countStmt->execute();
        $totalFiltered = (int)$countStmt->get_result()->fetch_assoc()['cnt'];

        $totalPages = max(1, ceil($totalFiltered / $per_page));
        $page = min($page, $totalPages);
        $offset = ($page - 1) * $per_page;

        $dataSql = "SELECT $selectCols $from $where $orderBy LIMIT ? OFFSET ?";
        $dataParams = $params;
        $dataTypes  = $types;
        $dataParams[] = $per_page;
        $dataParams[] = $offset;
        $dataTypes .= 'ii';

        $dataStmt = $conn->prepare($dataSql);
        $dataStmt->bind_param($dataTypes, ...$dataParams);
        $dataStmt->execute();
        $refunds = $dataStmt->get_result()->fetch_all(MYSQLI_ASSOC);

        // Calculate attendance and duration for paginated rows
        foreach ($refunds as &$row) {
            $row['attendance'] = rl_calculateAttendance($conn, $row['user_id'], $row['batch'], $row['total_duration'] ?? 0);
            $row['duration'] = rl_getDurationInMonths($row['total_duration']);
        }
        unset($row);
    }

    /* ── Batches ── */
    $batchSql = "SELECT DISTINCT ip.batch FROM internship_payment ip WHERE ip.refund = 'yes' AND ip.batch IS NOT NULL AND ip.batch != '' ORDER BY STR_TO_DATE(REGEXP_REPLACE(ip.batch, '(st|nd|rd|th)', ''), '%d %M, %Y') ASC";
    $batchResult = $conn->query($batchSql);
    $batches = [];
    while ($b = $batchResult->fetch_assoc()) {
        $batches[] = $b['batch'];
    }

    api_success([
        'refunds'     => $refunds,
        'total'       => $totalFiltered,
        'total_pages' => $totalPages,
        'page'        => $page,
        'batches'     => $batches,
        'stats'       => $statsCount,
    ]);
}

/* ─── POST: Handle actions ─── */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // Handle file upload (multipart) vs JSON body
    $action = $_POST['action'] ?? '';
    if (!$action) {
        $body = json_decode(file_get_contents('php://input'), true);
        $action = $body['action'] ?? '';
    } else {
        $body = $_POST;
    }

    switch ($action) {

        /* ── Update refund claim ── */
        case 'update_refund_claim':
            $user_id       = (int)($body['user_id'] ?? 0);
            $internship_id = (int)($body['internship_id'] ?? 0);
            $claimStatus   = $body['status'] ?? '';
            $admin_notes   = $body['admin_notes'] ?? '';
            $proof_url     = $body['proof_url'] ?? '';

            if (!$user_id || !$internship_id || !in_array($claimStatus, ['under_review', 'refunded', 'rejected'])) {
                api_error('Invalid parameters', 400);
            }

            $sql = "UPDATE refund_claims SET status=?, admin_notes=?, proof_url=?, processed_at=IF(? IN ('refunded','rejected'),NOW(),processed_at), updated_at=NOW() WHERE user_id=? AND internship_id=?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("ssssii", $claimStatus, $admin_notes, $proof_url, $claimStatus, $user_id, $internship_id);
            $stmt->execute();

            if ($stmt->affected_rows >= 0) {
                api_success([], 'Refund claim updated successfully');
            } else {
                api_error('Failed to update refund claim', 500);
            }
            break;

        /* ── Approve project ── */
        case 'approve_project':
            $user_id       = (int)($body['user_id'] ?? 0);
            $internship_id = (int)($body['internship_id'] ?? 0);

            if (!$user_id || !$internship_id) {
                api_error('Invalid parameters', 400);
            }

            $sql = "UPDATE project_submission SET status='approved', updated_at=NOW() WHERE user_id=? AND internship_id=?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("ii", $user_id, $internship_id);
            $stmt->execute();

            rl_logReview($conn, $user_id, $internship_id, 'approved', null, (int)($jwt['user_id'] ?? 0));

            api_success([], 'Project approved successfully');
            break;

        /* ── Decline project ── */
        case 'decline_project':
            $user_id       = (int)($body['user_id'] ?? 0);
            $internship_id = (int)($body['internship_id'] ?? 0);
            $reason        = $body['reason'] ?? '';

            if (!$user_id || !$internship_id) {
                api_error('Invalid parameters', 400);
            }

            $sql = "UPDATE project_submission SET status='rejected', reject_reason=?, updated_at=NOW() WHERE user_id=? AND internship_id=?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("sii", $reason, $user_id, $internship_id);
            $stmt->execute();

            rl_logReview($conn, $user_id, $internship_id, 'rejected', $reason, (int)($jwt['user_id'] ?? 0));

            api_success([], 'Project declined successfully');
            break;

        /* ── Send email ── via PHPMailer (SMTP), same config as send-otp.php
              because plain mail() silently drops messages on this host. */
        case 'send_email':
            $to      = trim($body['to'] ?? '');
            $subject = trim($body['subject'] ?? '');
            $html    = $body['html'] ?? '';
            $wrap    = !isset($body['wrap']) || !!$body['wrap'];   // default true

            if (!$to || !$subject || !$html) {
                api_error('Missing email parameters', 400);
            }

            $emailBody = $wrap ? rl_wrapEmail($html) : $html;

            // Load PHPMailer (same library used by main project)
            $phpmailer_loaded = false;
            foreach ([
                dirname(__DIR__, 3) . '/PHPMailer/src/',
                '/home/istudio/public_html/cit3/PHPMailer/src/',
            ] as $dir) {
                if (file_exists($dir . 'PHPMailer.php')) {
                    require_once $dir . 'Exception.php';
                    require_once $dir . 'PHPMailer.php';
                    require_once $dir . 'SMTP.php';
                    $phpmailer_loaded = true;
                    break;
                }
            }

            $sent = false;
            $err  = '';
            $via  = 'smtp';     // which path actually delivered it, for the send log
            $msgId = '';

            if ($phpmailer_loaded) {
                try {
                    $mail = new \PHPMailer\PHPMailer\PHPMailer(true);
                    $mail->isSMTP();
                    $mail->Host       = 'mailhost.internshipstudio.com';
                    $mail->SMTPAuth   = true;
                    $mail->Username   = 'contact@internshipstudio.com';
                    $mail->Password   = '5Hbe!j9rhbal~po1';
                    $mail->SMTPSecure = 'tls';
                    $mail->Port       = 587;
                    $mail->SMTPOptions = ['ssl' => [
                        'verify_peer' => false, 'verify_peer_name' => false, 'allow_self_signed' => true,
                    ]];
                    // UTF-8 so unicode dashes / emojis in subject + body don't garble.
                    $mail->CharSet  = 'UTF-8';
                    $mail->Encoding = 'base64';
                    $mail->setFrom('contact@internshipstudio.com', 'Internship Studio');
                    $mail->addAddress($to);
                    $mail->addReplyTo('contact@internshipstudio.com', 'Internship Studio');
                    $mail->isHTML(true);
                    $mail->Subject = $subject;
                    $mail->Body    = $emailBody;
                    $mail->AltBody = strip_tags($emailBody);
                    $sent = $mail->send();
                    if ($sent) $msgId = (string)$mail->getLastMessageID();
                } catch (\Throwable $e) {
                    $err = $e->getMessage() . (isset($mail) ? (' | ' . $mail->ErrorInfo) : '');
                }
            }

            // Fallback to plain mail() so the request still has a shot.
            // Subject must be MIME-encoded for non-ASCII chars (en-dash, emoji).
            if (!$sent) {
                $encodedSubject = function_exists('mb_encode_mimeheader')
                    ? mb_encode_mimeheader($subject, 'UTF-8', 'B')
                    : '=?UTF-8?B?' . base64_encode($subject) . '?=';
                $headers  = "MIME-Version: 1.0\r\n";
                $headers .= "Content-Type: text/html; charset=UTF-8\r\n";
                $headers .= "Content-Transfer-Encoding: 8bit\r\n";
                $headers .= "From: Internship Studio <contact@internshipstudio.com>\r\n";
                if (@mail($to, $encodedSubject, $emailBody, $headers)) {
                    $sent = true;
                    $via  = 'mail';
                } else {
                    $err .= ($err ? ' | ' : '') . 'mail() fallback failed';
                }
            }

            /* Record the send (or the failure) for Messaging analytics. The refund emails left no
               trace anywhere before this. Best-effort, guarded so a missing file on a partial
               deploy cannot break sending. */
            if (file_exists(__DIR__ . '/../lib/SmtpMailLog.php')) {
                require_once __DIR__ . '/../lib/SmtpMailLog.php';
                smtp_mail_log_record($conn, [
                    'module' => 'refunds', 'to_email' => $to, 'subject' => $subject,
                    'purpose' => (string)($body['purpose'] ?? ''), 'user_id' => (int)($body['user_id'] ?? 0),
                    'status' => $sent ? 'sent' : 'failed', 'transport' => $via, 'error' => $sent ? '' : $err,
                    'message_id' => $msgId, 'admin_id' => (int)($jwt['user_id'] ?? 0),
                ]);
            }

            if ($sent) {
                api_success([], 'Email sent successfully');
            } else {
                api_error('Failed to send email' . ($err ? (': ' . $err) : ''), 500);
            }
            break;

        /* ── Upload proof ── */
        case 'upload_proof':
            if (!isset($_FILES['proof']) || $_FILES['proof']['error'] !== UPLOAD_ERR_OK) {
                api_error('No file uploaded or upload error', 400);
            }

            $uploadDir = __DIR__ . '/../../uploads/refund_proofs/';
            if (!is_dir($uploadDir)) mkdir($uploadDir, 0755, true);
            $ext = pathinfo($_FILES['proof']['name'], PATHINFO_EXTENSION);
            $filename = 'proof_' . uniqid() . '.' . $ext;
            move_uploaded_file($_FILES['proof']['tmp_name'], $uploadDir . $filename);
            $url = 'https://cit3.internshipstudio.com/admin/react-api/uploads/refund_proofs/' . $filename;

            api_success(['url' => $url], 'Proof uploaded successfully');
            break;

        default:
            api_error('Unknown action', 400);
    }
}

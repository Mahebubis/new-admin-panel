<?php
/*
 * /api/freshdesk/lib/Automation.php
 *
 * THE RULES ENGINE
 *
 * A rule is: on EVENT, if every CONDITION holds, do these ACTIONS.
 *
 * Events
 *   ticket_created   a new ticket has just been opened by inbound mail
 *   ticket_updated   a reply, a note, a status/priority/agent change
 *   tag_added        a tag was put on a ticket
 *
 * Conditions combine by the rule's match_type: "all" (every condition must
 * hold, the default) or "any". Each is {field, op, value}; a field is read off the
 * ticket (or the message that triggered the run), an op compares, and the
 * value is what the agent typed. Everything is compared case-insensitively as
 * text, because that is what the rule author means by "subject contains mahhe".
 *
 * Actions are executed in order and each one is recorded. A failing action does
 * NOT abort the rest -- forwarding failing because SMTP is down should not also
 * stop the ticket being closed.
 *
 * MODULE SWITCHES
 * The four toggles on the Automation screen (auto close, forwarding, tagged
 * notifications, canned responses) gate the ACTIONS, not the rules. A rule can
 * stay on while its action type is switched off globally; the run is recorded
 * as skipped so the log explains why nothing happened.
 *
 * SAFETY
 *   - fd_automation_run() never throws. An automation is a convenience; it must
 *     not be able to stop mail being imported.
 *   - Each rule runs at most once per ticket per event, guarded by a row in
 *     fd_automation_log -- otherwise a rule that updates a ticket would trigger
 *     ticket_updated and re-run itself forever.
 */

/**
 * "a@b.com, c@d.com; e@f.com" -> an array of addresses.
 *
 * One place, because a rule author's comma habits should not decide whether
 * a forward or a notification reaches anyone. Anything that is not a valid
 * address is dropped rather than handed to the mail server.
 */
function fd_automation_addresses($value)
{
    $parts = is_array($value) ? $value : preg_split('/[,;\s]+/', (string)$value);
    $out = array();
    foreach ($parts as $p) {
        $p = trim((string)$p);
        if ($p !== '' && filter_var($p, FILTER_VALIDATE_EMAIL)) $out[] = $p;
    }
    return array_values(array_unique($out));
}

/** The module switches, read once per run. */
function fd_automation_modules()
{
    return array(
        'auto_close'   => (int)fd_cfg('AUTOMATION_AUTO_CLOSE', 1) === 1,
        'forwarding'   => (int)fd_cfg('AUTOMATION_FORWARDING', 1) === 1,
        'tagged_notif' => (int)fd_cfg('AUTOMATION_TAGGED_NOTIF', 1) === 1,
        'canned'       => (int)fd_cfg('AUTOMATION_CANNED', 1) === 1,
        'master'       => (int)fd_cfg('AUTOMATION_ENABLED', 1) === 1,
    );
}

/**
 * The value of one condition field for this ticket/message.
 * Always returns a string -- comparison is textual throughout.
 */
function fd_automation_field($field, $ticket, $message)
{
    switch ($field) {
        case 'subject':      return (string)$ticket['subject'];
        case 'description':  return (string)($message ? fd_html_to_text($message['body_html']) : '');
        case 'subject_or_description':
            return (string)$ticket['subject'] . ' ' . ($message ? fd_html_to_text($message['body_html']) : '');
        case 'from_email':   return (string)$ticket['requester_email'];
        case 'from_name':    return (string)$ticket['requester_name'];
        case 'status':       return (string)$ticket['status'];
        case 'priority':     return (string)$ticket['priority'];
        case 'category':     return (string)$ticket['category'];
        case 'agent':        return (string)$ticket['agent_name'];
        case 'tags':         return (string)$ticket['tags'];
        default:             return '';
    }
}

/** One condition. Case-insensitive throughout: rule authors think in words. */
function fd_automation_test($cond, $ticket, $message)
{
    $field = isset($cond['field']) ? $cond['field'] : 'subject';
    $op    = isset($cond['op']) ? $cond['op'] : 'contains';
    $want  = trim((string)(isset($cond['value']) ? $cond['value'] : ''));
    $have  = fd_automation_field($field, $ticket, $message);

    $h = mb_strtolower($have, 'UTF-8');
    $w = mb_strtolower($want, 'UTF-8');

    switch ($op) {
        case 'contains':      return $w !== '' && strpos($h, $w) !== false;
        case 'not_contains':  return $w === '' || strpos($h, $w) === false;
        case 'is':            return $h === $w;
        case 'is_not':        return $h !== $w;
        case 'starts_with':   return $w !== '' && strpos($h, $w) === 0;
        case 'ends_with':     return $w !== '' && substr($h, -strlen($w)) === $w;
        case 'is_empty':      return trim($h) === '';
        case 'is_not_empty':  return trim($h) !== '';
        case 'any_of':
            // "a, b, c" -- any one matching is enough.
            foreach (explode(',', $w) as $part) {
                $part = trim($part);
                if ($part !== '' && strpos($h, $part) !== false) return true;
            }
            return false;
        default:              return false;
    }
}

/**
 * Do this rule's conditions hold for this ticket?
 *
 * Shared with the dry-run endpoint, so "would this fire?" is answered by the
 * same code that decides whether it does fire.
 */
function fd_automation_matches($conds, $ticket, $message, $any = false)
{
    if (empty($conds)) return true;          // no conditions = every ticket
    if ($any) {
        foreach ($conds as $c) { if (fd_automation_test($c, $ticket, $message)) return true; }
        return false;
    }
    foreach ($conds as $c) { if (!fd_automation_test($c, $ticket, $message)) return false; }
    return true;
}

/**
 * Run every enabled rule for one event against one ticket.
 *
 * @param string $event  ticket_created | ticket_updated | tag_added
 * @return array summary for the caller's log
 */
function fd_automation_run($event, $ticketId, $messageId = null)
{
    $out = array('event' => $event, 'ticket' => (int)$ticketId, 'matched' => 0, 'actions' => 0, 'skipped' => array());
    try {
        $mods = fd_automation_modules();
        if (!$mods['master']) { $out['skipped'][] = 'automation-off'; return $out; }

        $ticket = fd_query_one("SELECT * FROM fd_tickets WHERE id = ?", 'i', array((int)$ticketId));
        if (!$ticket) return $out;

        $message = $messageId
            ? fd_query_one("SELECT * FROM fd_messages WHERE id = ?", 'i', array((int)$messageId))
            : fd_query_one("SELECT * FROM fd_messages WHERE ticket_id = ? ORDER BY id ASC LIMIT 1",
                           'i', array((int)$ticketId));

        $rules = fd_query("SELECT * FROM fd_automations
                           WHERE is_active = 1 AND event = ?
                           ORDER BY position ASC, id ASC", 's', array($event));

        foreach ($rules as $rule) {
            /*
             * Once per rule per ticket. Without this a rule whose action edits
             * the ticket fires ticket_updated, which re-runs the rule, which
             * edits the ticket...
             */
            $already = fd_query_one("SELECT id FROM fd_automation_log
                                     WHERE rule_id = ? AND ticket_id = ? LIMIT 1",
                                    'ii', array((int)$rule['id'], (int)$ticketId));
            if ($already) continue;

            $conds = json_decode((string)$rule['conditions'], true);
            if (!is_array($conds)) $conds = array();

            /*
             * match_type says how the conditions combine. "all" is the safe
             * default: a rule with no conditions matches every ticket either
             * way, but under "any" a half-written rule would fire on the first
             * condition alone, so an empty list is still treated as "matches".
             */
            $any = isset($rule['match_type']) && $rule['match_type'] === 'any';
            if (!fd_automation_matches($conds, $ticket, $message, $any)) continue;

            $out['matched']++;
            $done = fd_automation_apply($rule, $ticket, $message, $mods);
            $out['actions'] += count($done['applied']);
            foreach ($done['skipped'] as $sk) $out['skipped'][] = $sk;

            fd_exec("INSERT INTO fd_automation_log
                        (rule_id, rule_name, ticket_id, event, applied, skipped, created_at)
                     VALUES (?,?,?,?,?,?,NOW())",
                    'isssss', array((int)$rule['id'], $rule['name'], (int)$ticketId, $event,
                                    json_encode($done['applied']), json_encode($done['skipped'])));

            fd_exec("UPDATE fd_automations SET runs = runs + 1, last_run_at = NOW() WHERE id = ?",
                    'i', array((int)$rule['id']));

            // The ticket may have changed under us (status, tags); re-read so a
            // later rule in the same pass sees the current state.
            $ticket = fd_query_one("SELECT * FROM fd_tickets WHERE id = ?", 'i', array((int)$ticketId));
            if (!$ticket) break;
        }
    } catch (Throwable $e) {
        /*
         * An automation is a convenience. It must never be able to stop mail
         * being imported or a reply being sent, so every failure is logged and
         * swallowed.
         */
        $out['error'] = $e->getMessage();
        fd_log('error', 'Automation run failed: ' . $e->getMessage(),
               array('event' => $event, 'ticket' => $ticketId));
    }
    return $out;
}

/** Execute one rule's actions. Never throws; reports what it did and skipped. */
function fd_automation_apply($rule, $ticket, $message, $mods)
{
    $applied = array();
    $skipped = array();

    $actions = json_decode((string)$rule['actions'], true);
    if (!is_array($actions)) $actions = array();

    $ticketId = (int)$ticket['id'];

    foreach ($actions as $a) {
        $type  = isset($a['type']) ? $a['type'] : '';
        $value = isset($a['value']) ? $a['value'] : '';

        try {
            switch ($type) {

                /* ---- close / resolve ---- */
                case 'set_status':
                    $status = in_array($value, array('Open', 'Pending', 'Resolved', 'Closed', 'New'), true)
                        ? $value : 'Closed';
                    // Only "Closed"/"Resolved" belong to the auto-close module;
                    // reopening or setting Pending is plain triage.
                    if (in_array($status, array('Closed', 'Resolved'), true) && !$mods['auto_close']) {
                        $skipped[] = 'auto_close module off';
                        break;
                    }
                    $stamp = $status === 'Closed' ? ', closed_at = NOW()'
                           : ($status === 'Resolved' ? ', resolved_at = NOW()' : '');
                    fd_exec("UPDATE fd_tickets SET status = ?$stamp, updated_at = NOW() WHERE id = ?",
                            'si', array($status, $ticketId));
                    $applied[] = 'status -> ' . $status;
                    break;

                /* ---- priority ---- */
                case 'set_priority':
                    $p = in_array($value, array('Low', 'Medium', 'High', 'Urgent'), true) ? $value : 'Medium';
                    fd_exec("UPDATE fd_tickets SET priority = ?, updated_at = NOW() WHERE id = ?",
                            'si', array($p, $ticketId));
                    fd_sla_reprice($ticketId, $p);
                    $applied[] = 'priority -> ' . $p;
                    break;

                /* ---- assign ---- */
                case 'assign_agent':
                    $agent = fd_query_one("SELECT u.user_id, u.name FROM admin_users a
                                           INNER JOIN users u ON u.user_id = a.user_id
                                           WHERE a.is_active = 1 AND u.name = ? LIMIT 1", 's', array($value));
                    if (!$agent) { $skipped[] = 'no agent named "' . $value . '"'; break; }
                    fd_exec("UPDATE fd_tickets SET agent_user_id = ?, agent_name = ?, updated_at = NOW() WHERE id = ?",
                            'isi', array((int)$agent['user_id'], $agent['name'], $ticketId));
                    $applied[] = 'assigned to ' . $agent['name'];
                    break;

                /* ---- tag ---- */
                case 'add_tag':
                    $tags = json_decode((string)$ticket['tags'], true);
                    if (!is_array($tags)) $tags = array();
                    foreach (preg_split('/\s*,\s*/', (string)$value) as $tag) {
                        $tag = trim($tag);
                        if ($tag !== '' && !in_array($tag, $tags, true)) $tags[] = $tag;
                    }
                    fd_exec("UPDATE fd_tickets SET tags = ?, updated_at = NOW() WHERE id = ?",
                            'si', array(json_encode($tags), $ticketId));
                    $applied[] = 'tagged ' . $value;
                    break;

                /* ---- category ---- */
                case 'set_category':
                    fd_exec("UPDATE fd_tickets SET category = ?, updated_at = NOW() WHERE id = ?",
                            'si', array((string)$value, $ticketId));
                    $applied[] = 'category -> ' . $value;
                    break;

                /* ---- forward ---- */
                case 'forward':
                    if (!$mods['forwarding']) { $skipped[] = 'forwarding module off'; break; }
                    $to  = fd_automation_addresses($value);
                    $cc  = fd_automation_addresses(isset($a['cc'])  ? $a['cc']  : '');
                    $bcc = fd_automation_addresses(isset($a['bcc']) ? $a['bcc'] : '');
                    if (empty($to)) { $skipped[] = 'forward: no address'; break; }
                    $mailer = new FdMailer();
                    if (!$mailer->isReady()) { $skipped[] = 'forward: mailer unavailable'; break; }
                    // A covering note is optional; without one the forward says who sent it.
                    $note = isset($a['note']) ? trim((string)$a['note']) : '';
                    $mailer->sendTicketMessage(array(
                        'ticket_id' => $ticketId,
                        'type'      => 'forward',
                        'body_html' => $note !== ''
                            ? fd_compose_html(fd_apply_merge_tags($note, $ticket, array('id' => null, 'name' => 'Automation')))
                            : '<p>Forwarded automatically by the rule "'
                              . htmlspecialchars($rule['name'], ENT_QUOTES, 'UTF-8') . '".</p>',
                        'to'        => $to,
                        'cc'        => $cc,
                        'bcc'       => $bcc,
                        'agent'     => array('id' => null, 'name' => 'Automation'),
                        'include_signature' => false,
                        'quote_history'     => true,
                    ));
                    $applied[] = 'forwarded to ' . implode(', ', $to);
                    break;

                /* ---- notify (internal) ---- */
                case 'notify':
                    if (!$mods['tagged_notif']) { $skipped[] = 'notification module off'; break; }
                    $who = fd_automation_addresses($value);

                    /* The in-app alert always happens: it costs nothing and
                       does not depend on SMTP being up. */
                    fd_emit('automation-notify', array(
                        'ticket_id' => $ticketId,
                        'rule'      => $rule['name'],
                        'to'        => implode(', ', $who),
                    ), array(
                        'ticket_id' => $ticketId,
                        'summary'   => $rule['name'] . ': #' . $ticketId
                                     . (!empty($who) ? ' -> ' . implode(', ', $who) : ''),
                    ));

                    if (empty($who)) { $applied[] = 'notified the desk'; break; }

                    /*
                     * These go to your own staff, so they are sent plainly:
                     * not threaded onto the customer's ticket, not stored as
                     * a message on it, not filed in the Sent folder.
                     */
                    $tpl = isset($a['template']) && trim((string)$a['template']) !== ''
                        ? (string)$a['template']
                        : 'Ticket {Ticket ID} from {Customer Name} matched the rule "' . $rule['name'] . '".'
                          . "\n" . 'Subject: {Ticket Subject}'
                          . "\n" . 'Status: {Status} - Priority: {Priority}';
                    $html = fd_compose_html(
                        fd_apply_merge_tags($tpl, $ticket, array('id' => null, 'name' => 'Automation'))
                    );
                    $mailer = new FdMailer();
                    if (!$mailer->isReady()) { $skipped[] = 'notify: mailer unavailable'; break; }
                    $res = $mailer->sendPlain($who,
                        '[Ticket #' . $ticketId . '] ' . $rule['name'] . ' - ' . $ticket['subject'],
                        $html);
                    if (empty($res['ok'])) { $skipped[] = 'notify: ' . $res['message']; break; }
                    $applied[] = 'notified ' . implode(', ', $who);
                    break;

                /* ---- canned auto-reply ---- */
                case 'send_canned':
                    if (!$mods['canned']) { $skipped[] = 'canned module off'; break; }
                    $cr = ctype_digit((string)$value)
                        ? fd_query_one("SELECT * FROM fd_canned_responses WHERE id = ? AND is_active = 1",
                                       'i', array((int)$value))
                        : fd_query_one("SELECT * FROM fd_canned_responses WHERE name = ? AND is_active = 1 LIMIT 1",
                                       's', array((string)$value));
                    if (!$cr) { $skipped[] = 'canned response "' . $value . '" not found'; break; }
                    $mailer = new FdMailer();
                    if (!$mailer->isReady()) { $skipped[] = 'canned: mailer unavailable'; break; }
                    $body = fd_apply_merge_tags($cr['body'], $ticket, array('id' => null, 'name' => 'Support'));
                    $mailer->sendTicketMessage(array(
                        'ticket_id' => $ticketId,
                        'type'      => 'reply',
                        'body_html' => fd_compose_html($body, null),
                        'to'        => array($ticket['requester_email']),
                        'agent'     => array('id' => null, 'name' => 'Automation'),
                    ));
                    fd_exec("UPDATE fd_canned_responses SET uses = uses + 1 WHERE id = ?",
                            'i', array((int)$cr['id']));
                    $applied[] = 'sent canned ' . $cr['name'];
                    break;

                default:
                    $skipped[] = 'unknown action "' . $type . '"';
            }
        } catch (Throwable $e) {
            /*
             * One action failing must not abort the rest: a forward that fails
             * because SMTP is down should still leave the ticket closed.
             */
            $skipped[] = $type . ': ' . $e->getMessage();
            fd_log('warn', 'Automation action failed: ' . $e->getMessage(),
                   array('rule' => $rule['name'], 'action' => $type, 'ticket' => $ticketId));
        }
    }

    if (!empty($applied)) {
        fd_recount_ticket($ticketId);
        fd_sla_refresh($ticketId);
    }
    return array('applied' => $applied, 'skipped' => $skipped);
}

<?php
/*
 * KumoMTA module — configuration constants.
 *
 * This module is DELIBERATELY independent of the Netcore / email_campaigns
 * feature: it has its own tables (all prefixed `kumo_`), its own worker, its
 * own tracking endpoints and its own suppression list. Nothing in here reads
 * or writes an existing campaigns/netcore table except read-only SELECTs when
 * importing an audience.
 *
 * Every value below can be overridden at runtime from the `kumo_settings`
 * table (Settings screen) — the constants are only the fallback defaults, so
 * a deploy never resets what the panel configured.
 */

/* ── The bridge to the KumoMTA box ──────────────────────────────────────────
 * KumoMTA's HTTP injection API listens on 127.0.0.1:8000 on the mail server
 * and must never be exposed to the internet directly. The mail server runs an
 * nginx vhost (see SETUP.md) that terminates TLS, checks a bearer token and
 * proxies to that local port. This is the URL of that vhost.
 */
if (!defined('KUMO_BRIDGE_URL'))    define('KUMO_BRIDGE_URL',    'https://mailer.nitrocampus.com');
if (!defined('KUMO_BRIDGE_TOKEN'))  define('KUMO_BRIDGE_TOKEN',  '');   // set in kumo_settings
if (!defined('KUMO_BRIDGE_TIMEOUT'))define('KUMO_BRIDGE_TIMEOUT', 20);  // seconds per HTTP call

/* Shared secret for the machine-to-machine endpoints (webhook + worker HTTP
 * fallback). Not a user credential — just "this request really is ours".
 * KumoMTA's log hook must send it as ?secret=…  */
if (!defined('KUMO_CRON_SECRET')) {
    define('KUMO_CRON_SECRET', 'kumo_4b7f1e9c2a8d5036fe14c7b90d2a6538e1f4c7b0a9d2e5f8c1b4a7d0e3f6c9b2');
}

/* Public base URL for open/click/unsubscribe links. These are served by THIS
 * panel (react-api/api/kumo/track-*.php), not by the mail server, so they must
 * point at the panel host. Overridable from Settings → Tracking. */
if (!defined('KUMO_PUBLIC_BASE_URL')) {
    define('KUMO_PUBLIC_BASE_URL', 'https://cit3.internshipstudio.com/admin/react-api/api/kumo');
}

/* Secret used to sign unsubscribe / open / click tokens (HMAC-SHA256). */
if (!defined('KUMO_LINK_SECRET')) {
    define('KUMO_LINK_SECRET', 'kumo_lnk_5c8e2f7a1b9d4063ea27b5c8f1d4a7e0b3c6f9a2d5e8b1c4f7a0d3e6b9c2f5a8');
}

/* ── Send throughput ────────────────────────────────────────────────────────
 * KumoMTA does its own per-destination pacing and retries, so the panel only
 * has to hand it work in reasonably sized chunks. Injection is one HTTP call
 * per batch of recipients, which is why the batch can be large.
 */
if (!defined('KUMO_INJECT_BATCH'))        define('KUMO_INJECT_BATCH', 200);   // recipients per inject call
if (!defined('KUMO_CLAIM_BATCH'))         define('KUMO_CLAIM_BATCH', 1000);   // rows claimed per worker loop
if (!defined('KUMO_WORKER_MAX_SECONDS'))  define('KUMO_WORKER_MAX_SECONDS', 240);
if (!defined('KUMO_SEND_WINDOW_START'))   define('KUMO_SEND_WINDOW_START', 7);  // 07:00 local
if (!defined('KUMO_SEND_WINDOW_END'))     define('KUMO_SEND_WINDOW_END', 23);   // 23:00 local

/* ── Health thresholds (defaults; editable in Settings → Health) ────────────
 * A pool is scored on its worst signal: green → yellow → red.
 */
if (!defined('KUMO_TH_BOUNCE_YELLOW'))     define('KUMO_TH_BOUNCE_YELLOW', 1.0);   // %
if (!defined('KUMO_TH_BOUNCE_RED'))        define('KUMO_TH_BOUNCE_RED', 2.0);
if (!defined('KUMO_TH_COMPLAINT_YELLOW'))  define('KUMO_TH_COMPLAINT_YELLOW', 0.05);
if (!defined('KUMO_TH_COMPLAINT_RED'))     define('KUMO_TH_COMPLAINT_RED', 0.10);
if (!defined('KUMO_TH_DEFERRAL_YELLOW'))   define('KUMO_TH_DEFERRAL_YELLOW', 2.0);
if (!defined('KUMO_TH_DEFERRAL_RED'))      define('KUMO_TH_DEFERRAL_RED', 8.0);
/* Consecutive healthy hours required before an IP is allowed to move UP a colour. */
if (!defined('KUMO_RECOVERY_HOURS'))       define('KUMO_RECOVERY_HOURS', 6);
/* A red IP never resumes by itself — an admin must press Resume. */
if (!defined('KUMO_RED_NEEDS_MANUAL'))     define('KUMO_RED_NEEDS_MANUAL', true);

/* ── Warmup ────────────────────────────────────────────────────────────────
 * Day → daily cap per IP. Seeded into kumo_warmup_plan on first run and fully
 * editable from Settings → Warmup afterwards.
 */
function kumo_default_warmup_plan(): array {
    return [
        ['day_from' => 1,  'day_to' => 2,   'daily_cap' => 500],
        ['day_from' => 3,  'day_to' => 4,   'daily_cap' => 1000],
        ['day_from' => 5,  'day_to' => 6,   'daily_cap' => 2500],
        ['day_from' => 7,  'day_to' => 8,   'daily_cap' => 5000],
        ['day_from' => 9,  'day_to' => 10,  'daily_cap' => 10000],
        ['day_from' => 11, 'day_to' => 14,  'daily_cap' => 20000],
        ['day_from' => 15, 'day_to' => 18,  'daily_cap' => 35000],
        ['day_from' => 19, 'day_to' => 22,  'daily_cap' => 50000],
        ['day_from' => 23, 'day_to' => 26,  'daily_cap' => 75000],
        ['day_from' => 27, 'day_to' => 9999,'daily_cap' => 100000],
    ];
}

/* DNS blocklists checked per IP by the health worker. Spamhaus refuses queries
 * from public resolvers without a DQS key, so it is only queried when a key is
 * configured in Settings (kumo_settings.spamhaus_dqs_key). */
function kumo_dnsbl_zones(): array {
    return [
        'bl.spamcop.net'        => 'SpamCop',
        'b.barracudacentral.org'=> 'Barracuda',
        'psbl.surriel.com'      => 'PSBL',
        'dnsbl-1.uceprotect.net'=> 'UCEPROTECT-1',
    ];
}

/* Where the worker writes its own log (kept out of the web root). */
if (!defined('KUMO_WORKER_LOG')) define('KUMO_WORKER_LOG', __DIR__ . '/../worker.log');

function kumo_log(string $msg): void {
    @file_put_contents(KUMO_WORKER_LOG, '[' . date('Y-m-d H:i:s') . '] ' . $msg . "\n", FILE_APPEND | LOCK_EX);
}

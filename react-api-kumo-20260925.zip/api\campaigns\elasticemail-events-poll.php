<?php
/*
 * Elastic Email delivery-receipt poller — the PULL half of the pair described in
 * lib/ElasticEmailEventSink.php.
 *
 * Why this exists: webhooks are a PRO-plan feature at Elastic Email. Where Settings →
 * Notifications → "Manage webhooks" is padlocked there is no field anywhere in their
 * dashboard to give them our URL, so elasticemail-webhook.php is never called and
 * delivered_count / bounce_count sit at 0 however many emails actually arrive. GET /v4/events
 * carries the same receipts and is NOT plan-gated, so we fetch them on a schedule instead and
 * run them through the identical handler the webhook uses.
 *
 * Cron (every 5 minutes is a good default — see the retention note below). Written with an
 * explicit minute list rather than the usual step syntax because that spelling contains the
 * two characters that end a PHP block comment, which would truncate this header mid-sentence:
 *   0,5,10,15,20,25,30,35,40,45,50,55 * * * * /usr/local/bin/php /home/istudio/public_html/admin/react-api/api/campaigns/elasticemail-events-poll.php >> /home/istudio/logs/campaign-worker.log 2>&1
 *
 * HTTP fallback, same shared secret as campaign-send-worker.php (NOT a public endpoint):
 *   GET .../elasticemail-events-poll.php?cron_secret=...
 *
 * CLI flags:
 *   --since=2026-09-01T00:00:00   ignore the stored cursor and sweep from this UTC time
 *   --dry-run                     fetch and report, write nothing
 *
 * !! RETENTION is the one real weakness versus a webhook. A webhook pushes once and we either
 * take it or lose it; here, events older than Elastic Email's retention window are simply gone
 * from /v4/events. Probing this account, a send confirmed delivered in August had no events
 * left at all, so the window is real and short — but its exact length is not documented in
 * anything we can query, so treat it as "hours, not days". A poller that stops running for
 * longer than that loses those receipts permanently: delivered_count will under-report and no
 * later run can repair it. If the cron is ever disabled, expect a hole.
 *
 * !! ONE-TIME NOTE if you are switching FROM a working webhook TO this poller: the first run
 * has no cursor and sweeps the last 24 hours, which would re-count receipts the webhook had
 * already counted for any recipient whose delivered_at is still NULL (i.e. every recipient
 * from before the deploy that added that column). Start it with
 *     php elasticemail-events-poll.php --since=<the current UTC time>
 * once, which writes a cursor without re-reading history. Accounts that never had webhooks —
 * the reason this file exists — have nothing to avoid and can just let cron start it.
 */
// ini_set('display_errors', 0);
// error_reporting(E_ALL & ~E_WARNING & ~E_NOTICE & ~E_DEPRECATED);
// $_SERVER['REQUEST_METHOD'] = $_SERVER['REQUEST_METHOD'] ?? 'CLI';

// // Same guard, and for the same reason, as campaign-send-worker.php: PHP 8.1+ makes mysqli
// // throw on connection failure, and with display_errors off that would vanish without trace.
// try {
//     require_once __DIR__ . '/../../config/database.php';
// } catch (\Throwable $e) {
//     @file_put_contents(__DIR__ . '/worker.log', '[' . date('Y-m-d H:i:s') . '] [ee-poll] FATAL — could not connect to the database: '
//         . '[' . get_class($e) . '] ' . $e->getMessage() . "\n", FILE_APPEND | LOCK_EX);
//     exit;
// }

// require_once __DIR__ . '/lib/config.php';
// require_once __DIR__ . '/lib/schema.php';
// require_once __DIR__ . '/lib/ElasticEmailEventSink.php';

// campaigns_ensure_schema();

// /** How far back to re-read on every run. Cheap insurance: an event written a moment after a
//  *  run read up to "now" would otherwise fall in the gap between that run and the next. Every
//  *  write in the sink is idempotent, so re-reading costs an HTTP page, never a wrong number. */
// const EE_POLL_OVERLAP_SECONDS = 900;      // 15 min
// /**
//  * The oldest event this poller will ever ask for, whatever the cursor says.
//  *
//  * Two things this bounds:
//  *   • a cold start, which has no cursor at all;
//  *   • a stale cursor — if the poller stops for a month and then restarts, that
//  *     cursor is a month old, and without this the run would page through
//  *     everything since.
//  *
//  * Elastic Email's own retention is far shorter than this ("hours, not days" per
//  * the note at the top of this file), so in practice the API returns nothing
//  * near the far edge. The bound exists to keep a pathological run finite, not
//  * because there is data out there to find.
//  *
//  * Declared before the constants that use it: PHP evaluates a const expression
//  * where it stands, so referencing one defined further down is a fatal error.
//  */
// const EE_POLL_MAX_LOOKBACK_DAYS = 39;
// const EE_POLL_MAX_LOOKBACK_SECONDS = EE_POLL_MAX_LOOKBACK_DAYS * 86400;

// /** First-ever run has no cursor — sweep the whole permitted window. */
// const EE_POLL_COLD_START_SECONDS = EE_POLL_MAX_LOOKBACK_SECONDS;

// const EE_POLL_PAGE_SIZE = 500;
// /** Stops a pathological run (clock skew, a retention window far larger than expected) from
//  *  paging forever. 200 pages x 500 = 100k events, far beyond any real one-minute delta. */
// const EE_POLL_MAX_PAGES = 200;

// $isCli = (php_sapi_name() === 'cli');
// $isAuthorizedHttp = !$isCli && ($_GET['cron_secret'] ?? '') === CRON_SECRET;
// if (!$isCli && !$isAuthorizedHttp) {
//     http_response_code(403);
//     echo "forbidden\n";
//     exit;
// }

// $dryRun   = false;
// $sinceArg = null;
// if ($isCli && !empty($argv)) {
//     foreach ($argv as $a) {
//         if ($a === '--dry-run') $dryRun = true;
//         if (strpos($a, '--since=') === 0) $sinceArg = substr($a, 8);
//     }
// }

// function ee_poll_log(string $msg): void {
//     @file_put_contents(WORKER_LOG_PATH, '[' . date('Y-m-d H:i:s') . '] [ee-poll] ' . $msg . "\n", FILE_APPEND | LOCK_EX);
// }

// /*
//  * Exclusive lock. Two overlapping runs would not corrupt anything — the sink's writes are
//  * idempotent, which is the whole point — but they would double the API calls for no gain,
//  * and a slow run overlapping the next cron tick is exactly what happens during a backlog.
//  */
// $lockFp = @fopen(sys_get_temp_dir() . '/ee_events_poll.lock', 'c');
// if (!$lockFp || !flock($lockFp, LOCK_EX | LOCK_NB)) {
//     ee_poll_log('skip — another poll run is already in progress');
//     exit;
// }
// @set_time_limit(0);
// ignore_user_abort(true);

// /* ------------------------------------------------------------------ *
//  * Credentials + cursor
//  * ------------------------------------------------------------------ */
// $row = null;
// $r = $conn->query("SELECT api_key, extra_config FROM email_esp_settings WHERE provider='elasticemail' LIMIT 1");
// if ($r) $row = $r->fetch_assoc();
// $apiKey = (string)($row['api_key'] ?? '');
// if ($apiKey === '' || $apiKey === 'DUMMY_ELASTICEMAIL_API_KEY') {
//     ee_poll_log('skip — no Elastic Email API key configured');
//     exit;
// }

// $extra  = json_decode((string)($row['extra_config'] ?? ''), true);
// if (!is_array($extra)) $extra = [];
// $cursor = isset($extra['events_cursor']) ? (string)$extra['events_cursor'] : '';

// /*
//  * Everything below is UTC. /v4/events both returns EventDate as ...Z and interprets from/to
//  * as UTC, while PHP here runs on Asia/Kolkata (set in config/database.php) — so building a
//  * window with date() instead of gmdate() would shift it 5.5 hours and silently miss events.
//  */
// if ($sinceArg) {
//     $sinceTs = strtotime($sinceArg . ' UTC');
//     if (!$sinceTs) { ee_poll_log("abort — could not parse --since=$sinceArg"); exit; }
// } elseif ($cursor !== '' && ($cursorTs = strtotime($cursor)) !== false) {
//     $sinceTs = $cursorTs - EE_POLL_OVERLAP_SECONDS;
// } else {
//     $sinceTs = time() - EE_POLL_COLD_START_SECONDS;
// }

// /*
//  * The floor, applied to every path above including an explicit --since.
//  *
//  * Without it a cursor left behind by a poller that stopped weeks ago would make
//  * the next run page back over all of that time — thousands of requests for
//  * events Elastic Email deleted long before, on a job that now runs every minute
//  * and would still be paging when the next tick started.
//  */
// $floorTs = time() - EE_POLL_MAX_LOOKBACK_SECONDS;
// if ($sinceTs < $floorTs) {
//     ee_poll_log(sprintf(
//         'window clamped to the last %d day(s): requested %sZ, using %sZ',
//         EE_POLL_MAX_LOOKBACK_DAYS,
//         gmdate('Y-m-d\TH:i:s', $sinceTs),
//         gmdate('Y-m-d\TH:i:s', $floorTs)
//     ));
//     $sinceTs = $floorTs;
// }

// $from  = gmdate('Y-m-d\TH:i:s', $sinceTs);
// $toTs  = time();
// $runTo = gmdate('Y-m-d\TH:i:s', $toTs);
// ee_poll_log("run start — window {$from}Z .. {$runTo}Z" . ($cursor !== '' ? " (cursor $cursor)" : ' (cold start, no cursor)') . ($dryRun ? ' [DRY RUN]' : ''));

// /* ------------------------------------------------------------------ *
//  * Fetch
//  * ------------------------------------------------------------------ */
// /** One page of /v4/events. Returns [decodedArray|null, httpStatus, curlError]. */
// function ee_fetch_events(string $apiKey, string $from, string $to, int $limit): array {
//     // Sent = provider-confirmed delivery; Error/Bounce = failures. 'Submission' is omitted
//     // deliberately: it only says the API accepted our call, which sent_count already records,
//     // and including it would double the volume every page has to carry.
//     $url = 'https://api.elasticemail.com/v4/events'
//          . '?from=' . rawurlencode($from)
//          . '&to='   . rawurlencode($to)
//          . '&eventTypes=Sent,Error,Bounce'
//          . '&limit=' . $limit;
//     $ch = curl_init($url);
//     curl_setopt_array($ch, [
//         CURLOPT_RETURNTRANSFER => true,
//         CURLOPT_TIMEOUT        => 30,
//         CURLOPT_HTTPHEADER     => ['X-ElasticEmail-ApiKey: ' . $apiKey],
//     ]);
//     $body   = curl_exec($ch);
//     $status = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
//     $err    = curl_error($ch);
//     curl_close($ch);
//     if ($err !== '' || $status !== 200) return [null, $status, $err];
//     $decoded = json_decode((string)$body, true);
//     return [is_array($decoded) ? $decoded : null, $status, ''];
// }

// $pageTo    = $runTo;
// $pages     = 0;
// $seen      = 0;
// $handled   = 0;
// $newestTs  = 0;
// $failed    = false;

// while ($pages < EE_POLL_MAX_PAGES) {
//     [$events, $status, $err] = ee_fetch_events($apiKey, $from, $pageTo, EE_POLL_PAGE_SIZE);
//     $pages++;
//     if ($events === null) {
//         // Do NOT advance the cursor on a failed run — the next tick must re-read this window
//         // rather than skipping past receipts we never actually saw.
//         ee_poll_log("abort — GET /v4/events failed (HTTP $status" . ($err !== '' ? ", curl: $err" : '') . '); cursor left unchanged');
//         $failed = true;
//         break;
//     }
//     if (!$events) break;

//     $oldestOnPage = null;
//     foreach ($events as $evt) {
//         if (!is_array($evt)) continue;
//         $seen++;

//         $type      = strtolower(trim((string)($evt['EventType'] ?? '')));
//         $eventDate = (string)($evt['EventDate'] ?? '');
//         $ts        = $eventDate !== '' ? strtotime($eventDate) : false;
//         if ($ts !== false) {
//             if ($ts > $newestTs) $newestTs = $ts;
//             if ($oldestOnPage === null || $ts < $oldestOnPage) $oldestOnPage = $ts;
//         }

//         /*
//          * Translate /v4/events' vocabulary into the WEBHOOK's, which is the only one the sink
//          * knows. Both 'Error' and 'Bounce' become the webhook's 'error' — it has a single
//          * failure status and classifies hard vs soft from the category, not from the type.
//          *
//          * There is no `postback` here (the events API does not return it), so correlation runs
//          * entirely on MsgID → email_campaign_recipients.esp_message_id, which the transport
//          * stored from the send response.
//          */
//         $status2 = ($type === 'sent') ? 'sent' : (($type === 'error' || $type === 'bounce') ? 'error' : '');
//         if ($status2 === '') continue;

//         if ($dryRun) { $handled++; continue; }
//         if (ee_handle_event([
//             'status'    => $status2,
//             'category'  => (string)($evt['MessageCategory'] ?? ''),
//             'messageid' => (string)($evt['MsgID'] ?? ''),
//             'postback'  => '',
//             // Carried through verbatim so the raw provider payload lands in
//             // email_campaign_events.meta for bounces, exactly as the webhook stores it.
//             'raw'       => $evt,
//         ])) $handled++;
//     }

//     // /v4/events ignores `offset` entirely (verified: limit=5&offset=5 returns the same first
//     // five rows) and orders newest-first, so paging has to walk the UPPER bound backwards
//     // instead. A short page means the window is exhausted.
//     if (count($events) < EE_POLL_PAGE_SIZE || $oldestOnPage === null) break;
//     $nextTo = gmdate('Y-m-d\TH:i:s', $oldestOnPage);
//     // A full page whose events all share one second would otherwise re-request the same page
//     // forever; step back a second to guarantee progress.
//     if ($nextTo === $pageTo) $nextTo = gmdate('Y-m-d\TH:i:s', $oldestOnPage - 1);
//     $pageTo = $nextTo;
// }

// if ($pages >= EE_POLL_MAX_PAGES) {
//     ee_poll_log('warning — hit the ' . EE_POLL_MAX_PAGES . '-page ceiling; the remaining backlog is picked up next run');
// }

// /* ------------------------------------------------------------------ *
//  * Advance the cursor
//  * ------------------------------------------------------------------ */
// if (!$failed && !$dryRun) {
//     /*
//      * The cursor is the newest EventDate actually seen, not $runTo. Elastic Email may register
//      * an event slightly after it happened, and storing "the time we asked" would step over
//      * anything that landed in between. With no events at all, the cursor stays put and the
//      * overlap window simply widens on the next run.
//      */
//     if ($newestTs > 0) {
//         $newCursor = gmdate('Y-m-d\TH:i:s\Z', $newestTs);
//         $extra['events_cursor'] = $newCursor;
//         $extraE = $conn->real_escape_string(json_encode($extra));
//         $conn->query("UPDATE email_esp_settings SET extra_config = '$extraE' WHERE provider='elasticemail'");
//         ee_poll_log("cursor advanced to $newCursor");
//     }
// }

// ee_poll_log("run finished — $pages page(s), $seen event(s) fetched, $handled applied"
//     . ($dryRun ? ' (dry run, nothing written)' : ''));




















/*
 * Elastic Email delivery-receipt poller — the PULL half of the pair described in
 * lib/ElasticEmailEventSink.php.
 *
 * Why this exists: webhooks are a PRO-plan feature at Elastic Email. Where Settings →
 * Notifications → "Manage webhooks" is padlocked there is no field anywhere in their
 * dashboard to give them our URL, so elasticemail-webhook.php is never called and
 * delivered_count / bounce_count sit at 0 however many emails actually arrive. GET /v4/events
 * carries the same receipts and is NOT plan-gated, so we fetch them on a schedule instead and
 * run them through the identical handler the webhook uses.
 *
 * Cron: EVERY MINUTE now, not every five. See the Pacing section further down — one run stays
 * alive for just under a minute and polls every 10 seconds while a campaign is actually
 * delivering, so an every-minute tick means continuous coverage rather than 60x the API calls.
 * An idle tick still costs exactly one request, as it always did.
 *   * * * * * /usr/local/bin/php /home/istudio/public_html/admin/react-api/api/campaigns/elasticemail-events-poll.php >> /home/istudio/logs/campaign-worker.log 2>&1
 *
 * If it is still on the old five-minute schedule, Delivered cannot move faster than that no
 * matter what this file does — that lag is the cron, not the code. Replace the line above.
 *
 * HTTP fallback, same shared secret as campaign-send-worker.php (NOT a public endpoint):
 *   GET .../elasticemail-events-poll.php?cron_secret=...
 *
 * CLI flags:
 *   --since=2026-09-01T00:00:00   ignore the stored cursor and sweep from this UTC time
 *   --dry-run                     fetch and report, write nothing
 *
 * !! RETENTION is the one real weakness versus a webhook. A webhook pushes once and we either
 * take it or lose it; here, events older than Elastic Email's retention window are simply gone
 * from /v4/events. Probing this account, a send confirmed delivered in August had no events
 * left at all, so the window is real and short — but its exact length is not documented in
 * anything we can query, so treat it as "hours, not days". A poller that stops running for
 * longer than that loses those receipts permanently: delivered_count will under-report and no
 * later run can repair it. If the cron is ever disabled, expect a hole.
 *
 * !! ONE-TIME NOTE if you are switching FROM a working webhook TO this poller: the first run
 * has no cursor and sweeps the last 24 hours, which would re-count receipts the webhook had
 * already counted for any recipient whose delivered_at is still NULL (i.e. every recipient
 * from before the deploy that added that column). Start it with
 *     php elasticemail-events-poll.php --since=<the current UTC time>
 * once, which writes a cursor without re-reading history. Accounts that never had webhooks —
 * the reason this file exists — have nothing to avoid and can just let cron start it.
 */
ini_set('display_errors', 0);
error_reporting(E_ALL & ~E_WARNING & ~E_NOTICE & ~E_DEPRECATED);
$_SERVER['REQUEST_METHOD'] = $_SERVER['REQUEST_METHOD'] ?? 'CLI';

// Same guard, and for the same reason, as campaign-send-worker.php: PHP 8.1+ makes mysqli
// throw on connection failure, and with display_errors off that would vanish without trace.
try {
    require_once __DIR__ . '/../../config/database.php';
} catch (\Throwable $e) {
    @file_put_contents(__DIR__ . '/worker.log', '[' . date('Y-m-d H:i:s') . '] [ee-poll] FATAL — could not connect to the database: '
        . '[' . get_class($e) . '] ' . $e->getMessage() . "\n", FILE_APPEND | LOCK_EX);
    exit;
}

require_once __DIR__ . '/lib/config.php';
require_once __DIR__ . '/lib/schema.php';
require_once __DIR__ . '/lib/ElasticEmailEventSink.php';

campaigns_ensure_schema();

/** How far back to re-read on every run. Cheap insurance: an event written a moment after a
 *  run read up to "now" would otherwise fall in the gap between that run and the next. Every
 *  write in the sink is idempotent, so re-reading costs an HTTP page, never a wrong number. */
const EE_POLL_OVERLAP_SECONDS = 900;      // 15 min
/**
 * The oldest event this poller will ever ask for, whatever the cursor says.
 *
 * Two things this bounds:
 *   • a cold start, which has no cursor at all;
 *   • a stale cursor — if the poller stops for a month and then restarts, that
 *     cursor is a month old, and without this the run would page through
 *     everything since.
 *
 * Elastic Email's own retention is far shorter than this ("hours, not days" per
 * the note at the top of this file), so in practice the API returns nothing
 * near the far edge. The bound exists to keep a pathological run finite, not
 * because there is data out there to find.
 *
 * Declared before the constants that use it: PHP evaluates a const expression
 * where it stands, so referencing one defined further down is a fatal error.
 */
const EE_POLL_MAX_LOOKBACK_DAYS = 39;
const EE_POLL_MAX_LOOKBACK_SECONDS = EE_POLL_MAX_LOOKBACK_DAYS * 86400;

/** First-ever run has no cursor — sweep the whole permitted window. */
const EE_POLL_COLD_START_SECONDS = EE_POLL_MAX_LOOKBACK_SECONDS;

const EE_POLL_PAGE_SIZE = 500;
/** Stops a pathological run (clock skew, a retention window far larger than expected) from
 *  paging forever. 200 pages x 500 = 100k events, far beyond any real one-minute delta. */
const EE_POLL_MAX_PAGES = 200;

$isCli = (php_sapi_name() === 'cli');
$isAuthorizedHttp = !$isCli && ($_GET['cron_secret'] ?? '') === CRON_SECRET;
if (!$isCli && !$isAuthorizedHttp) {
    http_response_code(403);
    echo "forbidden\n";
    exit;
}

$dryRun   = false;
$sinceArg = null;
if ($isCli && !empty($argv)) {
    foreach ($argv as $a) {
        if ($a === '--dry-run') $dryRun = true;
        if (strpos($a, '--since=') === 0) $sinceArg = substr($a, 8);
    }
}

function ee_poll_log(string $msg): void {
    @file_put_contents(WORKER_LOG_PATH, '[' . date('Y-m-d H:i:s') . '] [ee-poll] ' . $msg . "\n", FILE_APPEND | LOCK_EX);
}

/*
 * Exclusive lock. Two overlapping runs would not corrupt anything — the sink's writes are
 * idempotent, which is the whole point — but they would double the API calls for no gain,
 * and a slow run overlapping the next cron tick is exactly what happens during a backlog.
 */
$lockFp = @fopen(sys_get_temp_dir() . '/ee_events_poll.lock', 'c');
if (!$lockFp || !flock($lockFp, LOCK_EX | LOCK_NB)) {
    ee_poll_log('skip — another poll run is already in progress');
    exit;
}
@set_time_limit(0);
ignore_user_abort(true);

/* ------------------------------------------------------------------ *
 * Credentials + cursor
 * ------------------------------------------------------------------ */
$row = null;
$r = $conn->query("SELECT api_key, extra_config FROM email_esp_settings WHERE provider='elasticemail' LIMIT 1");
if ($r) $row = $r->fetch_assoc();
$apiKey = (string)($row['api_key'] ?? '');
if ($apiKey === '' || $apiKey === 'DUMMY_ELASTICEMAIL_API_KEY') {
    ee_poll_log('skip — no Elastic Email API key configured');
    exit;
}

$extra  = json_decode((string)($row['extra_config'] ?? ''), true);
if (!is_array($extra)) $extra = [];
/* ------------------------------------------------------------------ *
 * Pacing
 * ------------------------------------------------------------------ *
 *
 * WHY THIS FILE NOW LOOPS
 *
 * Delivery receipts for email are PULLED, not pushed: Elastic Email's webhooks are a PRO-plan
 * feature, so on this account GET /v4/events is the only source. That makes the poll interval a
 * hard floor on how fresh Delivered can ever be — on a five-minute cron, a campaign sent at
 * 17:55 and looked at 17:58 shows whatever the 17:55 run happened to catch and nothing more,
 * which reads on the dashboard as "stuck at 631 while Elastic Email says 1,038".
 *
 * Running once per cron tick and exiting cannot fix that; the tick IS the delay. So a run now
 * stays alive for just under a minute and polls repeatedly inside that window.
 *
 * ADAPTIVE, because a fixed fast interval would be wrong in both directions. Polling every ten
 * seconds around the clock is ~8,600 API calls a day, almost all of them returning nothing, on
 * an endpoint with rate limits worth respecting. Polling slowly is exactly the problem being
 * fixed. So the cadence follows the only thing that matters: whether anything was actually sent
 * recently enough for receipts to still be arriving.
 *
 *   a campaign sending, or finished within EE_POLL_ACTIVE_WINDOW  →  poll every 10s
 *   nothing active                                                →  one poll, then exit
 *
 * Idle ticks therefore cost exactly what they did before this change.
 */

/** Gap between polls while a campaign is actively delivering. */
const EE_POLL_ACTIVE_INTERVAL = 10;

/** How long after a campaign finishes sending to keep polling fast. Receipts keep arriving for
 *  a while after the last message leaves — this is the window where the dashboard is being
 *  watched and the number is expected to move. */
const EE_POLL_ACTIVE_WINDOW = 1800;   // 30 min

/** Ceiling for one invocation, just under the cron minute so ticks never pile up behind
 *  each other (the flock above would drop them anyway, but silently). */
const EE_POLL_MAX_RUNTIME = 55;

/**
 * Is anything sending right now, or finished recently enough that receipts are still landing?
 *
 * Wrapped: a schema older than the column list here must cost a slower poll, never a dead
 * poller — mysqli throws on PHP 8.1+ and this runs before any receipt is fetched.
 */
function ee_poll_is_active(): bool {
    global $conn;
    try {
        $r = $conn->query("SELECT 1 FROM email_campaigns
                            WHERE status = 'running'
                               OR (completed_at IS NOT NULL
                                   AND completed_at >= DATE_SUB(NOW(), INTERVAL " . (int)EE_POLL_ACTIVE_WINDOW . " SECOND))
                            LIMIT 1");
        return (bool)($r && $r->fetch_row());
    } catch (\Throwable $e) {
        return false;
    }
}

/* ------------------------------------------------------------------ *
 * Fetch
 * ------------------------------------------------------------------ */

/* ------------------------------------------------------------------ *
 * Fetch
 * ------------------------------------------------------------------ */
/** One page of /v4/events. Returns [decodedArray|null, httpStatus, curlError]. */
function ee_fetch_events(string $apiKey, string $from, string $to, int $limit, int $offset = 0): array {
    // Sent = provider-confirmed delivery; Error/Bounce = failures. 'Submission' is omitted
    // deliberately: it only says the API accepted our call, which sent_count already records,
    // and including it would double the volume every page has to carry.
    $url = 'https://api.elasticemail.com/v4/events'
         . '?from=' . rawurlencode($from)
         . '&to='   . rawurlencode($to)
         . '&eventTypes=Sent,Error,Bounce'
         . '&limit=' . $limit
         . ($offset > 0 ? '&offset=' . $offset : '');
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT        => 30,
        CURLOPT_HTTPHEADER     => ['X-ElasticEmail-ApiKey: ' . $apiKey],
    ]);
    $body   = curl_exec($ch);
    $status = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $err    = curl_error($ch);
    curl_close($ch);
    if ($err !== '' || $status !== 200) return [null, $status, $err];
    $decoded = json_decode((string)$body, true);
    return [is_array($decoded) ? $decoded : null, $status, ''];
}
/**
 * One complete poll: work out the window from the stored cursor, page through /v4/events,
 * hand every receipt to the sink, and advance the cursor.
 *
 * The body is unchanged from when this ran once per process — only its surroundings moved. It
 * takes $extra by reference because the cursor it writes is what the NEXT cycle reads: without
 * that, every iteration inside one run would re-request the same window.
 *
 * @return array{seen:int, handled:int, failed:bool}
 */
function ee_poll_cycle(string $apiKey, array &$extra, ?string $sinceArg, bool $dryRun, int $cycle): array {
    global $conn;
    $cursor = isset($extra['events_cursor']) ? (string)$extra['events_cursor'] : '';
    /*
     * Everything below is UTC. /v4/events both returns EventDate as ...Z and interprets from/to
     * as UTC, while PHP here runs on Asia/Kolkata (set in config/database.php) — so building a
     * window with date() instead of gmdate() would shift it 5.5 hours and silently miss events.
     */
    if ($sinceArg !== null && $cycle === 1) {
        $sinceTs = strtotime($sinceArg . ' UTC');
        if (!$sinceTs) { ee_poll_log("abort — could not parse --since=$sinceArg"); exit; }
    } elseif ($cursor !== '' && ($cursorTs = strtotime($cursor)) !== false) {
        $sinceTs = $cursorTs - EE_POLL_OVERLAP_SECONDS;
    } else {
        $sinceTs = time() - EE_POLL_COLD_START_SECONDS;
    }

    /*
     * The floor, applied to every path above including an explicit --since.
     *
     * Without it a cursor left behind by a poller that stopped weeks ago would make
     * the next run page back over all of that time — thousands of requests for
     * events Elastic Email deleted long before, on a job that now runs every minute
     * and would still be paging when the next tick started.
     */
    $floorTs = time() - EE_POLL_MAX_LOOKBACK_SECONDS;
    if ($sinceTs < $floorTs) {
        ee_poll_log(sprintf(
            'window clamped to the last %d day(s): requested %sZ, using %sZ',
            EE_POLL_MAX_LOOKBACK_DAYS,
            gmdate('Y-m-d\TH:i:s', $sinceTs),
            gmdate('Y-m-d\TH:i:s', $floorTs)
        ));
        $sinceTs = $floorTs;
    }

    $from  = gmdate('Y-m-d\TH:i:s', $sinceTs);
    $toTs  = time();
    $runTo = gmdate('Y-m-d\TH:i:s', $toTs);
    ee_poll_log("run start — window {$from}Z .. {$runTo}Z" . ($cursor !== '' ? " (cursor $cursor)" : ' (cold start, no cursor)') . ($dryRun ? ' [DRY RUN]' : ''));

    /*
     * ── PAGING BY OFFSET, AND WHY IT HAD TO CHANGE ───────────────────────────
     *
     * This used to walk the upper bound of the window backwards: read a page, take the oldest
     * event on it, ask again with that as the new 'to'. The note below it said offset was ignored
     * by this API, and at the time it was.
     *
     * That walk is only safe if a page really is "the newest N events in the window". It is not.
     * The API returns a slice and sorts THAT newest-first — asking for 1000 rows comes back
     * spanning the same period as asking for 500, when a strictly newest-first read would have
     * reached twice as far back. So the oldest row on a page is not the boundary of what has been
     * seen, and moving 'to' down to it steps over everything in between, unread, for good.
     *
     * Measured on one ordinary day: 38,945 events existed, and the walk found 4,985 of them. It
     * held up in the quiet hours, where a single page covered everything, and collapsed in exactly
     * the two hours that carried a campaign — 22,656 events read as 1,050, and 14,227 as 1,873.
     * Every receipt it skipped is a recipient whose delivered_at stays NULL for ever, which is why
     * a campaign sent to 14,215 people showed 6,673 delivered while the provider had 38,713 for
     * the day.
     *
     * The API honours offset now, so the window stays fixed and the offset moves. 'to' is pinned to
     * the moment the run started, so events arriving mid-run fall outside it and cannot shift the
     * rows underneath the paging.
     */
    $pages     = 0;
    $offset    = 0;
    $seen      = 0;
    $handled   = 0;
    $newestTs  = 0;
    $failed    = false;

    while ($pages < EE_POLL_MAX_PAGES) {
        [$events, $status, $err] = ee_fetch_events($apiKey, $from, $runTo, EE_POLL_PAGE_SIZE, $offset);
        $pages++;
        if ($events === null) {
            // Do NOT advance the cursor on a failed run — the next tick must re-read this window
            // rather than skipping past receipts we never actually saw.
            ee_poll_log("abort — GET /v4/events failed (HTTP $status" . ($err !== '' ? ", curl: $err" : '') . '); cursor left unchanged');
            $failed = true;
            break;
        }
        if (!$events) break;

        // Kept only for the run log: it says how far back the page reached.
        $oldestOnPage = null;
        foreach ($events as $evt) {
            if (!is_array($evt)) continue;
            $seen++;

            $type      = strtolower(trim((string)($evt['EventType'] ?? '')));
            $eventDate = (string)($evt['EventDate'] ?? '');
            $ts        = $eventDate !== '' ? strtotime($eventDate) : false;
            if ($ts !== false) {
                if ($ts > $newestTs) $newestTs = $ts;
                if ($oldestOnPage === null || $ts < $oldestOnPage) $oldestOnPage = $ts;
            }

            /*
             * Translate /v4/events' vocabulary into the WEBHOOK's, which is the only one the sink
             * knows. Both 'Error' and 'Bounce' become the webhook's 'error' — it has a single
             * failure status and classifies hard vs soft from the category, not from the type.
             *
             * There is no `postback` here (the events API does not return it), so correlation runs
             * entirely on MsgID → email_campaign_recipients.esp_message_id, which the transport
             * stored from the send response.
             */
            $status2 = ($type === 'sent') ? 'sent' : (($type === 'error' || $type === 'bounce') ? 'error' : '');
            if ($status2 === '') continue;

            if ($dryRun) { $handled++; continue; }
            if (ee_handle_event([
                'status'    => $status2,
                'category'  => (string)($evt['MessageCategory'] ?? ''),
                'messageid' => (string)($evt['MsgID'] ?? ''),
                'postback'  => '',
                // Carried through verbatim so the raw provider payload lands in
                // email_campaign_events.meta for bounces, exactly as the webhook stores it.
                'raw'       => $evt,
            ])) $handled++;
        }

        // A short page is the end of the window. Anything else means there is more behind it.
        if (count($events) < EE_POLL_PAGE_SIZE) break;
        $offset += EE_POLL_PAGE_SIZE;
    }

    if ($pages >= EE_POLL_MAX_PAGES) {
        ee_poll_log('warning — hit the ' . EE_POLL_MAX_PAGES . '-page ceiling; the remaining backlog is picked up next run');
    }

    /* ------------------------------------------------------------------ *
     * Advance the cursor
     * ------------------------------------------------------------------ */
    if (!$failed && !$dryRun) {
        /*
         * The cursor is the newest EventDate actually seen, not $runTo. Elastic Email may register
         * an event slightly after it happened, and storing "the time we asked" would step over
         * anything that landed in between. With no events at all, the cursor stays put and the
         * overlap window simply widens on the next run.
         */
        if ($newestTs > 0) {
            $newCursor = gmdate('Y-m-d\TH:i:s\Z', $newestTs);
            $extra['events_cursor'] = $newCursor;
            $extraE = $conn->real_escape_string(json_encode($extra));
            $conn->query("UPDATE email_esp_settings SET extra_config = '$extraE' WHERE provider='elasticemail'");
            ee_poll_log("cursor advanced to $newCursor");
        }
    }

    ee_poll_log("cycle $cycle finished — $pages page(s), $seen event(s) fetched, $handled applied"
        . ($dryRun ? ' (dry run, nothing written)' : ''));

    return ['seen' => $seen, 'handled' => $handled, 'failed' => $failed];

}

/* ------------------------------------------------------------------ *
 * Run
 * ------------------------------------------------------------------ */
$startedAt = microtime(true);
$deadline  = $startedAt + EE_POLL_MAX_RUNTIME;
$cycle     = 0;
$totals    = ['seen' => 0, 'handled' => 0];

while (true) {
    $cycle++;
    $round = ee_poll_cycle($apiKey, $extra, $sinceArg, $dryRun, $cycle);
    $totals['seen']    += $round['seen'];
    $totals['handled'] += $round['handled'];

    // A failed fetch left the cursor alone on purpose; retrying it immediately would most
    // likely just fail again against the same rate limit or outage. Let cron come back.
    if ($round['failed']) break;

    // --since is a one-shot manual sweep, not a mode to sit in.
    if ($sinceArg !== null || $dryRun) break;

    if (!ee_poll_is_active()) break;
    if (microtime(true) + EE_POLL_ACTIVE_INTERVAL >= $deadline) break;
    sleep(EE_POLL_ACTIVE_INTERVAL);
}

ee_poll_log(sprintf('run finished — %d cycle(s), %d event(s) fetched, %d applied, %.1fs elapsed',
    $cycle, $totals['seen'], $totals['handled'], microtime(true) - $startedAt));

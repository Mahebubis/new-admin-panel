-- ===========================================================================
--  Resume / Profile Metrics — one-time database setup
--  Run against istudio_cit. Safe to re-run: every statement checks first.
--
--  Two jobs:
--    1. Make sure user_activity_log exists. The student dashboard writes resume
--       and profile-section events into it; without the table those endpoints
--       fall back to doing nothing (they never fail a save over logging), and
--       the Profile & Resume tab stays empty.
--    2. Add the date indexes every panel on the page groups by. Without these,
--       "last 30 days" is a full scan of chat_messages and
--       hiring_applications_new on every filter change.
-- ===========================================================================

CREATE TABLE IF NOT EXISTS user_activity_log (
    id            INT AUTO_INCREMENT PRIMARY KEY,
    user_id       INT NOT NULL,
    activity_type VARCHAR(64) NOT NULL,
    activity_data TEXT NULL,
    created_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_user_id (user_id),
    INDEX idx_activity_type (activity_type),
    INDEX idx_created_at (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- MySQL has no CREATE INDEX IF NOT EXISTS, and a duplicate key name is a hard
-- error that would abort the rest of the file. This walks information_schema
-- instead, so re-running is a no-op.
DROP PROCEDURE IF EXISTS pm_add_index;
DELIMITER //
CREATE PROCEDURE pm_add_index(
    IN p_table VARCHAR(64), IN p_name VARCHAR(64), IN p_cols VARCHAR(255))
BEGIN
    IF EXISTS (SELECT 1 FROM information_schema.TABLES
                WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = p_table)
       AND NOT EXISTS (SELECT 1 FROM information_schema.STATISTICS
                        WHERE TABLE_SCHEMA = DATABASE()
                          AND TABLE_NAME = p_table AND INDEX_NAME = p_name)
    THEN
        SET @s = CONCAT('ALTER TABLE `', p_table, '` ADD INDEX `', p_name, '` (', p_cols, ')');
        PREPARE st FROM @s; EXECUTE st; DEALLOCATE PREPARE st;
    END IF;
END //
DELIMITER ;

-- Profile & resume ----------------------------------------------------------
CALL pm_add_index('users', 'idx_pm_registered_at', '`registered_at`');
CALL pm_add_index('users', 'idx_pm_last_updated',  '`last_updated`');
-- The Profile tab always filters on activity_type first, then the date range.
CALL pm_add_index('user_activity_log', 'idx_pm_type_created', '`activity_type`, `created_at`');

-- Applications --------------------------------------------------------------
CALL pm_add_index('hiring_applications_new', 'idx_pm_applied_date', '`applied_date`');
CALL pm_add_index('hiring_applications_new', 'idx_pm_job_id',       '`job_id`');
CALL pm_add_index('hiring_applications_new', 'idx_pm_user_id',      '`user_id`');
CALL pm_add_index('job_list',                'idx_pm_employer_id',  '`employer_id`');
CALL pm_add_index('invited_candidate',       'idx_pm_created_at',   '`created_at`');

-- Assignments, interviews ---------------------------------------------------
CALL pm_add_index('hiring_assignment_new',          'idx_pm_created_at',  '`created_at`');
CALL pm_add_index('hiring_assignment_new',          'idx_pm_application', '`application_id`');
CALL pm_add_index('hiring_submit_assignment_new',   'idx_pm_created_at',  '`created_at`');
CALL pm_add_index('hiring_submit_assignment_new',   'idx_pm_assignment',  '`assignment_id`');
CALL pm_add_index('hiring_schedule_interview_new',  'idx_pm_created_at',  '`created_at`');
CALL pm_add_index('hiring_schedule_interview_new',  'idx_pm_interview_date', '`interview_date`');
CALL pm_add_index('hiring_schedule_interview_new',  'idx_pm_application', '`application_id`');
CALL pm_add_index('reschedule_interview_new',       'idx_pm_created_at',  '`created_at`');
CALL pm_add_index('reschedule_interview_new',       'idx_pm_interview',   '`interview_id`');

-- Messaging -----------------------------------------------------------------
-- Every messaging panel is "sent in this range, by this side, read or not", so
-- the index leads with the date and carries the other two.
CALL pm_add_index('chat_messages', 'idx_pm_created_sender', '`created_at`, `sender_type`, `status`');
CALL pm_add_index('chat_messages', 'idx_pm_application',    '`application_id`');

DROP PROCEDURE IF EXISTS pm_add_index;

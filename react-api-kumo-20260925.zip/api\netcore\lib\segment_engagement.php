<?php
/*
 * /api/netcore/lib/segment_engagement.php
 *
 * The "Engagement" and "Contacts" tabs of the segment builder. Required by segment_sql.php,
 * whose buildConditionSql() hands any condition with kind='engagement' or kind='contacts'
 * here; a condition without a kind is a Behaviour condition and never reaches this file.
 *
 * FUNCTIONS ONLY, no top-level variables. segment_sql.php is sometimes loaded for the first
 * time from inside a function (see the note at the top of campaigns/lib/SendWorker.php), and a
 * top-level array in a file loaded that way is trapped in that function's local scope — every
 * other function then sees it as empty. Lookup tables below live in static function locals.
 *
 * ── Engagement condition ──────────────────────────────────────────────────────────────────
 *   { kind:'engagement', did:'did'|'did_not_do', event:<key>,
 *     measure:'total'|'unique', operator:'>='|'>'|'<='|'<'|'=', count:N,
 *     source:{ type:'campaign'|'journey'|'tags'|'list', scope:'any'|'specific', ids:[], tags:[] },
 *     day:{ type, from, to, n, unit },
 *     filter:{ payload, op, value } | null }
 *
 * Every event is resolved to rows of (user_id, event_at, mkey, w):
 *   mkey — the message the event belongs to ('c'+campaign recipient id, 'j'+journey message id),
 *          so measure=unique counts distinct messages;
 *   w    — how many occurrences the row stands for, so measure=total can use the per-message
 *          counters (journey open_count / click_count, WhatsApp click_count) where the channel
 *          keeps no per-event log.
 * then GROUP BY user_id HAVING <SUM(w) | COUNT(DISTINCT mkey)> <op> N.
 *
 * Test sends (is_test=1) never count. Rows that cannot be tied to a registered user are dropped
 * (a segment is a set of users.user_id): an email recipient without user_id is matched to users
 * by email, and a WhatsApp recipient's user_id is backfilled by the send worker.
 *
 * ── Contacts condition ────────────────────────────────────────────────────────────────────
 *   { kind:'contacts', did:'did'|'did_not_do', event:'list'|'segment', ids:[] }
 *   did = "belongs to any of", did_not_do = "belongs to none of".
 */

/* users.email is utf8mb4_general_ci while every campaign/journey/list table is utf8mb4_unicode_ci;
   comparing the two raises "Illegal mix of collations". Same choice as AudienceResolver. */
if (!defined('SEG_EMAIL_COLLATION')) define('SEG_EMAIL_COLLATION', 'utf8mb4_general_ci');

/** SQL that yields no rows but has a user_id column — "nobody". */
function seg_empty_set_sql() {
    return "SELECT CAST(NULL AS UNSIGNED) AS user_id FROM DUAL WHERE 1=0";
}

function seg_table_exists($table) {
    global $conn;
    static $cache = [];
    if (isset($cache[$table])) return $cache[$table];
    $t = mysqli_real_escape_string($conn, $table);
    try { $r = mysqli_query($conn, "SHOW TABLES LIKE '$t'"); }
    catch (\Throwable $e) { $r = false; }
    return $cache[$table] = ($r && mysqli_num_rows($r) > 0);
}

function seg_column_exists($table, $col) {
    global $conn;
    static $cache = [];
    $k = "$table.$col";
    if (isset($cache[$k])) return $cache[$k];
    if (!seg_table_exists($table)) return $cache[$k] = false;
    $c = mysqli_real_escape_string($conn, $col);
    try { $r = mysqli_query($conn, "SHOW COLUMNS FROM `$table` LIKE '$c'"); }
    catch (\Throwable $e) { $r = false; }
    return $cache[$k] = ($r && mysqli_num_rows($r) > 0);
}

function seg_int_ids($arr) {
    if (!is_array($arr)) return [];
    return array_values(array_unique(array_filter(array_map('intval', $arr), function ($v) { return $v > 0; })));
}

function seg_str_list($arr) {
    if (!is_array($arr)) return [];
    $out = [];
    foreach ($arr as $v) { $v = trim((string)$v); if ($v !== '') $out[] = $v; }
    return array_values(array_unique($out));
}

/** user_id of a row, falling back to a users lookup by email when the row carries none. */
function seg_user_expr($uidCol, $emailCol) {
    return "COALESCE($uidCol, (SELECT uu.user_id FROM users uu WHERE uu.email = $emailCol COLLATE " . SEG_EMAIL_COLLATION . " LIMIT 1))";
}

/** "$col BETWEEN start AND end" for the condition's day window, or '' for Any Day. */
function seg_day_clause($day, $col) {
    [$ds, $de] = resolveDay($day);
    if (!$ds || !$de) return '';
    return "$col BETWEEN '" . esc($ds) . " 00:00:00' AND '" . esc($de) . " 23:59:59'";
}

/** Campaign ids carrying any of $tags. email_campaigns.tags / wa_campaigns.tags are comma lists. */
function seg_campaign_tag_sql($table, $tags) {
    $ors = [];
    foreach ($tags as $t) {
        $ors[] = "FIND_IN_SET('" . esc($t) . "', REPLACE(REPLACE(TRIM(tags), ', ', ','), ' ,', ',')) > 0";
    }
    return "SELECT id FROM $table WHERE tags IS NOT NULL AND tags <> '' AND (" . implode(' OR ', $ors) . ")";
}

/** Journey ids carrying any of $tags. journeys.tags is a JSON array of strings. */
function seg_journey_tag_sql($tags) {
    $ors = [];
    foreach ($tags as $t) {
        $ors[] = "JSON_CONTAINS(tags, JSON_QUOTE('" . esc($t) . "'))";
    }
    return "SELECT id FROM journeys WHERE tags IS NOT NULL AND (" . implode(' OR ', $ors) . ")";
}

/*
 * Event catalogue: which channel it belongs to, which "performed in" sources it supports,
 * which where-filters it supports, and whether one message can only ever count once.
 * Keys and labels must match ENGAGEMENT_EVENTS in src/pages/netcore/segmentEngagementConfig.js.
 */
function seg_engagement_events() {
    static $ev = [
        'email_opened'      => ['channel' => 'email',    'sources' => ['campaign', 'journey', 'tags'], 'filters' => ['open_type', 'platform', 'os', 'browser']],
        'email_clicked'     => ['channel' => 'email',    'sources' => ['campaign', 'journey', 'tags'], 'filters' => ['click_type', 'link_url', 'platform', 'os', 'browser']],
        'email_soft_bounce' => ['channel' => 'email',    'sources' => ['campaign', 'tags'],            'filters' => []],
        'email_hard_bounce' => ['channel' => 'email',    'sources' => ['campaign', 'tags'],            'filters' => []],
        'email_unsubscribe' => ['channel' => 'email',    'sources' => ['campaign', 'journey', 'tags'], 'filters' => [], 'once_per_message' => true],
        'email_sent'        => ['channel' => 'email',    'sources' => ['campaign', 'journey', 'tags'], 'filters' => []],
        'list_activity'     => ['channel' => 'list',     'sources' => ['list'],                        'filters' => []],
        'wa_sent'           => ['channel' => 'whatsapp', 'sources' => ['campaign', 'journey', 'tags'], 'filters' => []],
        'wa_read'           => ['channel' => 'whatsapp', 'sources' => ['campaign', 'journey', 'tags'], 'filters' => []],
        'wa_delivered'      => ['channel' => 'whatsapp', 'sources' => ['campaign', 'journey', 'tags'], 'filters' => []],
        'wa_clicked'        => ['channel' => 'whatsapp', 'sources' => ['campaign', 'journey', 'tags'], 'filters' => []],
        'wa_reply'          => ['channel' => 'whatsapp', 'sources' => ['campaign', 'tags'],            'filters' => []],
    ];
    return $ev;
}

/* User-agent classifiers for the OS / Browser filters. Order matters only for readability —
   each value is a self-contained predicate, so "Chrome" explicitly excludes Edge/Opera/Samsung,
   which also carry "Chrome/" in their user agent. */
function seg_ua_predicate($kind, $value, $col) {
    static $os = null, $br = null;
    if ($os === null) {
        $os = [
            'android' => "%c LIKE '%Android%'",
            'ios'     => "(%c LIKE '%iPhone%' OR %c LIKE '%iPad%' OR %c LIKE '%iPod%')",
            'windows' => "%c LIKE '%Windows%'",
            'macos'   => "(%c LIKE '%Macintosh%' AND %c NOT LIKE '%iPhone%' AND %c NOT LIKE '%iPad%')",
            'linux'   => "(%c LIKE '%Linux%' AND %c NOT LIKE '%Android%')",
        ];
        $br = [
            'chrome'  => "((%c LIKE '%Chrome/%' OR %c LIKE '%CriOS/%') AND %c NOT LIKE '%Edg%' AND %c NOT LIKE '%OPR/%' AND %c NOT LIKE '%SamsungBrowser%')",
            'safari'  => "(%c LIKE '%Safari/%' AND %c NOT LIKE '%Chrome/%' AND %c NOT LIKE '%CriOS/%' AND %c NOT LIKE '%FxiOS/%' AND %c NOT LIKE '%Edg%' AND %c NOT LIKE '%OPR/%')",
            'firefox' => "(%c LIKE '%Firefox/%' OR %c LIKE '%FxiOS/%')",
            'edge'    => "%c LIKE '%Edg%'",
            'opera'   => "(%c LIKE '%OPR/%' OR %c LIKE '%Opera%')",
            'samsung' => "%c LIKE '%SamsungBrowser%'",
        ];
    }
    $map = $kind === 'os' ? $os : $br;
    if (!isset($map[$value])) return null;
    return str_replace('%c', $col, $map[$value]);
}

/**
 * Where-filter → [allowedEventTypes|null, extraWhereSql|null] for the email events tables.
 * Returns false when the filter is incomplete (no value picked yet) so it is ignored rather
 * than silently matching nothing.
 */
function seg_engagement_filter($eventKey, $filter, $alias) {
    if (!$filter || !is_array($filter)) return [null, null];
    $p   = (string)($filter['payload'] ?? '');
    $op  = (string)($filter['op'] ?? 'is');
    $val = (string)($filter['value'] ?? '');
    $neg = ($op === 'is_not' || $op === 'does_not_contain');
    if ($p === '' || $val === '') return [null, null];

    if ($p === 'open_type' || $p === 'click_type') {
        $user = $p === 'open_type' ? 'open' : 'click';
        $bot  = $p === 'open_type' ? 'open_bot' : 'click_bot';
        if ($val === 'any') return [$neg ? [] : [$user, $bot], null];
        $pick = $val === 'bot' ? $bot : $user;
        $other = $val === 'bot' ? $user : $bot;
        return [[$neg ? $other : $pick], null];
    }

    if ($p === 'platform') {
        $allowed = ['mobile', 'tablet', 'desktop', 'unknown'];
        if (!in_array($val, $allowed, true)) return [null, null];
        $pred = $val === 'unknown'
            ? "($alias.device_type IS NULL OR $alias.device_type = 'unknown')"
            : "$alias.device_type = '$val'";
        return [null, $neg ? "NOT IFNULL($pred, 0)" : $pred];
    }

    if ($p === 'os' || $p === 'browser') {
        $pred = seg_ua_predicate($p, $val, "$alias.user_agent");
        if (!$pred) return [null, null];
        return [null, $neg ? "NOT IFNULL($pred, 0)" : "IFNULL($pred, 0)"];
    }

    if ($p === 'link_url') {
        $v = esc($val);
        $vLike = esc(addcslashes($val, '%_\\'));
        switch ($op) {
            case 'is':               return [null, "$alias.url = '$v'"];
            case 'is_not':           return [null, "($alias.url IS NULL OR $alias.url <> '$v')"];
            case 'does_not_contain': return [null, "($alias.url IS NULL OR $alias.url NOT LIKE '%$vLike%')"];
            default:                 return [null, "$alias.url LIKE '%$vLike%'"];
        }
    }
    return [null, null];
}

/**
 * The event rows for one engagement condition, as a list of SELECTs each yielding
 * (user_id, event_at, mkey, w). An empty list means "nobody" (e.g. Specific Campaign with
 * nothing picked, or a source the event does not support).
 */
function seg_engagement_parts($cond) {
    $events = seg_engagement_events();
    $key = (string)($cond['event'] ?? '');
    if (!isset($events[$key])) return [];
    $def = $events[$key];

    $src   = is_array($cond['source'] ?? null) ? $cond['source'] : [];
    $type  = (string)($src['type'] ?? ($def['channel'] === 'list' ? 'list' : 'campaign'));
    $scope = (string)($src['scope'] ?? 'any');
    $ids   = seg_int_ids($src['ids'] ?? []);
    $tags  = seg_str_list($src['tags'] ?? []);
    if (!in_array($type, $def['sources'], true)) return [];
    if ($type === 'tags' && !$tags) return [];
    if ($type !== 'tags' && $scope === 'specific' && !$ids) return [];
    $day = $cond['day'] ?? null;

    /* where-filters are only offered for campaign sources — journey messages keep no per-event
       user agent / bot flag, so a filter cannot be evaluated against them. */
    $filter = ($type === 'campaign' && in_array((string)($cond['filter']['payload'] ?? ''), $def['filters'], true))
        ? $cond['filter'] : null;

    $wantCampaign = ($type === 'campaign' || $type === 'tags');
    $wantJourney  = ($type === 'journey' || ($type === 'tags' && in_array('journey', $def['sources'], true)));

    $campScope = function ($col, $campTable) use ($type, $scope, $ids, $tags) {
        if ($type === 'tags') return "$col IN (" . seg_campaign_tag_sql($campTable, $tags) . ")";
        if ($scope === 'specific') return "$col IN (" . implode(',', $ids) . ")";
        return '';
    };
    $journeyScope = function ($col) use ($type, $scope, $ids, $tags) {
        if ($type === 'tags') return "$col IN (" . seg_journey_tag_sql($tags) . ")";
        if ($scope === 'specific') return "$col IN (" . implode(',', $ids) . ")";
        return '';
    };
    $where = function (array $parts) {
        $parts = array_values(array_filter($parts, function ($p) { return $p !== '' && $p !== null; }));
        return $parts ? 'WHERE ' . implode(' AND ', $parts) : '';
    };

    $out = [];
    $emailUser = seg_user_expr('r.user_id', 'r.email');
    $hasJourneys = seg_table_exists('journey_messages') && seg_table_exists('journeys');

    /* ── email: per-event log (opens / clicks) ── */
    if ($key === 'email_opened' || $key === 'email_clicked') {
        $isOpen = $key === 'email_opened';
        if ($wantCampaign && seg_table_exists('email_campaign_events')) {
            [$types, $extra] = seg_engagement_filter($key, $filter, 'e');
            if ($types === null) $types = $isOpen ? ['open', 'open_bot'] : ['click', 'click_bot'];
            if ($types) {
                $in = "'" . implode("','", $types) . "'";
                $out[] = "SELECT $emailUser AS user_id, e.created_at AS event_at, CONCAT('c', r.id) AS mkey, 1 AS w
                          FROM email_campaign_events e
                          INNER JOIN email_campaign_recipients r ON r.id = e.recipient_id
                          " . $where([
                              "e.event_type IN ($in)", 'r.is_test = 0',
                              $campScope('e.campaign_id', 'email_campaigns'),
                              seg_day_clause($day, 'e.created_at'), $extra,
                          ]);
            }
        }
        if ($wantJourney && $hasJourneys && !$filter) {
            $at  = $isOpen ? 'jm.opened_at' : 'jm.first_clicked_at';
            $cnt = $isOpen ? 'jm.open_count' : 'jm.click_count';
            $out[] = "SELECT " . seg_user_expr('jm.user_id', 'jm.to_addr') . " AS user_id, $at AS event_at, CONCAT('j', jm.id) AS mkey, GREATEST($cnt, 1) AS w
                      FROM journey_messages jm
                      " . $where([
                          "jm.channel = 'email'", "$at IS NOT NULL",
                          $journeyScope('jm.journey_id'), seg_day_clause($day, $at),
                      ]);
        }
        return $out;
    }

    /* ── email: bounces (classified per recipient by the ESP webhooks) ── */
    if ($key === 'email_soft_bounce' || $key === 'email_hard_bounce') {
        if (!$wantCampaign || !seg_table_exists('email_campaign_recipients')) return [];
        /* The webhooks default an unclassified bounce to hard (the safer assumption for
           suppression), so a bounced row with no type is counted as hard here too. */
        $typeSql = $key === 'email_soft_bounce'
            ? "r.bounce_type = 'soft'"
            : "(r.bounce_type = 'hard' OR (r.bounce_type IS NULL AND r.status = 'bounced'))";
        $at = 'COALESCE(r.bounced_at, r.sent_at, r.queued_at)';
        $out[] = "SELECT $emailUser AS user_id, $at AS event_at, CONCAT('c', r.id) AS mkey, 1 AS w
                  FROM email_campaign_recipients r
                  " . $where([
                      $typeSql, 'r.is_test = 0',
                      $campScope('r.campaign_id', 'email_campaigns'), seg_day_clause($day, $at),
                  ]);
        return $out;
    }

    /* ── email: unsubscribe — ESP-reported (events) + first-party page (email_unsubscribes) ── */
    if ($key === 'email_unsubscribe') {
        if ($wantCampaign && seg_table_exists('email_campaign_events')) {
            $out[] = "SELECT $emailUser AS user_id, e.created_at AS event_at, CONCAT('c', e.campaign_id) AS mkey, 1 AS w
                      FROM email_campaign_events e
                      INNER JOIN email_campaign_recipients r ON r.id = e.recipient_id
                      " . $where([
                          "e.event_type = 'unsubscribe'", 'r.is_test = 0',
                          $campScope('e.campaign_id', 'email_campaigns'), seg_day_clause($day, 'e.created_at'),
                      ]);
        }
        if (seg_table_exists('email_unsubscribes')) {
            $unsUser = "(SELECT uu.user_id FROM users uu WHERE uu.email = eu.email COLLATE " . SEG_EMAIL_COLLATION . " LIMIT 1)";
            if ($wantCampaign) {
                $out[] = "SELECT $unsUser AS user_id, eu.created_at AS event_at, CONCAT('c', eu.campaign_id) AS mkey, 1 AS w
                          FROM email_unsubscribes eu
                          " . $where([
                              'eu.campaign_id IS NOT NULL',
                              $campScope('eu.campaign_id', 'email_campaigns'), seg_day_clause($day, 'eu.created_at'),
                          ]);
            }
            if ($wantJourney) {
                $out[] = "SELECT $unsUser AS user_id, eu.created_at AS event_at, CONCAT('j', eu.journey_id) AS mkey, 1 AS w
                          FROM email_unsubscribes eu
                          " . $where([
                              'eu.journey_id IS NOT NULL',
                              $journeyScope('eu.journey_id'), seg_day_clause($day, 'eu.created_at'),
                          ]);
            }
        }
        return $out;
    }

    /* ── email: sent ── */
    if ($key === 'email_sent') {
        if ($wantCampaign && seg_table_exists('email_campaign_recipients')) {
            $out[] = "SELECT $emailUser AS user_id, r.sent_at AS event_at, CONCAT('c', r.id) AS mkey, 1 AS w
                      FROM email_campaign_recipients r
                      " . $where([
                          'r.sent_at IS NOT NULL', 'r.is_test = 0',
                          $campScope('r.campaign_id', 'email_campaigns'), seg_day_clause($day, 'r.sent_at'),
                      ]);
        }
        if ($wantJourney && $hasJourneys) {
            $out[] = "SELECT " . seg_user_expr('jm.user_id', 'jm.to_addr') . " AS user_id, jm.sent_at AS event_at, CONCAT('j', jm.id) AS mkey, 1 AS w
                      FROM journey_messages jm
                      " . $where([
                          "jm.channel = 'email'", 'jm.sent_at IS NOT NULL',
                          $journeyScope('jm.journey_id'), seg_day_clause($day, 'jm.sent_at'),
                      ]);
        }
        return $out;
    }

    /* ── WhatsApp: receipts on the recipient row ── */
    if (in_array($key, ['wa_sent', 'wa_delivered', 'wa_read', 'wa_clicked'], true)) {
        $waUser = seg_user_expr('r.user_id', 'r.email');
        if ($wantCampaign && seg_table_exists('wa_campaign_recipients')) {
            $w = '1';
            switch ($key) {
                case 'wa_sent':
                    $at = 'r.sent_at'; $cond0 = 'r.sent_at IS NOT NULL'; break;
                case 'wa_delivered':
                    /* a read receipt proves delivery even when the delivered receipt never came */
                    $at = 'COALESCE(r.delivered_at, r.read_at)'; $cond0 = '(r.delivered_at IS NOT NULL OR r.read_at IS NOT NULL)'; break;
                case 'wa_read':
                    $at = 'r.read_at'; $cond0 = 'r.read_at IS NOT NULL'; break;
                default: /* wa_clicked */
                    $hasFc = seg_column_exists('wa_campaign_recipients', 'first_clicked_at');
                    $at = $hasFc ? 'COALESCE(r.first_clicked_at, r.read_at, r.delivered_at, r.sent_at)'
                                 : 'COALESCE(r.read_at, r.delivered_at, r.sent_at)';
                    $cond0 = $hasFc ? '(r.click_count > 0 OR r.first_clicked_at IS NOT NULL)' : 'r.click_count > 0';
                    $w = 'GREATEST(r.click_count, 1)';
            }
            $out[] = "SELECT $waUser AS user_id, $at AS event_at, CONCAT('c', r.id) AS mkey, $w AS w
                      FROM wa_campaign_recipients r
                      " . $where([
                          $cond0, 'r.is_test = 0',
                          $campScope('r.campaign_id', 'wa_campaigns'), seg_day_clause($day, $at),
                      ]);
        }
        if ($wantJourney && $hasJourneys) {
            $w = '1';
            switch ($key) {
                case 'wa_sent':      $at = 'jm.sent_at';      $cond0 = 'jm.sent_at IS NOT NULL'; break;
                case 'wa_delivered': $at = 'COALESCE(jm.delivered_at, jm.opened_at)'; $cond0 = '(jm.delivered_at IS NOT NULL OR jm.opened_at IS NOT NULL)'; break;
                /* the journey webhook sink stores a WhatsApp read in opened_at */
                case 'wa_read':      $at = 'jm.opened_at';    $cond0 = 'jm.opened_at IS NOT NULL'; break;
                default:             $at = 'jm.first_clicked_at'; $cond0 = 'jm.first_clicked_at IS NOT NULL'; $w = 'GREATEST(jm.click_count, 1)';
            }
            $out[] = "SELECT jm.user_id AS user_id, $at AS event_at, CONCAT('j', jm.id) AS mkey, $w AS w
                      FROM journey_messages jm
                      " . $where([
                          "jm.channel = 'whatsapp'", $cond0,
                          $journeyScope('jm.journey_id'), seg_day_clause($day, $at),
                      ]);
        }
        return $out;
    }

    /* ── WhatsApp: replies (per-event log) ── */
    if ($key === 'wa_reply') {
        if (!$wantCampaign || !seg_table_exists('wa_campaign_events')) return [];
        $out[] = "SELECT " . seg_user_expr('r.user_id', 'r.email') . " AS user_id, e.created_at AS event_at, CONCAT('c', r.id) AS mkey, 1 AS w
                  FROM wa_campaign_events e
                  INNER JOIN wa_campaign_recipients r ON r.id = e.recipient_id
                  " . $where([
                      "e.event_type = 'replied'", 'r.is_test = 0',
                      $campScope('e.campaign_id', 'wa_campaigns'), seg_day_clause($day, 'e.created_at'),
                  ]);
        return $out;
    }

    /* ── Lists: contact added to a list ── */
    if ($key === 'list_activity') {
        if (!seg_table_exists('campaign_list_members')) return [];
        $scopeSql = $scope === 'specific'
            ? 'm.list_id IN (' . implode(',', $ids) . ')'
            : "m.list_id IN (SELECT id FROM campaign_lists WHERE kind = 'list')";
        $out[] = "SELECT u.user_id AS user_id, m.added_at AS event_at, CONCAT('l', m.list_id) AS mkey, 1 AS w
                  FROM campaign_list_members m
                  INNER JOIN campaign_contacts c ON c.id = m.contact_id
                  INNER JOIN users u ON u.email = c.email COLLATE " . SEG_EMAIL_COLLATION . "
                  " . $where([$scopeSql, seg_day_clause($day, 'm.added_at')]);
        return $out;
    }

    return [];
}

/** SELECT user_id … for one engagement condition. */
function buildEngagementConditionSql($cond) {
    $events = seg_engagement_events();
    $key = (string)($cond['event'] ?? '');
    if (!isset($events[$key])) return null;   // no event picked yet → condition ignored, like Behaviour

    $op = (string)($cond['operator'] ?? '>=');
    if (!in_array($op, ['>=', '>', '<=', '<', '='], true)) $op = '>=';
    $count = max(0, (int)($cond['count'] ?? 1));

    $parts = seg_engagement_parts($cond);
    if (!$parts) {
        $sql = seg_empty_set_sql();
    } else {
        $unique = ($cond['measure'] ?? 'total') === 'unique' || !empty($events[$key]['once_per_message']);
        $agg = $unique ? 'COUNT(DISTINCT ev.mkey)' : 'SUM(ev.w)';
        $sql = "SELECT ev.user_id AS user_id
                FROM (" . implode("\n UNION ALL \n", $parts) . ") AS ev
                WHERE ev.user_id IS NOT NULL
                GROUP BY ev.user_id
                HAVING $agg $op $count";
    }

    if (($cond['did'] ?? 'did') === 'did_not_do') {
        $sql = "SELECT u.user_id FROM users u
                WHERE u.user_id NOT IN (SELECT nd.user_id FROM ($sql) AS nd WHERE nd.user_id IS NOT NULL)";
    }
    return $sql;
}

/* ── Contacts ─────────────────────────────────────────────────────────────────────────── */

/** Segment ids a config references through Contacts → Segment conditions (one level). */
function seg_config_segment_refs($config) {
    $ids = [];
    foreach (['include', 'exclude'] as $side) {
        foreach (($config[$side]['blocks'] ?? []) as $b) {
            foreach (($b['conditions'] ?? []) as $c) {
                if (($c['kind'] ?? '') === 'contacts' && ($c['event'] ?? '') === 'segment') {
                    $ids = array_merge($ids, seg_int_ids($c['ids'] ?? []));
                }
            }
        }
    }
    return array_values(array_unique($ids));
}

/** Would saving $config as segment $selfId create a cycle (A → … → A)? */
function seg_config_creates_cycle($config, $selfId) {
    global $conn;
    $selfId = (int)$selfId;
    if ($selfId <= 0) return false;
    $queue = seg_config_segment_refs($config);
    $seen = [];
    while ($queue) {
        $id = array_shift($queue);
        if ($id === $selfId) return true;
        if (isset($seen[$id]) || count($seen) > 200) continue;
        $seen[$id] = true;
        $r = mysqli_query($conn, "SELECT config FROM netcore_segments WHERE id = $id LIMIT 1");
        $row = $r ? mysqli_fetch_assoc($r) : null;
        if (!$row) continue;
        $queue = array_merge($queue, seg_config_segment_refs(json_decode($row['config'], true) ?: []));
    }
    return false;
}

/** SELECT user_id … for one contacts condition (belongs to list/segment). */
function buildContactsConditionSql($cond) {
    global $conn;
    static $stack = [];   // segment ids currently being expanded — breaks A → B → A loops

    $what = (string)($cond['event'] ?? '');
    if ($what !== 'list' && $what !== 'segment') return null;
    $ids = seg_int_ids($cond['ids'] ?? []);

    $sql = null;
    if (!$ids) {
        $sql = seg_empty_set_sql();
    } elseif ($what === 'list') {
        $sql = seg_table_exists('campaign_list_members')
            ? "SELECT DISTINCT u.user_id AS user_id
               FROM campaign_list_members m
               INNER JOIN campaign_contacts c ON c.id = m.contact_id
               INNER JOIN users u ON u.email = c.email COLLATE " . SEG_EMAIL_COLLATION . "
               WHERE m.list_id IN (" . implode(',', $ids) . ")"
            : seg_empty_set_sql();
    } else {
        $subs = [];
        foreach ($ids as $id) {
            if (in_array($id, $stack, true) || count($stack) >= 10) continue;
            $r = mysqli_query($conn, "SELECT config FROM netcore_segments WHERE id = $id LIMIT 1");
            $row = $r ? mysqli_fetch_assoc($r) : null;
            if (!$row) continue;
            $stack[] = $id;
            $s = buildSegmentSql(json_decode($row['config'], true) ?: []);
            array_pop($stack);
            if ($s) $subs[] = "SELECT user_id FROM ($s) AS seg_$id";
        }
        $sql = $subs ? implode(' UNION ', $subs) : seg_empty_set_sql();
    }

    if (($cond['did'] ?? 'did') === 'did_not_do') {
        $sql = "SELECT u.user_id FROM users u
                WHERE u.user_id NOT IN (SELECT nc.user_id FROM ($sql) AS nc WHERE nc.user_id IS NOT NULL)";
    } else {
        $sql = "SELECT cs.user_id FROM ($sql) AS cs WHERE cs.user_id IS NOT NULL";
    }
    return $sql;
}

/* ── Picker data for the builder ──────────────────────────────────────────────────────── */

function seg_fetch_all($sql) {
    global $conn;
    try { $r = mysqli_query($conn, $sql); } catch (\Throwable $e) { return []; }
    $rows = [];
    while ($r && $row = mysqli_fetch_assoc($r)) $rows[] = $row;
    return $rows;
}

function seg_tags_from_csv_rows($rows) {
    $all = [];
    foreach ($rows as $row) {
        foreach (explode(',', (string)$row['tags']) as $t) { $t = trim($t); if ($t !== '') $all[] = $t; }
    }
    $all = array_values(array_unique($all));
    sort($all, SORT_NATURAL | SORT_FLAG_CASE);
    return array_map('strval', $all);
}

/** Everything the Engagement / Contacts pickers need, in one round-trip. */
function seg_engagement_options() {
    $num = function ($rows) {
        return array_map(function ($r) { $r['id'] = (int)$r['id']; return $r; }, $rows);
    };
    $out = [
        'email_campaigns' => [], 'wa_campaigns' => [], 'journeys' => [],
        'email_tags' => [], 'wa_tags' => [], 'journey_tags' => [],
        'lists' => [], 'segments' => [],
    ];
    if (seg_table_exists('email_campaigns')) {
        $out['email_campaigns'] = $num(seg_fetch_all("SELECT id, name, status FROM email_campaigns WHERE status <> 'draft' ORDER BY id DESC LIMIT 3000"));
        $out['email_tags'] = seg_tags_from_csv_rows(seg_fetch_all("SELECT tags FROM email_campaigns WHERE tags IS NOT NULL AND tags <> ''"));
    }
    if (seg_table_exists('wa_campaigns')) {
        $out['wa_campaigns'] = $num(seg_fetch_all("SELECT id, name, status FROM wa_campaigns WHERE status <> 'draft' ORDER BY id DESC LIMIT 3000"));
        $out['wa_tags'] = seg_tags_from_csv_rows(seg_fetch_all("SELECT tags FROM wa_campaigns WHERE tags IS NOT NULL AND tags <> ''"));
    }
    if (seg_table_exists('journeys')) {
        $out['journeys'] = $num(seg_fetch_all("SELECT id, name, status FROM journeys WHERE status <> 'draft' ORDER BY id DESC LIMIT 3000"));
        $jt = [];
        foreach (seg_fetch_all("SELECT tags FROM journeys WHERE tags IS NOT NULL") as $row) {
            foreach ((json_decode((string)$row['tags'], true) ?: []) as $t) { $t = trim((string)$t); if ($t !== '') $jt[] = $t; }
        }
        $jt = array_values(array_unique($jt));
        sort($jt, SORT_NATURAL | SORT_FLAG_CASE);
        $out['journey_tags'] = array_map('strval', $jt);
    }
    if (seg_table_exists('campaign_lists')) {
        $out['lists'] = array_map(function ($r) {
            $r['id'] = (int)$r['id']; $r['contact_count'] = (int)$r['contact_count']; return $r;
        }, seg_fetch_all("SELECT id, name, kind, contact_count FROM campaign_lists ORDER BY kind = 'blocklist', id DESC"));
    }
    $out['segments'] = array_map(function ($r) {
        $r['id'] = (int)$r['id']; $r['user_count'] = (int)$r['user_count']; return $r;
    }, seg_fetch_all("SELECT id, name, user_count FROM netcore_segments ORDER BY id DESC"));
    return $out;
}

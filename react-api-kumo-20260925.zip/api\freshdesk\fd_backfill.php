<?php
/*
 * /api/freshdesk/fd_backfill.php
 *
 * Import the mailbox's HISTORY -- the mail that is older than the day this desk
 * went live and that the forward sync will never reach.
 *
 *   action=status                -> progress of the current/last run
 *   action=preview  &until=DATE  -> how many messages would be imported (no writes)
 *   action=start    &until=DATE  -> arm the run and take the first batch
 *   action=run                   -> take one more batch (the UI loops this; cron calls it too)
 *   action=stop                  -> pause; the cursor is kept, so resume continues
 *   action=reset                 -> forget the run entirely (imported mail is NOT deleted)
 *
 * WHY A SECOND WORKER INSTEAD OF A FLAG ON fd_sync.php
 * fd_sync.php owns one number, fd_mailbox_state.last_uid, and it only ever goes
 * up. That is not an oversight -- it is what makes the forward sync safe to run
 * every minute from cron. This walks the other way, from the baseline down to a
 * chosen date, and keeps its own cursor in fd_backfill so the two can never be
 * confused. It also takes its own lock, because a backfill that runs for hours
 * must never stop today's mail from arriving.
 *
 * WHAT MAKES THIS SAFE TO POINT AT A TWO-YEAR-OLD MAILBOX
 *   - fd_store_inbound() is called in ARCHIVE MODE: tickets open Closed and
 *     stamped at their own date, nothing is reopened, nothing is marked unread.
 *   - NO automations, NO realtime events, and above all NO auto-acknowledgement.
 *     Every one of those is a live-mail reflex; firing them on 2024 mail would
 *     email customers about threads they have long forgotten. That is the one
 *     mistake here that cannot be taken back, so the send path is simply never
 *     reached from this file.
 *   - Duplicates are free: a UID already in fd_messages is skipped BEFORE the
 *     body is fetched, and the UNIQUE keys catch anything that slips past.
 *   - Every batch commits its cursor, so a killed run resumes where it stopped.
 */

/*
 * Cron runs this from the shell, exactly as it runs fd_sync.php:
 *
 *   * * * * * php /home/.../react-api/api/freshdesk/fd_backfill.php
 *
 * That line is what makes a multi-hour import finish with nobody watching. The
 * panel drives the same cursor while the Mail Archive card is open, and the
 * lock means the two can never import the same UID twice.
 */
$FD_IS_CLI = (php_sapi_name() === 'cli');

if ($FD_IS_CLI) {
    // No web-server context in a crontab: hand it the values the endpoints get
    // from Apache, and let a long batch run without max_execution_time.
    $_SERVER['REQUEST_METHOD'] = 'GET';
    $_SERVER['HTTP_HOST'] = 'cit3.internshipstudio.com';
    set_time_limit(0);
}

require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../middleware/auth.php';
require_once __DIR__ . '/lib/config.php';
require_once __DIR__ . '/lib/Helpers.php';
require_once __DIR__ . '/lib/schema.php';
require_once __DIR__ . '/lib/Sla.php';
require_once __DIR__ . '/lib/Storage.php';
/* Pusher is loaded but never triggered: TicketStore defines fd_activity(), which
   reaches fd_emit(). Nothing on the archive path calls it -- this is here so a
   future edit that does cannot turn into a fatal instead of a no-op. */
require_once __DIR__ . '/lib/Pusher.php';
require_once __DIR__ . '/lib/TicketStore.php';
require_once __DIR__ . '/lib/ImapClient.php';
require_once __DIR__ . '/lib/MimeParser.php';

/*
 * Messages per batch. Larger than the forward sync's 40 because this is a bulk
 * job nobody is waiting on interactively -- the real limiter is the wall-clock
 * budget below, which stops mid-batch and commits.
 */
if (!defined('FD_BACKFILL_BATCH'))       define('FD_BACKFILL_BATCH', 120);
if (!defined('FD_BACKFILL_MAX_SECONDS')) define('FD_BACKFILL_MAX_SECONDS', 45);
/*
 * How many UIDs a single SEARCH looks at.
 *
 * The run walks DOWN through the mailbox one window at a time instead of
 * re-listing the whole date range every batch. On a 400,000-message mailbox the
 * unwindowed version re-downloaded and re-parsed every UID on every one of
 * ~3,400 batches -- gigabytes of pointless transfer and an array large enough
 * to threaten memory_limit. Windowed, a batch costs the same on a mailbox of
 * ten thousand or ten million.
 *
 * Bigger than the batch size because UIDs are sparse: deleted mail leaves gaps,
 * so a 4,000-UID window typically yields far fewer than 4,000 messages.
 */
if (!defined('FD_BACKFILL_WINDOW'))      define('FD_BACKFILL_WINDOW', 4000);
/* Nothing before this is worth offering in the UI; it is also a guard against a
   typo'd year turning into a scan of the entire mailbox. */
if (!defined('FD_BACKFILL_FLOOR_DATE'))  define('FD_BACKFILL_FLOOR_DATE', '2015-01-01');

/**
 * Mail the archive can skip: delivery bounces and delay warnings the mail
 * server sent to itself.
 *
 * Measured, not guessed. The Freshdesk export for 01 Jan 2025 -> 18 Sep 2026
 * holds 182,796 tickets carrying 370,954 inbound messages; 261,164 of those
 * (70.4%) come from two addresses, mailer-daemon@mailhost.internshipstudio.com
 * and mailer-daemon@mailserver.internshipstudio.com, with the subjects below.
 * Importing them costs roughly 11 GB of body text and several days of runtime to
 * archive the fact that our own bulk mail bounced -- something the sending logs
 * already record, and nobody will ever open a ticket to read.
 *
 * It is a CHOICE, not a default: skip_auto is stored per run, and leaving it off
 * reproduces the mailbox exactly, bounces and all.
 *
 * Substring match, so one entry covers every mailer-daemon@<host> variant.
 */
function fd_bf_auto_filters()
{
    return array(
        array('FROM',    'mailer-daemon@'),
        array('FROM',    'postmaster@'),
        array('SUBJECT', 'Warning: message'),
        array('SUBJECT', 'Mail delivery failed'),
        array('SUBJECT', 'Undelivered Mail Returned'),
    );
}

/* ------------------------------------------------------------------ auth -- */
/*
 * Same two doors as fd_sync.php: a signed-in agent with the freshdesk
 * permission, or cron presenting the shared secret (no JWT exists in a crontab).
 */
$isCron = false;
$ACTOR  = array('id' => null, 'name' => 'System');

$secret = fd_str('secret', '');
if ($FD_IS_CLI) {
    $isCron = true;
} elseif ($secret !== '' && hash_equals((string)fd_cfg('CRON_SECRET', FD_CRON_SECRET), $secret)) {
    $isCron = true;
} else {
    $jwt = require_jwt();
    require_permission('freshdesk', $jwt);
    $ACTOR = array('id' => isset($jwt['user_id']) ? (int)$jwt['user_id'] : null,
                   'name' => isset($jwt['name']) ? $jwt['name'] : 'Agent');
}

fd_install_error_handlers();
fd_ensure_schema();

$MAILBOX = (string)fd_cfg('IMAP_FOLDER', 'INBOX');
// A cron tick exists to do work, so its default is 'run'; a panel request that
// forgot its action only wants to know where things stand.
$action  = fd_str('action', $FD_IS_CLI ? 'run' : 'status');
$GLOBALS['FD_ACTION'] = $action;

/* --------------------------------------------------------------- state --- */

function fd_bf_state($mailbox)
{
    return fd_query_one("SELECT * FROM fd_backfill WHERE mailbox = ?", 's', array($mailbox));
}

/**
 * The run's progress, shaped for the UI.
 *
 * `remaining` is derived rather than stored: total_in_scope is measured once at
 * the start, and a stored countdown would drift the first time a batch is
 * retried after a crash.
 */
function fd_bf_shape($st)
{
    if (!$st) {
        return array('status' => 'idle', 'until' => null, 'processed' => 0, 'total' => 0,
                     'imported' => 0, 'remaining' => 0, 'percent' => 0, 'new_tickets' => 0,
                     'duplicates' => 0, 'skipped' => 0, 'errors' => 0, 'skip_auto' => 0,
                     'started_at' => null, 'finished_at' => null, 'error' => null);
    }
    $total     = (int)$st['total_in_scope'];
    $processed = (int)$st['processed'];
    return array(
        'status'      => $st['status'],
        'until'       => $st['until_date'],
        'processed'   => $processed,
        'total'       => $total,
        'remaining'   => max(0, $total - $processed),
        'percent'     => $total > 0 ? min(100, (int)round(($processed / $total) * 100)) : ($st['status'] === 'done' ? 100 : 0),
        'imported'    => (int)$st['imported'],
        'new_tickets' => (int)$st['new_tickets'],
        'duplicates'  => (int)$st['duplicates'],
        'skipped'     => (int)$st['skipped'],
        'errors'      => (int)$st['errors'],
        'skip_auto'   => !empty($st['skip_auto']) ? 1 : 0,
        'cursor_uid'  => $st['cursor_uid'] !== null ? (int)$st['cursor_uid'] : null,
        'started_at'  => $st['started_at'],
        'updated_at'  => $st['updated_at'],
        'finished_at' => $st['finished_at'],
        'error'       => $st['last_error'],
    );
}

/* ---------------------------------------------------------------- lock --- */
/*
 * The same atomic claim fd_sync.php uses, on this table instead.
 *
 * Duplicated rather than shared because fd_sync.php's copy lives in an
 * entrypoint that runs its own auth on include -- requiring it here to reuse
 * ten lines would run that auth twice. The 5-minute staleness window is the
 * crash recovery: a worker killed by the host leaves its lock behind, and
 * without this the backfill would wedge permanently and silently.
 */
function fd_bf_lock($mailbox, $token)
{
    $n = fd_exec(
        "UPDATE fd_backfill SET lock_token = ?, lock_at = NOW()
         WHERE mailbox = ?
           AND (lock_token IS NULL OR lock_at IS NULL OR lock_at < DATE_SUB(NOW(), INTERVAL 5 MINUTE))",
        'ss', array($token, $mailbox)
    );
    return $n > 0;
}

function fd_bf_unlock($mailbox, $token)
{
    fd_exec("UPDATE fd_backfill SET lock_token = NULL, lock_at = NULL
             WHERE mailbox = ? AND (lock_token = ? OR lock_token IS NULL)",
            'ss', array($mailbox, $token));
}

/* ------------------------------------------------------------ IMAP scope -- */

/**
 * Open the mailbox and return the UIDs at or after $until, newest first.
 *
 * SEARCH is the whole trick: it returns UIDs only, so establishing the scope of
 * a two-year backfill costs one short round trip rather than a download.
 */
function fd_bf_scope($imap, $mailbox, $until, $skipAuto = false)
{
    $info = $imap->selectFolder($mailbox, true);   // EXAMINE: never touches \Seen
    $since = date('d-M-Y', strtotime($until));
    $uids = $imap->searchDateRange($since, null, 0, 0, $skipAuto ? fd_bf_auto_filters() : array());
    rsort($uids, SORT_NUMERIC);                    // newest first: we walk downward
    return array('uidvalidity' => (int)$info['uidvalidity'], 'uids' => $uids, 'exists' => (int)$info['exists']);
}

/**
 * Of these UIDs, which are already in fd_messages?
 *
 * One indexed query for the whole batch, asked BEFORE anything is fetched. A
 * UID we already hold costs a lookup here instead of a full RFC822 download,
 * which is the difference between a resumed run taking seconds and taking an
 * hour.
 */
function fd_bf_known_uids($mailbox, $uidvalidity, $uids)
{
    if (empty($uids)) return array();
    $place = implode(',', array_fill(0, count($uids), '?'));
    $types = 'si' . str_repeat('i', count($uids));
    $params = array_merge(array($mailbox, (int)$uidvalidity), array_map('intval', $uids));
    $rows = fd_query(
        "SELECT imap_uid FROM fd_messages
         WHERE mailbox = ? AND imap_uidvalidity = ? AND imap_uid IN ($place)",
        $types, $params
    );
    $out = array();
    foreach ($rows as $r) $out[(int)$r['imap_uid']] = true;
    return $out;
}

/**
 * Fetch one UID and file it as archived history.
 *
 * Extracted so the windowed walk above stays readable, and so there is exactly
 * ONE place that decides what "import an old message" means. $n is the batch
 * tally, passed by reference.
 *
 * Errors are counted and stepped over rather than thrown: one malformed message
 * out of four hundred thousand must not wedge the run forever. A protocol
 * failure IS rethrown, because carrying on after the connection has gone just
 * produces a stream of identical errors.
 */
function fd_bf_import_one($imap, $uid, $mailbox, $validity, &$n)
{
    try {
        $fetched = $imap->fetchMessages(array($uid));
        $n['scanned']++;
        if (empty($fetched[$uid])) { $n['skipped']++; return; }

        $parsed = MimeParser::parse($fetched[$uid]['raw']);

        /*
         * ARCHIVE MODE. Nothing reached from here sends mail, runs a rule or
         * publishes an event -- see the header of this file.
         */
        $stored = fd_store_inbound($parsed, array(
            'mailbox'     => $mailbox,
            'uid'         => (int)$uid,
            'uidvalidity' => $validity,
            'size'        => $fetched[$uid]['size'],
            'archive'     => true,
        ));

        if (!empty($stored['skipped']))       $n['skipped']++;
        elseif (!empty($stored['duplicate'])) $n['duplicates']++;
        else {
            $n['imported']++;
            if (!empty($stored['is_new_ticket'])) $n['new_tickets']++;
        }
    } catch (FdImapException $e) {
        throw $e;
    } catch (Throwable $e) {
        $n['errors']++;
        fd_log('error', 'Backfill failed on UID ' . $uid . ': ' . $e->getMessage(), array('mailbox' => $mailbox));
    }
}

/* ================================================================ status == */
if ($action === 'status') {
    api_success(array('backfill' => fd_bf_shape(fd_bf_state($MAILBOX)), 'mailbox' => fd_cfg('IMAP_USER', FD_IMAP_USER)));
}

/* =============================================================== preview == */
/*
 * What would happen, before anything happens.
 *
 * Deliberately a separate action rather than a flag on start: "this will import
 * 24,113 emails and create about 9,000 archived tickets" is a number the
 * operator should see BEFORE committing, not discover afterwards.
 */
if ($action === 'preview') {
    $until = fd_str('until', '');
    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $until)) api_error('Pick a date to import back to (YYYY-MM-DD).', 400);
    if (strtotime($until) < strtotime(FD_BACKFILL_FLOOR_DATE)) api_error('That date is too far back. The earliest supported is ' . FD_BACKFILL_FLOOR_DATE . '.', 400);
    if (strtotime($until) > time()) api_error('That date is in the future.', 400);

    $skipAuto = fd_bool('skip_auto', false);

    $imap = null;
    try {
        $imap = new ImapClient();
        $imap->login();
        /*
         * Both totals, always, whichever box is ticked. The operator's real
         * question is "what does skipping bounces actually save me?", and a
         * preview that answers it only after they change the setting and look
         * again is a preview that made them guess.
         */
        $scopeAll  = fd_bf_scope($imap, $MAILBOX, $until, false);
        $scopeReal = fd_bf_scope($imap, $MAILBOX, $until, true);
        $imap->close();

        $scope = $skipAuto ? $scopeReal : $scopeAll;
        $uids  = $scope['uids'];
        $known = 0;
        // Chunked so the IN(...) list stays a sane size on a 400k-message mailbox.
        foreach (array_chunk($uids, 500) as $chunk) {
            $known += count(fd_bf_known_uids($MAILBOX, $scope['uidvalidity'], $chunk));
        }
        $toImport = max(0, count($uids) - $known);

        api_success(array(
            'until'        => $until,
            'skip_auto'    => $skipAuto ? 1 : 0,
            'in_mailbox'   => count($uids),
            'total_all'    => count($scopeAll['uids']),
            'total_real'   => count($scopeReal['uids']),
            'auto_count'   => max(0, count($scopeAll['uids']) - count($scopeReal['uids'])),
            'already_have' => $known,
            'to_import'    => $toImport,
            'folder_total' => $scope['exists'],
            'uidvalidity'  => $scope['uidvalidity'],
        ), 'Preview ready');
    } catch (Exception $e) {
        if ($imap) { try { $imap->close(); } catch (Exception $e2) { /* already gone */ } }
        api_error('Could not read the mailbox: ' . $e->getMessage(), 502);
    }
}

/* ================================================================= start == */
if ($action === 'start') {
    $until = fd_str('until', '');
    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $until)) api_error('Pick a date to import back to (YYYY-MM-DD).', 400);
    if (strtotime($until) < strtotime(FD_BACKFILL_FLOOR_DATE)) api_error('That date is too far back. The earliest supported is ' . FD_BACKFILL_FLOOR_DATE . '.', 400);
    if (strtotime($until) > time()) api_error('That date is in the future.', 400);

    $skipAuto = fd_bool('skip_auto', false);

    $st = fd_bf_state($MAILBOX);
    if ($st && $st['status'] === 'running') {
        api_error('A backfill is already running. Stop it before starting a different one.', 409);
    }

    $imap = null;
    try {
        $imap = new ImapClient();
        $imap->login();
        $scope = fd_bf_scope($imap, $MAILBOX, $until, $skipAuto);
        $imap->close();

        $uids = $scope['uids'];
        $known = 0;
        foreach (array_chunk($uids, 500) as $chunk) {
            $known += count(fd_bf_known_uids($MAILBOX, $scope['uidvalidity'], $chunk));
        }
        $toImport = max(0, count($uids) - $known);

        /*
         * The cursor starts ABOVE the highest UID in scope, not at the mailbox's
         * top: everything above it is the forward sync's territory and is
         * already imported. Batches take UIDs strictly below the cursor.
         */
        $cursor = empty($uids) ? 0 : ((int)$uids[0] + 1);
        /*
         * The lowest UID in scope, measured ONCE here.
         *
         * This is the only place the full range is enumerated. Every batch
         * afterwards walks windows between the cursor and this floor, so it
         * never has to ask "what is in the whole range?" again -- and the run
         * knows it is finished when the cursor reaches the floor rather than by
         * re-listing to discover there is nothing left.
         */
        $floor = empty($uids) ? 0 : (int)$uids[count($uids) - 1];

        fd_exec(
            "INSERT INTO fd_backfill
                (mailbox, until_date, uidvalidity, cursor_uid, floor_uid, skip_auto, status, total_in_scope,
                 processed, imported, duplicates, skipped, errors, new_tickets,
                 last_error, started_at, finished_at)
             VALUES (?,?,?,?,?,?,'running',?,0,0,0,0,0,0,NULL,NOW(),NULL)
             ON DUPLICATE KEY UPDATE
                until_date = VALUES(until_date), uidvalidity = VALUES(uidvalidity),
                cursor_uid = VALUES(cursor_uid), floor_uid = VALUES(floor_uid),
                skip_auto = VALUES(skip_auto), status = 'running',
                total_in_scope = VALUES(total_in_scope), processed = 0, imported = 0,
                duplicates = 0, skipped = 0, errors = 0, new_tickets = 0,
                last_error = NULL, started_at = NOW(), finished_at = NULL",
            /*
             * total_in_scope is the length of the WALK, not the number of new
             * messages, because `processed` counts every UID the run steps over
             * including ones it already holds. Using to-import here would push
             * the progress bar past 100% the moment a re-arm re-walked ground
             * it had already covered. The genuinely-new count is reported in
             * the response message instead, where it answers the operator's
             * actual question.
             */
            'ssiiiii', array($MAILBOX, $until, $scope['uidvalidity'], $cursor, $floor,
                             $skipAuto ? 1 : 0, count($uids))
        );

        fd_log('info', 'Backfill armed', array('mailbox' => $MAILBOX, 'until' => $until,
                                               'in_scope' => $toImport, 'cursor' => $cursor,
                                               'skip_auto' => $skipAuto ? 1 : 0,
                                               'by' => $ACTOR['name']));

        api_success(array(
            'backfill' => fd_bf_shape(fd_bf_state($MAILBOX)),
            'to_import' => $toImport,
        ), $toImport > 0
            ? 'Importing ' . number_format($toImport) . ' older message(s) back to ' . $until . '.'
            : 'Nothing older to import — the desk already holds everything back to ' . $until . '.');
    } catch (Exception $e) {
        if ($imap) { try { $imap->close(); } catch (Exception $e2) { /* already gone */ } }
        api_error('Could not start the backfill: ' . $e->getMessage(), 502);
    }
}

/* ================================================================== stop == */
if ($action === 'stop') {
    fd_exec("UPDATE fd_backfill SET status = 'paused', lock_token = NULL, lock_at = NULL
             WHERE mailbox = ? AND status = 'running'", 's', array($MAILBOX));
    api_success(array('backfill' => fd_bf_shape(fd_bf_state($MAILBOX))), 'Backfill paused. Resume picks up where it stopped.');
}

if ($action === 'reset') {
    // Forgets the CURSOR, not the mail. Nothing that was imported is removed --
    // deleting thousands of tickets is not something a button should do.
    fd_exec("DELETE FROM fd_backfill WHERE mailbox = ?", 's', array($MAILBOX));
    api_success(array('backfill' => fd_bf_shape(null)), 'Backfill cleared. Imported mail was kept.');
}

/* =================================================================== run == */
/*
 * One batch. Called in a loop by the UI while the card is open, and once per
 * tick by cron so the run drains on its own with nobody watching.
 */
if ($action === 'run' || $action === 'resume') {

    if ($action === 'resume') {
        fd_exec("UPDATE fd_backfill SET status = 'running', last_error = NULL
                 WHERE mailbox = ? AND status IN ('paused','error')", 's', array($MAILBOX));
    }

    $st = fd_bf_state($MAILBOX);
    if (!$st) api_success(array('backfill' => fd_bf_shape(null), 'done' => true), 'No backfill has been set up.');
    if ($st['status'] !== 'running') {
        api_success(array('backfill' => fd_bf_shape($st), 'done' => true),
                    'Backfill is ' . $st['status'] . '.');
    }

    $token = bin2hex(random_bytes(8));
    if (!fd_bf_lock($MAILBOX, $token)) {
        // Not a failure: another tick holds it and is doing the work.
        api_success(array('backfill' => fd_bf_shape($st), 'done' => false, 'locked' => true),
                    'Another batch is already running.');
    }

    $started = microtime(true);
    $budget  = FD_BACKFILL_MAX_SECONDS;
    $batch   = FD_BACKFILL_BATCH;
    $imap    = null;

    $n = array('scanned' => 0, 'imported' => 0, 'duplicates' => 0, 'skipped' => 0,
               'errors' => 0, 'new_tickets' => 0);

    try {
        $imap = new ImapClient();
        $imap->login();
        $info = $imap->selectFolder($MAILBOX, true);
        $validity = (int)$info['uidvalidity'];

        /*
         * UIDVALIDITY is the whole reason the cursor is not just a number.
         * If the server rebuilt the mailbox mid-run, every remaining UID now
         * refers to a DIFFERENT message: continuing would import the wrong mail
         * under the right-looking cursor. Stop and say so.
         */
        if ((int)$st['uidvalidity'] !== 0 && $validity !== (int)$st['uidvalidity']) {
            fd_exec("UPDATE fd_backfill SET status = 'error', last_error = ? WHERE mailbox = ?",
                    'ss', array('The mailbox was rebuilt while the backfill was running (UIDVALIDITY changed from '
                                . (int)$st['uidvalidity'] . ' to ' . $validity . '). Start it again.', $MAILBOX));
            $imap->close();
            fd_bf_unlock($MAILBOX, $token);
            api_error('The mailbox was rebuilt mid-run (UIDVALIDITY changed). Start the backfill again.', 409);
        }

        $cursor = $st['cursor_uid'] !== null ? (int)$st['cursor_uid'] : 0;
        $floor  = (int)$st['floor_uid'];
        $untilImap = date('d-M-Y', strtotime($st['until_date']));

        if ($cursor <= $floor) {
            fd_exec("UPDATE fd_backfill SET status = 'done', finished_at = NOW() WHERE mailbox = ?",
                    's', array($MAILBOX));
            $imap->close();
            fd_bf_unlock($MAILBOX, $token);
            fd_log('info', 'Backfill complete', array('mailbox' => $MAILBOX, 'until' => $st['until_date']));
            api_success(array('backfill' => fd_bf_shape(fd_bf_state($MAILBOX)), 'done' => true),
                        'Backfill complete — everything back to ' . $st['until_date'] . ' has been imported.');
        }

        /*
         * Walk DOWN in windows until the batch is full or the clock runs out.
         *
         * The cursor means "everything at or above this has been dealt with",
         * so a window is [cursor - WINDOW, cursor - 1]. An empty window (a gap
         * left by deleted mail, or a stretch of the mailbox older than the
         * target date) costs one cheap SEARCH and the loop simply steps past
         * it, which is why sparse mailboxes do not stall the run.
         */
        /*
         * ONLY FETCHES COUNT TOWARDS THE BATCH.
         *
         * A UID already in fd_messages costs one hash lookup against a set the
         * DB handed over 200 at a time -- no IMAP round trip, no parse, no
         * insert. Letting those consume the batch quota is what would make
         * re-arming over an already-imported range unusable: widening a run
         * from 2025 back to 2018 has to walk down through 400,000 messages it
         * already holds, and at 120 skips per minute that is three days of
         * doing nothing. Bounded by the wall clock instead, a single batch
         * skips tens of thousands.
         */
        $fetches = 0;
        /* Whatever was chosen when the run was armed, held for the run's life --
           so a batch cannot silently change what "in scope" means halfway
           through and leave the cursor walking a different set than the floor
           was measured against. */
        $runFilters = !empty($st['skip_auto']) ? fd_bf_auto_filters() : array();

        while (true) {
            if ((microtime(true) - $started) > $budget) break;
            if ($cursor <= $floor) break;              // reached the floor: finished
            if ($fetches >= $batch) break;             // batch full

            $hi = $cursor - 1;
            $lo = max($floor, $hi - FD_BACKFILL_WINDOW + 1);
            if ($hi < $lo) break;

            $uids = $imap->searchDateRange($untilImap, null, $lo, $hi, $runFilters);
            rsort($uids, SORT_NUMERIC);                // newest first: we walk down

            if (empty($uids)) {
                // A gap -- deleted mail, or a stretch older than the target date.
                // One cheap SEARCH, step the cursor past it, carry on.
                $cursor = $lo;
                continue;
            }

            $stopped = false;

            /*
             * Chunked so the "do we already have these?" query never grows an
             * IN(...) list the width of the whole window.
             */
            foreach (array_chunk($uids, 200) as $chunk) {
                $known = fd_bf_known_uids($MAILBOX, $validity, $chunk);

                foreach ($chunk as $uid) {
                    if ((microtime(true) - $started) > $budget || $fetches >= $batch) {
                        // Resume AT this uid next time -- the cursor is exclusive.
                        $cursor = $uid + 1;
                        $stopped = true;
                        break;
                    }

                    $cursor = $uid;                    // this uid is now dealt with

                    if (isset($known[$uid])) { $n['duplicates']++; $n['scanned']++; continue; }

                    $fetches++;
                    fd_bf_import_one($imap, $uid, $MAILBOX, $validity, $n);
                }

                if ($stopped) break;
            }

            // Whole window consumed: the cursor can drop to its bottom edge.
            // Otherwise it already points at the uid to resume from.
            if (!$stopped) $cursor = $lo;
            else break;
        }


        $imap->close();
        $imap = null;

        /*
         * Commit the cursor and the tallies together.
         *
         * "Finished" is now a cursor comparison rather than a re-listing of what
         * is left: the floor was measured once when the run was armed, so
         * reaching it IS the end condition. $isDone is computed here and passed
         * twice so the CASE expressions cannot disagree with each other.
         */
        $isDone = ($cursor <= $floor) ? 1 : 0;

        fd_exec(
            "UPDATE fd_backfill
             SET cursor_uid = ?, processed = processed + ?, imported = imported + ?,
                 duplicates = duplicates + ?, skipped = skipped + ?, errors = errors + ?,
                 new_tickets = new_tickets + ?,
                 status = CASE WHEN ? = 1 THEN 'done' ELSE status END,
                 finished_at = CASE WHEN ? = 1 THEN NOW() ELSE finished_at END
             WHERE mailbox = ?",
            'iiiiiiiiis',
            array($cursor, $n['scanned'], $n['imported'], $n['duplicates'], $n['skipped'],
                  $n['errors'], $n['new_tickets'], $isDone, $isDone, $MAILBOX)
        );

        fd_bf_unlock($MAILBOX, $token);

        $after = fd_bf_state($MAILBOX);
        api_success(array(
            'backfill' => fd_bf_shape($after),
            'batch'    => $n,
            'done'     => $after && $after['status'] === 'done',
        ), $n['imported'] . ' older message(s) imported this batch.');

    } catch (Throwable $e) {
        if ($imap) { try { $imap->close(); } catch (Throwable $e2) { /* already gone */ } }
        fd_exec("UPDATE fd_backfill SET status = 'error', last_error = ? WHERE mailbox = ?",
                'ss', array(substr($e->getMessage(), 0, 900), $MAILBOX));
        fd_bf_unlock($MAILBOX, $token);
        fd_log('error', 'Backfill batch failed: ' . $e->getMessage(), array('mailbox' => $MAILBOX));
        api_error('Backfill batch failed: ' . $e->getMessage(), 500);
    }
}

api_error('Unknown action: ' . $action, 400);

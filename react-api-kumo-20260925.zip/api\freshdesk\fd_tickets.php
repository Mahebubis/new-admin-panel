<?php
/*
 * /api/freshdesk/fd_tickets.php
 *
 * Everything the ticket list and ticket detail need.
 *
 *   action=list        &view &page &per_page &search &sort &sort_dir &filters
 *   action=counts                                     -> per-view badge numbers
 *   action=get         &id                            -> ticket + full conversation
 *   action=create      &subject &email &name ...      -> agent-raised ticket
 *   action=update      &id &status &priority &agent_name &category ...
 *   action=bulk        &ids[] &fields                 -> same fields, many tickets
 *   action=merge       &primary_id &ids[]
 *   action=spam        &ids[] &value=1|0
 *   action=trash       &ids[] &value=1|0
 *   action=delete      &ids[]                         -> permanent, trash only
 *   action=mark_read   &id
 *   action=agents                                     -> assignable agent list
 *   action=meta                                       -> categories/departments/tags in use
 *
 * Rows come back already shaped for the panel (display strings, relative times,
 * boolean view flags) so the UI never has to re-derive them and the two can
 * never disagree about what "unresolved" means.
 */

require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../middleware/auth.php';
require_once __DIR__ . '/lib/config.php';
require_once __DIR__ . '/lib/Helpers.php';
require_once __DIR__ . '/lib/schema.php';
require_once __DIR__ . '/lib/Sla.php';
require_once __DIR__ . '/lib/Automation.php';
require_once __DIR__ . '/lib/Pusher.php';
require_once __DIR__ . '/lib/Storage.php';
require_once __DIR__ . '/lib/TicketStore.php';
/*
 * The rules engine fires from this file (tag_added, ticket_updated) and its
 * forward / canned-reply actions construct an FdMailer. Without this include
 * those actions threw "class not found", were swallowed by the engine's
 * Throwable guard, and showed up in the run log as a skipped action.
 */
require_once __DIR__ . '/lib/Mailer.php';

$jwt = require_jwt();
require_permission('freshdesk', $jwt);
fd_install_error_handlers();
fd_ensure_schema();

$ME = array(
    'id'   => isset($jwt['user_id']) ? (int)$jwt['user_id'] : null,
    'name' => isset($jwt['name']) ? $jwt['name'] : 'Agent',
);

/* ============================================================ view rules == */

/**
 * SQL for each left-hand view. Kept in ONE place and reused by both the list
 * query and the badge counts -- when these two drift apart the sidebar says
 * "8 Open" and the list shows 6, and nobody can tell which is lying.
 */
function fd_view_where($view, $me)
{
    $notDeleted = "t.is_trash = 0 AND t.is_spam = 0 AND t.merged_into IS NULL";
    switch ($view) {
        case 'unresolved':  return "$notDeleted AND t.status NOT IN ('Resolved','Closed')";
        case 'undelivered': return "t.is_trash = 0 AND t.merged_into IS NULL AND t.is_undelivered = 1";
        case 'open':        return "$notDeleted AND t.status IN ('Open','New')";
        case 'closed':      return "$notDeleted AND t.status = 'Closed'";
        case 'resolved':    return "$notDeleted AND t.status IN ('Resolved','Closed')";
        case 'mine':        return "$notDeleted AND (t.agent_user_id = " . ((int)$me['id']) . " OR t.raised_by_agent = 1)";
        case 'trash':       return "t.is_trash = 1";
        case 'spam':        return "t.is_spam = 1 AND t.is_trash = 0";
        case 'overdue':     return "$notDeleted AND t.sla_breached = 1 AND t.status NOT IN ('Resolved','Closed')";
        case 'unassigned':  return "$notDeleted AND (t.agent_user_id IS NULL)";
        /*
         * 'everything' includes spam and trash. The panel loads this once and
         * then filters the eight sidebar views client-side, which is why the
         * Spam and Trash views have anything in them at all -- excluding those
         * rows here would leave both permanently empty no matter what the
         * counts said.
         */
        case 'everything':  return "t.merged_into IS NULL";
        case 'all':
        default:            return $notDeleted;
    }
}

/**
 * Turn the filter drawer's selections into WHERE fragments + bound params.
 * Everything is parameterised: these values come from the browser and several
 * of them (search, tags) are free text.
 */
function fd_build_filters($filters, &$types, &$params)
{
    $where = array();
    $multi = array(
        'status'   => 't.status',
        'priority' => 't.priority',
        'source'   => 't.source',
        'category' => 't.category',
        'agent'    => 't.agent_name',
        'dept'     => 't.department',
    );
    foreach ($multi as $key => $col) {
        if (empty($filters[$key]) || !is_array($filters[$key])) continue;
        $vals = array_values(array_filter(array_map('strval', $filters[$key]), function ($v) { return $v !== ''; }));
        if (empty($vals)) continue;
        $where[] = "$col IN (" . implode(',', array_fill(0, count($vals), '?')) . ")";
        $types  .= str_repeat('s', count($vals));
        foreach ($vals as $v) $params[] = $v;
    }

    if (!empty($filters['sla']) && is_array($filters['sla'])) {
        $vals = array_values(array_filter($filters['sla']));
        if (!empty($vals)) {
            $where[] = "t.sla_status IN (" . implode(',', array_fill(0, count($vals), '?')) . ")";
            $types .= str_repeat('s', count($vals));
            foreach ($vals as $v) $params[] = $v;
        }
    }

    // Dates arrive as YYYY-MM-DD; the "to" bound is made inclusive of the whole
    // day, or a filter of 1 Sep..1 Sep silently returns nothing.
    if (!empty($filters['createdFrom'])) {
        $where[] = "t.created_at >= ?"; $types .= 's'; $params[] = $filters['createdFrom'] . ' 00:00:00';
    }
    if (!empty($filters['createdTo'])) {
        $where[] = "t.created_at <= ?"; $types .= 's'; $params[] = $filters['createdTo'] . ' 23:59:59';
    }
    if (!empty($filters['resolvedAt'])) {
        $where[] = "DATE(t.resolved_at) = ?"; $types .= 's'; $params[] = $filters['resolvedAt'];
    }
    if (!empty($filters['tags']) && is_array($filters['tags'])) {
        $ors = array();
        foreach ($filters['tags'] as $tag) {
            if ($tag === '') continue;
            $ors[] = "t.tags LIKE ?";
            $types .= 's';
            $params[] = '%"' . $tag . '"%';
        }
        if (!empty($ors)) $where[] = '(' . implode(' OR ', $ors) . ')';
    }
    if (isset($filters['unread']) && $filters['unread']) {
        $where[] = "t.unread_count > 0";
    }
    /*
     * Read / unread. Same test the list paints with and the counts use: either
     * something arrived since anyone looked, or nobody has ever opened it.
     */
    if (!empty($filters['readState'])) {
        if ($filters['readState'] === 'unread') {
            $where[] = "(t.unread_count > 0 OR t.last_read_at IS NULL)";
        } elseif ($filters['readState'] === 'read') {
            $where[] = "(t.unread_count = 0 AND t.last_read_at IS NOT NULL)";
        }
    }

    /*
     * "Due within N hours" -- what the Due today stat card counts. It cannot be
     * expressed as a view (it cuts across every status), so it is a filter.
     */
    if (!empty($filters['dueWithinHours'])) {
        $h = max(1, min(720, (int)$filters['dueWithinHours']));
        $where[] = "t.resolution_due BETWEEN NOW() AND DATE_ADD(NOW(), INTERVAL $h HOUR)";
    }
    return $where;
}

function fd_sort_sql($sort, $dir)
{
    $dir = strtoupper($dir) === 'ASC' ? 'ASC' : 'DESC';
    $map = array(
        'Created Date'  => 't.created_at',
        'Updated Date'  => 't.updated_at',
        'Priority'      => "FIELD(t.priority,'Low','Medium','High','Urgent','Critical')",
        'Status'        => 't.status',
        'Customer Name' => 't.requester_name',
        'Due Date'      => 't.resolution_due',
        'Last Activity' => 't.last_message_at',
    );
    $col = isset($map[$sort]) ? $map[$sort] : 't.last_message_at';
    // Secondary key on id keeps pagination stable when the primary key ties --
    // without it, two tickets with the same timestamp can swap pages between
    // requests and one of them is never seen.
    return "$col $dir, t.id DESC";
}

/* ======================================================== row shaping ==== */

/**
 * One ticket row in the exact shape the panel renders, so the UI does no
 * derivation of its own. Display strings (relative time, due text, SLA badge)
 * are computed here because they depend on server time -- a browser with a
 * skewed clock would otherwise show "overdue" on a ticket that is fine.
 */
function fd_shape_ticket($t, $me, $extra = array())
{
    $tags = json_decode((string)$t['tags'], true);
    if (!is_array($tags)) $tags = array();

    $unresolved = !in_array($t['status'], array('Resolved', 'Closed'), true);

    return array_merge(array(
        'id'        => (int)$t['id'],
        'name'      => $t['requester_name'] !== '' ? $t['requester_name'] : fd_display_name('', $t['requester_email']),
        'email'     => $t['requester_email'],
        'phone'     => $t['requester_phone'],
        'subject'   => $t['subject'],
        'category'  => $t['category'] ?: 'General',
        'priority'  => $t['priority'],
        'status'    => $t['status'],
        'source'    => $t['source'],
        'sla'       => $t['sla_status'],
        'agent'     => $t['agent_name'] ?: 'Unassigned',
        'agentId'   => $t['agent_user_id'] !== null ? (int)$t['agent_user_id'] : null,
        'dept'      => $t['department'],
        'type'      => $t['ticket_type'],

        'created'      => fd_relative_time($t['created_at']),
        'createdAt'    => $t['created_at'],
        'updatedAt'    => $t['updated_at'],
        'lastActivity' => fd_relative_time($t['last_message_at'] ?: $t['created_at']),
        'firstResp'    => fd_due_text($t['first_response_due']),
        'resolution'   => fd_due_text($t['resolution_due']),
        'firstResponseAt' => $t['first_response_at'],
        'resolvedAt'   => $t['resolved_at'],
        /*
         * Raw timestamps alongside the display strings above.
         *
         * The panel sorts client-side, and "in 30 min" / "overdue by 2h" are
         * prose -- comparing them alphabetically produces an order that looks
         * plausible and is meaningless. These are what Due Date actually sorts
         * on.
         */
        'firstResponseDue' => $t['first_response_due'],
        'resolutionDue'    => $t['resolution_due'],
        'lastMessageAt'    => $t['last_message_at'],

        'responseStatus' => $t['response_status'],
        'custReplied'    => (bool)$t['customer_replied'],
        'newReplies'     => (int)$t['unread_count'],

        /*
         * Read state, for the inbox treatment in the list.
         *
         * "Unread" is not simply unread_count > 0: a ticket nobody has ever
         * opened is unread too, even though no reply has landed on it since.
         * Both cases are what should stay bold.
         */
        'unread'       => ((int)$t['unread_count'] > 0) || empty($t['last_read_at']),
        'readAt'       => isset($t['last_read_at']) ? $t['last_read_at'] : null,
        'readAgo'      => !empty($t['last_read_at']) ? fd_relative_time($t['last_read_at']) : '',
        'readBy'       => isset($t['last_read_by_name']) ? $t['last_read_by_name'] : null,
        'readByMe'     => isset($t['last_read_by']) && (int)$t['last_read_by'] === (int)$me['id'],
        'repliedAgo'     => $t['last_customer_at'] ? fd_relative_time($t['last_customer_at']) : '',

        // View membership, decided server-side so the sidebar counts and the
        // list can never disagree.
        'mine'        => ((int)$t['agent_user_id'] === (int)$me['id'] && $t['agent_user_id'] !== null) || (bool)$t['raised_by_agent'],
        'undelivered' => (bool)$t['is_undelivered'],
        'spam'        => (bool)$t['is_spam'],
        'trash'       => (bool)$t['is_trash'],
        'unresolved'  => $unresolved,

        'tags'         => $tags,
        'messageCount' => (int)$t['message_count'],
        'attachmentCount' => (int)$t['attachment_count'],
        'mergedInto'   => $t['merged_into'] !== null ? (int)$t['merged_into'] : null,
    ), $extra);
}

/** Contact/student panel for the ticket detail sidebar. */
function fd_contact_block($email)
{
    $norm = fd_norm_email($email);
    $c = fd_query_one("SELECT * FROM fd_contacts WHERE email = ?", 's', array($norm));
    if (!$c) {
        // No contact row yet -- the platform account may still know them.
        $phone = fd_lookup_user_phone($norm);
        return array('registered' => false, 'totalTickets' => 0, 'joined' => '', 'college' => null,
                     'program' => null, 'enrollId' => null, 'contactId' => null, 'blocked' => false)
             + ($phone === '' ? array() : array('phone' => $phone));
    }
    $meta = json_decode((string)$c['meta'], true);
    if (!is_array($meta)) $meta = array();

    /*
     * The number the panel shows, in order of trust: the contact row, then the
     * platform account. Contacts created before fd_contact_link_student() ran
     * -- or before the person registered -- have an empty phone column while
     * the platform account has had the number all along, which is why the
     * sidebar kept saying "Not provided" for people we can obviously call.
     */
    $phone = trim((string)$c['phone']);
    if ($phone === '') {
        $phone = fd_lookup_user_phone($norm);
        // Backfill so the next read is a single query again.
        if ($phone !== '') {
            fd_exec("UPDATE fd_contacts SET phone = ? WHERE id = ?", 'si', array($phone, (int)$c['id']));
        }
    }

    return array(
        'contactId'    => (int)$c['id'],
        'registered'   => (bool)$c['is_registered'],
        'blocked'      => (bool)$c['is_blocked'],
        'userId'       => $c['user_id'] !== null ? (int)$c['user_id'] : null,
        'college'      => $c['college'],
        'program'      => $c['program'],
        'enrollId'     => $c['enroll_id'],
        'totalTickets' => (int)$c['tickets_count'],
        'joined'       => $c['first_seen_at'] ? fd_relative_time($c['first_seen_at']) : '',
        'notes'        => $c['notes'],
        'meta'         => $meta,
    ) + ($phone === '' ? array() : array('phone' => $phone));
    // NB: '+' not array_merge -- an empty phone must not overwrite the
    // requester_phone that fd_shape_ticket already put on the ticket.
}

/**
 * Which column on the users table holds a phone number, or '' if none does.
 *
 * Worked out once per request. This panel runs against installs whose users
 * table differs, and the alternative -- assuming a name -- is what put "Not
 * provided" under numbers that were in the database the whole time.
 */
function fd_user_phone_column()
{
    static $col = null;
    if ($col !== null) return $col;

    global $conn;
    $col = '';
    // "phone" first: it is what the rest of this codebase queries.
    foreach (array('phone', 'mobile', 'mobile_number', 'phone_number', 'contact_number') as $cand) {
        $r = @$conn->query("SHOW COLUMNS FROM users LIKE '" . $conn->real_escape_string($cand) . "'");
        if ($r && $r->num_rows > 0) { $col = $cand; break; }
    }
    if ($col === '') {
        fd_log('warn', 'No phone column found on users; the contact panel will show no numbers.');
    }
    return $col;
}

/**
 * The phone number on the platform account for an address, or ''.
 *
 * The dialling code is prefixed when the install stores one separately, so the
 * sidebar shows the number in the form someone would actually dial.
 */
function fd_lookup_user_phone($email)
{
    global $conn;
    if ($email === '') return '';

    $col = fd_user_phone_column();
    if ($col === '') return '';

    try {
        $hasCode = false;
        $r = @$conn->query("SHOW COLUMNS FROM users LIKE 'country_calling_code'");
        if ($r && $r->num_rows > 0) $hasCode = true;

        $select = $hasCode ? "`$col` AS phone, country_calling_code AS cc" : "`$col` AS phone, '' AS cc";
        $stmt = @$conn->prepare("SELECT $select FROM users
                                 WHERE email = ? AND `$col` IS NOT NULL AND `$col` <> ''
                                 LIMIT 1");
        if (!$stmt) return '';
        $stmt->bind_param('s', $email);
        if (!$stmt->execute()) { $stmt->close(); return ''; }
        $row = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        if (!$row) return '';

        $phone = trim((string)$row['phone']);
        if ($phone === '') return '';

        $cc = trim((string)$row['cc']);
        // Only when the number does not already carry one -- "+91 +91 90000"
        // is worse than no dialling code at all.
        if ($cc !== '' && strpos($phone, '+') !== 0) {
            $phone = '+' . ltrim($cc, '+') . ' ' . $phone;
        }
        return $phone;
    } catch (Throwable $e) {
        fd_log('debug', 'Phone lookup skipped: ' . $e->getMessage());
        return '';
    }
}

/* ================================================================ router == */

$action = fd_str('action', 'list');
$GLOBALS['FD_ACTION'] = $action;

/*
 * No try/catch wraps the router on purpose.
 *
 * PHP only hoists function declarations that sit at the top level of a file --
 * a `function` inside a try block is declared when execution REACHES it. The
 * helpers below (fd_view_counts, fd_bytes_human, fd_apply_ticket_fields) are
 * defined after the action blocks that call them, so wrapping everything in a
 * try would make every one of those calls a fatal "undefined function".
 *
 * fd_install_error_handlers() above already converts any uncaught throwable
 * into a logged, JSON 500 -- which is all the try block was doing.
 */

/* ------------------------------------------------------------------ list -- */
if ($action === 'list') {
    $view    = fd_str('view', 'all');
    $page    = max(1, fd_int('page', 1));
    /*
     * 500 rather than 100: the panel keeps the whole working set in memory and
     * does its own view filtering, searching and sorting (which is what makes
     * switching between the eight sidebar views instant). The ceiling is still
     * a ceiling -- a desk past 500 live tickets should page through the server
     * instead, and `total` in the response is what tells the UI that.
     */
    $perPage = max(1, min(500, fd_int('per_page', 25)));
    $search  = fd_str('search', '');
    $sort    = fd_str('sort', 'Created Date');
    $dir     = fd_str('sort_dir', 'DESC');
    $filters = fd_arr('filters', array());

    $types = ''; $params = array();
    $where = array(fd_view_where($view, $ME));

    if ($search !== '') {
        // Numeric input is almost always a ticket number -- match it exactly
        // and first, so pasting "336270" jumps straight to that ticket instead
        // of returning every message that happens to contain the digits.
        if (ctype_digit($search)) {
            $where[] = "(t.id = ? OR t.subject LIKE ? OR t.requester_name LIKE ? OR t.requester_email LIKE ?)";
            $types .= 'isss';
            $params[] = (int)$search;
            $like = '%' . $search . '%';
            $params[] = $like; $params[] = $like; $params[] = $like;
        } else {
            $where[] = "(t.subject LIKE ? OR t.requester_name LIKE ? OR t.requester_email LIKE ? OR t.requester_phone LIKE ? OR t.category LIKE ? OR t.agent_name LIKE ?)";
            $like = '%' . $search . '%';
            $types .= 'ssssss';
            for ($i = 0; $i < 6; $i++) $params[] = $like;
        }
    }

    $where = array_merge($where, fd_build_filters($filters, $types, $params));
    $whereSql = 'WHERE ' . implode(' AND ', $where);

    $countRow = fd_query_one("SELECT COUNT(*) AS c FROM fd_tickets t $whereSql", $types, $params);
    $total = $countRow ? (int)$countRow['c'] : 0;

    $offset = ($page - 1) * $perPage;
    // LIMIT/OFFSET are interpolated as integers (cast above), not bound --
    // MySQL will not accept placeholders there in a prepared statement.
    $rows = fd_query(
        "SELECT t.* FROM fd_tickets t $whereSql ORDER BY " . fd_sort_sql($sort, $dir) . " LIMIT $perPage OFFSET $offset",
        $types, $params
    );

    // Last message preview for every row in ONE query rather than N -- a 25-row
    // page was otherwise 26 round-trips.
    $previews = array();
    if (!empty($rows)) {
        $ids = array_map(function ($r) { return (int)$r['id']; }, $rows);
        $place = implode(',', array_fill(0, count($ids), '?'));
        $pv = fd_query(
            "SELECT m1.ticket_id, m1.direction, m1.snippet, m1.from_name, m1.created_at, m1.has_attachments
             FROM fd_messages m1
             INNER JOIN (SELECT ticket_id, MAX(id) AS mx FROM fd_messages WHERE ticket_id IN ($place) GROUP BY ticket_id) m2
                     ON m2.mx = m1.id",
            str_repeat('i', count($ids)), $ids
        );
        foreach ($pv as $p) $previews[(int)$p['ticket_id']] = $p;
    }

    $out = array();
    foreach ($rows as $t) {
        $p = isset($previews[(int)$t['id']]) ? $previews[(int)$t['id']] : null;
        $out[] = fd_shape_ticket($t, $ME, array(
            'preview'    => $p ? $p['snippet'] : '',
            'previewWho' => $p ? ($p['direction'] === 'inbound' ? 'cust' : ($p['direction'] === 'note' ? 'note' : 'agent')) : null,
            'hasAttachments' => $p ? (bool)$p['has_attachments'] : false,
        ));
    }

    $cur = fd_query_one("SELECT MAX(id) AS c FROM fd_activity");

    api_success(array(
        'tickets'  => $out,
        'total'    => $total,
        'page'     => $page,
        'per_page' => $perPage,
        'pages'    => (int)ceil($total / $perPage),
        'counts'   => fd_view_counts($ME),
        // Handed back so the client's realtime fallback can poll "what changed
        // since the moment this list was built" with no gap and no overlap.
        'cursor'   => $cur ? (int)$cur['c'] : 0,
    ), 'OK');
}

/* ---------------------------------------------------------------- counts -- */
function fd_view_counts($me)
{
    $views = array('all', 'unresolved', 'undelivered', 'open', 'closed', 'mine', 'trash', 'spam', 'overdue', 'unassigned', 'resolved');
    $out = array();

    /*
     * "Unread" is the same test the list paints with: something arrived since
     * anyone looked, OR nobody has ever opened it. Counting only unread_count
     * would call a ticket nobody has touched "read", which is backwards.
     */
    $unreadTest = "(t.unread_count > 0 OR t.last_read_at IS NULL)";

    foreach ($views as $v) {
        $where = fd_view_where($v, $me);
        $r = fd_query_one("SELECT COUNT(*) AS c FROM fd_tickets t WHERE $where");
        $out[$v] = $r ? (int)$r['c'] : 0;

        $u = fd_query_one("SELECT COUNT(*) AS c FROM fd_tickets t WHERE $where AND $unreadTest");
        $out[$v . 'Unread'] = $u ? (int)$u['c'] : 0;
        $out[$v . 'Read']   = max(0, $out[$v] - $out[$v . 'Unread']);
    }
    $r = fd_query_one("SELECT COUNT(*) AS c FROM fd_tickets t WHERE " . fd_view_where('all', $me) . " AND t.unread_count > 0");
    $out['unread'] = $r ? (int)$r['c'] : 0;

    return $out;
}

if ($action === 'counts') {
    api_success(array('counts' => fd_view_counts($ME)), 'OK');
}

/* ------------------------------------------------------------------- get -- */
if ($action === 'get') {
    $id = fd_int('id', 0);
    if ($id <= 0) api_error('Ticket id is required', 400);

    $t = fd_query_one("SELECT * FROM fd_tickets WHERE id = ?", 'i', array($id));
    if (!$t) api_error('Ticket #' . $id . ' was not found. It may have been deleted or merged.', 404);

    // A merged ticket redirects rather than showing an empty shell -- the panel
    // follows this so a bookmarked link to a merged ticket still lands somewhere
    // useful.
    if (!empty($t['merged_into'])) {
        api_success(array('redirect_to' => (int)$t['merged_into']), 'This ticket was merged.');
    }

    $messages = fd_query(
        "SELECT id, direction, msg_type, from_name, from_email, to_emails, cc_emails, subject,
                body_html, body_text, snippet, has_attachments, attachment_count, delivery_status,
                delivery_error, sent_by_name, message_date, created_at, is_auto_reply
         FROM fd_messages WHERE ticket_id = ? ORDER BY id ASC", 'i', array($id)
    );

    $atts = fd_query("SELECT id, message_id, filename, mime_type, size_bytes, is_inline, direction, created_at
                      FROM fd_attachments WHERE ticket_id = ? ORDER BY id ASC", 'i', array($id));
    $attByMsg = array();
    $allAttachments = array();     // flat list for the ticket's Attachments tab
    foreach ($atts as $a) {
        $mid = (int)$a['message_id'];
        if (!isset($attByMsg[$mid])) $attByMsg[$mid] = array();
        $shaped = array(
            'id'       => (int)$a['id'],
            'name'     => $a['filename'],
            'mime'     => $a['mime_type'],
            'size'     => (int)$a['size_bytes'],
            'sizeText' => fd_bytes_human((int)$a['size_bytes']),
            'inline'   => (bool)$a['is_inline'],
            'url'      => fd_attachment_url((int)$a['id'], 'download'),
            'viewUrl'  => fd_attachment_url((int)$a['id'], 'view'),
        );
        $attByMsg[$mid][] = $shaped;
        // Inline images are part of a message body, not files the customer
        // "attached" -- listing them would fill the tab with sig logos.
        if (!$a['is_inline']) $allAttachments[] = $shaped;
    }

    $convo = array();
    foreach ($messages as $m) {
        $mid = (int)$m['id'];
        $who = $m['direction'] === 'inbound' ? 'cust' : ($m['direction'] === 'note' ? 'note' : 'agent');
        $parts = fd_split_quoted_html($m['body_html']);
        $convo[] = array(
            'id'        => $mid,
            'who'       => $who,
            'type'      => $m['msg_type'],
            'msg'       => $m['body_text'] !== '' ? fd_strip_quoted_text($m['body_text']) : fd_html_to_text($m['body_html']),
            /*
             * Split first, then tidy. The panel renders 'html' and keeps
             * 'quoted' behind a toggle, the way Freshdesk does -- without this
             * the entire thread was repeated inside every single reply.
             */
            'html'      => fd_sign_html_attachments(fd_tidy_email_html($parts['visible'])),
            'quoted'    => $parts['quoted'] === '' ? '' : fd_sign_html_attachments(fd_tidy_email_html($parts['quoted'])),
            'fullText'  => $m['body_text'],
            'from'      => $m['from_name'] ?: $m['from_email'],
            'fromEmail' => $m['from_email'],
            'to'        => json_decode((string)$m['to_emails'], true) ?: array(),
            'cc'        => json_decode((string)$m['cc_emails'], true) ?: array(),
            'subject'   => $m['subject'],
            'at'        => date('j M, g:i a', strtotime($m['message_date'] ?: $m['created_at'])),
            'atIso'     => $m['message_date'] ?: $m['created_at'],
            'ago'       => fd_relative_time($m['message_date'] ?: $m['created_at']),
            'att'       => (bool)$m['has_attachments'],
            'attachments' => isset($attByMsg[$mid]) ? $attByMsg[$mid] : array(),
            'status'    => $m['delivery_status'],
            'error'     => $m['delivery_error'],
            'sentBy'    => $m['sent_by_name'],
            'isAuto'    => (bool)$m['is_auto_reply'],
        );
    }

    $activity = fd_query(
        "SELECT id, event, actor_type, actor_name, summary, created_at
         FROM fd_activity WHERE ticket_id = ? ORDER BY id DESC LIMIT 40", 'i', array($id)
    );
    foreach ($activity as &$a) { $a['ago'] = fd_relative_time($a['created_at']); }
    unset($a);

    /*
     * Opening a ticket is reading it, and the desk records WHO.
     *
     * Written on every open, not only when unread_count > 0: "Saif read this
     * four minutes ago" is the useful fact on a shared queue, and it stays
     * useful after the badge has already been cleared by someone else.
     */
    fd_exec("UPDATE fd_tickets
             SET unread_count = 0, last_read_at = NOW(), last_read_by = ?, last_read_by_name = ?
             WHERE id = ?",
            'isi', array((int)$ME['id'], (string)$ME['name'], $id));
    $t['unread_count']      = 0;
    $t['last_read_at']      = date('Y-m-d H:i:s');
    $t['last_read_by']      = (int)$ME['id'];
    $t['last_read_by_name'] = $ME['name'];

    $ctx = json_decode((string)$t['student_context'], true);

    api_success(array(
        'ticket'   => fd_shape_ticket($t, $ME, array_merge(
            fd_contact_block($t['requester_email']),
            array('studentContext' => is_array($ctx) ? $ctx : null)
        )),
        'convo'    => $convo,
        'attachments' => $allAttachments,
        'activity' => $activity,
    ), 'OK');
}

function fd_bytes_human($b)
{
    if ($b < 1024) return $b . ' B';
    if ($b < 1048576) return round($b / 1024, 1) . ' KB';
    if ($b < 1073741824) return round($b / 1048576, 1) . ' MB';
    return round($b / 1073741824, 2) . ' GB';
}

/* ---------------------------------------------------------------- create -- */
if ($action === 'create') {
    $email   = fd_str('email', '');
    $subject = fd_str('subject', '');
    if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) api_error('A valid customer email is required', 400);
    if ($subject === '') api_error('Subject is required', 400);

    $id = fd_create_ticket(array(
        'subject'         => $subject,
        'requester_email' => $email,
        'requester_name'  => fd_str('name', ''),
        'requester_phone' => fd_str('phone', ''),
        'priority'        => fd_str('priority', 'Medium'),
        'status'          => fd_str('status', 'Open'),
        'source'          => fd_str('source', 'Portal'),
        'category'        => fd_str('category', 'General'),
        'department'      => fd_str('dept', null),
        'agent_name'      => fd_str('agent', $ME['name']),
        'tags'            => fd_arr('tags', array()),
        'raised_by_agent' => 1,
    ));

    fd_activity($id, 'ticket-created', $ME['name'] . ' created ticket #' . $id, array('type' => 'agent', 'id' => $ME['id'], 'name' => $ME['name']));

    // An agent-raised ticket usually needs the first mail sent too; the panel
    // follows this with fd_messages.php?action=reply when a body was typed.
    api_success(array('id' => $id, 'ticket' => fd_shape_ticket(fd_query_one("SELECT * FROM fd_tickets WHERE id = ?", 'i', array($id)), $ME)), 'Ticket created');
}

/* ---------------------------------------------------------------- update -- */

/**
 * Apply a field set to one ticket. Shared by `update` and `bulk` so a single
 * ticket edit and a 50-ticket bulk edit can never behave differently.
 */
function fd_apply_ticket_fields($id, $fields, $me)
{
    $notifyAgentId = null;     // set when this call changes the assignee
    $t = fd_query_one("SELECT * FROM fd_tickets WHERE id = ?", 'i', array((int)$id));
    if (!$t) return array('ok' => false, 'error' => 'Ticket #' . $id . ' not found');

    $sets = array(); $types = ''; $params = array(); $changes = array();

    $simple = array(
        'status'   => array('status', 's', array('New','Open','Pending','In Progress','Waiting','Escalated','Resolved','Closed','Overdue')),
        'priority' => array('priority', 's', array('Low','Medium','High','Urgent','Critical')),
        'source'   => array('source', 's', array('Email','Chat','WhatsApp','Phone','Portal')),
        'category' => array('category', 's', null),
        'dept'     => array('department', 's', null),
        'type'     => array('ticket_type', 's', null),
    );
    foreach ($simple as $key => $def) {
        if (!array_key_exists($key, $fields) || $fields[$key] === '' || $fields[$key] === null) continue;
        $val = (string)$fields[$key];
        // An allow-list, not a trim: status drives every view filter and the SLA
        // logic, so an arbitrary string here would make a ticket invisible in
        // every view at once.
        if ($def[2] !== null && !in_array($val, $def[2], true)) {
            return array('ok' => false, 'error' => 'Invalid ' . $key . ': ' . $val);
        }
        if ((string)$t[$def[0]] === $val) continue;
        $sets[] = $def[0] . ' = ?'; $types .= $def[1]; $params[] = $val;
        $changes[$key] = $val;
    }

    if (array_key_exists('agent', $fields) && $fields['agent'] !== null && $fields['agent'] !== '') {
        $agentName = (string)$fields['agent'];
        $agentId = null;
        if ($agentName !== 'Unassigned') {
            $a = fd_query_one("SELECT user_id FROM users WHERE name = ? LIMIT 1", 's', array($agentName));
            if ($a) $agentId = (int)$a['user_id'];
        }
        $sets[] = 'agent_name = ?'; $types .= 's'; $params[] = $agentName;
        $sets[] = 'agent_user_id = ?'; $types .= 'i'; $params[] = $agentId;
        $changes['agent'] = $agentName;
        // Picked up after the UPDATE lands -- telling someone about an
        // assignment that then failed to save would be worse than silence.
        $notifyAgentId = $agentId;
    }

    if (array_key_exists('tags', $fields) && is_array($fields['tags'])) {
        $tags = array_values(array_unique(array_filter(array_map('trim', $fields['tags']))));
        $sets[] = 'tags = ?'; $types .= 's'; $params[] = json_encode($tags);
        $changes['tags'] = $tags;
    }

    // Resolution timestamps are derived from status, never sent by the client --
    // otherwise a stale browser tab can un-resolve a ticket by echoing back an
    // old value.
    if (isset($changes['status'])) {
        if (in_array($changes['status'], array('Resolved', 'Closed'), true)) {
            $sets[] = 'resolved_at = COALESCE(resolved_at, NOW())';
            if ($changes['status'] === 'Closed') $sets[] = 'closed_at = COALESCE(closed_at, NOW())';
        } else {
            $sets[] = 'resolved_at = NULL';
            $sets[] = 'closed_at = NULL';
        }
    }

    if (empty($sets)) return array('ok' => true, 'changes' => array(), 'noop' => true);

    $sets[] = 'updated_at = NOW()';
    $params[] = (int)$id; $types .= 'i';
    fd_exec("UPDATE fd_tickets SET " . implode(', ', $sets) . " WHERE id = ?", $types, $params);

    // A priority change moves the SLA targets; anything else may move the badge.
    if (isset($changes['priority'])) fd_sla_reprice($id, $changes['priority']);
    else fd_sla_refresh($id);

    if (!empty($notifyAgentId)) {
        fd_notify_user($notifyAgentId, 'assigned', $id,
            'Ticket #' . $id . ' was assigned to you',
            (string)$t['subject'],
            array('id' => $me['id'], 'name' => $me['name']));
    }

    $parts = array();
    foreach ($changes as $k => $v) $parts[] = $k . ' -> ' . (is_array($v) ? implode(', ', $v) : $v);
    fd_activity($id, 'ticket-updated', $me['name'] . ' updated #' . $id . ' (' . implode('; ', $parts) . ')',
                array('type' => 'agent', 'id' => $me['id'], 'name' => $me['name']), array('changes' => $changes));

    return array('ok' => true, 'changes' => $changes);
}

if ($action === 'update') {
    $id = fd_int('id', 0);
    if ($id <= 0) api_error('Ticket id is required', 400);
    $r = fd_apply_ticket_fields($id, fd_input(), $ME);
    if (empty($r['ok'])) api_error($r['error'], 400);

    /*
     * Adding a tag is its own event, because "notify the team when a ticket is
     * tagged Urgent" is the rule people actually want and it cannot be
     * expressed as ticket_updated without firing on every status change too.
     */
    $changed = isset($r['changes']) && is_array($r['changes']) ? $r['changes'] : array();
    if (in_array('tags', $changed, true)) fd_automation_run('tag_added', $id);
    fd_automation_run('ticket_updated', $id);

    $t = fd_query_one("SELECT * FROM fd_tickets WHERE id = ?", 'i', array($id));
    api_success(array('ticket' => fd_shape_ticket($t, $ME), 'changes' => $r['changes']), 'Ticket updated');
}

if ($action === 'bulk') {
    $ids = array_values(array_unique(array_map('intval', fd_arr('ids', array()))));
    if (empty($ids)) api_error('Select at least one ticket', 400);
    if (count($ids) > 200) api_error('Too many tickets in one operation (max 200)', 400);

    $fields = fd_arr('fields', array());
    $ok = 0; $failed = array();
    foreach ($ids as $id) {
        $r = fd_apply_ticket_fields($id, $fields, $ME);
        // One bad ticket in a batch of fifty must not abort the other
        // forty-nine; report them instead.
        if (!empty($r['ok'])) $ok++; else $failed[] = array('id' => $id, 'error' => $r['error']);
    }
    fd_emit('tickets-bulk-updated', array('ids' => $ids, 'fields' => $fields), array(
        'actor_type' => 'agent', 'actor_id' => $ME['id'], 'actor_name' => $ME['name'],
        'summary' => $ME['name'] . ' bulk-updated ' . $ok . ' tickets',
    ));
    api_success(array('updated' => $ok, 'failed' => $failed, 'counts' => fd_view_counts($ME)),
                $ok . ' ticket' . ($ok === 1 ? '' : 's') . ' updated');
}

/* ----------------------------------------------------------------- merge -- */
if ($action === 'merge') {
    $primary = fd_int('primary_id', 0);
    $ids = array_values(array_diff(array_map('intval', fd_arr('ids', array())), array($primary)));
    if ($primary <= 0 || empty($ids)) api_error('Pick a primary ticket and at least one to merge into it', 400);

    $p = fd_query_one("SELECT * FROM fd_tickets WHERE id = ?", 'i', array($primary));
    if (!$p) api_error('Primary ticket not found', 404);

    $moved = 0;
    foreach ($ids as $id) {
        if ($id === $primary) continue;
        $src = fd_query_one("SELECT * FROM fd_tickets WHERE id = ?", 'i', array($id));
        if (!$src) continue;

        // Messages and attachments move to the primary; the source becomes a
        // tombstone pointing at it rather than being deleted, so old links and
        // any [#IS-nnn] token still in a customer's mail client keep resolving.
        fd_exec("UPDATE fd_messages SET ticket_id = ? WHERE ticket_id = ?", 'ii', array($primary, $id));
        fd_exec("UPDATE fd_attachments SET ticket_id = ? WHERE ticket_id = ?", 'ii', array($primary, $id));
        fd_exec("UPDATE fd_tickets SET merged_into = ?, status = 'Closed', closed_at = NOW(), updated_at = NOW() WHERE id = ?",
                'ii', array($primary, $id));
        $moved++;
    }

    $tags = json_decode((string)$p['tags'], true);
    if (!is_array($tags)) $tags = array();
    if (!in_array('Merged', $tags, true)) $tags[] = 'Merged';
    fd_exec("UPDATE fd_tickets SET tags = ?, updated_at = NOW() WHERE id = ?", 'si', array(json_encode($tags), $primary));

    fd_recount_ticket($primary);
    fd_sla_refresh($primary);
    fd_activity($primary, 'tickets-merged', $ME['name'] . ' merged ' . $moved . ' ticket(s) into #' . $primary,
                array('type' => 'agent', 'id' => $ME['id'], 'name' => $ME['name']), array('merged' => $ids));

    api_success(array('primary' => $primary, 'merged' => $moved, 'counts' => fd_view_counts($ME)),
                $moved . ' ticket' . ($moved === 1 ? '' : 's') . ' merged into #' . $primary);
}

/* ------------------------------------------------------- spam / trash ---- */
if ($action === 'spam' || $action === 'trash') {
    $ids = array_values(array_unique(array_map('intval', fd_arr('ids', array()))));
    if (empty($ids)) api_error('Select at least one ticket', 400);
    $value = fd_bool('value', true) ? 1 : 0;
    $col = ($action === 'spam') ? 'is_spam' : 'is_trash';

    $place = implode(',', array_fill(0, count($ids), '?'));
    fd_exec("UPDATE fd_tickets SET $col = ?, updated_at = NOW() WHERE id IN ($place)",
            'i' . str_repeat('i', count($ids)), array_merge(array($value), $ids));

    // Marking a sender as spam should stop them reaching the desk again, not
    // just hide this one ticket -- otherwise the agent does it again tomorrow.
    if ($action === 'spam' && $value === 1 && fd_bool('block_sender', false)) {
        $rows = fd_query("SELECT DISTINCT requester_email FROM fd_tickets WHERE id IN ($place)",
                         str_repeat('i', count($ids)), $ids);
        foreach ($rows as $r) {
            fd_exec("UPDATE fd_contacts SET is_blocked = 1 WHERE email = ?", 's', array($r['requester_email']));
        }
    }

    fd_emit($action === 'spam' ? 'tickets-spam' : 'tickets-trash', array('ids' => $ids, 'value' => $value), array(
        'actor_type' => 'agent', 'actor_id' => $ME['id'], 'actor_name' => $ME['name'],
        'summary' => $ME['name'] . ($value ? ' moved ' : ' restored ') . count($ids) . ' ticket(s)',
    ));
    api_success(array('counts' => fd_view_counts($ME)),
                count($ids) . ' ticket' . (count($ids) === 1 ? '' : 's') . ($value ? ' moved' : ' restored'));
}

/* ---------------------------------------------------------------- delete -- */
if ($action === 'delete') {
    $ids = array_values(array_unique(array_map('intval', fd_arr('ids', array()))));
    if (empty($ids)) api_error('Select at least one ticket', 400);

    /*
     * Permanent deletion is only allowed from Trash. Two-step deletion is the
     * only thing standing between a mis-click on a bulk selection and losing a
     * customer conversation that cannot be recovered from anywhere.
     */
    $place = implode(',', array_fill(0, count($ids), '?'));
    $rows = fd_query("SELECT id FROM fd_tickets WHERE id IN ($place) AND is_trash = 1",
                     str_repeat('i', count($ids)), $ids);
    $deletable = array_map(function ($r) { return (int)$r['id']; }, $rows);
    if (empty($deletable)) api_error('Only tickets already in Trash can be deleted permanently.', 400);

    $dp = implode(',', array_fill(0, count($deletable), '?'));
    $t = str_repeat('i', count($deletable));

    // Stored objects first: a row deleted before its file leaves an orphan
    // nobody can ever find again, and an orphaned S3 object bills forever.
    $files = fd_query("SELECT storage, s3_key, rel_path FROM fd_attachments WHERE ticket_id IN ($dp)", $t, $deletable);
    foreach ($files as $f) { fd_storage_delete($f); }
    foreach ($deletable as $tid) { @rmdir(FD_ATTACH_DIR . '/' . (int)$tid); }

    fd_exec("DELETE FROM fd_attachments WHERE ticket_id IN ($dp)", $t, $deletable);
    fd_exec("DELETE FROM fd_messages WHERE ticket_id IN ($dp)", $t, $deletable);
    fd_exec("DELETE FROM fd_tickets WHERE id IN ($dp)", $t, $deletable);

    fd_emit('tickets-deleted', array('ids' => $deletable), array(
        'actor_type' => 'agent', 'actor_id' => $ME['id'], 'actor_name' => $ME['name'],
        'summary' => $ME['name'] . ' permanently deleted ' . count($deletable) . ' ticket(s)',
    ));
    api_success(array('deleted' => count($deletable), 'counts' => fd_view_counts($ME)),
                count($deletable) . ' ticket(s) permanently deleted');
}

/* ------------------------------------------------------------- mark_read -- */
/* -------------------------------------------------------------- close_all -- */
/*
 * Bulk-close every ticket matching a scope. Built for exactly one situation:
 * the desk has just imported a long-lived mailbox and the queue is thousands of
 * historical emails that were dealt with years ago, elsewhere.
 *
 * Why this is not just `action=bulk` with 1,755 ids:
 *   - bulk caps at 200 ids and the panel only holds 500 rows in memory;
 *   - bulk runs fd_apply_ticket_fields per ticket, which is one UPDATE, one
 *     SLA recompute and one activity row EACH. At this size that is ~5,000
 *     statements and a guaranteed timeout.
 * This is set-based instead: a handful of UPDATEs and ONE activity row.
 *
 * IT SENDS NO EMAIL. Closing only writes columns; nothing in the send path is
 * touched, so no customer hears about this.
 *
 * Dry run unless confirm=1. The response tells you exactly how many rows would
 * change before anything does.
 */
if ($action === 'close_all') {
    $confirm = fd_bool('confirm', false);
    $scope   = fd_str('scope', 'unresolved');
    $status  = fd_str('status', 'Closed');
    if (!in_array($status, array('Closed', 'Resolved'), true)) {
        api_error('close_all can only set Closed or Resolved.', 400);
    }

    // Bound the blast radius to things that are genuinely open.
    $where  = "t.is_trash = 0 AND t.merged_into IS NULL AND t.status NOT IN ('Resolved','Closed')";
    if ($scope === 'unresolved')      $where .= " AND t.is_spam = 0";
    elseif ($scope === 'spam')        $where .= " AND t.is_spam = 1";
    elseif ($scope === 'all')         { /* spam included */ }
    else api_error('Unknown scope: ' . $scope, 400);

    $types = ''; $params = array();

    /*
     * Optional cut-off: close everything older than a date and leave recent
     * conversations alone. This is the safe way to clear an imported backlog
     * without touching the handful of tickets someone is actually working.
     */
    $before = fd_str('before', '');
    if ($before !== '') {
        $ts = strtotime($before);
        if (!$ts) api_error('`before` is not a date we can read (use YYYY-MM-DD).', 400);
        $where .= " AND t.created_at < ?";
        $types .= 's'; $params[] = date('Y-m-d H:i:s', $ts);
    }

    // Optionally spare tickets where the customer is still waiting on us.
    if (fd_bool('keep_awaiting_reply', false)) {
        $where .= " AND t.customer_replied = 0";
    }

    $cnt = fd_query_one("SELECT COUNT(*) AS c FROM fd_tickets t WHERE $where", $types, $params);
    $matched = $cnt ? (int)$cnt['c'] : 0;

    if (!$confirm) {
        $sample = fd_query("SELECT t.id, t.subject, t.requester_email, t.status, t.created_at
                            FROM fd_tickets t WHERE $where ORDER BY t.id ASC LIMIT 10", $types, $params);
        api_success(array(
            'dry_run' => true, 'matched' => $matched, 'status' => $status,
            'scope' => $scope, 'before' => $before ?: null,
            'sample' => $sample,
        ), $matched . ' ticket(s) would be set to ' . $status . '. Re-run with confirm=1 to apply.');
    }

    if ($matched === 0) api_success(array('closed' => 0), 'Nothing to close.');

    /*
     * Chunked by id so one statement never locks the whole table, and so a
     * timeout mid-run leaves a consistent partial result the operator can
     * simply re-run rather than a half-updated mess.
     */
    $closed = 0;
    $guard  = 0;
    while ($guard++ < 200) {
        $batch = fd_query("SELECT t.id FROM fd_tickets t WHERE $where ORDER BY t.id ASC LIMIT 500", $types, $params);
        if (empty($batch)) break;
        $ids = array_map(function ($r) { return (int)$r['id']; }, $batch);
        $place = implode(',', array_fill(0, count($ids), '?'));

        $closed += fd_exec(
            "UPDATE fd_tickets
             SET status = ?,
                 resolved_at = COALESCE(resolved_at, NOW()),
                 closed_at   = CASE WHEN ? = 'Closed' THEN COALESCE(closed_at, NOW()) ELSE closed_at END,
                 response_status = 'Resolved',
                 customer_replied = 0,
                 unread_count = 0,
                 -- The clocks stopped when the ticket closed; leaving these set
                 -- would keep the whole backlog painted red forever.
                 sla_status = 'On track',
                 sla_breached = 0,
                 updated_at = NOW()
             WHERE id IN ($place)",
            'ss' . str_repeat('i', count($ids)),
            array_merge(array($status, $status), $ids)
        );
    }

    /*
     * ONE audit row, not one per ticket -- 1,755 identical activity entries
     * would bury every real event in the feed and in the Live Feed panel.
     * fd_emit directly rather than fd_activity() because this event belongs to
     * no single ticket, and fd_activity casts its id to int (null -> 0).
     */
    fd_emit('tickets-bulk-closed', array('closed' => $closed, 'scope' => $scope, 'status' => $status), array(
        'actor_type' => 'agent',
        'actor_id'   => $ME['id'],
        'actor_name' => $ME['name'],
        'summary'    => $ME['name'] . ' closed ' . $closed . ' ticket(s) in bulk (scope: ' . $scope . ($before ? ', before ' . $before : '') . ')',
    ));

    fd_log('info', 'Bulk close: ' . $closed . ' ticket(s) -> ' . $status, array('by' => $ME['name'], 'scope' => $scope));

    api_success(array('closed' => $closed, 'counts' => fd_view_counts($ME)),
                $closed . ' ticket(s) set to ' . $status . '. No email was sent.');
}

if ($action === 'mark_read') {
    $ids = fd_arr('ids', array());
    if (empty($ids)) { $one = fd_int('id', 0); if ($one) $ids = array($one); }
    $ids = array_values(array_unique(array_map('intval', $ids)));
    if (empty($ids)) api_error('Ticket id is required', 400);
    $place = implode(',', array_fill(0, count($ids), '?'));
    // Same stamp as opening one, so the list agrees either way. The reader's
    // name is bound, not interpolated -- it comes from the session, but every
    // other query in this file is prepared and this one is not going to be the
    // exception that teaches the next person otherwise.
    fd_exec("UPDATE fd_tickets
             SET unread_count = 0, customer_replied = 0,
                 last_read_at = NOW(), last_read_by = ?, last_read_by_name = ?
             WHERE id IN ($place)",
            'is' . str_repeat('i', count($ids)),
            array_merge(array((int)$ME['id'], (string)$ME['name']), $ids));
    api_success(array('counts' => fd_view_counts($ME)), 'Marked as read');
}

/* ---------------------------------------------------------------- agents -- */
/*
 * The team, with what each agent is actually carrying.
 *
 * Separate from the 'agents' action, which is the assignee picker and is
 * fetched on nearly every screen: this one does three aggregates per row and
 * has no business being on that path.
 */
if ($action === 'team') {
    $rows = array();
    $error = null;
    try {
        /*
         * Counts by agent_user_id, not by name. Two people called Priya are
         * one row if you group by name, and an agent who has been renamed
         * loses their whole history.
         */
        $rows = fd_query(
            "SELECT u.user_id, u.name, u.email, u.phone,
                    a.is_superadmin, a.is_active,
                    (SELECT COUNT(*) FROM fd_tickets t
                      WHERE t.agent_user_id = u.user_id
                        AND t.is_trash = 0 AND t.is_spam = 0 AND t.merged_into IS NULL
                        AND t.status NOT IN ('Resolved','Closed'))   AS open_count,
                    (SELECT COUNT(*) FROM fd_tickets t
                      WHERE t.agent_user_id = u.user_id
                        AND t.is_trash = 0 AND t.is_spam = 0 AND t.merged_into IS NULL
                        AND t.status IN ('Resolved','Closed'))       AS resolved_count,
                    (SELECT MAX(t.updated_at) FROM fd_tickets t
                      WHERE t.agent_user_id = u.user_id)             AS last_touch
             FROM admin_users a
             INNER JOIN users u ON u.user_id = a.user_id
             ORDER BY a.is_active DESC, a.is_superadmin DESC, u.name ASC
             LIMIT 500");
    } catch (Throwable $e) {
        $error = $e->getMessage();
        fd_log('error', 'Team query failed: ' . $error);
    }

    $team = array();
    foreach ($rows as $r) {
        $team[] = array(
            'id'        => (int)$r['user_id'],
            'name'      => $r['name'],
            'email'     => $r['email'],
            'phone'     => isset($r['phone']) ? $r['phone'] : null,
            'role'      => (int)$r['is_superadmin'] === 1 ? 'Super Admin' : 'Support Agent',
            'active'    => (int)$r['is_active'] === 1,
            'open'      => (int)$r['open_count'],
            'resolved'  => (int)$r['resolved_count'],
            // "Last active" from their own last ticket touch. There is no login
            // timestamp on admin_users, and inventing one is how the screen
            // ended up claiming people had signed in this morning.
            'lastTouch' => $r['last_touch'] ? fd_relative_time($r['last_touch']) : '',
        );
    }

    $active = 0;
    foreach ($team as $t) if ($t['active']) $active++;
    $resolvedAll = 0; $openAll = 0;
    foreach ($team as $t) { $resolvedAll += $t['resolved']; $openAll += $t['open']; }

    api_success(array(
        'team'  => $team,
        'error' => $error,
        'stats' => array(
            'total'    => count($team),
            'active'   => $active,
            'inactive' => count($team) - $active,
            'open'     => $openAll,
            'resolved' => $resolvedAll,
        ),
    ), 'OK');
}

if ($action === 'agents') {
    /*
     * Everyone who can be assigned a ticket: the active rows of admin_users,
     * joined to users for the name and address.
     *
     * The failure is REPORTED now. It used to be swallowed into a warning, so a
     * broken join looked exactly like "this desk has no agents" -- the picker
     * showed only "Unassigned" and nothing said why.
     */
    $rows = array();
    $error = null;
    try {
        $rows = fd_query("SELECT u.user_id, u.name, u.email, u.phone, a.is_superadmin
                          FROM admin_users a
                          INNER JOIN users u ON u.user_id = a.user_id
                          WHERE a.is_active = 1
                          ORDER BY a.is_superadmin DESC, u.name ASC
                          LIMIT 500");
    } catch (Throwable $e) {
        $error = $e->getMessage();
        fd_log('error', 'Agent list query failed: ' . $error);
    }

    $agents = array(array('id' => null, 'name' => 'Unassigned', 'email' => null, 'role' => null));
    foreach ($rows as $r) {
        $agents[] = array(
            'id'    => (int)$r['user_id'],
            'name'  => $r['name'] !== null && $r['name'] !== '' ? $r['name'] : fd_display_name('', $r['email']),
            'email' => $r['email'],
            'phone' => isset($r['phone']) && $r['phone'] !== '' ? (string)$r['phone'] : null,
            'role'  => ((int)$r['is_superadmin'] === 1) ? 'Super Admin' : 'Admin',
        );
    }

    api_success(array('agents' => $agents, 'count' => count($rows), 'error' => $error),
                $error ? ('Could not read the agent list: ' . $error) : 'OK');
}

/* ------------------------------------------------------------------ meta -- */
if ($action === 'meta') {
    $cats = fd_query("SELECT DISTINCT category AS v FROM fd_tickets WHERE category IS NOT NULL AND category <> '' ORDER BY v");
    $deps = fd_query("SELECT DISTINCT department AS v FROM fd_tickets WHERE department IS NOT NULL AND department <> '' ORDER BY v");
    $tagRows = fd_query("SELECT tags FROM fd_tickets WHERE tags IS NOT NULL AND tags <> '[]' LIMIT 2000");
    $tags = array();
    foreach ($tagRows as $r) {
        $arr = json_decode((string)$r['tags'], true);
        if (is_array($arr)) foreach ($arr as $tg) $tags[$tg] = true;
    }
    api_success(array(
        'categories'  => array_map(function ($r) { return $r['v']; }, $cats),
        'departments' => array_map(function ($r) { return $r['v']; }, $deps),
        'tags'        => array_keys($tags),
        'statuses'    => array('New','Open','Pending','In Progress','Escalated','Resolved','Closed'),
        'priorities'  => array('Low','Medium','High','Urgent','Critical'),
        'sources'     => array('Email','Chat','WhatsApp','Phone','Portal'),
    ), 'OK');
}

api_error('Unknown action: ' . $action, 400);

<?php
/*
 * /api/campaigns/unsubscribe.php — the page the unsubscribe link in every email opens.
 *
 * GET  with a signed token  →  asks why, with the address shown so they know what they are leaving
 * POST with a reason        →  records it, blocklists the address, confirms
 *
 * NO AUTH, deliberately, and no way around that: this is opened from an email by someone who is
 * not signed in and never will be. The signed token is the whole credential — see lib/Unsubscribe.php
 * for why it is signed rather than a bare address.
 *
 * WHY IT ASKS FOR A REASON AT ALL, rather than one-click
 * A one-click unsubscribe is faster for the person and tells us nothing. The reason is the only
 * information an opt-out carries, and it is the difference between "sending too often" and "these
 * look like spam" — two problems with opposite fixes. It stays honest by never being a blocker:
 * every option submits immediately, "Something else" is offered without forcing an explanation, and
 * nothing on the page can leave somebody subscribed against their wishes.
 */
ini_set('display_errors', 0);
error_reporting(E_ALL & ~E_WARNING & ~E_NOTICE & ~E_DEPRECATED);

/* Two levels up, not one: config/ sits beside api/, not inside it. */
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/lib/config.php';
require_once __DIR__ . '/lib/Unsubscribe.php';
require_once __DIR__ . '/../lists/lib/schema.php';
require_once __DIR__ . '/../lists/lib/ContactImportWorker.php';

unsub_ensure_schema();

header('Content-Type: text/html; charset=utf-8');
// Never cached: the page's content depends on whether this person has already opted out, and a
// cached "you are unsubscribed" served to the next visitor would be both wrong and alarming.
header('Cache-Control: no-store, no-cache, must-revalidate');
// A link inside an email is followed from anywhere; nothing here should ever be framed.
header('X-Frame-Options: DENY');
header('Referrer-Policy: no-referrer');

$token = (string)($_REQUEST['u'] ?? '');
$email = unsub_email_from_token($token);
$campaignId = isset($_REQUEST['c']) ? (int)$_REQUEST['c'] : null;
$journeyId  = isset($_REQUEST['j']) ? (int)$_REQUEST['j'] : null;

/* ── the page chrome, so every state below looks like the same page ──────── */
function unsub_page(string $title, string $body, string $tone = 'plain'): void {
    $accent = $tone === 'done' ? '#15803d' : ($tone === 'bad' ? '#b42318' : '#1e3a8a');
    echo '<!doctype html><html lang="en"><head><meta charset="utf-8">'
       . '<meta name="viewport" content="width=device-width,initial-scale=1">'
       . '<meta name="robots" content="noindex,nofollow">'
       . '<title>' . htmlspecialchars($title) . ' · Internship Studio</title>'
       . '<style>'
       . '*{box-sizing:border-box}'
       . 'body{margin:0;min-height:100vh;display:flex;align-items:center;justify-content:center;'
       . 'background:#f6f7fb;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Arial,sans-serif;'
       . 'color:#0f172a;padding:24px;line-height:1.55}'
       . '.card{background:#fff;border:1px solid #e2e8f0;border-radius:14px;max-width:520px;width:100%;'
       . 'padding:30px 28px;box-shadow:0 10px 30px rgba(15,23,42,.06)}'
       . '.brand{font-size:12px;font-weight:800;letter-spacing:.5px;text-transform:uppercase;'
       . 'color:' . $accent . ';margin-bottom:14px}'
       . 'h1{font-size:20px;margin:0 0 8px;font-weight:700}'
       . 'p{font-size:14px;color:#475569;margin:0 0 14px}'
       . '.addr{font-weight:700;color:#0f172a;word-break:break-all}'
       . 'fieldset{border:0;margin:0;padding:0}'
       . 'label.opt{display:flex;gap:11px;align-items:flex-start;padding:11px 13px;border:1.5px solid #e2e8f0;'
       . 'border-radius:10px;margin-bottom:8px;cursor:pointer;font-size:14px;transition:border-color .15s,background .15s}'
       . 'label.opt:hover{background:#f8fafc}'
       . 'label.opt input{margin:2px 0 0}'
       . 'label.opt:has(input:checked){border-color:#4f46e5;background:#eef2ff}'
       . 'textarea{width:100%;min-height:74px;padding:10px 12px;border:1.5px solid #e2e8f0;border-radius:9px;'
       . 'font:inherit;font-size:14px;resize:vertical;margin-bottom:6px}'
       . 'button{width:100%;padding:13px;border:0;border-radius:10px;background:#1e3a8a;color:#fff;'
       . 'font:inherit;font-size:15px;font-weight:700;cursor:pointer;margin-top:6px}'
       . 'button:hover{background:#1b326f}'
       . '.note{font-size:12px;color:#94a3b8;margin-top:16px}'
       . '</style></head><body><div class="card">'
       . '<div class="brand">Internship Studio</div>' . $body
       . '</div></body></html>';
    exit;
}

/* ════════════════════════════════════════════════════════════════════════════
   A LINK THAT CANNOT BE READ IS NOT A DEAD END.

   The token can be missing for reasons that are entirely our fault. The one that actually happened:
   templates carry the placeholder in the database, which both sending machines read, while the code
   that fills it in had only been deployed to one of them — so a whole send went out with the raw
   placeholder in the href and the recipients got a browser error instead of this page.

   Telling somebody in that position "this link is not valid" leaves them one way to stop the mail,
   and it is the spam button. A complaint costs the sending domain far more than an opt-out does. So
   the page asks for the address instead, and takes them off the list.

   IT WILL ONLY REMOVE AN ADDRESS WE HAVE ACTUALLY WRITTEN TO. Without a token there is nothing
   proving the person typing owns what they typed, and an endpoint that blocklists anything at all
   is a way to silence somebody else's mail. Requiring a send we have a record of keeps it open for
   the person this is for — they are holding one of our emails — while leaving a stranger nothing to
   aim at but addresses they would already have to know we mail.
   ═══════════════════════════════════════════════════════════════════════════ */
if ($email === null) {
    $typed = strtolower(trim((string)($_REQUEST['email'] ?? '')));
    $problem = '';

    if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST' && $typed !== '') {
        if (!filter_var($typed, FILTER_VALIDATE_EMAIL)) {
            $problem = 'That does not look like an email address. Please check it and try again.';
        } else {
            $tE = $conn->real_escape_string($typed);
            $known = false;
            foreach ([
                "SELECT 1 FROM email_campaign_recipients WHERE email = '$tE' LIMIT 1",
                "SELECT 1 FROM journey_messages WHERE to_addr = '$tE' LIMIT 1",
            ] as $sql) {
                $rq = @$conn->query($sql);
                if ($rq && $rq->num_rows > 0) { $known = true; break; }
            }
            if (!$known) {
                $problem = 'We have no record of sending anything to that address. Check the spelling, '
                         . 'or reply to one of our emails and we will remove you by hand.';
            } elseif (unsub_already($typed)) {
                unsub_page('Already unsubscribed',
                    '<h1>You are already unsubscribed</h1>'
                    . '<p><span class="addr">' . htmlspecialchars($typed) . '</span> is already off our '
                    . 'mailing list, so there is nothing more to do.</p>',
                    'done');
            } else {
                unsub_record($typed, (string)($_POST['reason'] ?? 'unspecified'),
                    (string)($_POST['reason_text'] ?? ''), $campaignId ?: null, $journeyId ?: null);
                unsub_page('Unsubscribed',
                    '<h1>You have been unsubscribed</h1>'
                    . '<p><span class="addr">' . htmlspecialchars($typed) . '</span> has been removed from '
                    . 'our mailing list. You will not receive marketing emails from us again.</p>'
                    . '<div class="note">Emails you ask for directly, such as a password reset or an exam '
                    . 'result you have requested, are not affected by this.</div>',
                    'done');
            }
        }
    }

    $opts = '';
    foreach (unsub_reasons() as $key => $label) {
        $opts .= '<label class="opt"><input type="radio" name="reason" value="' . htmlspecialchars($key) . '"'
              . ($key === 'too_frequent' ? ' checked' : '') . '><span>' . htmlspecialchars($label) . '</span></label>';
    }
    $warn = $problem === '' ? ''
        : '<p style="color:#b42318;font-weight:600">' . htmlspecialchars($problem) . '</p>';

    unsub_page('Unsubscribe',
        '<h1>Unsubscribe</h1>'
        . '<p>We could not read the link you followed, so we do not know which address to remove. '
        . 'Type it below and we will take it off the list.</p>'
        . $warn
        . '<form method="post">'
        . '<input type="email" name="email" required placeholder="you@example.com" '
        . 'value="' . htmlspecialchars($typed, ENT_QUOTES) . '" '
        . 'style="width:100%;padding:11px 12px;border:1.5px solid #e2e8f0;border-radius:9px;'
        . 'font:inherit;font-size:14px;margin-bottom:16px">'
        . '<fieldset>' . $opts . '</fieldset>'
        . '<textarea name="reason_text" placeholder="Anything else you want to tell us (optional)" '
        . 'maxlength="500"></textarea>'
        . '<button type="submit">Unsubscribe me</button>'
        . '</form>'
        . '<div class="note">Emails you ask for directly, such as a password reset, are not affected.</div>',
        'bad');
}

/* ── they submitted the form ─────────────────────────────────────────────── */
if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
    $reasonKey  = (string)($_POST['reason'] ?? 'unspecified');
    $reasonText = (string)($_POST['reason_text'] ?? '');
    unsub_record($email, $reasonKey, $reasonText, $campaignId ?: null, $journeyId ?: null);

    unsub_page('Unsubscribed',
        '<h1>You have been unsubscribed</h1>'
        . '<p><span class="addr">' . htmlspecialchars($email) . '</span> has been removed from our '
        . 'mailing list. You will not receive marketing emails from us again.</p>'
        . '<p>Thank you for telling us why — it is read, and it is the only way we find out what we '
        . 'are getting wrong.</p>'
        . '<div class="note">Emails you ask for directly, such as a password reset or an exam result '
        . 'you have requested, are not affected by this.</div>',
        'done');
}

/* ── already gone ────────────────────────────────────────────────────────── */
if (unsub_already($email)) {
    unsub_page('Already unsubscribed',
        '<h1>You are already unsubscribed</h1>'
        . '<p><span class="addr">' . htmlspecialchars($email) . '</span> is already off our mailing '
        . 'list, so there is nothing more to do.</p>'
        . '<p>If you are still receiving marketing emails from us, something is wrong at our end — '
        . 'please reply to one of them and tell us.</p>',
        'done');
}

/* ── the form ────────────────────────────────────────────────────────────── */
$opts = '';
foreach (unsub_reasons() as $key => $label) {
    $opts .= '<label class="opt"><input type="radio" name="reason" value="' . htmlspecialchars($key) . '"'
          . ($key === 'too_frequent' ? ' checked' : '') . '><span>' . htmlspecialchars($label) . '</span></label>';
}

$hidden = '<input type="hidden" name="u" value="' . htmlspecialchars($token, ENT_QUOTES) . '">';
if ($campaignId) $hidden .= '<input type="hidden" name="c" value="' . (int)$campaignId . '">';
if ($journeyId)  $hidden .= '<input type="hidden" name="j" value="' . (int)$journeyId . '">';

unsub_page('Unsubscribe',
    '<h1>Unsubscribe</h1>'
    . '<p>We will stop emailing <span class="addr">' . htmlspecialchars($email) . '</span>.</p>'
    . '<p>Before you go, would you tell us why? It takes one tap and it is the only way we learn.</p>'
    . '<form method="post">' . $hidden
    . '<fieldset>' . $opts . '</fieldset>'
    . '<textarea name="reason_text" placeholder="Anything else you want to tell us (optional)" '
    . 'maxlength="500"></textarea>'
    . '<button type="submit">Unsubscribe me</button>'
    . '</form>'
    . '<div class="note">One tap and you are off the list. Emails you ask for directly, such as a '
    . 'password reset, are not affected.</div>');

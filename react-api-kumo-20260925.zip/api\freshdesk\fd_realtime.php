<?php
/*
 * /api/freshdesk/fd_realtime.php
 *
 *   action=config          -> what the browser needs to connect (never the secret)
 *   action=auth            -> sign a private-channel subscription  [POST]
 *   action=poll   &since   -> events after a cursor  (the no-Pusher fallback)
 *   action=test            -> publish a test event to prove the pipe works
 *   action=status          -> mailbox health for the connection banner
 *
 * TWO TRANSPORTS, ONE EVENT LOG.
 *
 * Every event is written to fd_activity before any attempt to publish it (see
 * fd_emit). Pusher is the low-latency path; `poll` replays the SAME rows from
 * the same table by id. So the desk behaves identically either way -- it is
 * just faster with Pusher -- and a client whose websocket drops for 40 seconds
 * catches up exactly, in order, with nothing missed and nothing duplicated.
 *
 * COST: an idle panel issues NO repeating requests to this server.
 *
 * With Pusher configured, the server publishes and the browser listens -- no
 * polling at all. Without it the desk is manual-refresh by default, and an
 * agent can switch "Live" on in the rail to run the poller for their session
 * only. The mailbox itself is synced by CRON only; see the note on
 * sync_interval_ms below for why the panel no longer does it on a timer.
 */

require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../middleware/auth.php';
require_once __DIR__ . '/lib/config.php';
require_once __DIR__ . '/lib/Helpers.php';
require_once __DIR__ . '/lib/schema.php';
require_once __DIR__ . '/lib/Pusher.php';

$jwt = require_jwt();
require_permission('freshdesk', $jwt);
fd_install_error_handlers();
fd_ensure_schema();

$ME = array(
    'id'   => isset($jwt['user_id']) ? (int)$jwt['user_id'] : null,
    'name' => isset($jwt['name']) ? $jwt['name'] : 'Agent',
);

$action = fd_str('action', 'config');
$GLOBALS['FD_ACTION'] = $action;

/* ---------------------------------------------------------------- config -- */
if ($action === 'config') {
    $pusher = new FdPusher();
    $cfg = $pusher->clientConfig();

    $mailbox = fd_query_one("SELECT mailbox, last_status, last_error, last_success_at, consecutive_fails, last_sync_at
                             FROM fd_mailbox_state WHERE mailbox = ?", 's', array((string)fd_cfg('IMAP_FOLDER', 'INBOX')));
    $cur = fd_query_one("SELECT MAX(id) AS c FROM fd_activity");

    api_success(array(
        'pusher' => $cfg,
        /*
         * Interval used ONLY while an agent has switched "Live" on and Pusher
         * is not configured. The panel does not poll by default -- an idle tab
         * makes no repeating requests at all.
         */
        'poll_interval_ms' => 8000,
        /*
         * Deliberately null. The panel used to call fd_sync.php on a 60s timer,
         * which opens an IMAP connection and can run for ten seconds or more --
         * so every open tab was a recurring IMAP session against a shared
         * cPanel mailbox. Syncing is CRON's job:
         *
         *   * * * * * php <this dir>/fd_sync.php
         *
         * The panel only calls fd_sync.php when an agent presses Refresh.
         */
        'sync_interval_ms' => null,
        'cursor'  => $cur ? (int)$cur['c'] : 0,
        'sound'   => array(
            'enabled' => (bool)fd_cfg_int('SOUND_ENABLED', 1),
            'volume'  => (float)fd_cfg('SOUND_VOLUME', 0.5),
        ),
        'mailbox' => $mailbox ? array(
            'name'      => $mailbox['mailbox'],
            'status'    => $mailbox['last_status'],
            'error'     => $mailbox['last_error'],
            'lastSync'  => $mailbox['last_sync_at'],
            'lastSyncAgo' => fd_relative_time($mailbox['last_sync_at']),
            'lastOk'    => $mailbox['last_success_at'],
            'fails'     => (int)$mailbox['consecutive_fails'],
            'healthy'   => (int)$mailbox['consecutive_fails'] < 3,
        ) : array('name' => (string)fd_cfg('IMAP_FOLDER', 'INBOX'), 'status' => 'never',
                  'healthy' => false,
                  'error' => 'The mailbox has never been synced. Add the cron job (* * * * * php '
                             . realpath(__DIR__) . '/fd_sync.php), or press Refresh to sync once now.'),
        'me' => $ME,
    ), 'OK');
}

/* ------------------------------------------------------------------ auth -- */
if ($action === 'auth') {
    /*
     * pusher-js POSTs socket_id + channel_name here. Reaching this line already
     * means the caller passed require_jwt() and holds the 'freshdesk'
     * permission, which IS the authorisation decision -- the signature below
     * merely encodes it for Pusher.
     */
    $socketId = fd_str('socket_id', '');
    $channel  = fd_str('channel_name', '');
    if ($socketId === '' || $channel === '') api_error('socket_id and channel_name are required', 400);

    $allowed = (string)fd_cfg('PUSHER_CHANNEL', 'private-freshdesk');
    // Only ever sign OUR channel. Without this an authenticated agent could
    // have us sign a subscription to any private channel in the Pusher app.
    if ($channel !== $allowed && strpos($channel, $allowed . '-') !== 0) {
        api_error('Refusing to authorise channel "' . $channel . '".', 403);
    }

    try {
        $pusher = new FdPusher();
        $auth = $pusher->authorizeChannel($channel, $socketId, array(
            'user_id'   => (string)($ME['id'] ?: 'agent'),
            'user_info' => array('name' => $ME['name']),
        ));
    } catch (Throwable $e) {
        api_error($e->getMessage(), 400);
    }

    // pusher-js expects this object RAW at the top level, not wrapped in the
    // API's usual {success,message,data} envelope -- it reads response.auth.
    while (ob_get_level() > 0) { ob_end_clean(); }
    header('Content-Type: application/json; charset=UTF-8');
    echo json_encode($auth);
    exit;
}

/* ------------------------------------------------------------------ poll -- */
if ($action === 'poll') {
    $since = fd_int('since', 0);
    $limit = max(1, min(200, fd_int('limit', 100)));

    if ($since <= 0) {
        /*
         * A client with no cursor must NOT be handed the whole history -- that
         * would fire a notification (and a chime) for every email ever
         * received the moment someone opens the page. Give it the current
         * high-water mark instead, so it starts listening from "now".
         */
        $cur = fd_query_one("SELECT MAX(id) AS c FROM fd_activity");
        api_success(array('events' => array(), 'cursor' => $cur ? (int)$cur['c'] : 0, 'primed' => true), 'OK');
    }

    $rows = fd_query(
        "SELECT id, ticket_id, message_id, event, actor_type, actor_name, summary, payload, created_at
         FROM fd_activity WHERE id > ? ORDER BY id ASC LIMIT $limit",
        'i', array($since)
    );

    $events = array();
    $maxId = $since;
    foreach ($rows as $r) {
        $payload = json_decode((string)$r['payload'], true);
        if (!is_array($payload)) $payload = array();
        $events[] = array(
            'cursor'    => (int)$r['id'],
            'event'     => $r['event'],
            'ticket_id' => $r['ticket_id'] !== null ? (int)$r['ticket_id'] : null,
            'message_id'=> $r['message_id'] !== null ? (int)$r['message_id'] : null,
            'actor'     => $r['actor_name'],
            'actorType' => $r['actor_type'],
            'summary'   => $r['summary'],
            'at'        => $r['created_at'],
            'ago'       => fd_relative_time($r['created_at']),
            'data'      => $payload,
        );
        $maxId = max($maxId, (int)$r['id']);
    }

    // Counts ride along with every poll so the sidebar badges stay correct
    // without the client needing a second request per tick.
    $counts = array();
    foreach (array('all' => "is_trash=0 AND is_spam=0 AND merged_into IS NULL",
                   'unresolved' => "is_trash=0 AND is_spam=0 AND merged_into IS NULL AND status NOT IN ('Resolved','Closed')",
                   'open' => "is_trash=0 AND is_spam=0 AND merged_into IS NULL AND status IN ('Open','New')",
                   'unread' => "is_trash=0 AND is_spam=0 AND merged_into IS NULL AND unread_count > 0") as $k => $w) {
        $r = fd_query_one("SELECT COUNT(*) AS c FROM fd_tickets WHERE $w");
        $counts[$k] = $r ? (int)$r['c'] : 0;
    }

    api_success(array(
        'events'  => $events,
        'cursor'  => $maxId,
        'counts'  => $counts,
        'hasMore' => count($rows) >= $limit,
    ), 'OK');
}

/* ------------------------------------------------------------------ test -- */
if ($action === 'test') {
    $pusher = new FdPusher();
    $cursor = fd_emit('test-event', array(
        'ticket_id' => null,
        'subject'   => 'Realtime test',
        'from_name' => $ME['name'],
        'preview'   => 'If you can hear the chime and see this toast, realtime is working.',
        'notify'    => 1,
        'sound'     => 'new-reply',
    ), array(
        'actor_type' => 'agent', 'actor_id' => $ME['id'], 'actor_name' => $ME['name'],
        'summary'    => 'Realtime test fired by ' . $ME['name'],
    ));

    api_success(array(
        'cursor'         => $cursor,
        'pusherEnabled'  => $pusher->isConfigured(),
        'transport'      => $pusher->isConfigured() ? 'pusher' : 'polling',
    ), $pusher->isConfigured()
        ? 'Test event published to Pusher. It should appear within a second.'
        : 'Test event recorded. Pusher is not configured yet, so it will arrive on the next poll (a few seconds).');
}

/* ---------------------------------------------------------------- status -- */
if ($action === 'status') {
    $mailbox = (string)fd_cfg('IMAP_FOLDER', 'INBOX');
    $st = fd_query_one("SELECT * FROM fd_mailbox_state WHERE mailbox = ?", 's', array($mailbox));
    $pusher = new FdPusher();

    $lastSync = $st ? $st['last_sync_at'] : null;
    // "Stale" means the cron is not running, which is the failure that looks
    // exactly like a quiet inbox. Surfacing it is the whole point of this call.
    $stale = !$lastSync || (strtotime($lastSync) < time() - 600);

    api_success(array(
        'mailbox'   => $mailbox,
        'status'    => $st ? $st['last_status'] : 'never',
        'lastSync'  => $lastSync,
        'lastSyncAgo' => $lastSync ? fd_relative_time($lastSync) : 'never',
        'lastOk'    => $st ? $st['last_success_at'] : null,
        'error'     => $st ? $st['last_error'] : null,
        'fails'     => $st ? (int)$st['consecutive_fails'] : 0,
        'imported'  => $st ? (int)$st['imported_total'] : 0,
        'lastUid'   => $st ? (int)$st['last_uid'] : 0,
        'stale'     => $stale,
        'staleHint' => $stale
            ? 'No sync in the last 10 minutes. Add the cron job: * * * * * php ' . realpath(__DIR__) . '/fd_sync.php'
            : null,
        'realtime'  => array(
            'transport' => $pusher->isConfigured() ? 'pusher' : 'polling',
            'enabled'   => $pusher->isConfigured(),
        ),
    ), 'OK');
}

api_error('Unknown action: ' . $action, 400);

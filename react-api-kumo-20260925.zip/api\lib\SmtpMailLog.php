<?php
/*
 * SmtpMailLog — a record of every email the panel sends itself over SMTP as
 * contact@internshipstudio.com, outside Freshdesk and outside the campaign ESPs.
 *
 * WHY IT EXISTS
 * refunds/list.php (refund processed / rejected, project approved / declined) sends through
 * PHPMailer and kept no trace: no row, no Sent-folder copy. So nobody could say how many of
 * those emails went out on a day, or whether one failed. Messaging analytics reads this table
 * as its "Refund & project emails" source. History starts from the day this was deployed.
 *
 * Logging is strictly best-effort: every path is wrapped so a logging problem can never turn
 * a successful send into an error for the admin.
 */

function smtp_mail_log_ensure(mysqli $conn): bool {
    static $done = null;
    if ($done !== null) return $done;
    try {
        $done = (bool)@$conn->query("CREATE TABLE IF NOT EXISTS smtp_mail_log (
            id           BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
            module       VARCHAR(32)  NOT NULL,              -- which part of the panel sent it (refunds, ...)
            purpose      VARCHAR(40)  NOT NULL,              -- refund_processed | refund_rejected | project_approved | project_declined | other
            to_email     VARCHAR(255) NOT NULL,
            user_id      BIGINT UNSIGNED DEFAULT NULL,
            subject      VARCHAR(998) DEFAULT NULL,
            status       ENUM('sent','failed') NOT NULL,
            transport    VARCHAR(16)  NOT NULL DEFAULT 'smtp', -- smtp | mail (the mail() fallback)
            error        VARCHAR(1000) DEFAULT NULL,
            message_id   VARCHAR(255) DEFAULT NULL,
            from_email   VARCHAR(255) NOT NULL DEFAULT 'contact@internshipstudio.com',
            admin_id     BIGINT UNSIGNED DEFAULT NULL,
            created_at   DATETIME NOT NULL,
            KEY idx_created (created_at),
            KEY idx_purpose (purpose, created_at),
            KEY idx_to (to_email)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    } catch (\Throwable $e) {
        $done = false;
    }
    return $done;
}

/** What an email is, from its subject — the refund templates carry no other marker. */
function smtp_mail_log_purpose(string $subject): string {
    $s = strtolower($subject);
    if (strpos($s, 'refund') !== false) {
        if (preg_match('/process|approv|initiat|complet|success/', $s)) return 'refund_processed';
        return 'refund_rejected';
    }
    if (strpos($s, 'project') !== false) {
        if (strpos($s, 'approv') !== false) return 'project_approved';
        return 'project_declined';
    }
    return 'other';
}

/**
 * @param array $row module, to_email, subject, status ('sent'|'failed'), transport, error, message_id,
 *                   admin_id, purpose (optional — derived from subject when absent), user_id (optional)
 */
function smtp_mail_log_record(mysqli $conn, array $row): void {
    try {
        if (!smtp_mail_log_ensure($conn)) return;
        $to = trim((string)($row['to_email'] ?? ''));
        if ($to === '') return;
        $subject = (string)($row['subject'] ?? '');
        $purpose = (string)($row['purpose'] ?? '') ?: smtp_mail_log_purpose($subject);

        $userId = isset($row['user_id']) ? (int)$row['user_id'] : 0;
        if ($userId <= 0) {
            $q = @$conn->prepare("SELECT user_id FROM users WHERE email = ? LIMIT 1");
            if ($q) {
                $q->bind_param('s', $to);
                if (@$q->execute()) { $r = $q->get_result(); $u = $r ? $r->fetch_row() : null; $userId = (int)($u[0] ?? 0); }
                $q->close();
            }
        }

        $st = @$conn->prepare("INSERT INTO smtp_mail_log
            (module, purpose, to_email, user_id, subject, status, transport, error, message_id, admin_id, created_at)
            VALUES (?, ?, ?, NULLIF(?, 0), ?, ?, ?, ?, ?, NULLIF(?, 0), ?)");
        if (!$st) return;
        $module    = substr((string)($row['module'] ?? 'panel'), 0, 32);
        $status    = ($row['status'] ?? '') === 'sent' ? 'sent' : 'failed';
        $transport = substr((string)($row['transport'] ?? 'smtp'), 0, 16);
        $error     = isset($row['error']) && $row['error'] !== '' ? substr((string)$row['error'], 0, 1000) : null;
        $messageId = isset($row['message_id']) && $row['message_id'] !== '' ? substr((string)$row['message_id'], 0, 255) : null;
        $adminId   = (int)($row['admin_id'] ?? 0);
        $now       = date('Y-m-d H:i:s');   // PHP's clock (IST), not MySQL's — see campaign timestamps note
        $subject   = substr($subject, 0, 998);
        $st->bind_param('sssisssssis', $module, $purpose, $to, $userId, $subject, $status, $transport, $error, $messageId, $adminId, $now);
        @$st->execute();
        $st->close();
    } catch (\Throwable $e) {
        // Never let bookkeeping break a send.
    }
}

<?php
/*
 * lib/ProviderFailover.php — when a provider stops accepting mail, move to the other one.
 *
 * THE PROBLEM
 * At fifty people a provider limit is an inconvenience. At five hundred thousand it is the whole
 * send: Elastic Email hits its daily quota a third of the way in, every remaining request comes
 * back refused, and the campaign sits there failing recipient after recipient until somebody
 * notices. The audience is spent, the send window has passed, and the only thing anyone can do is
 * start again tomorrow.
 *
 * The account has a second provider standing idle. So the campaign moves to it, mid-flight, and
 * keeps going.
 *
 * ── NEVER SENDGRID ───────────────────────────────────────────────────────────
 * Only Elastic Email and Amazon SES take part, in either direction. SendGrid is deliberately
 * excluded as a destination: it stays configured and can be chosen by hand, but nothing may move a
 * live campaign onto it automatically. That is a business decision, not a technical one, and the
 * code enforces it in one place (failover_partner) so it cannot be half-forgotten somewhere else.
 *
 * ── ONLY FOR FAILURES THE WHOLE AUDIENCE SHARES ──────────────────────────────
 * A single recipient failing is not a reason to move anything, and switching on one bad address
 * would be worse than the problem — it would thrash between providers all day. Two conditions have
 * to hold together:
 *
 *   1. the error is about the ACCOUNT, not the person (a quota, a rate limit, a suspension), and
 *   2. it has happened to enough recipients that it plainly is not about them.
 *
 * "Not a WhatsApp user", "mailbox full", "user unknown" are per-person and never trigger this
 * however many of them arrive.
 */

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/Alerts.php';

/** Providers that may be switched TO. SendGrid is absent on purpose — see the header. */
if (!defined('FAILOVER_PARTNERS')) {
    define('FAILOVER_PARTNERS', json_encode(['elasticemail' => 'ses', 'ses' => 'elasticemail']));
}

/**
 * How many recipients must hit the same account-level error before a campaign moves.
 *
 * Low enough that the damage is a fraction of one batch rather than an entire audience. High
 * enough that a handful of unlucky rows cannot move a healthy campaign onto its backup, because a
 * spurious switch costs the reputation of a sending domain that was fine.
 */
/* How long a provider stays "somewhere we just left", so a failing pair cannot flap between them. */
if (!defined('FAILOVER_PINGPONG_HOURS')) define('FAILOVER_PINGPONG_HOURS', 6);

if (!defined('FAILOVER_THRESHOLD')) define('FAILOVER_THRESHOLD', 25);

/** A journey sends one message at a time, so its evidence accumulates over minutes rather than
 *  inside one batch. Counted over this window. */
if (!defined('FAILOVER_JOURNEY_WINDOW_MINUTES')) define('FAILOVER_JOURNEY_WINDOW_MINUTES', 30);

/* ════════════════════════════════════════════════════════════════════════════
   Schema
   ═══════════════════════════════════════════════════════════════════════════ */

function failover_ensure_schema(): void {
    global $conn;
    static $done = false;
    if ($done) return;
    $done = true;

    /*
     * Every switch, kept for the report.
     *
     * Without this a campaign simply reports a different provider than the one it started on and
     * nothing explains when or why — which reads as somebody having edited it. The row carries the
     * error verbatim, because "quota exceeded" and "account suspended" need completely different
     * responses and a summarised version of either is useless a week later.
     */
    @$conn->query("CREATE TABLE IF NOT EXISTS email_provider_switches (
        id           BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        scope        ENUM('campaign','journey') NOT NULL,
        campaign_id  BIGINT UNSIGNED DEFAULT NULL,
        journey_id   BIGINT UNSIGNED DEFAULT NULL,
        node_id      VARCHAR(64)  DEFAULT NULL,   -- which email step, since a journey has several
        step_label   VARCHAR(190) DEFAULT NULL,
        from_provider VARCHAR(32) NOT NULL,
        to_provider   VARCHAR(32) NOT NULL,
        reason_code   VARCHAR(64) NOT NULL,
        reason        VARCHAR(500) NOT NULL,
        sample_error  VARCHAR(500) DEFAULT NULL,
        failure_count INT UNSIGNED NOT NULL DEFAULT 0,
        alerted       TINYINT(1)   NOT NULL DEFAULT 0,
        switched_at   DATETIME NOT NULL,
        INDEX idx_campaign (campaign_id),
        INDEX idx_journey (journey_id, node_id),
        INDEX idx_when (switched_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
}

/* ════════════════════════════════════════════════════════════════════════════
   Classification
   ═══════════════════════════════════════════════════════════════════════════ */

/** Where a provider fails over to, or null when it has nowhere to go. */
/**
 * May this condition move a send to the other provider?
 *
 * Not a throttle — slowing down fixes that. Not a refused sender address — that is the campaign's
 * own setting, and the other provider would refuse it too, or send it from a domain nobody chose.
 */
function failover_code_switches(string $code): bool {
    return !in_array($code, ['rate_limited', 'sender_rejected'], true);
}

function failover_partner(string $provider): ?string {
    $map = json_decode(FAILOVER_PARTNERS, true) ?: [];
    return $map[strtolower(trim($provider))] ?? null;
}

/**
 * Is this error about the ACCOUNT rather than the recipient?
 *
 * Matched on the error text because the three providers report the same condition in three
 * different shapes and none of them uses a code we could switch on: SES says "Daily message quota
 * exceeded" over its API, Elastic Email answers 429, and an SMTP path returns "550 5.4.5 Daily
 * sending limit exceeded". The one thing they share is the words.
 *
 * Deliberately conservative. Every pattern here is a condition that cannot possibly depend on who
 * is being mailed, because a false positive moves a healthy campaign to a provider it was not
 * warmed up on — which is its own deliverability problem. Anything ambiguous is left out.
 *
 * @return string|null a short code naming the condition, or null when it is not one of these
 */
function failover_classify(string $error, ?string $code = null): ?string {
    $e = strtolower(trim($error . ' ' . (string)$code));
    if ($e === '') return null;

    $rules = [
        /*
         * The provider will not send FROM this address — the sender or its domain is not verified
         * with it. Same refusal for every recipient, and no other provider fixes it either: the
         * address is the campaign's. Checked first so nothing below claims it.
         */
        'sender_rejected' => ['from email address', 'email address is not verified',
                              'identities failed the check', 'sender address rejected'],
        // Sending caps — the commonest reason a large campaign stops half way.
        'daily_quota'    => ['daily sending quota', 'daily message quota', 'daily sending limit',
                             '5.4.5', 'daily quota exceeded'],
        'monthly_quota'  => ['monthly sending quota', 'monthly quota', 'monthly limit'],
        /*
         * THE PLAN ALLOWANCE IS SPENT — and this is the one that got away.
         *
         * Elastic Email says "You can not send above your plan limit. Upgrade your account to a
         * higher tier to continue sending emails." None of the phrasings above contain any part of
         * that, so the classifier returned null, the failover treated every one of them as an
         * ordinary per-recipient bounce, and nothing switched and nothing alerted. A registration
         * journey went 611 messages and four and a half hours without delivering anything, while
         * the panel showed it running normally.
         *
         * It is its own code rather than folded into monthly_quota because the fix a person has to
         * make differs: a monthly quota refills on its own, a plan limit needs somebody to buy more.
         */
        'plan_limit'     => ['plan limit', 'above your plan', 'exceeded your plan',
                             'upgrade your account', 'upgrade your plan', 'plan allowance'],
        /*
         * NOT "maximum sending rate exceeded". That is Amazon SES saying "too many this second",
         * which slowing down fixes and switching provider does not. It used to be listed here and
         * moved campaigns #100 and #101 off SES onto Elastic Email mid-send. It falls through to
         * rate_limited below, which never switches.
         */
        'account_quota'  => ['quota exceeded for this account', 'sending quota exceeded', 'account quota'],
        // Rate limiting. Retried first by the caller; only a sustained one reaches here.
        'rate_limited'   => ['429', 'too many requests', 'rate limit', 'throttl'],
        // The account itself is in trouble.
        'suspended'      => ['account temporarily restricted', 'account suspended', 'account disabled',
                            'sending paused', 'account is paused', 'temporarily restricted from sending'],
        'domain_blocked' => ['sending domain temporarily blocked', 'domain is blocked',
                             'domain not allowed', 'domain suspended'],
        // Credentials. A campaign cannot send another byte through this provider.
        'auth_failed'    => ['401', '403', 'unauthorized', 'unauthorised', 'invalid api key',
                             'signature', 'access denied', 'authentication failed'],
        // Nothing left to spend.
        'no_credit'      => ['insufficient credit', 'out of credit', 'balance', 'payment required', '402'],
    ];

    foreach ($rules as $codeName => $needles) {
        foreach ($needles as $needle) {
            if (strpos($e, $needle) !== false) return $codeName;
        }
    }
    return null;
}

/** The condition in words, for the alert and the report. */
function failover_reason_text(string $code): string {
    return [
        'sender_rejected' => 'the provider refuses to send from this sender address — it is not verified with that provider',
        'daily_quota'    => 'the daily sending quota was reached',
        'monthly_quota'  => 'the monthly sending quota was reached',
        'plan_limit'     => 'the plan\'s sending allowance is used up and the provider will not send again until it is raised',
        'account_quota'  => 'the account sending quota was exceeded',
        'rate_limited'   => 'the provider kept rate-limiting the send',
        'suspended'      => 'the provider has temporarily restricted this account from sending',
        'domain_blocked' => 'the provider has temporarily blocked this sending domain',
        'auth_failed'    => 'the provider rejected our credentials',
        'no_credit'      => 'the account has no sending credit left',
    ][$code] ?? 'the provider refused the send for an account-level reason';
}

/**
 * The account-level failures in a set of results, and which condition they share.
 *
 * @param array $errors  id => error string
 * @return array{code: ?string, count: int, sample: string}
 */
function failover_scan(array $errors): array {
    $byCode = [];
    $sample = [];
    foreach ($errors as $err) {
        $code = failover_classify((string)$err);
        // A throttle is answered by slowing down (the sender paces and requeues), never by moving.
        if ($code === null || $code === 'rate_limited') continue;
        $byCode[$code] = ($byCode[$code] ?? 0) + 1;
        if (!isset($sample[$code])) $sample[$code] = (string)$err;
    }
    if (!$byCode) return ['code' => null, 'count' => 0, 'sample' => ''];
    arsort($byCode);
    $top = array_key_first($byCode);
    return ['code' => $top, 'count' => $byCode[$top], 'sample' => $sample[$top] ?? ''];
}

/* ════════════════════════════════════════════════════════════════════════════
   Switching
   ═══════════════════════════════════════════════════════════════════════════ */

/**
 * Moves a CAMPAIGN to its partner provider, records it and alerts.
 *
 * @return string|null the provider it moved to, or null when it could not move
 */
function failover_switch_campaign(int $campaignId, string $from, string $code, string $sampleError, int $count): ?string {
    global $conn;
    failover_ensure_schema();

    $to = failover_partner($from);
    if ($to === null) return null;

    /*
     * Never straight back to where this campaign just came from. When BOTH providers are refusing
     * (SES over its daily quota, Elastic Email over its plan) each switch would trigger the next,
     * and the campaign would bounce between them failing every batch. The journey path always had
     * this guard; campaigns did not. Returning null makes the worker suspend the campaign, keeping
     * the rest of the audience pending for Resume, and the dead-end alert tells someone.
     */
    if (failover_just_came_from("scope = 'campaign' AND campaign_id = " . (int)$campaignId, $to, $from)) {
        failover_alert_dead_end('campaign', $campaignId, null, null, $from, $to, $code, $sampleError, $count);
        return null;
    }

    // The destination has to be usable, or this trades a stopped campaign for a broken one.
    if (!failover_provider_ready($to)) {
        failover_alert_dead_end('campaign', $campaignId, null, null, $from, $to, $code, $sampleError, $count);
        return null;
    }

    $r = $conn->query("SELECT name FROM email_campaigns WHERE id = " . (int)$campaignId . " LIMIT 1");
    $name = $r && ($row = $r->fetch_assoc()) ? (string)$row['name'] : ('#' . $campaignId);

    /*
     * The sending domain moves with the provider, for the same reason as a journey step: a domain
     * is verified with one provider, and sending from the old one through the new one is refused
     * outright. The local part is kept.
     */
    $toDomain = failover_provider_domain($to);
    $setDomain = '';
    if ($toDomain !== '') {
        $dE = $conn->real_escape_string($toDomain);
        $setDomain = ", sending_domain = '$dE',
                       sender_email = CONCAT(SUBSTRING_INDEX(COALESCE(NULLIF(sender_email, ''), 'contact@x'), '@', 1), '@', '$dE')";
    }
    $conn->query("UPDATE email_campaigns SET esp_transport = '" . $conn->real_escape_string($to) . "'
                   $setDomain
                   WHERE id = " . (int)$campaignId);

    /*
     * The recipients that failed on the old provider go back in the queue.
     *
     * Without this the switch only helps whoever had not been attempted yet, and everybody caught
     * by the quota stays failed — which is most of the damage the switch exists to undo. Only the
     * rows that failed for THIS reason are requeued; a genuine bad address stays failed.
     */
    $requeued = failover_requeue_campaign_failures($campaignId, $code);

    $reason = failover_reason_text($code);
    $conn->query("INSERT INTO email_provider_switches
        (scope, campaign_id, from_provider, to_provider, reason_code, reason, sample_error, failure_count, switched_at)
        VALUES ('campaign', " . (int)$campaignId . ",
                '" . $conn->real_escape_string($from) . "', '" . $conn->real_escape_string($to) . "',
                '" . $conn->real_escape_string($code) . "',
                '" . $conn->real_escape_string($reason) . "',
                '" . $conn->real_escape_string(mb_substr($sampleError, 0, 490)) . "',
                " . (int)$count . ", NOW())");
    $switchId = (int)$conn->insert_id;

    campaign_log("campaign #$campaignId: PROVIDER SWITCHED $from -> $to because $reason"
        . " ($count recipient(s) affected, $requeued requeued) — " . mb_substr($sampleError, 0, 200));

    $ok = alert_notify(
        "failover:campaign:$campaignId",
        'Email campaign switched provider mid-send',
        "*$name* stopped sending through *" . failover_label($from) . "* because " . $reason
        . ". It has been moved to *" . failover_label($to) . "* and the affected recipients were put back in the queue.",
        [
            'Campaign'        => $name . ' (id ' . $campaignId . ')',
            'Switched'        => failover_label($from) . '  ->  ' . failover_label($to),
            'Reason'          => ucfirst($reason),
            'Recipients hit'  => (string)$count,
            'Requeued'        => (string)$requeued,
            'Provider said'   => mb_substr($sampleError, 0, 400),
            'What to check'   => 'Whether ' . failover_label($from) . ' is back under its limit before the next send.',
        ],
        'critical'
    );
    if ($ok) $conn->query("UPDATE email_provider_switches SET alerted = 1 WHERE id = $switchId");

    return $to;
}

/**
 * Moves ONE EMAIL STEP of a journey to the partner provider.
 *
 * Per step, not per journey, because that is how the provider is chosen in the builder — a journey
 * can hold several email steps pinned to different providers, and moving all of them because one
 * hit a quota would change sends that were working.
 */
/**
 * Did we just come FROM the provider we are about to move to?
 *
 * There are two email providers to choose between, so when both are refusing — one over its plan
 * allowance, the other over its rate limit — every switch makes the next one inevitable and the
 * sending bounces between them for as long as the failures last, writing a switch record and an
 * alert each time. The messages fail either way; the flapping just buries the real problem in
 * noise and makes the report unreadable.
 *
 * So a move back to somewhere we left recently is refused, and the dead-end alert is raised
 * instead — which is the honest message: there is nowhere left to send from, and a person has to
 * do something about it.
 *
 * @param string $scopeSql  the WHERE fragment identifying this campaign or step
 */
function failover_just_came_from(string $scopeSql, string $to, string $from): bool {
    global $conn;
    $hours = (int)FAILOVER_PINGPONG_HOURS;
    $r = @$conn->query("SELECT 1 FROM email_provider_switches
                         WHERE $scopeSql
                           AND from_provider = '" . $conn->real_escape_string($to) . "'
                           AND to_provider   = '" . $conn->real_escape_string($from) . "'
                           AND switched_at >= DATE_SUB(NOW(), INTERVAL $hours HOUR)
                         LIMIT 1");
    return (bool)($r && $r->num_rows > 0);
}

function failover_switch_journey_step(int $journeyId, string $nodeId, string $stepLabel,
                                      string $from, string $code, string $sampleError, int $count): ?string {
    global $conn;
    failover_ensure_schema();

    $to = failover_partner($from);
    if ($to === null) return null;

    // Refuse to move back to a provider this step left in the last few hours — see above.
    $scope = "scope = 'journey' AND journey_id = " . (int)$journeyId
           . " AND node_id = '" . $conn->real_escape_string($nodeId) . "'";
    if (failover_just_came_from($scope, $to, $from)) {
        failover_alert_dead_end('journey', null, $journeyId, $nodeId, $from, $to, $code, $sampleError, $count);
        return null;
    }

    if (!failover_provider_ready($to)) {
        failover_alert_dead_end('journey', null, $journeyId, $nodeId, $from, $to, $code, $sampleError, $count);
        return null;
    }

    $r = $conn->query("SELECT name, graph, current_version_id FROM journeys WHERE id = " . (int)$journeyId . " LIMIT 1");
    $row = $r ? $r->fetch_assoc() : null;
    if (!$row) return null;
    $jName = (string)$row['name'];

    /*
     * WRITTEN INTO BOTH GRAPHS, AND THE SECOND ONE IS THE POINT.
     *
     * A journey has two copies of itself: the draft in journeys.graph, which the builder edits, and
     * the published snapshot in journey_versions, which is what the engine actually executes once
     * the journey is live (see journey_graph_for_execution). This only ever wrote the draft.
     *
     * So the failover looked like it worked from every angle except the one that matters. The
     * switch was recorded, the alert went out, the step drawer showed the new provider — and the
     * engine carried on reading the published version, sent the next message through the provider
     * that had just refused 611 of them, and failed again. The evidence: step n2 of journey 57 was
     * switched to SES at 11:35:05 and its next two sends at 11:36 still went out on Elastic Email.
     *
     * Both copies are updated so the running journey moves and the builder agrees with it.
     */
    /* The domain the new provider is allowed to send from — see failover_provider_domain(). */
    $toDomain = failover_provider_domain($to);

    $write = static function (string $rawGraph) use ($nodeId, $to, $toDomain): ?string {
        $g = json_decode($rawGraph, true);
        if (!is_array($g) || !isset($g['nodes'][$nodeId])) return null;
        $g['nodes'][$nodeId]['cfg']['provider'] = $to;
        // Move the sender onto a domain the new provider has verified, keeping the local part.
        if ($toDomain !== '' && (string)($g['nodes'][$nodeId]['cfg']['from'] ?? '') !== $toDomain) {
            $g['nodes'][$nodeId]['cfg']['from'] = $toDomain;
        }
        return json_encode($g);
    };

    $draft = $write((string)$row['graph']);
    if ($draft !== null) {
        $conn->query("UPDATE journeys SET graph = '" . $conn->real_escape_string($draft) . "'
                       WHERE id = " . (int)$journeyId);
    }

    $versionId = (int)($row['current_version_id'] ?? 0);
    if ($versionId > 0) {
        $vr = $conn->query("SELECT graph FROM journey_versions WHERE id = $versionId LIMIT 1");
        $vrow = $vr ? $vr->fetch_assoc() : null;
        if ($vrow) {
            $live = $write((string)$vrow['graph']);
            if ($live !== null) {
                $conn->query("UPDATE journey_versions SET graph = '" . $conn->real_escape_string($live) . "'
                               WHERE id = $versionId");
            }
        }
    }

    $reason = failover_reason_text($code);
    $label  = $stepLabel !== '' ? $stepLabel : $nodeId;
    $conn->query("INSERT INTO email_provider_switches
        (scope, journey_id, node_id, step_label, from_provider, to_provider, reason_code, reason, sample_error, failure_count, switched_at)
        VALUES ('journey', " . (int)$journeyId . ",
                '" . $conn->real_escape_string($nodeId) . "',
                '" . $conn->real_escape_string(mb_substr($label, 0, 180)) . "',
                '" . $conn->real_escape_string($from) . "', '" . $conn->real_escape_string($to) . "',
                '" . $conn->real_escape_string($code) . "',
                '" . $conn->real_escape_string($reason) . "',
                '" . $conn->real_escape_string(mb_substr($sampleError, 0, 490)) . "',
                " . (int)$count . ", NOW())");
    $switchId = (int)$conn->insert_id;

    if (function_exists('journey_log')) {
        journey_log("journey #$journeyId step $nodeId: PROVIDER SWITCHED $from -> $to because $reason ($count failure(s))");
    }

    $ok = alert_notify(
        "failover:journey:$journeyId:$nodeId",
        'Journey email step switched provider',
        "The step *$label* in journey *$jName* stopped sending through *" . failover_label($from)
        . "* because " . $reason . ". That step has been moved to *" . failover_label($to) . "*.",
        [
            'Journey'      => $jName . ' (id ' . $journeyId . ')',
            'Step'         => $label . ' (' . $nodeId . ')',
            'Switched'     => failover_label($from) . '  ->  ' . failover_label($to),
            'Reason'       => ucfirst($reason),
            'Failures seen'=> (string)$count . ' in the last ' . FAILOVER_JOURNEY_WINDOW_MINUTES . ' minutes',
            'Provider said'=> mb_substr($sampleError, 0, 400),
            'Other steps'  => 'Unchanged — only this step moved.',
        ],
        'critical'
    );
    if ($ok) $conn->query("UPDATE email_provider_switches SET alerted = 1 WHERE id = $switchId");

    return $to;
}

/**
 * Decides whether a journey email step has failed enough to move, and moves it.
 *
 * Called on every failed email send. Cheap on the common path: an error that is not account-level
 * returns before any query runs, which is every ordinary bounce and bad address.
 */
function failover_consider_journey_step(array $journey, array $cfg, array $ctx, string $provider, string $error): void {
    global $conn;

    $code = failover_classify($error);
    if ($code === null) return;                       // a per-recipient failure; not our business
    if (!failover_code_switches($code)) return;       // slowing down or a person fixes this, not moving

    $journeyId = (int)($journey['id'] ?? 0);
    $nodeId    = (string)($ctx['node_id'] ?? '');
    if ($journeyId <= 0 || $nodeId === '') return;

    // Already moved? The step's stored provider has changed, so the failures being counted are
    // from before the switch and must not trigger a second one straight back.
    if (failover_partner($provider) === null) return;

    /*
     * ONLY FAILURES SINCE THE LAST SWITCH COUNT.
     *
     * Without this the evidence for a switch survives the switch that acted on it. This step moved
     * off Elastic Email at 11:35 on the strength of 200 failures in the preceding half hour, and
     * then moved again at 11:36, and again a second later — the same 200 rows were still inside
     * the window, still failed, still carrying the same reason, so every subsequent send re-proved
     * a case that had already been answered. Three switch records and three alerts for one event.
     *
     * The floor is the moment this step last changed provider. Anything before it is history: it
     * describes a provider the step is no longer using and cannot be a reason to leave the one it
     * moved to.
     */
    $nodeE  = $conn->real_escape_string($nodeId);
    $scope  = "scope = 'journey' AND journey_id = $journeyId AND node_id = '$nodeE'";
    $lr     = @$conn->query("SELECT MAX(switched_at) t FROM email_provider_switches WHERE $scope");
    $since  = $lr ? (string)($lr->fetch_assoc()['t'] ?? '') : '';
    $sinceSql = ($since !== '' && $since !== '0000-00-00 00:00:00')
        ? " AND queued_at > '" . $conn->real_escape_string($since) . "'" : '';

    $window = (int)FAILOVER_JOURNEY_WINDOW_MINUTES;
    $r = @$conn->query("SELECT COUNT(*) c FROM journey_messages
                         WHERE journey_id = $journeyId
                           AND node_id = '$nodeE'
                           AND status = 'failed'
                           AND queued_at >= DATE_SUB(NOW(), INTERVAL $window MINUTE)
                           $sinceSql");
    $recent = $r ? (int)$r->fetch_assoc()['c'] : 0;
    if ($recent < FAILOVER_THRESHOLD) return;

    /*
     * Those are failures of every kind in the window, so confirm the SHARED reason before acting —
     * thirty different bad addresses must not look like a quota. Only the ones carrying this same
     * account-level condition count toward the decision.
     */
    $r = @$conn->query("SELECT error_message FROM journey_messages
                         WHERE journey_id = $journeyId
                           AND node_id = '$nodeE'
                           AND status = 'failed'
                           AND queued_at >= DATE_SUB(NOW(), INTERVAL $window MINUTE)
                           $sinceSql
                         ORDER BY id DESC LIMIT 200");
    $errors = [];
    while ($r && $row = $r->fetch_assoc()) $errors[] = (string)$row['error_message'];
    $scan = failover_scan($errors);
    if ($scan['code'] === null || $scan['count'] < FAILOVER_THRESHOLD) return;
    if (!failover_code_switches($scan['code'])) return;

    $label = (string)($cfg['__label'] ?? $cfg['template'] ?? '');
    failover_switch_journey_step($journeyId, $nodeId, $label, $provider, $scan['code'], $scan['sample'], $scan['count']);
}

/* ════════════════════════════════════════════════════════════════════════════
   Supporting
   ═══════════════════════════════════════════════════════════════════════════ */

/** Display name, so an alert reads like English rather than a column value. */
function failover_label(string $p): string {
    return ['sendgrid' => 'SendGrid', 'elasticemail' => 'Elastic Email', 'ses' => 'Amazon SES'][$p] ?? $p;
}

/** Can this provider actually send? Switching to one with no credentials turns a stalled campaign
 *  into a failed one, which is strictly worse than leaving it where it was. */
function failover_provider_ready(string $provider): bool {
    global $conn;
    $p = $conn->real_escape_string($provider);
    $r = $conn->query("SELECT api_key, api_secret FROM email_esp_settings WHERE provider = '$p' LIMIT 1");
    $row = $r ? $r->fetch_assoc() : null;
    if (!$row) return false;
    if (trim((string)$row['api_key']) === '') return false;
    // SES needs both halves of the credential pair; the others need only the key.
    if ($provider === 'ses' && trim((string)($row['api_secret'] ?? '')) === '') return false;
    return true;
}

/**
 * The sending domain a provider can actually send from, or '' when it has none on record.
 *
 * A DOMAIN IS VERIFIED WITH ONE PROVIDER, NOT WITH THE ACCOUNT. Switching the provider and leaving
 * the sender address alone hands the new provider a domain it has never heard of, and it refuses
 * every message:
 *
 *   SES 400: Email address is not verified. The following identities failed the check in region
 *   AP-SOUTH-1: iStudio <contact@alert.internshipstudio.com>
 *
 * Which is what happened the first time this failover ran for real. The step moved off Elastic
 * Email correctly, and then failed 21 times in five minutes on Amazon SES for a reason that had
 * nothing to do with why it moved — alert.internshipstudio.com is verified with Elastic Email and
 * SendGrid, and mailer.internshipstudio.com is the one SES holds.
 *
 * So the address moves with the provider. The local part is kept, because that is the identity the
 * recipient sees and it is not the provider's business.
 */
function failover_provider_domain(string $provider): string {
    global $conn;
    $p = $conn->real_escape_string($provider);
    $r = $conn->query("SELECT default_sending_domain FROM email_esp_settings WHERE provider = '$p' LIMIT 1");
    $row = $r ? $r->fetch_assoc() : null;
    return $row ? trim((string)$row['default_sending_domain']) : '';
}

/** Puts the recipients that failed for this reason back in the queue on the new provider. */
function failover_requeue_campaign_failures(int $campaignId, string $code): int {
    global $conn;
    /*
     * Matched on the same words failover_classify() matched on, so exactly the rows that were
     * refused for the account-level reason come back — and a genuinely undeliverable address does
     * not get retried for ever on a second provider.
     */
    $needles = [
        'daily_quota'    => ['daily sending quota', 'daily message quota', 'daily sending limit', '5.4.5'],
        'monthly_quota'  => ['monthly sending quota', 'monthly quota'],
        'account_quota'  => ['quota exceeded'],
        'sender_rejected'=> ['from email address', 'email address is not verified',
                             'identities failed the check', 'sender address rejected'],
        'rate_limited'   => ['429', 'too many requests', 'rate limit', 'throttl'],
        'suspended'      => ['restricted', 'suspended', 'paused'],
        'domain_blocked' => ['domain'],
        'auth_failed'    => ['401', '403', 'unauthor', 'invalid api key', 'signature', 'access denied'],
        'no_credit'      => ['credit', 'balance', 'payment required', '402'],
    ][$code] ?? [];
    if (!$needles) return 0;

    $where = [];
    foreach ($needles as $n) $where[] = "error_message LIKE '%" . $conn->real_escape_string($n) . "%'";

    $conn->query("UPDATE email_campaign_recipients
                     SET status = 'pending', attempts = 0, error_message = NULL,
                         claim_token = NULL, claimed_at = NULL
                   WHERE campaign_id = " . (int)$campaignId . " AND is_test = 0
                     AND status IN ('failed', 'pending') AND (" . implode(' OR ', $where) . ")");
    return $conn->affected_rows;
}

/** A campaign stopped because its provider will not send from its sender address. */
function failover_alert_sender_rejected(int $campaignId, string $name, string $provider, string $senderEmail,
                                        string $sampleError, int $count, int $requeued): void {
    alert_notify(
        "sender-rejected:campaign:$campaignId",
        'Email campaign stopped: sender address refused',
        '*' . ($name !== '' ? $name : "#$campaignId") . '* was stopped because *' . failover_label($provider)
        . '* will not send from *' . $senderEmail . '*. Nobody else has been attempted; the refused recipients are back in the queue.',
        [
            'Campaign'      => $name . ' (id ' . $campaignId . ')',
            'Provider'      => failover_label($provider),
            'Sender'        => $senderEmail,
            'Refused'       => (string)$count,
            'Requeued'      => (string)$requeued,
            'Provider said' => mb_substr($sampleError, 0, 400),
            'Fix'           => 'Use a sender domain verified with ' . failover_label($provider)
                             . ' (or switch the campaign to the provider that holds this domain), then Resume.',
        ],
        'critical'
    );
}

/** Nowhere to go: the partner is not configured. Still worth waking somebody — this is the case
 *  where the send is genuinely stuck and no automation can rescue it. */
function failover_alert_dead_end(string $scope, ?int $campaignId, ?int $journeyId, ?string $nodeId,
                                 string $from, string $to, string $code, string $sampleError, int $count): void {
    $what = $scope === 'campaign' ? "Campaign #$campaignId" : "Journey #$journeyId step $nodeId";
    alert_notify(
        "failover-blocked:$scope:" . ($campaignId ?: $journeyId) . ':' . ($nodeId ?: ''),
        'Email send is stuck and cannot fail over',
        "$what stopped sending through *" . failover_label($from) . "* because " . failover_reason_text($code)
        . ", and *" . failover_label($to) . "* is not configured, so there is nowhere to move it to. "
        . "This send is stopped until somebody acts.",
        [
            'Scope'         => $what,
            'Failing on'    => failover_label($from),
            'Would move to' => failover_label($to) . ' — but it has no credentials saved',
            'Reason'        => ucfirst(failover_reason_text($code)),
            'Recipients hit'=> (string)$count,
            'Provider said' => mb_substr($sampleError, 0, 400),
            'Fix'           => 'Add credentials for ' . failover_label($to) . ' in Settings, or wait for '
                             . failover_label($from) . ' to recover.',
        ],
        'critical'
    );
}

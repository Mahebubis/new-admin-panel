<?php
require_once __DIR__ . '/EspTransport.php';

/*
 * Runs many ESP sends concurrently.
 *
 * This is the whole reason a 40k campaign can finish in minutes rather than hours. An email
 * send is almost entirely WAITING — a few hundred milliseconds of network round-trip during
 * which the server does nothing. Sending sequentially, that dead time is the throughput
 * ceiling: ~3 emails/second no matter how fast the machine is. curl_multi keeps N of those
 * waits overlapping, so throughput becomes (concurrency / latency) instead of (1 / latency).
 *
 * Nothing here knows anything about SendGrid, Elastic Email or SES — each transport builds its
 * own request and interprets its own response (see EspTransport::buildRequest/parseResponse).
 * That keeps provider quirks in the provider classes and concurrency in exactly one place.
 */

/**
 * The cURL options for one built request.
 *
 * Requests are HTTP POSTs by default, which is every transport that talks to a REST API. A
 * transport whose protocol is not HTTP at all supplies a 'curlopts' map instead and this
 * function hands it through verbatim — that is how SES's SMTP mode (smtps://, SMTP AUTH, an
 * uploaded MIME body) reuses this file's concurrency instead of needing a second copy of it.
 * The generic options below still apply in that case; only the POST-shaped ones are skipped,
 * since setting CURLOPT_POST on an SMTP handle conflicts with CURLOPT_UPLOAD.
 */
function esp_curl_options(array $req, int $timeout): array {
    $opts = [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT        => $timeout,
    ];
    if (!empty($req['curlopts']) && is_array($req['curlopts'])) {
        foreach ($req['curlopts'] as $opt => $value) $opts[$opt] = $value;
        return $opts;
    }
    $opts[CURLOPT_POST]       = true;
    $opts[CURLOPT_POSTFIELDS] = $req['body'];
    $opts[CURLOPT_HTTPHEADER] = $req['headers'];
    return $opts;
}

/** Performs one already-built request. The single-send path (Send Test Email) and the
 *  fallback when there is only one job, so both share identical cURL options. */
function esp_http_exec(array $req, int $timeout = 20): array {
    $ch = curl_init($req['url']);
    curl_setopt_array($ch, esp_curl_options($req, $timeout));
    $body    = curl_exec($ch);
    $status  = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $curlErr = curl_error($ch);
    curl_close($ch);
    return [$status, $body === false ? null : $body, $curlErr];
}

/**
 * Sends every job, at most $concurrency in flight at once.
 *
 * @param array $jobs each ['key' => mixed, 'rid' => ?string, 'req' => built request]
 *                    `key` is echoed back as the result key — SendWorker passes the
 *                    recipient row id so results map straight back to rows.
 * @return array<mixed, array{ok: bool, message_id: ?string, error: ?string, retryable: bool}>
 */
function esp_send_parallel(EspTransport $transport, array $jobs, int $concurrency = 32, int $timeout = 20, ?EspRateLimiter $limiter = null): array {
    $results = [];
    if (!$jobs) return $results;

    $queue = array_values($jobs);
    $total = count($queue);
    $concurrency = max(1, min($concurrency, $total));

    // One handle in flight isn't worth curl_multi's bookkeeping.
    if ($concurrency === 1) {
        foreach ($queue as $job) {
            if ($limiter) {
                $wait = $limiter->take() - microtime(true);
                if ($wait > 0) usleep((int)($wait * 1000000));
            }
            [$status, $body, $err] = esp_http_exec($job['req'], $timeout);
            $results[$job['key']] = $transport->parseResponse($status, $body, $err, $job['rid'] ?? null);
        }
        return $results;
    }

    $mh = curl_multi_init();
    $next = 0;
    $inFlight = [];  // handle id => job

    // PHP 8 hands back CurlHandle OBJECTS, not resources, so (int)$ch is a TypeError there;
    // spl_object_id is the object-safe equivalent. The is_object() check keeps this working
    // if it is ever run on an older PHP where curl_init() still returns a resource.
    $handleId = fn($ch) => is_object($ch) ? spl_object_id($ch) : (int)$ch;

    $launch = function () use (&$queue, &$next, &$inFlight, $mh, $timeout, $total, $handleId) {
        if ($next >= $total) return false;
        $job = $queue[$next++];
        $ch = curl_init($job['req']['url']);
        curl_setopt_array($ch, esp_curl_options($job['req'], $timeout));
        curl_multi_add_handle($mh, $ch);
        $inFlight[$handleId($ch)] = $job;
        return true;
    };

    /*
     * Launch pacing. Without a limiter a freed slot is refilled at once, as before. With one, a
     * send also waits for its time slot — the difference between "14 in flight" and "14 a second",
     * which for Amazon SES is the difference between sending and being throttled.
     */
    $slotAt = null;   // local time the next launch may happen, once a slot has been taken
    $fill = function () use (&$next, $total, &$inFlight, $concurrency, $limiter, &$slotAt, $launch) {
        while ($next < $total && count($inFlight) < $concurrency) {
            if ($limiter) {
                if ($slotAt === null) $slotAt = $limiter->take();
                if (microtime(true) < $slotAt) return;
                $slotAt = null;
            }
            $launch();
        }
    };

    $fill();

    do {
        $status = curl_multi_exec($mh, $running);
        if ($status !== CURLM_OK) break;

        // How long we may block: until the next slot opens when one is waiting, else a second.
        $wait = 1.0;
        if ($slotAt !== null && count($inFlight) < $concurrency) {
            $wait = min(1.0, max(0.001, $slotAt - microtime(true)));
        }
        // Block until a handle actually has activity rather than spinning the CPU at 100%.
        // Guarded on $running because select() returns immediately (and can return -1) when
        // nothing is in flight — which happens on the tick right after the last completion.
        if ($running > 0) curl_multi_select($mh, $wait);
        elseif (!$inFlight && $next < $total) usleep((int)($wait * 1000000));

        while ($done = curl_multi_info_read($mh)) {
            $ch  = $done['handle'];
            $id  = $handleId($ch);
            $job = $inFlight[$id] ?? null;

            if ($job !== null) {
                $body = curl_multi_getcontent($ch);
                $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
                // $done['result'] is the cURL-level outcome (timeout, DNS, TLS). curl_error()
                // alone is unreliable once a handle has been removed from the multi stack.
                $err  = $done['result'] !== CURLE_OK ? (curl_error($ch) ?: 'cURL error ' . $done['result']) : '';
                $results[$job['key']] = $transport->parseResponse($code, $body, $err, $job['rid'] ?? null);
                unset($inFlight[$id]);
            }

            curl_multi_remove_handle($mh, $ch);
            curl_close($ch);
        }
        // Backfill freed slots — immediately without a limiter, as each time slot opens with one.
        $fill();
    } while ($running > 0 || $inFlight || $next < $total);

    curl_multi_close($mh);
    return $results;
}

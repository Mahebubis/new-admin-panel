<?php
/**
 * /api/caller-iq/live_call.php  —  Caller IQ live call presence (no JWT: phones cannot log in)
 * ---------------------------------------------------------------------------
 * POST { device_id, state: ringing|connected|ended, direction, number?, started_at(ms),
 *        answered_at?(ms), event_at(ms), sim_slot?, sim_label?, carrier?,
 *        device_model?, app_version? }
 *
 * Sent by the phone as a call happens, because the call log does not exist until the call is
 * over. Cheap on purpose: one row per phone, no history — the finished call is recorded by
 * log_call.php, and this row is only what the dashboard's "Live now" strip reads.
 *
 * Answers 200 for anything it can parse (the phone must not retry a payload for a call that has
 * already ended) and 503 only for our own failures, which the phone's worker does retry.
 * ---------------------------------------------------------------------------
 */
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../middleware/auth.php';
require_once __DIR__ . '/ciq_lib.php';

mysqli_report(MYSQLI_REPORT_OFF);
set_exception_handler(function (Throwable $e) {
    error_log('[caller-iq live] ' . $e->getMessage() . ' @ ' . $e->getFile() . ':' . $e->getLine());
    api_error('Temporary failure, retry later', 503);
});

require_method('POST');

/* ciq_live_update() lives in ciq_lib.php. If only part of the folder was uploaded, answer with a
   plain message the phone can retry against, rather than a PHP fatal it would retry forever. */
if (!function_exists('ciq_live_update')) {
    api_error('Server not ready: deploy react-api/api/caller-iq/ciq_lib.php', 503);
}

$in = get_json_input();

if (CALLER_IQ_INGEST_KEY !== '') {
    $sent = $_SERVER['HTTP_X_CALLIQ_KEY'] ?? ($in['key'] ?? '');
    if (!hash_equals(CALLER_IQ_INGEST_KEY, (string)$sent)) api_error('Invalid ingest key', 401);
}

if (!$in || !is_array($in)) api_success(['stored' => false], 'Empty payload ignored');

ciq_ensure_schema($conn);

/* Keep the device row fresh too: a phone on a call is plainly alive, which is what the Agents tab
   reports as "Active" — without this a busy phone could look offline between call syncs. */
$device = substr(preg_replace('/[^A-Za-z0-9_\-:.]/', '', (string)($in['device_id'] ?? '')), 0, 64);
if ($device !== '') {
    $now = date('Y-m-d H:i:s');
    $model = ciq_str($in['device_model'] ?? '', 120);
    $ver   = ciq_str($in['app_version'] ?? '', 20);
    $ip    = substr(get_client_ip(), 0, 64);
    $popupOk = array_key_exists('popup_ok', $in) ? (int)(bool)$in['popup_ok'] : null;
    if ($d = $conn->prepare("INSERT INTO caller_iq_devices (device_id, device_model, app_version, last_ip, popup_ok, first_seen_at, last_seen_at)
                             VALUES (?,?,?,?,?,?,?)
                             ON DUPLICATE KEY UPDATE
                               device_model = IF(VALUES(device_model) = '', device_model, VALUES(device_model)),
                               app_version  = IF(VALUES(app_version) = '', app_version, VALUES(app_version)),
                               last_ip      = VALUES(last_ip),
                               popup_ok     = COALESCE(VALUES(popup_ok), popup_ok),
                               last_seen_at = VALUES(last_seen_at)")) {
        $d->bind_param('ssssiss', $device, $model, $ver, $ip, $popupOk, $now, $now);
        $d->execute();
        $d->close();
    }
}

$r = ciq_live_update($conn, $in);
if (!$r['ok'] && ($r['reason'] ?? '') !== '' && strpos($r['reason'], 'unknown state') === false) {
    error_log('[caller-iq live] ' . $r['reason']);
    api_error('Could not store the live call, retry later', 503);
}

api_success(['stored' => (bool)$r['ok'], 'note' => $r['reason'] ?? ''], 'OK');

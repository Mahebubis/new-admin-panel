<?php
/*
 * lib/DeliveryReceipts.php — the one place a provider's receipt moves a campaign counter.
 *
 * THREE WAYS THE NUMBERS USED TO LIE
 *
 * 1. A RECEIPT ARRIVES MORE THAN ONCE. Amazon SNS delivers every notification AT LEAST once, and
 *    the Elastic Email poller deliberately re-reads an overlapping window so nothing is lost at
 *    its edge. The old code answered each arrival with "delivered_count = delivered_count + 1",
 *    so a repeat was a second delivery. Campaign #85 reported 1,987 deliveries to 1,066 people.
 *
 * 2. A TEST SEND COUNTS AS AN AUDIENCE MEMBER. A test is a real message with a real receipt, and
 *    its row lives in the same table (is_test = 1). Everything else — Sent, the report's people
 *    lists, the open and click trackers — already ignores those rows, so counting their receipts
 *    made Delivered exceed Sent: campaign #106 was sent to 2 people and reported 3 delivered,
 *    the third being the test the sender mailed to themselves.
 *
 * So a receipt is recorded on the recipient's own row FIRST, and the campaign counter moves only
 * when that row changed — which happens exactly once however many copies of the receipt arrive —
 * and only when the row is not a test send. The row is the fact; the counter is a summary of it.
 *
 * 3. A BOUNCE ARRIVES AFTER A DELIVERY. A mail server can accept a message ("delivered") and reject
 *    it a moment later ("bounced") — campaign #107 got both for the same address two seconds apart,
 *    and showed 2 delivered and 1 bounced for 2 people. A bounced message was not delivered, so the
 *    bounce takes the delivery back; and a delivery report that arrives AFTER the bounce is not
 *    counted in the first place. Either order ends in the same numbers.
 *
 * Every function takes the recipient row (id, campaign_id, is_test) and returns whether this was
 * the first time that receipt was seen, so the caller can skip the rest of its work on a replay.
 */

/** A receipt for a test send is recorded on the row, but never counted for the campaign. */
function receipt_counts_for_campaign(array $recipient): bool {
    return (int)($recipient['is_test'] ?? 0) === 0;
}

/**
 * The provider confirmed the mailbox accepted this message.
 *
 * @return bool true the first time, false for every replay of the same receipt
 */
function campaign_receipt_delivered(array $recipient): bool {
    global $conn;
    $rowId = (int)$recipient['id'];
    $cid   = (int)$recipient['campaign_id'];

    $conn->query("UPDATE email_campaign_recipients SET delivered_at = NOW()
                   WHERE id = $rowId AND delivered_at IS NULL");
    if ($conn->affected_rows < 1) return false;

    /*
     * DELIVERED CANNOT OUTRUN SENT.
     *
     * The worker claims five hundred recipients, marks them 'processing', sends them — at the SES
     * pace that takes about forty-five seconds — and writes 'sent' for the whole batch at the end.
     * The delivery confirmations come back within seconds, so for most of that window the campaign
     * had rows that were delivered while still counted as unsent: the list read 2,728 delivered
     * against 2,500 sent, which reads as a broken report even though the final numbers were right.
     *
     * A delivery receipt is itself proof the message went out, so the row is marked sent here and
     * the campaign's own sent figure recounted. The worker's end-of-batch write then agrees with
     * what is already recorded rather than contradicting it.
     */
    $conn->query("UPDATE email_campaign_recipients
                     SET status = 'sent', sent_at = COALESCE(sent_at, NOW())
                   WHERE id = $rowId AND status = 'processing'");
    if ($conn->affected_rows > 0 && receipt_counts_for_campaign($recipient)) {
        $c = $conn->query("SELECT COUNT(*) c FROM email_campaign_recipients
                            WHERE campaign_id = $cid AND is_test = 0 AND status IN ('sent','bounced')");
        if ($c) $conn->query("UPDATE email_campaigns SET sent_count = " . (int)$c->fetch_assoc()['c'] . " WHERE id = $cid");
    }

    // Already bounced? Then this delivery report is out of date — stamped, never counted.
    $b = $conn->query("SELECT bounced_at FROM email_campaign_recipients WHERE id = $rowId LIMIT 1");
    $alreadyBounced = $b && ($br = $b->fetch_assoc()) && !empty($br['bounced_at']);

    if (!$alreadyBounced && receipt_counts_for_campaign($recipient)) {
        $conn->query("UPDATE email_campaigns SET delivered_count = delivered_count + 1 WHERE id = $cid");
    }
    return true;
}

/**
 * The message bounced. $type is 'hard' or 'soft' — the caller's provider classifies it, because
 * each provider words it differently (see each webhook's own note).
 *
 * @return bool true the first time, false for every replay
 */
function campaign_receipt_bounced(array $recipient, string $type): bool {
    global $conn;
    $rowId = (int)$recipient['id'];
    $cid   = (int)$recipient['campaign_id'];
    $type  = $type === 'soft' ? 'soft' : 'hard';

    // Was it counted as delivered before this bounce arrived? Read BEFORE the update below.
    $d = $conn->query("SELECT delivered_at FROM email_campaign_recipients WHERE id = $rowId LIMIT 1");
    $wasDelivered = $d && ($dr = $d->fetch_assoc()) && !empty($dr['delivered_at']);

    $conn->query("UPDATE email_campaign_recipients
                     SET status = 'bounced', bounced_at = NOW(), bounce_type = '$type'
                   WHERE id = $rowId AND bounced_at IS NULL");
    if ($conn->affected_rows < 1) return false;

    if (receipt_counts_for_campaign($recipient)) {
        $col = $type === 'soft' ? 'soft_bounce_count' : 'hard_bounce_count';
        // The bounce takes back a delivery counted a moment earlier — a message cannot be both.
        $undo = $wasDelivered ? ', delivered_count = GREATEST(delivered_count - 1, 0)' : '';
        $conn->query("UPDATE email_campaigns SET bounce_count = bounce_count + 1, $col = $col + 1$undo WHERE id = $cid");
    }
    return true;
}

/**
 * An unsubscribe or a spam complaint.
 *
 * Neither has a timestamp column of its own on the recipient row, so the event row already
 * written to email_campaign_events is the record that this receipt was seen — the same approach
 * the Elastic Email sink has always used.
 *
 * @param string $eventType 'unsubscribe' or 'spamreport'
 * @return bool true the first time, false for every replay
 */
function campaign_receipt_once(array $recipient, string $eventType): bool {
    global $conn;
    $rowId = (int)$recipient['id'];
    $cid   = (int)$recipient['campaign_id'];
    $t     = $conn->real_escape_string($eventType);

    $seen = $conn->query("SELECT 1 FROM email_campaign_events
                           WHERE recipient_id = $rowId AND event_type = '$t' LIMIT 1");
    if ($seen && $seen->num_rows > 0) return false;

    if (receipt_counts_for_campaign($recipient)) {
        $col = $eventType === 'unsubscribe' ? 'unsubscribe_count' : 'spam_count';
        $conn->query("UPDATE email_campaigns SET $col = $col + 1 WHERE id = $cid");
    }
    return true;
}

<?php
/*
 * /api/whatsapp/lib/WaTemplateWabas.php
 *
 * One template, many WhatsApp Business Accounts.
 *
 * ── The problem ──────────────────────────────────────────────────────────────
 * A WhatsApp template is approved by Meta AGAINST ONE WABA. Add a second sending number
 * under a second WABA and none of the approved templates come with it — every one has to
 * be submitted again, approved again, and tracked again. Until now this panel modelled a
 * template as a single row with a single meta_template_id and a single approval_status,
 * which could only ever describe one of those accounts. Adding the second number therefore
 * broke campaign sending in a way the screen could not show: the template said APPROVED,
 * and the send failed because it was approved somewhere else.
 *
 * ── The shape ────────────────────────────────────────────────────────────────
 * The template stays ONE row — one piece of copy, edited in one place, which is the whole
 * point of a template library. What is per-WABA moves into wa_template_wabas: the Meta
 * template id it got on that account, its approval status there, the category Meta filed
 * it under there, and why it was rejected if it was.
 *
 * wa_templates keeps a ROLLUP of that (approval_status, meta_template_id) so every existing
 * query, campaign wizard and journey step keeps working unchanged. The rollup is the
 * pessimistic answer: a template is only "approved" when it is approved on EVERY account it
 * has been submitted to, because a campaign can go out from any of them.
 *
 * ── Category drift, and why it disables a template ───────────────────────────
 * Meta re-classifies templates on its own. A template submitted and approved as UTILITY can
 * be moved to MARKETING at any time — usually weeks later, with no notification. That is not
 * a cosmetic change: MARKETING messages are billed at a different rate, require marketing
 * opt-in, and are subject to per-user marketing frequency caps that silently drop them. A
 * journey or campaign that was designed around a utility template and is quietly sending
 * marketing is the single most expensive failure this integration can have.
 *
 * So a template whose EFFECTIVE category (what Meta says today) no longer matches its
 * REQUESTED category (what it was built as) is auto-disabled: it stops being selectable in
 * campaigns and journeys until somebody looks at it. The check is cheap and runs on the
 * stored data every time the template list is opened; the underlying categories are
 * refreshed from Meta on a throttle, oldest-checked-first, so opening the list does not
 * turn into 130 Graph calls.
 */

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/WaHelpers.php';
require_once __DIR__ . '/schema.php';   // wa_default_sender(), wa_settings_row()

/** How long a template's Meta category is trusted before it is re-read. */
if (!defined('WA_CATEGORY_TTL_MINUTES')) define('WA_CATEGORY_TTL_MINUTES', 180);
/** Templates re-checked against Meta per list request. Keeps the page fast; the rest are
 *  picked up on the next visit because the sweep is oldest-checked-first. */
if (!defined('WA_CATEGORY_SWEEP_LIMIT')) define('WA_CATEGORY_SWEEP_LIMIT', 12);
/** Width of wa_templates.disabled_reason. The sentence is assembled from three parts and the
 *  longest combination is 472 characters, which is why the original VARCHAR(400) threw
 *  "Data too long" and took the whole template list down with it. */
if (!defined('WA_DISABLED_REASON_MAX')) define('WA_DISABLED_REASON_MAX', 1000);

/**
 * Clip a string to a column's width, in CHARACTERS.
 *
 * VARCHAR(n) under utf8mb4 counts characters, not bytes, so mb_substr is the measure that
 * matches the column — substr() would cut mid-codepoint and store broken UTF-8. Anything
 * written to a bounded column goes through here: a value that is one character too long is
 * a fatal mysqli_sql_exception, not a truncation warning, and one row's overflow otherwise
 * kills the request that was only passing by.
 */
function wa_clip(?string $s, int $max): ?string {
    if ($s === null) return null;
    return mb_strlen($s) > $max ? mb_substr($s, 0, $max) : $s;
}

function wa_template_wabas_ensure_schema(): void {
    global $conn;
    static $done = false;
    if ($done || !$conn) return;
    $done = true;

    @$conn->query("CREATE TABLE IF NOT EXISTS wa_template_wabas (
        id               INT AUTO_INCREMENT PRIMARY KEY,
        template_id      INT NOT NULL,
        waba_id          VARCHAR(64) NOT NULL,
        waba_name        VARCHAR(255) DEFAULT NULL,
        meta_template_id VARCHAR(64) DEFAULT NULL,
        -- 'not_submitted' is a real state and distinct from 'pending': a WABA added after a
        -- template was approved has never been asked, which is a different thing from having
        -- been asked and waiting. Without it, a new number looks like it is mid-review forever.
        approval_status  ENUM('approved','pending','rejected','unknown','not_submitted')
                           NOT NULL DEFAULT 'not_submitted',
        -- What Meta has this template filed as ON THIS ACCOUNT. Categories are decided per
        -- submission, so two WABAs can genuinely disagree, and the stricter one has to win.
        meta_category    VARCHAR(32) DEFAULT NULL,
        rejected_reason  VARCHAR(120) DEFAULT NULL,
        last_error       VARCHAR(500) DEFAULT NULL,
        submitted_at     DATETIME DEFAULT NULL,
        last_synced_at   DATETIME DEFAULT NULL,
        created_at       TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at       TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        UNIQUE INDEX uq_template_waba (template_id, waba_id),
        INDEX idx_waba (waba_id, approval_status)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $add = function (string $col, string $ddl) use ($conn) {
        $chk = @$conn->query("SHOW COLUMNS FROM wa_templates LIKE '$col'");
        if ($chk && $chk->num_rows === 0) @$conn->query("ALTER TABLE wa_templates ADD COLUMN $ddl");
    };
    /*
     * `category` keeps its meaning — what this template was BUILT as, and what it is submitted
     * to Meta as. meta_category is what Meta currently says. Splitting them is what makes drift
     * detectable at all: with one column, an incoming sync would simply overwrite the answer
     * and the change would leave no trace.
     */
    $add('meta_category',       "meta_category VARCHAR(32) DEFAULT NULL AFTER category");
    $add('auto_disabled',       "auto_disabled TINYINT(1) NOT NULL DEFAULT 0 AFTER approval_status");
    $add('disabled_reason',     'disabled_reason VARCHAR(' . WA_DISABLED_REASON_MAX . ') DEFAULT NULL AFTER auto_disabled');
    $add('category_checked_at', "category_checked_at DATETIME DEFAULT NULL AFTER disabled_reason");

    /*
     * Widen disabled_reason on accounts that already have it.
     *
     * It was created as VARCHAR(400), and the sentence the drift rule writes runs to 472
     * characters at its longest (UTILITY re-filed as MARKETING — the most common drift there
     * is). Writing it threw "Data too long for column 'disabled_reason'", and because that is
     * a mysqli EXCEPTION rather than a warning it escaped the sweep, escaped wa_templates.php
     * and returned a fatal error page where the template list should have been: every
     * WhatsApp campaign on the panel lost its template picker over one row's text.
     *
     * The column is only ever ADDed above, never modified, so a widening has to be its own
     * step. Keyed on the stored width so it runs once and is a no-op on every later request.
     */
    $w = @$conn->query("SELECT CHARACTER_MAXIMUM_LENGTH AS len FROM INFORMATION_SCHEMA.COLUMNS
                         WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'wa_templates'
                           AND COLUMN_NAME = 'disabled_reason' LIMIT 1");
    $len = $w ? (int)($w->fetch_assoc()['len'] ?? 0) : 0;
    if ($len > 0 && $len < WA_DISABLED_REASON_MAX) {
        @$conn->query('ALTER TABLE wa_templates MODIFY COLUMN disabled_reason VARCHAR('
                      . WA_DISABLED_REASON_MAX . ') DEFAULT NULL');
    }

    /*
     * ── One-time reset of fabricated category evidence ───────────────────────────
     *
     * The first version of this feature let wa_upsert_templates() write its FALLBACK category
     * ('utility', used whenever a record carried none) into meta_category. Every sync and every
     * paste-import therefore claimed Meta had filed every template as utility, so every
     * MARKETING and AUTHENTICATION template on the account read as re-classified and the drift
     * rule disabled the entire library in one pass.
     *
     * Fixing the writer stops it happening again but does not undo what is already stored: the
     * bad values are indistinguishable from good ones, and wa_template_recompute() would keep
     * acting on them. So all of it is cleared, once.
     *
     * Clearing is safe precisely because meta_category is a CACHE of something Meta will tell us
     * again: wa_template_category_sweep() re-reads it, oldest-first, over the next few visits to
     * the template list, and any template that genuinely has drifted is disabled again — this
     * time on an answer Meta actually gave.
     *
     * The marker is the existence of the column added immediately below. It is added exactly
     * once, on the first request after this deploy, which makes it the hook for the reset with
     * no extra bookkeeping table and no chance of running twice.
     */
    $marker = $conn->query("SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS
                             WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'wa_templates'
                               AND COLUMN_NAME = 'category_evidence_reset_at' LIMIT 1");
    if ($marker && $marker->num_rows === 0) {
        @$conn->query("ALTER TABLE wa_templates ADD COLUMN category_evidence_reset_at DATETIME DEFAULT NULL");
        @$conn->query("UPDATE wa_templates
                          SET meta_category = NULL,
                              auto_disabled = 0,
                              disabled_reason = NULL,
                              category_checked_at = NULL,
                              category_evidence_reset_at = NOW()");
        // The per-WABA rows carry the same fabricated value and are what recompute actually
        // reads, so clearing only the template row would change nothing.
        @$conn->query("UPDATE wa_template_wabas SET meta_category = NULL, last_synced_at = NULL");
    }
}

/* ════════════════════════════════════════════════════════════════════════════
   Which accounts a template has to live on
   ═══════════════════════════════════════════════════════════════════════════ */

/**
 * Every WABA this account sends from — one entry per distinct waba_id across the active
 * sending numbers, not one per number. Two numbers under one business share a template
 * library, so submitting twice to the same WABA would be refused by Meta as a duplicate.
 */
function wa_active_wabas(): array {
    global $conn;
    $out = [];
    $r = @$conn->query("SELECT waba_id,
                               MIN(waba_name) AS waba_name,
                               GROUP_CONCAT(business_number ORDER BY is_default DESC SEPARATOR ', ') AS numbers
                          FROM wa_senders
                         WHERE is_active = 1 AND waba_id <> ''
                         GROUP BY waba_id
                         ORDER BY MAX(is_default) DESC, waba_id ASC");
    while ($r && $row = $r->fetch_assoc()) {
        $out[] = [
            'waba_id'   => (string)$row['waba_id'],
            'waba_name' => (string)($row['waba_name'] ?: ''),
            'numbers'   => (string)($row['numbers'] ?: ''),
        ];
    }
    return $out;
}

/** The per-WABA rows for one template, with a row synthesised for any WABA it has never
 *  been submitted to — so the UI always shows every account, not only the ones it has seen. */
function wa_template_waba_rows(int $templateId): array {
    global $conn;
    wa_template_wabas_ensure_schema();

    $stored = [];
    $r = @$conn->query("SELECT * FROM wa_template_wabas WHERE template_id = " . (int)$templateId);
    while ($r && $row = $r->fetch_assoc()) $stored[(string)$row['waba_id']] = $row;

    $out = [];
    foreach (wa_active_wabas() as $w) {
        $row = $stored[$w['waba_id']] ?? null;
        $out[] = [
            'waba_id'          => $w['waba_id'],
            'waba_name'        => $w['waba_name'] ?: ($row['waba_name'] ?? ''),
            'numbers'          => $w['numbers'],
            'meta_template_id' => $row['meta_template_id'] ?? null,
            'approval_status'  => $row['approval_status'] ?? 'not_submitted',
            'meta_category'    => $row['meta_category'] ?? null,
            'rejected_reason'  => $row['rejected_reason'] ?? null,
            'last_error'       => $row['last_error'] ?? null,
            'submitted_at'     => $row['submitted_at'] ?? null,
            'last_synced_at'   => $row['last_synced_at'] ?? null,
        ];
        unset($stored[$w['waba_id']]);
    }
    /*
     * A WABA that is no longer an active sender but still carries this template. Kept in the
     * list and flagged, because deleting the sending number does not delete the template on
     * Meta's side — and a template still approved on an account nobody is watching is exactly
     * the sort of thing that resurfaces when that number is switched back on.
     */
    foreach ($stored as $row) {
        $out[] = [
            'waba_id'          => (string)$row['waba_id'],
            'waba_name'        => (string)($row['waba_name'] ?? ''),
            'numbers'          => '',
            'meta_template_id' => $row['meta_template_id'],
            'approval_status'  => $row['approval_status'],
            'meta_category'    => $row['meta_category'],
            'rejected_reason'  => $row['rejected_reason'],
            'last_error'       => $row['last_error'],
            'submitted_at'     => $row['submitted_at'],
            'last_synced_at'   => $row['last_synced_at'],
            'inactive'         => 1,
        ];
    }
    return $out;
}

/** Write one WABA's state for one template. */
function wa_template_waba_upsert(int $templateId, string $wabaId, array $fields): void {
    global $conn;
    wa_template_wabas_ensure_schema();
    if ($wabaId === '') return;

    $cols = ['waba_name', 'meta_template_id', 'approval_status', 'meta_category',
             'rejected_reason', 'last_error', 'submitted_at', 'last_synced_at'];
    $set = [];
    foreach ($cols as $c) {
        if (!array_key_exists($c, $fields)) continue;
        $v = $fields[$c];
        $set[$c] = $v === null ? 'NULL' : "'" . $conn->real_escape_string((string)$v) . "'";
    }
    if (!$set) return;

    $wid = $conn->real_escape_string($wabaId);
    $insCols = array_merge(['template_id', 'waba_id'], array_keys($set));
    $insVals = array_merge([(string)(int)$templateId, "'$wid'"], array_values($set));
    $upd = [];
    foreach ($set as $c => $v) $upd[] = "`$c` = VALUES(`$c`)";

    @$conn->query('INSERT INTO wa_template_wabas (' . implode(',', $insCols) . ')
                   VALUES (' . implode(',', $insVals) . ')
                   ON DUPLICATE KEY UPDATE ' . implode(', ', $upd));
}

/* ════════════════════════════════════════════════════════════════════════════
   The rollup, and the disable decision
   ═══════════════════════════════════════════════════════════════════════════ */

/**
 * Recompute wa_templates' summary columns from its per-WABA rows, and decide whether the
 * template should be selectable.
 *
 * ── The rollup is pessimistic, deliberately ──────────────────────────────────
 * A campaign picks a sending number at send time, and any active number can be chosen. So
 * "is this template usable" has to mean "on every account we might send it from", not "on
 * at least one". The optimistic rollup is the one that produces a template marked APPROVED
 * that fails whenever the newer number is picked — which is precisely the bug this whole
 * change exists to fix.
 *
 * ── The category is the strictest one anybody reported ───────────────────────
 * If one WABA has it as UTILITY and another as MARKETING, it IS a marketing template as far
 * as anyone sending it is concerned: pick the wrong number and you are paying marketing
 * rates and subject to marketing opt-in. Taking the milder of the two answers would be
 * choosing the reading that is cheaper to believe and wrong half the time.
 *
 * @return array the recomputed summary
 */
function wa_template_recompute(int $templateId): array {
    global $conn;
    wa_template_wabas_ensure_schema();

    $r = @$conn->query("SELECT * FROM wa_templates WHERE id = " . (int)$templateId . ' LIMIT 1');
    $t = $r ? $r->fetch_assoc() : null;
    if (!$t) return [];

    /*
     * ONLY ACCOUNTS WE STILL SEND FROM COUNT TOWARDS THE VERDICT.
     *
     * A WABA that has been switched off in settings still has rows here, because switching off a
     * sending number does not delete the templates Meta holds for it. But its answer must stop
     * carrying weight the moment it stops being somewhere we send: the status shown on a card is
     * "can this be sent", and an account nobody sends from cannot make that answer worse. A test
     * account left on the list was enough to hold an otherwise approved template at "pending", and
     * a category it reported was enough to disable one.
     *
     * The rows themselves are kept, and wa_template_waba_rows() still lists them marked inactive,
     * so switching the account back on restores everything it knew.
     */
    $active = [];
    foreach (wa_active_wabas() as $w) $active[(string)$w['waba_id']] = true;

    $rows = [];
    $q = @$conn->query("SELECT * FROM wa_template_wabas WHERE template_id = " . (int)$templateId);
    while ($q && $row = $q->fetch_assoc()) {
        if ($active && !isset($active[(string)$row['waba_id']])) continue;
        $rows[] = $row;
    }

    $requested = strtolower(trim((string)$t['category'])) ?: 'utility';

    // No per-WABA rows at all: an older template from before this table existed, or one that
    // has never been submitted. Its own columns are the only truth there is, so they stand.
    if (!$rows) {
        $status  = (string)$t['approval_status'];
        $metaCat = strtolower(trim((string)($t['meta_category'] ?? ''))) ?: null;
    } else {
        $ranks = ['approved' => 0, 'pending' => 1, 'unknown' => 2, 'not_submitted' => 3, 'rejected' => 4];
        $worst = 'approved'; $worstRank = -1;
        $metaCat = null;
        foreach ($rows as $row) {
            $s = (string)$row['approval_status'];
            $rank = $ranks[$s] ?? 2;
            if ($rank > $worstRank) { $worstRank = $rank; $worst = $s; }

            $c = strtolower(trim((string)($row['meta_category'] ?? '')));
            if ($c === '') continue;
            // MARKETING is the strictest thing Meta can call a template — billed highest,
            // needs marketing opt-in, capped per user. It wins over anything else reported.
            if ($metaCat === null || $c === 'marketing') $metaCat = $c;
        }
        // 'not_submitted' is not an approval state wa_templates.approval_status can hold, and
        // it means the same thing to a sender as 'pending': do not rely on this yet.
        $status = $worst === 'not_submitted' ? 'pending' : $worst;
    }

    /* ── Should this template be selectable? ──────────────────────────────────────
     *
     * Disabling a template stops it being sendable, so it happens ONLY on positive
     * evidence: Meta named a category, that category is one of the three real ones, and it
     * differs from what this template was built as. Anything short of that — no category on
     * record, an empty string, a value nobody recognises — means we do not know, and "we do
     * not know" must never disable anything.
     *
     * That guard is here because its absence was a live incident. A fallback category was
     * being written into meta_category on every sync (see wa_upsert_templates), so every
     * MARKETING and AUTHENTICATION template on the account read as re-filed to UTILITY and
     * the whole library switched itself off at once — with a banner that said "Meta now
     * files this as ?", which is precisely what a disable with no evidence looks like.
     * The fallback is fixed at the source; this makes the rule itself unable to fire on it.
     */
    $known = ['marketing', 'utility', 'authentication'];
    $disabled = 0; $reason = null;

    if ($metaCat !== null && in_array($metaCat, $known, true)
        && in_array($requested, $known, true) && $metaCat !== $requested) {
        $disabled = 1;
        $reason = 'Meta has this template filed as ' . strtoupper($metaCat) . ', not the '
            . strtoupper($requested) . ' it was built as. ' . wa_category_drift_consequence($requested, $metaCat)
            . ' It has been disabled so it cannot be picked in a campaign or a journey until you '
            . 'either change its category here to match, or edit the copy and resubmit it.';
        // Belt and braces on top of the widened column: the wording above is edited from time
        // to time, and a sentence that grows past the column must degrade to a shorter
        // explanation, never to a fatal that hides the entire template library.
        $reason = wa_clip($reason, WA_DISABLED_REASON_MAX);
    }

    /*
     * Self-heal. A template left disabled by the bug above has auto_disabled = 1 and nothing
     * to justify it; recomputing now clears the flag, so simply opening the template list
     * puts the library back rather than needing a hand-written UPDATE. An admin's deliberate
     * "Send anyway" override also lands here with $disabled = 0 and is equally correct to
     * leave cleared — the next sweep re-reads Meta and re-raises it if it is still true.
     */
    $metaId = (string)($t['meta_template_id'] ?? '');
    if ($rows) {
        // The rollup id points at whichever account is the default sender's, so anything still
        // reading the single column keeps talking to the account it was talking to before.
        foreach ($rows as $row) {
            if (trim((string)$row['meta_template_id']) !== '') { $metaId = (string)$row['meta_template_id']; break; }
        }
    }

    $sets = [
        "approval_status = '" . $conn->real_escape_string($status) . "'",
        'auto_disabled = ' . (int)$disabled,
        'disabled_reason = ' . ($reason === null ? 'NULL' : "'" . $conn->real_escape_string($reason) . "'"),
        'meta_category = ' . ($metaCat === null ? 'NULL' : "'" . $conn->real_escape_string($metaCat) . "'"),
        "meta_template_id = " . ($metaId === '' ? 'NULL' : "'" . $conn->real_escape_string($metaId) . "'"),
    ];
    @$conn->query('UPDATE wa_templates SET ' . implode(', ', $sets) . ' WHERE id = ' . (int)$templateId);

    return [
        'approval_status' => $status,
        'auto_disabled'   => $disabled,
        'disabled_reason' => $reason,
        'meta_category'   => $metaCat,
        'category'        => $requested,
    ];
}

/** Why the specific drift matters, in one sentence, rather than a generic warning. */
function wa_category_drift_consequence(string $requested, string $actual): string {
    if ($actual === 'marketing' && $requested === 'utility') {
        return 'Marketing templates cost more per message, need marketing opt-in, and are dropped '
             . 'for users who have hit their marketing frequency cap — so this is now being '
             . 'delivered to fewer people, at a higher price, than the step that uses it assumes.';
    }
    if ($actual === 'marketing' && $requested === 'authentication') {
        return 'An authentication template reclassified as marketing will not reach users who have '
             . 'not opted in to marketing, which for an OTP or a login code means the message '
             . 'simply never arrives.';
    }
    if ($actual === 'utility' && $requested === 'marketing') {
        return 'Utility templates may only be sent in response to a user action; sending this as a '
             . 'broadcast risks the number being rate-limited or flagged.';
    }
    return 'Category decides pricing, opt-in requirements and delivery caps, so the template no '
         . 'longer behaves the way the campaigns using it were built to expect.';
}

/* ════════════════════════════════════════════════════════════════════════════
   The sweep — "check every time you come to the template list"
   ═══════════════════════════════════════════════════════════════════════════ */

/**
 * Re-read categories from Meta and re-apply the disable rule.
 *
 * Two halves, and they are deliberately different in cost:
 *
 *   the cheap half   re-runs wa_template_recompute() over every template using data already
 *                    in the database. Catches anything a sync or a webhook wrote since the
 *                    last look, costs no network at all, and runs on every list request.
 *
 *   the expensive half  asks Meta for the current category of the templates whose answer is
 *                    stale, oldest first, capped per request. This is what actually notices a
 *                    reclassification, since Meta sends no notification for one. Capped
 *                    because 130 templates is 130 Graph calls and the list has to stay fast;
 *                    oldest-first means every template is covered within a few page loads.
 *
 * @return array{checked:int, refreshed:int, disabled:int, errors:string[]}
 */
function wa_template_category_sweep(bool $withNetwork = true): array {
    global $conn;
    wa_template_wabas_ensure_schema();

    $out = ['checked' => 0, 'refreshed' => 0, 'disabled' => 0, 'errors' => []];

    /* ── the cheap half ── */
    $ids = [];
    $r = @$conn->query("SELECT id FROM wa_templates WHERE status = 'active'");
    while ($r && $row = $r->fetch_assoc()) $ids[] = (int)$row['id'];
    foreach ($ids as $id) {
        /*
         * The sweep is a side-effect of opening the template list, never the point of it. One
         * template that cannot be recomputed — a value a column will not hold, a row another
         * request has locked — must cost that template its refresh and nothing else; before
         * this, it threw out of the sweep, out of wa_templates.php and replaced the whole list
         * with a fatal error page, so a single bad row hid all 130 templates.
         */
        try {
            $res = wa_template_recompute($id);
        } catch (Throwable $e) {
            $out['errors'][] = 'template ' . $id . ': ' . $e->getMessage();
            continue;
        }
        $out['checked']++;
        if (!empty($res['auto_disabled'])) $out['disabled']++;
    }

    if (!$withNetwork) return $out;

    $token = wa_meta_token();
    if ($token === '') {
        // Not an error worth surfacing on every page load — a panel with no Meta token simply
        // cannot do the network half, and the settings screen already says so.
        return $out;
    }

    /* ── the expensive half ── */
    $stale = [];
    $q = @$conn->query("SELECT tw.id, tw.template_id, tw.waba_id, tw.meta_template_id, t.category
                          FROM wa_template_wabas tw
                          INNER JOIN wa_templates t ON t.id = tw.template_id
                         WHERE t.status = 'active'
                           AND tw.meta_template_id IS NOT NULL AND tw.meta_template_id <> ''
                           AND (tw.last_synced_at IS NULL
                                OR tw.last_synced_at < DATE_SUB(NOW(), INTERVAL " . WA_CATEGORY_TTL_MINUTES . " MINUTE))
                         ORDER BY tw.last_synced_at IS NULL DESC, tw.last_synced_at ASC
                         LIMIT " . WA_CATEGORY_SWEEP_LIMIT);
    while ($q && $row = $q->fetch_assoc()) $stale[] = $row;

    $touched = [];
    foreach ($stale as $row) {
        $url = WA_GRAPH_BASE . WA_GRAPH_VERSION . '/' . rawurlencode((string)$row['meta_template_id'])
             . '?fields=status,category,rejected_reason';
        $res = wa_graph_call('GET', $url, $token);

        if (!$res['ok']) {
            /*
             * The stamp is written even on failure, so one unreachable template cannot pin the
             * sweep to itself forever and starve every other template of its turn.
             */
            wa_template_waba_upsert((int)$row['template_id'], (string)$row['waba_id'], [
                'last_error'     => mb_substr((string)$res['error'], 0, 490),
                'last_synced_at' => date('Y-m-d H:i:s'),
            ]);
            $out['errors'][] = $res['error'];
            $touched[(int)$row['template_id']] = true;
            continue;
        }

        $status = strtolower((string)($res['data']['status'] ?? 'unknown'));
        $status = in_array($status, ['approved', 'pending', 'rejected'], true) ? $status : 'unknown';
        $cat    = strtolower(trim((string)($res['data']['category'] ?? '')));
        $reason = (string)($res['data']['rejected_reason'] ?? '');
        if (strtoupper($reason) === 'NONE') $reason = '';

        wa_template_waba_upsert((int)$row['template_id'], (string)$row['waba_id'], [
            'approval_status' => $status,
            'meta_category'   => $cat !== '' ? $cat : null,
            // Meta's rejected_reason is normally a short enum, but it is their field and the
            // column is VARCHAR(120) — clipped rather than trusted, for the same reason
            // disabled_reason is: over-long is a fatal here, not a truncation.
            'rejected_reason' => $reason !== '' ? wa_clip($reason, 120) : null,
            'last_error'      => null,
            'last_synced_at'  => date('Y-m-d H:i:s'),
        ]);
        $out['refreshed']++;
        $touched[(int)$row['template_id']] = true;
    }

    foreach (array_keys($touched) as $tid) {
        try {
            $res = wa_template_recompute($tid);
        } catch (Throwable $e) {
            $out['errors'][] = 'template ' . $tid . ': ' . $e->getMessage();
            continue;
        }
        @$conn->query("UPDATE wa_templates SET category_checked_at = NOW() WHERE id = " . (int)$tid);
        if (!empty($res['auto_disabled'])) $out['disabled']++;
    }

    return $out;
}

/**
 * Backfill: give an existing single-WABA template its per-WABA row so it appears correctly
 * the first time this screen is opened after the upgrade, instead of reading as
 * "never submitted anywhere".
 *
 * Attributed to the DEFAULT sender's WABA, which is where a template approved before there
 * was more than one account can only have come from.
 */
function wa_template_wabas_backfill(): void {
    global $conn;
    wa_template_wabas_ensure_schema();

    static $done = false;
    if ($done) return;
    $done = true;

    $default = wa_default_sender();
    $wabaId  = trim((string)($default['waba_id'] ?? ''));
    if ($wabaId === '') return;

    $q = @$conn->query("SELECT t.id, t.meta_template_id, t.approval_status, t.category
                          FROM wa_templates t
                          LEFT JOIN wa_template_wabas tw ON tw.template_id = t.id
                         WHERE tw.id IS NULL
                           AND t.meta_template_id IS NOT NULL AND t.meta_template_id <> ''
                         LIMIT 500");
    $rows = [];
    while ($q && $row = $q->fetch_assoc()) $rows[] = $row;

    foreach ($rows as $row) {
        wa_template_waba_upsert((int)$row['id'], $wabaId, [
            'waba_name'        => (string)($default['waba_name'] ?? ''),
            'meta_template_id' => (string)$row['meta_template_id'],
            'approval_status'  => (string)$row['approval_status'],
            // Category is left NULL rather than copied from `category`: copying it would assert
            // that Meta agrees with us, which is the exact question this feature exists to ask.
            // The first sweep fills it in from Meta.
            'meta_category'    => null,
        ]);
    }
}

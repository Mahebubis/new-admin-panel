<?php
/*
 * /api/freshdesk/fd_notifications.php
 *
 * One agent's notifications.
 *
 * WHAT THIS IS NOT: the activity feed. That is the desk's history, the same
 * for everyone, and it is what the bell used to show -- which is why it was
 * full of "291 tickets breached their SLA" repeated every minute. Nothing in
 * it was addressed to the person reading it.
 *
 * A row here exists because something was directed AT one person: a ticket
 * assigned to them, a mail forwarded to their address, a note that mentions
 * them. Every query below is scoped to the signed-in user's own id. There is
 * deliberately no way to ask for somebody else's.
 */

require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../middleware/auth.php';
require_once __DIR__ . '/lib/config.php';
require_once __DIR__ . '/lib/Helpers.php';
require_once __DIR__ . '/lib/schema.php';

$jwt = require_jwt();
require_permission('freshdesk', $jwt);
fd_install_error_handlers();
fd_ensure_schema();

$ME = isset($jwt['user_id']) ? (int)$jwt['user_id'] : 0;
if ($ME <= 0) api_error('Not signed in', 401);

$action = fd_str('action', 'list');
$GLOBALS['FD_ACTION'] = $action;

/* ------------------------------------------------------------------ list -- */
if ($action === 'list') {
    $limit  = max(1, min(100, fd_int('limit', 30)));
    $filter = fd_str('filter', 'all') === 'unread' ? 'unread' : 'all';

    $rows = $filter === 'unread'
        ? fd_query("SELECT n.id, n.kind, n.ticket_id, n.title, n.body, n.actor_name,
                           n.is_read, n.read_at, n.created_at, t.subject
                    FROM fd_notifications n
                    LEFT JOIN fd_tickets t ON t.id = n.ticket_id
                    WHERE n.user_id = ? AND n.is_read = 0
                    ORDER BY n.id DESC LIMIT $limit", 'i', array($ME))
        : fd_query("SELECT n.id, n.kind, n.ticket_id, n.title, n.body, n.actor_name,
                           n.is_read, n.read_at, n.created_at, t.subject
                    FROM fd_notifications n
                    LEFT JOIN fd_tickets t ON t.id = n.ticket_id
                    WHERE n.user_id = ?
                    ORDER BY n.id DESC LIMIT $limit", 'i', array($ME));
    foreach ($rows as &$r) {
        $r['id']        = (int)$r['id'];
        $r['ticket_id'] = $r['ticket_id'] !== null ? (int)$r['ticket_id'] : null;
        $r['is_read']   = (int)$r['is_read'] === 1;
        $r['ago']       = fd_relative_time($r['created_at']);
        $r['dt']        = date('j M Y, h:i a', strtotime($r['created_at']));
    }
    unset($r);

    $u = fd_query_one("SELECT COUNT(*) AS n FROM fd_notifications WHERE user_id = ? AND is_read = 0",
                      'i', array($ME));
    $a = fd_query_one("SELECT COUNT(*) AS n FROM fd_notifications WHERE user_id = ?",
                      'i', array($ME));

    api_success(array(
        'notifications' => $rows,
        'unread' => $u ? (int)$u['n'] : 0,
        'total'  => $a ? (int)$a['n'] : 0,
    ), 'OK');
}

/* ----------------------------------------------------------------- count -- */
/* Cheap enough for the bell to poll: one indexed COUNT on (user_id, is_read). */
if ($action === 'count') {
    $u = fd_query_one("SELECT COUNT(*) AS n FROM fd_notifications WHERE user_id = ? AND is_read = 0",
                      'i', array($ME));
    api_success(array('unread' => $u ? (int)$u['n'] : 0), 'OK');
}

/* ------------------------------------------------------------------ read -- */
/*
 * Mark one, several, or everything. The user_id in the WHERE clause is what
 * stops one agent marking another's notifications read -- an id from the
 * request is never trusted on its own.
 */
if ($action === 'read') {
    $ids = fd_arr('ids', array());
    $all = fd_bool('all', false);

    if ($all) {
        fd_exec("UPDATE fd_notifications SET is_read = 1, read_at = NOW()
                 WHERE user_id = ? AND is_read = 0", 'i', array($ME));
    } else {
        $clean = array();
        foreach ($ids as $id) { $id = (int)$id; if ($id > 0) $clean[] = $id; }
        if (empty($clean)) api_error('Nothing to mark', 400);

        $place = implode(',', array_fill(0, count($clean), '?'));
        $types = 'i' . str_repeat('i', count($clean));
        fd_exec("UPDATE fd_notifications SET is_read = 1, read_at = NOW()
                 WHERE user_id = ? AND id IN ($place)",
                $types, array_merge(array($ME), $clean));
    }

    $u = fd_query_one("SELECT COUNT(*) AS n FROM fd_notifications WHERE user_id = ? AND is_read = 0",
                      'i', array($ME));
    api_success(array('unread' => $u ? (int)$u['n'] : 0), 'Marked read');
}

/* ---------------------------------------------------------------- unread -- */
/* The other direction, so a notification can be put back for later. */
if ($action === 'unread') {
    $id = fd_int('id', 0);
    if ($id <= 0) api_error('id is required', 400);
    fd_exec("UPDATE fd_notifications SET is_read = 0, read_at = NULL
             WHERE user_id = ? AND id = ?", 'ii', array($ME, $id));
    api_success(array('id' => $id), 'Marked unread');
}

/* ----------------------------------------------------------------- clear -- */
if ($action === 'clear') {
    fd_exec("DELETE FROM fd_notifications WHERE user_id = ?", 'i', array($ME));
    api_success(array('cleared' => true), 'Notifications cleared');
}

api_error('Unknown action: ' . $action, 400);

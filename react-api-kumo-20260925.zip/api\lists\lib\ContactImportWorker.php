<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/CsvMapper.php';
require_once __DIR__ . '/../../lib/S3Uploader.php';
require_once __DIR__ . '/../../attributes/lib/schema.php';
require_once __DIR__ . '/schema.php';
require_once __DIR__ . '/../../campaigns/lib/EspSuppressionSync.php';
/*
 * The Contact-activity trigger's "an attribute was updated" ledger. Required here because
 * this worker is one of only two places on the platform that CHANGES a contact attribute's
 * value, and a change nobody recorded is a change no journey can ever react to. Everything
 * in that file is guarded, so an import can never fail because of it.
 */
require_once __DIR__ . '/../../journeys/lib/ContactActivity.php';

/** Same log-to-a-file-so-it's-debuggable-without-DB-access pattern as campaigns/lib/SendWorker.php's campaign_log(). */
function contact_import_log(string $msg): void {
    $line = '[' . date('Y-m-d H:i:s') . '] ' . $msg . "\n";
    @file_put_contents(CONTACT_IMPORT_LOG_PATH, $line, FILE_APPEND | LOCK_EX);
}

/**
 * Forces one string to valid UTF-8.
 *
 * Everything downstream — campaign_contacts, campaign_contact_upload_errors, json_encode —
 * is utf8mb4, and MySQL rejects a string containing bytes that aren't valid UTF-8 outright
 * ("Incorrect string value"). A CSV saved from Excel is routinely Windows-1252, not UTF-8, so
 * a single row with an accented character in it was enough: the contact's own upsert was
 * rejected, and then the INSERT recording that failure was rejected for carrying the same
 * bytes. That is the failed_count-says-3-but-the-report-is-empty case — the row failed and the
 * explanation of why it failed could not be stored either.
 *
 * Windows-1252 is assumed for non-UTF-8 input because it is what Excel writes and is a
 * superset of Latin-1 over the printable range; the handful of undefined code points come back
 * substituted rather than failing. Text that is already valid UTF-8 is returned untouched, so
 * this costs one validity check per cell and changes nothing for well-formed files.
 */
function contact_import_to_utf8(string $s): string {
    if ($s === '') return $s;
    $isUtf8 = function_exists('mb_check_encoding')
        ? mb_check_encoding($s, 'UTF-8')
        : (bool)preg_match('//u', $s);
    if ($isUtf8) return $s;

    if (function_exists('mb_convert_encoding')) {
        $c = @mb_convert_encoding($s, 'UTF-8', 'Windows-1252');
    } elseif (function_exists('iconv')) {
        $c = @iconv('Windows-1252', 'UTF-8//IGNORE', $s);
    } else {
        $c = false;
    }
    // Last resort with neither extension present: drop the bytes that can't be stored, so the
    // row still imports with the rest of its text rather than being lost entirely.
    if (!is_string($c) || $c === '') $c = preg_replace('/[\x80-\xFF]/', '', $s);
    return is_string($c) ? $c : '';
}

/**
 * Byte-length clip that can't leave a half-written character behind.
 *
 * Plain substr() counts bytes, so cutting valid UTF-8 at an arbitrary byte can split a
 * multi-byte character and produce exactly the malformed string that MySQL refuses — turning a
 * length guard into the very failure it was added to prevent. mb_strcut() clips on a character
 * boundary within a byte budget; without mbstring the trailing partial sequence is stripped.
 */
function contact_import_clip(string $s, int $maxBytes): string {
    if (strlen($s) <= $maxBytes) return $s;
    if (function_exists('mb_strcut')) return mb_strcut($s, 0, $maxBytes, 'UTF-8');
    $cut = substr($s, 0, $maxBytes);
    while ($cut !== '' && !preg_match('//u', $cut)) $cut = substr($cut, 0, -1);
    return $cut;
}

/**
 * Rows per second for the log line.
 *
 * Throughput is the whole point of the batched write path, and "it feels faster" is not
 * something anyone can act on. Logging the rate means a future slowdown can be attributed to a
 * change rather than guessed at, and it answers "how long will 50,000 rows take" from this
 * server's own numbers instead of from an estimate.
 */
function contact_import_rate(int $rows, float $startedAt): string {
    $elapsed = microtime(true) - $startedAt;
    if ($rows <= 0 || $elapsed <= 0) return 'n/a';
    return round($rows / $elapsed) . ' rows/sec';
}

/** contact_import_to_utf8() across one fgetcsv() row. */
function contact_import_row_to_utf8(array $row): array {
    foreach ($row as $i => $cell) {
        if (is_string($cell) && $cell !== '') $row[$i] = contact_import_to_utf8($cell);
    }
    return $row;
}

/**
 * Records one unimportable row in campaign_contact_upload_errors, and CANNOT itself
 * end the import.
 *
 * Both halves of that matter, and both were previously missing:
 *
 *  1. raw_row is built without array_combine(). The old call was
 *     array_combine(array_slice($headers, 0, count($row)), $row), which is only balanced
 *     while a row has no MORE cells than the file has headers. One row with an extra
 *     delimiter — a stray comma in a single-column EMAIL export is enough — makes the keys
 *     array shorter than the values array, and in PHP 8 array_combine() THROWS ValueError
 *     rather than returning false. Nothing caught it, so the whole worker process died on
 *     that row.
 *  2. The column is JSON, so it must receive valid JSON or MySQL rejects the INSERT
 *     (error 3140) — and that rejection is a mysqli_sql_exception, equally fatal. A row
 *     carrying bytes that aren't valid UTF-8 (an Excel-exported Latin-1 CSV) made
 *     json_encode() return false, which was escaped into an empty string and sent anyway.
 *     JSON_INVALID_UTF8_SUBSTITUTE keeps those rows encodable, and a still-unencodable
 *     value is written as SQL NULL instead of as broken JSON.
 *
 * Extra cells beyond the header count are kept under a synthetic "column_N" key rather than
 * dropped, since the point of raw_row is to show the operator the row that failed.
 *
 * Returns false if even the error row could not be written (the caller uses that to notice a
 * dead connection instead of spinning on it).
 */
function contact_import_record_row_error(int $uploadId, int $rowNumber, ?string $email, string $message, ?array $rawRow = null, array $headers = []): bool {
    global $conn;
    try {
        // Both columns are narrower than what can arrive here (VARCHAR(255)/VARCHAR(500)) and
        // both are utf8mb4. An address longer than the column, or one carrying non-UTF-8 bytes,
        // made this very INSERT fail — which is how failed_count could count a row that the
        // downloadable failure report then had nothing to say about. Trim and transcode first so
        // the report always accounts for every row the counter counted.
        $emailE = $conn->real_escape_string(contact_import_clip(contact_import_to_utf8((string)$email), 255));
        $errMsg = $conn->real_escape_string(contact_import_clip(contact_import_to_utf8($message), 480));

        $rawSql = 'NULL';
        if ($rawRow !== null) {
            $pairs = [];
            foreach (array_values($rawRow) as $i => $cell) {
                $key = (isset($headers[$i]) && $headers[$i] !== '') ? (string)$headers[$i] : 'column_' . ($i + 1);
                $pairs[$key] = is_scalar($cell) ? (string)$cell : '';
            }
            $json = json_encode($pairs, JSON_INVALID_UTF8_SUBSTITUTE | JSON_UNESCAPED_UNICODE);
            if (is_string($json)) $rawSql = "'" . $conn->real_escape_string($json) . "'";
        }

        $conn->query("INSERT INTO campaign_contact_upload_errors (upload_id, `row_number`, email, error_message, raw_row)
                      VALUES ($uploadId, $rowNumber, '$emailE', '$errMsg', $rawSql)");
        return true;
    } catch (\Throwable $e) {
        /*
         * A row the counter counted must never be missing from the report.
         *
         * If the detailed insert is still refused — an unforeseen encoding or width problem in
         * the row's own text — fall back to a row that contains no CSV-derived text at all, only
         * the row number and a fixed message. The operator then at least learns WHICH row failed
         * and can look it up in their file, instead of downloading a report with nothing in it
         * while the UI says three rows failed.
         */
        contact_import_log("upload #$uploadId: could not record full error for row $rowNumber — " . $e->getMessage());
        try {
            $safe = $conn->real_escape_string('Row could not be imported, and its text could not be stored '
                . '(unsupported characters or over-long value). Check this row in your source file.');
            $conn->query("INSERT INTO campaign_contact_upload_errors (upload_id, `row_number`, email, error_message, raw_row)
                          VALUES ($uploadId, $rowNumber, NULL, '$safe', NULL)");
            return true;
        } catch (\Throwable $e2) {
            contact_import_log("upload #$uploadId: could not record ANY error for row $rowNumber — " . $e2->getMessage());
            return false;
        }
    }
}

/**
 * Non-blocking "fire and forget" kick so Confirm & Import doesn't wait for the
 * next cron minute — mirrors campaigns/lib/SendWorker.php's trigger_worker_async()
 * exactly, just pointed at this feature's own worker entrypoint/secret-less path
 * (same CRON_SECRET, reused rather than minting a second one).
 */
function contact_import_trigger_worker_async(?int $uploadId = null) {
    $host = 'cit3.internshipstudio.com';
    $path = '/admin/react-api/api/lists/contact-import-worker.php?cron_secret=' . urlencode(CRON_SECRET)
          . ($uploadId !== null ? '&upload_id=' . $uploadId : '');
    $fp = @fsockopen('ssl://' . $host, 443, $errno, $errstr, 1);
    if (!$fp) return;
    stream_set_timeout($fp, 1);
    fwrite($fp, "GET $path HTTP/1.1\r\nHost: $host\r\nConnection: Close\r\n\r\n");
    fclose($fp);
}

/**
 * Upserts one contact by email (INSERT...ON DUPLICATE KEY UPDATE against the
 * uq_email unique index), links it into the target list, and returns the
 * contact's id. JSON_MERGE_PATCH on extra_attributes means a later import
 * that only supplies some custom columns won't wipe out custom fields an
 * earlier import wrote — keys merge instead of the whole blob being replaced.
 */
function contact_upsert(array $data, int $listId, ?string $reason = null): int {
    global $conn;
    $email = $conn->real_escape_string($data['email']);
    $fname = $conn->real_escape_string((string)($data['first_name'] ?? ''));
    $lname = $conn->real_escape_string((string)($data['last_name'] ?? ''));
    $phone = $conn->real_escape_string((string)($data['phone'] ?? ''));
    $state = $conn->real_escape_string((string)($data['state'] ?? ''));
    $country = $conn->real_escape_string((string)($data['country'] ?? ''));
    $city  = $conn->real_escape_string((string)($data['city'] ?? ''));
    $extra = $conn->real_escape_string(json_encode($data['extra_attributes'] ?? new stdClass()));

    $conn->query("INSERT INTO campaign_contacts (email, first_name, last_name, phone, state, country, city, extra_attributes)
                  VALUES ('$email', " . ($fname !== '' ? "'$fname'" : 'NULL') . ", " . ($lname !== '' ? "'$lname'" : 'NULL') . ",
                          " . ($phone !== '' ? "'$phone'" : 'NULL') . ", " . ($state !== '' ? "'$state'" : 'NULL') . ",
                          " . ($country !== '' ? "'$country'" : 'NULL') . ", " . ($city !== '' ? "'$city'" : 'NULL') . ", '$extra')
                  ON DUPLICATE KEY UPDATE
                      id = LAST_INSERT_ID(id),
                      first_name = COALESCE(VALUES(first_name), first_name),
                      last_name  = COALESCE(VALUES(last_name), last_name),
                      phone      = COALESCE(VALUES(phone), phone),
                      state      = COALESCE(VALUES(state), state),
                      country    = COALESCE(VALUES(country), country),
                      city       = COALESCE(VALUES(city), city),
                      extra_attributes = JSON_MERGE_PATCH(COALESCE(extra_attributes, '{}'), VALUES(extra_attributes))");
    $contactId = $conn->insert_id;
    $wasAlreadyInThisList = false;
    $chk = $conn->query("SELECT 1 FROM campaign_list_members WHERE list_id=$listId AND contact_id=$contactId");
    if ($chk && $chk->num_rows > 0) $wasAlreadyInThisList = true;
    if ($reason !== null && $reason !== '') {
        $reasonE = $conn->real_escape_string($reason);
        $conn->query("INSERT INTO campaign_list_members (list_id, contact_id, reason) VALUES ($listId, $contactId, '$reasonE')
                      ON DUPLICATE KEY UPDATE reason = VALUES(reason)");
    } else {
        $conn->query("INSERT IGNORE INTO campaign_list_members (list_id, contact_id) VALUES ($listId, $contactId)");
    }

    // Every path that adds someone to the Blocklist specifically (CSV import, the single-
    // contact "Add" action, or an auto-added hard bounce/unsubscribe — see
    // sendgrid-webhook.php / elasticemail-webhook.php) funnels through here, so this is the
    // one place that needs to also tell the ESPs themselves to suppress the address —
    // otherwise our own AudienceResolver exclusion would be the only thing stopping a send,
    // and the provider would still be willing to accept it. Fans out to every configured
    // provider, not just the active one (see EspSuppressionSync.php for why).
    // Skipped if they were already in the blocklist (no new suppression needed).
    // The blocklist's id is resolved once per process, not once per contact: it is a
    // SELECT (plus a possible CREATE) that returns the same id for every row of the file,
    // and it sat on the hot path of every single upsert.
    static $blocklistId = null;
    if ($blocklistId === null) $blocklistId = lists_get_or_create_blocklist_id();

    if (!$wasAlreadyInThisList && $listId === $blocklistId) {
        esp_add_global_suppression($data['email']);
    }

    if (!empty($data['extra_attributes'])) {
        fan_out_extra_attributes($data['email'], $data['extra_attributes']);
    }

    return $contactId;
}

/**
 * The batched form of contact_upsert(): identical semantics for a whole chunk of rows, in a
 * fixed handful of statements instead of three per contact.
 *
 * Round trips, not the writes themselves, are what made a large import slow. Per row this
 * feature was issuing an INSERT..ON DUPLICATE KEY UPDATE, a SELECT to ask whether the contact
 * was already on the list, and an INSERT for the membership — so 50,000 rows meant 150,000
 * separate statements, each paying the client/server round trip in full. Folded into multi-row
 * statements the same 50,000 rows cost roughly 4 statements per 500 contacts. The database
 * does the same amount of indexed work either way; what disappears is the waiting.
 *
 * The membership SELECT disappears outright for an ordinary list: its only purpose was
 * deciding whether a NEW blocklist entry needs pushing to the ESPs, so it is now asked once
 * per batch and only when the target list actually is the blocklist.
 *
 * Any failure here is left to the caller, which replays the batch one row at a time so a
 * single unusable row costs only itself — see contact_import_flush_buffer(). That fallback is
 * also what makes an over-large batch safe: if the statement ever exceeded max_allowed_packet
 * the batch would simply be re-run row by row, slower but correct.
 */
/**
 * @param bool $syncSuppression push newly blocklisted addresses to every ESP's own suppression
 *        list. True for the paths where an address earned its place by BOUNCING or COMPLAINING —
 *        there the provider genuinely needs telling. False for bulk administrative blocks, which
 *        is not miserliness: it is three outbound HTTP calls per address, so a verification pass
 *        over a large audience turns into thousands of sequential requests in the middle of a
 *        send worker. Those addresses are already refused before the send, and a provider's
 *        suppression list is a record of delivery failures, not a dumping ground for addresses
 *        nobody ever tried to reach.
 */
function contact_upsert_many(array $rows, int $listId, bool $syncSuppression = true): void {
    global $conn;
    if (!$rows) return;

    /*
     * One tuple per address, last occurrence winning — which is what writing the rows in
     * sequence did. Keyed lower-case because uq_email's collation is case-insensitive: two
     * spellings of one address are a single contact to MySQL, so listing both in the same
     * multi-row INSERT would just do the same work twice.
     */
    $byEmail = [];
    foreach ($rows as $d) {
        $e = trim((string)($d['email'] ?? ''));
        if ($e === '') continue;
        $byEmail[strtolower($e)] = $d;
    }
    if (!$byEmail) return;

    $lit = function ($v) use ($conn) {
        $v = trim((string)($v ?? ''));
        return $v === '' ? 'NULL' : "'" . $conn->real_escape_string($v) . "'";
    };

    $tuples = [];
    foreach ($byEmail as $d) {
        /*
         * (object), not the bare array: json_encode([]) is "[]", and JSON_MERGE_PATCH against a
         * non-object REPLACES its target instead of merging into it. Encoding an empty extras
         * array as "[]" would therefore wipe the custom attributes an earlier import had stored
         * for that contact — the opposite of what the merge is there to guarantee.
         */
        $extra = json_encode((object)($d['extra_attributes'] ?? []), JSON_INVALID_UTF8_SUBSTITUTE);
        if (!is_string($extra)) $extra = '{}';
        $tuples[] = '(' . $lit($d['email'])
            . ',' . $lit($d['first_name'] ?? null)
            . ',' . $lit($d['last_name'] ?? null)
            . ',' . $lit($d['phone'] ?? null)
            . ',' . $lit($d['state'] ?? null)
            . ',' . $lit($d['country'] ?? null)
            . ',' . $lit($d['city'] ?? null)
            . ",'" . $conn->real_escape_string($extra) . "')";
    }

    $conn->query("INSERT INTO campaign_contacts
                      (email, first_name, last_name, phone, state, country, city, extra_attributes)
                  VALUES " . implode(',', $tuples) . "
                  ON DUPLICATE KEY UPDATE
                      first_name = COALESCE(VALUES(first_name), first_name),
                      last_name  = COALESCE(VALUES(last_name),  last_name),
                      phone      = COALESCE(VALUES(phone),      phone),
                      state      = COALESCE(VALUES(state),      state),
                      country    = COALESCE(VALUES(country),    country),
                      city       = COALESCE(VALUES(city),       city),
                      extra_attributes = JSON_MERGE_PATCH(COALESCE(extra_attributes, '{}'), VALUES(extra_attributes))");

    // One lookup for the batch, replacing the single-row form's LAST_INSERT_ID(id) trick —
    // that can only ever report one row's id per statement.
    $inList = [];
    foreach ($byEmail as $d) $inList[] = "'" . $conn->real_escape_string(trim((string)$d['email'])) . "'";
    $idByEmail = [];
    $res = $conn->query("SELECT id, email FROM campaign_contacts WHERE email IN (" . implode(',', $inList) . ")");
    while ($res && $r = $res->fetch_assoc()) $idByEmail[strtolower($r['email'])] = (int)$r['id'];
    if (!$idByEmail) return;

    static $blocklistId = null;
    if ($blocklistId === null) $blocklistId = lists_get_or_create_blocklist_id();

    $newlyBlocked = [];
    if ($listId === $blocklistId) {
        $already = [];
        $idsSql = implode(',', array_map('intval', array_values($idByEmail)));
        $r2 = $conn->query("SELECT contact_id FROM campaign_list_members WHERE list_id=$listId AND contact_id IN ($idsSql)");
        while ($r2 && $m = $r2->fetch_assoc()) $already[(int)$m['contact_id']] = true;
        foreach ($idByEmail as $lc => $cid) {
            if (!isset($already[$cid]) && isset($byEmail[$lc])) $newlyBlocked[] = $byEmail[$lc]['email'];
        }
    }

    $members = [];
    /*
     * The per-row reason travels with the batch when one was given.
     *
     * Without it a bulk block writes rows that say nothing about why they are there, which on the
     * Blocklist is the difference between "Verification: Invalid, Invalid domain - no Mx record"
     * and an address somebody later un-blocks because nobody could say what it did wrong. The
     * single-row contact_upsert() has always stored it; this is the same write, batched.
     *
     * ON DUPLICATE KEY UPDATE rather than INSERT IGNORE once a reason is present, so re-running a
     * block refreshes the explanation instead of leaving the first one in place for ever.
     */
    $anyReason = false;
    foreach ($idByEmail as $lc => $cid) {
        $why = trim((string)($byEmail[$lc]['reason'] ?? ''));
        if ($why !== '') $anyReason = true;
        $members[] = "($listId,$cid," . ($why === '' ? 'NULL' : "'" . $conn->real_escape_string($why) . "'") . ')';
    }
    $conn->query('INSERT INTO campaign_list_members (list_id, contact_id, reason) VALUES ' . implode(',', $members)
        . ($anyReason
            ? ' ON DUPLICATE KEY UPDATE reason = COALESCE(VALUES(reason), reason)'
            : ' ON DUPLICATE KEY UPDATE contact_id = contact_id'));

    $extras = [];
    foreach ($byEmail as $d) {
        if (!empty($d['extra_attributes'])) $extras[trim((string)$d['email'])] = $d['extra_attributes'];
    }
    if ($extras) fan_out_extra_attributes_many($extras);

    // Last, and outside the batch's own statements: each of these is an outbound HTTP call to
    // a provider, and has no business sitting between two writes.
    if ($syncSuppression) foreach ($newlyBlocked as $e) esp_add_global_suppression($e);
}

/**
 * fan_out_extra_attributes() for a whole batch.
 *
 * Custom attributes all live in one wide table keyed by email, which is exactly the shape that
 * batches well: every custom column touched anywhere in the batch becomes one multi-row
 * INSERT .. ON DUPLICATE KEY UPDATE, instead of one statement per attribute per contact.
 *
 * A contact that had no value for one of the columns in the batch sends NULL for it, and the
 * update clause is COALESCE(VALUES(col), col) rather than a plain assignment — otherwise
 * batching would introduce a data-loss bug the row-at-a-time version could not have: one
 * contact lacking a column would blank that column for itself, because the statement has to
 * name every column any member of the batch uses.
 *
 * Mapped ('system') attributes stay one statement per value. They write into arbitrary source
 * tables keyed their own way, so there is no shared destination to batch into; they are also
 * rare compared with custom columns.
 */
function fan_out_extra_attributes_many(array $extrasByEmail): void {
    global $conn;
    static $attrDefs = [];   // same per-process definition cache as the single-row path

    $columns = [];     // physical column name => true
    $values  = [];     // email => [column => value]
    $ledger  = [];     // [email, ATTRIBUTE, value] for the journey trigger ledger

    foreach ($extrasByEmail as $email => $extras) {
        foreach ((array)$extras as $header => $value) {
            $value = trim((string)$value);
            if ($value === '') continue;

            $name = normalize_attribute_name((string)$header);
            if ($name === '') continue;

            if (!array_key_exists($name, $attrDefs)) {
                $nameE = $conn->real_escape_string($name);
                $r = $conn->query("SELECT id, category, mapped_db, mapped_table, mapped_column, mapped_join_col
                                    FROM campaign_attributes WHERE name='$nameE' LIMIT 1");
                $attrDefs[$name] = $r ? $r->fetch_assoc() : null;
            }
            $attr = $attrDefs[$name];

            if ($attr && $attr['category'] === 'system') {
                write_mapped_attribute_value($attr, (string)$email, $value);
                $ledger[] = [(string)$email, $name, $value];
                continue;
            }

            /*
             * A 'linked' attribute is COMPUTED at send time by walking its own chain of lookups
             * (attributes/lib/schema.php's attr_chain_normalize(), read back by
             * campaigns/lib/AttributeResolver.php), so there is no single place a CSV column
             * could write it back to. Skipped rather than stored in campaign_attribute_data,
             * where nothing would ever read it — and skipped BEFORE $columns[$col] is set, so a
             * CSV that happens to carry a linked attribute's name doesn't widen the batch's
             * INSERT with a column no reader uses.
             */
            if ($attr && $attr['category'] === 'linked') continue;

            if (!$attr) {
                $nameE = $conn->real_escape_string($name);
                $conn->query("INSERT INTO campaign_attributes (name, category) VALUES ('$nameE', 'custom')");
                $attributeId = $conn->insert_id;
                attribute_log($attributeId, $name, 'Auto-created from CSV import', null);
                // Cache the definition just created, never the miss — see the single-row
                // version's note: a cached miss would re-insert the attribute for every row.
                $attr = ['id' => $attributeId, 'category' => 'custom', 'mapped_db' => null,
                         'mapped_table' => null, 'mapped_column' => null, 'mapped_join_col' => null];
                $attrDefs[$name] = $attr;
            }

            attribute_data_ensure_column($name);
            $col = attribute_column_name($name);
            $columns[$col] = true;
            $values[(string)$email][$col] = $value;
            $ledger[] = [(string)$email, $name, $value];
        }
    }

    if ($values) {
        $cols = array_keys($columns);
        $tuples = [];
        foreach ($values as $email => $vals) {
            $cells = ["'" . $conn->real_escape_string((string)$email) . "'"];
            foreach ($cols as $c) {
                $cells[] = isset($vals[$c]) ? "'" . $conn->real_escape_string($vals[$c]) . "'" : 'NULL';
            }
            $tuples[] = '(' . implode(',', $cells) . ')';
        }
        $updates = [];
        foreach ($cols as $c) $updates[] = "`$c` = COALESCE(VALUES(`$c`), `$c`)";

        $conn->query("INSERT INTO campaign_attribute_data (email, `" . implode('`,`', $cols) . "`)
                      VALUES " . implode(',', $tuples) . "
                      ON DUPLICATE KEY UPDATE " . implode(',', $updates));
    }

    if ($ledger) journey_contact_log_updates_many($ledger);
}

/**
 * Every CSV column that isn't a canonical contact field (email/first_name/.../city)
 * ends up here, keyed by its original header text (e.g. "COLLEGE" => "MIT"). For each,
 * normalize the header into an attribute name (same rule attributes.php's manual create
 * uses, so "College" and "COLLEGE" resolve to the same attribute), then one of four things:
 *   1. An attribute with that name already exists and is MAPPED ('system') to a real
 *      table — write straight into that live table/column, matched back to this email
 *      (see write_mapped_attribute_value()). Confirmed, deliberate behavior: this CAN
 *      overwrite real system-of-record data (e.g. users.fname), not just campaign
 *      personalization data — a stale/wrong CSV column can silently change live records.
 *   2. An attribute with that name already exists and is a LOOKUP CHAIN ('linked') —
 *      skipped entirely. Its value is computed from other tables every time it is sent, so
 *      an imported value would have nowhere to live and nothing to read it.
 *   3. An attribute with that name already exists and is unmapped ('custom') — store the
 *      value in its own column in campaign_attribute_data, keyed by email.
 *   4. No attribute with that name exists yet — auto-create one ('custom'), add its
 *      column to campaign_attribute_data, then store the value there.
 * This is what makes an uploaded CSV column immediately usable as XX_COLLEGE_XX in a
 * campaign template with zero manual setup — see AttributeResolver.php for the read side.
 */
function fan_out_extra_attributes(string $email, array $extraAttributes): void {
    global $conn;
    $emailE = $conn->real_escape_string($email);

    /*
     * The attribute DEFINITION for a header is the same for every row of the file, so it is
     * looked up once per process rather than once per contact.
     *
     * A CSV's headers are fixed the moment the file is chosen; re-asking the database what
     * "COLLEGE" means for contact 2 through contact 2,000 cannot return anything different. Left
     * uncached it was one SELECT per column per row — six columns over 2,000 contacts is twelve
     * thousand identical queries, and together with the SHOW COLUMNS in
     * attribute_data_ensure_column() that is where an import's time was going.
     *
     * Keyed by the normalized name. A miss is cached as well, but only after the auto-create
     * below has replaced it with the definition it just inserted — see the note there for why
     * caching the bare null instead would insert one duplicate attribute per row.
     */
    static $attrDefs = [];

    foreach ($extraAttributes as $header => $value) {
        $value = trim((string)$value);
        if ($value === '') continue;

        $name = normalize_attribute_name((string)$header);
        if ($name === '') continue;
        $nameE = $conn->real_escape_string($name);

        if (array_key_exists($name, $attrDefs)) {
            $attr = $attrDefs[$name];
        } else {
            $r = $conn->query("SELECT id, category, mapped_db, mapped_table, mapped_column, mapped_join_col
                                FROM campaign_attributes WHERE name='$nameE' LIMIT 1");
            $attr = $r ? $r->fetch_assoc() : null;
            $attrDefs[$name] = $attr;
        }

        if ($attr && $attr['category'] === 'system') {
            write_mapped_attribute_value($attr, $email, $value);
            journey_contact_log_update($email, $name, $value, 'import');
            continue;
        }

        // Computed from a lookup chain at send time — see the same guard in
        // fan_out_extra_attributes_many() above for why there is nowhere to write it.
        if ($attr && $attr['category'] === 'linked') continue;

        if (!$attr) {
            $conn->query("INSERT INTO campaign_attributes (name, category) VALUES ('$nameE', 'custom')");
            $attributeId = $conn->insert_id;
            attribute_log($attributeId, $name, 'Auto-created from CSV import', null);

            /*
             * The cache MUST learn what was just created, not keep the miss.
             *
             * Uncached, this branch was self-correcting: row 2 re-queried, found the row row 1
             * had inserted, and skipped creation. Caching the null removes that second query and
             * with it the correction — every row would re-enter this branch and insert
             * campaign_attributes again, one duplicate per contact in the file, each with its own
             * "Auto-created from CSV import" ledger line.
             */
            $attr = ['id' => $attributeId, 'category' => 'custom', 'mapped_db' => null,
                     'mapped_table' => null, 'mapped_column' => null, 'mapped_join_col' => null];
            $attrDefs[$name] = $attr;
        }

        attribute_data_ensure_column($name);
        $col = attribute_column_name($name);
        $valueE = $conn->real_escape_string($value);
        $conn->query("INSERT INTO campaign_attribute_data (email, `$col`) VALUES ('$emailE', '$valueE')
                      ON DUPLICATE KEY UPDATE `$col`=VALUES(`$col`)");
        /*
         * One ledger row per attribute actually written, so a journey triggered on
         * "COLLEGE was updated" fires for exactly the contacts whose COLLEGE this import
         * touched — not for everyone whose row happened to move. See
         * journeys/lib/ContactActivity.php for why the ledger is needed at all.
         */
        journey_contact_log_update($email, $name, $value, 'import');
    }
}

/**
 * Writes one value directly into a mapped ('system') attribute's real source table,
 * matched back to $email via the attribute's own join column — resolving a user_id from
 * the email first when the mapped table is keyed by user_id (a CSV contact only ever
 * carries an email, never a user_id directly). Silently skipped when the email isn't a
 * registered user and the mapped table needs a user_id to match on — there's nothing to
 * attach the value to in that case.
 */
function write_mapped_attribute_value(array $attr, string $email, string $value): void {
    global $conn;
    $db = $attr['mapped_db']; $table = $attr['mapped_table']; $col = $attr['mapped_column']; $joinCol = $attr['mapped_join_col'];
    if (!$db || !$table || !$col || !$joinCol) return;
    $qualified = "`$db`.`$table`";
    $valueE = $conn->real_escape_string($value);
    $emailE = $conn->real_escape_string($email);

    if ($joinCol === 'user_id') {
        $uRes = $conn->query("SELECT user_id FROM users WHERE email='$emailE' LIMIT 1");
        $uRow = $uRes ? $uRes->fetch_assoc() : null;
        if (!$uRow) {
            contact_import_log("write_mapped_attribute_value: $email is not a registered user — skipping write to $qualified.$col (needs user_id to match on)");
            return;
        }
        $conn->query("UPDATE $qualified SET `$col`='$valueE' WHERE user_id=" . (int)$uRow['user_id']);
    } else {
        $conn->query("UPDATE $qualified SET `$col`='$valueE' WHERE email='$emailE'");
    }
}

/**
 * Processes one chunk of a single import job (or every due job, if $uploadId
 * is null — the recurring cron sweep). Resumes via a BYTE offset persisted in
 * cursor_byte_offset, not a row-skip count, so every tick costs O(chunk size)
 * regardless of how far into a large file it's resuming (re-reading from the
 * start and skipping N rows every tick would be quadratic overall).
 */

/**
 * Writes one buffered batch, and degrades to row-at-a-time rather than losing the batch.
 *
 * A multi-row INSERT is all-or-nothing: whatever makes one tuple unacceptable to MySQL takes
 * the other 499 down with it. So the fast path is tried first, and only if it is refused is
 * the same buffer replayed through the original single-row contact_upsert() — which isolates
 * the offending row, records just that one in the failure report, and still lands everything
 * else. Both paths are idempotent, so replaying rows the failed statement may already have
 * written costs nothing but time.
 *
 * @param array $buffer     rows as csv_apply_mapping() returned them, valid email already checked
 * @param array $rowNumbers same order as $buffer — the CSV line each row came from
 * @return array{success:int,failed:int}
 */
function contact_import_flush_buffer(int $uploadId, int $listId, array $buffer, array $rowNumbers, array $headers): array {
    if (!$buffer) return ['success' => 0, 'failed' => 0];

    try {
        contact_upsert_many($buffer, $listId);
        return ['success' => count($buffer), 'failed' => 0];
    } catch (\Throwable $e) {
        contact_import_log("upload #$uploadId: batch of " . count($buffer) . ' row(s) rejected ('
            . get_class($e) . ': ' . $e->getMessage() . ') — replaying row by row to isolate it');

        $ok = 0; $bad = 0;
        foreach ($buffer as $i => $data) {
            try {
                contact_upsert($data, $listId);
                $ok++;
            } catch (\Throwable $rowErr) {
                $bad++;
                contact_import_record_row_error($uploadId, (int)($rowNumbers[$i] ?? 0),
                    $data['email'] ?? null, get_class($rowErr) . ': ' . $rowErr->getMessage(), null, $headers);
            }
        }
        return ['success' => $ok, 'failed' => $bad];
    }
}

/*
 * Contacts written per multi-row statement.
 *
 * Large enough that the per-statement round trip stops being what the import is spending its
 * time on, small enough that one batch's SQL stays far inside max_allowed_packet and that the
 * row-by-row fallback above has little to replay when a batch is refused.
 */
if (!defined('CONTACT_IMPORT_BATCH_SIZE')) define('CONTACT_IMPORT_BATCH_SIZE', 500);

/*
 * Rows processed between commits of the cursor and counters.
 *
 * Tied to the batch size rather than set independently, because a commit records how far the
 * file has been read and rows still sitting in the buffer have NOT been written yet. Committing
 * on any other rhythm would mean either advancing the cursor past unwritten contacts, or
 * flushing a part-full batch purely to satisfy the counter. One batch, one commit.
 */
if (!defined('CONTACT_IMPORT_FLUSH_EVERY')) define('CONTACT_IMPORT_FLUSH_EVERY', CONTACT_IMPORT_BATCH_SIZE);

/*
 * How long one tick may spend in the row loop before stopping cleanly.
 *
 * Chosen against the cron interval, not against max_execution_time: cron fires this worker every
 * minute and flock() already stops two runs overlapping, so a tick may use most of that minute.
 * A run under a real PHP time limit ignores this and derives its budget from that limit instead
 * (see below), so the worker still stops on its own terms rather than being killed mid-row.
 *
 * It matters more now than it did: batching made a tick fast enough that the whole file usually
 * finishes inside one tick, and a budget of 20s would have been the only thing still forcing a
 * 50,000-row import to wait for the next cron minute to continue.
 */
if (!defined('CONTACT_IMPORT_TIME_BUDGET_SECONDS')) define('CONTACT_IMPORT_TIME_BUDGET_SECONDS', 50);

function contact_import_process_batch(int $chunkSize = 1000, ?int $uploadId = null): array {
    global $conn;

    $filter = $uploadId ? "id=" . (int)$uploadId : "status IN ('pending','processing')";
    $res = $conn->query("SELECT id FROM campaign_contact_uploads WHERE $filter");
    $ids = [];
    while ($res && $row = $res->fetch_assoc()) $ids[] = (int)$row['id'];

    contact_import_log('tick: ' . count($ids) . ' upload(s) to check' . ($uploadId ? " (instant kick for upload #$uploadId)" : ' (cron sweep)'));

    /*
     * ONE deadline for the whole tick, shared by every upload it visits.
     *
     * Per-upload budgets do not compose: three uploads sitting in 'processing' at once gave a
     * single PHP process 3 x the budget to spend, which put it back over max_execution_time and
     * back to being killed — the exact failure the budget was added to prevent. Worse, it was
     * killed while working on the FIRST upload, so the second and third were never reached on any
     * tick and could not advance at all. Upload #23 stopped dead at 400 rows for that reason,
     * while #21 and #22 soaked up every tick ahead of it.
     *
     * With one shared deadline a tick always returns in bounded time, and the loop below leaves
     * as soon as it is spent — so the next tick resumes wherever this one stopped.
     */
    /*
     * The budget is derived from the limit this process is actually running under, not assumed.
     *
     * A flat 20s was fine for the cron, which runs under CLI with no limit at all, and useless
     * for the "Send now" style instant kick, which arrives over HTTP where the limit is often
     * 30s or less and is spent partly on everything else the request does. That kick was killed
     * around 400 rows without ever reaching the 20s mark, so it never logged the pause and never
     * looked like a timeout — it just stopped.
     *
     * 60% leaves room for the flush, the completion bookkeeping and the response after the loop
     * gives up. ini_get returns 0 for "no limit", which is the CLI case and keeps the flat value.
     */
    $maxExec = (int)ini_get('max_execution_time');
    $budget  = $maxExec > 0 ? max(5, (int)($maxExec * 0.6)) : CONTACT_IMPORT_TIME_BUDGET_SECONDS;
    $tickDeadline = microtime(true) + $budget;

    $processedTotal = 0;
    /*
     * Uploads this tick is DONE with — completed, failed, or not eligible. Everything else in
     * $ids is still mid-file when the tick ends, and is what the caller chains a fresh run for
     * instead of leaving it to wait out a cron minute. Tracked as "finished" rather than
     * "unfinished" so an upload the loop never even reached (the tick's budget ran out first)
     * counts as still-running by default.
     */
    $settled = [];
    foreach ($ids as $idx => $id) {
        if (microtime(true) >= $tickDeadline) {
            contact_import_log('tick: time budget spent — remaining upload(s) continue next tick');
            break;
        }

        $r = $conn->query("SELECT * FROM campaign_contact_uploads WHERE id=$id LIMIT 1");
        $upload = $r ? $r->fetch_assoc() : null;
        if (!$upload || !in_array($upload['status'], ['pending', 'processing'], true)) { $settled[] = $id; continue; }

        if ($upload['status'] === 'pending') {
            $conn->query("UPDATE campaign_contact_uploads SET status='processing', started_at=NOW() WHERE id=$id");
        }

        $mappingCfg = json_decode($upload['column_mapping'] ?? '{}', true) ?: [];
        $mapping  = $mappingCfg['mapping'] ?? [];
        $defaults = $mappingCfg['defaults'] ?? [];
        $headers  = array_keys($mapping); // preserves the original CSV column order (see ContactImportWorker.php header comment)

        if (!is_file($upload['stored_path'])) {
            contact_import_log("upload #$id: stored file missing at {$upload['stored_path']} -> marking FAILED");
            $conn->query("UPDATE campaign_contact_uploads SET status='failed', completed_at=NOW() WHERE id=$id");
            $settled[] = $id;
            continue;
        }

        $fh = fopen($upload['stored_path'], 'r');
        if (!$fh) { contact_import_log("upload #$id: could not open file -> marking FAILED"); $conn->query("UPDATE campaign_contact_uploads SET status='failed', completed_at=NOW() WHERE id=$id"); $settled[] = $id; continue; }

        if ((int)$upload['cursor_byte_offset'] === 0) {
            fgetcsv($fh); // skip the header line on the very first tick
        } else {
            fseek($fh, (int)$upload['cursor_byte_offset']);
        }

        $rowNumber = (int)$upload['processed_rows'];
        $successDelta = 0; $failedDelta = 0; $rowsThisTick = 0;
        $pendingRows = 0; $pendingSuccess = 0; $pendingFailed = 0;
        $consecutiveWriteFailures = 0;
        // Contacts read but not yet written, and the CSV line each came from (so the row-by-row
        // fallback can still name the right line if the batch is refused).
        $buffer = []; $bufferRowNumbers = [];
        /*
         * A FAIR SHARE of the tick, not the whole of it.
         *
         * One shared deadline stops a tick overrunning max_execution_time, but on its own it
         * hands the entire budget to whichever upload is visited first: with several uploads
         * sitting in 'processing' the first one spends all 20s every single tick and the rest
         * are never reached, so they cannot advance no matter how long the cron runs. Slicing
         * the remaining time by the number of uploads still to visit keeps the tick bounded AND
         * guarantees every upload moves forward on every tick. An upload that finishes early
         * simply leaves more time for the ones after it.
         */
        $remaining   = max(1, count($ids) - $idx);
        $share       = max(1.0, ($tickDeadline - microtime(true)) / $remaining);
        $deadline    = min($tickDeadline, microtime(true) + $share);
        $tickStartedAt = microtime(true);
        $reachedEof  = false;
        $ranOutOfTime = false;

        while ($rowsThisTick < $chunkSize) {
            /*
             * Commit progress DURING the tick, not only at the end of it.
             *
             * This is the top of the loop on purpose: the handle sits exactly after the last row
             * that was fully processed, so the offset written here can never point past work that
             * has not been done. Flushing after reading but before upserting would skip a
             * contact on resume.
             *
             * Why it exists at all: everything used to be written once, after the whole 1,000-row
             * chunk. A tick that PHP killed on max_execution_time first — which is what a
             * 2,958-row file with several custom attributes does on shared hosting — committed
             * nothing. cursor_byte_offset stayed 0, so the next tick restarted from the top of
             * the file, re-imported the same few hundred rows, and died in the same place. The
             * upserts are idempotent so the contacts were correct, but processed_rows never left
             * 0: the progress bar sat at 0%, the list count sat at 0, and the import could not
             * finish however long it ran. That is exactly the shape of upload #21.
             *
             * With a flush every CONTACT_IMPORT_FLUSH_EVERY rows the worst a kill can cost is
             * that many rows of progress, and the run always moves forward.
             */
            if ($pendingRows > 0 && ($pendingRows >= CONTACT_IMPORT_FLUSH_EVERY || microtime(true) >= $deadline)) {
                /*
                 * The buffered contacts go in FIRST, always.
                 *
                 * The UPDATE below moves cursor_byte_offset to the current read position, which
                 * is a promise that everything before it is imported. Rows still in the buffer
                 * are not, so committing the offset while holding them would silently drop every
                 * one of them the moment the next tick resumed past their bytes.
                 */
                $w = contact_import_flush_buffer($id, (int)$upload['list_id'], $buffer, $bufferRowNumbers, $headers);
                $successDelta += $w['success']; $pendingSuccess += $w['success'];
                $failedDelta  += $w['failed'];  $pendingFailed  += $w['failed'];
                $buffer = []; $bufferRowNumbers = [];

                $off = ftell($fh);
                $conn->query("UPDATE campaign_contact_uploads SET
                    processed_rows = processed_rows + $pendingRows,
                    success_count  = success_count  + $pendingSuccess,
                    failed_count   = failed_count   + $pendingFailed,
                    cursor_byte_offset = $off
                    WHERE id=$id");
                $pendingRows = 0; $pendingSuccess = 0; $pendingFailed = 0;
            }

            /*
             * Stop on our own terms rather than being killed.
             *
             * Leaving before max_execution_time means the flush above has already run, so the
             * tick ends on a committed offset every time. The remaining rows are picked up by the
             * next cron tick from exactly here.
             */
            if (microtime(true) >= $deadline) { $ranOutOfTime = true; break; }

            /*
             * Skipping a row is the right answer for bad DATA; it is the wrong answer for a dead
             * database, where every row would "fail" instantly and the loop would burn through
             * the whole file marking every remaining row failed. If even the error row cannot be
             * written this many times running, the connection — not the CSV — is the problem, so
             * stop and let the next tick retry from the committed cursor.
             *
             * Checked here, at the top, rather than after the row body: the invalid-email branch
             * ends in `continue`, so a check placed below it would never be reached for exactly
             * the rows most likely to be failing.
             */
            if ($consecutiveWriteFailures >= 25) {
                contact_import_log("upload #$id: aborting tick — $consecutiveWriteFailures consecutive rows could not be written (database unreachable?)");
                $ranOutOfTime = true;
                break;
            }

            $row = fgetcsv($fh);
            if ($row === false) { $reachedEof = true; break; }

            $rowsThisTick++; $rowNumber++; $pendingRows++;
            if (count($row) === 1 && $row[0] === null) continue; // trailing blank line
            $email = null; // reset per row, so the catch below can never report the PREVIOUS row's address

            /*
             * Transcoded on the way in, once, before anything looks at the values.
             *
             * fgetcsv hands back raw bytes; every table these values reach is utf8mb4. Doing it
             * here means the contact itself IMPORTS — a name or address with an accented
             * character from an Excel-exported (Windows-1252) file is stored correctly instead
             * of being rejected by MySQL and counted as a failed row.
             */
            $row = contact_import_row_to_utf8($row);

            /*
             * ONE try/catch around the WHOLE row, not just around contact_upsert().
             *
             * The mapping, the validation and the write of the error row itself all used to sit
             * outside any handler, so an error raised in them was fatal to the process rather
             * than fatal to the row — and a fatal mid-chunk loses everything since the last
             * flush and leaves the upload's committed cursor exactly where it was. Every
             * following tick then re-read the same bytes, reached the same row, and died in the
             * same place: an import pinned forever on a multiple of the flush interval, which is
             * what "stuck at 400/2958, 400 succeeded, 0 failed" was. It could not have been the
             * time budget, because a budget stop logs that it paused and this logged nothing.
             *
             * A bad row is a data problem and belongs in campaign_contact_upload_errors where
             * the operator can see it. Only the row is lost now, and the run moves on.
             */
            try {
                $data = csv_apply_mapping($row, $headers, $mapping, $defaults);
                $email = $data['email'];
                if (!$email || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
                    $failedDelta++; $pendingFailed++;
                    $wrote = contact_import_record_row_error($id, $rowNumber, $email,
                        $email ? 'Invalid email address' : 'Missing email address', $row, $headers);
                    if (!$wrote) $consecutiveWriteFailures++; else $consecutiveWriteFailures = 0;
                    continue;
                }

                /*
                 * Buffered, not written. The contact is written by the batch flush at the top of
                 * the loop, which is also where its success is counted — so nothing is counted
                 * here that has not actually reached the database yet.
                 */
                $buffer[] = $data;
                $bufferRowNumbers[] = $rowNumber;
                $consecutiveWriteFailures = 0;
            } catch (\Throwable $e) {
                $failedDelta++; $pendingFailed++;
                $wrote = contact_import_record_row_error($id, $rowNumber, $email ?? null,
                    get_class($e) . ': ' . $e->getMessage(), $row, $headers);
                if (!$wrote) $consecutiveWriteFailures++; else $consecutiveWriteFailures = 0;
            }
        }

        /*
         * Whatever the loop was still holding when it stopped — on EOF, on the time budget, or
         * on the chunk limit — is written here, BEFORE the offset below is committed and before
         * EOF is allowed to mark the upload finished. Nothing may leave this loop unwritten.
         */
        if ($buffer) {
            $w = contact_import_flush_buffer($id, (int)$upload['list_id'], $buffer, $bufferRowNumbers, $headers);
            $successDelta += $w['success']; $pendingSuccess += $w['success'];
            $failedDelta  += $w['failed'];  $pendingFailed  += $w['failed'];
            $buffer = []; $bufferRowNumbers = [];
        }

        /*
         * EOF means fgetcsv actually reported it, nothing weaker.
         *
         * This used to also treat "fewer rows than the chunk size" as end-of-file, which was a
         * safe shorthand while the loop could only end by running out of rows. It no longer can:
         * a tick that stops on the time budget also ends short, and calling that EOF would mark a
         * part-finished import 'processed' and set the list's count from a partial membership.
         * Filling the chunk exactly just costs one extra tick to see the real EOF.
         */
        $atEof = $reachedEof;
        $newOffset = ftell($fh);
        fclose($fh);

        // Whatever the in-loop flush has not yet written.
        if ($pendingRows > 0) {
            $conn->query("UPDATE campaign_contact_uploads SET
                processed_rows = processed_rows + $pendingRows,
                success_count  = success_count  + $pendingSuccess,
                failed_count   = failed_count   + $pendingFailed,
                cursor_byte_offset = $newOffset
                WHERE id=$id");
        } else {
            $conn->query("UPDATE campaign_contact_uploads SET cursor_byte_offset = $newOffset WHERE id=$id");
        }
        $processedTotal += $rowsThisTick;

        if ($ranOutOfTime) {
            contact_import_log("upload #$id: paused after {$rowsThisTick} row(s) on its "
                . round($share, 1) . "s share of the {$budget}s tick budget — resuming from byte $newOffset next tick");
        }

        if ($atEof) {
            $settled[] = $id;
            $r2 = $conn->query("SELECT success_count, failed_count FROM campaign_contact_uploads WHERE id=$id LIMIT 1");
            $final = $r2 ? $r2->fetch_assoc() : ['success_count' => 0, 'failed_count' => 0];
            $finalStatus = ((int)$final['success_count'] > 0 || (int)$final['failed_count'] === 0) ? 'processed' : 'failed';
            $conn->query("UPDATE campaign_contact_uploads SET status='$finalStatus', completed_at=NOW() WHERE id=$id");
            $conn->query("UPDATE campaign_lists SET contact_count = (
                              SELECT COUNT(*) FROM campaign_list_members WHERE list_id={$upload['list_id']}
                          ) WHERE id={$upload['list_id']}");
            contact_import_log("upload #$id: COMPLETED -> status=$finalStatus (success={$final['success_count']}, failed={$final['failed_count']})"
                . ' — final tick did ' . $rowsThisTick . ' row(s) in ' . round(microtime(true) - $tickStartedAt, 2) . 's'
                . ' [' . contact_import_rate($rowsThisTick, $tickStartedAt) . ']');

            // Archive to S3 and remove the local copy — cPanel disk only ever holds files
            // actively being processed above, never a permanently-growing history. The
            // chunked fseek/fgetcsv/ftell processing above is untouched local-disk logic;
            // this only runs once, after the import has fully finished.
            $s3Url = s3_upload_file($upload['stored_path'], 'campaign_contact_uploads/' . $id . '/' . basename($upload['original_filename']), 'text/csv');
            if ($s3Url) {
                $s3UrlE = $conn->real_escape_string($s3Url);
                $conn->query("UPDATE campaign_contact_uploads SET s3_url='$s3UrlE' WHERE id=$id");
                @unlink($upload['stored_path']);
                contact_import_log("upload #$id: archived to S3 ($s3Url) and removed local copy");
            } else {
                contact_import_log("upload #$id: S3 archival FAILED — local copy kept at {$upload['stored_path']}");
            }
        } else {
            contact_import_log("upload #$id: this tick processed=$rowsThisTick (success=$successDelta, failed=$failedDelta)"
                . ' in ' . round(microtime(true) - $tickStartedAt, 2) . 's'
                . ' [' . contact_import_rate($rowsThisTick, $tickStartedAt) . '], still in progress');
        }
    }

    return [
        'uploads'    => count($ids),
        'processed'  => $processedTotal,
        'unfinished' => array_values(array_diff($ids, $settled)),
    ];
}

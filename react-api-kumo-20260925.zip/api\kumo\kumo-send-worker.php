<?php
/*
 * Cron / instant-kick entrypoint for the KumoMTA batch sender.
 *
 *   * * * * * /usr/local/bin/php /home/istudio/public_html/admin/react-api/api/kumo/kumo-send-worker.php >> /home/istudio/logs/kumo-worker.log 2>&1
 *   GET .../kumo-send-worker.php?secret=<KUMO_CRON_SECRET>&campaign_id=123     (HTTP fallback / instant kick)
 *
 * Mirrors campaigns/campaign-send-worker.php, including the PHP 8.1 mysqli
 * caveat: the connect failure throws instead of setting connect_error.
 */
ini_set('display_errors', 0);
error_reporting(E_ALL & ~E_WARNING & ~E_NOTICE & ~E_DEPRECATED);
$_SERVER['REQUEST_METHOD'] = $_SERVER['REQUEST_METHOD'] ?? 'CLI';

try {
    require_once __DIR__ . '/../../config/database.php';
} catch (\Throwable $e) {
    @file_put_contents(__DIR__ . '/worker.log', '[' . date('Y-m-d H:i:s') . '] FATAL — no database: ' . $e->getMessage() . "\n", FILE_APPEND | LOCK_EX);
    exit;
}

require_once __DIR__ . '/lib/config.php';
require_once __DIR__ . '/lib/schema.php';
require_once __DIR__ . '/lib/SendWorker.php';

kumo_ensure_schema();

$isCli = (php_sapi_name() === 'cli');
if (!$isCli && (($_GET['secret'] ?? '') !== KUMO_CRON_SECRET)) {
    http_response_code(403);
    echo "forbidden\n";
    exit;
}

@set_time_limit(0);
ignore_user_abort(true);

$campaignId = (int)($_GET['campaign_id'] ?? ($argv[1] ?? 0));
$summary    = kumo_worker_tick($campaignId);

$line = sprintf('tick: promoted=%d sent=%d failed=%d skipped=%d%s',
    $summary['promoted'], $summary['sent'], $summary['failed'], $summary['skipped'],
    $summary['note'] ? ' note=' . $summary['note'] : '');
kumo_log($line);

if ($isCli) {
    echo $line . "\n";
} else {
    header('Content-Type: application/json');
    echo json_encode(['ok' => true, 'summary' => $summary]);
}

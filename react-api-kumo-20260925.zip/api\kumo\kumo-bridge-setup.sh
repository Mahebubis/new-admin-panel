#!/usr/bin/env bash
#
# Builds the nginx bridge that lets the panel talk to KumoMTA.
#
#   panel / worker ──HTTPS──▶ mailer.nitrocampus.com ──▶ 127.0.0.1:8000 (KumoMTA)
#
# Run ON THE OVH MAIL BOX:   sudo bash kumo-bridge-setup.sh
# Safe to re-run: it overwrites its own two config files and nothing else. It
# never touches KumoMTA's config, the mail queue or the sending IPs.
#
# Optional: KUMO_TOKEN=<existing token> sudo -E bash kumo-bridge-setup.sh
#           (otherwise a new token is generated and printed at the end)
set -euo pipefail

HOST="mailer.nitrocampus.com"
CERT_EMAIL="${CERT_EMAIL:-postmaster@nitrocampus.com}"
# Allowed callers: the panel and the box that runs the send/health crons.
ALLOW_CIT3="15.207.59.247"
ALLOW_WORKER="13.207.16.208"

say()  { printf '\n\033[1;36m==> %s\033[0m\n' "$*"; }
ok()   { printf '    \033[1;32mOK\033[0m  %s\n' "$*"; }
bad()  { printf '    \033[1;31mFAIL\033[0m %s\n' "$*"; }

[ "$(id -u)" -eq 0 ] || { echo "Run me with sudo."; exit 1; }

say "1/8  Is KumoMTA answering on 127.0.0.1:8000?"
if curl -fsS -m 10 http://127.0.0.1:8000/metrics.json >/dev/null 2>&1; then
  ok "KumoMTA HTTP listener is up"
else
  bad "no answer from 127.0.0.1:8000 — fix KumoMTA first (systemctl status kumomta)"
  exit 1
fi

say "2/8  Token"
if [ -n "${KUMO_TOKEN:-}" ]; then
  TOKEN="$KUMO_TOKEN";        ok "using the token passed in"
else
  TOKEN="$(openssl rand -hex 32)"; ok "generated a new one (printed at the end)"
fi

say "3/8  Packages"
export DEBIAN_FRONTEND=noninteractive
apt-get update -qq
apt-get install -y -qq nginx certbot python3-certbot-nginx >/dev/null
ok "nginx + certbot installed"

say "4/8  Firewall"
if command -v ufw >/dev/null && ufw status | grep -q "Status: active"; then
  ufw allow 80/tcp  >/dev/null
  ufw allow 443/tcp >/dev/null
  ok "ufw: 80 and 443 allowed"
else
  ok "ufw inactive — nothing to open"
fi
systemctl enable --now nginx >/dev/null 2>&1 || true

say "5/8  TLS certificate for $HOST"
if [ -f "/etc/letsencrypt/live/$HOST/fullchain.pem" ]; then
  ok "certificate already present"
else
  certbot certonly --nginx -d "$HOST" -m "$CERT_EMAIL" --agree-tos -n
  ok "certificate issued"
fi

say "6/8  Config files"
install -d /etc/nginx/snippets
cat > /etc/nginx/snippets/kumo-guard.conf <<'EOF'
# Both guards live here because nginx matches an exact `location =` before the
# `location /kumo/` prefix — guards written only in the prefix block would never
# run for /kumo/inject, which would leave injection wide open.
if ($kumo_allowed = 0) { return 403; }
if ($kumo_bad_token)   { return 401; }
client_max_body_size 25m;
proxy_read_timeout   60s;
proxy_set_header Host $host;
proxy_set_header Authorization "";   # the token is for nginx, not for KumoMTA
EOF

cat > "/etc/nginx/sites-available/$HOST" <<EOF
# Managed by kumo-bridge-setup.sh — re-running the script rewrites this file.
geo \$kumo_allowed {
    default              0;
    $ALLOW_CIT3/32   1;    # cit3 — the panel
    $ALLOW_WORKER/32   1;    # monitoring box — send + health crons
}

# "Bearer " + 64 hex = 71 chars, past nginx default 64-byte map hash bucket.
map_hash_bucket_size 128;

map \$http_authorization \$kumo_bad_token {
    default              1;
    "Bearer $TOKEN"  0;
}

server {
    listen 443 ssl;
    server_name $HOST;

    ssl_certificate     /etc/letsencrypt/live/$HOST/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/$HOST/privkey.pem;

    access_log /var/log/nginx/kumo-bridge.access.log;
    error_log  /var/log/nginx/kumo-bridge.error.log;

    location = /kumo/ping    { return 200 "ok\n"; }
    location = /kumo/inject  { include snippets/kumo-guard.conf; proxy_pass http://127.0.0.1:8000/api/inject/v1; }
    location = /kumo/metrics { include snippets/kumo-guard.conf; proxy_pass http://127.0.0.1:8000/metrics.json; }
    location = /kumo/bounce  { include snippets/kumo-guard.conf; proxy_pass http://127.0.0.1:8000/api/admin/bounce/v1; }

    location / { return 404; }
}

server {
    listen 80;
    server_name $HOST;
    location /.well-known/acme-challenge/ { root /var/www/html; }
    location / { return 301 https://\$host\$request_uri; }
}
EOF
ln -sf "/etc/nginx/sites-available/$HOST" "/etc/nginx/sites-enabled/$HOST"
ok "wrote the snippet and the site file"

say "7/8  Test and reload nginx"
nginx -t
systemctl reload nginx
ok "nginx reloaded"

say "8/8  Verify"
FAILED=0
code() { curl -s -o /dev/null -m 15 -w '%{http_code}' "$@"; }

C="$(code "https://$HOST/kumo/ping")"
[ "$C" = "200" ] && ok "/kumo/ping → 200"                 || { bad "/kumo/ping → $C (want 200)"; FAILED=1; }

C="$(code "https://$HOST/kumo/metrics")"
[ "$C" = "401" ] && ok "/kumo/metrics without a token → 401" || { bad "/kumo/metrics without a token → $C (want 401)"; FAILED=1; }

C="$(code -H "Authorization: Bearer $TOKEN" "https://$HOST/kumo/metrics")"
[ "$C" = "403" ] && ok "/kumo/metrics with the token, from this box → 403 (this box is not on the allowlist — correct)" \
                 || { bad "/kumo/metrics with the token → $C (want 403 from here)"; FAILED=1; }

C="$(code -H "Authorization: Bearer wrong-$TOKEN" "https://$HOST/kumo/metrics")"
[ "$C" = "401" ] && ok "a wrong token → 401"               || { bad "a wrong token → $C (want 401)"; FAILED=1; }

echo
if [ "$FAILED" -eq 0 ]; then
  printf '\033[1;32m  BRIDGE IS UP.\033[0m\n\n'
else
  printf '\033[1;31m  Something is off — see the FAIL lines above.\033[0m\n\n'
fi
echo "  Bridge URL : https://$HOST"
echo "  Token      : $TOKEN"
echo
echo "  Put both into the panel: Kumo MTA -> Settings -> Connection -> Test connection."
echo "  Keep the token — it is not stored anywhere else on this box in readable form."
echo

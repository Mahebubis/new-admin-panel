<?php
/*
 * /api/whatsapp/wa_settings.php — WhatsApp Business API credentials and sending numbers.
 *
 * Credentials are account-level (one API key). Sending identity is NOT: a WABA owns several
 * business numbers and each has its own Source ID, so those live in wa_senders and a campaign
 * picks one.
 *
 * action=get                                   → settings row (api_key masked) + every sender
 * action=save   &api_key &api_base_url &default_country_code &webhook_secret
 * action=sender_save   [&id] &waba_id &waba_name &business_number &display_name &source_id
 *                      &quality_rating &messaging_limit &is_default &is_active &notes
 * action=sender_delete &id
 * action=sender_default &id
 * action=test          &phone                  → verifies the credentials against the provider
 * action=optin  &phones (comma/newline separated) [&type=optin|optout]
 * action=optin_list &page &per_page &search
 */
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../middleware/auth.php';
require_once __DIR__ . '/lib/config.php';
require_once __DIR__ . '/lib/schema.php';
require_once __DIR__ . '/lib/WhatsAppTransport.php';
require_once __DIR__ . '/lib/WaAudienceResolver.php';

whatsapp_ensure_schema();

$jwt = require_jwt();
require_permission('netcore_behaviour', $jwt);

function jin($k, $d = null) { $v = $_REQUEST[$k] ?? null; return ($v === null || $v === '') ? $d : $v; }

/** Shows enough of a credential to recognize it, never enough to use it. */
function wa_mask(string $k): string {
    if ($k === '') return 'not set';
    if (strlen($k) <= 10) return str_repeat('•', max(0, strlen($k) - 2)) . substr($k, -2);
    return substr($k, 0, 6) . str_repeat('•', 10) . substr($k, -4);
}

$action = jin('action', '');

if ($action === 'get') {
    $row = wa_settings_row();
    if (!$row) api_error('Settings row missing', 500);

    $row['api_key_masked'] = wa_mask(trim((string)$row['api_key']));
    $row['has_api_key']    = trim((string)$row['api_key']) !== '';
    unset($row['api_key']); // never return the raw key to the client
    // Legacy single-sender columns — migrated into wa_senders, kept out of the response so no
    // caller can start depending on them again.
    unset($row['source_id'], $row['waba_id'], $row['business_number'], $row['business_name']);
    $row['is_active'] = (int)$row['is_active'];
    if (empty($row['api_base_url'])) $row['api_base_url'] = WA_DEFAULT_API_BASE;

    $accountKey = trim((string)(wa_settings_row()['api_key'] ?? ''));
    $senders = array_map(function ($s) use ($accountKey) {
        $own = trim((string)$s['api_key']);
        $s['id']              = (int)$s['id'];
        $s['is_default']      = (int)$s['is_default'];
        $s['is_active']       = (int)$s['is_active'];
        $s['has_own_api_key'] = $own !== '';
        $s['api_key_masked']  = wa_mask($own);
        // Whether this number can actually send: Netcore issues the API key per business
        // number, so that key — not the source tag — is what makes a number usable.
        $s['ready']           = $own !== '' || $accountKey !== '';
        $s['has_source']      = trim((string)$s['source_id']) !== '';
        unset($s['api_key']); // never return a raw key to the client
        return $s;
    }, wa_senders_all());

    $usable = array_filter($senders, fn($s) => $s['ready'] && $s['is_active'] === 1);
    $row['ready']          = count($usable) > 0;
    $row['sender_count']   = count($senders);
    $row['usable_senders'] = count($usable);
    $row['senders_with_source'] = count(array_filter($senders, fn($s) => $s['has_source']));

    $tplR = $conn->query("SELECT COUNT(*) AS c FROM wa_templates WHERE status='active'");
    $row['template_count'] = $tplR ? (int)$tplR->fetch_assoc()['c'] : 0;
    $optR = $conn->query("SELECT COUNT(*) AS c FROM wa_optins WHERE status='optin'");
    $row['optin_count'] = $optR ? (int)$optR->fetch_assoc()['c'] : 0;

    api_success([
        'settings' => $row,
        'senders'  => array_values($senders),
        'webhook_path' => '/api/whatsapp/webhook.php',
        // Lets the page tell you when the deployed backend is older than the UI driving it.
        'api_version' => WA_API_VERSION,
    ]);
}

if ($action === 'save') {
    // Account-level credentials only — sending identity is per number (sender_save below).
    $set = [];
    foreach (['api_key', 'api_base_url', 'default_country_code', 'webhook_secret'] as $f) {
        $v = jin($f, null);
        if ($v === null) continue;
        // Leave the key untouched when the client echoes back the masked placeholder — that
        // means the admin edited other fields without retyping the credential.
        if ($f === 'api_key' && strpos((string)$v, '•') !== false) continue;
        $set[] = "$f='" . $conn->real_escape_string(trim((string)$v)) . "'";
    }
    if ($set) $conn->query("UPDATE wa_settings SET " . implode(', ', $set) . " WHERE provider='netcore'");
    api_success([]);
}

/* ── Sending numbers ────────────────────────────────────────────────────────────────────── */

if ($action === 'sender_save') {
    $id     = (int)jin('id', 0);
    $waba   = trim((string)jin('waba_id', ''));
    $number = trim((string)jin('business_number', ''));
    if ($waba === '')   api_error('WABA ID is required');
    if ($number === '') api_error('Business number is required');

    // Stored exactly as Netcore displays it minus the cosmetics, so two spellings of the same
    // number ("+91 8237850238" / "918237850238") can't become two sender rows with different
    // Source IDs — uq_number would not catch that on its own.
    $number = '+' . ltrim(preg_replace('/\D+/', '', $number), '0');
    if (strlen($number) < 8) api_error('That does not look like a business number');

    $fields = [
        'waba_id'         => $waba,
        'waba_name'       => (string)jin('waba_name', ''),
        'business_number' => $number,
        'display_name'    => (string)jin('display_name', ''),
        'source_id'       => trim((string)jin('source_id', '')),
        'quality_rating'  => (string)jin('quality_rating', ''),
        'messaging_limit' => (string)jin('messaging_limit', ''),
        'notes'           => (string)jin('notes', ''),
    ];
    $set = [];
    foreach ($fields as $c => $v) $set[] = "`$c`='" . $conn->real_escape_string($v) . "'";
    $set[] = 'is_active=' . ((int)jin('is_active', 1) === 1 ? 1 : 0);

    // Left untouched when blank or when the client echoes back the masked placeholder — that
    // means the admin edited other fields without retyping the credential.
    $apiKey = (string)jin('api_key', '');
    if (trim($apiKey) !== '' && strpos($apiKey, '•') === false) {
        $set[] = "api_key='" . $conn->real_escape_string(trim($apiKey)) . "'";
    }

    if ($id > 0) {
        $dup = $conn->query("SELECT id FROM wa_senders WHERE business_number='" . $conn->real_escape_string($number) . "' AND id <> $id LIMIT 1");
        if ($dup && $dup->num_rows > 0) api_error("$number is already saved as a sending number");
        $conn->query("UPDATE wa_senders SET " . implode(', ', $set) . " WHERE id=$id");
    } else {
        $dup = $conn->query("SELECT id FROM wa_senders WHERE business_number='" . $conn->real_escape_string($number) . "' LIMIT 1");
        if ($dup && $dup->num_rows > 0) api_error("$number is already saved as a sending number");
        $conn->query("INSERT INTO wa_senders SET " . implode(', ', $set));
        $id = $conn->insert_id;
    }

    // The first number saved becomes the default automatically — otherwise a single-number
    // setup would have no default at all and every campaign would need an explicit pick.
    $anyDefault = $conn->query("SELECT 1 FROM wa_senders WHERE is_default=1 LIMIT 1");
    $makeDefault = (int)jin('is_default', 0) === 1 || !$anyDefault || $anyDefault->num_rows === 0;
    if ($makeDefault) {
        $conn->query("UPDATE wa_senders SET is_default=0");
        $conn->query("UPDATE wa_senders SET is_default=1 WHERE id=$id");
    }
    api_success(['id' => $id]);
}

if ($action === 'sender_default') {
    $id = (int)jin('id', 0);
    if (!$id) api_error('id required');
    $conn->query("UPDATE wa_senders SET is_default=0");
    $conn->query("UPDATE wa_senders SET is_default=1 WHERE id=$id");
    api_success([]);
}

if ($action === 'sender_delete') {
    $id = (int)jin('id', 0);
    if (!$id) api_error('id required');

    // Campaigns snapshot source_id/business_number when they are sent or scheduled, so removing
    // a number never changes anything already queued. A DRAFT pointing at it would silently
    // fall back to the default, which is worth saying out loud rather than discovering later.
    $inUse = $conn->query("SELECT COUNT(*) AS c FROM wa_campaigns WHERE sender_id=$id AND status IN ('draft','scheduled')");
    $count = $inUse ? (int)$inUse->fetch_assoc()['c'] : 0;

    $wasDefault = $conn->query("SELECT is_default FROM wa_senders WHERE id=$id LIMIT 1");
    $wasDefaultRow = $wasDefault ? $wasDefault->fetch_assoc() : null;

    $conn->query("DELETE FROM wa_senders WHERE id=$id");
    // Don't leave the account with no default at all — activeProvider-style silent fallbacks
    // are exactly what makes this integration hard to debug.
    if ($wasDefaultRow && (int)$wasDefaultRow['is_default'] === 1) {
        $next = $conn->query("SELECT id FROM wa_senders WHERE is_active=1 ORDER BY id ASC LIMIT 1");
        $nextRow = $next ? $next->fetch_assoc() : null;
        if ($nextRow) $conn->query("UPDATE wa_senders SET is_default=1 WHERE id=" . (int)$nextRow['id']);
    }
    api_success(['affected_drafts' => $count]);
}

/*
 * Credential check. There is no "ping" endpoint on this API, so the honest test is a real
 * consent call for a throwaway-but-syntactically-valid number: a 200 proves the key is live,
 * a 401/403 proves it isn't. This does NOT prove the Source ID or templates are right —
 * nothing except an actual delivery does, which is why the campaign preflight checks those
 * separately.
 */
if ($action === 'test') {
    $row = wa_settings_row() ?: [];
    // Tested against a specific number's key when one is given, since that's the credential a
    // campaign would really use.
    $sender = wa_sender_by_id((int)jin('sender_id', 0)) ?: wa_default_sender();
    $transport = new WhatsAppTransport($row, null, wa_sender_api_key($sender));
    if (!$transport->isConfigured()) api_error('Add an API key for a sending number first');

    $probe = trim((string)jin('phone', ''));
    $phone = $probe !== '' ? wa_normalize_phone($probe, wa_default_cc()) : null;
    if ($phone === null) api_error('Enter a WhatsApp number to run the check against (your own is ideal)');

    $res = $transport->manageConsent([$phone], 'optin');
    if ($res['ok']) wa_record_optin($phone, 'optin', 'ADMIN_TEST');

    $notes = [];
    $all = wa_senders_all();
    $noKey = array_values(array_filter($all, fn($s) => trim((string)$s['api_key']) === ''));
    if (!$all) {
        $notes[] = 'No sending numbers added yet. A campaign needs at least one, and each number has its own API key in the Netcore panel.';
    } elseif ($noKey && trim((string)($row['api_key'] ?? '')) === '') {
        $notes[] = 'These numbers have no API key of their own and cannot send: '
            . implode(', ', array_map(fn($s) => $s['business_number'], $noKey)) . '.';
    }
    $tplR = $conn->query("SELECT COUNT(*) AS c FROM wa_templates WHERE status='active' AND approval_status='approved'");
    if ($tplR && (int)$tplR->fetch_assoc()['c'] === 0) {
        $notes[] = 'No approved templates registered yet. Outside the 24-hour service window WhatsApp only delivers approved templates — sync them from the Templates page.';
    }

    api_success([
        'ok' => $res['ok'],
        'message' => $res['ok'] ? "API key is valid — consent registered for $phone." : ($res['error'] ?: 'The provider rejected the request'),
        'notes' => $notes,
    ]);
}

/*
 * Consent management.
 *
 * Opt-IN is not a hard prerequisite on this account — the Netcore panel's opt-in list can be
 * empty while template messages still deliver at ~92%. What matters is opt-OUT: a number that
 * opted out (or replied STOP) must never be messaged again, and wa_optins is what enforces
 * that locally at audience-resolve time. Registering opt-ins here is still useful for
 * marketing-category sends and for keeping our copy of consent in step with the provider's.
 */
if ($action === 'optin') {
    $row = wa_settings_row() ?: [];
    $sender = wa_default_sender();
    $transport = new WhatsAppTransport($row, null, wa_sender_api_key($sender));
    if (!$transport->isConfigured()) api_error('Add an API key for a sending number first');

    $type = jin('type', 'optin') === 'optout' ? 'optout' : 'optin';
    $raw = (string)jin('phones', '');
    $inputs = array_values(array_filter(array_map('trim', preg_split('/[,;\n]+/', $raw))));
    if (!$inputs) api_error('Enter at least one number');

    $cc = wa_default_cc();
    $valid = []; $invalid = [];
    foreach ($inputs as $in) {
        $p = wa_normalize_phone($in, $cc);
        if ($p === null) { $invalid[] = $in; continue; }
        $valid[$p] = true;
    }
    $valid = array_keys($valid);
    if (!$valid) api_error('None of those look like valid WhatsApp numbers');

    // Chunked — the consent endpoint takes a batch, but not an unbounded one.
    $okCount = 0; $errors = [];
    foreach (array_chunk($valid, 100) as $chunk) {
        $res = $transport->manageConsent($chunk, $type);
        if ($res['ok']) {
            foreach ($chunk as $p) wa_record_optin($p, $type, 'ADMIN');
            $okCount += count($chunk);
        } else {
            $errors[] = $res['error'] ?: 'Provider rejected the batch';
        }
    }
    api_success(['registered' => $okCount, 'invalid' => $invalid, 'errors' => $errors, 'type' => $type]);
}

if ($action === 'optin_list') {
    $page    = max(1, (int)jin('page', 1));
    $perPage = max(1, min(100, (int)jin('per_page', 20)));
    $search  = trim((string)jin('search', ''));
    $offset  = ($page - 1) * $perPage;

    $where = $search !== '' ? "WHERE phone LIKE '%" . $conn->real_escape_string($search) . "%'" : '';
    $tr = $conn->query("SELECT COUNT(*) AS c FROM wa_optins $where");
    $total = $tr ? (int)$tr->fetch_assoc()['c'] : 0;

    $r = $conn->query("SELECT phone, status, source, updated_at FROM wa_optins $where ORDER BY updated_at DESC LIMIT $perPage OFFSET $offset");
    $rows = [];
    while ($r && $row = $r->fetch_assoc()) $rows[] = $row;

    api_success(['optins' => $rows, 'total' => $total, 'page' => $page, 'per_page' => $perPage,
                 'pages' => $total > 0 ? (int)ceil($total / $perPage) : 1]);
}

api_error('Invalid action');

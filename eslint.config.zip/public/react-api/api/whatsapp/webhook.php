<?php
/*
 * /api/whatsapp/webhook.php — inbound delivery-status receiver.
 *
 * This is the ONLY thing that can move a campaign's delivered / read / clicked numbers. The
 * send API answering 200 means "accepted for delivery", nothing more — a message can be
 * accepted and then silently dropped (unapproved template, number never opted in), so
 * treating an accept as a delivery would report a campaign as fully delivered while nobody
 * received anything. Until this URL is registered in the Netcore panel, Delivered/Read stay
 * at 0 by design and the report says so rather than inventing numbers.
 *
 * Register as:  https://cit3.internshipstudio.com/admin/react-api/api/whatsapp/webhook.php
 * in the Netcore panel under Business number → Edit → Webhook Integration. The SAME URL can be
 * registered on several tabs and this file handles each:
 *   Event    → delivered / read / failed / button click   (required for any reporting)
 *   Incoming → replies, including "STOP" as an opt-out    (recommended)
 *   Consent  → opt-in / opt-out / blocklist changes       (recommended — feeds suppression)
 *   Template → Meta approval decisions                    (optional — keeps badges honest)
 *
 * The optional "Source key or ID" on that form is worth setting: without it the webhook
 * receives events for EVERY message on that business number, including traffic from other
 * systems sharing it. Events we can't match to a recipient are ignored, but scoping by source
 * key keeps the volume (and the log) to this panel's own sends.
 *
 * Payload shapes differ between provider versions, so parsing is deliberately tolerant: the
 * handler walks the JSON for anything carrying a message id + status and correlates it back
 * through wa_message_id (the provider's own id) or x-apiheader (our rid, echoed verbatim).
 */
ini_set('display_errors', 0);
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/lib/config.php';
require_once __DIR__ . '/lib/schema.php';
require_once __DIR__ . '/lib/WaSendWorker.php';

whatsapp_ensure_schema();

// Always 200 — a webhook that answers anything else gets retried, then disabled, by most
// providers. Parsing problems are logged instead.
http_response_code(200);

$raw = file_get_contents('php://input');
if ($raw === '' || $raw === false) { echo 'ok'; exit; }

$settings = wa_settings_row() ?: [];
$secret = trim((string)($settings['webhook_secret'] ?? ''));
if ($secret !== '') {
    // Optional shared secret — only enforced once one has been configured, so registering the
    // URL before setting a secret still works.
    $provided = $_GET['secret'] ?? ($_SERVER['HTTP_X_WEBHOOK_SECRET'] ?? '');
    if (!hash_equals($secret, (string)$provided)) {
        wa_log('webhook: rejected a call with a bad/missing secret');
        echo 'ok';
        exit;
    }
}

$payload = json_decode($raw, true);
if (!is_array($payload)) {
    wa_log('webhook: unparseable body — ' . substr($raw, 0, 400));
    echo 'ok';
    exit;
}

/** Collects every {id, status} pair anywhere in the payload. */
function wa_collect_statuses(array $node, array &$out): void {
    $idKeys     = ['message_id', 'messageId', 'id', 'wamid', 'mid'];
    $statusKeys = ['status', 'event', 'event_type', 'state'];

    $id = null; $status = null; $rid = null; $reason = null; $code = null;
    foreach ($idKeys as $k) {
        if (isset($node[$k]) && (is_string($node[$k]) || is_numeric($node[$k]))) { $id = (string)$node[$k]; break; }
    }
    foreach ($statusKeys as $k) {
        if (isset($node[$k]) && is_string($node[$k])) { $status = strtolower($node[$k]); break; }
    }
    foreach (['x-apiheader', 'x_apiheader', 'apiheader', 'custom_id'] as $k) {
        if (isset($node[$k]) && is_string($node[$k])) { $rid = $node[$k]; break; }
    }
    foreach (['reason', 'error_message', 'description', 'detail'] as $k) {
        if (isset($node[$k]) && is_string($node[$k])) { $reason = $node[$k]; break; }
    }
    foreach (['error_code', 'code', 'errorCode'] as $k) {
        if (isset($node[$k]) && (is_string($node[$k]) || is_numeric($node[$k]))) { $code = (string)$node[$k]; break; }
    }

    if ($status !== null && ($id !== null || $rid !== null)) {
        $out[] = ['id' => $id, 'rid' => $rid, 'status' => $status, 'reason' => $reason, 'code' => $code];
        // Stop here rather than also walking this node's children: a node carrying both an id
        // and a status IS the message record, and descending into it would collect the same
        // event a second time — which would double-count clicks and replies (delivered/read
        // are protected by the forward-only rank check below, those two are not).
        return;
    }
    foreach ($node as $child) {
        if (is_array($child)) wa_collect_statuses($child, $out);
    }
}

/*
 * The same endpoint is registered on the panel's Consent tab as well as its Event tab, because
 * an opt-out made anywhere — the Netcore UI, a STOP reply, another system on the same number —
 * has to reach our suppression list or the next campaign will message that person again.
 *
 * Consent payloads carry a phone number and an optin/optout state but no message id, so they
 * never match the status collector above and need their own pass.
 */
function wa_apply_consent_events(array $node, int &$applied): void {
    $phone = null; $state = null;
    foreach (['mobile', 'recipient', 'recipient_whatsapp', 'phone', 'mobile_number', 'msisdn'] as $k) {
        if (isset($node[$k]) && (is_string($node[$k]) || is_numeric($node[$k]))) { $phone = (string)$node[$k]; break; }
    }
    foreach (['type', 'status', 'consent', 'consent_status', 'event'] as $k) {
        if (isset($node[$k]) && is_string($node[$k])) {
            $v = strtolower(trim($node[$k]));
            if (in_array($v, ['optin', 'opt-in', 'opt_in', 'optout', 'opt-out', 'opt_out', 'blocklist', 'blocked'], true)) {
                $state = $v; break;
            }
        }
    }

    if ($phone !== null && $state !== null) {
        $normalized = wa_normalize_phone($phone, wa_default_cc());
        if ($normalized !== null) {
            // Blocklisted is treated as opted out: either way we must not message them.
            $isOut = strpos($state, 'out') !== false || strpos($state, 'block') !== false;
            wa_record_optin($normalized, $isOut ? 'optout' : 'optin', 'WEBHOOK');
            $applied++;
            wa_log("webhook: consent $state for $normalized");
        }
        return;
    }
    foreach ($node as $child) {
        if (is_array($child)) wa_apply_consent_events($child, $applied);
    }
}

/*
 * Registered on the Template tab too: Meta's approval decisions arrive here, and an approval
 * badge that silently goes stale is worse than none — the wizard uses it to warn before a send.
 * Only ever updates a template we already know about, so an unrelated payload can't create rows.
 */
function wa_apply_template_events(array $node, int &$applied): void {
    global $conn;
    $name = null; $status = null;
    foreach (['template_name', 'templateName', 'name'] as $k) {
        if (isset($node[$k]) && is_string($node[$k]) && preg_match('/^[a-z0-9_]+$/', $node[$k])) { $name = $node[$k]; break; }
    }
    foreach (['status', 'event', 'template_status'] as $k) {
        if (isset($node[$k]) && is_string($node[$k])) {
            $v = strtolower(trim($node[$k]));
            if (in_array($v, ['approved', 'rejected', 'pending', 'paused', 'disabled'], true)) { $status = $v; break; }
        }
    }

    if ($name !== null && $status !== null) {
        // 'paused'/'disabled' are not deliverable, so they map to the same warning state as a
        // rejection rather than being dropped on the floor.
        $mapped = $status === 'approved' ? 'approved' : ($status === 'pending' ? 'pending' : 'rejected');
        $conn->query("UPDATE wa_templates SET approval_status='" . $conn->real_escape_string($mapped) . "'
                       WHERE name='" . $conn->real_escape_string($name) . "'");
        if ($conn->affected_rows > 0) {
            $applied++;
            wa_log("webhook: template $name -> $mapped");
        }
        return;
    }
    foreach ($node as $child) {
        if (is_array($child)) wa_apply_template_events($child, $applied);
    }
}

$consentApplied = 0;
wa_apply_consent_events($payload, $consentApplied);
$templateApplied = 0;
wa_apply_template_events($payload, $templateApplied);

$events = [];
wa_collect_statuses($payload, $events);
if (!$events) {
    if ($consentApplied === 0 && $templateApplied === 0) {
        wa_log('webhook: no recognizable events in payload — ' . substr($raw, 0, 400));
    }
    echo 'ok';
    exit;
}

// Provider vocabulary → our recipient statuses. Anything unrecognized is logged, not guessed.
$MAP = [
    'sent' => 'sent', 'accepted' => 'sent', 'submitted' => 'sent',
    'delivered' => 'delivered', 'delivery' => 'delivered',
    'read' => 'read', 'seen' => 'read',
    'failed' => 'failed', 'undelivered' => 'failed', 'rejected' => 'failed', 'error' => 'failed',
    'click' => 'button_click', 'button_click' => 'button_click', 'clicked' => 'button_click',
    'reply' => 'replied', 'replied' => 'replied', 'inbound' => 'replied',
];

$applied = 0;
foreach ($events as $ev) {
    $mapped = $MAP[$ev['status']] ?? null;
    if ($mapped === null) { wa_log("webhook: ignoring unknown status \"{$ev['status']}\""); continue; }

    $where = [];
    if (!empty($ev['id']))  $where[] = "wa_message_id='" . $conn->real_escape_string($ev['id']) . "'";
    if (!empty($ev['rid'])) $where[] = "rid='" . $conn->real_escape_string($ev['rid']) . "'";
    if (!$where) continue;

    $r = $conn->query("SELECT id, campaign_id, status FROM wa_campaign_recipients
                        WHERE " . implode(' OR ', $where) . ' LIMIT 1');
    $rec = $r ? $r->fetch_assoc() : null;
    if (!$rec) continue;

    $recId = (int)$rec['id'];
    $cid   = (int)$rec['campaign_id'];

    /*
     * Status only ever moves FORWARD along sent → delivered → read. WhatsApp does not
     * guarantee webhook ordering, and a late-arriving "delivered" must not overwrite a "read"
     * that already landed — otherwise the read count silently decays over the life of a
     * campaign. Rank comparison, not blind assignment.
     */
    $rank = ['pending' => 0, 'processing' => 1, 'sent' => 2, 'delivered' => 3, 'read' => 4];
    $current = $rec['status'];

    if (in_array($mapped, ['delivered', 'read'], true)) {
        if (($rank[$mapped] ?? 0) > ($rank[$current] ?? 0)) {
            $col = $mapped === 'read' ? 'read_at' : 'delivered_at';
            $conn->query("UPDATE wa_campaign_recipients SET status='$mapped', $col=NOW() WHERE id=$recId");
            $counter = $mapped === 'read' ? 'read_count' : 'delivered_count';
            $conn->query("UPDATE wa_campaigns SET $counter = $counter + 1 WHERE id=$cid");
            wa_record_event($cid, $recId, $mapped);
            $applied++;
        }
    } elseif ($mapped === 'failed') {
        // A failure reported after acceptance is the real outcome, so it always wins.
        if ($current !== 'failed') {
            $err = $conn->real_escape_string(substr((string)($ev['reason'] ?? 'Reported failed by WhatsApp'), 0, 480));
            $code = $conn->real_escape_string(substr((string)($ev['code'] ?? ''), 0, 60));
            $conn->query("UPDATE wa_campaign_recipients SET status='failed', failed_at=NOW(),
                                 error_message='$err', error_code='$code' WHERE id=$recId");
            $conn->query("UPDATE wa_campaigns SET failed_count = failed_count + 1 WHERE id=$cid");
            wa_record_event($cid, $recId, 'failed', $ev['code'] ?? null, $ev['reason'] ?? null);
            $applied++;
        }
    } elseif ($mapped === 'button_click') {
        $conn->query("UPDATE wa_campaign_recipients SET click_count = click_count + 1 WHERE id=$recId");
        $conn->query("UPDATE wa_campaigns SET click_count = click_count + 1 WHERE id=$cid");
        wa_record_event($cid, $recId, 'button_click', null, $ev['reason'] ?? null);
        $applied++;
    } elseif ($mapped === 'replied') {
        $conn->query("UPDATE wa_campaigns SET reply_count = reply_count + 1 WHERE id=$cid");
        wa_record_event($cid, $recId, 'replied', null, $ev['reason'] ?? null);
        // "STOP" is the universal WhatsApp opt-out. Honouring it here is what keeps a future
        // campaign from messaging someone who explicitly asked us not to.
        if ($ev['reason'] !== null && preg_match('/\b(stop|unsubscribe|opt\s*out)\b/i', $ev['reason'])) {
            $pR = $conn->query("SELECT phone FROM wa_campaign_recipients WHERE id=$recId LIMIT 1");
            $pRow = $pR ? $pR->fetch_assoc() : null;
            if ($pRow) {
                wa_record_optin($pRow['phone'], 'optout', 'REPLY');
                wa_log("webhook: {$pRow['phone']} opted out via reply");
            }
        }
        $applied++;
    }
}

wa_log('webhook: ' . count($events) . ' status event(s) received, ' . $applied . ' applied'
    . ($consentApplied ? ", $consentApplied consent change(s)" : '')
    . ($templateApplied ? ", $templateApplied template update(s)" : ''));
echo 'ok';

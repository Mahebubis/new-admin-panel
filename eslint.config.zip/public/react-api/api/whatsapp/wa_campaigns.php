<?php
/*
 * /api/whatsapp/wa_campaigns.php — WhatsApp campaign builder backend.
 *
 * action=list            &page &per_page &status &search   → paginated list + per-status tab counts
 * action=get              &id                              → full campaign row
 * action=save      [&id]  &name &... (see $fields)          → create/update (autosave from the wizard)
 * action=delete           &id
 * action=duplicate        &id
 * action=tags                                               → distinct tags across all WhatsApp campaigns
 * action=audience_count   &audience_type &segment_ids &exclude_segment_ids &list_ids
 *                         &dedup_enabled &dedup_window_hours &dedup_scope [&template_name] [&id]
 *                                                           → reachable / unreachable / duplicates / dedup preview
 * action=preflight        &id                               → the pre-send checklist (blocking + warnings)
 * action=send_test        &id &phones (comma/newline separated)
 * action=send_now         &id
 * action=schedule         &id &scheduled_at
 * action=pause  | resume | requeue   &id
 * action=report           &id                               → stats + recent events
 * action=recipients       &id &page &per_page &status &search
 */
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../middleware/auth.php';
require_once __DIR__ . '/lib/config.php';
require_once __DIR__ . '/lib/schema.php';
require_once __DIR__ . '/lib/WaSendWorker.php';   // pulls in the transport, resolver and merge tags
require_once __DIR__ . '/../attributes/lib/schema.php';

whatsapp_ensure_schema();
attributes_ensure_schema();

$jwt = require_jwt();
require_permission('netcore_behaviour', $jwt);

function jin($k, $d = null) { $v = $_REQUEST[$k] ?? null; return ($v === null || $v === '') ? $d : $v; }

/** Audience config in the shape the resolver expects, read off a stored campaign row. */
function wa_campaign_audience_config(array $c): array {
    return [
        'audience_type'       => $c['audience_type'],
        'segment_ids'         => json_decode($c['segment_ids'] ?? '[]', true) ?: [],
        'exclude_segment_ids' => json_decode($c['exclude_segment_ids'] ?? '[]', true) ?: [],
        'list_ids'            => json_decode($c['list_ids'] ?? '[]', true) ?: [],
        'domain_filter'       => '',
    ];
}

/**
 * Everything that must be true before a real send, separated into blocking problems and
 * warnings.
 *
 * The checks worth having are the silent ones. Netcore answers "Request received successfully"
 * and then drops the message when the template name isn't one Meta approved, or when a
 * free-text message goes to someone outside the 24-hour service window. Catching those here is
 * the difference between a visible error and a campaign that reports 4,000 sent with nobody
 * receiving anything.
 */
function wa_validate_for_send(array $campaign): array {
    $blocking = [];
    $warnings = [];

    // Which number this goes out from, and whether that number can actually send. Checked here
    // rather than in the browser because it's server state the wizard can't see.
    $sender = wa_sender_for_campaign($campaign);
    if (!$sender) {
        $blocking[] = 'No sending number selected';
    } else {
        if (wa_sender_api_key($sender) === '') $blocking[] = 'No API key for the selected sending number';
        if ((int)$sender['is_active'] !== 1)   $blocking[] = 'The selected sending number is switched off';
        // Not blocking: `source` is only a webhook routing tag, and messages send fine without
        // it. Without it, though, delivery receipts won't be tied to a webhook by source key,
        // so Delivered/Read may never move even though the messages arrive.
        if (trim((string)$sender['source_id']) === '') {
            $warnings[] = 'This number has no source key set, so delivery receipts may not route back to our webhook — messages will still be delivered, but Delivered/Read could stay at 0.';
        }
    }

    if ($campaign['message_type'] === 'template') {
        if (trim((string)$campaign['template_name']) === '') {
            $blocking[] = 'No template selected';
        } else {
            $vars = json_decode($campaign['variables'] ?? '{}', true) ?: [];
            $bodyNeeded = wa_placeholder_count((string)$campaign['body_text']);
            $bodyGiven  = array_filter((array)($vars['body'] ?? []), fn($v) => trim((string)$v) !== '');
            if (count($bodyGiven) < $bodyNeeded) {
                $blocking[] = 'Template variables are not all filled in';
            }
            if (($campaign['header_type'] ?? 'none') === 'text') {
                $headerNeeded = wa_placeholder_count((string)$campaign['header_text']);
                $headerGiven  = array_filter((array)($vars['header'] ?? []), fn($v) => trim((string)$v) !== '');
                if (count($headerGiven) < $headerNeeded) $blocking[] = 'Template variables are not all filled in';
            }
        }
    } else {
        if (trim((string)$campaign['text_content']) === '') $blocking[] = 'Message text is empty';
        // A free-text (non-template) message is only deliverable inside the 24-hour customer
        // service window — outside it WhatsApp drops it. Worth saying out loud, not blocking.
        $warnings[] = 'Free-text messages only reach contacts who messaged you in the last 24 hours. Use an approved template for everyone else.';
    }

    $audience = wa_resolve_audience_count(wa_campaign_audience_config($campaign));
    if ($audience['count'] === 0) $blocking[] = 'Audience has 0 reachable WhatsApp numbers';
    if ($audience['unreachable'] > 0) {
        $warnings[] = number_format($audience['unreachable']) . ' contact(s) in this audience have no usable phone number and will be skipped.';
    }
    if ($audience['duplicates'] > 0) {
        $warnings[] = number_format($audience['duplicates']) . ' duplicate number(s) were merged — each person receives exactly one message.';
    }

    return [
        'blocking' => array_values(array_unique($blocking)),
        'warnings' => $warnings,
        'audience' => $audience,
        'sender'   => $sender ? [
            'id' => (int)$sender['id'], 'business_number' => $sender['business_number'],
            'display_name' => $sender['display_name'], 'waba_id' => $sender['waba_id'],
        ] : null,
    ];
}

$action = jin('action', '');

if ($action === 'list') {
    $page    = max(1, (int)jin('page', 1));
    $perPage = max(1, min(100, (int)jin('per_page', 10)));
    $status  = jin('status', 'all');
    $search  = trim((string)jin('search', ''));
    $offset  = ($page - 1) * $perPage;

    $where = [];
    if ($status !== 'all' && $status !== '') $where[] = "status='" . $conn->real_escape_string($status) . "'";
    if ($search !== '') $where[] = "name LIKE '%" . $conn->real_escape_string($search) . "%'";
    $whereSql = $where ? 'WHERE ' . implode(' AND ', $where) : '';

    $tr = $conn->query("SELECT COUNT(*) AS c FROM wa_campaigns $whereSql");
    $total = $tr ? (int)$tr->fetch_assoc()['c'] : 0;

    $r = $conn->query("SELECT id, name, tags, status, message_type, template_name, template_category,
                              business_number, sender_id,
                              total_recipients, sent_count, delivered_count, read_count, failed_count,
                              click_count, reply_count, skipped_dedup_count, dedup_enabled,
                              schedule_type, scheduled_at, started_at, completed_at, created_at, updated_at
                         FROM wa_campaigns $whereSql
                        ORDER BY id DESC LIMIT $perPage OFFSET $offset");
    $rows = [];
    while ($r && $row = $r->fetch_assoc()) $rows[] = $row;

    $counts = ['all' => 0, 'draft' => 0, 'scheduled' => 0, 'running' => 0, 'sent' => 0, 'suspended' => 0, 'failed' => 0];
    $cr = $conn->query("SELECT status, COUNT(*) AS c FROM wa_campaigns GROUP BY status");
    while ($cr && $row = $cr->fetch_assoc()) { $counts[$row['status']] = (int)$row['c']; $counts['all'] += (int)$row['c']; }

    api_success([
        'campaigns' => $rows, 'total' => $total, 'page' => $page, 'per_page' => $perPage,
        'pages' => $total > 0 ? (int)ceil($total / $perPage) : 1, 'counts' => $counts,
    ]);
}

if ($action === 'get') {
    $id = (int)jin('id', 0);
    $r = $conn->query("SELECT * FROM wa_campaigns WHERE id=$id LIMIT 1");
    $row = $r ? $r->fetch_assoc() : null;
    if (!$row) api_error('Not found', 404);
    foreach (['segment_ids', 'exclude_segment_ids', 'list_ids'] as $k) {
        $row[$k] = json_decode($row[$k] ?? '[]', true) ?: [];
    }
    $row['buttons']   = json_decode($row['buttons'] ?? '[]', true) ?: [];
    $row['variables'] = json_decode($row['variables'] ?? '{}', true) ?: [];
    api_success(['campaign' => $row]);
}

if ($action === 'save') {
    $id   = (int)jin('id', 0);
    $name = trim((string)jin('name', ''));
    if ($id === 0 && $name === '') api_error('Campaign name required');

    $fields = [
        'name' => 's', 'tags' => 's',
        'ga_source' => 's', 'ga_medium' => 's', 'ga_campaign' => 's', 'ga_content' => 's', 'ga_term' => 's',
        'audience_type' => 's', 'reachable_count' => 'i',
        'sender_id' => 'i',
        'dedup_enabled' => 'i', 'dedup_window_hours' => 'i', 'dedup_scope' => 's',
        'message_type' => 's', 'template_language' => 's', 'template_category' => 's',
        'header_type' => 's', 'header_text' => 's', 'header_media_url' => 's',
        'footer_text' => 's', 'text_content' => 's', 'preview_url' => 'i',
        'schedule_type' => 's',
        'contact_limit_enabled' => 'i', 'contact_limit' => 'i', 'retry_enabled' => 'i',
    ];
    $set = [];
    foreach ($fields as $f => $type) {
        $v = jin($f, null);
        if ($v === null) continue;
        $set[] = $type === 'i' ? "$f=" . (int)$v : "$f='" . $conn->real_escape_string((string)$v) . "'";
    }
    foreach (['segment_ids', 'exclude_segment_ids', 'list_ids'] as $f) {
        if (jin($f, null) === null) continue;
        $arr = json_decode(jin($f), true) ?: [];
        $set[] = "$f='" . $conn->real_escape_string(json_encode(array_values(array_map('intval', $arr)))) . "'";
    }
    // Per-variable values as chosen in the Content step. Stored as-is (they may contain merge
    // tags) and only resolved per recipient at send time.
    if (jin('variables', null) !== null) {
        $vars = json_decode(jin('variables'), true);
        if (!is_array($vars)) $vars = [];
        $set[] = "variables='" . $conn->real_escape_string(json_encode($vars)) . "'";
    }

    /*
     * Snapshot the chosen template's content onto the campaign — exactly like the email
     * builder snapshots content_html. A later edit to the template (or an archive) must not
     * retroactively change what an already-scheduled campaign will send.
     */
    $templateId = jin('template_id', null);
    if ($templateId !== null) {
        $tid = (int)$templateId;
        if ($tid > 0) {
            $tRes = $conn->query("SELECT * FROM wa_templates WHERE id=$tid LIMIT 1");
            $t = $tRes ? $tRes->fetch_assoc() : null;
            if ($t) {
                $set[] = 'template_id=' . $tid;
                $set[] = "template_name='"     . $conn->real_escape_string($t['name']) . "'";
                $set[] = "template_language='" . $conn->real_escape_string($t['language']) . "'";
                $set[] = "template_category='" . $conn->real_escape_string($t['category']) . "'";
                $set[] = "header_type='"       . $conn->real_escape_string($t['header_type']) . "'";
                $set[] = "header_text='"       . $conn->real_escape_string((string)$t['header_text']) . "'";
                $set[] = "header_media_url='"  . $conn->real_escape_string((string)$t['header_media_url']) . "'";
                $set[] = "body_text='"         . $conn->real_escape_string((string)$t['body_text']) . "'";
                $set[] = "footer_text='"       . $conn->real_escape_string((string)$t['footer_text']) . "'";
                $set[] = "buttons='"           . $conn->real_escape_string((string)($t['buttons'] ?: '[]')) . "'";
            }
        } else {
            // Explicit "no template" (switching to a free-text message).
            $set[] = 'template_id=NULL';
            $set[] = "template_name=''";
        }
    }

    if ($id > 0) {
        if ($set) $conn->query("UPDATE wa_campaigns SET " . implode(', ', $set) . " WHERE id=$id");
    } else {
        $set[] = 'created_by=' . (int)($jwt['user_id'] ?? 0);
        $conn->query("INSERT INTO wa_campaigns SET " . implode(', ', $set));
        $id = $conn->insert_id;
    }

    $r = $conn->query("SELECT reachable_count, status FROM wa_campaigns WHERE id=$id LIMIT 1");
    $row = $r ? $r->fetch_assoc() : ['reachable_count' => 0, 'status' => 'draft'];
    api_success(['id' => $id, 'reachable_count' => (int)$row['reachable_count'], 'status' => $row['status']]);
}

if ($action === 'delete') {
    $id = (int)jin('id', 0);
    if (!$id) api_error('id required');
    $conn->query("DELETE FROM wa_campaign_events WHERE campaign_id=$id");
    $conn->query("DELETE FROM wa_campaign_recipients WHERE campaign_id=$id");
    $conn->query("DELETE FROM wa_campaigns WHERE id=$id");
    api_success([]);
}

if ($action === 'duplicate') {
    $id = (int)jin('id', 0);
    $r = $conn->query("SELECT * FROM wa_campaigns WHERE id=$id LIMIT 1");
    $row = $r ? $r->fetch_assoc() : null;
    if (!$row) api_error('Not found', 404);

    $cols = ['name', 'tags', 'ga_source', 'ga_medium', 'ga_campaign', 'ga_content', 'ga_term',
             'sender_id',
             'audience_type', 'segment_ids', 'exclude_segment_ids', 'list_ids',
             'dedup_enabled', 'dedup_window_hours', 'dedup_scope',
             'message_type', 'template_id', 'template_name', 'template_language', 'template_category',
             'header_type', 'header_text', 'header_media_url', 'body_text', 'footer_text', 'buttons',
             'variables', 'text_content', 'preview_url',
             'contact_limit_enabled', 'contact_limit', 'retry_enabled'];
    $vals = [];
    foreach ($cols as $c) {
        if ($c === 'name') { $vals[] = "'" . $conn->real_escape_string($row['name'] . ' (Copy)') . "'"; continue; }
        $v = $row[$c];
        $vals[] = $v === null ? 'NULL' : "'" . $conn->real_escape_string((string)$v) . "'";
    }
    $conn->query("INSERT INTO wa_campaigns (" . implode(',', $cols) . ", created_by)
                  VALUES (" . implode(',', $vals) . ', ' . (int)($jwt['user_id'] ?? 0) . ')');
    api_success(['id' => $conn->insert_id]);
}

if ($action === 'tags') {
    // Collected into a plain list, NOT used as array keys — PHP silently casts any key that
    // looks like a whole number ("171") to an int, which then serializes as a bare JSON number
    // and breaks the frontend's tag.toLowerCase() calls.
    $r = $conn->query("SELECT tags FROM wa_campaigns WHERE tags IS NOT NULL AND tags <> ''");
    $all = [];
    while ($r && $row = $r->fetch_assoc()) {
        foreach (explode(',', $row['tags']) as $t) {
            $t = trim((string)$t);
            if ($t !== '') $all[] = $t;
        }
    }
    $tags = array_map('strval', array_values(array_unique($all)));
    sort($tags, SORT_NATURAL | SORT_FLAG_CASE);
    api_success(['tags' => $tags]);
}

if ($action === 'audience_count') {
    $config = [
        'audience_type'       => jin('audience_type', 'segments'),
        'segment_ids'         => json_decode(jin('segment_ids', '[]'), true) ?: [],
        'exclude_segment_ids' => json_decode(jin('exclude_segment_ids', '[]'), true) ?: [],
        'list_ids'            => json_decode(jin('list_ids', '[]'), true) ?: [],
        'domain_filter'       => '',
    ];
    $resolved = wa_resolve_audience($config);
    $phones   = array_column($resolved['recipients'], 'phone');

    // Opt-outs are always subtracted; the dedup preview is only computed when the toggle is on,
    // since it's the expensive part (a JOIN across every past campaign's recipients).
    $optins   = wa_optin_map($phones);
    $optedOut = count(array_filter($phones, fn($p) => ($optins[$p] ?? '') === 'optout'));

    $dedupSkipped = 0;
    if ((int)jin('dedup_enabled', 0) === 1) {
        $recent = wa_recently_messaged(
            $phones,
            max(1, (int)jin('dedup_window_hours', 24)),
            (string)jin('dedup_scope', 'all_campaigns'),
            jin('template_name', null),
            (int)jin('id', 0)
        );
        $dedupSkipped = count(array_intersect_key(array_flip($phones), $recent));
    }

    $reachable = count($phones) - $optedOut - $dedupSkipped;
    api_success([
        'count'           => max(0, $reachable),
        'raw_count'       => count($phones),
        'unreachable'     => $resolved['unreachable'],
        'duplicates'      => $resolved['duplicates'],
        'opted_out'       => $optedOut,
        'dedup_skipped'   => $dedupSkipped,
    ]);
}

if ($action === 'preflight') {
    $id = (int)jin('id', 0);
    $r = $conn->query("SELECT * FROM wa_campaigns WHERE id=$id LIMIT 1");
    $campaign = $r ? $r->fetch_assoc() : null;
    if (!$campaign) api_error('Not found', 404);
    api_success(wa_validate_for_send($campaign));
}

if ($action === 'send_test') {
    $id = (int)jin('id', 0);
    $r = $conn->query("SELECT * FROM wa_campaigns WHERE id=$id LIMIT 1");
    $campaign = $r ? $r->fetch_assoc() : null;
    if (!$campaign) api_error('Save the campaign before sending a test', 404);

    $raw = (string)jin('phones', '');
    $inputs = array_values(array_filter(array_map('trim', preg_split('/[,;\n]+/', $raw))));
    if (!$inputs) api_error('Enter at least one WhatsApp number');

    $settings  = wa_settings_row() ?: [];
    // A test must go out through the SAME number (and therefore the same API key) the real
    // send will use, or it proves nothing about whether that number is set up correctly.
    $sender    = wa_sender_for_campaign($campaign);
    if (!$sender) api_error('Add a sending number in WhatsApp settings first');
    $transport = new WhatsAppTransport($settings, $sender['source_id'], wa_sender_api_key($sender));
    $cc        = wa_default_cc();
    $attributes = load_all_attributes();

    $results = [];
    foreach ($inputs as $input) {
        $phone = wa_normalize_phone($input, $cc);
        if ($phone === null) {
            $results[] = ['phone' => $input, 'ok' => false, 'error' => 'Not a valid WhatsApp number'];
            continue;
        }

        // If the number belongs to a real student, use their real identity so merge tags and
        // mapped Customer Attributes resolve exactly as they will on the real send — otherwise
        // a test tells you nothing about whether personalization works.
        $phoneE = $conn->real_escape_string($phone);
        $last10 = substr($phone, -10);
        // Matched against the handful of literal shapes a number is actually stored in, rather
        // than wrapping the column in REPLACE()/LIKE — a function on the column defeats any
        // index on `phone` and turns this into a full scan of the users table.
        $candidates = array_unique([$phone, $last10, '+' . $phone, '0' . $last10, '+91' . $last10]);
        $inList = implode(',', array_map(fn($p) => "'" . $conn->real_escape_string($p) . "'", $candidates));
        $uRes = $conn->query("SELECT user_id, fname, lname, email FROM users WHERE phone IN ($inList) LIMIT 1");
        $u = $uRes ? $uRes->fetch_assoc() : null;

        $recipient = [
            'user_id'    => $u['user_id'] ?? null,
            'email'      => $u['email'] ?? '',
            'first_name' => $u['fname'] ?? 'Test',
            'last_name'  => $u['lname'] ?? 'User',
            'phone'      => $phone,
        ];
        $attrTokens = ($attributes && !empty($recipient['email']))
            ? (resolve_attribute_values_batch($attributes, [$recipient])[strtolower($recipient['email'])] ?? [])
            : [];

        $rid = bin2hex(random_bytes(16));
        // Test rows live in the same table (is_test=1) so a test send is auditable and shows up
        // in the report's own "test sends" view — uq_campaign_phone keeps them from clashing
        // with the real audience.
        $conn->query("INSERT INTO wa_campaign_recipients
            (campaign_id, user_id, phone, raw_phone, email, first_name, last_name, is_test, status, rid)
            VALUES ($id, " . ($recipient['user_id'] ? (int)$recipient['user_id'] : 'NULL') . ", '$phoneE',
                    '" . $conn->real_escape_string($input) . "',
                    '" . $conn->real_escape_string((string)$recipient['email']) . "',
                    '" . $conn->real_escape_string((string)$recipient['first_name']) . "',
                    '" . $conn->real_escape_string((string)$recipient['last_name']) . "',
                    1, 'pending', '$rid')
            ON DUPLICATE KEY UPDATE status='pending', rid=VALUES(rid), attempts=0, error_message=NULL");
        $recIdRes = $conn->query("SELECT id, rid FROM wa_campaign_recipients WHERE campaign_id=$id AND is_test=1 AND phone='$phoneE' LIMIT 1");
        $recRow = $recIdRes ? $recIdRes->fetch_assoc() : null;
        $recId = (int)($recRow['id'] ?? 0);
        $rid   = (string)($recRow['rid'] ?? $rid);

        $rendered = wa_render_for_recipient($campaign, $recipient, $attrTokens);
        $res = $transport->sendMessage($phone, $rendered['content'], $rid);

        if ($recId) {
            if ($res['ok']) {
                $mid = $conn->real_escape_string((string)($res['message_id'] ?? ''));
                $body = $conn->real_escape_string(mb_substr($rendered['preview'], 0, 4000));
                $conn->query("UPDATE wa_campaign_recipients SET status='sent', sent_at=NOW(), wa_message_id='$mid', rendered_body='$body' WHERE id=$recId");
            } else {
                $err = $conn->real_escape_string(substr((string)($res['error'] ?? ''), 0, 480));
                $conn->query("UPDATE wa_campaign_recipients SET status='failed', failed_at=NOW(), error_message='$err' WHERE id=$recId");
            }
        }
        $results[] = ['phone' => $phone, 'ok' => $res['ok'], 'error' => $res['error'] ?? null, 'message_id' => $res['message_id'] ?? null];
    }
    api_success([
        'results' => $results,
        'sent_from' => $sender['business_number'],
    ]);
}

if ($action === 'send_now') {
    $id = (int)jin('id', 0);
    $r = $conn->query("SELECT * FROM wa_campaigns WHERE id=$id LIMIT 1");
    $campaign = $r ? $r->fetch_assoc() : null;
    if (!$campaign) api_error('Not found', 404);

    $checks = wa_validate_for_send($campaign);
    if ($checks['blocking']) api_error('Cannot send: ' . implode('; ', $checks['blocking']));

    // Recipients are NOT materialized here — the resolve + insert happens inside the worker's
    // background run, which has no web-request time limit, so this click stays instant even for
    // a 40k-number audience. The count below is a preview, not the queued rows.
    // Snapshot the sending identity now. Changing the default number, editing a Source ID or
    // deleting a sender tomorrow must not silently re-route a campaign that is already running.
    $sender = wa_sender_for_campaign($campaign);
    $srcE  = $conn->real_escape_string((string)($sender['source_id'] ?? ''));
    $numE  = $conn->real_escape_string((string)($sender['business_number'] ?? ''));
    $wabaE = $conn->real_escape_string((string)($sender['waba_id'] ?? ''));
    $sid   = (int)($sender['id'] ?? 0);
    $conn->query("UPDATE wa_campaigns
                     SET status='running', schedule_type='now', scheduled_at=NULL, started_at=NOW(),
                         total_recipients=0, sent_count=0, failed_count=0, materialized_at=NULL,
                         source_id='$srcE', business_number='$numE', waba_id='$wabaE'"
                         . ($sid ? ", sender_id=$sid" : '') . "
                   WHERE id=$id");
    wa_trigger_worker_async($id);
    api_success(['queued' => $checks['audience']['count']]);
}

if ($action === 'schedule') {
    $id = (int)jin('id', 0);
    $at = trim((string)jin('scheduled_at', ''));
    if (!$at) api_error('Pick a date & time');
    $ts = strtotime($at);
    if (!$ts || $ts <= time()) api_error('Scheduled time must be in the future');

    $r = $conn->query("SELECT * FROM wa_campaigns WHERE id=$id LIMIT 1");
    $campaign = $r ? $r->fetch_assoc() : null;
    if (!$campaign) api_error('Not found', 404);

    $checks = wa_validate_for_send($campaign);
    if ($checks['blocking']) api_error('Cannot schedule: ' . implode('; ', $checks['blocking']));

    $sender = wa_sender_for_campaign($campaign);
    $atE   = $conn->real_escape_string(date('Y-m-d H:i:s', $ts));
    $srcE  = $conn->real_escape_string((string)($sender['source_id'] ?? ''));
    $numE  = $conn->real_escape_string((string)($sender['business_number'] ?? ''));
    $wabaE = $conn->real_escape_string((string)($sender['waba_id'] ?? ''));
    $sid   = (int)($sender['id'] ?? 0);
    // The AUDIENCE is deliberately re-resolved by the worker when the time arrives (a reminder
    // scheduled for tomorrow should go to whoever qualifies tomorrow), but the SENDING NUMBER
    // is frozen here — "send from this number" is an explicit choice, not a moving target.
    $conn->query("UPDATE wa_campaigns
                     SET status='scheduled', schedule_type='later', scheduled_at='$atE',
                         total_recipients=0, materialized_at=NULL,
                         source_id='$srcE', business_number='$numE', waba_id='$wabaE'"
                         . ($sid ? ", sender_id=$sid" : '') . "
                   WHERE id=$id");
    api_success(['queued' => $checks['audience']['count'], 'scheduled_at' => $atE]);
}

if ($action === 'pause') {
    $id = (int)jin('id', 0);
    $r = $conn->query("SELECT status FROM wa_campaigns WHERE id=$id LIMIT 1");
    $row = $r ? $r->fetch_assoc() : null;
    if (!$row) api_error('Not found', 404);
    if (!in_array($row['status'], ['draft', 'scheduled', 'running'], true)) {
        api_error('Only draft, scheduled or running campaigns can be suspended');
    }
    $conn->query("UPDATE wa_campaigns SET status='suspended' WHERE id=$id");
    api_success([]);
}

if ($action === 'resume') {
    $id = (int)jin('id', 0);
    $r = $conn->query("SELECT * FROM wa_campaigns WHERE id=$id LIMIT 1");
    $campaign = $r ? $r->fetch_assoc() : null;
    if (!$campaign) api_error('Not found', 404);
    if ($campaign['status'] !== 'suspended') api_error('Only suspended campaigns can be resumed');

    if ($campaign['schedule_type'] === 'later' && $campaign['scheduled_at'] && strtotime($campaign['scheduled_at']) > time()) {
        $conn->query("UPDATE wa_campaigns SET status='scheduled' WHERE id=$id");
    } else {
        $conn->query("UPDATE wa_campaigns SET status='running' WHERE id=$id");
        wa_trigger_worker_async($id);
    }
    api_success([]);
}

if ($action === 'requeue') {
    $id = (int)jin('id', 0);
    $r = $conn->query("SELECT total_recipients FROM wa_campaigns WHERE id=$id LIMIT 1");
    $row = $r ? $r->fetch_assoc() : null;
    if (!$row) api_error('Not found', 404);

    if ((int)$row['total_recipients'] === 0) {
        // This campaign never had any recipients at all. Clearing materialized_at forces a
        // fresh audience resolve on the next tick instead of just relabelling the status over
        // a check that has already been made and will never change on its own.
        $conn->query("UPDATE wa_campaigns SET status='running', materialized_at=NULL WHERE id=$id");
    } else {
        // Real per-number failures — the audience was resolved correctly, so retry only those.
        $conn->query("UPDATE wa_campaign_recipients SET status='pending', attempts=0, error_message=NULL, error_code=NULL
                       WHERE campaign_id=$id AND status='failed' AND is_test=0");
        $conn->query("UPDATE wa_campaigns SET status='running', failed_count=0 WHERE id=$id AND status IN ('sent','failed','suspended')");
    }
    wa_trigger_worker_async($id);
    api_success([]);
}

if ($action === 'report') {
    $id = (int)jin('id', 0);
    $r = $conn->query("SELECT * FROM wa_campaigns WHERE id=$id LIMIT 1");
    $campaign = $r ? $r->fetch_assoc() : null;
    if (!$campaign) api_error('Not found', 404);
    $campaign['buttons']   = json_decode($campaign['buttons'] ?? '[]', true) ?: [];
    $campaign['variables'] = json_decode($campaign['variables'] ?? '{}', true) ?: [];

    $statusCounts = ['pending' => 0, 'processing' => 0, 'sent' => 0, 'delivered' => 0, 'read' => 0, 'failed' => 0, 'skipped' => 0];
    $sc = $conn->query("SELECT status, COUNT(*) AS c FROM wa_campaign_recipients WHERE campaign_id=$id AND is_test=0 GROUP BY status");
    while ($sc && $row = $sc->fetch_assoc()) $statusCounts[$row['status']] = (int)$row['c'];

    $evR = $conn->query("SELECT e.event_type, e.error_code, e.detail, e.created_at, r.phone
                           FROM wa_campaign_events e
                           JOIN wa_campaign_recipients r ON r.id = e.recipient_id
                          WHERE e.campaign_id=$id AND r.is_test=0
                          ORDER BY e.id DESC LIMIT 30");
    $events = [];
    while ($evR && $row = $evR->fetch_assoc()) $events[] = $row;

    // The provider's own rejection text, grouped — one bad template name produces thousands of
    // identical failures, and "what is Netcore actually saying" should be one line, not a scroll.
    $fgR = $conn->query("SELECT COALESCE(error_message,'Unknown error') AS error_message,
                                COALESCE(error_code,'') AS error_code, COUNT(*) AS c
                           FROM wa_campaign_recipients
                          WHERE campaign_id=$id AND status='failed' AND is_test=0
                          GROUP BY error_message, error_code ORDER BY c DESC LIMIT 20");
    $failureGroups = [];
    while ($fgR && $row = $fgR->fetch_assoc()) $failureGroups[] = $row;

    $testR = $conn->query("SELECT phone, status, error_message, sent_at
                             FROM wa_campaign_recipients WHERE campaign_id=$id AND is_test=1
                            ORDER BY id DESC LIMIT 20");
    $tests = [];
    while ($testR && $row = $testR->fetch_assoc()) $tests[] = $row;

    api_success([
        'campaign' => $campaign, 'recipient_status_counts' => $statusCounts,
        'events' => $events, 'failure_groups' => $failureGroups, 'test_sends' => $tests,
    ]);
}

if ($action === 'recipients') {
    $id      = (int)jin('id', 0);
    $page    = max(1, (int)jin('page', 1));
    $perPage = max(1, min(100, (int)jin('per_page', 25)));
    $status  = jin('status', 'all');
    $search  = trim((string)jin('search', ''));
    $offset  = ($page - 1) * $perPage;

    $where = ["campaign_id=$id", 'is_test=0'];
    if ($status !== 'all' && $status !== '') $where[] = "status='" . $conn->real_escape_string($status) . "'";
    if ($search !== '') {
        $s = $conn->real_escape_string($search);
        $where[] = "(phone LIKE '%$s%' OR first_name LIKE '%$s%' OR last_name LIKE '%$s%' OR email LIKE '%$s%')";
    }
    $whereSql = 'WHERE ' . implode(' AND ', $where);

    $tr = $conn->query("SELECT COUNT(*) AS c FROM wa_campaign_recipients $whereSql");
    $total = $tr ? (int)$tr->fetch_assoc()['c'] : 0;

    $r = $conn->query("SELECT id, phone, first_name, last_name, email, status, error_message,
                              wa_message_id, sent_at, delivered_at, read_at, click_count
                         FROM wa_campaign_recipients $whereSql
                        ORDER BY id ASC LIMIT $perPage OFFSET $offset");
    $rows = [];
    while ($r && $row = $r->fetch_assoc()) $rows[] = $row;

    api_success([
        'recipients' => $rows, 'total' => $total, 'page' => $page, 'per_page' => $perPage,
        'pages' => $total > 0 ? (int)ceil($total / $perPage) : 1,
    ]);
}

api_error('Invalid action');

<?php
/*
 * whatsapp_ensure_schema() — idempotent CREATE TABLE IF NOT EXISTS for the 6 tables backing
 * the WhatsApp Campaigns builder. Called at the top of every entrypoint in this feature,
 * mirroring campaigns/lib/schema.php's campaigns_ensure_schema(). SQL is documented (kept in
 * sync by hand) in ../whatsapp_schema.sql.
 *
 * Everything here is metadata-only (CREATE IF NOT EXISTS / SHOW COLUMNS) except the single
 * settings-row seed, which is guarded behind a SELECT for exactly the reason spelled out in
 * the email version: it's the one real row-level unique-key write, and concurrent requests
 * can deadlock on it.
 */
require_once __DIR__ . '/config.php';

function whatsapp_ensure_schema() {
    global $conn;
    if (!$conn) return;

    try {
        $conn->query("CREATE TABLE IF NOT EXISTS wa_campaigns (
            id                  INT AUTO_INCREMENT PRIMARY KEY,
            name                VARCHAR(255) NOT NULL,
            tags                VARCHAR(500) DEFAULT NULL,
            status              ENUM('draft','scheduled','running','sent','suspended','failed') NOT NULL DEFAULT 'draft',
            channel             ENUM('whatsapp') NOT NULL DEFAULT 'whatsapp',

            -- Setup step 'Advanced' — stored for reference, same as the email builder
            ga_source VARCHAR(255) DEFAULT NULL, ga_medium VARCHAR(255) DEFAULT NULL, ga_campaign VARCHAR(255) DEFAULT NULL,
            ga_content VARCHAR(255) DEFAULT NULL, ga_term VARCHAR(255) DEFAULT NULL,

            -- Audience step (identical semantics to email — the SAME segments and lists feed
            -- both channels; only the reachability rule differs: a phone number, not an email)
            audience_type       ENUM('all_contacts','segments') NOT NULL DEFAULT 'segments',
            segment_ids         JSON DEFAULT NULL,
            exclude_segment_ids JSON DEFAULT NULL,
            list_ids            JSON DEFAULT NULL,
            reachable_count     INT NOT NULL DEFAULT 0,

            -- Deduplication: 'Avoid duplicate communication to contacts'. Within a single
            -- campaign duplicates are collapsed unconditionally (uq_campaign_phone below);
            -- these columns control the OPTIONAL cross-campaign window on top of that.
            dedup_enabled       TINYINT(1) NOT NULL DEFAULT 0,
            dedup_window_hours  INT NOT NULL DEFAULT 24,
            dedup_scope         ENUM('all_campaigns','same_template') NOT NULL DEFAULT 'all_campaigns',
            skipped_dedup_count INT NOT NULL DEFAULT 0,

            -- Content step
            message_type      ENUM('template','text') NOT NULL DEFAULT 'template',
            template_id       INT DEFAULT NULL,
            template_name     VARCHAR(255) DEFAULT NULL,
            template_language VARCHAR(16) DEFAULT 'en',
            template_category VARCHAR(32) DEFAULT NULL,
            header_type       ENUM('none','text','image','video','document') NOT NULL DEFAULT 'none',
            header_text       VARCHAR(500) DEFAULT NULL,
            header_media_url  VARCHAR(1000) DEFAULT NULL,
            body_text         TEXT DEFAULT NULL,
            footer_text       VARCHAR(255) DEFAULT NULL,
            buttons           JSON DEFAULT NULL,
            -- Per-variable values chosen in the wizard, e.g.
            -- {'header':['XX_USER_FNAME_XX'],'body':['XX_USER_FNAME_XX','iCAT 174'],'button_url_suffix':''}
            -- Values may contain merge tags; they're resolved per recipient at send time.
            variables         JSON DEFAULT NULL,
            text_content      TEXT DEFAULT NULL,
            preview_url       TINYINT(1) NOT NULL DEFAULT 1,

            -- Sending identity, snapshotted when the campaign is sent/scheduled
            -- Sending identity, snapshotted from wa_senders when the campaign is sent/scheduled
            -- so a later edit to (or deletion of) the sender can't change what an already-
            -- queued campaign goes out as.
            source_id       VARCHAR(100) DEFAULT NULL,
            business_number VARCHAR(32) DEFAULT NULL,
            sender_id       INT DEFAULT NULL,
            waba_id         VARCHAR(64) DEFAULT NULL,

            -- Schedule step
            schedule_type   ENUM('now','later') NOT NULL DEFAULT 'now',
            scheduled_at    DATETIME DEFAULT NULL,
            contact_limit_enabled TINYINT(1) NOT NULL DEFAULT 0,
            contact_limit   INT DEFAULT NULL,
            retry_enabled   TINYINT(1) NOT NULL DEFAULT 1,

            -- Denormalized rollup stats
            total_recipients INT NOT NULL DEFAULT 0,
            sent_count INT NOT NULL DEFAULT 0, delivered_count INT NOT NULL DEFAULT 0,
            read_count INT NOT NULL DEFAULT 0, failed_count INT NOT NULL DEFAULT 0,
            click_count INT NOT NULL DEFAULT 0, reply_count INT NOT NULL DEFAULT 0,

            created_by  BIGINT UNSIGNED DEFAULT NULL,
            created_at  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            started_at DATETIME DEFAULT NULL, completed_at DATETIME DEFAULT NULL, materialized_at DATETIME DEFAULT NULL,

            INDEX idx_status_scheduled (status, scheduled_at),
            INDEX idx_created_at (created_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

        /*
         * uq_campaign_phone is the deduplication guarantee, enforced by the database rather
         * than by application bookkeeping: the materializer inserts with INSERT IGNORE, so a
         * number reachable through three different selected segments/lists collapses to
         * exactly one row — there is no code path that can send the same person the same
         * campaign twice. is_test is part of the key so a test send to your own number never
         * blocks that number from also being in the real audience.
         */
        $conn->query("CREATE TABLE IF NOT EXISTS wa_campaign_recipients (
            id            BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            campaign_id   INT NOT NULL,
            user_id       BIGINT UNSIGNED DEFAULT NULL,
            phone         VARCHAR(24) NOT NULL,
            raw_phone     VARCHAR(32) DEFAULT NULL,
            email         VARCHAR(255) DEFAULT NULL,
            first_name    VARCHAR(255) DEFAULT NULL, last_name VARCHAR(255) DEFAULT NULL,
            is_test       TINYINT(1) NOT NULL DEFAULT 0,
            status        ENUM('pending','processing','sent','delivered','read','failed','skipped') NOT NULL DEFAULT 'pending',
            skip_reason   VARCHAR(190) DEFAULT NULL,
            rid           CHAR(32) NOT NULL,
            attempts      TINYINT UNSIGNED NOT NULL DEFAULT 0,
            error_code    VARCHAR(64) DEFAULT NULL,
            error_message VARCHAR(500) DEFAULT NULL,
            wa_message_id VARCHAR(120) DEFAULT NULL,
            rendered_body TEXT DEFAULT NULL,
            queued_at     TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            sent_at DATETIME DEFAULT NULL, delivered_at DATETIME DEFAULT NULL,
            read_at DATETIME DEFAULT NULL, failed_at DATETIME DEFAULT NULL,
            click_count INT NOT NULL DEFAULT 0,

            UNIQUE INDEX uq_rid (rid),
            UNIQUE INDEX uq_campaign_phone (campaign_id, is_test, phone),
            INDEX idx_campaign_status (campaign_id, status),
            INDEX idx_wa_message_id (wa_message_id),
            INDEX idx_phone_sent (phone, sent_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

        $conn->query("CREATE TABLE IF NOT EXISTS wa_campaign_events (
            id           BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            campaign_id  INT NOT NULL,
            recipient_id BIGINT UNSIGNED NOT NULL,
            event_type   ENUM('sent','delivered','read','failed','button_click','replied') NOT NULL,
            error_code   VARCHAR(64) DEFAULT NULL,
            detail       VARCHAR(500) DEFAULT NULL,
            meta         JSON DEFAULT NULL,
            created_at   TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_campaign_type (campaign_id, event_type),
            INDEX idx_recipient (recipient_id),
            INDEX idx_created_at (created_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

        /*
         * Our own record of a WhatsApp message template. WhatsApp itself only ever accepts a
         * template that Meta has already APPROVED, so `name`/`language` here must match the
         * approved template exactly — everything else (body preview, variable labels, sample
         * values) exists so the wizard can render a real preview and offer a variable-mapping
         * UI without a round-trip to the provider on every keystroke.
         */
        $conn->query("CREATE TABLE IF NOT EXISTS wa_templates (
            id              INT AUTO_INCREMENT PRIMARY KEY,
            name            VARCHAR(255) NOT NULL,
            display_name    VARCHAR(255) DEFAULT NULL,
            category        ENUM('marketing','utility','authentication') NOT NULL DEFAULT 'utility',
            language        VARCHAR(16) NOT NULL DEFAULT 'en',
            header_type     ENUM('none','text','image','video','document') NOT NULL DEFAULT 'none',
            header_text     VARCHAR(500) DEFAULT NULL,
            header_media_url VARCHAR(1000) DEFAULT NULL,
            body_text       TEXT NOT NULL,
            footer_text     VARCHAR(255) DEFAULT NULL,
            buttons         JSON DEFAULT NULL,
            variable_labels JSON DEFAULT NULL,
            sample_values   JSON DEFAULT NULL,
            approval_status ENUM('approved','pending','rejected','unknown') NOT NULL DEFAULT 'pending',
            status          ENUM('active','archived') NOT NULL DEFAULT 'active',
            created_by      BIGINT UNSIGNED DEFAULT NULL,
            created_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            UNIQUE INDEX uq_name_lang (name, language),
            INDEX idx_status (status, category)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

        /*
         * Account-level credentials ONLY — one row, one API key.
         *
         * The `source_id`/`waba_id`/`business_number`/`business_name` columns are legacy: the
         * first build assumed a single sending number. They are kept purely so the one-time
         * migration below can lift their values into wa_senders, and are no longer read or
         * written by anything else. Who a campaign sends AS now lives in wa_senders.
         */
        $conn->query("CREATE TABLE IF NOT EXISTS wa_settings (
            id                   INT AUTO_INCREMENT PRIMARY KEY,
            provider             VARCHAR(32) NOT NULL DEFAULT 'netcore',
            is_active            TINYINT(1) NOT NULL DEFAULT 1,
            api_key              TEXT DEFAULT NULL,
            api_base_url         VARCHAR(500) DEFAULT NULL,
            source_id            VARCHAR(100) DEFAULT NULL,
            waba_id              VARCHAR(64) DEFAULT NULL,
            business_number      VARCHAR(32) DEFAULT NULL,
            business_name        VARCHAR(255) DEFAULT NULL,
            default_country_code VARCHAR(6) NOT NULL DEFAULT '91',
            webhook_secret       VARCHAR(255) DEFAULT NULL,
            updated_at           TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            UNIQUE INDEX uq_provider (provider)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

        /*
         * One row per sending number — the shape Netcore's own panel exposes, where a WABA
         * (the account, e.g. 1229117948963194) owns several business numbers and each number
         * has its OWN API key, generated under Business number → Edit → Integrate API.
         *
         * That per-number key is what makes a message go out from that number; there is no
         * separate sender id in the payload. `waba_id` groups numbers for the picker and is
         * never sent. `source_id` is optional and unrelated to identity — it is the routing
         * tag matched against a webhook's "Source key / callbackData" so delivery receipts
         * come back to the right endpoint.
         */
        $conn->query("CREATE TABLE IF NOT EXISTS wa_senders (
            id              INT AUTO_INCREMENT PRIMARY KEY,
            waba_id         VARCHAR(64) NOT NULL,
            waba_name       VARCHAR(255) DEFAULT NULL,
            business_number VARCHAR(32) NOT NULL,
            display_name    VARCHAR(255) DEFAULT NULL,
            api_key         TEXT DEFAULT NULL,
            source_id       VARCHAR(100) DEFAULT NULL,
            quality_rating  VARCHAR(32) DEFAULT NULL,
            messaging_limit VARCHAR(64) DEFAULT NULL,
            is_default      TINYINT(1) NOT NULL DEFAULT 0,
            is_active       TINYINT(1) NOT NULL DEFAULT 1,
            notes           VARCHAR(500) DEFAULT NULL,
            created_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            UNIQUE INDEX uq_number (business_number),
            INDEX idx_waba (waba_id, is_active)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

        /*
         * WhatsApp will not deliver to a number that hasn't opted in. This mirrors the
         * provider's consent state locally so the wizard can warn BEFORE a send instead of
         * discovering it as a per-number failure afterwards; the provider remains the source
         * of truth, this is a cache written whenever we call the consent API ourselves.
         */
        $conn->query("CREATE TABLE IF NOT EXISTS wa_optins (
            id         BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            phone      VARCHAR(24) NOT NULL,
            status     ENUM('optin','optout') NOT NULL DEFAULT 'optin',
            source     VARCHAR(32) DEFAULT 'WEB',
            updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            UNIQUE INDEX uq_phone (phone)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

        // Guarded separately — the one real row-level write in this function. After the first
        // request seeds it, the SELECT finds a row and nothing is attempted again.
        $seed = $conn->query("SELECT 1 FROM wa_settings LIMIT 1");
        if (!$seed || $seed->num_rows === 0) {
            $base = $conn->real_escape_string(WA_DEFAULT_API_BASE);
            $cc   = $conn->real_escape_string(WA_DEFAULT_COUNTRY_CODE);
            // api_key/source_id are left blank on purpose: the Settings page is the one place
            // credentials are entered, and a blank key produces a clear "not configured yet"
            // banner instead of silent 401s from a placeholder.
            $conn->query("INSERT IGNORE INTO wa_settings
                (provider, is_active, api_key, api_base_url, default_country_code)
                VALUES ('netcore', 1, '', '$base', '$cc')");
        }

        /*
         * One-time lift of the old single-sender columns into wa_senders. Guarded on the table
         * being empty AND the legacy columns holding something, so it runs at most once and is
         * a no-op on a fresh install (where those columns were never filled in).
         */
        $senderCheck = $conn->query("SELECT 1 FROM wa_senders LIMIT 1");
        if (!$senderCheck || $senderCheck->num_rows === 0) {
            $legacy = $conn->query("SELECT source_id, waba_id, business_number, business_name
                                      FROM wa_settings WHERE provider='netcore' LIMIT 1");
            $lrow = $legacy ? $legacy->fetch_assoc() : null;
            $hasLegacy = $lrow && (trim((string)$lrow['source_id']) !== '' || trim((string)$lrow['business_number']) !== '');
            if ($hasLegacy) {
                $conn->query("INSERT IGNORE INTO wa_senders
                    (waba_id, waba_name, business_number, display_name, source_id, is_default, is_active) VALUES ("
                    . "'" . $conn->real_escape_string((string)$lrow['waba_id']) . "', "
                    . "'" . $conn->real_escape_string((string)$lrow['business_name']) . "', "
                    . "'" . $conn->real_escape_string((string)($lrow['business_number'] ?: 'unknown')) . "', "
                    . "'" . $conn->real_escape_string((string)$lrow['business_name']) . "', "
                    . "'" . $conn->real_escape_string((string)$lrow['source_id']) . "', 1, 1)");
            }
        }

        // Additive columns for a DB created by the first build of this feature (which had no
        // sender concept at all).
        $chk = $conn->query("SHOW COLUMNS FROM wa_campaigns LIKE 'sender_id'");
        if ($chk && $chk->num_rows === 0) {
            $conn->query("ALTER TABLE wa_campaigns ADD COLUMN sender_id INT DEFAULT NULL AFTER business_number");
            $conn->query("ALTER TABLE wa_campaigns ADD COLUMN waba_id VARCHAR(64) DEFAULT NULL AFTER sender_id");
        }
        // Per-number API key, added once it became clear Netcore issues the key per business
        // number rather than per account. Seeded from the account key so an install that was
        // already sending keeps working with no re-entry.
        $chk2 = $conn->query("SHOW COLUMNS FROM wa_senders LIKE 'api_key'");
        if ($chk2 && $chk2->num_rows === 0) {
            $conn->query("ALTER TABLE wa_senders ADD COLUMN api_key TEXT DEFAULT NULL AFTER display_name");
            $conn->query("UPDATE wa_senders s
                            JOIN wa_settings t ON t.provider = 'netcore'
                             SET s.api_key = t.api_key
                           WHERE (s.api_key IS NULL OR s.api_key = '') AND t.api_key <> ''");
        }
    } catch (\Throwable $e) {
        // Another concurrent request is running this same idempotent setup. Every statement
        // above is CREATE-IF-NOT-EXISTS / INSERT-IGNORE, so whoever wins still leaves the
        // schema correct and this request continues instead of fatal-erroring the page.
        error_log('whatsapp_ensure_schema: ' . $e->getMessage());
    }
}

/** The single settings row (account-level credentials), or null before it's seeded. */
function wa_settings_row(): ?array {
    global $conn;
    $r = $conn->query("SELECT * FROM wa_settings WHERE provider='netcore' LIMIT 1");
    $row = $r ? $r->fetch_assoc() : null;
    return $row ?: null;
}

/** Every configured sending number, default first. */
function wa_senders_all(bool $activeOnly = false): array {
    global $conn;
    $where = $activeOnly ? 'WHERE is_active = 1' : '';
    $r = $conn->query("SELECT * FROM wa_senders $where ORDER BY is_default DESC, waba_id ASC, id ASC");
    $rows = [];
    while ($r && $row = $r->fetch_assoc()) $rows[] = $row;
    return $rows;
}

function wa_sender_by_id(?int $id): ?array {
    global $conn;
    if (!$id) return null;
    $r = $conn->query("SELECT * FROM wa_senders WHERE id=" . (int)$id . ' LIMIT 1');
    $row = $r ? $r->fetch_assoc() : null;
    return $row ?: null;
}

/** The number a campaign uses when it hasn't picked one: the flagged default, else the first
 *  active number that actually has an API key (one without cannot send). */
function wa_default_sender(): ?array {
    global $conn;
    $r = $conn->query("SELECT * FROM wa_senders
                        WHERE is_active = 1
                        ORDER BY is_default DESC, (api_key IS NULL OR api_key = '') ASC, id ASC
                        LIMIT 1");
    $row = $r ? $r->fetch_assoc() : null;
    return $row ?: null;
}

/**
 * The API key a given sender sends with: its own, falling back to the account-level key.
 *
 * The fallback exists for the single-number case and for installs that entered one key before
 * this was per-number — with two numbers configured, each needs its own or both would go out
 * as whichever number the shared key belongs to.
 */
function wa_sender_api_key(?array $sender): string {
    $own = trim((string)($sender['api_key'] ?? ''));
    if ($own !== '') return $own;
    $settings = wa_settings_row() ?: [];
    return trim((string)($settings['api_key'] ?? ''));
}

/**
 * The sender a given campaign will actually go out through.
 *
 * Falls back to the default number when the campaign's chosen sender was deleted, rather than
 * failing the send — but the caller still validates that whatever comes back has a Source ID,
 * because sending without one is accepted by the API and silently discarded.
 */
function wa_sender_for_campaign(array $campaign): ?array {
    $chosen = wa_sender_by_id(isset($campaign['sender_id']) ? (int)$campaign['sender_id'] : null);
    return $chosen ?: wa_default_sender();
}

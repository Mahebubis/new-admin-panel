<?php
/*
 * The WhatsApp campaign send pipeline: materialize audience → claim a batch → render →
 * send concurrently → write outcomes back.
 *
 * Structurally a sibling of campaigns/lib/SendWorker.php (same flock'd cron + instant-kick
 * model, same three-phase batch, same "retryable failures don't burn an attempt" rule), with
 * three WhatsApp-specific differences:
 *
 *   1. Recipients are numbers, not addresses — see WaAudienceResolver.php.
 *   2. Deduplication runs at materialize time and is recorded, not silently applied.
 *   3. `sent` means the provider ACCEPTED the message. delivered/read only ever come from
 *      the webhook — a 200 from the send API is not evidence a phone ever showed anything.
 */
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/schema.php';
require_once __DIR__ . '/WhatsAppTransport.php';
require_once __DIR__ . '/WaParallelSender.php';
// Required at TOP LEVEL, never lazily inside a function: WaAudienceResolver pulls in the
// email pipeline's AudienceResolver, which pulls in netcore/lib/segment_sql.php, whose
// $EVENT_SOURCE/$PAYLOAD_COLUMNS are plain top-level variables. Loading that file from inside
// a function traps those arrays in the function's LOCAL scope and every segment then silently
// resolves to zero users. (This exact bug is documented in campaigns/lib/SendWorker.php.)
require_once __DIR__ . '/WaAudienceResolver.php';
require_once __DIR__ . '/../../campaigns/lib/MergeTags.php';
require_once __DIR__ . '/../../campaigns/lib/AttributeResolver.php';

/** One timestamped line per event in wa-worker.log — "did cron run", "how many numbers did it
 *  find", "what did Netcore actually say" answerable without SSH/DB access. */
function wa_log(string $msg): void {
    @file_put_contents(WA_WORKER_LOG_PATH, '[' . date('Y-m-d H:i:s') . '] ' . $msg . "\n", FILE_APPEND | LOCK_EX);
}

/** Flip due `scheduled` campaigns to `running`. Uses PHP's clock, not MySQL's NOW() — the two
 *  can sit in different timezones on shared hosting, and scheduled_at was written with PHP's
 *  date(), so comparing against NOW() would silently shift when a campaign actually fires. */
function wa_activate_due_scheduled(): void {
    global $conn;
    $now = $conn->real_escape_string(date('Y-m-d H:i:s'));
    $dueR = $conn->query("SELECT id, name, scheduled_at FROM wa_campaigns WHERE status='scheduled' AND scheduled_at <= '$now'");
    $due = [];
    while ($dueR && $row = $dueR->fetch_assoc()) $due[] = "#{$row['id']} \"{$row['name']}\" (was due {$row['scheduled_at']})";

    static $loggedOnce = false;
    if (!$loggedOnce || $due) {
        wa_log('checking due scheduled campaigns at server-time ' . $now . ' -> ' . ($due ? implode(', ', $due) : 'none due'));
        $loggedOnce = true;
    }
    $conn->query("UPDATE wa_campaigns SET status='running', started_at=IFNULL(started_at, '$now')
                  WHERE status='scheduled' AND scheduled_at <= '$now'");
}

/**
 * Resolves the audience and writes recipient rows — run inside the background worker, not on
 * the admin's "Send now" click, so that click stays instant even for a 40k-number audience.
 *
 * Returns the number of rows actually queued (after every dedup/limit rule).
 */
function wa_materialize_recipients(int $campaignId): int {
    global $conn;

    $r = $conn->query("SELECT * FROM wa_campaigns WHERE id=$campaignId LIMIT 1");
    if (!$r) {
        // mysqli returns false silently on a failed query (e.g. a column an older DB never
        // got); without this that's indistinguishable from "campaign not found".
        wa_log("campaign #$campaignId: FATAL — campaign SELECT failed: " . $conn->error);
        return 0;
    }
    $campaign = $r->fetch_assoc();
    if (!$campaign) return 0;

    $config = [
        'audience_type'       => $campaign['audience_type'],
        'segment_ids'         => json_decode($campaign['segment_ids'] ?? '[]', true) ?: [],
        'exclude_segment_ids' => json_decode($campaign['exclude_segment_ids'] ?? '[]', true) ?: [],
        'list_ids'            => json_decode($campaign['list_ids'] ?? '[]', true) ?: [],
        'domain_filter'       => '', // email-only concept; never narrows a WhatsApp audience
    ];

    // Clear any previous non-test rows before re-materializing (re-scheduling a draft, requeue
    // after a 0-recipient run, etc.).
    $conn->query("DELETE FROM wa_campaign_recipients WHERE campaign_id=$campaignId AND is_test=0");

    $resolved = wa_resolve_audience($config);
    $rows = $resolved['recipients'];
    wa_log("campaign #$campaignId: audience -> " . count($rows) . " reachable number(s), {$resolved['unreachable']} without a usable phone, {$resolved['duplicates']} duplicate(s) merged");

    $skippedDedup = 0;

    // ── Cross-campaign deduplication ────────────────────────────────────────────────────
    if ((int)$campaign['dedup_enabled'] === 1) {
        $phones = array_column($rows, 'phone');
        $recent = wa_recently_messaged(
            $phones,
            (int)$campaign['dedup_window_hours'],
            (string)$campaign['dedup_scope'],
            $campaign['template_name'],
            $campaignId
        );
        if ($recent) {
            $before = count($rows);
            $rows = array_values(array_filter($rows, fn($x) => !isset($recent[$x['phone']])));
            $skippedDedup = $before - count($rows);
            wa_log("campaign #$campaignId: deduplication skipped $skippedDedup number(s) messaged in the last {$campaign['dedup_window_hours']}h (scope={$campaign['dedup_scope']})");
        }
    }

    // ── Opt-out suppression ─────────────────────────────────────────────────────────────
    // A number that replied STOP must never be messaged again, regardless of segment rules.
    $optins = wa_optin_map(array_column($rows, 'phone'));
    $before = count($rows);
    $rows = array_values(array_filter($rows, fn($x) => ($optins[$x['phone']] ?? '') !== 'optout'));
    $optedOut = $before - count($rows);
    if ($optedOut > 0) wa_log("campaign #$campaignId: $optedOut number(s) skipped — opted out");

    // ── Contact limit ───────────────────────────────────────────────────────────────────
    if ((int)$campaign['contact_limit_enabled'] === 1 && (int)$campaign['contact_limit'] > 0) {
        $limit = (int)$campaign['contact_limit'];
        if (count($rows) > $limit) {
            wa_log("campaign #$campaignId: contact limit $limit applied (audience was " . count($rows) . ")");
            $rows = array_slice($rows, 0, $limit);
        }
    }

    $total = count($rows);
    if ($total > 0) {
        foreach (array_chunk($rows, 500) as $chunk) {
            $values = [];
            foreach ($chunk as $u) {
                $rid   = bin2hex(random_bytes(16));
                $uid   = $u['user_id'] !== null && $u['user_id'] !== '' ? (int)$u['user_id'] : 'NULL';
                $phone = $conn->real_escape_string($u['phone']);
                $rawP  = $conn->real_escape_string((string)$u['raw_phone']);
                $email = $conn->real_escape_string((string)$u['email']);
                $fname = $conn->real_escape_string((string)$u['first_name']);
                $lname = $conn->real_escape_string((string)$u['last_name']);
                $values[] = "($campaignId, $uid, '$phone', '$rawP', '$email', '$fname', '$lname', 0, 'pending', '$rid')";
            }
            // INSERT IGNORE + uq_campaign_phone is the second half of the dedup guarantee: even
            // if a future caller hands this function a list it forgot to fold, the database
            // physically cannot store the same number twice for one campaign.
            $conn->query("INSERT IGNORE INTO wa_campaign_recipients
                (campaign_id, user_id, phone, raw_phone, email, first_name, last_name, is_test, status, rid)
                VALUES " . implode(',', $values));
        }
    }

    // Count the rows that actually landed rather than trusting $total — INSERT IGNORE may have
    // collapsed more than we folded in PHP.
    $cR = $conn->query("SELECT COUNT(*) AS c FROM wa_campaign_recipients WHERE campaign_id=$campaignId AND is_test=0");
    $queued = $cR ? (int)$cR->fetch_assoc()['c'] : $total;

    $conn->query("UPDATE wa_campaigns
                     SET total_recipients=$queued, skipped_dedup_count=" . (int)$skippedDedup . ", materialized_at=NOW()
                   WHERE id=$campaignId");
    return $queued;
}

/**
 * Renders one recipient's message content — the campaign's variable values with merge tags
 * resolved for this specific person, ready to hand to WhatsAppTransport::buildRequest().
 *
 * @return array{content: array, preview: string}
 */
function wa_render_for_recipient(array $campaign, array $recipient, array $attrTokens): array {
    $vars = json_decode($campaign['variables'] ?? '{}', true) ?: [];

    $resolveList = function ($list) use ($recipient, $attrTokens) {
        $out = [];
        foreach ((array)$list as $v) $out[] = substitute_merge_tags((string)$v, $recipient, $attrTokens);
        return $out;
    };

    if (($campaign['message_type'] ?? 'template') === 'text') {
        $body = substitute_merge_tags((string)$campaign['text_content'], $recipient, $attrTokens);
        return [
            'content' => ['type' => 'text', 'body' => $body, 'preview_url' => (int)$campaign['preview_url'] === 1],
            'preview' => $body,
        ];
    }

    $headerValues = $resolveList($vars['header'] ?? []);
    $bodyValues   = $resolveList($vars['body'] ?? []);
    $buttonSuffix = substitute_merge_tags((string)($vars['button_url_suffix'] ?? ''), $recipient, $attrTokens);

    $tpl = [
        'header_type'      => $campaign['header_type'],
        'header_text'      => $campaign['header_text'],
        'header_media_url' => $campaign['header_media_url'],
        'body_text'        => $campaign['body_text'],
        'buttons'          => $campaign['buttons'],
    ];

    $components = wa_build_components($tpl, [
        'header' => $headerValues, 'body' => $bodyValues, 'button_url_suffix' => $buttonSuffix,
    ]);

    return [
        'content' => [
            'type'       => 'template',
            'name'       => $campaign['template_name'],
            'language'   => $campaign['template_language'] ?: 'en',
            'components' => $components,
        ],
        // Human-readable copy of exactly what this person was sent, stored on their row so the
        // report can show it without re-deriving anything.
        'preview' => wa_fill_placeholders((string)$campaign['body_text'], $bodyValues),
    ];
}

/**
 * Processes one chunk of pending recipients (per running campaign, or a single $campaignId
 * for the instant "Send now" kick). Concurrency-safe by virtue of the caller's flock().
 */
function wa_process_batch(int $limit = 200, ?int $campaignId = null): array {
    global $conn;
    wa_activate_due_scheduled();

    $filter = $campaignId ? 'id = ' . (int)$campaignId : "status = 'running'";
    $ids = [];
    $res = $conn->query("SELECT id FROM wa_campaigns WHERE $filter");
    while ($res && $row = $res->fetch_assoc()) $ids[] = (int)$row['id'];

    static $tickLogged = false;
    if (!$tickLogged) {
        wa_log('tick: ' . count($ids) . ' running campaign(s) to check'
            . ($campaignId ? " (instant kick for campaign #$campaignId)" : ' (cron sweep)'));
        $tickLogged = true;
    }

    $processed = 0; $sent = 0; $failed = 0;
    $settings  = wa_settings_row() ?: [];

    foreach ($ids as $cid) {
        $campRes = $conn->query("SELECT * FROM wa_campaigns WHERE id=$cid LIMIT 1");
        $campaign = $campRes ? $campRes->fetch_assoc() : null;
        if (!$campaign || $campaign['status'] !== 'running') continue;

        if (empty($campaign['materialized_at'])) {
            wa_log("campaign #$cid \"{$campaign['name']}\": resolving audience (type={$campaign['audience_type']}, segments={$campaign['segment_ids']}, lists={$campaign['list_ids']})…");
            $n = wa_materialize_recipients($cid);
            if ($n === 0) {
                wa_log("campaign #$cid: 0 reachable recipients -> marking FAILED (nothing was sent)");
                $conn->query("UPDATE wa_campaigns SET status='failed', completed_at=NOW() WHERE id=$cid");
                continue;
            }
            // Re-read: materialize stamped total_recipients/materialized_at on the row.
            $campRes = $conn->query("SELECT * FROM wa_campaigns WHERE id=$cid LIMIT 1");
            $campaign = $campRes ? $campRes->fetch_assoc() : $campaign;
        }

        // Re-check live status right before claiming — a Suspend click can land while this tick
        // was busy waiting on slow API calls for an earlier batch.
        $liveR = $conn->query("SELECT status FROM wa_campaigns WHERE id=$cid LIMIT 1");
        $live  = $liveR ? $liveR->fetch_assoc() : null;
        if (!$live || $live['status'] !== 'running') continue;

        $conn->query("UPDATE wa_campaign_recipients SET status='processing'
                       WHERE campaign_id=$cid AND status='pending' AND is_test=0 ORDER BY id LIMIT " . (int)$limit);
        $claimedR = $conn->query("SELECT * FROM wa_campaign_recipients
                                   WHERE campaign_id=$cid AND status='processing' AND is_test=0 ORDER BY id LIMIT " . (int)$limit);
        $claimed = [];
        while ($claimedR && $row = $claimedR->fetch_assoc()) $claimed[] = $row;
        if (!$claimed) {
            wa_finalize_if_drained($cid);
            continue;
        }

        // The API key comes from the campaign's chosen sender, because Netcore issues one key
        // per business number — that key IS what decides which number the message goes out
        // from. The routing tag comes from the campaign's own snapshot so a campaign keeps
        // sending as whatever it was queued with even if the default is changed mid-send.
        $sender = wa_sender_for_campaign($campaign);
        $transport = new WhatsAppTransport($settings, $campaign['source_id'] ?? null, wa_sender_api_key($sender));
        // Settled once per batch rather than discovered 200 times over the network: with no key
        // every single request is a guaranteed 401.
        $blocker = null;
        if (!$transport->isConfigured()) {
            $blocker = 'No API key for the sending number ' . ($campaign['business_number'] ?: '(none selected)') . ' — add it in WhatsApp settings';
        }
        if ($blocker) wa_log("campaign #$cid: $blocker — this batch will be marked failed");

        // Customer Attributes resolved ONCE for the whole batch (one query per attribute), not
        // once per recipient — same batching as the email worker.
        $attributes = load_all_attributes();
        $attrByEmail = $attributes ? resolve_attribute_values_batch($attributes, $claimed) : [];

        // ── Phase 1: render everything (pure CPU, no network) ──
        $jobs = []; $rowsById = []; $previews = [];
        foreach ($claimed as $rec) {
            $processed++;
            $rowsById[$rec['id']] = $rec;
            if ($blocker) continue;

            $attrTokens = $attrByEmail[strtolower((string)$rec['email'])] ?? [];
            $rendered   = wa_render_for_recipient($campaign, $rec, $attrTokens);
            $previews[$rec['id']] = $rendered['preview'];
            $jobs[] = [
                'key' => $rec['id'],
                'rid' => $rec['rid'],
                'req' => $transport->buildRequest($rec['phone'], $rendered['content'], $rec['rid']),
            ];
        }

        // ── Phase 2: send them concurrently ──
        if ($blocker) {
            $results = [];
            foreach ($rowsById as $id => $_) {
                $results[$id] = ['ok' => false, 'message_id' => null, 'error' => $blocker, 'code' => 'unconfigured', 'retryable' => false];
            }
        } else {
            $startedAt = microtime(true);
            $results = wa_send_parallel($transport, $jobs, WA_SEND_CONCURRENCY);
            $elapsed = max(0.001, microtime(true) - $startedAt);
            if ($jobs) {
                wa_log(sprintf('campaign #%d: %d sends in %.1fs (%.0f/s, concurrency %d)',
                    $cid, count($jobs), $elapsed, count($jobs) / $elapsed, WA_SEND_CONCURRENCY));
            }
        }

        // ── Phase 3: write outcomes back in a handful of queries ──
        // The campaign's own Retry toggle decides whether a recipient gets more than one go:
        // with it off, both a permanent rejection AND a provider-busy response settle the
        // recipient immediately instead of going back in the queue.
        $retryOn = (int)($campaign['retry_enabled'] ?? 1) === 1;
        $maxAttempts = $retryOn ? WA_MAX_ATTEMPTS : 1;

        $sentIds = []; $messageIds = []; $failures = []; $retryables = [];
        foreach ($results as $id => $res) {
            if (!empty($res['ok'])) {
                $sentIds[] = (int)$id;
                $messageIds[(int)$id] = (string)($res['message_id'] ?? '');
            } elseif (!empty($res['retryable']) && $retryOn) {
                $retryables[(int)$id] = $res['error'] ?? 'Provider busy';
            } else {
                $failures[(int)$id] = ['error' => $res['error'] ?? 'Unknown send error', 'code' => $res['code'] ?? null];
            }
        }

        if ($sentIds) {
            $idCases = ''; $bodyCases = '';
            foreach ($sentIds as $id) {
                $idCases   .= " WHEN $id THEN '" . $conn->real_escape_string($messageIds[$id] ?? '') . "'";
                $bodyCases .= " WHEN $id THEN '" . $conn->real_escape_string(mb_substr((string)($previews[$id] ?? ''), 0, 4000)) . "'";
            }
            $inList = implode(',', $sentIds);
            $conn->query("UPDATE wa_campaign_recipients
                             SET status='sent', sent_at=NOW(),
                                 wa_message_id = CASE id$idCases ELSE wa_message_id END,
                                 rendered_body = CASE id$bodyCases ELSE rendered_body END
                           WHERE id IN ($inList)");
            // delivered_count/read_count are deliberately NOT touched here — "sent" only means
            // the provider accepted the API call. Real delivery arrives later via webhook.php.
            $conn->query("UPDATE wa_campaigns SET sent_count = sent_count + " . count($sentIds) . " WHERE id=$cid");
            foreach ($sentIds as $id) wa_record_event($cid, $id, 'sent');
            $sent += count($sentIds);
        }

        if ($failures) {
            wa_mark_failed_batch($cid, $failures, $rowsById, $maxAttempts);
            $failed += count($failures);
            $sampleId = array_key_first($failures);
            wa_log("campaign #$cid: " . count($failures) . " permanent rejection(s), e.g. "
                . ($rowsById[$sampleId]['phone'] ?? '?') . ' -> ' . $failures[$sampleId]['error']);
        }

        if ($retryables) {
            // Straight back to 'pending' with attempts untouched: the provider said "not now",
            // not "never". Burning an attempt here would permanently fail thousands of perfectly
            // good numbers after three rate-limit bursts.
            $conn->query("UPDATE wa_campaign_recipients SET status='pending'
                           WHERE id IN (" . implode(',', array_keys($retryables)) . ")");
            $sampleId = array_key_first($retryables);
            wa_log("campaign #$cid: " . count($retryables) . ' rate-limited/retryable, requeued (attempts NOT consumed), e.g. '
                . $retryables[$sampleId] . ' — lower WA_SEND_CONCURRENCY if this is constant');
            sleep(WA_RATE_LIMIT_BACKOFF_SECONDS);
        }

        wa_finalize_if_drained($cid);
    }

    return ['processed' => $processed, 'sent' => $sent, 'failed' => $failed, 'campaigns' => count($ids)];
}

/**
 * $maxAttempts strikes → 'failed', otherwise back to 'pending' — in two queries rather than one
 * per recipient. Only ever called with PERMANENT failures (provider-busy takes the requeue path
 * above, unless the campaign has Retry switched off, in which case $maxAttempts is 1 and
 * everything settles on the first try).
 */
function wa_mark_failed_batch(int $campaignId, array $failures, array $rowsById, int $maxAttempts = WA_MAX_ATTEMPTS): void {
    global $conn;
    if (!$failures) return;

    $byStatus = ['failed' => [], 'pending' => []];
    $errCases = ''; $codeCases = '';
    foreach ($failures as $id => $f) {
        $id = (int)$id;
        $attempts = (int)($rowsById[$id]['attempts'] ?? 0) + 1;
        $byStatus[$attempts >= $maxAttempts ? 'failed' : 'pending'][] = $id;
        $errCases  .= " WHEN $id THEN '" . $conn->real_escape_string(substr((string)$f['error'], 0, 480)) . "'";
        $codeCases .= " WHEN $id THEN '" . $conn->real_escape_string(substr((string)($f['code'] ?? ''), 0, 60)) . "'";
    }

    foreach ($byStatus as $status => $ids) {
        if (!$ids) continue;
        $inList = implode(',', $ids);
        $failedAt = $status === 'failed' ? ', failed_at=NOW()' : '';
        // attempts + 1 rather than a computed literal, so a concurrent write can't be
        // overwritten with a stale value.
        $conn->query("UPDATE wa_campaign_recipients
                         SET status='$status', attempts = attempts + 1$failedAt,
                             error_message = CASE id$errCases ELSE error_message END,
                             error_code    = CASE id$codeCases ELSE error_code END
                       WHERE id IN ($inList)");
        if ($status === 'failed') {
            $conn->query("UPDATE wa_campaigns SET failed_count = failed_count + " . count($ids) . " WHERE id=$campaignId");
            foreach ($ids as $id) {
                wa_record_event($campaignId, $id, 'failed', $failures[$id]['code'] ?? null, $failures[$id]['error'] ?? null);
            }
        }
    }
}

function wa_record_event(int $campaignId, int $recipientId, string $type, ?string $code = null, ?string $detail = null): void {
    global $conn;
    $codeSql   = $code === null ? 'NULL' : "'" . $conn->real_escape_string(substr($code, 0, 60)) . "'";
    $detailSql = $detail === null ? 'NULL' : "'" . $conn->real_escape_string(substr($detail, 0, 480)) . "'";
    $conn->query("INSERT INTO wa_campaign_events (campaign_id, recipient_id, event_type, error_code, detail)
                  VALUES ($campaignId, $recipientId, '" . $conn->real_escape_string($type) . "', $codeSql, $detailSql)");
}

/**
 * Closes out a campaign once its queue is empty.
 *
 * "Nothing left pending" is NOT the same as "everyone got it" — a recipient that fails
 * WA_MAX_ATTEMPTS times also leaves the queue. So the final status depends on whether
 * anything actually succeeded, which is what stops a campaign showing SENT when every single
 * message was rejected (e.g. an unapproved template name).
 */
function wa_finalize_if_drained(int $campaignId): void {
    global $conn;
    $r = $conn->query("SELECT COUNT(*) AS c FROM wa_campaign_recipients
                        WHERE campaign_id=$campaignId AND is_test=0 AND status IN ('pending','processing')");
    $remaining = $r ? (int)$r->fetch_assoc()['c'] : 0;
    if ($remaining > 0) return;

    $s = $conn->query("SELECT COUNT(*) AS c FROM wa_campaign_recipients
                        WHERE campaign_id=$campaignId AND is_test=0 AND status IN ('sent','delivered','read')");
    $sentCount = $s ? (int)$s->fetch_assoc()['c'] : 0;
    $finalStatus = $sentCount > 0 ? 'sent' : 'failed';
    $conn->query("UPDATE wa_campaigns SET status='$finalStatus', completed_at=NOW()
                   WHERE id=$campaignId AND status='running'");
    wa_log("campaign #$campaignId: COMPLETED -> status=$finalStatus ($sentCount accepted by the provider)");
}

/**
 * Fire-and-forget kick so "Send now" doesn't wait for the next cron minute — opens a socket
 * to the worker endpoint and closes it without reading the response. Cron remains the
 * reliable safety net that finishes whatever this didn't get to.
 */
function wa_trigger_worker_async(int $campaignId): void {
    $path = WA_WORKER_PATH . '?cron_secret=' . urlencode(WA_CRON_SECRET) . '&campaign_id=' . $campaignId;
    $fp = @fsockopen('ssl://' . WA_WORKER_HOST, 443, $errno, $errstr, 1);
    if (!$fp) return;
    stream_set_timeout($fp, 1);
    fwrite($fp, "GET $path HTTP/1.1\r\nHost: " . WA_WORKER_HOST . "\r\nConnection: Close\r\n\r\n");
    fclose($fp);
}

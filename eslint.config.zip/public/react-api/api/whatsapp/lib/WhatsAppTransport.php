<?php
/*
 * Netcore Cloud WhatsApp Business API transport (waapi.pepipost.com/api/v2).
 *
 * Split into buildRequest() / parseResponse() for the same reason the email transports are
 * (see campaigns/lib/EspTransport.php): the HTTP call has to be separable from the payload
 * shape so many sends can be in flight at once via curl_multi — lib/WaParallelSender.php
 * owns the concurrency and knows nothing about Netcore, this class owns the payload and the
 * error vocabulary.
 *
 * Wire format (verified against the live API during integration testing):
 *
 *   POST {base}/message/
 *   Authorization: Bearer <api key>
 *   {
 *     "message": [{
 *       "recipient_whatsapp": "919921079337",
 *       "recipient_type": "individual",
 *       "message_type": "template",
 *       "source": "<source uuid — the WABA sending number>",
 *       "x-apiheader": "<our rid, echoed back on webhooks>",
 *       "type_template": [{ "name": "...", "language": {...}, "components": [...] }]
 *     }]
 *   }
 *   → 200 {"status":"success","message":"Request received successfully.","data":{"id":"<uuid>"}}
 *
 * Two things about this API that are easy to get wrong, both learned the hard way:
 *
 * 1. The API KEY is issued PER BUSINESS NUMBER (Netcore panel → Business number → Edit →
 *    Integrate API, where each number has its own API key 1/2 and a Generate API button).
 *    The key is therefore what identifies the sender — not a separate id — so a business with
 *    two numbers has two keys and the campaign has to send with the right one.
 *
 * 2. `source` is OPTIONAL. It is the routing tag that ties a message to a webhook's
 *    "Source key / callbackData" in the panel, so delivery receipts come back to the matching
 *    endpoint. It is NOT a sending-number identifier and is NOT validated — a message posted
 *    with a nonsense source is still accepted. It is omitted entirely when blank rather than
 *    sent empty.
 *
 * IMPORTANT — a 200 here means ACCEPTED, not DELIVERED. The API returns success for messages
 * it will still drop: an unapproved template name, or a free-text message to someone outside
 * the 24-hour service window. That is why delivered/read counts only ever move from the
 * webhook, never from a send response.
 */
require_once __DIR__ . '/config.php';

class WhatsAppTransport {
    private string $apiKey;
    private string $baseUrl;
    private string $sourceId;

    /**
     * @param array       $settingsRow  wa_settings — used for the base URL, and for the API key
     *                                  only as a fallback when a sender has none of its own.
     * @param string|null $sourceId     optional webhook routing tag (see the note above)
     * @param string|null $apiKey       the SENDING NUMBER's own API key (wa_senders.api_key).
     *                                  This is what makes the message go out from that number.
     */
    public function __construct(array $settingsRow, ?string $sourceId = null, ?string $apiKey = null) {
        $senderKey      = trim((string)$apiKey);
        $this->apiKey   = $senderKey !== '' ? $senderKey : trim((string)($settingsRow['api_key'] ?? ''));
        $base           = trim((string)($settingsRow['api_base_url'] ?? '')) ?: WA_DEFAULT_API_BASE;
        $this->baseUrl  = rtrim($base, '/') . '/';
        $this->sourceId = trim((string)$sourceId);
    }

    public function isConfigured(): bool { return $this->apiKey !== ''; }
    public function hasSource(): bool    { return $this->sourceId !== ''; }
    public function sourceId(): string   { return $this->sourceId; }

    private function headers(): array {
        return ['Content-Type: application/json', 'Authorization: Bearer ' . $this->apiKey];
    }

    /**
     * One outgoing message, as a ready-to-execute request.
     *
     * @param string $to      E.164 digits, no '+' (e.g. 919921079337) — see wa_normalize_phone()
     * @param array  $content ['type' => 'template'|'text', ...] — see buildTemplatePayload()/
     *                        buildTextPayload() below for each shape
     * @param string $rid     our tracking id, echoed back by the provider's webhook
     */
    public function buildRequest(string $to, array $content, string $rid): array {
        $message = [
            'recipient_whatsapp' => $to,
            'recipient_type'     => 'individual',
            'x-apiheader'        => $rid,
        ];
        // Omitted entirely when unset — an empty `source` is not the same as no source, and
        // this field only exists to route delivery receipts to a matching webhook.
        if ($this->sourceId !== '') $message['source'] = $this->sourceId;

        if (($content['type'] ?? 'template') === 'text') {
            $text = (string)($content['body'] ?? '');
            /*
             * preview_url may only be true when the text actually contains a link. Netcore
             * rejects the whole message otherwise:
             *   8006 "if preview url is true then you must set at least one url in text content"
             * So the flag is downgraded here rather than trusted — the toggle expresses intent
             * ("show a preview if there's a link"), and a message with no link silently loses
             * nothing by sending false.
             */
            $wantsPreview = !empty($content['preview_url']);
            $hasUrl = (bool)preg_match('~(https?://|www\.)\S+~i', $text);
            $message['message_type'] = 'text';
            $message['type_text'] = [[
                // Netcore expects these as STRINGS, not JSON booleans.
                'preview_url' => ($wantsPreview && $hasUrl) ? 'true' : 'false',
                'content'     => $text,
            ]];
        } else {
            $message['message_type'] = 'template';
            $message['type_template'] = [[
                'name'     => (string)($content['name'] ?? ''),
                'language' => ['policy' => 'deterministic', 'code' => (string)($content['language'] ?? 'en')],
                'components' => $content['components'] ?? [],
            ]];
        }

        return [
            'url'     => $this->baseUrl . 'message/',
            'headers' => $this->headers(),
            'body'    => json_encode(['message' => [$message]]),
        ];
    }

    /**
     * Turns one raw HTTP outcome into a uniform result.
     *
     * `retryable` separates "this number/template is wrong, stop trying" (4xx) from "the
     * provider is busy or briefly unreachable" (429, 5xx, connection errors). Only the former
     * consumes one of a recipient's WA_MAX_ATTEMPTS — without that split, a single rate-limit
     * burst at high concurrency would permanently fail an entire batch of good numbers.
     *
     * @return array{ok: bool, message_id: ?string, error: ?string, code: ?string, retryable: bool}
     */
    public function parseResponse(int $status, ?string $body, string $curlError, ?string $rid): array {
        if ($curlError !== '') {
            return ['ok' => false, 'message_id' => null, 'error' => "Network error: $curlError", 'code' => 'network', 'retryable' => true];
        }

        $decoded = json_decode((string)$body, true);

        if ($status >= 200 && $status < 300) {
            // Netcore answers 200 with status:"success" on accept. It can also answer 200 with
            // status:"error" for a per-message rejection, so the body — not the HTTP code — is
            // what decides success here.
            $apiStatus = strtolower((string)($decoded['status'] ?? 'success'));
            if ($apiStatus === 'success') {
                $messageId = $decoded['data']['id'] ?? ($decoded['data']['message_id'] ?? null);
                return ['ok' => true, 'message_id' => $messageId ?: $rid, 'error' => null, 'code' => null, 'retryable' => false];
            }
            $msg = $decoded['message'] ?? ($body ?: 'Provider rejected the message');
            return ['ok' => false, 'message_id' => null, 'error' => 'WhatsApp: ' . $msg, 'code' => (string)($decoded['error_code'] ?? 'rejected'), 'retryable' => false];
        }

        $msg = $decoded['message']
            ?? ($decoded['error']['message'] ?? ($decoded['errors'][0]['message'] ?? ($body ?: "HTTP $status")));
        $retryable = ($status === 429 || $status >= 500);
        $code = $status === 401 || $status === 403 ? 'auth' : (string)$status;
        return ['ok' => false, 'message_id' => null, 'error' => "WhatsApp $status: $msg", 'code' => $code, 'retryable' => $retryable];
    }

    /** Single-shot path (test sends). build → execute → parse. */
    public function sendMessage(string $to, array $content, string $rid): array {
        if (!$this->isConfigured()) {
            return ['ok' => false, 'message_id' => null, 'error' => 'No API key for this sending number — add it in Settings', 'code' => 'unconfigured', 'retryable' => false];
        }
        $req = $this->buildRequest($to, $content, $rid);
        [$status, $body, $curlErr] = wa_http_exec($req);
        return $this->parseResponse($status, $body, $curlErr, $rid);
    }

    /**
     * Registers consent for one or more numbers (POST {base}/consent/manage/).
     * WhatsApp will not deliver to a number that has never opted in, so this is offered
     * straight from the Settings page rather than being a hidden prerequisite.
     *
     * @param string[] $phones normalized numbers
     */
    public function manageConsent(array $phones, string $type = 'optin'): array {
        if (!$this->isConfigured()) {
            return ['ok' => false, 'error' => 'WhatsApp API key not configured'];
        }
        $recipients = array_map(fn($p) => [
            'recipient'  => $p,
            'source'     => 'WEB',
            'user_agent' => 'InternshipStudio-Admin/1.0',
            'ip'         => $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1',
        ], array_values($phones));

        $req = [
            'url'     => $this->baseUrl . 'consent/manage/',
            'headers' => $this->headers(),
            'body'    => json_encode(['type' => $type === 'optout' ? 'optout' : 'optin', 'recipients' => $recipients]),
        ];
        [$status, $body, $curlErr] = wa_http_exec($req);
        if ($curlErr !== '') return ['ok' => false, 'error' => "Network error: $curlErr"];

        $decoded = json_decode((string)$body, true);
        $ok = $status >= 200 && $status < 300 && strtolower((string)($decoded['status'] ?? '')) === 'success';
        return ['ok' => $ok, 'error' => $ok ? null : ($decoded['message'] ?? ($body ?: "HTTP $status")), 'raw' => $decoded];
    }
}

/**
 * Builds the `components` array for a template message from a template row plus the
 * already-merge-tag-resolved values for this specific recipient.
 *
 * WhatsApp is strict here: a template approved with two body variables MUST be sent with
 * exactly two body parameters, in order, or Meta rejects (or worse, silently drops) it. So
 * the component list is derived from the template's own placeholder count, not from however
 * many values happen to have been filled in — missing values become empty strings rather
 * than shortening the array.
 *
 * @param array $tpl      wa_templates row (or the campaign's snapshot of one)
 * @param array $resolved ['header' => [...], 'body' => [...], 'button_url_suffix' => '...']
 */
function wa_build_components(array $tpl, array $resolved): array {
    $components = [];

    $headerType = $tpl['header_type'] ?? 'none';
    if ($headerType === 'text') {
        $headerVars = wa_placeholder_count((string)($tpl['header_text'] ?? ''));
        if ($headerVars > 0) {
            $params = [];
            for ($i = 0; $i < $headerVars; $i++) {
                $params[] = ['type' => 'text', 'text' => (string)($resolved['header'][$i] ?? '')];
            }
            $components[] = ['type' => 'header', 'parameters' => $params];
        }
    } elseif (in_array($headerType, ['image', 'video', 'document'], true)) {
        $url = trim((string)($tpl['header_media_url'] ?? ''));
        if ($url !== '') {
            $components[] = ['type' => 'header', 'parameters' => [[
                'type' => $headerType, $headerType => ['link' => $url],
            ]]];
        }
    }

    $bodyVars = wa_placeholder_count((string)($tpl['body_text'] ?? ''));
    if ($bodyVars > 0) {
        $params = [];
        for ($i = 0; $i < $bodyVars; $i++) {
            $params[] = ['type' => 'text', 'text' => (string)($resolved['body'][$i] ?? '')];
        }
        $components[] = ['type' => 'body', 'parameters' => $params];
    }

    // Only a DYNAMIC url button carries a parameter — a static url/quick-reply button is
    // baked into the approved template and must NOT be sent as a component.
    $buttons = $tpl['buttons'] ?? [];
    if (is_string($buttons)) $buttons = json_decode($buttons, true) ?: [];
    foreach (array_values($buttons) as $idx => $btn) {
        if (($btn['type'] ?? '') !== 'url' || empty($btn['dynamic'])) continue;
        $suffix = (string)($resolved['button_url_suffix'] ?? '');
        if ($suffix === '') continue;
        $components[] = [
            'type' => 'button', 'sub_type' => 'url', 'index' => (string)$idx,
            'parameters' => [['type' => 'text', 'text' => $suffix]],
        ];
    }

    return $components;
}

/** How many {{n}} placeholders a template string declares. */
function wa_placeholder_count(string $text): int {
    if ($text === '') return 0;
    preg_match_all('/\{\{\s*(\d+)\s*\}\}/', $text, $m);
    if (!$m[1]) return 0;
    return max(array_map('intval', $m[1]));
}

/** Substitutes {{1}}, {{2}} … with the given ordered values — used for previews and for the
 *  human-readable copy of the message stored on each recipient row. */
function wa_fill_placeholders(string $text, array $values): string {
    return preg_replace_callback('/\{\{\s*(\d+)\s*\}\}/', function ($m) use ($values) {
        return (string)($values[((int)$m[1]) - 1] ?? '');
    }, $text);
}

/** Performs one already-built request. Mirrors campaigns/lib/ParallelSender.php's
 *  esp_http_exec() but is defined here so this feature has no load-order dependency on the
 *  email pipeline's files. */
function wa_http_exec(array $req, int $timeout = 20): array {
    $ch = curl_init($req['url']);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST           => true,
        CURLOPT_POSTFIELDS     => $req['body'],
        CURLOPT_HTTPHEADER     => $req['headers'],
        CURLOPT_TIMEOUT        => $timeout,
    ]);
    $body    = curl_exec($ch);
    $status  = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $curlErr = curl_error($ch);
    curl_close($ch);
    return [$status, $body === false ? null : $body, $curlErr];
}

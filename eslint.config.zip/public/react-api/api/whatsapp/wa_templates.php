<?php
/*
 * /api/whatsapp/wa_templates.php — WhatsApp message templates.
 *
 * A row here is OUR record of a template that exists (or is being submitted) on the WhatsApp
 * Business Account. WhatsApp itself will only deliver a template Meta has approved, so `name`
 * + `language` must match the approved template exactly; everything else on the row (body
 * copy, buttons, variable labels, samples) is what lets the campaign wizard render a true
 * preview and offer variable mapping without calling the provider on every keystroke.
 *
 * action=list     &page &per_page &search &status(active|archived) &category
 * action=get       &id
 * action=save     [&id] &name &display_name &category &language &header_* &body_text
 *                  &footer_text &buttons(json) &variable_labels(json) &sample_values(json) &approval_status
 * action=archive | restore | delete   &id
 * action=sync                                → pull the approved-template list from the provider
 */
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../middleware/auth.php';
require_once __DIR__ . '/lib/config.php';
require_once __DIR__ . '/lib/schema.php';
require_once __DIR__ . '/lib/WhatsAppTransport.php';

whatsapp_ensure_schema();

$jwt = require_jwt();
require_permission('netcore_behaviour', $jwt);

function jin($k, $d = null) { $v = $_REQUEST[$k] ?? null; return ($v === null || $v === '') ? $d : $v; }

/** Decodes a JSON parameter into an array, tolerating an empty/garbage value. */
function jarr($k): array {
    $v = $_REQUEST[$k] ?? null;
    if ($v === null || $v === '') return [];
    $d = json_decode((string)$v, true);
    return is_array($d) ? $d : [];
}

$action = jin('action', '');

if ($action === 'list') {
    $page     = max(1, (int)jin('page', 1));
    $perPage  = max(1, min(200, (int)jin('per_page', 24)));
    $search   = trim((string)jin('search', ''));
    $status   = jin('status', 'active');
    $category = jin('category', '');
    $offset   = ($page - 1) * $perPage;

    $where = ["status='" . $conn->real_escape_string($status) . "'"];
    if ($search !== '') {
        $s = $conn->real_escape_string($search);
        $where[] = "(name LIKE '%$s%' OR display_name LIKE '%$s%' OR body_text LIKE '%$s%')";
    }
    if ($category !== '') $where[] = "category='" . $conn->real_escape_string($category) . "'";
    $whereSql = 'WHERE ' . implode(' AND ', $where);

    $tr = $conn->query("SELECT COUNT(*) AS c FROM wa_templates $whereSql");
    $total = $tr ? (int)$tr->fetch_assoc()['c'] : 0;

    $r = $conn->query("SELECT * FROM wa_templates $whereSql ORDER BY id DESC LIMIT $perPage OFFSET $offset");
    $rows = [];
    while ($r && $row = $r->fetch_assoc()) {
        $row['buttons']         = json_decode($row['buttons'] ?? '[]', true) ?: [];
        $row['variable_labels'] = json_decode($row['variable_labels'] ?? '{}', true) ?: [];
        $row['sample_values']   = json_decode($row['sample_values'] ?? '{}', true) ?: [];
        // Placeholder counts are derived, never stored — a body edit can't leave them stale.
        $row['body_variable_count']   = wa_placeholder_count((string)$row['body_text']);
        $row['header_variable_count'] = $row['header_type'] === 'text' ? wa_placeholder_count((string)$row['header_text']) : 0;
        $rows[] = $row;
    }

    $counts = [];
    $cr = $conn->query("SELECT status, COUNT(*) AS c FROM wa_templates GROUP BY status");
    while ($cr && $row = $cr->fetch_assoc()) $counts[$row['status']] = (int)$row['c'];

    api_success(['templates' => $rows, 'total' => $total, 'page' => $page, 'per_page' => $perPage,
                 'pages' => $total > 0 ? (int)ceil($total / $perPage) : 1, 'counts' => $counts]);
}

if ($action === 'get') {
    $id = (int)jin('id', 0);
    $r = $conn->query("SELECT * FROM wa_templates WHERE id=$id LIMIT 1");
    $row = $r ? $r->fetch_assoc() : null;
    if (!$row) api_error('Not found', 404);
    $row['buttons']         = json_decode($row['buttons'] ?? '[]', true) ?: [];
    $row['variable_labels'] = json_decode($row['variable_labels'] ?? '{}', true) ?: [];
    $row['sample_values']   = json_decode($row['sample_values'] ?? '{}', true) ?: [];
    $row['body_variable_count']   = wa_placeholder_count((string)$row['body_text']);
    $row['header_variable_count'] = $row['header_type'] === 'text' ? wa_placeholder_count((string)$row['header_text']) : 0;
    api_success(['template' => $row]);
}

if ($action === 'save') {
    $id   = (int)jin('id', 0);
    $name = trim((string)jin('name', ''));
    $body = (string)jin('body_text', '');

    if ($name === '') api_error('Template name is required');
    // Meta's own rule for template names — enforced here rather than discovered at submission,
    // since a name with spaces or capitals can never be approved.
    if (!preg_match('/^[a-z0-9_]+$/', $name)) {
        api_error('Template name may only contain lowercase letters, numbers and underscores (e.g. exam_reminder_1)');
    }
    if (trim($body) === '') api_error('Message body is required');
    if (mb_strlen($body) > 1024) api_error('Message body is limited to 1024 characters by WhatsApp');

    $footer = (string)jin('footer_text', '');
    if (mb_strlen($footer) > 60) api_error('Footer is limited to 60 characters by WhatsApp');

    $language   = trim((string)jin('language', 'en')) ?: 'en';
    $category   = jin('category', 'utility');
    if (!in_array($category, ['marketing', 'utility', 'authentication'], true)) $category = 'utility';
    $headerType = jin('header_type', 'none');
    if (!in_array($headerType, ['none', 'text', 'image', 'video', 'document'], true)) $headerType = 'none';
    $approval   = jin('approval_status', 'pending');
    if (!in_array($approval, ['approved', 'pending', 'rejected', 'unknown'], true)) $approval = 'pending';

    // Placeholders must be a complete 1..N run — WhatsApp rejects a body that uses {{1}} and
    // {{3}} but never {{2}}, and catching it here beats a rejection days later.
    foreach ([['body', $body], ['header', $headerType === 'text' ? (string)jin('header_text', '') : '']] as [$part, $text]) {
        if ($text === '') continue;
        preg_match_all('/\{\{\s*(\d+)\s*\}\}/', $text, $m);
        $used = array_values(array_unique(array_map('intval', $m[1] ?? [])));
        sort($used);
        $expected = range(1, count($used));
        if ($used && $used !== $expected) {
            api_error(ucfirst($part) . ' placeholders must be numbered consecutively from {{1}} — found {{' . implode('}}, {{', $used) . '}}');
        }
    }

    $buttons = jarr('buttons');
    // Normalized so the send path can trust the shape without re-validating per recipient.
    $buttons = array_values(array_map(function ($b) {
        $type = in_array(($b['type'] ?? ''), ['url', 'phone', 'quick_reply'], true) ? $b['type'] : 'quick_reply';
        return [
            'type'    => $type,
            'text'    => mb_substr(trim((string)($b['text'] ?? '')), 0, 25),
            'url'     => $type === 'url' ? trim((string)($b['url'] ?? '')) : '',
            'phone'   => $type === 'phone' ? trim((string)($b['phone'] ?? '')) : '',
            // A dynamic url button takes a per-recipient suffix appended to the base url.
            'dynamic' => $type === 'url' && !empty($b['dynamic']),
        ];
    }, $buttons));
    if (count($buttons) > 3) api_error('WhatsApp allows at most 3 buttons on a template');

    $cols = [
        'name'             => $name,
        'display_name'     => (string)jin('display_name', $name),
        'category'         => $category,
        'language'         => $language,
        'header_type'      => $headerType,
        'header_text'      => $headerType === 'text' ? (string)jin('header_text', '') : '',
        'header_media_url' => in_array($headerType, ['image', 'video', 'document'], true) ? (string)jin('header_media_url', '') : '',
        'body_text'        => $body,
        'footer_text'      => $footer,
        'buttons'          => json_encode($buttons),
        'variable_labels'  => json_encode(jarr('variable_labels')),
        'sample_values'    => json_encode(jarr('sample_values')),
        'approval_status'  => $approval,
    ];
    $set = [];
    foreach ($cols as $c => $v) $set[] = "`$c`='" . $conn->real_escape_string((string)$v) . "'";

    if ($id > 0) {
        $conn->query("UPDATE wa_templates SET " . implode(', ', $set) . " WHERE id=$id");
    } else {
        // uq_name_lang: the same approved template can't be registered twice for one language.
        $dup = $conn->query("SELECT id FROM wa_templates WHERE name='" . $conn->real_escape_string($name) . "'
                              AND language='" . $conn->real_escape_string($language) . "' LIMIT 1");
        if ($dup && $dup->num_rows > 0) api_error("A template named \"$name\" already exists for language \"$language\"");
        $set[] = 'created_by=' . (int)($jwt['user_id'] ?? 0);
        $conn->query("INSERT INTO wa_templates SET " . implode(', ', $set));
        $id = $conn->insert_id;
    }
    api_success(['id' => $id]);
}

if ($action === 'archive' || $action === 'restore') {
    $id = (int)jin('id', 0);
    $status = $action === 'archive' ? 'archived' : 'active';
    $conn->query("UPDATE wa_templates SET status='$status' WHERE id=$id");
    api_success([]);
}

if ($action === 'delete') {
    $id = (int)jin('id', 0);
    if (!$id) api_error('id required');
    // Campaigns snapshot a template's content at save time (see wa_campaigns.php's save), so
    // deleting one never changes what an already-scheduled campaign will send.
    $conn->query("DELETE FROM wa_templates WHERE id=$id");
    api_success([]);
}

/*
 * Pulls the approved-template list from the provider so the admin doesn't have to re-type
 * names that already exist on the WABA (a mistyped name is accepted by the API and then
 * silently dropped by WhatsApp — exactly the failure worth designing this away from).
 *
 * The response shape varies between provider versions, so the parser is deliberately
 * tolerant: it walks the JSON for any object carrying a `name`, and reports honestly when
 * nothing template-shaped comes back rather than pretending the sync worked.
 */
if ($action === 'sync') {
    $settings = wa_settings_row() ?: [];
    // The key is per business number, so the sync has to use a SENDER's key — the account-level
    // one is normally blank now. Optionally scoped to one number via &sender_id.
    $sender = wa_sender_by_id((int)jin('sender_id', 0)) ?: wa_default_sender();
    $apiKey = wa_sender_api_key($sender);
    if ($apiKey === '') {
        api_error('Add the API key for a sending number first (Settings → Sending numbers).');
    }

    $base = rtrim(trim((string)($settings['api_base_url'] ?? '')) ?: WA_DEFAULT_API_BASE, '/') . '/';

    /*
     * Netcore's template-listing endpoint isn't documented in the material this was built
     * against, and it has moved between versions — so rather than hard-coding one guess and
     * failing opaquely, each plausible endpoint is tried in turn and every attempt's status is
     * reported back. Whatever answers with template-shaped JSON wins; if none does, the caller
     * gets the full list of what was tried so it can be handed to Netcore support verbatim.
     */
    $candidates = [
        ['GET',  $base . 'template/?limit=500'],
        ['GET',  $base . 'template/'],
        ['GET',  $base . 'templates/?limit=500'],
        ['GET',  $base . 'template/list/?limit=500'],
        ['POST', $base . 'template/list/'],
        ['POST', $base . 'template/get/'],
    ];

    $attempts = [];
    $found = [];
    $walk = function ($node) use (&$walk, &$found) {
        if (!is_array($node)) return;
        // A template row always has a Meta-legal name (lowercase/digits/underscore) AND some
        // content — the name check alone matches too many unrelated objects. Both the Meta
        // spelling (`name`) and Netcore's own (`template_name`) are accepted.
        $nameVal = $node['name'] ?? ($node['template_name'] ?? null);
        $looksLikeTemplate = is_string($nameVal) && preg_match('/^[a-z0-9_]+$/', $nameVal)
            && (isset($node['components']) || isset($node['body']) || isset($node['template_body'])
                || isset($node['language']) || isset($node['category']));
        if ($looksLikeTemplate) { $found[] = $node; return; }
        foreach ($node as $child) if (is_array($child)) $walk($child);
    };

    foreach ($candidates as [$method, $url]) {
        $ch = curl_init($url);
        $opts = [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HTTPHEADER     => ['Content-Type: application/json', 'Authorization: Bearer ' . $apiKey],
            CURLOPT_TIMEOUT        => 20,
        ];
        if ($method === 'POST') { $opts[CURLOPT_POST] = true; $opts[CURLOPT_POSTFIELDS] = '{}'; }
        curl_setopt_array($ch, $opts);
        $body   = curl_exec($ch);
        $status = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $err    = curl_error($ch);
        curl_close($ch);

        $attempts[] = [
            'method' => $method,
            'url'    => $url,
            'status' => $err !== '' ? 0 : $status,
            // Trimmed so a huge HTML error page doesn't drown the response.
            'reply'  => $err !== '' ? "network error: $err" : mb_substr(preg_replace('/\s+/', ' ', (string)$body), 0, 220),
        ];
        if ($err !== '' || $status < 200 || $status >= 300) continue;

        $decoded = json_decode((string)$body, true);
        if (!is_array($decoded)) continue;
        $walk($decoded);
        if ($found) break;
    }

    if (!$found) {
        // Every /api/v2/template* path answers 404 on this host: the messaging API simply has no
        // template routes (they live on the cpaas.netcorecloud.com side). Point at Import rather
        // than leaving a dead end.
        $allNotFound = $attempts && count(array_filter($attempts, fn($a) => $a['status'] === 404)) === count($attempts);
        api_error(
            ($allNotFound
                ? "This Netcore account's messaging API has no template endpoint — every template path returns 404. Use \"Import from panel\" instead: it takes the CSV from the Templates page download button, or the JSON from the panel's own network request."
                : "Netcore didn't return a template list from any of the endpoints tried. Use \"Import from panel\", or add templates by hand.")
            . " Tried: " . implode(' | ', array_map(fn($a) => "{$a['method']} {$a['url']} → HTTP {$a['status']}: {$a['reply']}", $attempts))
        );
    }

    $res = wa_upsert_templates($found, (int)($jwt['user_id'] ?? 0));
    api_success($res + ['found' => count($found)]);
}

/*
 * Import templates from whatever the Netcore panel can hand you, because its messaging API
 * (waapi.pepipost.com) has no template endpoint at all — every path under /api/v2/template*
 * answers 404, since template management lives on the cpaas.netcorecloud.com side.
 *
 * Accepts either:
 *   - JSON  — the response body of the panel's own template-list XHR, copied from DevTools.
 *             This also reveals the real endpoint, so automatic sync can be wired up later.
 *   - CSV / TSV — the file behind the download icon on Template management.
 *
 * Columns/keys are matched loosely by name, since neither export format is documented here.
 */
if ($action === 'import') {
    $payload = (string)jin('payload', '');
    if ($payload === '' && !empty($_FILES['file']) && $_FILES['file']['error'] === UPLOAD_ERR_OK) {
        if ($_FILES['file']['size'] > 5 * 1024 * 1024) api_error('File too large (max 5MB)');
        $payload = (string)file_get_contents($_FILES['file']['tmp_name']);
    }
    $payload = trim($payload);
    if ($payload === '') api_error('Paste the exported template list, or choose a file');

    // Excel and some panel exports write a UTF-8 BOM, which would otherwise become part of the
    // first column's header name and break every match against it.
    $payload = preg_replace('/^\xEF\xBB\xBF/', '', $payload);

    $found = [];

    $decoded = json_decode($payload, true);
    if (is_array($decoded)) {
        $walk = function ($node) use (&$walk, &$found) {
            if (!is_array($node)) return;
            $nameVal = $node['name'] ?? ($node['template_name'] ?? null);
            if (is_string($nameVal) && preg_match('/^[a-z0-9_]+$/', $nameVal)
                && (isset($node['components']) || isset($node['body']) || isset($node['template_body'])
                    || isset($node['language']) || isset($node['category']))) {
                $found[] = $node;
                return;
            }
            foreach ($node as $child) if (is_array($child)) $walk($child);
        };
        $walk($decoded);
        if (!$found) api_error('That JSON parsed, but nothing template-shaped was found in it. Make sure you copied the full response body.');
    } else {
        // ── CSV / TSV ──────────────────────────────────────────────────────────────────
        // Read through a stream rather than splitting on newlines: a template body legitimately
        // contains line breaks inside a quoted field, which a naive split would tear apart.
        $firstLine = strtok($payload, "\n");
        $delimiter = substr_count($firstLine, "\t") > substr_count($firstLine, ',') ? "\t" : ',';

        $fh = fopen('php://memory', 'r+');
        fwrite($fh, $payload);
        rewind($fh);
        $rows = [];
        while (($r = fgetcsv($fh, 0, $delimiter)) !== false) {
            if ($r === [null] || $r === false) continue; // blank line
            $rows[] = $r;
        }
        fclose($fh);
        if (count($rows) < 2) api_error('That does not look like a template export — no header row plus data rows were found.');

        $header = array_shift($rows);
        /** Exact header match first, then a contains-match, so "Template Name" and "name" both work. */
        $col = function (array $needles) use ($header) {
            foreach ([true, false] as $exact) {
                foreach ($header as $i => $h) {
                    $h = strtolower(trim((string)$h));
                    foreach ($needles as $n) {
                        if ($exact ? $h === $n : strpos($h, $n) !== false) return $i;
                    }
                }
            }
            return null;
        };
        $iName   = $col(['template name', 'name', 'template']);
        $iLang   = $col(['language', 'lang']);
        $iCat    = $col(['category', 'type']);
        $iStatus = $col(['status']);
        $iBody   = $col(['body', 'message', 'content']);
        $iHeader = $col(['header']);
        $iFooter = $col(['footer']);
        if ($iName === null) api_error('No "Template name" column found in that file. Header row was: ' . implode(' | ', array_map('strval', $header)));

        $get = fn(array $r, $i) => ($i === null || !isset($r[$i])) ? '' : trim((string)$r[$i]);
        foreach ($rows as $r) {
            $name = $get($r, $iName);
            if ($name === '') continue;
            $found[] = [
                'name'     => $name,
                'language' => $get($r, $iLang) ?: 'en',
                'category' => $get($r, $iCat),
                'status'   => $get($r, $iStatus),
                'body'     => $get($r, $iBody),
                'header'   => $get($r, $iHeader),
                'footer'   => $get($r, $iFooter),
            ];
        }
        if (!$found) api_error('No template rows were found in that file.');
    }

    $res = wa_upsert_templates($found, (int)($jwt['user_id'] ?? 0));
    api_success($res + ['found' => count($found)]);
}

/**
 * Writes a batch of loosely-shaped template records into wa_templates, keyed on (name,
 * language). Shared by the API sync and the manual import so both land identical rows.
 *
 * Rows without message text are counted as skipped rather than written: body_text is what the
 * placeholder count is derived from, and a template imported with an empty body would look like
 * it has no variables — which would then send a real template with its parameters missing.
 *
 * @return array{imported:int, updated:int, skipped:int, skipped_names:string[]}
 */
function wa_upsert_templates(array $found, int $userId): array {
    global $conn;
    $imported = 0; $updated = 0; $skipped = 0; $skippedNames = [];

    foreach ($found as $t) {
        // Field names differ between Meta's shape, Netcore's own, and a CSV export, so each is
        // read through a short list of spellings rather than one hard-coded key.
        $name = (string)($t['name'] ?? ($t['template_name'] ?? ''));
        if ($name === '' || !preg_match('/^[a-z0-9_]+$/', $name)) { $skipped++; continue; }

        $lang = (string)($t['language']['code'] ?? ($t['language'] ?? ($t['language_code'] ?? ($t['lang'] ?? 'en'))));
        // A CSV often writes "English" rather than the code Meta expects.
        $langMap = ['english' => 'en', 'hindi' => 'hi', 'marathi' => 'mr', 'gujarati' => 'gu',
                    'tamil' => 'ta', 'telugu' => 'te', 'bengali' => 'bn', 'kannada' => 'kn',
                    'malayalam' => 'ml', 'punjabi' => 'pa'];
        $lang = $langMap[strtolower(trim($lang))] ?? $lang;
        if ($lang === '') $lang = 'en';

        $cat = strtolower(trim((string)($t['category'] ?? ($t['template_category'] ?? 'utility'))));
        if (!in_array($cat, ['marketing', 'utility', 'authentication'], true)) $cat = 'utility';

        $approval = strtolower(trim((string)($t['status'] ?? ($t['template_status'] ?? ($t['approval_status'] ?? 'unknown')))));
        $approval = in_array($approval, ['approved', 'pending', 'rejected'], true) ? $approval : 'unknown';

        // Meta's components array when present; the flat spellings otherwise.
        $bodyText = ''; $headerText = ''; $footerText = ''; $headerType = 'none'; $buttons = [];
        foreach ((array)($t['components'] ?? []) as $comp) {
            if (!is_array($comp)) continue;
            $ctype = strtolower((string)($comp['type'] ?? ''));
            if ($ctype === 'body')   $bodyText = (string)($comp['text'] ?? '');
            if ($ctype === 'footer') $footerText = (string)($comp['text'] ?? '');
            if ($ctype === 'header') {
                $fmt = strtolower((string)($comp['format'] ?? 'text'));
                $headerType = in_array($fmt, ['text', 'image', 'video', 'document'], true) ? $fmt : 'text';
                $headerText = (string)($comp['text'] ?? '');
            }
            if ($ctype === 'buttons') {
                foreach ((array)($comp['buttons'] ?? []) as $b) {
                    $bt = strtolower((string)($b['type'] ?? ''));
                    $buttons[] = [
                        'type'    => $bt === 'url' ? 'url' : ($bt === 'phone_number' ? 'phone' : 'quick_reply'),
                        'text'    => (string)($b['text'] ?? ''),
                        'url'     => (string)($b['url'] ?? ''),
                        'phone'   => (string)($b['phone_number'] ?? ''),
                        'dynamic' => isset($b['url']) && strpos((string)$b['url'], '{{') !== false,
                    ];
                }
            }
        }
        if ($bodyText === '')   $bodyText = (string)($t['body'] ?? ($t['template_body'] ?? ($t['content'] ?? '')));
        if ($headerText === '') $headerText = (string)($t['header'] ?? '');
        if ($footerText === '') $footerText = (string)($t['footer'] ?? '');
        if ($headerType === 'none' && trim($headerText) !== '') $headerType = 'text';

        if (trim($bodyText) === '') { $skipped++; $skippedNames[] = $name; continue; }

        $nameE = $conn->real_escape_string($name);
        $langE = $conn->real_escape_string($lang);
        $vals = [
            "name='$nameE'", "display_name='$nameE'",
            "category='" . $conn->real_escape_string($cat) . "'", "language='$langE'",
            "header_type='" . $conn->real_escape_string($headerType) . "'",
            "header_text='" . $conn->real_escape_string($headerText) . "'",
            "body_text='"   . $conn->real_escape_string($bodyText) . "'",
            "footer_text='" . $conn->real_escape_string($footerText) . "'",
            "approval_status='" . $conn->real_escape_string($approval) . "'",
            "status='active'",
        ];
        // Buttons are only overwritten when the source actually carried some — a CSV export
        // usually has no button column, and blanking existing buttons would quietly break the
        // dynamic-URL mapping on a template that was imported properly earlier.
        if ($buttons) $vals[] = "buttons='" . $conn->real_escape_string(json_encode($buttons)) . "'";

        $exists = $conn->query("SELECT id FROM wa_templates WHERE name='$nameE' AND language='$langE' LIMIT 1");
        $row = $exists ? $exists->fetch_assoc() : null;
        if ($row) {
            $conn->query("UPDATE wa_templates SET " . implode(', ', $vals) . ' WHERE id=' . (int)$row['id']);
            $updated++;
        } else {
            $conn->query("INSERT INTO wa_templates SET " . implode(', ', $vals) . ', created_by=' . $userId);
            $imported++;
        }
    }

    return ['imported' => $imported, 'updated' => $updated, 'skipped' => $skipped,
            'skipped_names' => array_slice($skippedNames, 0, 20)];
}

api_error('Invalid action');

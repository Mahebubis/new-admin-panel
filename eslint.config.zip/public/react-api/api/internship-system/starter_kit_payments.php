<?php
/**
 * starter_kit_payments.php
 * ---------------------------------------------------------------------------
 * Admin API for "Purchased Starter Kit".
 *
 * Reads the `starter_kit_payment_logs` table and joins `users` to expose the
 * buyer's name / email alongside the payment. Supports a status filter
 * (success | initiated), a date-range filter (today | yesterday | last7 |
 * all | custom) and server-side pagination.
 *
 * Columns in starter_kit_payment_logs:
 *   id, user_id, order_id, razorpay_order_id, payment_id, provider,
 *   amount, status, created_at, updated_at
 *
 * Routes (POST or GET ?action=):
 *   action=fetch_stats  &range=&start=&end=   -> success/initiated counts + sums
 *   action=fetch_list   &status=&range=&start=&end=&page=&per_page=
 *                                             -> paginated records + total
 *
 * Responses: { "status":"success", "data":{...} } | { "status":"error", ... }
 *
 * Mirrors the bootstrap / error-handling style of problem_statements_api.php.
 * ---------------------------------------------------------------------------
 */

@ini_set('display_errors', '0');
error_reporting(E_ALL);

define('SK_LOG_FILE', __DIR__ . '/starter_kit_payments_errors.log');
@ini_set('log_errors', '1');
@ini_set('error_log', SK_LOG_FILE);

function sk_log($label, $msg) {
    $line = '[' . date('Y-m-d H:i:s') . '] ' . $label . ': ' . $msg
          . '  {' . ($_SERVER['REQUEST_METHOD'] ?? 'CLI') . ' '
          . ($_SERVER['REQUEST_URI'] ?? '') . '}' . PHP_EOL;
    @file_put_contents(SK_LOG_FILE, $line, FILE_APPEND | LOCK_EX);
}

set_error_handler(function ($no, $str, $file, $line) {
    if (strpos($file, 'starter_kit_payments.php') !== false) {
        sk_log('PHP-ERROR(' . $no . ')', $str . ' in ' . $file . ':' . $line);
    }
    return true;
});

/* shared bootstrap — provides global $conn (same as the other endpoints here) */
ob_start();
chdir('/home/istudio/public_html/cit/common');
include '/home/istudio/public_html/cit/common/helper.php';
ob_clean();

header('Content-Type: application/json');

register_shutdown_function(function () {
    $e = error_get_last();
    if ($e && in_array($e['type'], [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR], true)) {
        sk_log('FATAL', $e['message'] . ' in ' . $e['file'] . ':' . $e['line']);
        if (!headers_sent()) header('Content-Type: application/json');
        echo json_encode(['status' => 'error', 'message' => 'Server error: ' . $e['message']]);
    }
});

set_exception_handler(function ($e) {
    sk_log('EXCEPTION', get_class($e) . ': ' . $e->getMessage()
        . ' in ' . $e->getFile() . ':' . $e->getLine());
    if (!headers_sent()) {
        http_response_code(500);
        header('Content-Type: application/json');
    }
    echo json_encode(['status' => 'error', 'message' => 'Server error: ' . $e->getMessage()]);
    exit;
});

/* ====== helpers ====== */
function sk_out($p) { echo json_encode($p); exit; }
function sk_error($m, $c = 400) {
    sk_log('API-ERROR(' . $c . ')', $m);
    http_response_code($c);
    sk_out(['status' => 'error', 'message' => $m]);
}
function sk_ok($d = null, $m = '') {
    $r = ['status' => 'success'];
    if ($d !== null) $r['data'] = $d;
    if ($m !== '')   $r['message'] = $m;
    sk_out($r);
}

/* Build a safe SQL date-range condition on `created_at`.
   Returns a string that is always a valid boolean expression. */
function sk_date_condition($range, $start, $end) {
    switch ($range) {
        case 'today':
            return "DATE(s.created_at) = CURDATE()";
        case 'yesterday':
            return "DATE(s.created_at) = (CURDATE() - INTERVAL 1 DAY)";
        case 'last7':
            // last 7 days including today
            return "DATE(s.created_at) >= (CURDATE() - INTERVAL 6 DAY)";
        case 'custom':
            $re = '/^\d{4}-\d{2}-\d{2}$/';
            if (!preg_match($re, $start) || !preg_match($re, $end)) {
                sk_error('Invalid custom date range — expected YYYY-MM-DD for both start and end');
            }
            if ($start > $end) { $t = $start; $start = $end; $end = $t; }
            return "DATE(s.created_at) BETWEEN '$start' AND '$end'";
        case 'all':
        default:
            return "1";
    }
}

/* Build a safe provider condition. Empty / "all" => no filter. */
function sk_provider_condition($conn, $provider) {
    if ($provider === '' || $provider === 'all') return "1";
    if (!in_array($provider, ['cashfree', 'razorpay'], true)) {
        sk_error('Invalid provider — must be cashfree, razorpay or all');
    }
    $p = $conn->real_escape_string($provider);
    return "s.provider = '$p'";
}

global $conn;
if (!$conn) sk_error('Database connection failed', 500);

$action   = $_REQUEST['action']   ?? '';
$range    = $_REQUEST['range']    ?? 'today';
$start    = trim($_REQUEST['start'] ?? '');
$end      = trim($_REQUEST['end']   ?? '');
$provider = strtolower(trim($_REQUEST['provider'] ?? 'all'));

$dateCond     = sk_date_condition($range, $start, $end);
$providerCond = sk_provider_condition($conn, $provider);

/* ════════════════════════════════════════
   FETCH STATS — success + initiated totals for the range
════════════════════════════════════════ */
if ($action === 'fetch_stats') {
    $sql = "SELECT
                SUM(s.status = 'success')                              AS success_count,
                SUM(s.status = 'initiated')                            AS initiated_count,
                COALESCE(SUM(CASE WHEN s.status = 'success'   THEN s.amount ELSE 0 END), 0) AS success_amount,
                COALESCE(SUM(CASE WHEN s.status = 'initiated' THEN s.amount ELSE 0 END), 0) AS initiated_amount
            FROM starter_kit_payment_logs s
            WHERE $dateCond AND $providerCond";

    $res = $conn->query($sql);
    if ($res === false) sk_error('Stats query failed: ' . $conn->error, 500);
    $row = $res->fetch_assoc() ?: [];
    $conn->close();

    sk_ok([
        'success_count'    => (int)($row['success_count']    ?? 0),
        'initiated_count'  => (int)($row['initiated_count']  ?? 0),
        'success_amount'   => (float)($row['success_amount']   ?? 0),
        'initiated_amount' => (float)($row['initiated_amount'] ?? 0),
    ]);
}

/* ════════════════════════════════════════
   FETCH LIST — paginated records for one status
════════════════════════════════════════ */
if ($action === 'fetch_list') {
    $status = $_REQUEST['status'] ?? 'success';
    if (!in_array($status, ['success', 'initiated'], true)) {
        sk_error('Invalid status — must be success or initiated');
    }

    $page     = max(1,  (int)($_REQUEST['page']     ?? 1));
    $perPage  = (int)($_REQUEST['per_page'] ?? 20);
    if (!in_array($perPage, [20, 50, 100, 200], true)) $perPage = 20;
    $offset   = ($page - 1) * $perPage;

    $where = "$dateCond AND $providerCond AND s.status = '$status'";

    /* total count */
    $cRes = $conn->query("SELECT COUNT(*) AS c FROM starter_kit_payment_logs s WHERE $where");
    if ($cRes === false) sk_error('Count query failed: ' . $conn->error, 500);
    $total = (int)($cRes->fetch_assoc()['c'] ?? 0);

    /* main data */
    $sql = "SELECT
                s.id,
                s.user_id,
                s.order_id,
                s.payment_id,
                s.provider,
                s.amount,
                s.status,
                s.created_at,
                s.updated_at,
                u.name,
                u.email,
                u.phone
            FROM starter_kit_payment_logs s
            LEFT JOIN users u ON s.user_id = u.user_id
            WHERE $where
            ORDER BY s.id DESC
            LIMIT $perPage OFFSET $offset";

    $res = $conn->query($sql);
    if ($res === false) sk_error('List query failed: ' . $conn->error, 500);

    $rows = [];
    while ($r = $res->fetch_assoc()) {
        // paid date = when it turned success; for initiated fall back to created_at
        $r['paid_at'] = ($r['status'] === 'success') ? $r['updated_at'] : $r['created_at'];
        $rows[] = $r;
    }
    $conn->close();

    sk_ok([
        'rows'     => $rows,
        'total'    => $total,
        'page'     => $page,
        'per_page' => $perPage,
    ]);
}

/* ════════════════════════════════════════
   EXPORT — every matching record (no pagination) for the date range.
   status = success | initiated | all (default all, so both statuses export)
════════════════════════════════════════ */
if ($action === 'export') {
    $status = $_REQUEST['status'] ?? 'all';
    if (!in_array($status, ['success', 'initiated', 'all'], true)) {
        sk_error('Invalid status — must be success, initiated or all');
    }
    $statusCond = ($status === 'all') ? "1" : "s.status = '$status'";

    $sql = "SELECT
                s.id,
                s.user_id,
                s.order_id,
                s.payment_id,
                s.provider,
                s.amount,
                s.status,
                s.created_at,
                s.updated_at,
                u.name,
                u.email,
                u.phone
            FROM starter_kit_payment_logs s
            LEFT JOIN users u ON s.user_id = u.user_id
            WHERE $dateCond AND $providerCond AND $statusCond
            ORDER BY s.id DESC";

    $res = $conn->query($sql);
    if ($res === false) sk_error('Export query failed: ' . $conn->error, 500);

    $rows = [];
    while ($r = $res->fetch_assoc()) {
        $r['paid_at'] = ($r['status'] === 'success') ? $r['updated_at'] : $r['created_at'];
        $rows[] = $r;
    }
    $conn->close();

    sk_ok(['rows' => $rows, 'total' => count($rows)]);
}

sk_error('Unknown action: ' . $action, 404);

<?php
/*
 * Public POST receiver for SendGrid's Event Webhook.
 * Configure once real SendGrid keys are in: SendGrid dashboard →
 * Settings → Mail Settings → Event Webhook → HTTP POST URL = this file's
 * public URL. Only meaningful when a campaign's esp_transport = 'sendgrid'
 * — campaigns sent via Elastic Email are handled by the sibling
 * elasticemail-webhook.php instead.
 *
 * Each event object SendGrid posts echoes back our `custom_args.rid`
 * (set in lib/SendGridTransport.php's payload) as a top-level `rid` field —
 * that's how we correlate an async event back to our recipient row without
 * relying on sg_message_id matching.
 */
ini_set('display_errors', 0);
error_reporting(0);
header('Content-Type: application/json');

require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../lists/lib/schema.php';
require_once __DIR__ . '/../lists/lib/ContactImportWorker.php';

$raw = file_get_contents('php://input');
$events = json_decode($raw, true);
if (!is_array($events)) { http_response_code(200); echo json_encode(['ok' => true, 'processed' => 0]); exit; }

$processed = 0;
foreach ($events as $evt) {
    $rid = $evt['rid'] ?? null;
    $type = $evt['event'] ?? '';
    if (!$rid || !preg_match('/^[a-f0-9]{32}$/', $rid)) continue;

    $stmt = $conn->prepare("SELECT id, campaign_id, email FROM email_campaign_recipients WHERE rid = ? LIMIT 1");
    $stmt->bind_param('s', $rid);
    $stmt->execute();
    $recipient = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    if (!$recipient) continue;

    // 'delivered' is the real, provider-confirmed delivery signal — this is the ONLY place
    // delivered_count is incremented (the worker no longer assumes "sent" = "delivered").
    if ($type === 'delivered') {
        $conn->query("UPDATE email_campaigns SET delivered_count = delivered_count + 1 WHERE id={$recipient['campaign_id']}");
        $processed++;
        continue;
    }

    $eventTypeMap = [
        'bounce'      => 'bounce',
        'dropped'     => 'dropped',
        'deferred'    => 'deferred',
        'unsubscribe' => 'unsubscribe',
        'spamreport'  => 'spamreport',
        'open'        => null,   // opens/clicks are already tracked first-party via track-open.php/track-click.php
        'click'       => null,
    ];
    $mapped = $eventTypeMap[$type] ?? null;
    if ($mapped === null) continue;

    $meta = json_encode($evt);
    $metaE = $conn->real_escape_string($meta);
    $conn->query("INSERT INTO email_campaign_events (campaign_id, recipient_id, event_type, meta)
                  VALUES ({$recipient['campaign_id']}, {$recipient['id']}, '$mapped', '$metaE')");

    if ($mapped === 'bounce') {
        // SendGrid's own classification on the bounce event object: 'bounce' = permanent/hard
        // (invalid address, doesn't exist), 'blocked' = temporary/soft (mailbox full, greylisted,
        // receiving server temporarily refusing) — anything unrecognized defaults to hard since
        // that's the safer assumption for suppression purposes.
        $bounceType = ($evt['type'] ?? '') === 'blocked' ? 'soft' : 'hard';
        $conn->query("UPDATE email_campaign_recipients SET status='bounced', bounced_at=NOW(), bounce_type='$bounceType' WHERE id={$recipient['id']}");
        $countCol = $bounceType === 'soft' ? 'soft_bounce_count' : 'hard_bounce_count';
        $conn->query("UPDATE email_campaigns SET bounce_count = bounce_count + 1, $countCol = $countCol + 1 WHERE id={$recipient['campaign_id']}");

        // A hard bounce means the address is permanently invalid (doesn't exist) — there's no
        // point ever emailing it again, so suppress it the same way an unsubscribe would. A
        // soft bounce (mailbox full, temporarily refused) is NOT blocklisted — the address may
        // still be valid later, so future campaigns should keep trying it.
        if ($bounceType === 'hard' && !empty($recipient['email'])) {
            $blocklistId = lists_get_or_create_blocklist_id();
            contact_upsert(['email' => $recipient['email']], $blocklistId);
        }
    } elseif ($mapped === 'unsubscribe') {
        $conn->query("UPDATE email_campaigns SET unsubscribe_count = unsubscribe_count + 1 WHERE id={$recipient['campaign_id']}");

        // An unsubscribe means "never email this person again" — not just "skip them on this
        // one campaign". Add them to the single global Blocklist so AudienceResolver.php
        // excludes them from every future send, regardless of which segment/list they're in.
        if (!empty($recipient['email'])) {
            $blocklistId = lists_get_or_create_blocklist_id();
            contact_upsert(['email' => $recipient['email']], $blocklistId);
        }
    } elseif ($mapped === 'spamreport') {
        $conn->query("UPDATE email_campaigns SET spam_count = spam_count + 1 WHERE id={$recipient['campaign_id']}");

        // A spam complaint is the strongest possible negative signal — worse than an
        // unsubscribe, since it's an active complaint to the mailbox provider that hurts
        // sender reputation/deliverability for every future send. Same auto-blocklist
        // treatment as a hard bounce/unsubscribe: never email this address again.
        if (!empty($recipient['email'])) {
            $blocklistId = lists_get_or_create_blocklist_id();
            contact_upsert(['email' => $recipient['email']], $blocklistId, 'Marked as spam via SendGrid');
        }
    }
    $processed++;
}

http_response_code(200);
echo json_encode(['ok' => true, 'processed' => $processed]);

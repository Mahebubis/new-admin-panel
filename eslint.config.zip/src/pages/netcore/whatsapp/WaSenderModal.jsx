import { useState } from 'react';
import api from '../../../api/axios';
import toast from 'react-hot-toast';
import { WA_SET_API, FORM, WA, inp, label } from './waShared';
import { Notice } from './WaUi';

/*
 * Add / edit one sending number.
 *
 * Everything on this form comes from one screen in the Netcore panel:
 * Settings → Business number → ⋮ Edit → Integrate API, which shows the WhatsApp number, the
 * WABA ID, and that number's own API keys.
 *
 *   WABA ID          the ACCOUNT that owns the numbers (same for all of them)
 *   Business number  which phone the message comes from
 *   API key          issued PER NUMBER — this is what makes a message go out from it
 *   Source key       optional; only ties delivery receipts to a webhook
 *
 * A number saved without its API key is stored but flagged unusable rather than rejected, so
 * numbers can be registered before their keys are generated.
 */
export default function WaSenderModal({ sender, existingWabas = [], onClose, onSaved }) {
  const [form, setForm] = useState({
    id: sender?.id || null,
    waba_id: sender?.waba_id || (existingWabas[0]?.waba_id ?? ''),
    waba_name: sender?.waba_name || (existingWabas[0]?.waba_name ?? ''),
    business_number: sender?.business_number || '',
    display_name: sender?.display_name || '',
    api_key: '',
    source_id: sender?.source_id || '',
    quality_rating: sender?.quality_rating || '',
    messaging_limit: sender?.messaging_limit || '',
    notes: sender?.notes || '',
    is_default: sender ? Number(sender.is_default) === 1 : false,
    is_active: sender ? Number(sender.is_active) === 1 : true,
  });
  const [saving, setSaving] = useState(false);
  const set = (k, v) => setForm(f => ({ ...f, [k]: v }));
  // The stored key is never sent back to the browser, so "already has one" comes from a flag.
  const hasKey = !!sender?.has_own_api_key;

  const save = async () => {
    if (!form.waba_id.trim()) return toast.error('WABA ID is required');
    if (!form.business_number.trim()) return toast.error('Business number is required');
    setSaving(true);
    try {
      const body = new URLSearchParams({
        action: 'sender_save',
        id: form.id || '',
        waba_id: form.waba_id.trim(),
        waba_name: form.waba_name.trim(),
        business_number: form.business_number.trim(),
        display_name: form.display_name.trim(),
        // Blank means "keep whatever is stored" — the server never sends the key back, so an
        // untouched field must not blank it.
        api_key: form.api_key.trim(),
        source_id: form.source_id.trim(),
        quality_rating: form.quality_rating.trim(),
        messaging_limit: form.messaging_limit.trim(),
        notes: form.notes.trim(),
        is_default: form.is_default ? 1 : 0,
        is_active: form.is_active ? 1 : 0,
      });
      const res = await api.post(WA_SET_API, body, FORM);
      if (res.data.success) { toast.success(form.id ? 'Number updated' : 'Number added'); onSaved(); }
      else toast.error(res.data.message || 'Could not save');
    } catch (e) { toast.error(e?.response?.data?.message || 'Network error'); }
    finally { setSaving(false); }
  };

  return (
    <div style={{ position: 'fixed', inset: 0, background: 'rgba(15,23,42,.5)', zIndex: 960, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 20 }}
      onClick={() => !saving && onClose()}>
      <div style={{ background: '#fff', borderRadius: 14, padding: 26, width: 560, maxHeight: '88vh', overflowY: 'auto', fontFamily: "'Plus Jakarta Sans',sans-serif" }}
        onClick={e => e.stopPropagation()}>
        <div style={{ fontSize: 16, fontWeight: 700, color: '#0f172a', marginBottom: 4 }}>
          {form.id ? 'Edit sending number' : 'Add a sending number'}
        </div>
        <div style={{ fontSize: 12, color: '#94a3b8', marginBottom: 18 }}>
          Copy these straight out of the Netcore panel. Every number needs its own API key.
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14 }}>
          <div>
            <label style={label}>WABA ID <span style={{ color: '#dc2626' }}>*</span></label>
            <input style={inp} value={form.waba_id} onChange={e => set('waba_id', e.target.value.replace(/\s/g, ''))}
              placeholder="1229117948963194" list="wa-existing-wabas" />
            <datalist id="wa-existing-wabas">
              {existingWabas.map(w => <option key={w.waba_id} value={w.waba_id}>{w.waba_name || w.waba_id}</option>)}
            </datalist>
            <div style={{ fontSize: 10.5, color: '#94a3b8', marginTop: 4 }}>
              The account, not the number — numbers under one business share it.
            </div>
          </div>
          <div>
            <label style={label}>WABA name</label>
            <input style={inp} value={form.waba_name} onChange={e => set('waba_name', e.target.value)} placeholder="Internship studio" />
            <div style={{ fontSize: 10.5, color: '#94a3b8', marginTop: 4 }}>Label shown in the WABA dropdown.</div>
          </div>

          <div>
            <label style={label}>Business number <span style={{ color: '#dc2626' }}>*</span></label>
            <input style={inp} value={form.business_number} onChange={e => set('business_number', e.target.value)} placeholder="+91 8237850238" />
          </div>
          <div>
            <label style={label}>Display name</label>
            <input style={inp} value={form.display_name} onChange={e => set('display_name', e.target.value)} placeholder="Internship Studio" />
            <div style={{ fontSize: 10.5, color: '#94a3b8', marginTop: 4 }}>Shown in message previews.</div>
          </div>

          <div style={{ gridColumn: '1 / -1' }}>
            <label style={label}>
              API key for this number
              {hasKey && <span style={{ fontWeight: 500, color: '#94a3b8' }}> (currently {sender.api_key_masked || 'set'})</span>}
              {!hasKey && <span style={{ fontWeight: 500, color: '#dc2626' }}> — required before this number can send</span>}
            </label>
            <input style={{ ...inp, borderColor: hasKey || form.api_key.trim() ? '#e2e8f0' : '#fca5a5' }}
              type="password" autoComplete="new-password"
              value={form.api_key} onChange={e => set('api_key', e.target.value)}
              placeholder={hasKey ? 'Leave blank to keep the current key' : 'Paste this number’s API key'} />
            <div style={{ fontSize: 10.5, color: '#94a3b8', marginTop: 4 }}>
              Netcore panel → Settings → Business number → ⋮ Edit → <b>Integrate API</b> → API key 1 / 2 (Show).
              Each business number has its own key, and that key is what determines which number a message goes out from.
            </div>
          </div>

          <div style={{ gridColumn: '1 / -1' }}>
            <label style={label}>
              Source key <span style={{ fontWeight: 500, color: '#94a3b8' }}>(optional)</span>
            </label>
            <input style={inp} value={form.source_id} onChange={e => set('source_id', e.target.value.trim())}
              placeholder="Leave blank unless your webhook uses a source key" />
            <div style={{ fontSize: 10.5, color: '#94a3b8', marginTop: 4 }}>
              Sent as <code>source</code> on every message. It only routes delivery receipts: set it to match the
              <b> Source key / callbackData</b> on your Event webhook so Delivered/Read come back to us. It does
              not affect whether a message is sent.
            </div>
          </div>

          <div>
            <label style={label}>Quality rating <span style={{ fontWeight: 500, color: '#94a3b8' }}>(optional)</span></label>
            <input style={inp} value={form.quality_rating} onChange={e => set('quality_rating', e.target.value)} placeholder="HIGH" />
          </div>
          <div>
            <label style={label}>Messaging limit <span style={{ fontWeight: 500, color: '#94a3b8' }}>(optional)</span></label>
            <input style={inp} value={form.messaging_limit} onChange={e => set('messaging_limit', e.target.value)} placeholder="100000 / 24hrs" />
          </div>

          <div style={{ gridColumn: '1 / -1' }}>
            <label style={label}>Notes <span style={{ fontWeight: 500, color: '#94a3b8' }}>(optional)</span></label>
            <input style={inp} value={form.notes} onChange={e => set('notes', e.target.value)} placeholder="e.g. use for exam reminders only" />
          </div>
        </div>

        <div style={{ display: 'flex', gap: 20, marginTop: 16 }}>
          <label style={{ display: 'flex', alignItems: 'center', gap: 8, cursor: 'pointer' }}>
            <input type="checkbox" checked={form.is_default} onChange={e => set('is_default', e.target.checked)} />
            <span style={{ fontSize: 12, color: '#334155' }}>Use as the default for new campaigns</span>
          </label>
          <label style={{ display: 'flex', alignItems: 'center', gap: 8, cursor: 'pointer' }}>
            <input type="checkbox" checked={form.is_active} onChange={e => set('is_active', e.target.checked)} />
            <span style={{ fontSize: 12, color: '#334155' }}>Available for sending</span>
          </label>
        </div>

        {!hasKey && !form.api_key.trim() && (
          <Notice tone="warn" style={{ marginTop: 16 }}>
            You can save this number now and add its API key later — campaigns just won't be able to send
            from it until then. Generate or reveal the key under Business number → Edit → Integrate API.
          </Notice>
        )}

        <div style={{ display: 'flex', gap: 10, justifyContent: 'flex-end', marginTop: 20 }}>
          <button onClick={onClose} disabled={saving}
            style={{ padding: '9px 18px', border: '1.5px solid #e2e8f0', background: '#fff', borderRadius: 8, fontWeight: 700, fontSize: 12, cursor: 'pointer', fontFamily: 'inherit' }}>CANCEL</button>
          <button onClick={save} disabled={saving}
            style={{ padding: '9px 22px', border: 'none', background: WA.green, color: '#fff', borderRadius: 8, fontWeight: 700, fontSize: 12, cursor: saving ? 'wait' : 'pointer', fontFamily: 'inherit' }}>
            {saving ? 'Saving…' : form.id ? 'SAVE CHANGES' : 'ADD NUMBER'}
          </button>
        </div>
      </div>
    </div>
  );
}

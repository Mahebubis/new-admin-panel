import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import api from '../../../api/axios';
import toast from 'react-hot-toast';
import { WA_SET_API, FORM, WA, WA_CSS, WA_EXPECTED_API_VERSION, inp, label, card, fmtDt, n0 } from './waShared';
import { Spinner, WhatsAppIcon, Notice } from './WaUi';
import WaSenderModal from './WaSenderModal';

// Same base + fallback as src/api/axios.js — the webhook URL shown below has to be the real
// public one the provider will POST to, which is never localhost even in dev.
const API_BASE = import.meta.env.VITE_API_URL || 'https://cit3.internshipstudio.com/admin/react-api';

/* One row of the "is this actually going to work" checklist. This page exists as much to
   explain the failure modes as to store credentials — a WhatsApp integration can be fully
   "connected" by every visible signal and still deliver nothing. */
function CheckRow({ ok, title, children }) {
  return (
    <div style={{ display: 'flex', gap: 10, padding: '11px 0', borderBottom: '1px solid #f1f5f9' }}>
      <span style={{ width: 20, height: 20, borderRadius: '50%', flexShrink: 0, marginTop: 1, display: 'inline-flex', alignItems: 'center', justifyContent: 'center', background: ok ? '#dcfce7' : '#fee2e2', color: ok ? '#16a34a' : '#dc2626', fontSize: 12, fontWeight: 800 }}>
        {ok ? '✓' : '!'}
      </span>
      <div style={{ minWidth: 0 }}>
        <div style={{ fontSize: 12.5, fontWeight: 700, color: ok ? '#0f172a' : '#dc2626' }}>{title}</div>
        {children && <div style={{ fontSize: 11.5, color: '#64748b', marginTop: 3, lineHeight: 1.55 }}>{children}</div>}
      </div>
    </div>
  );
}

export default function WaSettings() {
  const nav = useNavigate();
  const [row, setRow] = useState(null);
  const [webhookPath, setWebhookPath] = useState('/api/whatsapp/webhook.php');
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({});

  const [testPhone, setTestPhone] = useState('');
  const [testing, setTesting] = useState(false);
  const [testResult, setTestResult] = useState(null);

  const [optinPhones, setOptinPhones] = useState('');
  const [optinBusy, setOptinBusy] = useState(false);
  const [optins, setOptins] = useState([]);
  const [optinTotal, setOptinTotal] = useState(0);

  const [senders, setSenders] = useState([]);
  const [senderModal, setSenderModal] = useState(null); // { sender } | { sender: null } for "add"
  const [confirmDelete, setConfirmDelete] = useState(null);
  // Absent on any backend older than v1's stamp, so undefined means "old" too.
  const [apiVersion, setApiVersion] = useState(null);

  const load = async () => {
    setLoading(true);
    try {
      const res = await api.post(WA_SET_API, new URLSearchParams({ action: 'get' }), FORM);
      if (res.data.success) {
        const s = res.data.data.settings;
        setRow(s);
        setSenders(res.data.data.senders || []);
        setApiVersion(Number(res.data.data.api_version) || 0);
        setWebhookPath(res.data.data.webhook_path || '/api/whatsapp/webhook.php');
        setForm({
          api_key: '',
          api_base_url: s.api_base_url || '',
          default_country_code: s.default_country_code || '91',
          webhook_secret: s.webhook_secret || '',
        });
      }
    } finally { setLoading(false); }
  };

  const senderAction = async (action, id) => {
    const t = toast.loading('Working…');
    try {
      const res = await api.post(WA_SET_API, new URLSearchParams({ action, id }), FORM);
      if (res.data.success) {
        const affected = res.data.data?.affected_drafts;
        toast.success(
          affected ? `Done — ${affected} draft(s) will fall back to the default number` : 'Done',
          { id: t, duration: affected ? 6000 : 3000 },
        );
        load();
      } else toast.error(res.data.message || 'Failed', { id: t });
    } catch (e) { toast.error(e?.response?.data?.message || 'Network error', { id: t }); }
  };

  const loadOptins = async () => {
    try {
      const res = await api.post(WA_SET_API, new URLSearchParams({ action: 'optin_list', page: 1, per_page: 10 }), FORM);
      if (res.data.success) { setOptins(res.data.data.optins || []); setOptinTotal(res.data.data.total || 0); }
    } catch { /* non-critical */ }
  };

  useEffect(() => { load(); loadOptins(); }, []);

  const set = (k, v) => setForm(f => ({ ...f, [k]: v }));

  const save = async () => {
    setSaving(true);
    const t = toast.loading('Saving…');
    try {
      const body = { action: 'save', ...form };
      // An untouched key field must not blank the stored credential.
      if (!body.api_key) delete body.api_key;
      const res = await api.post(WA_SET_API, new URLSearchParams(body), FORM);
      if (res.data.success) { toast.success('Saved', { id: t }); load(); }
      else toast.error(res.data.message || 'Failed', { id: t });
    } catch (e) { toast.error(e?.response?.data?.message || 'Network error', { id: t }); }
    finally { setSaving(false); }
  };

  const runTest = async () => {
    if (!testPhone.trim()) return toast.error('Enter a number to test against — your own works well');
    setTesting(true); setTestResult(null);
    try {
      const res = await api.post(WA_SET_API, new URLSearchParams({ action: 'test', phone: testPhone }), FORM);
      if (res.data.success) { setTestResult(res.data.data); loadOptins(); }
      else setTestResult({ ok: false, message: res.data.message || 'Test failed', notes: [] });
    } catch (e) {
      setTestResult({ ok: false, message: e?.response?.data?.message || 'Network error', notes: [] });
    } finally { setTesting(false); }
  };

  const registerConsent = async (type) => {
    if (!optinPhones.trim()) return toast.error('Enter at least one number');
    setOptinBusy(true);
    const t = toast.loading(type === 'optin' ? 'Registering opt-in…' : 'Registering opt-out…');
    try {
      const res = await api.post(WA_SET_API, new URLSearchParams({ action: 'optin', phones: optinPhones, type }), FORM);
      if (res.data.success) {
        const d = res.data.data;
        toast.success(`${d.registered} number(s) registered${d.invalid.length ? `, ${d.invalid.length} invalid` : ''}`, { id: t });
        if (d.errors?.length) toast.error(d.errors[0], { duration: 6000 });
        setOptinPhones('');
        loadOptins(); load();
      } else toast.error(res.data.message || 'Failed', { id: t });
    } catch (e) { toast.error(e?.response?.data?.message || 'Network error', { id: t }); }
    finally { setOptinBusy(false); }
  };

  if (loading || !row) {
    return <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', height: '100vh' }}><Spinner /></div>;
  }

  const webhookUrl = API_BASE + webhookPath;

  return (
    <div style={{ fontFamily: "'Plus Jakarta Sans', sans-serif", background: '#f8fafc', minHeight: '100vh' }}>
      <style>{WA_CSS}</style>

      <div style={{ maxWidth: 860, margin: '0 auto', padding: '26px 26px 80px' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 14, marginBottom: 20 }}>
          <button onClick={() => nav('/netcore/whatsapp')}
            style={{ border: 'none', background: '#f1f5f9', borderRadius: 8, width: 34, height: 34, cursor: 'pointer', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', color: '#334155' }}>
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2.2}><path d="m15 18-6-6 6-6" /></svg>
          </button>
          <span style={{ width: 36, height: 36, borderRadius: 9, background: WA.green, color: '#fff', display: 'inline-flex', alignItems: 'center', justifyContent: 'center' }}>
            <WhatsAppIcon size={20} color="#fff" />
          </span>
          <div>
            <div style={{ fontSize: 19, fontWeight: 700, color: '#0f172a' }}>WhatsApp settings</div>
            <div style={{ fontSize: 11.5, color: '#94a3b8' }}>Credentials and sending identity for the WhatsApp Business API</div>
          </div>
        </div>

        {/* The one mismatch that makes this page lie: a saved field the running backend doesn't
            know about is accepted by the form and then ignored, with nothing to show for it. */}
        {apiVersion !== null && apiVersion < WA_EXPECTED_API_VERSION && (
          <Notice tone="danger" title="The WhatsApp backend on the server is out of date" style={{ marginBottom: 18 }}>
            This page needs API v{WA_EXPECTED_API_VERSION} but the server is running
            v{apiVersion || '1'}. Until it's updated, the per-number <b>API key</b> field is
            ignored on save — which is exactly why a number can still show <b>NO API KEY</b> right
            after you entered one.
            <div style={{ marginTop: 6 }}>
              Re-upload <code>public/react-api/api/whatsapp/</code> (all files, including
              <code> lib/</code>) to the server, then reload this page.
            </div>
          </Notice>
        )}

        {/* ── Readiness checklist ──────────────────────────────────────────────────────── */}
        <div style={{ ...card, borderColor: row.ready ? '#bbf7d0' : '#fed7aa' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 6 }}>
            <div style={{ fontSize: 15, fontWeight: 700, color: '#0f172a' }}>Connection status</div>
            <span style={{ padding: '5px 12px', borderRadius: 999, fontSize: 11, fontWeight: 800, letterSpacing: '.3px', background: row.ready ? '#dcfce7' : '#fef3c7', color: row.ready ? '#15803d' : '#b45309' }}>
              {row.ready ? 'READY TO SEND' : 'SETUP INCOMPLETE'}
            </span>
          </div>
          <div style={{ fontSize: 12, color: '#94a3b8', marginBottom: 8 }}>
            The first two must be true to send at all. The third is what decides whether the message
            actually arrives.
          </div>

          <CheckRow ok={row.usable_senders > 0} title="A sending number with its own API key">
            {row.usable_senders > 0
              ? `${row.usable_senders} of ${row.sender_count} number(s) can send.`
              : (row.sender_count > 0
                ? 'Numbers are saved, but none has an API key yet.'
                : 'No sending numbers added yet.')}
            {' '}Netcore issues the API key <b>per business number</b> (Business number → Edit → Integrate
            API), so the key is what decides which number a message goes out from.
          </CheckRow>
          <CheckRow ok={row.template_count > 0} title="Approved templates registered">
            {row.template_count > 0
              ? `${row.template_count} template(s) registered here.`
              : 'None yet. Use "Sync from provider" on the Templates page to import the ones Meta already approved.'}
            {' '}<b>An unapproved template name is accepted by the API and then silently dropped</b> — the
            most common reason a campaign reports thousands sent with nobody receiving anything.
          </CheckRow>
          <CheckRow ok={row.senders_with_source > 0} title="Source key set (for delivery receipts)">
            Optional. It only ties a message to a webhook's <b>Source key / callbackData</b> so
            Delivered/Read flow back here. Messages send fine without it — those counters just stay at 0.
          </CheckRow>
          <div style={{ display: 'flex', gap: 10, padding: '11px 0' }}>
            <span style={{ width: 20, height: 20, borderRadius: '50%', flexShrink: 0, marginTop: 1, display: 'inline-flex', alignItems: 'center', justifyContent: 'center', background: '#eff6ff', color: '#1d4ed8', fontSize: 12, fontWeight: 800 }}>i</span>
            <div>
              <div style={{ fontSize: 12.5, fontWeight: 700, color: '#0f172a' }}>Consent</div>
              <div style={{ fontSize: 11.5, color: '#64748b', marginTop: 3, lineHeight: 1.55 }}>
                {n0(row.optin_count)} opt-in(s) recorded here. Opt-in is not required for approved utility
                templates on this account — what matters is <b>opt-out</b>: anyone who opted out or replied
                STOP is excluded from every campaign automatically.
              </div>
            </div>
          </div>
        </div>

        {/* ── Account-level settings ──────────────────────────────────────────────────── */}
        <div style={card}>
          <div style={{ fontSize: 15, fontWeight: 700, color: '#0f172a', marginBottom: 2 }}>Account settings</div>
          <div style={{ fontSize: 12, color: '#94a3b8', marginBottom: 16 }}>
            API keys live on each sending number below — Netcore issues one per business number.
          </div>

          <div style={{ marginBottom: 14 }}>
            <label style={label}>
              Fallback API key <span style={{ fontWeight: 500, color: '#94a3b8' }}>(optional, currently {row.api_key_masked})</span>
            </label>
            <input style={inp} type="password" value={form.api_key} onChange={e => set('api_key', e.target.value)}
              placeholder="Leave blank — set the key on each number instead" autoComplete="new-password" />
            <div style={{ fontSize: 10.5, color: '#94a3b8', marginTop: 4 }}>
              Used only by numbers that have no key of their own. With two numbers configured, give each its
              own key — otherwise both would send through whichever number this key belongs to.
            </div>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14 }}>
            <div>
              <label style={label}>Default country code</label>
              <input style={inp} value={form.default_country_code} onChange={e => set('default_country_code', e.target.value.replace(/\D/g, ''))} placeholder="91" />
              <div style={{ fontSize: 10.5, color: '#94a3b8', marginTop: 4 }}>Prefixed to stored contact numbers that have none (a bare 10-digit mobile).</div>
            </div>
            <div>
              <label style={label}>API base URL</label>
              <input style={inp} value={form.api_base_url} onChange={e => set('api_base_url', e.target.value)} placeholder="https://waapi.pepipost.com/api/v2/" />
            </div>
          </div>

          <div style={{ marginTop: 18, textAlign: 'right' }}>
            <button onClick={save} disabled={saving}
              style={{ padding: '10px 24px', border: 'none', background: WA.primary, color: '#fff', borderRadius: 8, fontSize: 12, fontWeight: 700, cursor: saving ? 'wait' : 'pointer', fontFamily: 'inherit' }}>
              {saving ? 'Saving…' : 'Save credentials'}
            </button>
          </div>
        </div>

        {/* ── Sending numbers ─────────────────────────────────────────────────────────── */}
        <div style={card}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', gap: 14, marginBottom: 4 }}>
            <div>
              <div style={{ fontSize: 15, fontWeight: 700, color: '#0f172a' }}>Sending numbers</div>
              <div style={{ fontSize: 12, color: '#94a3b8', marginTop: 2, lineHeight: 1.5 }}>
                A WABA can own several business numbers, and <b>each number has its own API key</b>.
                Campaigns pick which number they go out from.
              </div>
            </div>
            <button onClick={() => setSenderModal({ sender: null })}
              style={{ padding: '9px 16px', border: 'none', background: WA.green, color: '#fff', borderRadius: 8, fontSize: 12, fontWeight: 700, cursor: 'pointer', whiteSpace: 'nowrap', fontFamily: 'inherit' }}>
              + Add number
            </button>
          </div>

          {senders.length === 0 ? (
            <Notice tone="warn" style={{ marginTop: 14 }} title="No sending numbers yet">
              Add each business number from your Netcore panel, along with the API key shown for it under
              Business number → Edit → Integrate API. Campaigns cannot send until at least one number here
              has its API key.
            </Notice>
          ) : (
            <div style={{ marginTop: 14, display: 'flex', flexDirection: 'column', gap: 10 }}>
              {senders.map(s => (
                <div key={s.id} style={{
                  border: `1.5px solid ${s.is_default ? WA.greenDark : '#e2e8f0'}`,
                  background: s.is_default ? '#f0fdf4' : '#fff',
                  borderRadius: 10, padding: '13px 15px', opacity: s.is_active ? 1 : .6,
                }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', gap: 12 }}>
                    <div style={{ minWidth: 0 }}>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 8, flexWrap: 'wrap' }}>
                        <span style={{ fontSize: 13.5, fontWeight: 700, color: '#0f172a' }}>{s.business_number}</span>
                        {s.display_name && <span style={{ fontSize: 12, color: '#64748b' }}>{s.display_name}</span>}
                        {s.is_default === 1 && (
                          <span style={{ background: WA.greenDark, color: '#fff', fontSize: 9, fontWeight: 800, padding: '2px 7px', borderRadius: 999, letterSpacing: '.3px' }}>DEFAULT</span>
                        )}
                        {s.is_active !== 1 && (
                          <span style={{ background: '#f1f5f9', color: '#64748b', fontSize: 9, fontWeight: 800, padding: '2px 7px', borderRadius: 999 }}>OFF</span>
                        )}
                        <span style={{ background: s.ready ? '#dcfce7' : '#fee2e2', color: s.ready ? '#15803d' : '#dc2626', fontSize: 9, fontWeight: 800, padding: '2px 7px', borderRadius: 999, letterSpacing: '.3px' }}>
                          {s.ready ? 'CAN SEND' : 'NO API KEY'}
                        </span>
                      </div>
                      <div style={{ fontSize: 11, color: '#94a3b8', marginTop: 4 }}>
                        WABA {s.waba_id}{s.waba_name ? ` · ${s.waba_name}` : ''}
                        {s.quality_rating ? ` · quality ${s.quality_rating}` : ''}
                        {s.messaging_limit ? ` · ${s.messaging_limit}` : ''}
                      </div>
                      <div style={{ fontSize: 10.5, color: s.ready ? '#64748b' : '#dc2626', marginTop: 3, wordBreak: 'break-all' }}>
                        API key: {s.has_own_api_key ? s.api_key_masked : (s.ready ? 'using the account-level key' : 'not set — this number cannot send')}
                        {' · '}Source key: {s.source_id || 'none'}
                      </div>
                      {s.notes && <div style={{ fontSize: 10.5, color: '#94a3b8', marginTop: 3 }}>{s.notes}</div>}
                    </div>
                    <div style={{ display: 'flex', gap: 6, flexShrink: 0 }}>
                      {s.is_default !== 1 && (
                        <button onClick={() => senderAction('sender_default', s.id)} title="Use for new campaigns"
                          style={{ padding: '6px 10px', border: '1.5px solid #e2e8f0', background: '#fff', borderRadius: 6, fontSize: 10.5, fontWeight: 700, color: '#475569', cursor: 'pointer', whiteSpace: 'nowrap', fontFamily: 'inherit' }}>
                          Make default
                        </button>
                      )}
                      <button onClick={() => setSenderModal({ sender: s })}
                        style={{ padding: '6px 12px', border: '1.5px solid #e2e8f0', background: '#fff', borderRadius: 6, fontSize: 10.5, fontWeight: 700, color: WA.primary, cursor: 'pointer', fontFamily: 'inherit' }}>
                        Edit
                      </button>
                      <button onClick={() => setConfirmDelete(s)}
                        style={{ padding: '6px 10px', border: '1.5px solid #fecaca', background: '#fff', borderRadius: 6, fontSize: 10.5, fontWeight: 700, color: '#dc2626', cursor: 'pointer', fontFamily: 'inherit' }}>
                        Delete
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* ── Connection test ─────────────────────────────────────────────────────────── */}
        <div style={card}>
          <div style={{ fontSize: 15, fontWeight: 700, color: '#0f172a', marginBottom: 2 }}>Check the credentials</div>
          <div style={{ fontSize: 12, color: '#94a3b8', marginBottom: 14 }}>
            There is no ping endpoint on this API, so the honest check is a real consent call using the
            default number's key: a success proves that key is live. It does <b>not</b> prove your templates
            are approved — only a delivered message does, so send a test from a campaign too.
          </div>
          <div style={{ display: 'flex', gap: 10, alignItems: 'flex-end' }}>
            <div style={{ flex: 1, maxWidth: 280 }}>
              <label style={label}>Your WhatsApp number</label>
              <input style={inp} value={testPhone} onChange={e => setTestPhone(e.target.value)} placeholder="9921079337" />
            </div>
            <button onClick={runTest} disabled={testing}
              style={{ padding: '10px 20px', border: `1.5px solid ${WA.greenDark}`, background: '#fff', color: WA.greenDark, borderRadius: 8, fontSize: 12, fontWeight: 700, cursor: testing ? 'wait' : 'pointer', fontFamily: 'inherit' }}>
              {testing ? 'Checking…' : 'Run check'}
            </button>
          </div>

          {testResult && (
            <Notice tone={testResult.ok ? 'success' : 'danger'} style={{ marginTop: 14 }}
              title={testResult.ok ? 'Credentials accepted' : 'The provider rejected the request'}>
              {testResult.message}
              {(testResult.notes || []).map((n, i) => <div key={i} style={{ marginTop: 6 }}>• {n}</div>)}
            </Notice>
          )}
        </div>

        {/* ── Consent ─────────────────────────────────────────────────────────────────── */}
        <div style={card}>
          <div style={{ fontSize: 15, fontWeight: 700, color: '#0f172a', marginBottom: 2 }}>Consent management</div>
          <div style={{ fontSize: 12, color: '#94a3b8', marginBottom: 14 }}>
            Mirrors the panel's Consent management page. <b>Opt-out is the one that matters here</b> — those
            numbers are excluded from every campaign automatically, and a contact replying "STOP" is opted
            out for you. Opt-in registration is optional for approved utility templates.
          </div>
          <label style={label}>Numbers <span style={{ fontWeight: 500, color: '#94a3b8' }}>(comma, semicolon or newline separated)</span></label>
          <textarea rows={3} style={{ ...inp, resize: 'vertical' }} value={optinPhones}
            onChange={e => setOptinPhones(e.target.value)} placeholder="9921079337, 919876543210" />
          <div style={{ display: 'flex', gap: 10, marginTop: 12 }}>
            <button onClick={() => registerConsent('optin')} disabled={optinBusy}
              style={{ padding: '9px 18px', border: 'none', background: WA.green, color: '#fff', borderRadius: 8, fontSize: 12, fontWeight: 700, cursor: optinBusy ? 'wait' : 'pointer', fontFamily: 'inherit' }}>
              Register opt-in
            </button>
            <button onClick={() => registerConsent('optout')} disabled={optinBusy}
              style={{ padding: '9px 18px', border: '1.5px solid #fecaca', background: '#fff', color: '#dc2626', borderRadius: 8, fontSize: 12, fontWeight: 700, cursor: optinBusy ? 'wait' : 'pointer', fontFamily: 'inherit' }}>
              Register opt-out
            </button>
          </div>

          {optins.length > 0 && (
            <div style={{ marginTop: 18 }}>
              <div style={{ fontSize: 11.5, fontWeight: 800, color: '#475569', marginBottom: 8 }}>
                MOST RECENT ({n0(optinTotal)} total)
              </div>
              <div style={{ border: '1px solid #e2e8f0', borderRadius: 8, overflow: 'hidden' }}>
                {optins.map((o, i) => (
                  <div key={o.phone} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 12, padding: '8px 12px', fontSize: 11.5, borderBottom: i < optins.length - 1 ? '1px solid #f1f5f9' : 'none' }}>
                    <span style={{ fontWeight: 600, color: '#334155' }}>+{o.phone}</span>
                    <span style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
                      <span style={{ color: '#94a3b8' }}>{o.source}</span>
                      <span style={{ color: '#94a3b8' }}>{fmtDt(o.updated_at)}</span>
                      <span style={{ padding: '2px 8px', borderRadius: 999, fontSize: 9.5, fontWeight: 800, background: o.status === 'optin' ? '#dcfce7' : '#fee2e2', color: o.status === 'optin' ? '#15803d' : '#dc2626' }}>
                        {o.status === 'optin' ? 'OPTED IN' : 'OPTED OUT'}
                      </span>
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* ── Webhook ─────────────────────────────────────────────────────────────────── */}
        <div style={card}>
          <div style={{ fontSize: 15, fontWeight: 700, color: '#0f172a', marginBottom: 2 }}>Delivery webhook</div>
          <div style={{ fontSize: 12, color: '#94a3b8', marginBottom: 14 }}>
            Register this URL per business number: Netcore panel → Settings → Business number → ⋮ Edit →
            <b> Webhook Integration → Event → + Add event webhook</b>. It is the only thing that can move
            Delivered / Read / Clicked — a send API returning success means "accepted", not "delivered", so
            those counters stay at 0 until it's wired up. If you give the webhook a <b>Source key</b>, put
            the same value in that number's Source key field above.
          </div>
          <div style={{ padding: '11px 13px', background: '#f8fafc', border: '1px solid #e2e8f0', borderRadius: 8, marginBottom: 14 }}>
            <code style={{ fontSize: 11.5, color: WA.primary, wordBreak: 'break-all' }}>{webhookUrl}</code>
          </div>
          <label style={label}>Webhook secret <span style={{ fontWeight: 500, color: '#94a3b8' }}>(optional)</span></label>
          <input style={{ ...inp, maxWidth: 360 }} value={form.webhook_secret} onChange={e => set('webhook_secret', e.target.value)}
            placeholder="Leave blank to accept unauthenticated callbacks" />
          <div style={{ fontSize: 10.5, color: '#94a3b8', marginTop: 4 }}>
            When set, the webhook only accepts calls carrying it as <code>?secret=…</code> or an
            <code> X-Webhook-Secret</code> header — so register the URL first, then add the secret.
          </div>
        </div>
      </div>

      {senderModal && (
        <WaSenderModal
          sender={senderModal.sender}
          // Offered as suggestions when adding a second number — in practice every number
          // belongs to the same WABA, and retyping a 16-digit id is how they end up mismatched.
          existingWabas={Object.values(senders.reduce((acc, s) => {
            if (!acc[s.waba_id]) acc[s.waba_id] = { waba_id: s.waba_id, waba_name: s.waba_name };
            return acc;
          }, {}))}
          onClose={() => setSenderModal(null)}
          onSaved={() => { setSenderModal(null); load(); }}
        />
      )}

      {confirmDelete && (
        <div style={{ position: 'fixed', inset: 0, background: 'rgba(15,23,42,.5)', zIndex: 960, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 20 }}
          onClick={() => setConfirmDelete(null)}>
          <div style={{ background: '#fff', borderRadius: 14, padding: 26, width: 420, fontFamily: "'Plus Jakarta Sans',sans-serif" }} onClick={e => e.stopPropagation()}>
            <div style={{ fontSize: 15, fontWeight: 700, color: '#0f172a', marginBottom: 8 }}>
              Remove {confirmDelete.business_number}?
            </div>
            <div style={{ fontSize: 12, color: '#64748b', lineHeight: 1.6, marginBottom: 20 }}>
              Campaigns that already sent or are scheduled keep their own copy of this number, so nothing
              in flight changes. Drafts pointing at it will fall back to the default number.
            </div>
            <div style={{ display: 'flex', gap: 10, justifyContent: 'flex-end' }}>
              <button onClick={() => setConfirmDelete(null)}
                style={{ padding: '9px 18px', border: '1.5px solid #e2e8f0', background: '#fff', borderRadius: 8, fontWeight: 700, fontSize: 12, cursor: 'pointer', fontFamily: 'inherit' }}>CANCEL</button>
              <button onClick={() => { senderAction('sender_delete', confirmDelete.id); setConfirmDelete(null); }}
                style={{ padding: '9px 18px', border: 'none', background: '#dc2626', color: '#fff', borderRadius: 8, fontWeight: 700, fontSize: 12, cursor: 'pointer', fontFamily: 'inherit' }}>REMOVE</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

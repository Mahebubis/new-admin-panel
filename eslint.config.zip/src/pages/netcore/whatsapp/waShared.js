/*
 * Constants, styling tokens and formatters for the WhatsApp campaign builder.
 *
 * Deliberately JSX-free and kept separate from WaUi.jsx (which holds the shared components):
 * mixing component and non-component exports in one file breaks Fast Refresh, which this
 * project's eslint config enforces.
 *
 * The visual language matches the existing /netcore email builder (Plus Jakarta Sans,
 * #1e3a8a primary, the same card/input/toggle shapes) so the two channels read as one
 * product — WhatsApp green appears only where the channel itself is being identified (chrome,
 * message bubbles, send buttons), never as a second primary.
 */

export const WA_API      = '/api/whatsapp/wa_campaigns.php';
export const WA_TPL_API  = '/api/whatsapp/wa_templates.php';
export const WA_SET_API  = '/api/whatsapp/wa_settings.php';
export const SEG_API     = '/api/netcore/segments.php';
export const LISTS_API   = '/api/lists/lists.php';
export const ATTR_API    = '/api/attributes/attributes.php';

export const FORM = { headers: { 'Content-Type': 'application/x-www-form-urlencoded' } };

/* The wa_settings.php version this build needs. public/react-api deploys separately from the
   React bundle, so the Settings page compares the two and says so when the backend is older —
   otherwise a field you filled in is silently ignored with no visible reason. Keep in step with
   WA_API_VERSION in whatsapp/lib/config.php. */
export const WA_EXPECTED_API_VERSION = 3;

export const WA = {
  green: '#25D366',
  greenDark: '#128C7E',
  greenInk: '#075E54',
  bubble: '#DCF8C6',
  chat: '#ECE5DD',
  primary: '#1e3a8a',
};

export const inp = {
  width: '100%', padding: '10px 12px', border: '1.5px solid #e2e8f0', borderRadius: 8,
  fontSize: 12.5, fontFamily: 'inherit', color: '#1e293b', outline: 'none', boxSizing: 'border-box',
};
export const label = { display: 'block', fontSize: 12, fontWeight: 700, color: '#0f172a', marginBottom: 6 };
export const card  = { background: '#fff', border: '1px solid #e2e8f0', borderRadius: 12, padding: 20, marginBottom: 18 };

/* ── formatters ────────────────────────────────────────────────────────────────────── */

export const n0 = v => Number(v || 0).toLocaleString();

export function fmtDt(s) {
  if (!s) return 'NA';
  const d = new Date(String(s).replace(' ', 'T'));
  if (isNaN(d.getTime())) return s;
  const pad = n => String(n).padStart(2, '0');
  const M = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'][d.getMonth()];
  return `${M} ${pad(d.getDate())}, ${d.getFullYear()} ${pad(d.getHours() % 12 || 12)}:${pad(d.getMinutes())} ${d.getHours() < 12 ? 'AM' : 'PM'}`;
}

export function fmtDate(s) {
  if (!s) return '';
  const d = new Date(String(s).replace(' ', 'T'));
  if (isNaN(d.getTime())) return s;
  const pad = n => String(n).padStart(2, '0');
  return `${['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'][d.getMonth()]} ${pad(d.getDate())}, ${d.getFullYear()}`;
}

/* Client-side preview of the same normalization the server applies (wa_normalize_phone() in
   whatsapp/lib/WaAudienceResolver.php) — used purely to show an admin what a number they typed
   will become. The server always re-normalizes; this never decides anything on its own. */
export function previewNormalizedPhone(raw, cc = '91') {
  const hadPlus = String(raw || '').trim().startsWith('+');
  let digits = String(raw || '').replace(/\D+/g, '');
  if (!digits) return null;
  if (digits.length > 10 && digits.startsWith('0')) digits = digits.replace(/^0+/, '');
  if (digits.startsWith('00')) digits = digits.slice(2);
  if (!hadPlus && digits.length === 10) digits = cc + digits;
  if (digits.length < 10 || digits.length > 15) return null;
  return digits;
}

/** Shared keyframes/utility CSS — dropped once per page via <style>. */
export const WA_CSS = `
  @keyframes nc_spin { to { transform: rotate(360deg); } }
  @keyframes wa_indeterminate { 0% { left: -40%; } 100% { left: 100%; } }
  .wa *{ box-sizing:border-box; font-family:'Plus Jakarta Sans',sans-serif; }
  .wa-tab { padding: 10px 4px; margin-right: 22px; font-size: 13px; font-weight: 600; color: #64748b; border-bottom: 2px solid transparent; cursor: pointer; white-space: nowrap; background:none; border-top:none; border-left:none; border-right:none; font-family: inherit; }
  .wa-tab.active { color: ${WA.primary}; border-bottom-color: ${WA.primary}; }
  .wa-row:hover td { background: #f0fdf4; }
  .wa-dots { background: none; border: none; cursor: pointer; padding: 4px; color: #1e293b; border-radius: 6px; }
  .wa-dots:hover, .wa-dots.open { color: ${WA.primary}; background: #eef2ff; }
  .wa-progress-track { position: relative; height: 5px; border-radius: 999px; background: #e2e8f0; overflow: hidden; }
  .wa-progress-indeterminate { position: absolute; top: 0; left: -40%; height: 100%; width: 40%; background: ${WA.green}; border-radius: 999px; animation: wa_indeterminate 1.1s ease-in-out infinite; }
  .wa-card-hover { transition: box-shadow .15s, border-color .15s; }
  .wa-card-hover:hover { border-color: ${WA.greenDark}; box-shadow: 0 6px 18px rgba(18,140,126,.12); }
`;

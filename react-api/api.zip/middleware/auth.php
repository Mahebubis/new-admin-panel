<?php
/**
 * JWT Authentication Middleware
 * Custom HS256 JWT implementation (no external library needed)
 */

function base64url_encode($data) {
    return rtrim(strtr(base64_encode($data), '+/', '-_'), '=');
}

function base64url_decode($data) {
    return base64_decode(strtr($data, '-_', '+/'));
}

function jwt_encode($payload) {
    $header = json_encode(['typ' => 'JWT', 'alg' => 'HS256']);
    $payload = json_encode($payload);

    $base = base64url_encode($header) . '.' . base64url_encode($payload);
    $signature = hash_hmac('sha256', $base, JWT_SECRET_KEY, true);

    return $base . '.' . base64url_encode($signature);
}

function jwt_decode($token) {
    $parts = explode('.', $token);
    if (count($parts) !== 3) return null;

    $base = $parts[0] . '.' . $parts[1];
    $signature = base64url_decode($parts[2]);
    $expected = hash_hmac('sha256', $base, JWT_SECRET_KEY, true);

    if (!hash_equals($expected, $signature)) return null;

    $payload = json_decode(base64url_decode($parts[1]), true);
    if (!$payload) return null;

    // Check expiration
    if (isset($payload['exp']) && $payload['exp'] < time()) return null;

    return $payload;
}

function get_bearer_token() {
    $auth = $_SERVER['HTTP_AUTHORIZATION'] ?? '';
    if (preg_match('/Bearer\s+(.+)$/i', $auth, $m)) {
        return $m[1];
    }
    return $_GET['token'] ?? null;
}

function require_jwt() {
    $token = get_bearer_token();
    if (!$token) {
        api_error('No authentication token provided', 401);
    }

    $payload = jwt_decode($token);
    if (!$payload) {
        api_error('Invalid or expired token', 401);
    }

    return $payload;
}

function get_admin_permissions($user_id, $conn) {
    // Check if superadmin
    $stmt = $conn->prepare("SELECT is_superadmin FROM admin_users WHERE user_id = ? AND is_active = 1");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result()->fetch_assoc();

    if ($result && $result['is_superadmin']) {
        return ['__superadmin__'];
    }

    // Get individual permissions
    $stmt = $conn->prepare("SELECT permission_key FROM admin_permissions WHERE user_id = ? AND granted = 1");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $res = $stmt->get_result();

    $perms = ['dashboard'];
    while ($row = $res->fetch_assoc()) {
        $perms[] = $row['permission_key'];
    }

    return array_unique($perms);
}

function has_permission($key, $jwt_data) {
    $perms = $jwt_data['permissions'] ?? [];
    if (in_array('__superadmin__', $perms)) return true;
    if ($key === 'dashboard') return true;
    return in_array($key, $perms);
}

function require_permission($key, $jwt_data) {
    if (!has_permission($key, $jwt_data)) {
        api_error('You do not have permission for this action', 403);
    }
}

function is_superadmin($jwt_data) {
    return in_array('__superadmin__', $jwt_data['permissions'] ?? []);
}

// Response helpers
function api_success($data = [], $message = 'Success', $code = 200) {
    http_response_code($code);
    echo json_encode(['success' => true, 'message' => $message, 'data' => $data]);
    exit();
}

function api_error($message = 'Error', $code = 400) {
    http_response_code($code);
    echo json_encode(['success' => false, 'message' => $message, 'data' => []]);
    exit();
}

function get_json_input() {
    $input = json_decode(file_get_contents('php://input'), true);
    return $input ?: [];
}

function get_client_ip() {
    return $_SERVER['HTTP_CF_CONNECTING_IP']
        ?? $_SERVER['HTTP_X_FORWARDED_FOR']
        ?? $_SERVER['HTTP_CLIENT_IP']
        ?? $_SERVER['REMOTE_ADDR']
        ?? '0.0.0.0';
}

function require_method($method) {
    if ($_SERVER['REQUEST_METHOD'] !== strtoupper($method)) {
        api_error('Method not allowed', 405);
    }
}

// Pagination helper
function get_pagination() {
    $page = max(1, intval($_GET['page'] ?? 1));
    $per_page = max(1, min(100, intval($_GET['per_page'] ?? $_GET['limit'] ?? 20)));
    $offset = ($page - 1) * $per_page;
    return [$page, $per_page, $offset];
}

function get_search() {
    return trim($_GET['search'] ?? $_GET['keyword'] ?? '');
}

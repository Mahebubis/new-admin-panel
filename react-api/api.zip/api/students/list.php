<?php
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../middleware/auth.php';

require_method('GET');
$jwt = require_jwt();
require_permission('all_students', $jwt);

[$page, $per_page, $offset] = get_pagination();
$search = get_search();

$where = "WHERE u.role = 4";
$params = [];
$types = '';

if ($search) {
    $like = "%$search%";
    $where .= " AND (u.name LIKE ? OR u.email LIKE ? OR u.phone LIKE ?)";
    $params = [$like, $like, $like];
    $types = 'sss';
}

$status = $_GET['status'] ?? '';
if ($status === 'active') { $where .= " AND u.active = 1"; }
elseif ($status === 'inactive') { $where .= " AND u.active = 0"; }

// Count
$countSql = "SELECT COUNT(*) AS c FROM users u $where";
$stmt = $conn->prepare($countSql);
if ($params) $stmt->bind_param($types, ...$params);
$stmt->execute();
$total = $stmt->get_result()->fetch_assoc()['c'];

// Data
$sql = "
    SELECT u.user_id, u.name, u.email,
           COALESCE(u.phone,'') AS phone,
           COALESCE(u.branch,'') AS course,
           COALESCE(u.cit_id,'') AS batch,
           COALESCE(u.city,'') AS city,
           CASE WHEN u.active=1 THEN 'active' ELSE 'inactive' END AS status,
           u.photo, DATE(u.registered_at) AS registered_at
    FROM users u $where
    ORDER BY u.user_id DESC
    LIMIT ? OFFSET ?
";
$stmt = $conn->prepare($sql);
$allParams = array_merge($params, [$per_page, $offset]);
$allTypes = $types . 'ii';
$stmt->bind_param($allTypes, ...$allParams);
$stmt->execute();
$students = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

api_success(['students' => $students, 'total' => (int)$total, 'page' => $page]);

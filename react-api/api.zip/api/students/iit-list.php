<?php
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../middleware/auth.php';

require_method('GET');
$jwt = require_jwt();
require_permission('all_iit_students', $jwt);

[$page, $per_page, $offset] = get_pagination();
$search = get_search();

$where = "WHERE (u.college_name LIKE '%IIT%' OR u.college_name LIKE '%Indian Institute of Technology%')";
$params = [];
$types = '';

if ($search) {
    $like = "%$search%";
    $where .= " AND (u.name LIKE ? OR u.email LIKE ?)";
    $params = [$like, $like];
    $types = 'ss';
}

$countSql = "SELECT COUNT(*) AS c FROM users u $where";
$stmt = $conn->prepare($countSql);
if ($params) $stmt->bind_param($types, ...$params);
$stmt->execute();
$total = $stmt->get_result()->fetch_assoc()['c'];

$sql = "
    SELECT u.user_id, u.name, u.email,
           COALESCE(u.phone,'') AS phone,
           COALESCE(u.college_name,'') AS college,
           COALESCE(u.branch,'') AS course,
           COALESCE(u.cit_id,'') AS batch,
           CASE WHEN u.active=1 THEN 'active' ELSE 'inactive' END AS status,
           DATE(u.registered_at) AS registered_at
    FROM users u $where
    ORDER BY u.user_id DESC LIMIT ? OFFSET ?
";
$stmt = $conn->prepare($sql);
$allParams = array_merge($params, [$per_page, $offset]);
$stmt->bind_param($types . 'ii', ...$allParams);
$stmt->execute();
$students = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

api_success(['students' => $students, 'total' => (int)$total, 'page' => $page]);

<?php
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../middleware/auth.php';

require_method('POST');
$jwt = require_jwt();
require_permission('all_students', $jwt);

$input = get_json_input();
$action = $input['action'] ?? '';
$user_id = intval($input['user_id'] ?? 0);

if (!$user_id || !in_array($action, ['activate', 'deactivate', 'delete'])) {
    api_error('Invalid action or user ID');
}

switch ($action) {
    case 'activate':
        $conn->prepare("UPDATE users SET active=1 WHERE user_id=?")->bind_param("i", $user_id) && $conn->query("UPDATE users SET active=1 WHERE user_id=$user_id");
        api_success([], 'Student activated');
        break;
    case 'deactivate':
        $conn->query("UPDATE users SET active=0 WHERE user_id=$user_id");
        api_success([], 'Student deactivated');
        break;
    case 'delete':
        $conn->query("DELETE FROM users WHERE user_id=$user_id");
        api_success([], 'Student deleted');
        break;
}

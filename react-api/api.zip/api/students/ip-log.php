<?php
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../middleware/auth.php';

require_method('GET');
$jwt = require_jwt();
require_permission('students_with_ip', $jwt);

[$page, $per_page, $offset] = get_pagination();
$search = get_search();
$type = $_GET['type'] ?? '';

$where = "WHERE 1=1";
$params = [];
$types = '';

if ($search) {
    $like = "%$search%";
    $where .= " AND (ip.ip_address LIKE ? OR ip.user_id LIKE ? OR u.email LIKE ?)";
    $params = [$like, $like, $like];
    $types = 'sss';
}
if ($type) {
    $where .= " AND ip.type = ?";
    $params[] = $type;
    $types .= 's';
}

$stmt = $conn->prepare("SELECT COUNT(*) AS c FROM admin_ip ip JOIN users u ON u.user_id = ip.user_id $where");
if ($params) $stmt->bind_param($types, ...$params);
$stmt->execute();
$total = $stmt->get_result()->fetch_assoc()['c'];

$sql = "
    SELECT ip.user_id, u.name, u.email, ip.ip_address,
           COALESCE(ip.type,'') AS type, COALESCE(ip.domain,'') AS domain,
           ip.created_at AS accessed_at
    FROM admin_ip ip
    JOIN users u ON u.user_id = ip.user_id
    $where ORDER BY ip.id DESC LIMIT ? OFFSET ?
";
$stmt = $conn->prepare($sql);
$allParams = array_merge($params, [$per_page, $offset]);
$stmt->bind_param($types . 'ii', ...$allParams);
$stmt->execute();
$rows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

api_success(['rows' => $rows, 'total' => (int)$total, 'page' => $page]);

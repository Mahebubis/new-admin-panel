<?php
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../middleware/auth.php';

$jwt = require_jwt();
require_permission('download_student_data', $jwt);

[$page, $per_page, $offset] = get_pagination();
$search = get_search();
$start_date = $_GET['start_date'] ?? '';
$end_date = $_GET['end_date'] ?? '';
$action = $_GET['action'] ?? '';

$where = "WHERE u.active=1 AND u.role=4";
$params = [];
$types = '';

if ($search) {
    $like = "%$search%";
    $where .= " AND u.email LIKE ?";
    $params[] = $like;
    $types .= 's';
}
if ($start_date && $end_date) {
    $where .= " AND DATE(u.registered_at) BETWEEN ? AND ?";
    $params[] = $start_date;
    $params[] = $end_date;
    $types .= 'ss';
}

// CSV download
if ($action === 'download_csv') {
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="students_' . date('Y-m-d') . '.csv"');

    $out = fopen('php://output', 'w');
    fputcsv($out, ['ID', 'Name', 'Email', 'Phone', 'State', 'Gender', 'Registered At']);

    $sql = "SELECT u.user_id, u.name, u.email, u.phone, u.state, u.gender, u.registered_at FROM users u $where ORDER BY u.registered_at DESC";
    $stmt = $conn->prepare($sql);
    if ($params) $stmt->bind_param($types, ...$params);
    $stmt->execute();
    $res = $stmt->get_result();

    while ($row = $res->fetch_assoc()) {
        fputcsv($out, [$row['user_id'], $row['name'], $row['email'], $row['phone'], $row['state'], $row['gender'], $row['registered_at']]);
    }
    fclose($out);
    exit();
}

// JSON listing
$stmt = $conn->prepare("SELECT COUNT(*) AS c FROM users u $where");
if ($params) $stmt->bind_param($types, ...$params);
$stmt->execute();
$total = $stmt->get_result()->fetch_assoc()['c'];

$sql = "
    SELECT u.user_id, u.name, u.email, COALESCE(u.phone,'') AS phone,
           COALESCE(u.state,'') AS state, COALESCE(u.gender,'') AS gender,
           (SELECT CASE WHEN COUNT(*)>0 THEN 'Yes' ELSE 'No' END FROM cit_results r WHERE r.user_id=u.user_id) AS has_given_exam,
           (SELECT COUNT(*) FROM internship_payment ip WHERE ip.user_id=u.user_id) AS internship_count,
           COALESCE(u.cit_id,'') AS batch,
           DATE(u.registered_at) AS registered_at
    FROM users u $where ORDER BY u.registered_at DESC LIMIT ? OFFSET ?
";
$stmt = $conn->prepare($sql);
$allParams = array_merge($params, [$per_page, $offset]);
$stmt->bind_param($types . 'ii', ...$allParams);
$stmt->execute();
$students = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

api_success(['students' => $students, 'total' => (int)$total, 'page' => $page]);

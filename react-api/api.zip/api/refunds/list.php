<?php
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../middleware/auth.php';
require_method('GET');
$jwt = require_jwt();
require_permission('manage_refund', $jwt);

[$page, $per_page, $offset] = get_pagination();
$search = get_search();
$status = $_GET['status'] ?? '';

$where = "WHERE 1=1";
$params = []; $types = '';

if ($search) { $like = "%$search%"; $where .= " AND (u.name LIKE ? OR u.email LIKE ?)"; $params = [$like,$like]; $types = 'ss'; }
if ($status) { $where .= " AND r.status = ?"; $params[] = $status; $types .= 's'; }

$stmt = $conn->prepare("SELECT COUNT(*) AS c FROM refunds r JOIN users u ON u.user_id = r.user_id $where");
if ($params) $stmt->bind_param($types, ...$params);
$stmt->execute();
$total = $stmt->get_result()->fetch_assoc()['c'];

// Stats
$stats_row = $conn->query("
    SELECT COUNT(*) AS total,
        SUM(CASE WHEN status='pending' THEN 1 ELSE 0 END) AS pending,
        SUM(CASE WHEN status='approved' THEN 1 ELSE 0 END) AS approved,
        SUM(CASE WHEN status='rejected' THEN 1 ELSE 0 END) AS rejected,
        SUM(CASE WHEN status='processed' THEN 1 ELSE 0 END) AS processed
    FROM refunds
")->fetch_assoc();

$sql = "
    SELECT r.refund_id, u.name AS student_name, u.email, r.amount,
           COALESCE(il.internship_name,'') AS internship,
           COALESCE(r.reason,'') AS reason, r.status,
           COALESCE(r.payment_id,'') AS payment_id,
           DATE(r.created_at) AS requested_at
    FROM refunds r JOIN users u ON u.user_id = r.user_id
    LEFT JOIN internship_list il ON il.id = r.internship_id
    $where ORDER BY r.created_at DESC LIMIT ? OFFSET ?
";
$stmt = $conn->prepare($sql);
$allParams = array_merge($params, [$per_page, $offset]);
$stmt->bind_param($types . 'ii', ...$allParams);
$stmt->execute();
$refunds = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

api_success(['refunds' => $refunds, 'total' => (int)$total, 'page' => $page, 'stats' => $stats_row]);

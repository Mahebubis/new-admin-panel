<?php
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../middleware/auth.php';
require_method('GET');
$jwt = require_jwt();
require_permission('manage_coupons', $jwt);

[$page, $per_page, $offset] = get_pagination();
$search = get_search();

$where = "WHERE 1=1";
$params = []; $types = '';
if ($search) { $like = "%$search%"; $where .= " AND c.code LIKE ?"; $params = [$like]; $types = 's'; }

$stmt = $conn->prepare("SELECT COUNT(*) AS c FROM istudio_coupons c $where");
if ($params) $stmt->bind_param($types, ...$params);
$stmt->execute();
$total = $stmt->get_result()->fetch_assoc()['c'];

$sql = "
    SELECT c.*, COUNT(cu.id) AS usage_count
    FROM istudio_coupons c
    LEFT JOIN coupon_usage cu ON cu.coupon_id = c.id AND cu.status = 'used'
    $where GROUP BY c.id ORDER BY c.id DESC LIMIT ? OFFSET ?
";
$stmt = $conn->prepare($sql);
$allParams = array_merge($params, [$per_page, $offset]);
$stmt->bind_param($types . 'ii', ...$allParams);
$stmt->execute();
$coupons = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

api_success(['coupons' => $coupons, 'total' => (int)$total, 'page' => $page]);

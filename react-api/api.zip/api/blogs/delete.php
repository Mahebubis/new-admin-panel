<?php
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../middleware/auth.php';
require_method('DELETE');
$jwt = require_jwt();
require_permission('manage_blogs', $jwt);

$input = get_json_input();
$id = intval($input['id'] ?? 0);
if (!$id) api_error('Blog ID required');

$conn->query("DELETE FROM blogs WHERE blog_id = $id");
api_success([], 'Blog deleted');

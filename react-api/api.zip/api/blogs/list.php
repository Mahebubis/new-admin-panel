<?php
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../middleware/auth.php';
require_method('GET');
$jwt = require_jwt();

[$page, $per_page, $offset] = get_pagination();
$search = get_search();

$where = "WHERE 1=1";
$params = []; $types = '';
if ($search) { $like = "%$search%"; $where .= " AND (title LIKE ? OR category LIKE ?)"; $params = [$like,$like]; $types = 'ss'; }

$stmt = $conn->prepare("SELECT COUNT(*) AS c FROM blogs $where");
if ($params) $stmt->bind_param($types, ...$params);
$stmt->execute();
$total = $stmt->get_result()->fetch_assoc()['c'];

$sql = "SELECT blog_id, title, COALESCE(category,'') AS category, COALESCE(author,'Admin') AS author, status, COALESCE(views,0) AS views, DATE(created_at) AS created_at FROM blogs $where ORDER BY created_at DESC LIMIT ? OFFSET ?";
$stmt = $conn->prepare($sql);
$allParams = array_merge($params, [$per_page, $offset]);
$stmt->bind_param($types . 'ii', ...$allParams);
$stmt->execute();
$blogs = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

api_success(['blogs' => $blogs, 'total' => (int)$total, 'page' => $page]);

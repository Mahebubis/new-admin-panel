<?php
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../middleware/auth.php';
require_method('POST');
$jwt = require_jwt();
require_permission('add_blogs', $jwt);

$input = get_json_input();
$title = trim($input['title'] ?? '');
$category = trim($input['category'] ?? '');
$content = $input['content'] ?? '';
$status = in_array($input['status'] ?? '', ['draft','published']) ? $input['status'] : 'draft';

if (!$title || !$content) api_error('Title and content required');

$admin_id = $jwt['user_id'];
$author = $conn->query("SELECT name FROM users WHERE user_id=$admin_id")->fetch_assoc()['name'] ?? 'Admin';
$excerpt = substr(strip_tags($content), 0, 200);

$stmt = $conn->prepare("INSERT INTO blogs (title, category, author, content, excerpt, status, created_by) VALUES (?,?,?,?,?,?,?)");
$stmt->bind_param("ssssssi", $title, $category, $author, $content, $excerpt, $status, $admin_id);
$stmt->execute();

api_success(['blog_id' => $conn->insert_id], 'Blog created');

<?php
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../middleware/auth.php';

require_method('GET');
$jwt = require_jwt();
require_permission('dashboard', $jwt);

$days = max(1, min(90, intval($_GET['days'] ?? 7)));

// Registered per day
$stmt = $conn->prepare("
    SELECT DATE(registered_at) AS d, COUNT(*) AS c
    FROM users WHERE role=4 AND applyforexam=1 AND registered_at >= DATE_SUB(CURDATE(), INTERVAL ? DAY)
    GROUP BY DATE(registered_at)
");
$stmt->bind_param("i", $days);
$stmt->execute();
$regMap = [];
$res = $stmt->get_result();
while ($r = $res->fetch_assoc()) $regMap[$r['d']] = (int)$r['c'];

// Unregistered per day
$stmt = $conn->prepare("
    SELECT DATE(registered_at) AS d, COUNT(*) AS c
    FROM users WHERE role=4 AND (applyforexam=0 OR applyforexam IS NULL) AND registered_at >= DATE_SUB(CURDATE(), INTERVAL ? DAY)
    GROUP BY DATE(registered_at)
");
$stmt->bind_param("i", $days);
$stmt->execute();
$unregMap = [];
$res = $stmt->get_result();
while ($r = $res->fetch_assoc()) $unregMap[$r['d']] = (int)$r['c'];

$labels = []; $registered = []; $unregistered = []; $total = [];

for ($i = $days - 1; $i >= 0; $i--) {
    $date = date('Y-m-d', strtotime("-$i days"));
    $label = date('d M', strtotime($date));
    $reg = $regMap[$date] ?? 0;
    $unreg = $unregMap[$date] ?? 0;

    $labels[] = $label;
    $registered[] = $reg;
    $unregistered[] = $unreg;
    $total[] = $reg + $unreg;
}

api_success([
    'labels' => $labels,
    'registered' => $registered,
    'unregistered' => $unregistered,
    'total' => $total,
]);

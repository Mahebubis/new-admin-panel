<?php
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../middleware/auth.php';

require_method('GET');
$jwt = require_jwt();
require_permission('dashboard', $jwt);

$items = [];

// Recent registrations
$res = $conn->query("SELECT name, registered_at FROM users WHERE role=4 ORDER BY user_id DESC LIMIT 4");
while ($r = $res->fetch_assoc()) {
    $diff = time() - strtotime($r['registered_at']);
    $time = $diff < 60 ? 'just now' : ($diff < 3600 ? floor($diff/60).'m ago' : ($diff < 86400 ? floor($diff/3600).'h ago' : floor($diff/86400).'d ago'));
    $items[] = ['type' => 'registration', 'message' => $r['name'] . ' signed up', 'status' => 'new', 'time' => $time];
}

// Recent payments
$res = $conn->query("SELECT amount, timestamp, internship_name FROM payment_status WHERE status='captured' ORDER BY id DESC LIMIT 3");
while ($r = $res->fetch_assoc()) {
    $diff = time() - strtotime($r['timestamp']);
    $time = $diff < 3600 ? floor($diff/60).'m ago' : ($diff < 86400 ? floor($diff/3600).'h ago' : floor($diff/86400).'d ago');
    $items[] = ['type' => 'payment', 'message' => '₹' . $r['amount'] . ' payment for ' . $r['internship_name'], 'status' => 'captured', 'time' => $time];
}

// Pending refunds
$res = $conn->query("SELECT refund_id, created_at FROM refunds WHERE status='pending' ORDER BY refund_id DESC LIMIT 2");
while ($r = $res->fetch_assoc()) {
    $diff = time() - strtotime($r['created_at']);
    $time = $diff < 3600 ? floor($diff/60).'m ago' : ($diff < 86400 ? floor($diff/3600).'h ago' : floor($diff/86400).'d ago');
    $items[] = ['type' => 'refund', 'message' => 'Refund #' . $r['refund_id'] . ' is pending', 'status' => 'pending', 'time' => $time];
}

api_success(['items' => $items]);

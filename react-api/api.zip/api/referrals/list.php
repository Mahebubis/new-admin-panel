<?php
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../middleware/auth.php';
require_method('GET');
$jwt = require_jwt();
require_permission('manage_referrals', $jwt);

[$page, $per_page, $offset] = get_pagination();
$search = get_search();
$status = $_GET['status'] ?? '';

$where = "WHERE EXISTS(SELECT 1 FROM referrals r WHERE r.referrer_user_id = u.user_id)";
$params = []; $types = '';

if ($search) { $like = "%$search%"; $where .= " AND (u.name LIKE ? OR u.email LIKE ?)"; $params = [$like,$like]; $types = 'ss'; }

$having = '';
if ($status) { $having = $status === 'active' ? "HAVING 1=1" : ""; }

$stmt = $conn->prepare("SELECT COUNT(DISTINCT u.user_id) AS c FROM users u $where");
if ($params) $stmt->bind_param($types, ...$params);
$stmt->execute();
$total = $stmt->get_result()->fetch_assoc()['c'];

$sql = "
    SELECT u.user_id AS referral_id, u.name AS referrer_name, u.email AS referrer_email,
           CASE WHEN u.active=1 THEN 'active' ELSE 'inactive' END AS status,
           DATE(u.registered_at) AS joined_at,
           COUNT(DISTINCT r.id) AS referred_count,
           COALESCE(SUM(re.amount),0) AS total_earnings, 0 AS pending_amount
    FROM users u
    LEFT JOIN referrals r ON r.referrer_user_id = u.user_id
    LEFT JOIN referral_earnings re ON re.referral_id = r.id
    $where GROUP BY u.user_id ORDER BY total_earnings DESC LIMIT ? OFFSET ?
";
$stmt = $conn->prepare($sql);
$allParams = array_merge($params, [$per_page, $offset]);
$stmt->bind_param($types . 'ii', ...$allParams);
$stmt->execute();
$referrals = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

api_success(['referrals' => $referrals, 'total' => (int)$total, 'page' => $page]);

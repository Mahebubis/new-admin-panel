<?php
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../middleware/auth.php';
require_method('GET');
$jwt = require_jwt();
require_permission('manage_withdrawal', $jwt);

[$page, $per_page, $offset] = get_pagination();
$search = get_search();
$status = $_GET['status'] ?? '';

$where = "WHERE 1=1";
$params = []; $types = '';

if ($search) { $like = "%$search%"; $where .= " AND (u.name LIKE ? OR u.email LIKE ? OR w.upi_id LIKE ?)"; $params = [$like,$like,$like]; $types = 'sss'; }
if ($status) { $where .= " AND w.payment_status = ?"; $params[] = $status; $types .= 's'; }

$stmt = $conn->prepare("SELECT COUNT(*) AS c FROM withdrawal_request w JOIN users u ON u.user_id = w.user_id $where");
if ($params) $stmt->bind_param($types, ...$params);
$stmt->execute();
$total = $stmt->get_result()->fetch_assoc()['c'];

$sql = "
    SELECT w.id AS withdrawal_id, u.name AS student_name, u.email,
           w.payment_amount AS amount, COALESCE(w.upi_id,'') AS upi_id,
           w.payment_status AS status, DATE(w.created_at) AS requested_at
    FROM withdrawal_request w JOIN users u ON u.user_id = w.user_id
    $where ORDER BY w.created_at DESC LIMIT ? OFFSET ?
";
$stmt = $conn->prepare($sql);
$allParams = array_merge($params, [$per_page, $offset]);
$stmt->bind_param($types . 'ii', ...$allParams);
$stmt->execute();
$withdrawals = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

api_success(['withdrawals' => $withdrawals, 'total' => (int)$total, 'page' => $page]);

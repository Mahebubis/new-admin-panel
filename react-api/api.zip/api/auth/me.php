<?php
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../middleware/auth.php';

require_method('GET');
$jwt = require_jwt();

$uid = $jwt['user_id'];

$stmt = $conn->prepare("SELECT user_id, name, email, photo, is_admin, role FROM users WHERE user_id = ?");
$stmt->bind_param("i", $uid);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();

if (!$user) {
    api_error('User not found', 404);
}

// Get permissions
$permissions = ['dashboard'];
$is_superadmin = 0;

$admin_check = $conn->query("SELECT is_superadmin FROM admin_users WHERE user_id = $uid AND is_active = 1");
if ($admin_check && $admin_row = $admin_check->fetch_assoc()) {
    if ($admin_row['is_superadmin']) {
        $is_superadmin = 1;
        $permissions = ['__superadmin__'];
    } else {
        $perm_res = $conn->query("SELECT permission_key FROM admin_permissions WHERE user_id = $uid AND granted = 1");
        if ($perm_res) {
            while ($p = $perm_res->fetch_assoc()) {
                $permissions[] = $p['permission_key'];
            }
        }
        $permissions = array_unique($permissions);
    }
} else {
    // Fallback for users who are admin via role/is_admin flag
    $permissions = ['__superadmin__'];
    $is_superadmin = 1;
}

api_success([
    'user' => [
        'user_id' => (int)$user['user_id'],
        'name' => $user['name'],
        'email' => $user['email'],
        'photo' => $user['photo'] ?? '',
        'is_admin' => (int)($user['is_admin'] ?? 0),
        'is_superadmin' => $is_superadmin,
        'permissions' => $permissions,
    ]
]);

<?php
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../middleware/auth.php';
require_method('GET');
$jwt = require_jwt();
require_permission('netcore_behaviour', $jwt);

// Netcore behaviour analytics - this returns mock/aggregated data
// In production, this would query the Netcore API or a local analytics table

$event = $_GET['event'] ?? 'register';
$range = $_GET['range'] ?? '7';
$from_date = $_GET['from_date'] ?? '';
$to_date = $_GET['to_date'] ?? '';

// Event counts from users table as approximation
$event_counts = [
    'register' => $conn->query("SELECT COUNT(*) AS c FROM users WHERE role=4")->fetch_assoc()['c'] ?? 0,
    'signin' => $conn->query("SELECT COUNT(*) AS c FROM users WHERE role=4 AND active=1")->fetch_assoc()['c'] ?? 0,
    'exam_success' => $conn->query("SELECT COUNT(*) AS c FROM cit_results WHERE score >= 60")->fetch_assoc()['c'] ?? 0,
    'course_purchase' => $conn->query("SELECT COUNT(*) AS c FROM internship_payment")->fetch_assoc()['c'] ?? 0,
    'payment_success' => $conn->query("SELECT COUNT(*) AS c FROM payment_status WHERE status='captured'")->fetch_assoc()['c'] ?? 0,
    'preferred_domain' => 0,
];

// Users for selected event
$users = [];
$chart = [];

if ($event === 'register') {
    $dateWhere = "WHERE role=4";
    if ($from_date && $to_date) {
        $dateWhere .= " AND DATE(registered_at) BETWEEN '$from_date' AND '$to_date'";
    } elseif ($range !== 'custom') {
        $dateWhere .= " AND registered_at >= DATE_SUB(NOW(), INTERVAL $range DAY)";
    }

    $res = $conn->query("SELECT email, DATE(registered_at) AS date FROM users $dateWhere ORDER BY registered_at DESC LIMIT 100");
    while ($r = $res->fetch_assoc()) $users[] = $r;

    $res = $conn->query("SELECT DATE(registered_at) AS date, COUNT(*) AS count FROM users $dateWhere GROUP BY DATE(registered_at) ORDER BY date");
    while ($r = $res->fetch_assoc()) $chart[] = $r;
} elseif ($event === 'payment_success') {
    $dateWhere = "WHERE status='captured'";
    if ($range !== 'custom') $dateWhere .= " AND timestamp >= DATE_SUB(NOW(), INTERVAL $range DAY)";

    $res = $conn->query("SELECT ps.internship_name AS email, DATE(ps.timestamp) AS date FROM payment_status ps $dateWhere ORDER BY ps.id DESC LIMIT 100");
    while ($r = $res->fetch_assoc()) $users[] = $r;

    $res = $conn->query("SELECT DATE(timestamp) AS date, COUNT(*) AS count FROM payment_status $dateWhere GROUP BY DATE(timestamp) ORDER BY date");
    while ($r = $res->fetch_assoc()) $chart[] = $r;
}

api_success(['event_counts' => $event_counts, 'users' => $users, 'chart' => $chart]);

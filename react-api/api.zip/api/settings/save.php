<?php
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../middleware/auth.php';
require_method('POST');
$jwt = require_jwt();
require_permission('settings', $jwt);

$input = get_json_input();
$settings = $input['settings'] ?? [];

$allowed = ['site_name','support_email','admin_email','timezone','session_timeout','otp_expiry',
    'max_login_attempts','lockout_duration','smtp_host','smtp_port','smtp_user','smtp_pass',
    'aws_region','aws_instance','netcore_api_key','notify_new_student','notify_payment',
    'notify_refund','notify_exam','notify_ticket','notify_low_seats'];

$count = 0;
$stmt = $conn->prepare("INSERT INTO platform_settings (setting_key, setting_value) VALUES (?,?) ON DUPLICATE KEY UPDATE setting_value=VALUES(setting_value), updated_at=NOW()");

foreach ($settings as $key => $value) {
    if (!in_array($key, $allowed)) continue;
    if (strpos($value, '***') === 0) continue; // Skip masked passwords
    $stmt->bind_param("ss", $key, $value);
    $stmt->execute();
    $count++;
}

$admin_id = $jwt['user_id'];
$conn->query("INSERT INTO admin_action_log (admin_id, action, target_type, target_id, note, created_at) VALUES ($admin_id, 'settings_update', 'settings', 0, '$count settings saved', NOW())");

api_success([], "$count settings saved");

<?php
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../middleware/auth.php';
require_method('GET');
$jwt = require_jwt();
require_permission('settings', $jwt);

$res = $conn->query("SELECT setting_key, setting_value FROM platform_settings");
$settings = [];
while ($row = $res->fetch_assoc()) {
    // Mask sensitive values
    $key = $row['setting_key'];
    if (preg_match('/(pass|secret|key)/i', $key) && $row['setting_value']) {
        $row['setting_value'] = str_repeat('*', 12);
    }
    $settings[] = $row;
}

api_success(['settings' => $settings]);

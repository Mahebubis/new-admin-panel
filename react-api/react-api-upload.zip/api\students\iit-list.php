<?php
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../middleware/auth.php';

require_method('GET');
$jwt = require_jwt();
require_permission('all_iit_students', $jwt);

[$page, $per_page, $offset] = get_pagination();
$search = get_search();

// Same SQL as all_students but filtered for IIT colleges
$iit_filter = "(u.college_name LIKE '%IIT%' OR u.college_name LIKE '%Indian Institute of Technology%')";

if ($search) {
    $keyword = $conn->real_escape_string($search);
    $sql = "SELECT u.*, ad.*
            FROM users u
            INNER JOIN additional_details ad ON u.user_id = ad.user_id
            WHERE u.role = 4 AND $iit_filter
            AND (u.user_id = '$keyword' OR u.email LIKE '%$keyword%' OR u.phone LIKE '%$keyword%' OR u.name LIKE '%$keyword%')
            ORDER BY u.registered_at DESC";
    $result = $conn->query($sql);
    $students = [];
    if ($result) { while ($row = $result->fetch_assoc()) { unset($row['password']); $students[] = $row; } }
    api_success(['students' => $students, 'total' => count($students), 'page' => 1]);
} else {
    $total = (int)$conn->query("SELECT COUNT(*) AS c FROM users u WHERE u.role = 4 AND $iit_filter")->fetch_assoc()['c'];
    $registered = (int)$conn->query("SELECT COUNT(*) AS c FROM users u WHERE u.role = 4 AND u.applyforexam = 1 AND $iit_filter")->fetch_assoc()['c'];

    $sql = "SELECT u.*, ad.*
            FROM users u
            INNER JOIN additional_details ad ON u.user_id = ad.user_id
            WHERE u.role = 4 AND $iit_filter
            ORDER BY u.registered_at DESC
            LIMIT $per_page OFFSET $offset";
    $result = $conn->query($sql);
    $students = [];
    if ($result) { while ($row = $result->fetch_assoc()) { unset($row['password']); $students[] = $row; } }

    api_success(['students' => $students, 'total' => $total, 'registered' => $registered, 'unregistered' => $total - $registered, 'page' => $page]);
}

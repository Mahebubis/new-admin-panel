<?php
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../config/cache.php';
require_once __DIR__ . '/../../middleware/auth.php';

require_method('GET');
$jwt = require_jwt();
require_permission('dashboard', $jwt);

// Check cache first (30 second TTL)
$cache_key = 'dashboard_stats';
$cached = cache_get($cache_key);
if ($cached) { api_success($cached); }

// Single optimized query for student counts
$row = $conn->query("
    SELECT
        COUNT(CASE WHEN role=4 THEN 1 END) AS total_students,
        COUNT(CASE WHEN role=4 AND applyforexam=1 THEN 1 END) AS registered_students,
        COUNT(CASE WHEN online_status='online' THEN 1 END) AS online_users,
        COUNT(CASE WHEN role=4 AND DATE(registered_at)=CURDATE() THEN 1 END) AS today_signups,
        COUNT(CASE WHEN role=4 AND registered_at >= DATE_SUB(NOW(),INTERVAL 7 DAY) THEN 1 END) AS week_signups
    FROM users
")->fetch_assoc();

$revenue = $conn->query("SELECT COALESCE(SUM(CAST(amount AS DECIMAL(10,2))),0) AS t FROM payment_status WHERE status='captured'")->fetch_assoc()['t'];

$pending_refunds = 0;
$r = $conn->query("SELECT COUNT(*) AS c FROM refunds WHERE status='pending'");
if ($r) $pending_refunds = $r->fetch_assoc()['c'] ?? 0;

$open_tickets = 0;
$r = $conn->query("SELECT COUNT(*) AS c FROM support_tickets WHERE status='open'");
if ($r) $open_tickets = $r->fetch_assoc()['c'] ?? 0;

$active_internships = 0;
$r = $conn->query("SELECT COUNT(*) AS c FROM internship_list WHERE show_internship=1");
if ($r) $active_internships = $r->fetch_assoc()['c'] ?? 0;

$total = (int)$row['total_students'];
$registered = (int)$row['registered_students'];
$pct = $total > 0 ? round(($registered / $total) * 100, 1) : 0;

$result = [
    'total_students' => $total,
    'registered_students' => $registered,
    'unregistered' => $total - $registered,
    'online_users' => (int)$row['online_users'],
    'today_signups' => (int)$row['today_signups'],
    'week_signups' => (int)$row['week_signups'],
    'registration_pct' => $pct,
    'total_revenue' => '₹' . number_format($revenue, 0),
    'pending_refunds' => (int)$pending_refunds,
    'open_tickets' => (int)$open_tickets,
    'active_internships' => (int)$active_internships,
];

cache_set($cache_key, $result, 30);
api_success($result);

<?php
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../middleware/auth.php';
require_method('GET');
$jwt = require_jwt();
require_permission('manage_withdrawal', $jwt);

// Original PHP calls dashboard.internshipstudio.com
$page = intval($_GET['page'] ?? 1);
$search = $_GET['search'] ?? '';
$status = $_GET['status'] ?? '';
$startDate = $_GET['startDate'] ?? '';
$endDate = $_GET['endDate'] ?? '';

$url = "https://dashboard.internshipstudio.com/api/get_withdrawal_request.php?"
     . "page=$page"
     . "&search=" . urlencode($search)
     . "&status=" . urlencode($status)
     . "&startDate=" . urlencode($startDate)
     . "&endDate=" . urlencode($endDate);

$ch = curl_init($url);
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_TIMEOUT => 15,
    CURLOPT_SSL_VERIFYPEER => false,
]);
$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$error = curl_error($ch);
curl_close($ch);

if ($error || $httpCode >= 400) {
    // Fallback to local DB
    [$pg, $per_page, $offset] = get_pagination();
    $stmt = $conn->prepare("SELECT COUNT(*) AS c FROM withdrawal_request");
    $stmt->execute();
    $total = $stmt->get_result()->fetch_assoc()['c'] ?? 0;

    $sql = "SELECT w.id AS withdrawal_id, u.name AS student_name, u.email,
            w.payment_amount AS amount, COALESCE(w.upi_id,'') AS upi_id,
            w.payment_status AS status, DATE(w.created_at) AS requested_at
            FROM withdrawal_request w JOIN users u ON u.user_id = w.user_id
            ORDER BY w.created_at DESC LIMIT ? OFFSET ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('ii', $per_page, $offset);
    $stmt->execute();
    $withdrawals = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

    api_success(['withdrawals' => $withdrawals, 'total' => (int)$total, 'page' => $pg]);
}

$data = json_decode($response, true);

if ($data) {
    $withdrawals = [];
    foreach (($data['data'] ?? []) as $item) {
        $withdrawals[] = [
            'withdrawal_id' => $item['id'] ?? '',
            'student_name' => $item['name'] ?? '',
            'email' => $item['email'] ?? '',
            'amount' => $item['amount'] ?? 0,
            'upi_id' => $item['upi_id'] ?? '',
            'status' => $item['status'] ?? 'pending',
            'proof' => $item['proof'] ?? '',
            'requested_at' => $item['requested_at'] ?? '',
        ];
    }
    $pagination = $data['pagination'] ?? [];
    api_success([
        'withdrawals' => $withdrawals,
        'total' => $pagination['total'] ?? count($withdrawals),
        'page' => $pagination['page'] ?? $page,
    ]);
} else {
    api_error('Failed to fetch withdrawal data', 502);
}

<?php
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../middleware/auth.php';

require_method('GET');
$jwt = require_jwt();
require_permission('all_students', $jwt);

[$page, $per_page, $offset] = get_pagination();
$search = get_search();

// Exact same SQL as PHP: SELECT * FROM users INNER JOIN additional_details
if ($search) {
    // Search mode — same as fetch_student_by_keyword()
    $keyword = $conn->real_escape_string($search);
    $sql = "SELECT u.*, ad.*
            FROM users u
            INNER JOIN additional_details ad ON u.user_id = ad.user_id
            WHERE u.role = 4
            AND (
                u.user_id = '$keyword'
                OR u.email LIKE '%$keyword%'
                OR u.phone LIKE '%$keyword%'
                OR u.name LIKE '%$keyword%'
            )
            ORDER BY u.registered_at DESC";
    $result = $conn->query($sql);
    $students = [];
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            unset($row['password']);
            $students[] = $row;
        }
    }
    api_success(['students' => $students, 'total' => count($students), 'page' => 1]);
} else {
    // Paginated mode — same as fetch_all_students()
    // Count
    $count_row = $conn->query("SELECT COUNT(*) AS count FROM users WHERE role = 4")->fetch_assoc();
    $total = (int)($count_row['count'] ?? 0);

    // Registered count
    $reg_row = $conn->query("SELECT COUNT(*) AS count FROM users WHERE role = 4 AND applyforexam = 1")->fetch_assoc();
    $registered = (int)($reg_row['count'] ?? 0);

    // Data — exact same JOIN as PHP
    $sql = "SELECT u.*, ad.*
            FROM users u
            INNER JOIN additional_details ad ON u.user_id = ad.user_id
            WHERE u.role = 4
            ORDER BY u.registered_at DESC
            LIMIT $per_page OFFSET $offset";
    $result = $conn->query($sql);
    $students = [];
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            unset($row['password']);
            $students[] = $row;
        }
    }

    api_success([
        'students' => $students,
        'total' => $total,
        'registered' => $registered,
        'unregistered' => $total - $registered,
        'page' => $page
    ]);
}

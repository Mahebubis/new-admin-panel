<?php
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../middleware/auth.php';
require_method('POST');
$jwt = require_jwt();
require_permission('all_students', $jwt);

$input = get_json_input();
$user_id = intval($input['user_id'] ?? 0);
if (!$user_id) api_error('User ID required');

// Fields that can be updated on users table (same as PHP edit_by_admin.php)
$user_fields = ['fname','lname','name','email','phone','city','state','pincode','gender',
    'college_name','program','year','branch','other_branch','role','applyforexam',
    'active','is_test_account','payment_id','payment_status','payment_amount',
    'used_ref_id','ca_ref_id','cc_ref_id','used_ref_id_by_ca','certificate',
    'current_exam_date','whatsapp'];

$sets = [];
$params = [];
$types = '';

foreach ($user_fields as $field) {
    if (array_key_exists($field, $input)) {
        $sets[] = "`$field` = ?";
        $params[] = $input[$field];
        $types .= 's';
    }
}

// Handle password change
if (!empty($input['password'])) {
    $sets[] = "`password` = ?";
    $params[] = password_hash($input['password'], PASSWORD_BCRYPT);
    $types .= 's';
}

if (!empty($sets)) {
    $params[] = $user_id;
    $types .= 'i';
    $sql = "UPDATE users SET " . implode(', ', $sets) . " WHERE user_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param($types, ...$params);
    $stmt->execute();
}

// Update user_steps table
$steps_fields = ['cit_registration','cit_whatsapp_community','cit_exam_details','cit_exam_result',
    'cit_internship_selection','istudio_training_portal','istudio_project_submission',
    'istudio_certificates','user_profile','hiring_portal'];

$step_sets = [];
$step_params = [];
$step_types = '';

foreach ($steps_fields as $field) {
    if (array_key_exists($field, $input)) {
        $step_sets[] = "`$field` = ?";
        $step_params[] = $input[$field];
        $step_types .= 's';
    }
}

if (!empty($step_sets)) {
    // Check if user_steps row exists
    $check = $conn->query("SELECT user_id FROM user_steps WHERE user_id = $user_id");
    if ($check && $check->num_rows > 0) {
        $step_params[] = $user_id;
        $step_types .= 'i';
        $sql = "UPDATE user_steps SET " . implode(', ', $step_sets) . " WHERE user_id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param($step_types, ...$step_params);
        $stmt->execute();
    }
}

api_success([], 'Student updated successfully');
